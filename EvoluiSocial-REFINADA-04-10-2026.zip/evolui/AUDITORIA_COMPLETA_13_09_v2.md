# Auditoria completa — 13/09 (revisão linha a linha)

## Atualização (mesmo dia, depois de você já ter rodado a v1 e confirmado tudo "true")

Você rodou o `SQL_FIX_completo_13_09.sql` (v1 desta auditoria), a query de conferência do final voltou com **tudo `true`**, e mesmo assim o card de Metas do Início continuou mostrando **"Falha ao consultar atividades (400)"**.

Isso não invalida a v1 — as 10 tabelas que ela criou realmente existem, e isso foi confirmado de verdade. O problema é outro, e é importante eu deixar registrado com todas as letras: **a query de conferência só prova que TABELAS existem. Ela nunca checou COLUNA por coluna, nem CONSTRAINT por constraint.** Existem 3 migrações pequenas e independentes — `SQL_PENDENTE_estados_rapidos.sql`, `SQL_PENDENTE_inteligencia.sql` e parte de `SQL_PENDENTE_clientes.sql` — que criam colunas/liberam valores em `admin_prospeccao_atividades` e `admin_prospeccao_leads` (tabelas que já existiam) e que nunca tinham sido incorporadas em nenhuma versão do arquivo consolidado. Achei isso ao investigar o seu print do erro atual, comparando a query exata que falha (`relatorioService.js:buscarAtividadesPeriodo`, que pede `status_anterior`/`status_novo`) com o schema real.

Enquanto corrigia esse ponto específico, fui além do que o print mostrava (por causa do seu pedido de não deixar passar nenhum 400/404) e conferi, um por um, todo `tipo`/`status` que o código grava contra a constraint que o banco aceita hoje — achei mais 2 pontos na mesma situação (abaixo, itens 8 e 9). Os três já estão corrigidos na `SQL_FIX_completo_13_09.sql` (seção 3d) — continua sendo o mesmo único arquivo, agora mais completo, e a query de conferência do final também foi ampliada pra checar coluna e constraint, não só tabela.

## O que foi pedido

"Verificar código caractere por caractere", entender por que os mesmos tipos de erro (404/400) continuam aparecendo mesmo depois de eu já ter mandado correções, e entregar de uma vez **todos** os problemas encontrados — inclusive os que ainda não foram reportados — pra não precisar repetir esse ciclo.

## Metodologia

Não foi uma releitura visual do código. Foi uma comparação automatizada, arquivo por arquivo:

1. Extraí, de **todos** os arquivos `SQL_PENDENTE_*.sql` e `SQL_FIX_*.sql`, a lista completa de tabelas e colunas que eles criam (`create table` + todo `alter table ... add column`, inclusive os que têm várias colunas na mesma instrução — foi aí que apareceu o achado principal, explico abaixo).
2. Extraí, de **todas** as 38 Netlify Functions e seus serviços (`netlify/functions/_lib/services/*.js`), toda tabela, toda coluna usada em filtro (`?coluna=eq....`), toda coluna pedida em `select=` e toda coluna escrita no corpo de cada `INSERT`/`PATCH`.
3. Cruzei as duas listas: qualquer coluna ou tabela usada no código que não existe em nenhum SQL é um 404/400 esperando pra acontecer.
4. Conferi também se toda chamada `/.netlify/functions/X` que o painel faz tem, de fato, um arquivo `X.js` correspondente (um segundo jeito de dar 404, sem ser problema de banco).
5. Rodei a suíte de testes inteira de novo no final (**156 testes, todos passando**) e `node --check` em todo arquivo `.js` do projeto (zero erro de sintaxe).

## O achado principal — a causa raiz de vários problemas em cascata

**`SQL_PENDENTE_equipe_permissoes.sql` tinha um bloco que aborta sozinho, sempre no mesmo lugar, toda vez que é executado.**

Esse arquivo tem uma seção (a de número 11) que aplica "só admin pode mexer" numa lista de 10 tabelas, de uma vez, usando um loop:

```sql
foreach tabela in array array[
  'admin_settings', 'admin_posts', 'admin_pages', 'site_content',
  'admin_tarefas', 'admin_relatorios', 'admin_ai_usage', 'admin_insights_historico',
  'consultas_leads', 'consultas_atividades'
]
loop
  execute format('... on %1$s', tabela);
  ...
```

O problema: **`admin_tarefas`, `admin_ai_usage` e `admin_insights_historico` nunca tiveram uma migração própria em nenhum arquivo do projeto.** Elas simplesmente nunca foram criadas. E em Postgres, tentar alterar/criar política numa tabela que não existe é **erro imediato — não um aviso, um erro que para a execução ali mesmo**.

Como esse loop roda dentro de um bloco `do $$ ... end $$;`, o erro aborta o bloco inteiro. E como tudo isso está dentro de UM ARQUIVO SQL colado de uma vez no SQL Editor do Supabase, **tudo que vem depois desse bloco no mesmo arquivo nunca chega a rodar** — inclusive a seção 12, que configura a permissão de quem pode ver a trilha de auditoria (`admin_audit_log`).

Isso explica o padrão que se repetiu várias vezes nesta conversa: um SQL que "às vezes aplica, às vezes não", mesmo sendo idempotente. Não é sobre idempotência — é que o script nunca terminava de rodar.

**Efeito prático, ainda não reportado:** se você entrar em Sistema/Diagnóstico hoje, as abas **"Tarefas"** e **"Auditoria"** muito provavelmente estão dando erro de carregamento — mesmo sem relação nenhuma com Bianca, metas ou envios.

## Todos os problemas encontrados (e o que resolve cada um)

| # | Problema | Onde aparece | Causa | Resolvido em |
|---|---|---|---|---|
| 1 | "Falha ao consultar envios (404)" | Início, filtro "últimos 7 dias" | `admin_prospeccao_buscas`/`admin_prospeccao_envios` nunca criadas (migração parcial de `SQL_PENDENTE_prospeccao.sql`) | `SQL_FIX_completo_13_09.sql` §3b |
| 2 | "Não foi possível carregar metas" (400) | Início, card de Metas | `admin_metas_prospeccao` nunca criada | `SQL_FIX_completo_13_09.sql` §3 |
| 3 | Notificações não carregam / 504 | Início, card de Notificações | `admin_notificacoes` nunca teve migração rastreada no projeto | `SQL_FIX_completo_13_09.sql` §1 |
| 4 | **(novo, não reportado ainda)** Tarefas e Auditoria não devem carregar | Sistema/Diagnóstico | Causa raiz acima — 3 tabelas faltando abortam o script antes de chegar nas policies de auditoria | `SQL_FIX_completo_13_09.sql` §3c |
| 5 | Uso de IA nunca é registrado (não trava nada, mas some do controle de custo) | Interno — geração de diagnóstico/apresentação por IA em Clientes | `admin_ai_usage` nunca criada (essa parte falha em silêncio, por design — não derruba a geração) | `SQL_FIX_completo_13_09.sql` §3c |
| 6 | Página "Inteligência" (já fora do menu) ficaria quebrada se reativada | — (não está no menu hoje) | `admin_insights_historico` nunca criada | `SQL_FIX_completo_13_09.sql` §3c |
| 7 | `analyticsClient.js` chama uma Function que não existe mais (`analytics-ga`) | Só nas telas "Inteligência"/"Configurações" antigas, que **não estão no menu** | Function apagada quando o GA4 saiu do painel, cliente ficou pra trás | Não afeta nenhuma tela em uso — deixado como está, mesmo padrão de "arquivo órfão mantido" já usado no resto do projeto |
| 8 | **(achado na 2ª rodada)** "Falha ao consultar atividades (400)" no card de Metas, mesmo com a v1 já rodada | Início, card de Metas | `admin_prospeccao_atividades` sem as colunas `status_anterior`/`status_novo`/`objecao` — vinham de `SQL_PENDENTE_estados_rapidos.sql`/`inteligencia.sql`, nunca incorporadas | `SQL_FIX_completo_13_09.sql` §3d |
| 9 | **(achado na 2ª rodada)** Botão de marcar lead como "Interessado" e qualquer atividade dos tipos `mudanca_status`/`briefing_atualizado`/`diagnostico_criado`/`diagnostico_publicado`/`apresentacao_enviada` falhariam com 400 (constraint) | Prospecção (kanban) e Clientes (timeline) | As constraints de `status` (leads) e `tipo` (atividades) nunca tinham sido ampliadas para esses valores, embora o código já os use há tempos | `SQL_FIX_completo_13_09.sql` §3d |
| 10 | **(achado na 2ª rodada)** `instagram`/`responsavel_interno` em leads e `follow_up_notificado_em` (usada pelo job agendado de follow-up) nunca criadas | Clientes; job agendado de follow-up | Mesma causa — migrações pequenas separadas, nunca incorporadas | `SQL_FIX_completo_13_09.sql` §3d |

## O que foi conferido e está **certo** (sem achado)

- Todo `select=coluna,coluna` e todo filtro (`?coluna=eq.`) de toda Function do projeto bate exatamente com uma coluna que existe em algum SQL — **zero divergência** depois da correção acima.
- Todo corpo de `INSERT`/`PATCH` (o que cada Function grava no banco) bate com as colunas reais — incluindo os casos que pareciam suspeitos à primeira vista (`admin_prospeccao_leads` e `consultas_leads`, as duas tabelas maiores do projeto, ambas com dezenas de colunas) e que, na conferência linha a linha, se confirmaram corretos.
- Todo endpoint que o painel chama (`/.netlify/functions/*`) tem a Function correspondente publicada — com a única exceção de `analytics-ga` (item 7 acima, sem efeito prático).
- Nenhuma chamada RPC (`supabase.rpc(...)`) existe no projeto — todo acesso é via REST direto, então não há esse tipo de dependência escondida.
- Suíte de testes: **156/156 passando**. `node --check`: **zero erro de sintaxe** em qualquer arquivo `.js` do projeto.

## O que fazer agora

Continua sendo **um único arquivo**: `SQL_FIX_completo_13_09.sql` (já atualizado com os achados 1 a 10 desta auditoria — nenhum arquivo novo, o mesmo que eu já tinha te mandado, agora mais completo). Cole no SQL Editor do Supabase e rode de novo — é seguro rodar por cima do que você já rodou, nada é duplicado ou apagado. A query de conferência no final do arquivo agora checa tabela, coluna E constraint, e resolve os 10 problemas de uma vez.

Eu não tenho acesso direto ao banco de produção da Felipe Branding — não consigo rodar isso por você. É o único passo manual que continua sendo necessário.

**Nota honesta sobre o que aconteceu entre a v1 e esta v2:** a v1 já estava certa no que ela verificava — as 10 tabelas realmente foram criadas, e a query de conferência não mentiu. O que faltou foi escopo: ela provava que TABELA existe, não que toda COLUNA e CONSTRAINT que o código usa também existe. Essa segunda rodada fechou esse gap conferindo, um por um, todo `select=`/filtro de coluna E todo valor de `status`/`tipo` que o código grava contra o que o banco aceita — não só a existência das tabelas. Não posso garantir que não existe uma 3ª camada ainda mais profunda que eu não pensei em checar, mas o método agora é mais rigoroso do que era na v1.
