const test = require('node:test');
const assert = require('node:assert/strict');
const net = require('node:net');
const tls = require('node:tls');
const fs = require('node:fs');
const path = require('node:path');
const { enviarEmailRaw } = require('../netlify/functions/_lib/integrations/rawSmtp');

const CERT = fs.readFileSync(path.join(__dirname, 'fixtures/cert.pem'));
const KEY = fs.readFileSync(path.join(__dirname, 'fixtures/key.pem'));

/**
 * Sobe um servidor SMTP falso mínimo em localhost — implementa exatamente
 * a conversa que rawSmtp.js espera (EHLO, STARTTLS, EHLO nas TLS, AUTH
 * LOGIN, MAIL FROM, RCPT TO, DATA, QUIT), gravando tudo que recebe pra o
 * teste inspecionar depois. `comportamento` permite cada teste customizar
 * uma resposta específica (ex: simular AUTH LOGIN falhando).
 */
function subirServidorFalso(comportamento = {}) {
  const recebido = { comandos: [], dataBruta: '' };

  return new Promise((resolveServidor) => {
    const server = net.createServer((socketPlano) => {
      let socket = socketPlano;
      let emData = false;
      let bufferData = '';
      let buffer = '';
      let estado = 'inicial'; // inicial -> pos_tls -> aguardando_user -> aguardando_pass -> autenticado

      function enviar(linha) {
        socket.write(linha + '\r\n');
      }

      function tratarLinha(linha) {
        if (emData) {
          if (linha === '.') {
            emData = false;
            recebido.dataBruta = bufferData;
            enviar(comportamento.respostaData || '250 Message accepted');
            return;
          }
          bufferData += (bufferData ? '\r\n' : '') + linha;
          return;
        }

        recebido.comandos.push(linha);
        const upper = linha.toUpperCase();

        if (upper.startsWith('EHLO')) return enviar('250 ok');

        if (upper === 'STARTTLS') {
          enviar('220 go ahead');
          const tlsSocket = new tls.TLSSocket(socket, { isServer: true, cert: CERT, key: KEY });
          socket = tlsSocket;
          buffer = '';
          estado = 'pos_tls';
          ligarListeners();
          return;
        }

        if (upper === 'AUTH LOGIN') { estado = 'aguardando_user'; return enviar(comportamento.respostaAuthLogin || '334 VXNlcm5hbWU6'); }

        if (estado === 'aguardando_user') { estado = 'aguardando_pass'; return enviar(comportamento.respostaUser || '334 UGFzc3dvcmQ6'); }
        if (estado === 'aguardando_pass') { estado = 'autenticado'; return enviar(comportamento.respostaPass || '235 Authentication successful'); }

        if (upper.startsWith('MAIL FROM')) return enviar('250 ok');
        if (upper.startsWith('RCPT TO')) return enviar(comportamento.respostaRcpt || '250 ok');
        if (upper === 'DATA') { emData = true; return enviar('354 Start mail input'); }
        if (upper === 'QUIT') { enviar('221 Bye'); socket.end(); return; }
        enviar('500 comando desconhecido no servidor falso');
      }

      function ligarListeners() {
        socket.on('data', (chunk) => {
          buffer += chunk.toString('utf8');
          let idx;
          while ((idx = buffer.indexOf('\n')) !== -1) {
            let linha = buffer.slice(0, idx);
            buffer = buffer.slice(idx + 1);
            if (linha.endsWith('\r')) linha = linha.slice(0, -1);
            tratarLinha(linha);
          }
        });
      }

      ligarListeners();
      enviar('220 servidor falso pronto');
    });

    server.listen(0, 'localhost', () => resolveServidor({ server, port: server.address().port, recebido }));
  });
}

function fecharServidor(server) {
  return new Promise((resolve) => server.close(resolve));
}

test('enviarEmailRaw: completa a conversa inteira com sucesso (EHLO→STARTTLS→AUTH→MAIL→RCPT→DATA→QUIT)', async () => {
  const { server, port, recebido } = await subirServidorFalso();
  try {
    await enviarEmailRaw({
      host: 'localhost',
      port,
      user: 'contato@felipebranding.com.br',
      pass: 'senha-secreta',
      from: 'contato@felipebranding.com.br',
      fromDisplay: 'Felipe Souto',
      to: 'lead@empresa.com',
      subject: 'Uma ideia para a Empresa X',
      text: 'Corpo do e-mail de teste.',
      tlsOptions: { ca: CERT, rejectUnauthorized: true },
    });

    assert.ok(recebido.comandos.some((c) => c.toUpperCase() === 'STARTTLS'));
    assert.ok(recebido.comandos.some((c) => c.toUpperCase().startsWith('MAIL FROM:<CONTATO@FELIPEBRANDING.COM.BR'.toUpperCase()) || c.startsWith('MAIL FROM:<contato@felipebranding.com.br')));
    assert.ok(recebido.comandos.some((c) => c.startsWith('RCPT TO:<lead@empresa.com>')));
  } finally {
    await fecharServidor(server);
  }
});

test('enviarEmailRaw: usuário/senha vão em base64 corretamente (AUTH LOGIN)', async () => {
  const { server, port, recebido } = await subirServidorFalso();
  try {
    await enviarEmailRaw({
      host: 'localhost', port,
      user: 'usuario@x.com', pass: 'minhaSenha123',
      from: 'usuario@x.com', to: 'lead@empresa.com', subject: 'Oi', text: 'Corpo',
      tlsOptions: { ca: CERT },
    });
    const comandosPosAuth = recebido.comandos.filter((c) => !c.toUpperCase().startsWith('EHLO'));
    const idxAuthLogin = comandosPosAuth.findIndex((c) => c.toUpperCase() === 'AUTH LOGIN');
    const userB64 = comandosPosAuth[idxAuthLogin + 1];
    const passB64 = comandosPosAuth[idxAuthLogin + 2];
    assert.equal(Buffer.from(userB64, 'base64').toString('utf8'), 'usuario@x.com');
    assert.equal(Buffer.from(passB64, 'base64').toString('utf8'), 'minhaSenha123');
  } finally {
    await fecharServidor(server);
  }
});

test('enviarEmailRaw: monta a mensagem com From/To/Subject/corpo corretos', async () => {
  const { server, port, recebido } = await subirServidorFalso();
  try {
    await enviarEmailRaw({
      host: 'localhost', port,
      user: 'contato@felipebranding.com.br', pass: 'x',
      from: 'contato@felipebranding.com.br', fromDisplay: 'Felipe Souto - Felipe Branding',
      to: 'lead@empresa.com', subject: 'Assunto do teste', text: 'Linha 1\nLinha 2',
      tlsOptions: { ca: CERT },
    });
    assert.ok(recebido.dataBruta.includes('From: Felipe Souto - Felipe Branding <contato@felipebranding.com.br>'));
    assert.ok(recebido.dataBruta.includes('To: <lead@empresa.com>'));
    assert.ok(recebido.dataBruta.includes('Subject: Assunto do teste'));
    assert.ok(recebido.dataBruta.includes('Linha 1'));
    assert.ok(recebido.dataBruta.includes('Linha 2'));
    assert.ok(recebido.dataBruta.includes('Content-Type: text/plain'), 'não deveria mandar HTML, só texto simples');
  } finally {
    await fecharServidor(server);
  }
});

test('enviarEmailRaw: linha do corpo que começa com "." recebe byte-stuffing (".." ) — não pode ser confundida com fim da mensagem', async () => {
  const { server, port, recebido } = await subirServidorFalso();
  try {
    await enviarEmailRaw({
      host: 'localhost', port,
      user: 'x', pass: 'x', from: 'x@x.com', to: 'y@y.com',
      subject: 'Teste', text: 'Primeira linha\n.Segunda linha começando com ponto\nTerceira linha',
      tlsOptions: { ca: CERT },
    });
    // O servidor falso já desfaz o "." dobrado na leitura bruta (ele só corta na linha "." sozinha) —
    // então a prova de que funcionou é a mensagem ter chegado INTEIRA, sem cortar no meio.
    assert.ok(recebido.dataBruta.includes('Terceira linha'), 'a mensagem não pode ter sido cortada no meio pela linha que começa com ponto');
  } finally {
    await fecharServidor(server);
  }
});

test('enviarEmailRaw: sanitiza CRLF em campos que vêm de dados do lead (evita injeção de comando SMTP)', async () => {
  const { server, port, recebido } = await subirServidorFalso();
  try {
    await enviarEmailRaw({
      host: 'localhost', port,
      user: 'x', pass: 'x', from: 'x@x.com', to: 'y@y.com',
      subject: 'Assunto normal\r\nRCPT TO:<hacker@evil.com>', text: 'Corpo',
      tlsOptions: { ca: CERT },
    });
    // O texto ainda pode aparecer (dentro da linha do Subject, inofensivo) — o que a
    // sanitização impede é ele virar uma LINHA SEPARADA (ex: um header novo, tipo
    // "Bcc:", ou pior, escapar da mensagem por completo). Isso é o que de fato importa.
    const linhas = recebido.dataBruta.split('\n').map((l) => l.trim());
    assert.ok(!linhas.includes('RCPT TO:<hacker@evil.com>'), 'CRLF no assunto não pode virar uma linha própria dentro da mensagem');
  } finally {
    await fecharServidor(server);
  }
});

test('enviarEmailRaw: AUTH LOGIN rejeitado pelo servidor (senha errada) lança erro claro com o código', async () => {
  const { server, port } = await subirServidorFalso({ respostaPass: '535 Authentication failed' });
  try {
    await assert.rejects(
      () => enviarEmailRaw({
        host: 'localhost', port, user: 'x', pass: 'senha-errada',
        from: 'x@x.com', to: 'y@y.com', subject: 'S', text: 'C',
        tlsOptions: { ca: CERT },
      }),
      /535/
    );
  } finally {
    await fecharServidor(server);
  }
});

test('enviarEmailRaw: servidor recusa o destinatário (RCPT TO) lança erro claro', async () => {
  const { server, port } = await subirServidorFalso({ respostaRcpt: '550 No such user here' });
  try {
    await assert.rejects(
      () => enviarEmailRaw({
        host: 'localhost', port, user: 'x', pass: 'x',
        from: 'x@x.com', to: 'naoexiste@empresa.com', subject: 'S', text: 'C',
        tlsOptions: { ca: CERT },
      }),
      /550/
    );
  } finally {
    await fecharServidor(server);
  }
});

test('enviarEmailRaw: servidor recusa a conexão (nada rodando na porta) rejeita em vez de travar', async () => {
  await assert.rejects(
    () => enviarEmailRaw({ host: 'localhost', port: 1, user: 'x', pass: 'x', from: 'a@a.com', to: 'b@b.com', subject: 'S', text: 'C' }),
    /ECONNREFUSED|EACCES/
  );
});

test('enviarEmailRaw: assunto com acento vai codificado (RFC 2047) e Reply-To opcional entra no cabeçalho', async () => {
  const { server, port, recebido } = await subirServidorFalso();
  try {
    await enviarEmailRaw({
      host: 'localhost', port, user: 'u@x.com', pass: 'x', from: 'u@x.com',
      to: 'contato@felipebranding.com.br', replyTo: 'visitante@loja.com',
      subject: 'Novo contato: João (Produção de Vídeo)', text: 'Corpo', tlsOptions: { ca: CERT },
    });
    const esperado = `=?UTF-8?B?${Buffer.from('Novo contato: João (Produção de Vídeo)', 'utf8').toString('base64')}?=`;
    assert.ok(recebido.dataBruta.includes(`Subject: ${esperado}`));
    assert.ok(recebido.dataBruta.includes('Reply-To: <visitante@loja.com>'));
  } finally {
    await fecharServidor(server);
  }
});
