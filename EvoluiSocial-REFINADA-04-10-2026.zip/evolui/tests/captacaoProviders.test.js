const test = require('node:test');
const assert = require('node:assert/strict');
const fixture = require('./fixtures/geoapify_construcao_petrolina.json');
const { validarRegistro, CAMPOS } = require('../netlify/functions/_lib/captacao/tipos');
const geoapify = require('../netlify/functions/_lib/captacao/providers/geoapify');
const overpass = require('../netlify/functions/_lib/captacao/providers/overpass');
const csv = require('../netlify/functions/_lib/captacao/providers/csv');
const inbound = require('../netlify/functions/_lib/captacao/providers/inbound');
const manual = require('../netlify/functions/_lib/captacao/providers/manual');
const taxonomia = require('../netlify/functions/_lib/captacao/taxonomia');

const PETROLINA = { lat: -9.3891, lon: -40.503 };
const buscarFake = async (categorias) => fixture.por_categoria[categorias.join(',')] || [];

test('REGRESSÃO Construção/Petrolina: estratégia antiga (filtro por nome) dá 0; nova (categoria do setor) dá > 0', async () => {
  // ANTES: integrations/geoapify.js — categorias amplas + "nome contém o ramo"
  const antigo = require('../netlify/functions/_lib/integrations/geoapify');
  const fetchOriginal = global.fetch;
  global.fetch = async (url) => {
    const cats = decodeURIComponent(String(url).match(/categories=([^&]+)/)[1]);
    return { ok: true, status: 200, json: async () => ({ type: 'FeatureCollection', features: fixture.por_categoria[cats] || [] }) };
  };
  let antes;
  try {
    antes = await antigo.buscarEmpresasGeoapify('Construção', PETROLINA.lat, PETROLINA.lon, 'chave-teste');
  } finally {
    global.fetch = fetchOriginal;
  }
  assert.equal(antes.length, 0, 'a estratégia antiga filtra pelo nome e perde todas');

  // DEPOIS: provider novo — categoria específica do setor, sem depender do nome
  const { registros } = await geoapify.coletar({ setor: 'Construção', ...PETROLINA, raioKm: 15 }, { apiKey: 'x', buscar: buscarFake });
  assert.ok(registros.length > 0, 'a estratégia nova encontra empresas do setor');
  const nomes = registros.map((r) => r.empresa);
  assert.ok(nomes.includes('Ferragens Sertão'), 'entra pela categoria mesmo sem "constru" no nome');
  assert.ok(nomes.includes('Alfa Construções e Incorporações'), 'categoria genérica entra quando o nome tem termo do setor');
  assert.ok(!nomes.includes('Escritório Contábil Beta'), 'categoria genérica sem termo do setor fica de fora');
  assert.ok(!registros.some((r) => r.external_id === 'geoapify:p-sem-nome'), 'sem nome não vira registro');
});

test('contrato: todos os providers devolvem exatamente o formato intermediário', async () => {
  const { registros: g } = await geoapify.coletar({ setor: 'Construção', ...PETROLINA, raioKm: 15 }, { apiKey: 'x', buscar: buscarFake });
  const { registros: o } = await overpass.coletar({ setor: 'Arquitetura', ...PETROLINA, raioKm: 15 }, {
    consultar: async () => [{ type: 'node', id: 7, lat: -9.39, lon: -40.5, tags: { name: 'Estúdio Linha', office: 'architect', phone: '87 3861-2222', website: 'estudiolinha.example.com', 'addr:city': 'Petrolina', 'contact:instagram': 'https://instagram.com/estudiolinha' } }],
  });
  const leitura = csv.ler(Buffer.from('Empresa;Telefone\nAlfa;87 3862-0000\n').toString('base64'));
  const c = csv.paraRegistro(leitura.linhas[0], leitura.mapeamentoSugerido, leitura.hash, 2).registro;
  const cons = inbound.consultoria.paraRegistro({ id: 'a1', nome: 'Maria', instagram: 'loja.maria', whatsapp: '87999990000', segmento: 'moda_vestuario' });
  const site = inbound.siteContato.paraRegistro({ id: 'b2', nome: 'João', email: 'j@x.com', whatsapp: '87988887777', servico: 'Branding' });
  const man = manual.paraRegistro({ empresa: 'Beta', telefone: '87 3862-1111' });
  for (const r of [g[0], o[0], c, cons, site, man]) {
    assert.deepEqual(validarRegistro(r), [], JSON.stringify(r));
    assert.deepEqual(Object.keys(r).sort(), [...CAMPOS].sort());
  }
  assert.equal(o[0].external_id, 'osm:node/7');
  assert.equal(o[0].categoria_origem, 'office=architect');
  assert.equal(cons.empresa, '@loja.maria');
  assert.equal(site.empresa, 'João (a identificar)');
});

test('overpass: consulta usa TAGS do setor e só usa nome como reforço', () => {
  const q = overpass.montarConsulta(taxonomia.porId('Construção'), -9.39, -40.5, 15000, ['constru']);
  assert.match(q, /nwr\["shop"="hardware"\]\["name"\]/);
  assert.match(q, /nwr\["craft"="builder"\]/);
  assert.match(q, /\["office"="company"\]\["name"~"constru/);
  assert.equal(overpass.montarConsulta(taxonomia.porId('Outro'), 0, 0, 1000, []), null);
});

test('geoapify: 429 → 1 nova tentativa com espera; erro de rede vira mensagem sem vazar a chave', async () => {
  let chamadas = 0;
  const fetchOriginal = global.fetch;
  const setTimeoutOriginal = global.setTimeout;
  global.setTimeout = (fn) => { fn(); return 0; };
  global.fetch = async (url) => {
    chamadas += 1;
    assert.ok(!String(url).includes('undefined'));
    if (chamadas === 1) return { ok: false, status: 429, headers: { get: () => '1' } };
    return { ok: true, status: 200, json: async () => ({ features: [] }) };
  };
  try {
    const r = await geoapify.buscarCategorias(['office.architect'], -9, -40, 1000, 10, 'segredo');
    assert.deepEqual(r, []);
    assert.equal(chamadas, 2);
    global.fetch = async () => { throw Object.assign(new Error('x'), { name: 'AbortError' }); };
    await assert.rejects(() => geoapify.buscarCategorias(['office'], -9, -40, 1000, 10, 'segredo'), (e) => !e.message.includes('segredo') && /timeout/.test(e.message));
  } finally {
    global.fetch = fetchOriginal;
    global.setTimeout = setTimeoutOriginal;
  }
});

test('CSV: BOM + ";" + UTF-8', () => {
  const r = csv.ler(Buffer.from('﻿Razão Social;Celular;Município\n"Construtora; Alfa";(87) 99999-0000;Petrolina\n').toString('base64'));
  assert.equal(r.delimitador, ';');
  assert.equal(r.codificacao, 'utf-8');
  assert.equal(r.cabecalhos[0], 'Razão Social');
  assert.deepEqual(r.mapeamentoSugerido, { empresa: 0, telefone: 1, cidade: 2 });
  assert.equal(r.linhas[0][0], 'Construtora; Alfa');
});

test('CSV: vírgula, TAB, aspas escapadas e quebra de linha dentro do campo', () => {
  const v = csv.ler(Buffer.from('nome,fone,obs\n"Beta ""Oficial""",8738620000,"linha 1\nlinha 2"\n').toString('base64'));
  assert.equal(v.delimitador, ',');
  assert.equal(v.linhas[0][0], 'Beta "Oficial"');
  assert.equal(v.linhas[0][2], 'linha 1\nlinha 2');
  const t = csv.ler(Buffer.from('empresa\ttelefone\nGama\t87 3862\n').toString('base64'));
  assert.equal(t.delimitador, '\t');
  assert.equal(t.linhas[0][0], 'Gama');
});

test('CSV: arquivo do Excel em Windows-1252 é lido com acentos e avisa', () => {
  const bytes = Buffer.from([0x45, 0x6d, 0x70, 0x72, 0x65, 0x73, 0x61, 0x0a, 0x43, 0x6f, 0x6e, 0x73, 0x74, 0x72, 0x75, 0xe7, 0xe3, 0x6f, 0x0a]); // "Empresa\nConstrução\n" em cp1252
  const r = csv.ler(bytes.toString('base64'));
  assert.equal(r.codificacao, 'windows-1252');
  assert.equal(r.linhas[0][0], 'Construção');
  assert.ok(r.avisos.length);
});

test('CSV: recusa .xlsx com orientação e arquivo vazio', () => {
  assert.throws(() => csv.ler(Buffer.from([0x50, 0x4b, 0x03, 0x04, 1, 2]).toString('base64')), /Salvar como/);
  assert.throws(() => csv.ler(''), /vazio/);
  assert.throws(() => csv.ler(Buffer.from('só cabeçalho\n').toString('base64')), /ao menos uma linha/);
});
