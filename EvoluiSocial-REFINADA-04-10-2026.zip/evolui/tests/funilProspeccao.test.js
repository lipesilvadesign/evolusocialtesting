const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

async function carregarComponente() {
  const url = 'file://' + path.resolve(__dirname, '../painel/assets/js/components/FunilProspeccao.js');
  return import(url);
}

const STATUS_MAP = {
  novo_lead: { label: 'Novo lead', cls: 'badge-demo' },
  contatado: { label: 'Contatado', cls: 'badge-info' },
  respondeu: { label: 'Respondeu', cls: 'badge-warning' },
  interessado: { label: 'Interessado', cls: 'badge-warning' },
  reuniao_marcada: { label: 'Reunião/orçamento', cls: 'badge-warning' },
  proposta_enviada: { label: 'Proposta enviada', cls: 'badge-warning' },
  cliente: { label: 'Convertido', cls: 'badge-ok' },
  nao_convertido: { label: 'Perdido', cls: 'badge-danger' },
};
const STATUS_ORDER = Object.keys(STATUS_MAP);

test('funilProspeccaoHtml: sem nenhum lead, mostra mensagem de vazio (nunca 0% ou funil quebrado)', async () => {
  const { funilProspeccaoHtml } = await carregarComponente();
  const contagem = {};
  STATUS_ORDER.forEach((s) => { contagem[s] = 0; });
  const html = funilProspeccaoHtml(contagem, STATUS_ORDER, STATUS_MAP);
  assert.match(html, /Nenhum lead cadastrado ainda/);
});

test('funilProspeccaoHtml: "nao_convertido" (Perdidos) fica FORA do afunilamento principal', async () => {
  const { funilProspeccaoHtml } = await carregarComponente();
  const contagem = { novo_lead: 10, contatado: 6, respondeu: 3, interessado: 2, reuniao_marcada: 1, proposta_enviada: 1, cliente: 1, nao_convertido: 4 };
  const html = funilProspeccaoHtml(contagem, STATUS_ORDER, STATUS_MAP);
  // "Perdidos" aparece na seção separada (funil2-perdidos), não como uma
  // linha "funil2-estagio" no meio do afunilamento.
  assert.match(html, /funil2-perdidos/);
  const estagioMatches = html.match(/funil2-estagio/g) || [];
  assert.equal(estagioMatches.length, 7); // todos os status exceto nao_convertido
  assert.doesNotMatch(html.split('funil2-perdidos')[0], /Perdido</);
});

test('funilProspeccaoHtml: mostra a % do total de leads em cada estágio', async () => {
  const { funilProspeccaoHtml } = await carregarComponente();
  // total geral (incluindo perdidos) = 20; novo_lead = 10 → 50% do total.
  const contagem = { novo_lead: 10, contatado: 4, respondeu: 2, interessado: 1, reuniao_marcada: 1, proposta_enviada: 1, cliente: 1, nao_convertido: 0 };
  const html = funilProspeccaoHtml(contagem, STATUS_ORDER, STATUS_MAP);
  assert.match(html, /\(50%\)/);
});

test('funilProspeccaoHtml: anota a queda (%) só quando o estágio seguinte tem MENOS leads que o anterior', async () => {
  const { funilProspeccaoHtml } = await carregarComponente();
  // novo_lead=10 → contatado=5 (queda de 50%) → todos os demais também 5 (sem novas quedas)
  const contagem = { novo_lead: 10, contatado: 5, respondeu: 5, interessado: 5, reuniao_marcada: 5, proposta_enviada: 5, cliente: 5, nao_convertido: 0 };
  const html = funilProspeccaoHtml(contagem, STATUS_ORDER, STATUS_MAP);
  const quedas = html.match(/funil2-queda">↓ (\d+)%/g) || [];
  assert.equal(quedas.length, 1);
  assert.match(html, /↓ 50% não avançou/);
});

test('funilProspeccaoHtml: cada estágio usa a cor do MESMO cls já usado no badge de status (nenhuma cor nova)', async () => {
  const { funilProspeccaoHtml } = await carregarComponente();
  const contagem = { novo_lead: 3, contatado: 2, respondeu: 1, interessado: 0, reuniao_marcada: 0, proposta_enviada: 0, cliente: 1, nao_convertido: 0 };
  const html = funilProspeccaoHtml(contagem, STATUS_ORDER, STATUS_MAP);
  assert.match(html, /--cor:var\(--text-muted\)/); // novo_lead → badge-demo
  assert.match(html, /--cor:var\(--info\)/); // contatado → badge-info
  assert.match(html, /--cor:var\(--ok\)/); // cliente → badge-ok
});
