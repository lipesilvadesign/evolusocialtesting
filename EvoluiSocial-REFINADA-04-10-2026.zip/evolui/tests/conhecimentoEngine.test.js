const assert = require('assert');
(async () => {
  const M = await import('../supabase/functions/evolui-api/eie/conhecimento.ts');
  assert.equal(M.deveAdquirirConhecimento('Quero uma ideia de vídeo para uma corretora', { assunto:'corretora', confianca:'alta', intencoes:[{id:'ideias'}]}), true);
  const k = M.estruturarConhecimento('corretora', [
    {titulo:'Corretora de seguros: serviços e mercado', snippet:'Empresa especializada em intermediar seguros', url:'https://example.com/a'},
    {titulo:'Corretora de imóveis', snippet:'Profissional e empresa do mercado imobiliário', url:'https://example.com/b'}
  ]);
  assert.equal(k.entidade, 'corretora');
  assert.ok(k.termosRelacionados.length > 0);
  assert.equal(k.necessitaDesambiguacao, true);
  assert.ok(k.confianca > 0.5);
  console.log('conhecimentoEngine.test.js: 1/1 OK');
})();
