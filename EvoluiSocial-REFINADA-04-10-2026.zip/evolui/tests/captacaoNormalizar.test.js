const test = require('node:test');
const assert = require('node:assert/strict');
const n = require('../netlify/functions/_lib/captacao/normalizar');

test('telefone: formatos brasileiros viram 55+DDD+número', () => {
  assert.equal(n.telefone('(87) 99999-9999'), '5587999999999');
  assert.equal(n.telefone('+55 (87) 3862-0000'), '558738620000');
  assert.equal(n.telefone('87 3862-0000'), '558738620000');
  assert.equal(n.telefone('3862-0000'), '558738620000'); // DDD padrão 87
  assert.equal(n.telefone('98888-7777', '74'), '5574988887777');
  assert.equal(n.telefone('0xx87 99999-8888'), '5587999998888');
  assert.equal(n.telefone('0 21 87 99999-8888'), '5587999998888'); // prefixo de operadora
  assert.equal(n.telefone('5587999999999'), '5587999999999');
});

test('telefone: entrada inválida vira null, nunca "corrigida"', () => {
  assert.equal(n.telefone(''), null);
  assert.equal(n.telefone('123'), null);
  assert.equal(n.telefone('(87) 89999-9999'), null); // 9 dígitos sem começar com 9
  assert.equal(n.telefone('0000-0000'), null);
  assert.equal(n.telefone('3862-0000', null), null); // sem DDD e sem padrão
});

test('instagram: URL, @ e parâmetros viram só o usuário', () => {
  assert.equal(n.instagram('https://instagram.com/empresa/'), 'empresa');
  assert.equal(n.instagram('@Empresa'), 'empresa');
  assert.equal(n.instagram('instagram.com/empresa'), 'empresa');
  assert.equal(n.instagram('https://www.instagram.com/empresa.pe/?igsh=abc123'), 'empresa.pe');
  assert.equal(n.instagram('empresa_oficial'), 'empresa_oficial');
  assert.equal(n.instagram('https://instagram.com/p/Cxyz/'), null);
  assert.equal(n.instagram('https://facebook.com/empresa'), null);
  assert.equal(n.instagram('nome com espaço'), null);
});

test('domínio: tira protocolo, www e caminho; ignora genéricos', () => {
  assert.equal(n.dominio('https://www.empresa.com.br/pagina'), 'empresa.com.br');
  assert.equal(n.dominio('HTTP://Empresa.com.br:8080/x?y=1'), 'empresa.com.br');
  assert.equal(n.dominio('empresa.com.br'), 'empresa.com.br');
  assert.equal(n.dominio('contato@empresa.com.br'), 'empresa.com.br');
  for (const g of ['https://instagram.com/x', 'facebook.com/x', 'https://wa.me/5587', 'linktr.ee/x', 'google.com', 'fulano@gmail.com', 'loja.wixsite.com/site', 'x.blogspot.com']) {
    assert.equal(n.dominio(g), null, g);
  }
});

test('CNPJ: valida dígitos verificadores (14 dígitos não bastam)', () => {
  assert.equal(n.cnpj('11.222.333/0001-81'), '11222333000181');
  assert.equal(n.cnpj('11222333000181'), '11222333000181');
  assert.equal(n.cnpj('11.222.333/0001-82'), null);
  assert.equal(n.cnpj('11111111111111'), null);
  assert.equal(n.cnpj('123'), null);
});

test('cidade: grafias diferentes viram um único formato', () => {
  for (const v of ['Petrolina', 'petrolina', 'PETROLINA', 'Petrolina - PE', 'Petrolina/PE', 'Petrolina, PE']) {
    assert.deepEqual(n.cidade(v), { cidade: 'Petrolina', uf: 'PE', cidadeNorm: 'petrolina' }, v);
  }
  assert.deepEqual(n.cidade('SANTA MARIA DA BOA VISTA'), { cidade: 'Santa Maria da Boa Vista', uf: 'PE', cidadeNorm: 'santa maria da boa vista' });
  assert.equal(n.cidade('Juazeiro, BA').uf, 'BA');
  assert.equal(n.cidade('Remanso').uf, null); // fora da lista: não inventa UF
});

test('empresa: exibição preserva a marca; norm tira sufixo societário e acento', () => {
  assert.deepEqual(n.empresa('  CONSTRUTORA  ALFA LTDA - ME '), { exibicao: 'CONSTRUTORA ALFA LTDA - ME', norm: 'construtora alfa' });
  assert.equal(n.empresa('Café São João EIRELI').norm, 'cafe sao joao');
  assert.equal(n.empresa('Alfa S/A').norm, 'alfa');
  assert.equal(n.empresa('').exibicao, null);
});

test('setor: sinônimos e grafias antigas caem na taxonomia', () => {
  assert.deepEqual(n.setor('Construção Civil/Engenharia'), { setor: 'Construção', subsetor: 'Civil/Engenharia' });
  assert.equal(n.setor('Coworking (nicho saúde)').setor, 'Coworking');
  assert.equal(n.setor('clínica odontológica').setor, 'Saúde');
  assert.deepEqual(n.setor('coisa sem mapa'), { setor: null, subsetor: 'coisa sem mapa' });
});

test('similaridade: mesma empresa com grafia diferente fica alta; diferentes, baixa', () => {
  assert.ok(n.similaridade('construtora alfa', 'construtora alfa ltda') > 0.7);
  assert.ok(n.similaridade('construtora alfa', 'padaria beta') < 0.2);
  assert.equal(n.similaridade('', 'x'), 0);
  assert.ok(n.distanciaMetros(-9.39, -40.5, -9.3905, -40.5) < 100);
});

test('registro: normaliza o registro intermediário inteiro e gera avisos, sem inventar', () => {
  const r = n.registro({ empresa: 'Alfa Ltda', telefone: '(87) 3862-0000', site: 'www.alfa.com.br/contato', instagram: '@alfa', cnpj: '123', cidade: 'PETROLINA', setor_sugerido: 'construtora' });
  assert.equal(r.empresa_norm, 'alfa');
  assert.equal(r.telefone_norm, '558738620000');
  assert.equal(r.dominio, 'alfa.com.br');
  assert.equal(r.instagram_handle, 'alfa');
  assert.equal(r.cnpj, null);
  assert.ok(r.avisos.some((a) => a.includes('CNPJ')));
  assert.equal(r.cidade, 'Petrolina');
  assert.equal(r.uf, 'PE');
  assert.equal(r.setor, 'Construção');
  const juazeiro = n.registro({ empresa: 'X', telefone: '98888-7777', cidade: 'Juazeiro' });
  assert.equal(juazeiro.telefone_norm, '5574988887777'); // DDD da cidade, não o padrão
});
