const test = require('node:test');
const assert = require('node:assert/strict');
const { calcularScore, faixaScore, PONTOS } = require('../netlify/functions/_lib/scoreEngine');

test('calcularScore: lead vazio (novo, com site, sem nenhum sinal) tem score 0', () => {
  const { score, motivos } = calcularScore({ site: 'https://x.com', status: 'novo_lead' });
  assert.equal(score, 0);
  assert.deepEqual(motivos, []);
});

test('calcularScore: sem site soma 30 e explica o motivo', () => {
  const { score, motivos } = calcularScore({ site: null, status: 'novo_lead' });
  assert.equal(score, 30);
  assert.equal(motivos.length, 1);
  assert.equal(motivos[0].pontos, 30);
});

test('calcularScore: soma todos os sinais manuais marcados', () => {
  const { score } = calcularScore({
    site: null, // +30
    sinalSiteDesatualizado: true, // não deveria contar junto com "sem site" na prática, mas a função soma o que for marcado
    sinalInstagramDesorganizado: true, // +15
    sinalGbpFraco: true, // +15
    sinalPorteMedioGrande: true, // +15
    sinalSegmentoAltoPotencial: true, // +15
    sinalEmailValidado: true, // +10
    status: 'novo_lead',
  });
  // 30 (sem site) + 20 (site desatualizado) + 15+15+15+15 (sinais) + 10 (email) = 120
  assert.equal(score, 30 + 20 + 15 + 15 + 15 + 15 + 10);
});

test('calcularScore: contato decisor identificado soma 20', () => {
  const { score, motivos } = calcularScore({ site: 'https://x.com', temContatoDecisor: true, status: 'novo_lead' });
  assert.equal(score, 20);
  assert.ok(motivos.some((m) => m.label.includes('decisor')));
});

test('calcularScore: estágio "respondeu" soma 40', () => {
  const { score } = calcularScore({ site: 'https://x.com', status: 'respondeu' });
  assert.equal(score, 40);
});

test('calcularScore: estágio "reuniao_marcada" soma 70 (pediu proposta/reunião), NÃO soma os 40 de "respondeu" também', () => {
  const { score, motivos } = calcularScore({ site: 'https://x.com', status: 'reuniao_marcada' });
  assert.equal(score, 70, 'não pode somar 40+70=110 — são o MESMO sinal em estágios diferentes, não dois sinais');
  assert.equal(motivos.length, 1);
});

test('calcularScore: estágio "proposta_enviada" e "cliente" também contam como "pediu proposta/reunião"', () => {
  assert.equal(calcularScore({ site: 'x', status: 'proposta_enviada' }).score, 70);
  assert.equal(calcularScore({ site: 'x', status: 'cliente' }).score, 70);
});

test('calcularScore: estágio "contatado" ou "nao_convertido" não somam nada de estágio', () => {
  assert.equal(calcularScore({ site: 'x', status: 'contatado' }).score, 0);
  assert.equal(calcularScore({ site: 'x', status: 'nao_convertido' }).score, 0);
});

test('calcularScore: lead sem "status" nenhum não quebra (trata como novo_lead)', () => {
  assert.doesNotThrow(() => calcularScore({ site: 'x' }));
  assert.equal(calcularScore({ site: 'x' }).score, 0);
});

test('calcularScore: cenário completo da análise recebida (score 78 esperado)', () => {
  // "Não possui site: +30, Instagram ativo: +15, Empresa localizada no ICP
  // (segmento alto potencial): +15, Decisor identificado: +20" = 80 no
  // exemplo da análise (o "-2 de e-mail não validado" não é implementado
  // aqui — não penalizamos ausência, só somamos presença de sinais positivos).
  const { score } = calcularScore({
    site: null,
    sinalInstagramDesorganizado: true,
    sinalSegmentoAltoPotencial: true,
    temContatoDecisor: true,
    status: 'novo_lead',
  });
  assert.equal(score, 30 + 15 + 15 + 20);
});

test('faixaScore: classifica corretamente cada faixa', () => {
  assert.equal(faixaScore(0).chave, 'aguardar');
  assert.equal(faixaScore(30).chave, 'aguardar');
  assert.equal(faixaScore(31).chave, 'nutrir');
  assert.equal(faixaScore(60).chave, 'nutrir');
  assert.equal(faixaScore(61).chave, 'prospectar');
  assert.equal(faixaScore(90).chave, 'prospectar');
  assert.equal(faixaScore(91).chave, 'prioritario');
  assert.equal(faixaScore(200).chave, 'prioritario');
});

test('PONTOS: valores batem com a tabela da análise recebida', () => {
  assert.equal(PONTOS.semSite, 30);
  assert.equal(PONTOS.siteDesatualizado, 20);
  assert.equal(PONTOS.instagramDesorganizado, 15);
  assert.equal(PONTOS.gbpFraco, 15);
  assert.equal(PONTOS.porteMedioGrande, 15);
  assert.equal(PONTOS.segmentoAltoPotencial, 15);
  assert.equal(PONTOS.decisorIdentificado, 20);
  assert.equal(PONTOS.emailValidado, 10);
  assert.equal(PONTOS.respondeu, 40);
  assert.equal(PONTOS.pediuPropostaOuReuniao, 70);
});

test('espelho do navegador (painel/assets/js/services/scoreEngine.js) calcula EXATAMENTE igual ao do backend — as duas cópias não podem sair de sincronia', async () => {
  const path = require('node:path');
  const frontUrl = 'file://' + path.resolve(__dirname, '../painel/assets/js/services/scoreEngine.js');
  const front = await import(frontUrl);

  const cenarios = [
    { site: 'https://x.com', status: 'novo_lead' },
    { site: null, status: 'novo_lead' },
    { site: null, sinalInstagramDesorganizado: true, sinalSegmentoAltoPotencial: true, temContatoDecisor: true, status: 'novo_lead' },
    { site: 'x', status: 'respondeu' },
    { site: 'x', status: 'reuniao_marcada' },
    { site: 'x', status: 'proposta_enviada' },
    { site: null, sinalSiteDesatualizado: true, sinalGbpFraco: true, sinalEmailValidado: true, status: 'cliente' },
  ];

  cenarios.forEach((cenario, i) => {
    const back = calcularScore(cenario);
    const fro = front.calcularScore(cenario);
    assert.equal(fro.score, back.score, `cenário ${i}: score divergente entre backend (${back.score}) e frontend (${fro.score})`);
    assert.deepEqual(fro.motivos, back.motivos, `cenário ${i}: motivos divergentes`);
  });

  [0, 30, 31, 60, 61, 90, 91, 200].forEach((s) => {
    assert.deepEqual(front.faixaScore(s), faixaScore(s), `faixaScore(${s}) divergente entre backend e frontend`);
  });
});
