/**
 * Motor novo do PDF da apresentação (assets/js/apresentacao-pdf.js), com a
 * mesma pdf-lib hospedada em /assets/vendor (conferida por hash).
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const VENDOR = path.join(__dirname, '..', 'assets', 'vendor', 'pdf-lib-1.17.1.min.0f9a5cad.js');
// Carrega o MESMO arquivo que o navegador recebe (UMD → global PDFLib)
function carregarPdfLib() {
  const codigo = fs.readFileSync(VENDOR, 'utf8');
  const mod = { exports: {} };
  new Function('module', 'exports', codigo)(mod, mod.exports); // eslint-disable-line no-new-func
  return mod.exports;
}
const PDFLib = carregarPdfLib();
const motor = require('../assets/js/apresentacao-pdf.js');
const exemplo = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'apresentacao_exemplo.json'), 'utf8'));

const sha = (b) => crypto.createHash('sha256').update(Buffer.from(b)).digest('hex');

test('PDF: gera, tem capa + miolo, nome de arquivo sem perder letras acentuadas', async () => {
  const etapas = [];
  const r = await motor.gerar({ PDFLib, ...exemplo, onEtapa: (e) => etapas.push(e) });
  assert.ok(r.bytes.length > 5000);
  assert.equal(Buffer.from(r.bytes.slice(0, 5)).toString(), '%PDF-');
  assert.ok(r.paginas >= 2 && r.paginas <= 6, `${r.paginas} páginas`);
  assert.equal(r.nomeArquivo, 'diagnostico-construtora-exemplo-sao-francisco-ltda.pdf');
  assert.deepEqual(etapas, ['gerando', 'finalizando']);
  // cópia para inspeção visual fora da pasta publicada do site
  fs.writeFileSync(path.join(require('os').tmpdir(), 'apresentacao-exemplo.pdf'), r.bytes);
});

test('PDF: determinístico — mesmas entradas, mesmos bytes', async () => {
  const a = await motor.gerar({ PDFLib, ...exemplo });
  const b = await motor.gerar({ PDFLib, ...exemplo });
  assert.equal(sha(a.bytes), sha(b.bytes));
});

test('PDF: conteúdo vazio/nulo não quebra (null-safe) e caracteres fora da fonte não derrubam a geração', async () => {
  const r1 = await motor.gerar({ PDFLib, conteudo: null, tema: null });
  assert.equal(r1.paginas, 2);
  const r2 = await motor.gerar({ PDFLib, conteudo: { capa: { subtitulo: '🚀 Empresa → Nova ✓' }, oportunidades: '日本語 e emoji 😀' }, tema: { primaryColor: 'javascript:1' } });
  assert.ok(r2.bytes.length > 1000);
});

test('PDF: texto longo pagina sem título órfão e sem página quase vazia', async () => {
  const PDF = PDFLib;
  const longo = Array.from({ length: 12 }, (_, i) => `Parágrafo ${i + 1}. ` + 'Texto de teste para paginação do diagnóstico. '.repeat(14)).join(' ');
  const conteudo = { ...exemplo.conteudo, sobreEmpresa: { ...exemplo.conteudo.sobreEmpresa, contexto: longo, diferenciais: longo } };
  const r = await motor.gerar({ PDFLib: PDF, conteudo, tema: exemplo.tema, publicadoEm: exemplo.publicadoEm });
  assert.ok(r.paginas >= 4);
  const doc = await PDF.PDFDocument.load(r.bytes);
  assert.equal(doc.getPageCount(), r.paginas);
});

test('quebra de linha respeita a largura e parte palavra gigante', async () => {
  const doc = await PDFLib.PDFDocument.create();
  const f = await doc.embedFont(PDFLib.StandardFonts.Helvetica);
  const linhas = motor._internos.quebrar('https://' + 'x'.repeat(300) + ' fim', f, 10.5, 200);
  assert.ok(linhas.length > 3);
  for (const l of linhas) assert.ok(f.widthOfTextAtSize(l, 10.5) <= 200);
});

test('vendor: pdf-lib hospedado é o arquivo 1.17.1 conferido (hash)', () => {
  assert.equal(sha(fs.readFileSync(VENDOR)), '0f9a5cad07941f0826586c94e089d89b918c46e5c17cf2d5a3c6f666e3bc694f');
});

// ---------- 01/10: modelo editorial único (web = PDF), volumes, imagem ----------
const Modelo = require('../assets/js/apresentacao-modelo.js');

function conteudoComTamanho(n) {
  const p = (i) => `Bloco ${i}. ` + 'Análise do posicionamento da marca frente aos concorrentes da região, com foco em percepção, clareza da oferta e consistência visual. '.repeat(4);
  return {
    ...exemplo.conteudo,
    sobreEmpresa: { incluir: true, contexto: Array.from({ length: n }, (_, i) => p(i)).join(' '), segmento: 'Construção civil', produtos: '', diferenciais: '' },
    interpretacao: Array.from({ length: n }, (_, i) => ({ dado: `Dado ${i}: ${p(i)}`, significado: p(i), impacto: `Impacto ${i}.` })),
    oportunidades: Array.from({ length: n * 2 }, (_, i) => `Oportunidade ${i + 1}: ${p(i).slice(0, 180)}`).join('\n'),
  };
}

test('web = PDF: todo texto de conteúdo do modelo aparece no HTML e no PDF', async () => {
  const modelo = Modelo.montarModelo(exemplo.conteudo);
  const esperados = Modelo.textosDoModelo(modelo);
  assert.ok(esperados.length > 20);
  const html = Modelo.renderizarWeb(modelo);
  const texto = html.replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  for (const t of esperados) assert.ok(texto.includes(t), `web sem: ${t.slice(0, 60)}`);
  const r = await motor.gerar({ PDFLib, modelo, tema: exemplo.tema, publicadoEm: exemplo.publicadoEm });
  for (const t of esperados) assert.ok(r.textos.includes(t), `PDF sem: ${t.slice(0, 60)}`);
});

test('modelo: dado ≠ análise — cada seção declara a natureza; nenhum número inventado', () => {
  const m = Modelo.montarModelo(exemplo.conteudo);
  const nat = Object.fromEntries(m.secoes.map((s) => [s.id, s.natureza]));
  assert.deepEqual(nat, { sobre: 'contexto', presenca: 'dado', metricas: 'dado', interpretacao: 'interpretacao', oportunidades: 'recomendacao', estrategia: 'recomendacao', visual: 'recomendacao', passos: 'plano' });
  const met = m.secoes.find((s) => s.id === 'metricas').itens;
  assert.deepEqual(met.map((x) => x.valor), [1840, 620, null]);
  assert.equal(met[2].valorTexto, '4,6 ★', 'valor textual exatamente como publicado');
});

test('modelo: campos nulos / tipos errados não quebram (null-safe)', () => {
  const m = Modelo.montarModelo({ capa: null, sobreEmpresa: 'x', metricasIds: 'a', metricasDisponiveis: {}, interpretacao: [null, 3], oportunidades: 42, direcaoVisual: { incluir: true, cores: null } });
  assert.equal(m.secoes.length, 1, 'só "oportunidades" (o número 42 vira texto)');
  assert.ok(Modelo.renderizarWeb(m).includes('ap-capa'));
});

test('modelo: HTML escapa conteúdo (XSS)', () => {
  const html = Modelo.renderizarWeb(Modelo.montarModelo({ capa: { subtitulo: '<img src=x onerror=alert(1)>' }, oportunidades: '<script>alert(1)</script>' }));
  assert.ok(!/<img src=x|<script>/i.test(html));
});

for (const [rotulo, n, min, max] of [['1 página', 0, 2, 2], ['~5 páginas', 4, 4, 7], ['~10 páginas', 9, 8, 14], ['20+ páginas', 24, 20, 45]]) {
  test(`PDF volume: ${rotulo}`, async () => {
    const conteudo = n === 0 ? { capa: exemplo.conteudo.capa, oportunidades: 'Uma oportunidade curta.' } : conteudoComTamanho(n);
    const r = await motor.gerar({ PDFLib, conteudo, tema: exemplo.tema, publicadoEm: exemplo.publicadoEm });
    assert.ok(r.paginas >= min && r.paginas <= max, `${r.paginas} páginas (esperado ${min}–${max})`);
    const doc = await PDFLib.PDFDocument.load(r.bytes);
    assert.equal(doc.getPageCount(), r.paginas);
    for (const t of Modelo.textosDoModelo(Modelo.montarModelo(conteudo))) assert.ok(r.textos.includes(t));
  });
}

test('PDF: logo PNG do cliente é embutido; SVG/URL externa não faz a geração falhar', async () => {
  const png1x1 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  const com = await motor.gerar({ PDFLib, ...exemplo, tema: { ...exemplo.tema, logo: png1x1 } });
  const sem = await motor.gerar({ PDFLib, ...exemplo });
  assert.ok(com.bytes.length > sem.bytes.length, 'PDF com logo tem a imagem');
  const svg = await motor.gerar({ PDFLib, ...exemplo, tema: { ...exemplo.tema, logo: 'data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=' } });
  assert.equal(svg.paginas, sem.paginas);
});

test('PDF: tipografia própria (Times-Bold nos títulos, Helvetica no texto)', async () => {
  const r = await motor.gerar({ PDFLib, ...exemplo });
  const s = Buffer.from(r.bytes).toString('latin1');
  assert.match(s, /Times-Bold/);
  assert.match(s, /Helvetica/);
});

// ---------- Fase 3: plano estruturado, hero, símbolos, logo, paginação por linhas ----------
const { execFileSync } = require('child_process');
function textoDoPdf(bytes) {
  try {
    const arq = path.join(require('os').tmpdir(), `fb-pdf-${process.pid}-${Math.random().toString(36).slice(2)}.pdf`);
    fs.writeFileSync(arq, bytes);
    return execFileSync('pdftotext', ['-layout', arq, '-']).toString();
  } catch { return null; } // sem pdftotext na máquina: o teste correspondente é pulado
}

test('plano: "Ação | Objetivo | Indicador" vira prioridade + ação + objetivo + indicador (web e PDF)', async () => {
  const conteudo = { ...exemplo.conteudo, proximosPassos: 'Ajustar posicionamento | Clareza | Compreensão da proposta\nNova identidade visual' };
  const modelo = Modelo.montarModelo(conteudo);
  const passos = modelo.secoes.find((s) => s.id === 'passos').itens;
  assert.deepEqual(passos[0], { prioridade: 1, acao: 'Ajustar posicionamento', objetivo: 'Clareza', indicador: 'Compreensão da proposta' });
  assert.deepEqual(passos[1], { prioridade: 2, acao: 'Nova identidade visual', objetivo: '', indicador: '' });
  const html = Modelo.renderizarWeb(modelo);
  assert.match(html, /<dt>Objetivo<\/dt><dd>Clareza<\/dd>/);
  const r = await motor.gerar({ PDFLib, modelo, tema: exemplo.tema });
  for (const t of ['Ajustar posicionamento', 'Clareza', 'Compreensão da proposta']) assert.ok(r.textos.includes(t));
});

test('hero: nome + segmento + localização + tipo de análise + data', () => {
  const m = Modelo.montarModelo({ ...exemplo.conteudo, capa: { ...exemplo.conteudo.capa, localizacao: 'Petrolina · PE' } });
  const html = Modelo.renderizarWeb(m);
  assert.match(html, /Construção civil · Petrolina · PE/);
  assert.match(html, /Diagnóstico Estratégico da Marca/);
  assert.match(html, /30 de setembro de 2026/);
});

test('insights: Observação → Interpretação → Implicação (web e PDF)', async () => {
  const html = Modelo.renderizarWeb(Modelo.montarModelo(exemplo.conteudo));
  assert.match(html, /Observação[\s\S]*Interpretação[\s\S]*Implicação/);
  const txt = textoDoPdf((await motor.gerar({ PDFLib, ...exemplo })).bytes);
  if (txt !== null) assert.match(txt, /OBSERVAÇÃO[\s\S]*INTERPRETAÇÃO[\s\S]*IMPLICAÇÃO/);
});

test('símbolos: ★ vira estrela vetorial; emoji some; NENHUM "�" no texto do PDF', async (t) => {
  const conteudo = { ...exemplo.conteudo, oportunidades: 'Melhorar avaliações 😀 ★★★\nOutra 🚀 ideia', capa: { ...exemplo.conteudo.capa, subtitulo: 'Café ☕ São João' } };
  const r = await motor.gerar({ PDFLib, conteudo, tema: exemplo.tema });
  const bruto = Buffer.from(r.bytes).toString('latin1');
  assert.ok(/ 0\.6 0 0 0\.6 | re |c\n/.test(bruto) || bruto.includes('re'), 'PDF gerado');
  const txt = textoDoPdf(r.bytes);
  if (txt === null) { t.skip('pdftotext indisponível'); return; }
  assert.ok(!txt.includes('�'), 'sem caractere de substituição');
  assert.match(txt, /4,6/);
  assert.match(txt, /Café São João/);
});

test('logo inválida (SVG/corrompida) → monograma; documento gerado normalmente', async () => {
  for (const logo of ['data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=', 'data:image/png;base64,QUJDRA==']) {
    const r = await motor.gerar({ PDFLib, ...exemplo, tema: { ...exemplo.tema, logo } });
    assert.ok(r.paginas >= 2);
  }
});

for (const n of [1, 2, 20, 100]) {
  test(`paginação: parágrafo de ${n} linha(s) sem órfã/viúva e sem página vazia`, async () => {
    const frase = 'Linha de texto do diagnóstico para testar a paginação controlada do motor de PDF ';
    const doc0 = await PDFLib.PDFDocument.create();
    const f = await doc0.embedFont(PDFLib.StandardFonts.Helvetica);
    // monta um texto que quebra em exatamente n linhas na largura útil
    let texto = '';
    while (motor._internos.quebrar(texto + frase, f, 10.5, 595.28 - 112).length <= n) texto += frase;
    texto = texto.trim();
    assert.equal(motor._internos.quebrar(texto, f, 10.5, 595.28 - 112).length, n);
    const conteudo = { capa: { subtitulo: 'Teste' }, sobreEmpresa: { incluir: true, contexto: texto } };
    const r = await motor.gerar({ PDFLib, conteudo });
    const esperadas = { 1: 2, 2: 2, 20: 2, 100: 4 }[n]; // capa + ~44 linhas por página interna
    assert.equal(r.paginas, esperadas, `${n} linhas → ${r.paginas} páginas`);
    const txt = textoDoPdf(r.bytes);
    if (txt !== null) {
      const paginas = txt.split('\f').filter((p) => p.trim());
      assert.equal(paginas.length, esperadas, 'nenhuma página vazia');
      const FIXO = /Teste|Diagnóstico Estratégico|Felipe Branding|Página \d|SOBRE A EMPRESA|Sobre a empresa|CONTEXTO/;
      for (const p of paginas.slice(1)) {
        const linhasConteudo = p.split('\n').filter((l) => l.trim() && !FIXO.test(l)).length;
        assert.ok(linhasConteudo >= Math.min(2, n), `página com ${linhasConteudo} linha(s) solta(s)`);
      }
    }
  });
}
