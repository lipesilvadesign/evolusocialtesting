const test = require('node:test');
const assert = require('node:assert/strict');
const { resolverPeriodo, PERIODOS_VALIDOS } = require('../netlify/functions/_lib/dateRangeProspeccao');

const AGORA = new Date('2026-09-06T18:00:00.000Z');

test('resolverPeriodo: "hoje" volta 1 dia', () => {
  const { inicio, fim } = resolverPeriodo('hoje', AGORA);
  assert.equal(fim, '2026-09-06T18:00:00.000Z');
  assert.equal(inicio, '2026-09-05T18:00:00.000Z');
});

test('resolverPeriodo: "semana" volta 7 dias', () => {
  const { inicio } = resolverPeriodo('semana', AGORA);
  assert.equal(inicio, '2026-08-30T18:00:00.000Z');
});

test('resolverPeriodo: "mes" volta 30 dias', () => {
  const { inicio } = resolverPeriodo('mes', AGORA);
  assert.equal(inicio, '2026-08-07T18:00:00.000Z');
});

test('resolverPeriodo: "tudo" não tem início (null), só fim', () => {
  const { inicio, fim } = resolverPeriodo('tudo', AGORA);
  assert.equal(inicio, null);
  assert.equal(fim, '2026-09-06T18:00:00.000Z');
});

test('resolverPeriodo: período inválido lança erro claro', () => {
  assert.throws(() => resolverPeriodo('ano', AGORA), /Período inválido/);
});

test('resolverPeriodo: label amigável pra cada período', () => {
  assert.equal(resolverPeriodo('hoje', AGORA).label, 'Hoje');
  assert.equal(resolverPeriodo('semana', AGORA).label, 'Últimos 7 dias');
  assert.equal(resolverPeriodo('mes', AGORA).label, 'Últimos 30 dias');
  assert.equal(resolverPeriodo('tudo', AGORA).label, 'Todo o período');
});

test('PERIODOS_VALIDOS: exporta a lista usada pra validar', () => {
  assert.deepEqual(PERIODOS_VALIDOS, ['hoje', 'semana', 'mes', 'tudo']);
});

test('resolverPeriodo: sem passar "agora" usa o relógio real (não trava/quebra)', () => {
  const { fim } = resolverPeriodo('hoje');
  assert.ok(new Date(fim).getTime() <= Date.now() + 1000);
});
