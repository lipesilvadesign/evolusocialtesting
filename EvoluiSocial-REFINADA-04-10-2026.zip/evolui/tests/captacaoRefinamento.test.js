/**
 * Refinamento 30/09: Overpass (orçamento, Retry-After, remark), enriquecimento
 * de página (sinais só com evidência), merge sem sobrescrever, CNPJ, flags,
 * mensagens de erro da aprovação.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const enriquecer = require('../netlify/functions/_lib/captacao/enriquecer');
const cnpj = require('../netlify/functions/_lib/captacao/providers/cnpj');
const flags = require('../netlify/functions/_lib/captacao/flags');
const cache = require('../netlify/functions/_lib/captacao/cache');
const overpass = require('../netlify/functions/_lib/captacao/providers/overpass');
const taxonomia = require('../netlify/functions/_lib/captacao/taxonomia');

const RECHEIO = '<p>' + 'Somos uma empresa de construção em Petrolina com obras residenciais e comerciais. '.repeat(20) + '</p>';
const pagina = (corpo) => `<!doctype html><html><head><title>Alfa Construções</title><meta name="description" content="Obras em Petrolina"></head><body>${RECHEIO}${corpo}</body></html>`;

// ---------- Overpass ----------
function respostaJson(status, corpo, headers = {}) {
  return { status, ok: status >= 200 && status < 300, headers: { get: (h) => headers[h.toLowerCase()] || null }, json: async () => corpo };
}

test('Overpass: 200 com lista vazia + remark de timeout NÃO é "0 resultados" — tenta outro espelho', async () => {
  const osm = require('../netlify/functions/_lib/integrations/openStreetMap');
  const original = global.fetch;
  let n = 0;
  global.fetch = async () => {
    n += 1;
    if (n === 1) return respostaJson(200, { elements: [], remark: 'runtime error: Query timed out in "query" at line 1 after 25 seconds.' });
    return respostaJson(200, { elements: [{ type: 'node', id: 1, tags: { name: 'X' } }] });
  };
  try {
    const els = await osm.postOverpassQuery('[out:json];node(1);out;');
    assert.equal(els.length, 1);
    assert.equal(n, 2);
  } finally { global.fetch = original; }
});

test('Overpass: Retry-After de 60 s é limitado (teto) e o orçamento total é respeitado', async () => {
  const osm = require('../netlify/functions/_lib/integrations/openStreetMap');
  const original = global.fetch;
  global.fetch = async () => respostaJson(429, {}, { 'retry-after': '60' });
  const t = Date.now();
  try {
    await assert.rejects(() => osm.postOverpassQuery('[out:json];node(1);out;', { prazoMs: 4000 }), /Overpass|espelhos/);
  } finally { global.fetch = original; }
  assert.ok(Date.now() - t < 5000, `levou ${Date.now() - t} ms (orçamento 4 s)`);
  assert.ok(osm.RETRY_AFTER_MAX_MS <= 5000);
});

test('Overpass: consulta leve — sem relações na busca só por nome; timeout do servidor acompanha o prazo', () => {
  const def = taxonomia.porId('Construção');
  const q = overpass.montarConsulta(def, -9.39, -40.5, 15000, ['construtora'], 18);
  assert.match(q, /\[timeout:18\]/);
  assert.doesNotMatch(q, /nwr\["name"~/);
});

// ---------- Página / sinais ----------
test('página: título, descrição, WhatsApp, e-mail (sem pegar nome de imagem) e formulário', () => {
  const p = enriquecer.analisarPagina(pagina('<form action="/c"></form><a href="https://wa.me/5587999990000">WhatsApp</a> fale: contato@alfa.com.br <img src="logo@2x.png">'));
  assert.equal(p.titulo, 'Alfa Construções');
  assert.equal(p.descricao, 'Obras em Petrolina');
  assert.equal(p.formulario, true);
  assert.equal(p.whatsapp, '5587999990000');
  assert.deepEqual(p.emails, ['contato@alfa.com.br']);
  assert.equal(p.conteudoSuficiente, true);
});

test('sinais: página sem formulário e sem contato → SITE_SEM_FORMULARIO + SITE_SEM_CONTATO, com evidência "página inicial"', () => {
  const chec = { resultado: 'ok', httpStatus: 200, https: true, url: 'https://alfa.com.br/', evidencia: 'x', pagina: enriquecer.analisarPagina(pagina('')) };
  const s = enriquecer.sinaisPara({ site: 'https://alfa.com.br' }, chec);
  assert.deepEqual(s.map((x) => x.tipo), ['SITE_SEM_FORMULARIO', 'SITE_SEM_CONTATO', 'SITE_SEM_WHATSAPP', 'SITE_SEM_INSTAGRAM']);
  for (const x of s) { assert.match(x.evidencia, /página inicial/); assert.equal(x.confianca, 'media'); }
});

test('sinais: página com WhatsApp mas sem <form> → só SITE_SEM_FORMULARIO', () => {
  const chec = { resultado: 'ok', httpStatus: 200, https: true, pagina: enriquecer.analisarPagina(pagina('<a href="https://wa.me/5587999990000">zap</a>')) };
  assert.deepEqual(enriquecer.sinaisPara({ site: 'x' }, chec).map((x) => x.tipo), ['SITE_SEM_FORMULARIO', 'SITE_SEM_INSTAGRAM']);
  assert.deepEqual(enriquecer.sinaisPara({ site: 'x', instagram: '@empresa' }, chec).map((x) => x.tipo), ['SITE_SEM_FORMULARIO'], 'Instagram informado pela fonte: sem sinal');
});

test('sinais: site montado só por JavaScript (HTML quase vazio) = não conclusivo → NENHUM sinal inventado', () => {
  const chec = { resultado: 'ok', httpStatus: 200, https: true, pagina: enriquecer.analisarPagina('<html><body><div id="root"></div><script src="/app.js"></script></body></html>') };
  assert.equal(chec.pagina.conteudoSuficiente, false);
  assert.deepEqual(enriquecer.sinaisPara({ site: 'x' }, chec), []);
});

test('sinais: SITE_DESATUALIZADO nunca é gerado automaticamente', () => {
  const chec = { resultado: 'ok', httpStatus: 200, https: true, pagina: enriquecer.analisarPagina(pagina('© 2009 Todos os direitos reservados')) };
  assert.ok(!enriquecer.sinaisPara({ site: 'x' }, chec).some((x) => x.tipo === 'SITE_DESATUALIZADO'));
});

test('merge: campo já preenchido NÃO é proposto; vazio é proposto com a origem', () => {
  const chec = { resultado: 'ok', httpStatus: 200, https: true, pagina: enriquecer.analisarPagina(pagina('<a href="tel:+558738620000">ligue</a> <a href="mailto:vendas@alfa.com.br">e-mail</a> <a href="https://instagram.com/alfa.obras">IG</a>')) };
  const d1 = enriquecer.montarEnriquecimento({ site: 'x', email: 'manual@alfa.com.br', telefone: null, instagram: null }, chec);
  assert.equal(d1.email, undefined, 'e-mail manual preservado');
  assert.equal(d1.telefone, '+558738620000');
  assert.equal(d1.instagram, '@alfa.obras');
  assert.deepEqual(d1.enriquecimento.origem_campos, { telefone: 'site (tel:)', instagram: 'link no site' });
  assert.equal(d1.status, 'concluido');
  const d2 = enriquecer.montarEnriquecimento({ site: 'x' }, { resultado: 'nao_verificado', httpStatus: 403, evidencia: 'bloqueio' });
  assert.equal(d2.status, 'parcial');
  assert.deepEqual(d2.sinais, []);
});

// ---------- CNPJ ----------
test('CNPJ: inválido não faz requisição; 404 e timeout viram motivo, nunca exceção', async () => {
  let chamadas = 0;
  const f = async () => { chamadas += 1; return { status: 404, ok: false }; };
  assert.deepEqual(await cnpj.consultar('11.111.111/1111-11', { fetchImpl: f }), { ok: false, motivo: 'CNPJ inválido' });
  assert.equal(chamadas, 0);
  const r = await cnpj.consultar('11.222.333/0001-81', { fetchImpl: f });
  assert.equal(r.ok, false);
  assert.match(r.motivo, /não encontrado/);
  const lento = (url, { signal }) => new Promise((_, rej) => signal.addEventListener('abort', () => rej(Object.assign(new Error('abort'), { name: 'AbortError' }))));
  assert.equal((await cnpj.consultar('11222333000181', { fetchImpl: lento, timeoutMs: 20 })).motivo, 'timeout');
});

test('CNPJ: grava fonte e data; EMPRESA_NOVA só com início de atividade < 12 meses informado pela fonte', async () => {
  const f = async () => ({ status: 200, ok: true, json: async () => ({ razao_social: 'ALFA LTDA', data_inicio_atividade: '2026-03-10', descricao_situacao_cadastral: 'ATIVA', qsa: [{ nome_socio: 'PESSOA FÍSICA' }] }) });
  const r = await cnpj.consultar('11222333000181', { fetchImpl: f });
  assert.equal(r.ok, true);
  assert.match(r.dados.fonte, /BrasilAPI/);
  assert.ok(r.dados.consultado_em);
  assert.ok(!JSON.stringify(r.dados).includes('PESSOA FÍSICA'), 'quadro de sócios não é guardado');
  const s = cnpj.sinalEmpresaNova(r.dados, new Date('2026-09-30T12:00:00Z'));
  assert.equal(s.tipo, 'EMPRESA_NOVA');
  assert.match(s.evidencia, /2026-03-10/);
  assert.equal(cnpj.sinalEmpresaNova({ ...r.dados, inicio_atividade: '2019-01-01' }, new Date('2026-09-30T12:00:00Z')), null);
  assert.equal(cnpj.sinalEmpresaNova({ ...r.dados, inicio_atividade: null }), null);
});

// ---------- Flags e cache ----------
test('flags: padrões (captação nova, mapa e PDF ligados; CNPJ desligado) e desligamento por env', () => {
  assert.deepEqual(flags.publicas({}), { novoFluxoCaptacao: true, selecaoNoMapa: true, novoPdf: true, consultaCnpj: false });
  assert.equal(flags.ligada('ENABLE_NEW_CAPTURE_FLOW', { ENABLE_NEW_CAPTURE_FLOW: 'false' }), false);
  assert.equal(flags.ligada('ENABLE_CNPJ_LOOKUP', { ENABLE_CNPJ_LOOKUP: '1' }), true);
  assert.equal(flags.ligada('ENABLE_MAP_SELECTION', { ENABLE_MAP_SELECTION: '0' }), false);
});

test('cache: mesma busca com centro a < 50 m gera a mesma chave; setor/raio diferentes não', () => {
  const a = cache.chave('geoapify', { setor: 'Construção', lat: -9.38912, lon: -40.50301, raioKm: 15 });
  const b = cache.chave('geoapify', { setor: 'Construção', lat: -9.38918, lon: -40.50298, raioKm: 15 });
  assert.equal(a, b);
  assert.notEqual(a, cache.chave('geoapify', { setor: 'Saúde', lat: -9.38912, lon: -40.50301, raioKm: 15 }));
  assert.notEqual(a, cache.chave('geoapify', { setor: 'Construção', lat: -9.38912, lon: -40.50301, raioKm: 5 }));
  assert.notEqual(a, cache.chave('overpass', { setor: 'Construção', lat: -9.38912, lon: -40.50301, raioKm: 15 }));
});

// ---------- API: área do mapa e mensagens da aprovação ----------
test('iniciar com área do mapa: valida no servidor (Brasil, 0,5–30 km) e grava {latitude, longitude, raio_metros}', () => {
  const { _internos } = require('../netlify/functions/captacao');
  const base = { setor: 'Construção', providers: ['geoapify'] };
  const ok = _internos.validarPesquisa({ ...base, area: { latitude: -9.3891234567, longitude: -40.503, raio_metros: 2500 } });
  assert.deepEqual(ok.dados.area, { latitude: -9.389123, longitude: -40.503, raio_metros: 2500, rotulo: 'Área escolhida no mapa' });
  assert.equal(ok.dados.raioKm, 2.5);
  assert.match(_internos.validarPesquisa({ ...base, area: { latitude: 40.7, longitude: -74, raio_metros: 2500 } }).erro, /Área do mapa inválida/);
  assert.match(_internos.validarPesquisa({ ...base, area: { latitude: -9.3, longitude: -40.5, raio_metros: 90000 } }).erro, /Área do mapa inválida/);
  assert.match(_internos.validarPesquisa({ ...base, providers: [], area: { latitude: -9.3, longitude: -40.5, raio_metros: 1000 } }).erro, /fonte/);
  const antes = process.env.ENABLE_MAP_SELECTION;
  process.env.ENABLE_MAP_SELECTION = 'false';
  try { assert.match(_internos.validarPesquisa({ ...base, area: { latitude: -9.3, longitude: -40.5, raio_metros: 1000 } }).erro, /desativada/); }
  finally { if (antes === undefined) delete process.env.ENABLE_MAP_SELECTION; else process.env.ENABLE_MAP_SELECTION = antes; }
});

test('aprovação: erro do banco vira frase legível (nunca "Erro desconhecido"), sem detalhe técnico', () => {
  const { _internos } = require('../netlify/functions/captacao');
  const audit = { message: 'Falha no banco (400): new row for relation "admin_audit_log" violates check constraint "admin_audit_log_action_check"', detalhe: 'new row for relation "admin_audit_log" violates check constraint "admin_audit_log_action_check"' };
  assert.match(_internos.motivoAprovacao(audit), /auditoria/);
  assert.match(_internos.motivoAprovacao({ message: 'Banco não respondeu (timeout).' }), /demorou/);
  assert.match(_internos.motivoAprovacao({ message: 'Falha no banco (400): Usuário de prospecção só pode atribuir leads a si mesmo.', detalhe: 'Usuário de prospecção só pode atribuir leads a si mesmo.' }), /si mesmo/);
  assert.doesNotMatch(_internos.motivoAprovacao({}), /desconhecido/i);
});

// ---------- 01/10: área personalizada (polígono) ----------
const pipeline = require('../netlify/functions/_lib/captacao/pipeline');
const { registro } = require('../netlify/functions/_lib/captacao/tipos');
const quadrado = { type: 'Polygon', coordinates: [[[-40.52, -9.40], [-40.48, -9.40], [-40.48, -9.37], [-40.52, -9.37], [-40.52, -9.40]]] };

test('polígono: validação (fechado, 3–20 cantos, no Brasil) e ponto dentro/fora', () => {
  assert.ok(pipeline.poligonoValido(quadrado));
  assert.equal(pipeline.poligonoValido({ type: 'Polygon', coordinates: [[[-40.5, -9.4], [-40.4, -9.4], [-40.5, -9.4]]] }), null, 'menos de 3 cantos');
  assert.equal(pipeline.poligonoValido({ type: 'Polygon', coordinates: [[[-40.5, -9.4], [-40.4, -9.4], [-40.4, -9.3], [-40.5, -9.3]]] }), null, 'anel aberto');
  assert.equal(pipeline.poligonoValido({ type: 'Polygon', coordinates: [[[2.3, 48.8], [2.4, 48.8], [2.4, 48.9], [2.3, 48.8]]] }), null, 'fora do Brasil');
  assert.equal(pipeline.dentroDoPoligono(-9.385, -40.50, quadrado), true);
  assert.equal(pipeline.dentroDoPoligono(-9.30, -40.50, quadrado), false);
});

test('polígono: o círculo consultado precisa cobrir a área inteira', () => {
  assert.ok(pipeline.areaValida({ latitude: -9.385, longitude: -40.50, raio_metros: 3000, geometry: quadrado }));
  assert.equal(pipeline.areaValida({ latitude: -9.385, longitude: -40.50, raio_metros: 1000, geometry: quadrado }), null);
  assert.equal(pipeline.areaValida({ latitude: -9.385, longitude: -40.50, raio_metros: 3000, geometry: { type: 'Point' } }), null, 'geometria inválida é recusada, não ignorada');
});

test('polígono: pipeline descarta o que caiu FORA da área e conta quantos', async () => {
  const gravados = [];
  const deps = {
    novoFluxo: true,
    atualizarJob: async () => {}, lerStatusJob: async () => 'em_andamento', aguardar: async () => {},
    geocodificar: async () => { throw new Error('não deveria geocodificar'); },
    coletar: { geoapify: async () => ({ registros: [
      registro({ provider: 'geoapify', external_id: 'g:dentro', empresa: 'Dentro Ltda', cidade: 'Petrolina', lat: -9.385, lon: -40.50 }),
      registro({ provider: 'geoapify', external_id: 'g:fora', empresa: 'Fora Ltda', cidade: 'Petrolina', lat: -9.30, lon: -40.50 }),
      registro({ provider: 'geoapify', external_id: 'g:semcoord', empresa: 'Sem Coordenada', cidade: 'Petrolina' }),
    ], avisos: [] }) },
    carregarBloqueios: async () => require('../netlify/functions/_lib/captacao/deduplicar').montarBloqueios([]),
    buscarCandidatos: async () => [],
    gravarCaptura: async (l) => gravados.push(...l),
    listarPendentesEnriquecimento: async () => [], gravarEnriquecimento: async () => ({}),
  };
  const job = { id: 'job-pol', providers: ['geoapify'], parametros: { setor: 'Construção', area: { latitude: -9.385, longitude: -40.50, raio_metros: 3000, geometry: quadrado } } };
  const r = await pipeline.executarPesquisa(job, deps);
  assert.deepEqual(gravados.map((g) => g.empresa), ['Dentro Ltda']);
  assert.equal(r.metricas.fora_da_area, 2);
});

test('API: iniciar com área personalizada grava a geometria normalizada', () => {
  const { _internos } = require('../netlify/functions/captacao');
  const ok = _internos.validarPesquisa({ setor: 'Construção', providers: ['geoapify'], area: { latitude: -9.385, longitude: -40.5, raio_metros: 3000, geometry: quadrado } });
  assert.deepEqual(ok.dados.area.geometry, quadrado);
  assert.match(_internos.validarPesquisa({ setor: 'Construção', providers: ['geoapify'], area: { latitude: -9.385, longitude: -40.5, raio_metros: 600, geometry: quadrado } }).erro, /cantos/);
});

test('flags: nomes da Fase 2 (ENABLE_CAPTURE_ENGINE_V2 / ENABLE_PDF_V2) funcionam e têm precedência', () => {
  assert.equal(flags.ligada('ENABLE_NEW_CAPTURE_FLOW', { ENABLE_CAPTURE_ENGINE_V2: 'false' }), false);
  assert.equal(flags.ligada('ENABLE_NEW_PDF_ENGINE', { ENABLE_PDF_V2: '0', ENABLE_NEW_PDF_ENGINE: 'true' }), false);
  assert.equal(flags.ligada('ENABLE_NEW_PDF_ENGINE', { ENABLE_NEW_PDF_ENGINE: 'false' }), false);
});


// ---------- Fase 3: crawl controlado ----------
function fakeSite(paginas) {
  const chamadas = [];
  const f = async (url) => {
    chamadas.push(url);
    const v = paginas[url];
    if (v === undefined) return { status: 404, ok: false, headers: { get: () => null }, text: async () => '', body: null };
    return { status: 200, ok: true, headers: { get: () => null }, text: async () => v, body: null };
  };
  f.chamadas = chamadas;
  return f;
}

test('crawl: sem contato na inicial → visita SÓ o link de contato do mesmo domínio e acha o WhatsApp lá', async () => {
  const home = pagina('<a href="/fale-conosco">Fale conosco</a><a href="https://outro.com/contato">externo</a><a href="/blog/post-1">blog</a>');
  const f = fakeSite({ 'https://alfa.com.br/': home, 'https://alfa.com.br/fale-conosco': pagina('<a href="https://wa.me/5587999990000">zap</a><form></form>') });
  const r = await enriquecer.verificarSite('alfa.com.br', { fetchImpl: f });
  assert.equal(r.pagina.whatsapp, '5587999990000');
  assert.equal(r.pagina.formulario, true);
  assert.ok(!f.chamadas.some((u) => u.includes('outro.com') || u.includes('/blog/')), 'não segue link externo nem não-relacionado');
  assert.ok(f.chamadas.length <= 1 + 1 + 2 + 1, 'inicial + robots + no máx. 2 extras + favicon');
  const s = enriquecer.sinaisPara({ site: 'https://alfa.com.br' }, r).map((x) => x.tipo);
  assert.ok(!s.includes('SITE_SEM_CONTATO') && !s.includes('SITE_SEM_WHATSAPP'));
});

test('crawl: robots.txt com Disallow é respeitado', async () => {
  const home = pagina('<a href="/contato">Contato</a>');
  const f = fakeSite({ 'https://beta.com.br/': home, 'https://beta.com.br/robots.txt': 'User-agent: *\nDisallow: /contato\n', 'https://beta.com.br/contato': pagina('<form></form>') });
  const r = await enriquecer.verificarSite('beta.com.br', { fetchImpl: f });
  assert.ok(!f.chamadas.includes('https://beta.com.br/contato'));
  assert.equal(r.pagina.formulario, false);
});

test('crawl: favicon ausente (sem <link rel=icon> e /favicon.ico 404) → SITE_SEM_FAVICON; sem meta description → SITE_SEM_META_DESCRIPTION', async () => {
  const semMeta = `<!doctype html><html><head><title>Gama</title></head><body>${'<p>Texto institucional da empresa Gama com bastante conteúdo visível. </p>'.repeat(30)}<a href="https://wa.me/5587988887777">zap</a></body></html>`;
  const f = fakeSite({ 'https://gama.com.br/': semMeta });
  const r = await enriquecer.verificarSite('gama.com.br', { fetchImpl: f });
  const s = enriquecer.sinaisPara({ site: 'https://gama.com.br' }, r).map((x) => x.tipo);
  assert.ok(s.includes('SITE_SEM_FAVICON'));
  assert.ok(s.includes('SITE_SEM_META_DESCRIPTION'));
  assert.ok(!s.includes('SITE_SEM_WHATSAPP'));
});

test('robots.txt: regras só do bloco que vale para nós', () => {
  const r = enriquecer.regrasRobots('User-agent: Googlebot\nDisallow: /tudo\n\nUser-agent: *\nDisallow: /privado\n# comentário\n');
  assert.deepEqual(r, ['/privado']);
});
