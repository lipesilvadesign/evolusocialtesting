const test = require('node:test');
const assert = require('node:assert/strict');
const equipeMensagensService = require('../netlify/functions/_lib/services/equipeMensagensService');
const { handler } = require('../netlify/functions/equipe-mensagens');

test('equipeMensagensService.enviar: rejeita mensagem vazia sem nem chamar a rede', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  try {
    await assert.rejects(() => equipeMensagensService.enviar('token', 'autor-1', '   '), /Escreva alguma coisa/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('equipeMensagensService.enviar: rejeita mensagem acima de 2000 caracteres sem chamar a rede', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  try {
    await assert.rejects(() => equipeMensagensService.enviar('token', 'autor-1', 'x'.repeat(2001)), /muito longa/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('equipeMensagensService.enviar: mensagem válida chama a API e devolve a linha criada', async () => {
  const originalFetch = globalThis.fetch;
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => ([{ id: 'm1', autor_id: 'autor-1', mensagem: 'Oi equipe', created_at: '2026-09-13T12:00:00Z' }]) };
  };
  try {
    const resultado = await equipeMensagensService.enviar('token', 'autor-1', '  Oi equipe  ');
    assert.equal(resultado.id, 'm1');
    assert.equal(corpoEnviado.autor_id, 'autor-1');
    assert.equal(corpoEnviado.mensagem, 'Oi equipe', 'deveria remover espaços nas pontas antes de gravar');
    assert.equal('lead_id' in corpoEnviado, false, 'sem leadId, não deveria mandar a chave no corpo');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('equipeMensagensService.enviar: com leadId, grava lead_id no corpo (compartilhar no mural)', async () => {
  const originalFetch = globalThis.fetch;
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => ([{ id: 'm2', autor_id: 'autor-1', mensagem: 'Dúvida sobre o cliente', lead_id: 'lead-123' }]) };
  };
  try {
    await equipeMensagensService.enviar('token', 'autor-1', 'Dúvida sobre o cliente', 'lead-123');
    assert.equal(corpoEnviado.lead_id, 'lead-123');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

function evento({ method = 'GET', body, token = 'token-valido', qs } = {}) {
  return {
    httpMethod: method,
    headers: token ? { authorization: `Bearer ${token}` } : {},
    body: body ? JSON.stringify(body) : undefined,
    queryStringParameters: qs || {},
  };
}

test('equipe-mensagens (Function): sem sessão, rejeita com 401', async () => {
  const res = await handler(evento({ token: null }));
  assert.equal(res.statusCode, 401);
});

test('equipe-mensagens (Function): GET lista as mensagens em ordem cronológica', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    if (String(url).includes('/auth/v1/user')) return { ok: true, json: async () => ({ id: 'u1', email: 'a@felipebranding.com.br' }) };
    return {
      ok: true,
      json: async () => ([
        { id: 'm2', autor_id: 'u1', mensagem: 'segunda', created_at: '2026-09-13T12:05:00Z' },
        { id: 'm1', autor_id: 'u1', mensagem: 'primeira', created_at: '2026-09-13T12:00:00Z' },
      ]),
    };
  };
  try {
    const res = await handler(evento({ method: 'GET' }));
    assert.equal(res.statusCode, 200);
    const { mensagens } = JSON.parse(res.body);
    assert.deepEqual(mensagens.map((m) => m.id), ['m1', 'm2'], 'devolvida do mais antigo pro mais novo');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('equipe-mensagens (Function): POST com corpo vazio responde 400 (não 502)', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    if (String(url).includes('/auth/v1/user')) return { ok: true, json: async () => ({ id: 'u1', email: 'a@felipebranding.com.br' }) };
    if (String(url).includes('admin_funcionarios')) return { ok: true, json: async () => ([{ role: 'admin' }]) };
    throw new Error('não deveria chegar na API do Supabase com mensagem vazia');
  };
  try {
    const res = await handler(evento({ method: 'POST', body: { mensagem: '' } }));
    assert.equal(res.statusCode, 400);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('equipe-mensagens (Function): DELETE sem id responde 400', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url) => (String(url).includes('admin_funcionarios')
    ? { ok: true, json: async () => ([{ role: 'admin' }]) }
    : { ok: true, json: async () => ({ id: 'u1', email: 'a@felipebranding.com.br' }) });
  try {
    const res = await handler(evento({ method: 'DELETE' }));
    assert.equal(res.statusCode, 400);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
