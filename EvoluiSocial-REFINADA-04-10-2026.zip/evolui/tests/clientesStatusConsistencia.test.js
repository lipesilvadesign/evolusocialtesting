const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

/**
 * Regressão do bug encontrado em 13/09: views/clientes.js tinha seu PRÓPRIO
 * STATUS_MAP (chaves lead/contato_feito/diagnostico/proposta/cliente/
 * perdido) e escrevia isso na coluna status_lead — que só aceita
 * novo/pesquisando/qualificado/nao_qualificado/duplicado/bloqueado (ver
 * SQL_PENDENTE_prospeccao.sql). Todo "Salvar alterações" que mexesse no
 * campo "Status" da página Clientes falhava contra a constraint do
 * Postgres. Corrigido: clientes.js agora importa STATUS_MAP/STATUS_ORDER de
 * prospeccao.js (fonte única) e lê/escreve o campo `status`.
 *
 * Roda em Node puro (sem DOM) — nem prospeccao.js nem clientes.js tocam
 * document/window no nível superior do módulo.
 */

function carregarProspeccaoView() {
  const url = 'file://' + path.resolve(__dirname, '../painel/assets/js/views/prospeccao.js');
  return import(url);
}

function carregarClientesView() {
  const url = 'file://' + path.resolve(__dirname, '../painel/assets/js/views/clientes.js');
  return import(url);
}

function carregarProspeccaoService() {
  return require('../netlify/functions/_lib/services/prospeccaoService.js');
}

test('views/clientes.js carrega sem erro e consegue importar STATUS_MAP/STATUS_ORDER de prospeccao.js', async () => {
  await assert.doesNotReject(carregarClientesView());
});

test('todo valor de STATUS_ORDER (usado no <select> da página Clientes) é aceito pelo backend (VALID_STATUS)', async () => {
  const { STATUS_ORDER } = await carregarProspeccaoView();
  const { VALID_STATUS } = carregarProspeccaoService();
  assert.ok(STATUS_ORDER.length > 0, 'STATUS_ORDER não pode estar vazio.');
  STATUS_ORDER.forEach((status) => {
    assert.ok(VALID_STATUS.has(status), `STATUS_ORDER contém "${status}", que o backend (VALID_STATUS) não aceita — o formulário de edição do cliente falharia ao salvar esse status.`);
  });
});

test('"cliente" (usado pra ordenar clientes primeiro na lista) é um status real e válido', async () => {
  const { STATUS_MAP } = await carregarProspeccaoView();
  const { VALID_STATUS } = carregarProspeccaoService();
  assert.ok(STATUS_MAP.cliente, 'STATUS_MAP precisa ter a chave "cliente".');
  assert.ok(VALID_STATUS.has('cliente'));
});
