const test = require('node:test');
const assert = require('node:assert/strict');
const { calcularResumo } = require('../netlify/functions/_lib/services/pontoService.js');

test('calcularResumo: um par entrada/saída no mesmo dia soma as horas certas', () => {
  const registros = [
    { tipo: 'entrada', registrado_em: '2026-09-10T09:00:00.000Z' },
    { tipo: 'saida', registrado_em: '2026-09-10T17:00:00.000Z' },
  ];
  const resumo = calcularResumo(registros);
  assert.equal(resumo.diasTrabalhados, 1);
  assert.equal(resumo.horasTrabalhadas, 8);
});

test('calcularResumo: soma dias distintos mesmo com múltiplos pares', () => {
  const registros = [
    { tipo: 'entrada', registrado_em: '2026-09-10T09:00:00.000Z' },
    { tipo: 'saida', registrado_em: '2026-09-10T12:00:00.000Z' },
    { tipo: 'entrada', registrado_em: '2026-09-10T13:00:00.000Z' },
    { tipo: 'saida', registrado_em: '2026-09-10T18:00:00.000Z' },
    { tipo: 'entrada', registrado_em: '2026-09-11T09:00:00.000Z' },
    { tipo: 'saida', registrado_em: '2026-09-11T17:00:00.000Z' },
  ];
  const resumo = calcularResumo(registros);
  assert.equal(resumo.diasTrabalhados, 2);
  assert.equal(resumo.horasTrabalhadas, 3 + 5 + 8);
});

test('calcularResumo: entrada sem saída correspondente (dia em andamento, ou esqueceu de bater) não soma horas, mas conta o dia', () => {
  const registros = [{ tipo: 'entrada', registrado_em: '2026-09-13T09:00:00.000Z' }];
  const resumo = calcularResumo(registros);
  assert.equal(resumo.diasTrabalhados, 1);
  assert.equal(resumo.horasTrabalhadas, 0);
});

test('calcularResumo: sem nenhum registro, tudo zerado (nunca inventa número)', () => {
  const resumo = calcularResumo([]);
  assert.equal(resumo.diasTrabalhados, 0);
  assert.equal(resumo.horasTrabalhadas, 0);
});

test('calcularResumo: eventos fora de ordem cronológica são ordenados antes de parear', () => {
  const registros = [
    { tipo: 'saida', registrado_em: '2026-09-10T17:00:00.000Z' },
    { tipo: 'entrada', registrado_em: '2026-09-10T09:00:00.000Z' },
  ];
  const resumo = calcularResumo(registros);
  assert.equal(resumo.horasTrabalhadas, 8);
});
