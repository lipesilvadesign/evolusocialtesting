const test = require('node:test');
const assert = require('node:assert/strict');
const { preencherModelo } = require('../netlify/functions/_lib/templateUtil');

test('preencherModelo: substitui empresa/setor/cidade', () => {
  const lead = { empresa: 'Construtora Teste', setor: 'Construção Civil', cidade: 'Petrolina, PE' };
  assert.equal(preencherModelo('Uma ideia para a {{empresa}}', lead), 'Uma ideia para a Construtora Teste');
  assert.equal(
    preencherModelo('{{empresa}} atua em {{setor}} na cidade de {{cidade}}.', lead),
    'Construtora Teste atua em Construção Civil na cidade de Petrolina, PE.'
  );
});

test('preencherModelo: variável repetida é substituída em todas as ocorrências', () => {
  const lead = { empresa: 'ACME' };
  assert.equal(preencherModelo('{{empresa}} e {{empresa}} de novo', lead), 'ACME e ACME de novo');
});

test('preencherModelo: campo ausente no lead vira string vazia, não quebra', () => {
  const lead = { empresa: 'Empresa X' };
  assert.equal(preencherModelo('{{empresa}} - {{setor}} - {{cidade}}', lead), 'Empresa X -  - ');
});

test('preencherModelo: texto/lead vazios não lançam erro', () => {
  assert.equal(preencherModelo('', {}), '');
  assert.equal(preencherModelo(null, {}), '');
});

const { normalizarNome } = require('../netlify/functions/_lib/templateUtil');

test('normalizarNome: usado pra deduplicar a mesma empresa vinda de fontes diferentes (Geoapify + OSM)', () => {
  assert.equal(normalizarNome('Construtora Silva Ltda'), 'construtora silva ltda');
  assert.equal(normalizarNome('  Construtora Silva Ltda  '), 'construtora silva ltda', 'espaços nas pontas não contam');
  assert.equal(normalizarNome('CONSTRUTORA SILVA LTDA'), normalizarNome('construtora silva ltda'), 'maiúscula/minúscula é a mesma empresa');
  assert.equal(normalizarNome(''), '');
  assert.equal(normalizarNome(null), '');
  assert.equal(normalizarNome(undefined), '');
});

const { agregarRelatorio } = require('../netlify/functions/_lib/templateUtil');

test('agregarRelatorio: soma enviados/falhas de vários envios do período', () => {
  const envios = [
    { resumo: { enviados: 3, falhas: 1 } },
    { resumo: { enviados: 5, falhas: 0 } },
    { resumo: { enviados: 2, falhas: 2 } },
  ];
  const r = agregarRelatorio(envios, [], { total: 0, porFonte: {} });
  assert.equal(r.emailsEnviados, 10);
  assert.equal(r.emailsComFalha, 3);
});

test('agregarRelatorio: soma total_encontrado de várias buscas do período', () => {
  const buscas = [{ total_encontrado: 4 }, { total_encontrado: 0 }, { total_encontrado: 7 }];
  const r = agregarRelatorio([], buscas, { total: 0, porFonte: {} });
  assert.equal(r.empresasEncontradas, 11);
  assert.equal(r.buscasRealizadas, 3);
});

test('agregarRelatorio: sem nenhum envio/busca no período, tudo zerado (não quebra)', () => {
  const r = agregarRelatorio([], [], { total: 0, porFonte: {} });
  assert.equal(r.emailsEnviados, 0);
  assert.equal(r.emailsComFalha, 0);
  assert.equal(r.empresasEncontradas, 0);
  assert.equal(r.buscasRealizadas, 0);
  assert.equal(r.leadsNoPeriodo, 0);
});

test('agregarRelatorio: envio sem campo "resumo" (job travou antes de concluir) não quebra a soma', () => {
  const envios = [{ resumo: { enviados: 2, falhas: 0 } }, { resumo: null }, {}];
  const r = agregarRelatorio(envios, [], { total: 0, porFonte: {} });
  assert.equal(r.emailsEnviados, 2);
});

test('agregarRelatorio: repassa leadsNoPeriodo e leadsPorFonte como vieram', () => {
  const leads = { total: 5, porFonte: { geoapify_manual: 3, osm_auto: 2 } };
  const r = agregarRelatorio([], [], leads);
  assert.equal(r.leadsNoPeriodo, 5);
  assert.deepEqual(r.leadsPorFonte, { geoapify_manual: 3, osm_auto: 2 });
});

const { onlyDigits } = require('../netlify/functions/_lib/templateUtil');

test('onlyDigits: remove tudo que não é número (usado pra comparar telefone em opt-out)', () => {
  assert.equal(onlyDigits('(87) 99999-8888'), '87999998888');
  assert.equal(onlyDigits('+55 87 99999-8888'), '5587999998888');
  assert.equal(onlyDigits(''), '');
  assert.equal(onlyDigits(null), '');
  assert.equal(onlyDigits(undefined), '');
});

const { candidatoEstaBloqueado, leadEstaBloqueado } = require('../netlify/functions/_lib/templateUtil');

function bloqueiosVazios() {
  return { origemIds: new Set(), emails: new Set(), telefones: new Set() };
}

test('candidatoEstaBloqueado: bloqueia por origem_id', () => {
  const bloqueios = { origemIds: new Set(['osm:node/1']), emails: new Set(), telefones: new Set() };
  assert.equal(candidatoEstaBloqueado({ origemId: 'osm:node/1' }, bloqueios), true);
  assert.equal(candidatoEstaBloqueado({ origemId: 'osm:node/2' }, bloqueios), false);
});

test('candidatoEstaBloqueado: bloqueia por e-mail (case-insensitive) e telefone (só dígitos)', () => {
  const bloqueios = { origemIds: new Set(), emails: new Set(['contato@empresa.com']), telefones: new Set(['87999998888']) };
  assert.equal(candidatoEstaBloqueado({ email: 'CONTATO@empresa.com' }, bloqueios), true);
  assert.equal(candidatoEstaBloqueado({ telefone: '(87) 99999-8888' }, bloqueios), true);
  assert.equal(candidatoEstaBloqueado({ email: 'outro@empresa.com', telefone: '87911112222' }, bloqueios), false);
});

test('candidatoEstaBloqueado: sem nenhum identificador presente não é bloqueado (não quebra)', () => {
  assert.equal(candidatoEstaBloqueado({}, bloqueiosVazios()), false);
});

test('leadEstaBloqueado: status_contato "nao_contatar" ou "optout_solicitado" bloqueiam mesmo sem estar na lista de opt-out', () => {
  assert.equal(leadEstaBloqueado({ statusContato: 'nao_contatar' }, bloqueiosVazios()), true);
  assert.equal(leadEstaBloqueado({ statusContato: 'optout_solicitado' }, bloqueiosVazios()), true);
  assert.equal(leadEstaBloqueado({ statusContato: 'email_validado' }, bloqueiosVazios()), false);
});

test('leadEstaBloqueado: também herda a checagem de origem_id/e-mail/telefone (mesma lógica do candidato)', () => {
  const bloqueios = { origemIds: new Set(), emails: new Set(['lead@empresa.com']), telefones: new Set() };
  assert.equal(leadEstaBloqueado({ statusContato: 'email_validado', email: 'lead@empresa.com' }, bloqueios), true);
});
