const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

async function carregarModulo() {
  const url = 'file://' + path.resolve(__dirname, '../painel/assets/js/services/csvLeads.js');
  return import(url);
}

test('leadsParaCSV: gera cabeçalho + uma linha por lead, na ordem certa de colunas', async () => {
  const { leadsParaCSV, COLUNAS_CSV } = await carregarModulo();
  const csv = leadsParaCSV([
    { id: '1', empresa: 'Construtora A', cnpj: '', setor: 'Construção', cidade: 'Petrolina', score: 30, sinal_porte_medio_grande: false },
  ]);
  const linhas = csv.split('\r\n');
  assert.equal(linhas[0], COLUNAS_CSV.join(','));
  assert.ok(linhas[1].startsWith('1,Construtora A,,Construção,Petrolina'));
  assert.ok(linhas[1].includes('Não'), 'porte_medio_grande false deveria virar "Não"');
});

test('leadsParaCSV: escapa campo com vírgula, aspas e quebra de linha', async () => {
  const { leadsParaCSV } = await carregarModulo();
  const csv = leadsParaCSV([{ id: '1', empresa: 'Empresa, com vírgula "e aspas"' }]);
  assert.ok(csv.includes('"Empresa, com vírgula ""e aspas"""'));
});

test('parseCSV: round-trip com leadsParaCSV recupera os dados exatos', async () => {
  const { leadsParaCSV, parseCSV } = await carregarModulo();
  const lead = { id: 'abc-123', empresa: 'Empresa, Ltda "Apelido"', cnpj: '12.345.678/0001-90', setor: 'Indústria' };
  const csv = leadsParaCSV([lead]);
  const linhas = parseCSV(csv);
  assert.equal(linhas.length, 2, 'cabeçalho + 1 linha de dado');
  assert.equal(linhas[1][0], 'abc-123');
  assert.equal(linhas[1][1], 'Empresa, Ltda "Apelido"');
  assert.equal(linhas[1][2], '12.345.678/0001-90');
});

test('parseCSV: ignora linhas totalmente vazias no fim do arquivo', async () => {
  const { parseCSV } = await carregarModulo();
  const linhas = parseCSV('a,b\r\n1,2\r\n\r\n');
  assert.equal(linhas.length, 2);
});

test('csvParaAtualizacoes: detecta CNPJ preenchido numa linha que antes estava vazio', async () => {
  const { parseCSV, csvParaAtualizacoes, COLUNAS_CSV } = await carregarModulo();
  const leadsAtuais = [{ id: '1', empresa: 'Construtora A', cnpj: '', anos_mercado: '', setor: 'Construção', sinal_porte_medio_grande: false }];
  const csvEditado = [
    COLUNAS_CSV.join(','),
    '1,Construtora A,12345678000190,Construção,,,,,,Não,,,,,',
  ].join('\r\n');
  const atualizacoes = csvParaAtualizacoes(parseCSV(csvEditado), leadsAtuais);
  assert.equal(atualizacoes.length, 1);
  assert.equal(atualizacoes[0].payload.cnpj, '12345678000190');
  assert.equal(Object.keys(atualizacoes[0].payload).length, 1, 'só o CNPJ mudou, não deveria mandar outros campos junto');
});

test('csvParaAtualizacoes: linha reexportada sem edição nenhuma não gera atualização', async () => {
  const { leadsParaCSV, parseCSV, csvParaAtualizacoes } = await carregarModulo();
  const leadsAtuais = [{ id: '1', empresa: 'Construtora A', cnpj: 'já tinha', anos_mercado: '10 anos', setor: 'Construção', sinal_porte_medio_grande: true }];
  const csv = leadsParaCSV(leadsAtuais);
  const atualizacoes = csvParaAtualizacoes(parseCSV(csv), leadsAtuais);
  assert.equal(atualizacoes.length, 0);
});

test('csvParaAtualizacoes: detecta mudança de porte (texto "Sim"/"Não" → booleano)', async () => {
  const { parseCSV, csvParaAtualizacoes, COLUNAS_CSV } = await carregarModulo();
  const leadsAtuais = [{ id: '1', empresa: 'X', sinal_porte_medio_grande: false }];
  const csv = [COLUNAS_CSV.join(','), '1,X,,,,,,,,Sim,,,,,'].join('\r\n');
  const atualizacoes = csvParaAtualizacoes(parseCSV(csv), leadsAtuais);
  assert.equal(atualizacoes.length, 1);
  assert.equal(atualizacoes[0].payload.sinalPorteMedioGrande, true);
});

test('csvParaAtualizacoes: linha com id que não existe mais é ignorada silenciosamente', async () => {
  const { parseCSV, csvParaAtualizacoes, COLUNAS_CSV } = await carregarModulo();
  const csv = [COLUNAS_CSV.join(','), 'id-nao-existe,X,12345,,,,,,,,,,,,'].join('\r\n');
  const atualizacoes = csvParaAtualizacoes(parseCSV(csv), []);
  assert.equal(atualizacoes.length, 0);
});

test('csvParaAtualizacoes: CSV sem coluna "id" lança erro claro', async () => {
  const { csvParaAtualizacoes } = await carregarModulo();
  assert.throws(() => csvParaAtualizacoes([['empresa', 'cnpj'], ['X', '123']], []), /coluna "id" não encontrada/);
});
