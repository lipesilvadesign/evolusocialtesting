const test = require('node:test');
const assert = require('node:assert/strict');

const MODULE_PATH = require.resolve('../netlify/functions/_lib/integrations/geoapify.js');
function carregarModuloFresco() {
  delete require.cache[MODULE_PATH];
  return require(MODULE_PATH);
}

// Formato de resposta simulado a partir da documentação oficial do Geoapify
// (GeoJSON FeatureCollection, properties com name/address_line1/address_line2/contact/website/place_id).
function featureSimulada(overrides) {
  return {
    type: 'Feature',
    properties: {
      name: 'Construtora Simulada Ltda',
      address_line1: 'Construtora Simulada Ltda',
      address_line2: 'Av. Central, 100, Petrolina, PE, Brasil',
      city: 'Petrolina',
      contact: { phone: '+55 87 99999-0000' },
      website: 'https://construtorasimulada.com.br',
      place_id: '51abc123def',
      categories: ['commercial', 'commercial.construction'],
      ...overrides,
    },
    geometry: { type: 'Point', coordinates: [-40.5, -9.38] },
  };
}

test('CATEGORIAS_NEGOCIO: NÃO inclui "building" (maioria sem nome no OSM, lota o limite de resultados e esconde negócios de verdade)', () => {
  const geo = carregarModuloFresco();
  assert.ok(!geo.CATEGORIAS_NEGOCIO.split(',').some((c) => c === 'building' || c.startsWith('building.')), `CATEGORIAS_NEGOCIO não deveria conter "building": ${geo.CATEGORIAS_NEGOCIO}`);
});

test('CATEGORIAS_NEGOCIO: cada categoria usada é uma categoria-topo real da documentação oficial (evita repetir o erro de "building.retail" inválido)', () => {
  const geo = carregarModuloFresco();
  // Lista de categorias-TOPO confirmadas em https://apidocs.geoapify.com/docs/places/#categories
  // (24/lista real, não exaustiva — só as que aparecem documentadas como chave de topo).
  const CATEGORIAS_TOPO_VALIDAS = new Set([
    'accommodation', 'activity', 'airport', 'commercial', 'catering', 'emergency', 'education',
    'childcare', 'entertainment', 'healthcare', 'heritage', 'highway', 'leisure', 'man_made',
    'maritime', 'waterway', 'natural', 'national_park', 'office', 'parking', 'pet', 'power',
    'production', 'railway', 'rental', 'service', 'tourism', 'religion', 'camping', 'amenity',
    'beach', 'adult', 'building', 'ski', 'sport', 'public_transport', 'administrative',
    'postal_code', 'political', 'low_emission_zone', 'populated_place', 'memorial',
  ]);
  const usadas = geo.CATEGORIAS_NEGOCIO.split(',');
  usadas.forEach((cat) => {
    // Uma categoria pode ser um top-level ("commercial") ou ter subchave ("commercial.supermarket") —
    // aqui só validamos que o TOP-LEVEL de cada uma está na lista confirmada.
    const topo = cat.split('.')[0];
    assert.ok(CATEGORIAS_TOPO_VALIDAS.has(topo), `categoria "${cat}" usa um top-level ("${topo}") que não está confirmado na documentação`);
  });
});

test('buscarEmpresasGeoapify: monta a URL certa (categorias amplas + circle + apiKey)', async () => {
  const geo = carregarModuloFresco();
  let urlChamada = null;
  global.fetch = async (url) => {
    urlChamada = url;
    return { ok: true, json: async () => ({ features: [] }) };
  };
  await geo.buscarEmpresasGeoapify('construtora', -9.38, -40.5, 'CHAVE_TESTE');

  assert.match(urlChamada, /^https:\/\/api\.geoapify\.com\/v2\/places\?categories=/);
  assert.match(urlChamada, /categories=commercial,office,production,education,accommodation,service,healthcare(?!,building)/);
  assert.match(urlChamada, /filter=circle:-40\.5,-9\.38,15000/);
  assert.match(urlChamada, /limit=500/);
  assert.match(urlChamada, /apiKey=CHAVE_TESTE/);
});

test('buscarEmpresasGeoapify: filtra localmente por nome conter o ramo digitado', async () => {
  const geo = carregarModuloFresco();
  global.fetch = async () => ({
    ok: true,
    json: async () => ({
      features: [
        featureSimulada({ name: 'Construtora Simulada Ltda', place_id: '1' }),
        featureSimulada({ name: 'Padaria do Zé', place_id: '2' }),
        featureSimulada({ name: 'Construções Silva', place_id: '3' }),
      ],
    }),
  });
  const resultado = await geo.buscarEmpresasGeoapify('construtora', -9.38, -40.5, 'CHAVE');
  assert.equal(resultado.length, 2, 'deveria manter só os 2 que batem com "constru" (Construtora / Construções), excluir a padaria');
  assert.ok(resultado.every((f) => f.properties.place_id !== '2'));
});

test('buscarEmpresasGeoapify: ramo vazio devolve tudo sem filtrar', async () => {
  const geo = carregarModuloFresco();
  global.fetch = async () => ({ ok: true, json: async () => ({ features: [featureSimulada({}), featureSimulada({ place_id: '2', name: 'Outra Qualquer' })] }) });
  const resultado = await geo.buscarEmpresasGeoapify('', -9.38, -40.5, 'CHAVE');
  assert.equal(resultado.length, 2);
});

test('buscarEmpresasGeoapify: 401 (chave inválida) lança erro claro e identificável', async () => {
  const geo = carregarModuloFresco();
  global.fetch = async () => ({ ok: false, status: 401, text: async () => '{"message":"Invalid API key"}' });
  await assert.rejects(
    () => geo.buscarEmpresasGeoapify('construtora', -9.38, -40.5, 'CHAVE_ERRADA'),
    /401.*chave de API inválida/
  );
});

test('buscarEmpresasGeoapify: 429 (limite de créditos) lança erro claro e identificável', async () => {
  const geo = carregarModuloFresco();
  global.fetch = async () => ({ ok: false, status: 429, text: async () => 'Daily quota exceeded' });
  await assert.rejects(
    () => geo.buscarEmpresasGeoapify('construtora', -9.38, -40.5, 'CHAVE'),
    /429.*limite diário de créditos/
  );
});

test('buscarEmpresasGeoapify: sem apiKey nem tenta a rede, erro imediato', async () => {
  const geo = carregarModuloFresco();
  let chamouFetch = false;
  global.fetch = async () => { chamouFetch = true; return { ok: true, json: async () => ({ features: [] }) }; };
  await assert.rejects(() => geo.buscarEmpresasGeoapify('construtora', -9.38, -40.5, ''), /GEOAPIFY_API_KEY não configurada/);
  assert.equal(chamouFetch, false);
});

test('buscarEmpresasGeoapify: resposta 200 mas sem "features" válido é tratada como erro', async () => {
  const geo = carregarModuloFresco();
  global.fetch = async () => ({ ok: true, json: async () => ({ nao_tem_features: true }) });
  await assert.rejects(() => geo.buscarEmpresasGeoapify('construtora', -9.38, -40.5, 'CHAVE'), /resposta inválida/);
});

test('buscarEmpresasGeoapify: timeout é tratado como falha de rede clara', async () => {
  process.env.GEOAPIFY_TIMEOUT_MS = '150';
  const geo = carregarModuloFresco();
  global.fetch = (url, opts) => new Promise((_resolve, reject) => {
    opts.signal.addEventListener('abort', () => {
      const err = new Error('aborted');
      err.name = 'AbortError';
      reject(err);
    });
  });
  await assert.rejects(() => geo.buscarEmpresasGeoapify('construtora', -9.38, -40.5, 'CHAVE'), /timeout/);
  delete process.env.GEOAPIFY_TIMEOUT_MS;
});

test('featureToLead: converte corretamente nome/telefone/endereço/site', () => {
  const geo = carregarModuloFresco();
  const lead = geo.featureToLead(featureSimulada({}), 'Petrolina, PE', 'Construtora');
  assert.equal(lead.empresa, 'Construtora Simulada Ltda');
  assert.equal(lead.telefone, '+55 87 99999-0000');
  assert.equal(lead.site, 'https://construtorasimulada.com.br');
  assert.equal(lead.cidade, 'Petrolina');
  assert.equal(lead.origemId, 'geoapify:51abc123def');
  assert.equal(lead.prioridade, 'media', 'tem site → prioridade média');
  assert.equal(
    lead.endereco,
    'Av. Central, 100, Petrolina, PE, Brasil',
    'endereco deve ser o address_line2 (endereço de verdade), NÃO repetir o nome da empresa (address_line1)'
  );
  assert.ok(!lead.endereco.includes('Construtora Simulada'), 'endereco não pode conter o nome da empresa duplicado');
});

test('featureToLead: sem address_line2, cai pro "formatted"; sem nenhum dos dois, cai pro address_line1', () => {
  const geo = carregarModuloFresco();
  const semAddress2 = geo.featureToLead(
    featureSimulada({ address_line2: undefined, formatted: 'Endereço formatado completo, Petrolina, PE', place_id: 'x1' }),
    'Petrolina, PE',
    'Construtora'
  );
  assert.equal(semAddress2.endereco, 'Endereço formatado completo, Petrolina, PE');

  const semNenhum = geo.featureToLead(
    featureSimulada({ address_line2: undefined, formatted: undefined, address_line1: 'Único dado disponível', place_id: 'x2' }),
    'Petrolina, PE',
    'Construtora'
  );
  assert.equal(semNenhum.endereco, 'Único dado disponível');
});

test('featureToLead: sem site → prioridade alta (critério real de presença online fraca)', () => {
  const geo = carregarModuloFresco();
  const lead = geo.featureToLead(featureSimulada({ website: undefined, place_id: '99' }), 'Petrolina, PE', 'Construtora');
  assert.equal(lead.prioridade, 'alta');
});

test('featureToLead: sem name ou sem place_id retorna null (não insere lixo)', () => {
  const geo = carregarModuloFresco();
  assert.equal(geo.featureToLead(featureSimulada({ name: undefined }), 'Petrolina, PE', 'x'), null);
  assert.equal(geo.featureToLead(featureSimulada({ place_id: undefined }), 'Petrolina, PE', 'x'), null);
});

test('featureToLead: embute fonte="geoapify_manual" (busca combina Geoapify + OSM na mesma chamada, precisa saber de onde veio cada lead)', () => {
  const geo = carregarModuloFresco();
  const lead = geo.featureToLead(featureSimulada({}), 'Petrolina, PE', 'Construtora');
  assert.equal(lead.fonte, 'geoapify_manual');
});
