const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

/**
 * Regressão crítica: getCurrentUser() passou a pedir foto_url (coluna nova,
 * SQL_PENDENTE_ponto_metas.sql) além de role/ativo/nome. Se essa migração
 * ainda não tiver rodado em produção, um select com uma coluna inexistente
 * faz o PostgREST recusar a consulta INTEIRA (400) — sem fallback, isso
 * derrubaria login de TODO MUNDO (mesmo efeito do bug "Acesso não
 * configurado" já visto neste projeto), só por causa de uma coluna
 * cosmética de foto. Este teste garante que, quando a consulta COM
 * foto_url falha, o código tenta de novo SEM foto_url antes de desistir —
 * nunca desiste na primeira tentativa.
 *
 * Roda em Node puro: stub de window.supabase e fetch (auth.js só toca
 * esses globais dentro de função, nunca no top-level do módulo).
 */

function stubSupabaseClient({ userId, email }) {
  return {
    createClient: () => ({
      auth: {
        getSession: async () => ({
          data: { session: { access_token: 'fake-token', user: { id: userId, email } } },
          error: null,
        }),
      },
    }),
  };
}

async function carregarAuth() {
  const url = 'file://' + path.resolve(__dirname, '../painel/assets/js/services/auth.js');
  // cache-bust: cada teste registra um window.supabase/fetch diferente, e o
  // client interno de auth.js é memorizado (`let client`) na primeira
  // chamada de getClient() — importar com querystring força um módulo novo.
  return import(url + `?t=${Date.now()}${Math.random()}`);
}

test('getCurrentUser: se o select com foto_url falhar (coluna ainda não existe), tenta de novo sem foto_url e mantém o acesso', async () => {
  const originalWindow = global.window;
  const originalFetch = global.fetch;
  const chamadas = [];

  global.window = { supabase: stubSupabaseClient({ userId: 'u1', email: 'admin@felipebranding.com.br' }) };
  global.fetch = async (url) => {
    chamadas.push(url);
    if (String(url).includes('foto_url')) {
      return { ok: false, status: 400 }; // coluna não existe ainda em produção
    }
    return { ok: true, json: async () => [{ role: 'admin', ativo: true, nome: 'Felipe' }] };
  };

  try {
    const { getCurrentUser } = await carregarAuth();
    const user = await getCurrentUser();
    assert.equal(user.role, 'admin', 'Precisa continuar dando acesso mesmo sem a coluna foto_url existir ainda.');
    assert.equal(user.nome, 'Felipe');
    assert.equal(user.fotoUrl, null);
    assert.equal(chamadas.length, 2, 'Esperava 2 tentativas: uma com foto_url (falha) e uma sem (sucesso).');
  } finally {
    global.window = originalWindow;
    global.fetch = originalFetch;
  }
});

test('getCurrentUser: quando o select com foto_url funciona, usa a foto normalmente (sem tentativa extra)', async () => {
  const originalWindow = global.window;
  const originalFetch = global.fetch;
  const chamadas = [];

  global.window = { supabase: stubSupabaseClient({ userId: 'u2', email: 'design@felipebranding.com.br' }) };
  global.fetch = async (url) => {
    chamadas.push(url);
    return { ok: true, json: async () => [{ role: 'design', ativo: true, nome: 'Ana', foto_url: 'https://exemplo.com/ana.jpg' }] };
  };

  try {
    const { getCurrentUser } = await carregarAuth();
    const user = await getCurrentUser();
    assert.equal(user.role, 'design');
    assert.equal(user.fotoUrl, 'https://exemplo.com/ana.jpg');
    assert.equal(chamadas.length, 1);
  } finally {
    global.window = originalWindow;
    global.fetch = originalFetch;
  }
});

test('getCurrentUser: se AMBAS as tentativas falharem, cai pra sem_acesso (mesmo comportamento de antes) em vez de travar', async () => {
  const originalWindow = global.window;
  const originalFetch = global.fetch;

  global.window = { supabase: stubSupabaseClient({ userId: 'u3', email: 'novo@felipebranding.com.br' }) };
  global.fetch = async () => ({ ok: false, status: 500 });

  try {
    const { getCurrentUser } = await carregarAuth();
    const user = await getCurrentUser();
    assert.equal(user.role, 'sem_acesso');
  } finally {
    global.window = originalWindow;
    global.fetch = originalFetch;
  }
});
