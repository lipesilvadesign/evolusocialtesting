const assert = require('assert');
const R = require('../evoluisocial/app/referencias.js');
(async () => {
  let calls = 0;
  const p = R.provedorPinterest(async function (acao, d) {
    calls++;
    assert.equal(arguments.length, 2);
    assert.equal(acao, 'buscar_referencias_pinterest');
    assert.equal(d.consulta, 'barbearia premium');
    return { itens: [{ url:'https://br.pinterest.com/search/pins/?q=barbearia%20premium', id_externo:'trend:barbearia premium', titulo:'barbearia premium', autor:'Pinterest Trends', crescimento_wow:120, porque:'Sinal de crescimento' }] };
  }, true);
  assert.equal(p.ativo(), true);
  const itens = await p.buscar({texto:'barbearia premium', termos:['barbearia','premium']}, {maxItens:6});
  assert.equal(calls, 1);
  assert.equal(itens.length, 1);
  assert.equal(itens[0].fonte, 'pinterest');
  assert.equal(itens[0].crescimento_wow, 120);
  const ran = R.ranquear(itens, {termos:['barbearia','premium']}, []);
  assert.ok(ran[0].score >= 80);
  console.log('pinterestReferencias.test.js: 1/1 OK');
})();
