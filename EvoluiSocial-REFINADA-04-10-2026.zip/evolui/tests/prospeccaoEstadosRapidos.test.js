const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

/**
 * Testa a reformulação de "ações rápidas" da Prospecção (WhatsApp com
 * registro automático + botões de estado rápido). O foco aqui é garantir
 * que o modelo de estados do FRONTEND (painel/assets/js/views/prospeccao.js)
 * nunca desalinhe do que o BACKEND aceita
 * (netlify/functions/_lib/services/prospeccaoService.js) — o mesmo tipo de
 * problema que a auditoria encontrou entre atividadesService.js e a
 * migração do banco (tipos aceitos no código, mas não na constraint do
 * Postgres). Roda em Node puro (sem DOM) — nenhum dos módulos importados
 * toca `document`/`window` no nível superior, só dentro de funções.
 */

async function carregarProspeccaoView() {
  const url = 'file://' + path.resolve(__dirname, '../painel/assets/js/views/prospeccao.js');
  return import(url);
}

function carregarProspeccaoService() {
  return require('../netlify/functions/_lib/services/prospeccaoService.js');
}

function carregarAtividadesService() {
  return require('../netlify/functions/_lib/services/atividadesService.js');
}

test('toda ação rápida (ACOES_RAPIDAS) que muda status usa um valor aceito pelo backend (VALID_STATUS)', async () => {
  const { ACOES_RAPIDAS } = await carregarProspeccaoView();
  const { VALID_STATUS } = carregarProspeccaoService();
  ACOES_RAPIDAS.forEach((acao) => {
    if (acao.status) {
      assert.ok(VALID_STATUS.has(acao.status), `Ação "${acao.id}" usa status "${acao.status}", que o backend não aceita.`);
    }
  });
});

test('toda ação rápida usa um tipo de atividade aceito pelo backend (TIPOS_VALIDOS)', async () => {
  const { ACOES_RAPIDAS } = await carregarProspeccaoView();
  const { TIPOS_VALIDOS } = carregarAtividadesService();
  ACOES_RAPIDAS.forEach((acao) => {
    assert.ok(TIPOS_VALIDOS.includes(acao.tipoAtividade), `Ação "${acao.id}" usa tipo de atividade "${acao.tipoAtividade}", que o backend não aceita.`);
  });
});

test('o registro automático de WhatsApp usa "whatsapp_enviado", que já existe e não depende da migração pendente', async () => {
  const { TIPOS_VALIDOS } = carregarAtividadesService();
  assert.ok(TIPOS_VALIDOS.includes('whatsapp_enviado'));
});

test('STATUS_MAP (rótulos exibidos) cobre exatamente os mesmos valores que VALID_STATUS do backend — nenhum a mais, nenhum a menos', async () => {
  const { STATUS_MAP } = await carregarProspeccaoView();
  const { VALID_STATUS } = carregarProspeccaoService();
  const doFrontend = new Set(Object.keys(STATUS_MAP));
  const doBackend = VALID_STATUS;
  assert.deepEqual([...doFrontend].sort(), [...doBackend].sort());
});

test('NAO_TERMINAIS só contém estágios que existem em STATUS_MAP, e exclui os dois terminais', async () => {
  const { STATUS_MAP, NAO_TERMINAIS } = await carregarProspeccaoView();
  NAO_TERMINAIS.forEach((s) => assert.ok(STATUS_MAP[s], `"${s}" não existe em STATUS_MAP`));
  assert.ok(!NAO_TERMINAIS.includes('cliente'));
  assert.ok(!NAO_TERMINAIS.includes('nao_convertido'));
});

test('diasSemAtividade: calcula corretamente a partir de ultima_atividade_em', async () => {
  const { diasSemAtividade } = await carregarProspeccaoView();
  const cincoDiasAtras = new Date(Date.now() - 5 * 86400000).toISOString();
  const dias = diasSemAtividade({ ultima_atividade_em: cincoDiasAtras });
  assert.equal(dias, 5);
});

test('diasSemAtividade: usa created_at como fallback quando não há atividade ainda', async () => {
  const { diasSemAtividade } = await carregarProspeccaoView();
  const doisDiasAtras = new Date(Date.now() - 2 * 86400000).toISOString();
  const dias = diasSemAtividade({ created_at: doisDiasAtras, ultima_atividade_em: null });
  assert.equal(dias, 2);
});

test('diasSemAtividade: retorna null quando não há nenhuma data de referência (nunca inventa um número)', async () => {
  const { diasSemAtividade } = await carregarProspeccaoView();
  assert.equal(diasSemAtividade({}), null);
});
