const test = require('node:test');
const assert = require('node:assert/strict');
const contratosService = require('../netlify/functions/_lib/services/financeiroContratosService');
const parcelasService = require('../netlify/functions/_lib/services/financeiroParcelasService');
const despesasService = require('../netlify/functions/_lib/services/financeiroDespesasService');

function comFetchMock(fn) {
  return async () => {
    const originalFetch = globalThis.fetch;
    try {
      await fn();
    } finally {
      globalThis.fetch = originalFetch;
    }
  };
}

// ---- Validação (nunca chega a bater na rede com dado inválido) ----

test('contratos.create: rejeita sem leadId — contrato tem que estar ligado a um cliente do CRM', comFetchMock(async () => {
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  await assert.rejects(
    () => contratosService.create('token', { servico: 'branding', valorTotal: 100, criadoPor: 'a@a.com' }),
    /cliente/
  );
}));

test('contratos.create: rejeita valor total zero ou negativo', comFetchMock(async () => {
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  await assert.rejects(
    () => contratosService.create('token', { leadId: 'l1', servico: 'branding', valorTotal: 0, criadoPor: 'a@a.com' }),
    /maior que zero/
  );
}));

test('contratos.create: rejeita serviço fora da lista fixa (evita "categoria inventada" digitada errado)', comFetchMock(async () => {
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  await assert.rejects(
    () => contratosService.create('token', { leadId: 'l1', servico: 'consultoria_generica', valorTotal: 100, criadoPor: 'a@a.com' }),
    /Serviço inválido/
  );
}));

test('despesas.create: rejeita categoria fora do vocabulário real da agência', comFetchMock(async () => {
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  await assert.rejects(
    () => despesasService.create('token', { categoria: 'viagem_generica', descricao: 'x', valor: 10, vencimento: '2026-01-01', criadoPor: 'a@a.com' }),
    /Categoria inválida/
  );
}));

// ---- Rateio de parcelas — é aqui que erro de centavos costuma aparecer ----

test('parcelasService.gerarParaContrato: soma das parcelas bate EXATAMENTE com o valor total (sem sobrar/faltar centavo)', comFetchMock(async () => {
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => corpoEnviado };
  };
  // 1000,00 em 3 parcelas — divisão exata seria 333,333... (dízima); o
  // rateio tem que absorver a sobra na última parcela, nunca perder centavo.
  const contrato = { id: 'c1', valor_total: 1000, data_inicio: '2026-01-15', numero_parcelas: 3 };
  await parcelasService.gerarParaContrato('token', contrato);
  const soma = corpoEnviado.reduce((s, p) => s + p.valor, 0);
  assert.equal(Math.round(soma * 100), 100000, 'soma das parcelas tem que bater 1000,00 exatamente (em centavos, pra evitar erro de ponto flutuante)');
  assert.equal(corpoEnviado.length, 3);
  assert.equal(corpoEnviado[0].numero, 1);
  assert.equal(corpoEnviado[2].numero, 3);
}));

test('parcelasService.gerarParaContrato: vencimentos mensais a partir da data de início', comFetchMock(async () => {
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => corpoEnviado };
  };
  const contrato = { id: 'c1', valor_total: 300, data_inicio: '2026-01-15', numero_parcelas: 3 };
  await parcelasService.gerarParaContrato('token', contrato);
  assert.equal(corpoEnviado[0].vencimento, '2026-01-15');
  assert.equal(corpoEnviado[1].vencimento, '2026-02-15');
  assert.equal(corpoEnviado[2].vencimento, '2026-03-15');
}));

test('adicionarMesesCravando: contrato iniciado no dia 31 "crava" no último dia dos meses mais curtos, em vez de estourar pro mês seguinte', () => {
  const { adicionarMesesCravando } = parcelasService;
  const base = new Date(2026, 0, 31, 12, 0, 0); // 31/01/2026
  const fmt = (d) => d.toISOString().slice(0, 10);
  assert.equal(fmt(adicionarMesesCravando(base, 0)), '2026-01-31');
  // Sem a correção, isto virava 2026-03-03 (estourava fevereiro inteiro).
  assert.equal(fmt(adicionarMesesCravando(base, 1)), '2026-02-28', 'fevereiro/2026 (não bissexto) tem 28 dias');
  assert.equal(fmt(adicionarMesesCravando(base, 2)), '2026-03-31');
  assert.equal(fmt(adicionarMesesCravando(base, 3)), '2026-04-30', 'abril tem 30 dias');
});

test('parcelasService.gerarParaContrato: contrato de parcela única gera 1 parcela com o valor cheio', comFetchMock(async () => {
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => corpoEnviado };
  };
  const contrato = { id: 'c1', valor_total: 4500.5, data_inicio: '2026-01-01', numero_parcelas: 1 };
  await parcelasService.gerarParaContrato('token', contrato);
  assert.equal(corpoEnviado.length, 1);
  assert.equal(corpoEnviado[0].valor, 4500.5);
}));

test('parcelasService.updateStatus: marcar como pago preenche pago_em (hoje, se não informado)', comFetchMock(async () => {
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => ([{ id: 'p1', ...corpoEnviado }]) };
  };
  await parcelasService.updateStatus('token', 'p1', { status: 'pago' });
  assert.ok(corpoEnviado.pago_em, 'pago_em precisa ser preenchido automaticamente');
}));

test('parcelasService.updateStatus: voltar de "pago" pra outro status limpa pago_em/valor_pago (evita registro pago fantasma)', comFetchMock(async () => {
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => ([{ id: 'p1', ...corpoEnviado }]) };
  };
  await parcelasService.updateStatus('token', 'p1', { status: 'previsto' });
  assert.equal(corpoEnviado.pago_em, null);
  assert.equal(corpoEnviado.valor_pago, null);
}));

test('parcelasService.updateStatus: rejeita status fora da lista', comFetchMock(async () => {
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  await assert.rejects(() => parcelasService.updateStatus('token', 'p1', { status: 'quitado' }), /Status inválido/);
}));
