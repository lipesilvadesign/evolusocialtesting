const test = require('node:test');
const assert = require('node:assert/strict');

const { gerarDiagnostico, SEGMENTOS, OBJETIVOS, MOTOR_VERSAO } = require('../netlify/functions/_lib/diagnosticoEngine');

const DADOS_BASE = { nome: 'Ana Teste', instagram: '@ana.teste', segmento: 'beleza_estetica', objetivo: 'gerar_vendas' };

test('gerarDiagnostico: contrato básico continua presente (não regride o painel/consultorias.js)', () => {
  const r = gerarDiagnostico(DADOS_BASE);
  assert.equal(r.motorVersao, MOTOR_VERSAO);
  assert.equal(typeof r.geradoEm, 'string');
  assert.equal(typeof r.resumo, 'string');
  assert.ok(r.resumo.length > 0);
  assert.equal(r.categorias.length, 5);
  assert.ok(Array.isArray(r.pontosFortes));
  assert.ok(Array.isArray(r.pontosDeAtencao));
  assert.ok(Array.isArray(r.oportunidades));
  assert.ok(Array.isArray(r.proximasAcoes));
  assert.equal(typeof r.ctaTexto, 'string');
});

test('gerarDiagnostico: cada categoria traz entre 5 e 7 dicas práticas, todas com texto', () => {
  const r = gerarDiagnostico(DADOS_BASE);
  r.categorias.forEach((cat) => {
    assert.ok(Array.isArray(cat.dicasPraticas), `categoria ${cat.chave} sem array de dicasPraticas`);
    assert.ok(
      cat.dicasPraticas.length >= 5 && cat.dicasPraticas.length <= 7,
      `categoria ${cat.chave} tem ${cat.dicasPraticas.length} dicas (esperado 5 a 7)`
    );
    cat.dicasPraticas.forEach((dica) => {
      assert.equal(typeof dica, 'string');
      assert.ok(dica.trim().length > 10, `dica vazia/curta demais em ${cat.chave}: "${dica}"`);
    });
  });
});

test('gerarDiagnostico: dicas de uma categoria não se repetem entre si', () => {
  const r = gerarDiagnostico(DADOS_BASE);
  r.categorias.forEach((cat) => {
    const unicas = new Set(cat.dicasPraticas);
    assert.equal(unicas.size, cat.dicasPraticas.length, `dica repetida na categoria ${cat.chave}`);
  });
});

test('gerarDiagnostico: é determinístico — mesma entrada gera exatamente o mesmo resultado (exceto geradoEm)', () => {
  const r1 = gerarDiagnostico(DADOS_BASE);
  const r2 = gerarDiagnostico(DADOS_BASE);
  delete r1.geradoEm;
  delete r2.geradoEm;
  assert.deepEqual(r1, r2);
});

test('gerarDiagnostico: entradas diferentes tendem a variar a quantidade/conteúdo das dicas (não é sempre a mesma lista fixa)', () => {
  const r1 = gerarDiagnostico(DADOS_BASE);
  const r2 = gerarDiagnostico({ nome: 'Carlos', instagram: '@outra.marca', segmento: 'tecnologia', objetivo: 'fortalecer_autoridade' });
  const dicas1 = r1.categorias.map((c) => c.dicasPraticas.join('|')).join('||');
  const dicas2 = r2.categorias.map((c) => c.dicasPraticas.join('|')).join('||');
  assert.notEqual(dicas1, dicas2);
});

test('gerarDiagnostico: segmento e objetivo desconhecidos não quebram o motor (cai no fallback "outro")', () => {
  assert.doesNotThrow(() => {
    const r = gerarDiagnostico({ nome: '', instagram: '', segmento: 'nao_existe', objetivo: 'nao_existe' });
    r.categorias.forEach((cat) => assert.ok(cat.dicasPraticas.length >= 5));
  });
});

test('SEGMENTOS e OBJETIVOS: todo segmento/objetivo cadastrado tem banco de dicas cobrindo as 5 categorias', () => {
  const chavesSegmento = Object.keys(SEGMENTOS);
  const chavesObjetivo = Object.keys(OBJETIVOS);
  // amostra alguns cruzamentos (todos seria O(n*m), não é necessário) pra garantir que
  // nenhuma combinação real usada no formulário público derruba o motor.
  chavesSegmento.forEach((segmento, i) => {
    const objetivo = chavesObjetivo[i % chavesObjetivo.length];
    const r = gerarDiagnostico({ nome: 'Teste', instagram: '@teste', segmento, objetivo });
    assert.equal(r.categorias.length, 5);
    r.categorias.forEach((cat) => {
      assert.ok(cat.dicasPraticas.length >= 5 && cat.dicasPraticas.length <= 7);
    });
  });
});
