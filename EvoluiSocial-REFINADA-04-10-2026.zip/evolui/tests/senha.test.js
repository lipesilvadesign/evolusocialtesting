const test = require('node:test');
const assert = require('node:assert/strict');
const { gerarSenhaTemporaria } = require('../netlify/functions/_lib/util/senha');

test('gerarSenhaTemporaria: sempre gera 12 caracteres', () => {
  for (let i = 0; i < 20; i++) {
    assert.equal(gerarSenhaTemporaria().length, 12);
  }
});

test('gerarSenhaTemporaria: só usa o alfabeto esperado (sem caracteres ambíguos tipo 0/O/1/I/l)', () => {
  const alfabetoPermitido = /^[ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%]+$/;
  for (let i = 0; i < 20; i++) {
    assert.match(gerarSenhaTemporaria(), alfabetoPermitido);
  }
});

test('gerarSenhaTemporaria: não repete a mesma senha em chamadas seguidas (usa crypto, não é fixo)', () => {
  const senhas = new Set();
  for (let i = 0; i < 30; i++) senhas.add(gerarSenhaTemporaria());
  assert.ok(senhas.size > 25, 'senhas geradas deveriam ser (quase sempre) distintas entre si');
});
