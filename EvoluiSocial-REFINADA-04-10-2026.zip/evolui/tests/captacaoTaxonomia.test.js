const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const t = require('../netlify/functions/_lib/captacao/taxonomia');
const n = require('../netlify/functions/_lib/captacao/normalizar');

const mig = (f) => fs.readFileSync(path.join(__dirname, '..', 'migrations', f), 'utf8');
const listaSql = (sql, marcador) => {
  const i = sql.indexOf(marcador);
  assert.ok(i >= 0, `marcador não encontrado: ${marcador}`);
  const ini = sql.indexOf('(', i + marcador.length);
  const fim = sql.indexOf(')', ini);
  return [...sql.slice(ini, fim).matchAll(/'([^']+)'/g)].map((m) => m[1]);
};

test('paridade JS ↔ SQL: fontes, métodos, status de job e da captura, oportunidades, motivos', () => {
  const m2 = mig('002_taxonomia.sql');
  assert.deepEqual(listaSql(m2, "admin_prospeccao_leads_fonte_check check (fonte in").slice(0, t.FONTES.length), t.FONTES);
  assert.deepEqual(listaSql(m2, "admin_prospeccao_leads_metodo_check check (metodo_captacao is null or metodo_captacao in"), t.METODOS);
  assert.deepEqual(listaSql(mig('005_capture_jobs.sql'), "admin_prospeccao_buscas_status_check\n  check (status in"), t.STATUS_JOB);
  assert.deepEqual(listaSql(mig('006_capture_raw.sql'), "status text not null default 'pendente'\n    check (status in"), t.STATUS_CAPTURA);
  // 011 recria a CHECK de tipos (superconjunto de 007) — a fonte vigente é a 011
  // a fonte vigente da CHECK de tipos é a migration mais recente que a recria (013)
  const m11 = mig('013_fase3_operacao.sql');
  const i11 = m11.indexOf('admin_prospeccao_oportunidades_tipo_check check (tipo = any (array[');
  const tipos011 = [...m11.slice(i11, m11.indexOf(']', i11)).matchAll(/'([^']+)'/g)].map((x) => x[1]);
  assert.deepEqual(tipos011.sort(), Object.keys(t.OPORTUNIDADES).sort());
  for (const x of listaSql(mig('007_oportunidades.sql'), 'tipo text not null check (tipo in')) assert.ok(tipos011.includes(x), `011 não pode remover ${x}`);
  assert.deepEqual(listaSql(mig('001_arquivamento.sql'), 'motivo_arquivamento is null or motivo_arquivamento in'), t.MOTIVOS_ARQUIVAMENTO);
  for (const legado of Object.keys(t.FONTES_LEGADAS)) assert.match(m2, new RegExp(`'${legado}'`));
});

test('paridade JS ↔ SQL: setores estratégicos, cidades da região (com DDD) e temperatura', () => {
  const m3 = mig('003_normalizacao.sql');
  const m8 = mig('008_score_temperatura.sql');
  const estrategicosSql = [...m8.slice(m8.indexOf('select array['), m8.indexOf(']', m8.indexOf('select array['))).matchAll(/'([^']+)'/g)].map((x) => x[1]);
  assert.deepEqual(estrategicosSql, t.SETORES.filter((s) => s.estrategico).map((s) => s.id));
  const regiao = [...m3.slice(m3.indexOf('values (\'petrolina\''), m3.indexOf('$$;', m3.indexOf('values (\'petrolina\''))).matchAll(/\('([^']+)','([A-Z]{2})','(\d{2})'\)/g)];
  assert.deepEqual(regiao.map((r) => [r[1], r[2], r[3]]), t.CIDADES_REGIAO.map((c) => [t.semAcento(c.cidade), c.uf, c.ddd]));
  const T = t.TEMPERATURA;
  for (const d of [T.quenteDiasInteracao, T.quenteDiasInbound, T.mornoDiasInteracao, T.mornoDiasInbound, T.mornoDiasRespondeu]) assert.match(m8, new RegExp(`interval '${d} days'`));
  assert.match(m8, new RegExp(T.atividadesDoLead.map((a) => `'${a}'`).join(',')));
  assert.ok(!T.atividadesDoLead.includes('whatsapp_enviado') && !T.atividadesDoLead.includes('email_enviado'), 'ação da equipe não aquece');
});

test('taxonomia: toda categoria Geoapify do setor é de uma família documentada; faixas de score', () => {
  const familias = ['accommodation', 'activity', 'commercial', 'catering', 'education', 'childcare', 'healthcare', 'office', 'production', 'rental', 'service'];
  for (const s of t.SETORES) for (const c of [...s.geoapify.especificas, ...s.geoapify.genericas]) assert.ok(familias.includes(c.split('.')[0]), `${s.id}: ${c}`);
  assert.equal(t.faixaScore(95).chave, 'prioritario');
  assert.equal(t.faixaScore(91).chave, 'prioritario');
  assert.equal(t.faixaScore(90).chave, 'prospectar');
  assert.equal(t.faixaScore(61).chave, 'prospectar');
  assert.equal(t.faixaScore(60).chave, 'nutrir');
  assert.equal(t.faixaScore(30).chave, 'aguardar');
  assert.equal(t.direcao('formulario'), 'inbound');
  assert.equal(t.direcao('pesquisa_local'), 'outbound');
});

// Paridade da normalização JS × SQL no Postgres local do robô (pula se não houver).
const PG = { PGHOST: process.env.PGHOST || '/var/tmp/pgaudit', PGPORT: process.env.PGPORT || '5499', PGUSER: process.env.PGUSER || 'postgres' };
function psql(sql) {
  return execFileSync('psql', ['-X', '-At', '-d', process.env.PGDB || 'robo_rls_teste', '-c', sql], { env: { ...process.env, ...PG }, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
}
let temPg = false;
try { temPg = psql("select to_regprocedure('public.prospeccao_norm_telefone(text,text)') is not null") === 't'; } catch { temPg = false; }

test('paridade da normalização JS × SQL (Postgres local)', { skip: !temPg && 'Postgres local com as migrations não disponível' }, () => {
  const esc = (v) => (v === null ? 'null' : `'${String(v).replace(/'/g, "''")}'`);
  const casos = {
    telefone: ['(87) 99999-9999', '+55 (87) 3862-0000', '3862-0000', '0 21 87 99999-8888', '123', '(87) 89999-9999', '0000-0000'],
    instagram: ['https://instagram.com/empresa/', '@Empresa', 'instagram.com/empresa?igsh=x', 'https://instagram.com/p/abc', 'x y'],
    dominio: ['https://www.empresa.com.br/pagina', 'empresa.com.br', 'fulano@gmail.com', 'loja.wixsite.com/x', 'https://wa.me/55', 'contato@alfa.com.br'],
    cnpj: ['11.222.333/0001-81', '11.222.333/0001-82', '11111111111111', '123'],
    empresa: ['CONSTRUTORA ALFA LTDA - ME', 'Café São João EIRELI', 'Alfa S/A', 'Beta'],
  };
  const fnSql = { telefone: "prospeccao_norm_telefone(%s, '87')", instagram: 'prospeccao_norm_instagram(%s)', dominio: 'prospeccao_norm_dominio(%s)', cnpj: 'prospeccao_norm_cnpj(%s)', empresa: 'prospeccao_norm_empresa(%s)' };
  const fnJs = { telefone: (v) => n.telefone(v, '87'), instagram: n.instagram, dominio: n.dominio, cnpj: n.cnpj, empresa: (v) => n.empresa(v).norm };
  for (const [campo, valores] of Object.entries(casos)) {
    for (const v of valores) {
      const sql = psql(`select coalesce(${fnSql[campo].replace('%s', esc(v))}, '<null>')`);
      const js = fnJs[campo](v);
      assert.equal(sql === '<null>' ? null : sql, js, `${campo}(${v})`);
    }
  }
  assert.equal(psql("select prospeccao_norm_cidade('Petrolina - PE')"), 'petrolina');
  assert.equal(psql("select prospeccao_uf_da_cidade('Juazeiro')"), 'BA');
});
