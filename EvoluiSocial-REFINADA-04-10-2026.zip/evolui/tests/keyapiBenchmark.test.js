const assert = require('assert');
const fs = require('fs');
const path = require('path');

const config = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'scripts', 'keyapi-benchmark.config.json'), 'utf8'));
const total = config.plan.reduce((sum, item) => {
  const costs = {
    tiktok_trending_hashtags: 2,
    tiktok_captions: 2,
    instagram_reels_search: 2,
    instagram_post_comments: 2,
    instagram_shortcode: 2,
    youtube_search: 3,
    youtube_video_info: 3,
    pinterest_search_users: 2,
    pinterest_user_info: 2
  };
  return sum + (costs[item.endpoint] || 0) * Number(item.count || 1);
}, 0);

assert.equal(config.hard_cap_credits, 98);
assert.ok(total <= config.recommended_cap_credits);
assert.ok(config.reserve_credits >= 1);
assert.equal(total, 56);
assert.ok(config.instagram_comments_url.includes("DRhvwVLAHAG"));
console.log('keyapiBenchmark.test.js: 5/5 OK');
