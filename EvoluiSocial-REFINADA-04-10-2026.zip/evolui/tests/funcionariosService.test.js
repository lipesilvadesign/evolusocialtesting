const test = require('node:test');
const assert = require('node:assert/strict');
const funcionariosService = require('../netlify/functions/_lib/services/funcionariosService');

function comFetchMock(fn) {
  return async () => {
    const originalFetch = globalThis.fetch;
    try {
      await fn();
    } finally {
      globalThis.fetch = originalFetch;
    }
  };
}

test('atualizar: rejeita biografia acima de 500 caracteres sem nem chamar a rede', comFetchMock(async () => {
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  await assert.rejects(
    () => funcionariosService.atualizar('token', 'f1', { biografia: 'x'.repeat(501) }),
    /Biografia muito longa/
  );
}));

test('atualizar: aceita biografia dentro do limite e grava no corpo do PATCH', comFetchMock(async () => {
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => ([{ id: 'f1', biografia: corpoEnviado.biografia }]) };
  };
  await funcionariosService.atualizar('token', 'f1', { biografia: 'Trabalho com design há 5 anos.' });
  assert.equal(corpoEnviado.biografia, 'Trabalho com design há 5 anos.');
}));

test('atualizar: biografia vazia/undefined não força escrita da coluna', comFetchMock(async () => {
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => ([{ id: 'f1', nome: 'Novo nome' }]) };
  };
  await funcionariosService.atualizar('token', 'f1', { nome: 'Novo nome' });
  assert.equal('biografia' in corpoEnviado, false, 'não deveria mandar biografia se não foi passada no payload');
}));

test('atualizar: rejeita gênero inválido', comFetchMock(async () => {
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  await assert.rejects(
    () => funcionariosService.atualizar('token', 'f1', { genero: 'outro' }),
    /Gênero inválido/
  );
}));

test('atualizar: rejeita id de avatar inválido', comFetchMock(async () => {
  globalThis.fetch = async () => { throw new Error('não deveria chamar fetch'); };
  await assert.rejects(
    () => funcionariosService.atualizar('token', 'f1', { avatarEscolhido: 'a99' }),
    /Avatar inválido/
  );
}));

test('atualizar: aceita um id de avatar válido e grava avatar_escolhido no corpo do PATCH', comFetchMock(async () => {
  let corpoEnviado = null;
  globalThis.fetch = async (url, opts) => {
    corpoEnviado = JSON.parse(opts.body);
    return { ok: true, json: async () => ([{ id: 'f1', avatar_escolhido: corpoEnviado.avatar_escolhido }]) };
  };
  await funcionariosService.atualizar('token', 'f1', { avatarEscolhido: 'a7' });
  assert.equal(corpoEnviado.avatar_escolhido, 'a7');
}));

test('atualizar: quando a RLS/trigger bloqueia (0 linhas voltam), dá erro de permissão claro', comFetchMock(async () => {
  globalThis.fetch = async () => ({ ok: true, json: async () => ([]) });
  await assert.rejects(
    () => funcionariosService.atualizar('token', 'outro-id', { role: 'admin' }),
    /permissão/
  );
}));
