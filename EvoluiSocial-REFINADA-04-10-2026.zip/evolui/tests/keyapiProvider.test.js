const assert = require('assert');

(async () => {
  const K = await import('../supabase/functions/evolui-api/eie/pesquisa/keyapi.ts');
  assert.equal(K.KEYAPI_ENDPOINTS.tiktok_captions.credits, 2);
  assert.equal(K.KEYAPI_ENDPOINTS.youtube_search.credits, 3);
  assert.equal(K.KEYAPI_ENDPOINTS.pinterest_user_info.path, '/v1/pinterest/information');

  const valid = K.validarChamadaKeyApi({ endpoint: 'tiktok_captions', params: { video_id: '123' } });
  assert.equal(valid.ok, true);
  const invalid = K.validarChamadaKeyApi({ endpoint: 'tiktok_captions', params: {} });
  assert.equal(invalid.ok, false);

  let seen = null;
  const result = await K.chamarKeyApi(
    { endpoint: 'tiktok_trending_hashtags', params: { region: 'BR', page: 1, limit: 20 } },
    'sk_test_1234567890',
    {
      fetchImpl: async (url, init) => {
        seen = { url: String(url), init };
        return new Response(JSON.stringify({ code: 0, message: 'success', data: { list: [{ hashtag_name: 'evolui' }] }, requestId: 'req-1' }), { status: 200, headers: { 'content-type': 'application/json' } });
      }
    }
  );
  assert.equal(result.ok, true);
  assert.equal(result.credits, 2);
  assert.equal(result.requestId, 'req-1');
  assert.ok(seen.url.includes('region=BR'));
  assert.equal(seen.init.headers.Authorization, 'Bearer sk_test_1234567890');

  const sinal = K.normalizarSinalSocial(result, { ramo: 'barbearia', objetivo: 'alcance', consulta: 'barbearia premium' });
  assert.equal(sinal.fonte, 'keyapi');
  assert.equal(sinal.plataforma, 'tiktok');
  assert.equal(sinal.tipo_sinal, 'observado');
  assert.equal(sinal.contexto.ramo, 'barbearia');
  console.log('keyapiProvider.test.js: 9/9 OK');
})();
