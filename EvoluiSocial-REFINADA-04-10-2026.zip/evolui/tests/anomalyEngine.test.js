const test = require('node:test');
const assert = require('node:assert/strict');
const { detectAnomalies } = require('../netlify/functions/_lib/anomalyEngine');

function buildSeries({ days = 90, baseline = 50, spikeLastDays = 0, spikeValue = 200 }) {
  const rows = [];
  for (let i = days - 1; i >= 0; i--) {
    const isSpike = i < spikeLastDays;
    rows.push({
      date: `d${i}`,
      activeUsers: isSpike ? spikeValue : baseline,
      sessions: isSpike ? spikeValue : baseline,
      screenPageViews: isSpike ? spikeValue : baseline,
      engagementRate: 40,
      averageSessionDuration: 30,
    });
  }
  return rows;
}

test('anomalyEngine: pico recente muito acima da linha de base é detectado', () => {
  const series = buildSeries({ spikeLastDays: 1, spikeValue: 300 });
  const anomalies = detectAnomalies(series);
  const found = anomalies.find((a) => a.metric === 'activeUsers');
  assert.ok(found, 'esperava detectar anomalia em activeUsers');
  assert.equal(found.direction, 'alta');
});

test('anomalyEngine: série estável (sem variação) não gera anomalia nenhuma', () => {
  const series = buildSeries({ spikeLastDays: 0 });
  const anomalies = detectAnomalies(series);
  assert.equal(anomalies.length, 0);
});

test('anomalyEngine: série curta demais (menos que o mínimo) não tenta detectar nada', () => {
  const series = buildSeries({ days: 5 });
  const anomalies = detectAnomalies(series);
  assert.equal(anomalies.length, 0);
});

test('anomalyEngine: nunca lança exceção com série vazia', () => {
  assert.doesNotThrow(() => detectAnomalies([]));
  assert.deepEqual(detectAnomalies([]), []);
});
