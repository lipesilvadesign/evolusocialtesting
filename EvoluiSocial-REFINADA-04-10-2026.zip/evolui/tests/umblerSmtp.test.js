const test = require('node:test');
const assert = require('node:assert/strict');

const MODULE_PATH = require.resolve('../netlify/functions/_lib/integrations/umblerSmtp.js');
const RAWSMTP_PATH = require.resolve('../netlify/functions/_lib/integrations/rawSmtp.js');

/**
 * REESCRITO (auditoria de 09/09/2026 encontrou este teste quebrado): a
 * versão anterior mockava 'nodemailer', mas umblerSmtp.js não usa nodemailer
 * há tempos — usa rawSmtp.js (cliente SMTP próprio, net/tls nativos). O mock
 * antigo nunca era de fato exercitado pelo código real, e o teste só não
 * falhava porque tentava abrir uma conexão de rede de verdade com
 * smtp.umbler.com, o que trava por ~20s e falha em qualquer ambiente sem
 * acesso a essa rede.
 *
 * O teste real de PROTOCOLO SMTP (conversa completa com um servidor fake)
 * já existe em tests/rawSmtp.test.js — não precisa ser duplicado aqui. Este
 * arquivo testa só a responsabilidade própria de umblerSmtp.js: validar as
 * credenciais de ambiente e montar corretamente os parâmetros repassados
 * para enviarEmailRaw (host/porta/usuário/remetente/destinatário/assunto/
 * corpo) — por isso mocka `rawSmtp.js`, a única dependência real deste
 * módulo, em vez de uma biblioteca que ele nem importa.
 */
function mockarRawSmtp({ enviarEmailRawImpl } = {}) {
  const chamadas = [];
  require.cache[RAWSMTP_PATH] = {
    id: RAWSMTP_PATH,
    filename: RAWSMTP_PATH,
    loaded: true,
    exports: {
      async enviarEmailRaw(opts) {
        chamadas.push(opts);
        if (enviarEmailRawImpl) return enviarEmailRawImpl(opts);
      },
    },
  };
  return { chamadas };
}

function carregarUmblerSmtpFresco() {
  delete require.cache[MODULE_PATH];
  return require(MODULE_PATH);
}

test('enviarEmail: sem UMBLER_SMTP_USER/UMBLER_SMTP_PASS configurados, lança erro claro e nunca chama rawSmtp', async () => {
  delete process.env.UMBLER_SMTP_USER;
  delete process.env.UMBLER_SMTP_PASS;
  const { chamadas } = mockarRawSmtp();
  const umblerSmtp = carregarUmblerSmtpFresco();

  await assert.rejects(
    () => umblerSmtp.enviarEmail({ para: 'teste@exemplo.com', assunto: 'Oi', corpo: 'Corpo' }),
    /UMBLER_SMTP_USER\/UMBLER_SMTP_PASS não configurados/
  );
  assert.equal(chamadas.length, 0);
});

test('enviarEmail: com credenciais, chama enviarEmailRaw com host/porta certos da Umbler', async () => {
  process.env.UMBLER_SMTP_USER = 'contato@felipebranding.com.br';
  process.env.UMBLER_SMTP_PASS = 'senha-de-teste-fake';
  const { chamadas } = mockarRawSmtp();
  const umblerSmtp = carregarUmblerSmtpFresco();

  await umblerSmtp.enviarEmail({ para: 'lead@empresa.com', assunto: 'Assunto', corpo: 'Corpo do e-mail' });

  assert.equal(chamadas.length, 1);
  const opts = chamadas[0];
  assert.equal(opts.host, 'smtp.umbler.com');
  assert.equal(opts.port, 587);
  assert.equal(opts.user, 'contato@felipebranding.com.br');
  assert.equal(opts.pass, 'senha-de-teste-fake');

  delete process.env.UMBLER_SMTP_USER;
  delete process.env.UMBLER_SMTP_PASS;
});

test('enviarEmail: envia remetente/destinatário/assunto/corpo corretos, em texto simples', async () => {
  process.env.UMBLER_SMTP_USER = 'contato@felipebranding.com.br';
  process.env.UMBLER_SMTP_PASS = 'senha-de-teste-fake';
  const { chamadas } = mockarRawSmtp();
  const umblerSmtp = carregarUmblerSmtpFresco();

  await umblerSmtp.enviarEmail({ para: 'lead@empresa.com', assunto: 'Uma ideia para a Empresa X', corpo: 'Texto do corpo aqui.' });

  const opts = chamadas[0];
  assert.equal(opts.to, 'lead@empresa.com');
  assert.equal(opts.subject, 'Uma ideia para a Empresa X');
  assert.equal(opts.text, 'Texto do corpo aqui.');
  assert.equal(opts.from, 'contato@felipebranding.com.br');
  assert.ok(opts.fromDisplay.includes('Felipe'), 'nome de exibição do remetente deve identificar a Felipe Branding');

  delete process.env.UMBLER_SMTP_USER;
  delete process.env.UMBLER_SMTP_PASS;
});

test('enviarEmail: se o envio (rawSmtp) rejeitar, o erro propaga pra quem chamou', async () => {
  process.env.UMBLER_SMTP_USER = 'contato@felipebranding.com.br';
  process.env.UMBLER_SMTP_PASS = 'senha-errada';
  mockarRawSmtp({
    enviarEmailRawImpl: async () => { throw new Error('535 Authentication failed (simulado)'); },
  });
  const umblerSmtp = carregarUmblerSmtpFresco();

  await assert.rejects(
    () => umblerSmtp.enviarEmail({ para: 'lead@empresa.com', assunto: 'Oi', corpo: 'Corpo' }),
    /Authentication failed/
  );

  delete process.env.UMBLER_SMTP_USER;
  delete process.env.UMBLER_SMTP_PASS;
});
