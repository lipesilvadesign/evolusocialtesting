const test = require('node:test');
const assert = require('node:assert/strict');
const { handler } = require('../netlify/functions/funcionarios-conta');

function evento({ method = 'POST', body, token = 'token-valido' } = {}) {
  return {
    httpMethod: method,
    headers: token ? { authorization: `Bearer ${token}` } : {},
    body: body ? JSON.stringify(body) : undefined,
  };
}

/** Stub de fetch que resolve por URL, cobrindo as chamadas que o handler faz em sequência: /auth/v1/user (requireUser), /rest/v1/admin_funcionarios (checagem de admin), /auth/v1/admin/users/:id (ação de verdade). */
function stubFetch({ ehAdmin = true, acaoOk = true, statusAcao = 200 } = {}) {
  return async (url, opts = {}) => {
    const u = String(url);
    if (u.includes('/auth/v1/user')) {
      return { ok: true, json: async () => ({ id: 'admin-id', email: 'admin@felipebranding.com.br' }) };
    }
    if (u.includes('/rest/v1/admin_funcionarios')) {
      return { ok: true, json: async () => (ehAdmin ? [{ role: 'admin' }] : []) };
    }
    if (u.includes('/auth/v1/admin/users/')) {
      if (!acaoOk) return { ok: false, status: statusAcao, json: async () => ({ msg: 'falhou' }) };
      return { ok: true, status: 200, json: async () => ({}) };
    }
    if (u.includes('/rest/v1/admin_audit_log')) {
      return { ok: true, json: async () => ([]) };
    }
    throw new Error(`URL inesperada no teste: ${u}`);
  };
}

test('funcionarios-conta: sem sessão, rejeita com 401 antes de tocar em qualquer chave', async () => {
  const res = await handler(evento({ token: null, body: { acao: 'resetar_senha', funcionarioId: 'x' } }));
  assert.equal(res.statusCode, 401);
});

test('funcionarios-conta: quem chama não é admin, rejeita com 403', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = stubFetch({ ehAdmin: false });
  try {
    const res = await handler(evento({ body: { acao: 'resetar_senha', funcionarioId: 'outro-id' } }));
    assert.equal(res.statusCode, 403);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('funcionarios-conta: não deixa admin alvejar a própria conta (nem excluir, nem resetar)', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = stubFetch({ ehAdmin: true });
  try {
    const res = await handler(evento({ body: { acao: 'excluir', funcionarioId: 'admin-id' } }));
    assert.equal(res.statusCode, 400);
    assert.match(JSON.parse(res.body).error, /própria conta/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('funcionarios-conta: ação inválida rejeita com 400', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = stubFetch({ ehAdmin: true });
  try {
    const res = await handler(evento({ body: { acao: 'formatar_disco', funcionarioId: 'outro-id' } }));
    assert.equal(res.statusCode, 400);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('funcionarios-conta: sem SUPABASE_SERVICE_ROLE_KEY configurada, erro 500 explicativo (não trava/não mente)', async () => {
  const originalFetch = globalThis.fetch;
  const originalKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  delete process.env.SUPABASE_SERVICE_ROLE_KEY;
  globalThis.fetch = stubFetch({ ehAdmin: true });
  try {
    const res = await handler(evento({ body: { acao: 'resetar_senha', funcionarioId: 'outro-id' } }));
    assert.equal(res.statusCode, 500);
    assert.match(JSON.parse(res.body).error, /SUPABASE_SERVICE_ROLE_KEY/);
  } finally {
    globalThis.fetch = originalFetch;
    if (originalKey !== undefined) process.env.SUPABASE_SERVICE_ROLE_KEY = originalKey;
  }
});

test('funcionarios-conta: resetar_senha com sucesso devolve uma senha gerada de 12 caracteres', async () => {
  const originalFetch = globalThis.fetch;
  const originalKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'chave-de-teste';
  globalThis.fetch = stubFetch({ ehAdmin: true, acaoOk: true });
  try {
    const res = await handler(evento({ body: { acao: 'resetar_senha', funcionarioId: 'outro-id' } }));
    assert.equal(res.statusCode, 200);
    const { senhaGerada } = JSON.parse(res.body);
    assert.equal(senhaGerada.length, 12);
  } finally {
    globalThis.fetch = originalFetch;
    if (originalKey !== undefined) process.env.SUPABASE_SERVICE_ROLE_KEY = originalKey; else delete process.env.SUPABASE_SERVICE_ROLE_KEY;
  }
});

test('funcionarios-conta: excluir propaga erro do Supabase Auth quando a exclusão falha', async () => {
  const originalFetch = globalThis.fetch;
  const originalKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  process.env.SUPABASE_SERVICE_ROLE_KEY = 'chave-de-teste';
  globalThis.fetch = stubFetch({ ehAdmin: true, acaoOk: false, statusAcao: 404 });
  try {
    const res = await handler(evento({ body: { acao: 'excluir', funcionarioId: 'outro-id' } }));
    assert.equal(res.statusCode, 404);
  } finally {
    globalThis.fetch = originalFetch;
    if (originalKey !== undefined) process.env.SUPABASE_SERVICE_ROLE_KEY = originalKey; else delete process.env.SUPABASE_SERVICE_ROLE_KEY;
  }
});

// Auditoria 29/09: admin DESATIVADO (ativo=false) não pode passar na checagem.
// Simula a RLS real: a própria linha é sempre visível (id = auth.uid()); só o
// filtro ativo=eq.true na URL impede o ex-admin de passar.
test('funcionarios-conta: admin DESATIVADO é barrado (checagem filtra id do chamador + ativo=true)', async () => {
  const originalFetch = globalThis.fetch;
  let urlChecagem = '';
  globalThis.fetch = async (url) => {
    const u = String(url);
    if (u.includes('/auth/v1/user')) return { ok: true, json: async () => ({ id: 'ex-admin-id', email: 'ex@fb.com' }) };
    if (u.includes('/rest/v1/admin_funcionarios')) {
      urlChecagem = u;
      const linhaPropria = { id: 'ex-admin-id', role: 'admin', ativo: false };
      const exigeAtivo = u.includes('ativo=eq.true');
      return { ok: true, json: async () => (exigeAtivo && !linhaPropria.ativo ? [] : [linhaPropria]) };
    }
    throw new Error('Não deveria chegar à ação: ' + u);
  };
  try {
    const res = await handler(evento({ body: { acao: 'excluir', funcionarioId: 'outra-pessoa' } }));
    assert.equal(res.statusCode, 403);
    assert.match(urlChecagem, /id=eq\.ex-admin-id/);
    assert.match(urlChecagem, /ativo=eq\.true/);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
