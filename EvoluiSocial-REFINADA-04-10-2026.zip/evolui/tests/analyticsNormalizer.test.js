const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeSnapshot, computeDelta } = require('../netlify/functions/_lib/analyticsNormalizer');

test('computeDelta: previous=0 e current>0 vira isNew, nunca Infinity', () => {
  const d = computeDelta(50, 0);
  assert.equal(d.isNew, true);
  assert.equal(d.deltaPct, null);
  assert.notEqual(d.deltaAbs, Infinity);
});

test('computeDelta: previous=0 e current=0 não é anomalia nem erro', () => {
  const d = computeDelta(0, 0);
  assert.equal(d.isNew, false);
  assert.equal(d.deltaPct, 0);
});

test('computeDelta: previous null (sem comparação) devolve tudo null', () => {
  const d = computeDelta(50, null);
  assert.equal(d.deltaAbs, null);
  assert.equal(d.deltaPct, null);
  assert.equal(d.isNew, false);
});

test('normalizeSnapshot: página fora do top anterior vira isNew', () => {
  const raw = {
    rangeLabel: 'teste',
    overview: {
      current: { metrics: { activeUsers: 10, sessions: 10, screenPageViews: 10, engagementRate: 10, averageSessionDuration: 10 }, isEmpty: false },
      previous: { metrics: { activeUsers: 5, sessions: 5, screenPageViews: 5, engagementRate: 5, averageSessionDuration: 5 }, isEmpty: false },
    },
    pages: { current: [{ path: '/nova', title: 'Nova', views: 40, activeUsers: 20, eventCount: 5 }], previous: [] },
    events: { current: [], previous: [] },
    trafficSources: { current: [], previous: [] },
    devices: { current: [] },
  };
  const normalized = normalizeSnapshot(raw);
  assert.equal(normalized.pages[0].isNew, true);
  assert.equal(normalized.pages[0].previousViews, null);
});

test('normalizeSnapshot: sem overview anterior, hasComparison=false', () => {
  const raw = {
    rangeLabel: 'teste',
    overview: {
      current: { metrics: { activeUsers: 10, sessions: 10, screenPageViews: 10, engagementRate: 10, averageSessionDuration: 10 }, isEmpty: false },
      previous: null,
    },
    pages: { current: [], previous: [] },
    events: { current: [], previous: [] },
    trafficSources: { current: [], previous: [] },
    devices: { current: [] },
  };
  const normalized = normalizeSnapshot(raw);
  assert.equal(normalized.hasComparison, false);
});
