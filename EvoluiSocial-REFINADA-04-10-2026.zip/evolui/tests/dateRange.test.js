const test = require('node:test');
const assert = require('node:assert/strict');
const { resolveDateRange, previousDateRange } = require('../netlify/functions/_lib/dateRange');

test('resolveDateRange: preset padrão (7d)', () => {
  const { dateRange, key, label } = resolveDateRange({});
  assert.equal(key, '7d');
  assert.equal(dateRange.startDate, '7daysAgo');
  assert.equal(dateRange.endDate, 'today');
  assert.equal(label, 'Últimos 7 dias');
});

test('resolveDateRange: período personalizado válido', () => {
  const { dateRange } = resolveDateRange({ range: 'personalizado', start: '2026-01-01', end: '2026-01-31' });
  assert.equal(dateRange.startDate, '2026-01-01');
  assert.equal(dateRange.endDate, '2026-01-31');
});

test('resolveDateRange: personalizado sem datas lança erro claro', () => {
  assert.throws(() => resolveDateRange({ range: 'personalizado' }), /AAAA-MM-DD/);
});

test('resolveDateRange: chave inválida lança erro', () => {
  assert.throws(() => resolveDateRange({ range: 'inexistente' }), /Período inválido/);
});

test('previousDateRange: desloca presets relativos corretamente', () => {
  const prev7d = previousDateRange({ startDate: '7daysAgo', endDate: 'today' });
  assert.equal(prev7d.startDate, '14daysAgo');
  assert.equal(prev7d.endDate, '8daysAgo');
});

test('previousDateRange: desloca datas absolutas mantendo a duração', () => {
  const prev = previousDateRange({ startDate: '2026-02-10', endDate: '2026-02-16' }); // 7 dias
  assert.equal(prev.endDate, '2026-02-09');
  assert.equal(prev.startDate, '2026-02-03');
});
