const assert = require('assert');
(async () => {
  const V = await import('../supabase/functions/evolui-api/eie/video.ts');
  const a = V.normalizarAnaliseVideo({
    versao: 'evi-video-v1',
    impressao_digital: 'abc123',
    ajuste_contextual_observavel: { nivel: 'alto' },
    descricao: 'Vídeo sobre conteúdo para barbearias.',
    tema: 'conteúdo para barbearias',
    gancho: 'Você está postando do jeito errado?',
    cta: 'Comente BARBA',
    elementos_visuais: ['cortes rápidos', 'texto na tela'],
    termos: ['barbearia', 'conteúdo'],
    confianca: 0.91,
  }, { url: 'https://youtube.com/watch?v=x', plataforma: 'youtube' });
  assert.equal(a.modo, 'video');
  assert.equal(a.confianca, 0.91);
  assert.equal(a.elementosVisuais.length, 2);
  assert.equal(a.versao, 'evi-video-v1');
  assert.equal(a.impressaoDigital, 'abc123');
  assert.equal(a.ajusteContextualObservavel.nivel, 'alto');
  const ideias = V.gerarIdeiasVideo(a, { ramo: 'barbearias', objetivo: 'crescer' });
  assert.equal(ideias.length, 4);
  assert.ok(ideias[0].titulo.includes('barbearias') || ideias[0].titulo.includes('conteúdo'));
  assert.ok(V.promptAnaliseVideo({ url: 'https://youtube.com/watch?v=x', ramo: 'barbearias', objetivo: 'crescer' }).includes('Retorne SOMENTE JSON'));
  console.log('videoIntelligence.test.js: 6/6 OK');
})();
