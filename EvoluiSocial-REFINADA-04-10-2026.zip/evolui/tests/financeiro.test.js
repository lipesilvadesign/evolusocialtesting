const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

async function carregarView() {
  const url = 'file://' + path.resolve(__dirname, '../painel/assets/js/views/financeiro.js');
  return import(url);
}

test('formatBRL: formata em Real brasileiro, inclusive zero/nulo', async () => {
  const { formatBRL } = await carregarView();
  assert.equal(formatBRL(1234.5), 'R$ 1.234,50');
  assert.equal(formatBRL(0), 'R$ 0,00');
  assert.equal(formatBRL(null), 'R$ 0,00');
  assert.equal(formatBRL(undefined), 'R$ 0,00');
});

test('formatDataBR: formata data pura (YYYY-MM-DD) sem cair um dia por fuso horário', async () => {
  const { formatDataBR } = await carregarView();
  assert.equal(formatDataBR('2026-01-31'), '31/01/2026');
  assert.equal(formatDataBR(null), '—');
});

test('statusEfetivo: parcela vencida e não paga vira "atrasado" na exibição, sem precisar de job/gatilho', async () => {
  const { statusEfetivo } = await carregarView();
  assert.equal(statusEfetivo({ status: 'previsto', vencimento: '2026-01-01' }, '2026-02-01'), 'atrasado');
  assert.equal(statusEfetivo({ status: 'aguardando', vencimento: '2026-03-01' }, '2026-02-01'), 'aguardando');
  assert.equal(statusEfetivo({ status: 'pago', vencimento: '2026-01-01' }, '2026-02-01'), 'pago', 'paga nunca vira atrasado, mesmo com vencimento passado');
  assert.equal(statusEfetivo({ status: 'cancelado', vencimento: '2026-01-01' }, '2026-02-01'), 'cancelado');
});

test('calcularResumoFinanceiro: saldo disponível = recebido − pago (só o que está marcado como pago)', async () => {
  const { calcularResumoFinanceiro } = await carregarView();
  const leads = [{ id: 'l1', empresa: 'Padaria Sol', status: 'cliente', origem: null }];
  const contratos = [{ id: 'c1', lead_id: 'l1', servico: 'branding', valor_total: 3000, status: 'ativo', recorrente: false }];
  const parcelas = [
    { id: 'p1', contrato_id: 'c1', numero: 1, valor: 1500, valor_pago: 1500, vencimento: '2026-01-01', status: 'pago', pago_em: '2026-01-01' },
    { id: 'p2', contrato_id: 'c1', numero: 2, valor: 1500, vencimento: '2026-03-01', status: 'previsto' },
  ];
  const despesas = [
    { id: 'd1', categoria: 'netlify', descricao: 'Plano', valor: 100, vencimento: '2026-01-05', status: 'pago', pago_em: '2026-01-05' },
  ];

  const r = calcularResumoFinanceiro({ contratos, parcelas, despesas, leads, hojeIso: '2026-02-01' });

  assert.equal(r.saldoDisponivel, 1400, '1500 recebido - 100 pago em despesas');
  assert.equal(r.aReceber, 1500, 'só a parcela não paga conta como "a receber"');
  assert.equal(r.aPagar, 0, 'a única despesa já está paga');
  assert.equal(r.receitaContratada, 3000);
  assert.equal(r.receitaPorCliente.length, 1);
  assert.equal(r.receitaPorCliente[0].nome, 'Padaria Sol');
  assert.equal(r.receitaPorCliente[0].emAberto, 1500);
  assert.equal(r.receitaPorCliente[0].status, 'parcial');
});

test('calcularResumoFinanceiro: nunca inventa "receita por origem" com poucos dados — retorna null (tela mostra "Dados insuficientes")', async () => {
  const { calcularResumoFinanceiro } = await carregarView();
  const leads = [
    { id: 'l1', empresa: 'A', status: 'cliente', origem: 'google' },
    { id: 'l2', empresa: 'B', status: 'cliente', origem: 'instagram' },
  ];
  const contratos = [
    { id: 'c1', lead_id: 'l1', servico: 'branding', valor_total: 1000, status: 'ativo', recorrente: false },
    { id: 'c2', lead_id: 'l2', servico: 'conteudo', valor_total: 1000, status: 'ativo', recorrente: false },
  ];
  const parcelas = [
    { id: 'p1', contrato_id: 'c1', numero: 1, valor: 1000, valor_pago: 1000, vencimento: '2026-01-01', status: 'pago', pago_em: '2026-01-01' },
    { id: 'p2', contrato_id: 'c2', numero: 1, valor: 1000, valor_pago: 1000, vencimento: '2026-01-01', status: 'pago', pago_em: '2026-01-01' },
  ];
  const r = calcularResumoFinanceiro({ contratos, parcelas, despesas: [], leads, hojeIso: '2026-02-01' });
  assert.equal(r.receitaPorOrigem, null, 'só 2 clientes com origem preenchida — abaixo do mínimo (3)');
});

test('calcularResumoFinanceiro: contrato/parcela de cliente que não existe mais no CRM não quebra (mostra rótulo explicativo)', async () => {
  const { calcularResumoFinanceiro } = await carregarView();
  const contratos = [{ id: 'c1', lead_id: 'lead-excluido', servico: 'branding', valor_total: 500, status: 'ativo', recorrente: false }];
  const parcelas = [{ id: 'p1', contrato_id: 'c1', numero: 1, valor: 500, vencimento: '2026-01-01', status: 'previsto' }];
  const r = calcularResumoFinanceiro({ contratos, parcelas, despesas: [], leads: [], hojeIso: '2026-02-01' });
  assert.equal(r.receitaPorCliente[0].nome, 'Cliente removido do CRM');
  assert.equal(r.proximosVencimentos[0].nomeCliente, 'Cliente removido do CRM');
});

test('resolverPeriodo: presets viram limites de data corretos (o seletor do header precisa filtrar de verdade, não só existir)', async () => {
  const { resolverPeriodo } = await carregarView();
  assert.deepEqual(resolverPeriodo({ range: 'hoje' }, '2026-03-15'), { inicioIso: '2026-03-15', fimIso: '2026-03-15', label: 'hoje' });
  assert.equal(resolverPeriodo({ range: '7d' }, '2026-03-15').inicioIso, '2026-03-09', '7 dias incluindo hoje = hoje - 6');
  assert.equal(resolverPeriodo({ range: '7d' }, '2026-03-15').fimIso, '2026-03-15');
  const personalizado = resolverPeriodo({ range: 'personalizado', start: '2026-01-01', end: '2026-01-31' }, '2026-03-15');
  assert.equal(personalizado.inicioIso, '2026-01-01');
  assert.equal(personalizado.fimIso, '2026-01-31');
});

test('calcularResumoFinanceiro: "resultado do período" muda de verdade quando o período muda (achado — antes o seletor não filtrava nada)', async () => {
  const { calcularResumoFinanceiro, resolverPeriodo } = await carregarView();
  const leads = [{ id: 'l1', empresa: 'X', status: 'cliente' }];
  const contratos = [{ id: 'c1', lead_id: 'l1', servico: 'branding', valor_total: 2000, status: 'ativo', recorrente: false }];
  const parcelas = [
    { id: 'p1', contrato_id: 'c1', numero: 1, valor: 1000, valor_pago: 1000, vencimento: '2026-01-01', status: 'pago', pago_em: '2026-01-10' },
    { id: 'p2', contrato_id: 'c1', numero: 2, valor: 1000, valor_pago: 1000, vencimento: '2026-03-01', status: 'pago', pago_em: '2026-03-10' },
  ];
  const hojeIso = '2026-03-15';

  const noPeriodoDeJaneiro = calcularResumoFinanceiro({ contratos, parcelas, despesas: [], leads, hojeIso, periodo: resolverPeriodo({ range: 'personalizado', start: '2026-01-01', end: '2026-01-31' }, hojeIso) });
  const noPeriodoDeMarco = calcularResumoFinanceiro({ contratos, parcelas, despesas: [], leads, hojeIso, periodo: resolverPeriodo({ range: 'personalizado', start: '2026-03-01', end: '2026-03-31' }, hojeIso) });

  assert.equal(noPeriodoDeJaneiro.recebidoNoPeriodo, 1000, 'só a parcela paga em janeiro entra no período de janeiro');
  assert.equal(noPeriodoDeMarco.recebidoNoPeriodo, 1000, 'só a parcela paga em março entra no período de março');
  assert.equal(noPeriodoDeJaneiro.saldoDisponivel, noPeriodoDeMarco.saldoDisponivel, 'saldo disponível é sempre acumulado — não muda com o período (só "resultado do período" muda)');
});

test('calcularSerieFluxo: agrupa por mês de pagamento (pago_em), ignora não-pagos', async () => {
  const { calcularSerieFluxo } = await carregarView();
  const parcelas = [
    { valor: 100, valor_pago: 100, status: 'pago', pago_em: '2026-01-15' },
    { valor: 200, status: 'previsto' }, // não paga — não deve entrar
  ];
  const despesas = [{ valor: 50, status: 'pago', pago_em: '2026-01-20' }];
  const serie = calcularSerieFluxo(parcelas, despesas, 2, '2026-01-31');
  assert.deepEqual(serie.receitas, [0, 100]);
  assert.deepEqual(serie.despesas, [0, 50]);
});
