const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');

test('pesquisa web: SearXNG e Firecrawl são adaptadores server-side separados', () => {
  const o = read('supabase/functions/evolui-api/eie/pesquisa/orquestrador.ts');
  assert.match(o, /buscarSearXNG/);
  assert.match(o, /buscarFirecrawl/);
  assert.match(o, /Promise\.all\(\[searxP, fireP\]\)/);
});

test('pesquisa web: nenhum segredo de provedor é referenciado no navegador', () => {
  const a = read('evoluisocial/app/app.js');
  assert.doesNotMatch(a, /FIRECRAWL_API_KEY|SEARXNG_URL/);
});

test('pesquisa UI: usa dicas educativas e Business somente em planos pagos', () => {
  const a = read('evoluisocial/app/app.js');
  assert.match(a, /Dica da Evolui/);
  assert.match(a, /Laboratório/);
  assert.match(a, /Evolui Business/);
  assert.doesNotMatch(a, /esperarMinimo/);
});

test('pesquisa UI: o slider usa área fixa para não reflowar o card a cada slide', () => {
  const c = read('evoluisocial/app/app.css');
  assert.match(c, /\.promo-pro-slides\{[^}]*aspect-ratio:16\/5/);
  assert.match(c, /\.promo-pro-slide\.ativo/);
});
