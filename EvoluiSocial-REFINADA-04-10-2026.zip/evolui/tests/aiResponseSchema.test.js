const test = require('node:test');
const assert = require('node:assert/strict');
const { validateAiResponse } = require('../netlify/functions/_lib/aiResponseSchema');
const { AiError } = require('../netlify/functions/_lib/errors/aiErrors');

function validPayload(overrides = {}) {
  return {
    summary: 'Resumo válido.',
    insufficient_data: false,
    positive_points: [{ text: 'x', evidence_strength: 'forte', related_metric: 'activeUsers' }],
    attention_points: [],
    opportunities: [],
    recommendations: [{ title: 't', explanation: 'e', evidence: 'ev', suggested_action: 'a', priority: 'alta' }],
    questions_to_investigate: ['pergunta?'],
    ...overrides,
  };
}

test('aiResponseSchema: aceita payload bem formado', () => {
  const result = validateAiResponse(validPayload());
  assert.equal(result.summary, 'Resumo válido.');
  assert.equal(result.recommendations[0].priority, 'alta');
});

test('aiResponseSchema: rejeita summary ausente', () => {
  const bad = validPayload();
  delete bad.summary;
  assert.throws(() => validateAiResponse(bad), AiError);
});

test('aiResponseSchema: rejeita evidence_strength fora do enum', () => {
  const bad = validPayload({ positive_points: [{ text: 'x', evidence_strength: 'super-forte' }] });
  assert.throws(() => validateAiResponse(bad), AiError);
});

test('aiResponseSchema: rejeita recomendação sem "evidence"', () => {
  const bad = validPayload({
    recommendations: [{ title: 't', explanation: 'e', suggested_action: 'a', priority: 'alta' }],
  });
  assert.throws(() => validateAiResponse(bad), AiError);
});

test('aiResponseSchema: rejeita priority fora do enum', () => {
  const bad = validPayload({
    recommendations: [{ title: 't', explanation: 'e', evidence: 'ev', suggested_action: 'a', priority: 'urgentíssima' }],
  });
  assert.throws(() => validateAiResponse(bad), AiError);
});

test('aiResponseSchema: rejeita resposta que não é objeto', () => {
  assert.throws(() => validateAiResponse(null), AiError);
  assert.throws(() => validateAiResponse('texto solto'), AiError);
});
