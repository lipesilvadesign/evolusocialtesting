const test = require('node:test');
const assert = require('node:assert/strict');
const enriquecer = require('../netlify/functions/_lib/captacao/enriquecer');
const dedup = require('../netlify/functions/_lib/captacao/deduplicar');
const pipeline = require('../netlify/functions/_lib/captacao/pipeline');
const { registro } = require('../netlify/functions/_lib/captacao/tipos');

// ---------- fetch falso para checagem de site ----------
function resp(status, { location, html = '' } = {}) {
  return { status, headers: { get: (h) => (h.toLowerCase() === 'location' ? location || null : null) }, text: async () => html, body: null };
}
function fetchPorUrl(mapa) {
  const chamadas = [];
  const f = async (url) => {
    chamadas.push(url);
    const v = mapa[url];
    if (typeof v === 'function') return v();
    if (v instanceof Error) throw v;
    if (!v) throw Object.assign(new Error('fetch failed'), { cause: { code: 'ENOTFOUND' } });
    return v;
  };
  f.chamadas = chamadas;
  return f;
}

test('site: HTTPS ok + Instagram extraído da página inicial', async () => {
  const f = fetchPorUrl({ 'https://alfa.com.br/': resp(200, { html: '<a href="https://www.instagram.com/alfa.oficial/">IG</a>' }) });
  const r = await enriquecer.verificarSite('alfa.com.br', { fetchImpl: f });
  assert.equal(r.resultado, 'ok');
  assert.equal(r.https, true);
  assert.equal(r.instagram, 'alfa.oficial');
});

test('site: HTTPS falha e HTTP responde → SITE_SEM_HTTPS (alta, com evidência)', async () => {
  const tls = Object.assign(new Error('fetch failed'), { cause: { code: 'ERR_TLS_CERT_ALTNAME_INVALID' } });
  const f = fetchPorUrl({ 'https://beta.com.br/': tls, 'http://beta.com.br/': resp(200) });
  const r = await enriquecer.verificarSite('http://beta.com.br', { fetchImpl: f });
  assert.equal(r.resultado, 'sem_https');
  const s = enriquecer.sinaisPara({ site: 'http://beta.com.br' }, r);
  assert.equal(s[0].tipo, 'SITE_SEM_HTTPS');
  assert.equal(s[0].confianca, 'alta');
  assert.match(s[0].evidencia, /HTTP 200/);
});

test('site: redireciona https → http conta como sem HTTPS', async () => {
  const f = fetchPorUrl({ 'https://gama.com/': resp(301, { location: 'http://gama.com/' }), 'http://gama.com/': resp(200) });
  const r = await enriquecer.verificarSite('gama.com', { fetchImpl: f });
  assert.equal(r.resultado, 'sem_https');
});

test('site: DNS/timeout nas 2 tentativas dos 2 protocolos → SITE_FORA_DO_AR; 1 retry por protocolo', async () => {
  const f = fetchPorUrl({});
  const r = await enriquecer.verificarSite('naoexiste.com.br', { fetchImpl: f });
  assert.equal(r.resultado, 'fora_do_ar');
  assert.equal(f.chamadas.length, 4, '2 tentativas × 2 protocolos');
  assert.equal(enriquecer.sinaisPara({ site: 'x' }, r)[0].tipo, 'SITE_FORA_DO_AR');
});

test('site: 403/429 (bloqueio de robô) = NÃO VERIFICADO, nunca "fora do ar"', async () => {
  for (const st of [403, 429]) {
    const r = await enriquecer.verificarSite('delta.com', { fetchImpl: fetchPorUrl({ 'https://delta.com/': resp(st) }) });
    assert.equal(r.resultado, 'nao_verificado');
    assert.deepEqual(enriquecer.sinaisPara({ site: 'delta.com' }, r), []);
  }
});

test('site: mais de 3 redirecionamentos para; 500 tenta de novo', async () => {
  let n = 0;
  const loop = fetchPorUrl({ 'https://eps.com/': () => resp(302, { location: `https://eps.com/${++n}` }) });
  const f = async (url) => (url.startsWith('https://eps.com/') ? resp(302, { location: `https://eps.com/${++n}` }) : loop(url));
  const r = await enriquecer.verificarSite('eps.com', { fetchImpl: f });
  assert.ok(n <= 3 * 2 + 2, 'não segue redirecionamentos infinitos');
  assert.notEqual(r.resultado, 'ok');
  let tentativas = 0;
  const r5 = await enriquecer.verificarSite('zeta.com', { fetchImpl: async (u) => { tentativas += 1; return u.startsWith('https') ? resp(500) : resp(500); } });
  assert.equal(r5.resultado, 'fora_do_ar');
  assert.equal(tentativas, 4);
});

test('SEM_SITE só com evidência (fontes consultadas); sem fontes, nenhum sinal', () => {
  assert.deepEqual(enriquecer.sinaisPara({ site: null }, null, { fontesConsultadas: [] }), []);
  const s = enriquecer.sinaisPara({ site: null }, null, { fontesConsultadas: ['Geoapify', 'OpenStreetMap'] });
  assert.equal(s[0].tipo, 'SEM_SITE');
  assert.equal(s[0].confianca, 'media');
  assert.match(s[0].evidencia, /Geoapify, OpenStreetMap/);
});

test('concorrência limitada: nunca mais que N checagens ao mesmo tempo', async () => {
  let ativos = 0; let pico = 0;
  await enriquecer.emLotes(Array.from({ length: 20 }, (_, i) => i), 5, async () => {
    ativos += 1; pico = Math.max(pico, ativos);
    await new Promise((r) => setImmediate(r));
    ativos -= 1;
  });
  assert.ok(pico <= 5);
});

// ---------- deduplicação ----------
const L = (x) => ({ status: 'pendente', avisos: [], payload: {}, ...x });

test('dedup no job: mesma empresa do Geoapify e do OSM vira UM registro (campos completados)', () => {
  const { linhas, fundidos } = dedup.dedupNoJob([
    L({ provider: 'geoapify', external_id: 'geoapify:1', empresa_norm: 'alfa construcoes', cidade_norm: 'petrolina', telefone_norm: '558738620000', site: null }),
    L({ provider: 'overpass', external_id: 'osm:node/9', empresa_norm: 'alfa construcoes', cidade_norm: 'petrolina', site: 'https://alfa.com.br', dominio: 'alfa.com.br' }),
    L({ provider: 'overpass', external_id: 'osm:node/10', empresa_norm: 'padaria beta', cidade_norm: 'petrolina' }),
  ]);
  assert.equal(linhas.length, 2);
  assert.equal(fundidos, 1);
  assert.equal(linhas[0].site, 'https://alfa.com.br');
  assert.equal(linhas[0].payload.outras_fontes[0].external_id, 'osm:node/9');
});

test('dedup CRM: CNPJ/origem/domínio+nome = duplicado automático; telefone/Instagram/nome+cidade = revisão', async () => {
  const linhas = [
    L({ external_id: 'a', cnpj: '11222333000181' }), L({ external_id: 'b' }), L({ external_id: 'c' }),
    L({ external_id: 'd' }), L({ external_id: 'e' }), L({ external_id: 'f' }), L({ external_id: 'g' }), L({ external_id: 'h', email: 'x@y.com' }),
  ];
  const tipos = ['cnpj', 'external_id', 'dominio_nome', 'dominio', 'telefone', 'instagram', 'nome_cidade'];
  const busca = async (lote) => lote.filter((x) => x.idx < tipos.length).map((x) => ({ idx: x.idx, lead_id: `lead-${x.idx}`, empresa: 'E', match_tipo: tipos[x.idx], confianca: 80 }));
  await dedup.classificarContraCrm(linhas, busca);
  assert.deepEqual(linhas.map((l) => l.status), ['duplicado', 'duplicado', 'duplicado', 'possivel_duplicado', 'possivel_duplicado', 'possivel_duplicado', 'possivel_duplicado', 'pendente']);
  assert.equal(linhas[4].match_lead_id, 'lead-4');
});

test('opt-out: telefone em outro formato, e-mail com maiúscula e origem bloqueiam', () => {
  const b = dedup.montarBloqueios([{ telefone: '(87) 3862-0000' }, { email: 'Contato@Loja.com' }, { origem_id: 'osm:node/5' }]);
  const linhas = [L({ telefone_norm: '558738620000' }), L({ email: 'contato@loja.com' }), L({ external_id: 'osm:node/5' }), L({ external_id: 'x' })];
  assert.equal(dedup.aplicarOptout(linhas, b), 3);
  assert.equal(linhas[3].status, 'pendente');
});

// ---------- pipeline de ponta a ponta (deps falsas) ----------
function depsFalsas({ statusJob = () => 'em_andamento', crm = [] } = {}) {
  const banco = new Map(); // chave job|provider|external → linha (índice único)
  const atualizacoes = [];
  const deps = {
    atualizarJob: async (id, campos) => { atualizacoes.push(campos); },
    lerStatusJob: async () => statusJob(),
    geocodificar: async (c) => (c.startsWith('Nenhum') ? null : { lat: -9.39, lon: -40.5 }),
    coletar: {
      geoapify: async () => ({ registros: [
        registro({ provider: 'geoapify', external_id: 'geoapify:1', empresa: 'Alfa Construções', telefone: '87 3862-0000', cidade: 'Petrolina', site: 'alfa.com.br', setor_sugerido: 'Construção' }),
        registro({ provider: 'geoapify', external_id: 'geoapify:2', empresa: 'Beta Materiais', cidade: 'Petrolina', setor_sugerido: 'Construção' }),
      ], avisos: [] }),
      overpass: async () => ({ registros: [
        registro({ provider: 'overpass', external_id: 'osm:node/1', empresa: 'Alfa Construções LTDA', telefone: '(87) 3862-0000', cidade: 'Petrolina' }),
        registro({ provider: 'overpass', external_id: 'osm:node/2', empresa: 'Gama Obras', cidade: 'Petrolina', telefone: '87 99999-1111' }),
      ], avisos: [] }),
    },
    carregarBloqueios: async () => dedup.montarBloqueios([{ telefone: '87 99999-1111' }]),
    buscarCandidatos: async (lote) => lote.filter((x) => crm.includes(x.empresa_norm)).map((x) => ({ idx: x.idx, lead_id: 'L1', empresa: 'Existente', match_tipo: 'nome_cidade', confianca: 85 })),
    verificarSite: async () => ({ resultado: 'sem_https', httpStatus: 200, https: false, instagram: null, evidencia: 'medido' }),
    gravarCaptura: async (lote) => { for (const l of lote) { const k = `${l.job_id}|${l.provider}|${l.external_id}`; if (!banco.has(k)) banco.set(k, l); } },
    aguardar: async () => {},
  };
  return { deps, banco, atualizacoes };
}

test('pipeline (legado, flag desligada): coleta → normaliza → dedup → opt-out → enriquece → grava só na CAPTURA', async () => {
  const { deps, banco, atualizacoes } = depsFalsas({ crm: ['beta materiais'] });
  deps.novoFluxo = false;
  const job = { id: 'job-1', status: 'em_andamento', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } };
  const r = await pipeline.executarPesquisa(job, deps);
  assert.equal(r.encontrados, 4);
  const linhas = [...banco.values()];
  assert.equal(linhas.length, 3, 'Alfa (Geoapify + OSM) fundida');
  const porNome = Object.fromEntries(linhas.map((l) => [l.empresa, l]));
  assert.equal(porNome['Alfa Construções'].telefone_norm, '558738620000');
  assert.equal(porNome['Alfa Construções'].sinais[0].tipo, 'SITE_SEM_HTTPS');
  assert.equal(porNome['Beta Materiais'].status, 'possivel_duplicado');
  assert.equal(porNome['Beta Materiais'].sinais[0].tipo, 'SEM_SITE');
  assert.equal(porNome['Gama Obras'].status, 'bloqueado_optout');
  assert.equal(atualizacoes.at(-1).status, 'em_revisao');
  assert.ok(linhas.every((l) => l.job_id === 'job-1' && !('lead_id' in l && l.lead_id)), 'nada aponta para o CRM');
});

test('pipeline idempotente: rodar o mesmo job 2 vezes não duplica a captura', async () => {
  const { deps, banco } = depsFalsas();
  const job = { id: 'job-2', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } };
  await pipeline.executarPesquisa(job, deps);
  const n = banco.size;
  await pipeline.executarPesquisa(job, deps);
  assert.equal(banco.size, n);
});

test('pipeline: cancelado entre etapas para sem gravar', async () => {
  const { deps, banco } = depsFalsas({ statusJob: () => 'cancelado' });
  const job = { id: 'job-3', providers: ['geoapify'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE', 'Juazeiro, BA'], raioKm: 15 } };
  await assert.rejects(() => pipeline.executarPesquisa(job, deps), pipeline.JobCancelado);
  assert.equal(banco.size, 0);
});

test('pipeline: todas as fontes falhando vira status erro com mensagem (sem inventar resultado)', async () => {
  const { deps, atualizacoes } = depsFalsas();
  deps.coletar.geoapify = async () => { throw new Error('Geoapify respondeu 401'); };
  const job = { id: 'job-4', providers: ['geoapify'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } };
  const r = await pipeline.executarPesquisa(job, deps);
  assert.equal(r.status, 'erro');
  assert.match(atualizacoes.at(-1).mensagem_erro, /Nenhuma fonte/);
  assert.match(JSON.stringify(atualizacoes.at(-1).erros), /401/);
});

// ---------- v2 (ENABLE_NEW_CAPTURE_FLOW): paralelo, prazo, cache, área, enriquecimento depois ----------
function comEnriquecimentoFalso(ctx) {
  const { deps, banco } = ctx;
  const gravacoes = [];
  deps.listarPendentesEnriquecimento = async () => [...banco.values()].filter((l) => l.enriquecimento_status === 'pendente').map((l, i) => ({ id: `cap-${i}`, ...l }));
  deps.gravarEnriquecimento = async (id, dados) => { gravacoes.push({ id, dados }); return { status: dados.status }; };
  return gravacoes;
}
const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

test('v2: resultados gravados ANTES do enriquecimento; job em_revisao com etapa "enriquecimento" e telemetria', async () => {
  const ctx = depsFalsas({ crm: ['beta materiais'] });
  const gravacoes = comEnriquecimentoFalso(ctx);
  const ordem = [];
  const gravar = ctx.deps.gravarCaptura;
  ctx.deps.gravarCaptura = async (lote) => { ordem.push('grava'); return gravar(lote); };
  const verificar = ctx.deps.verificarSite;
  ctx.deps.verificarSite = async (s) => { ordem.push('site'); return verificar(s); };
  ctx.deps.novoFluxo = true;
  const job = { id: 'job-v2', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } };
  const r = await pipeline.executarPesquisa(job, ctx.deps);
  assert.equal(ordem.at(-1), 'site', 'site só é checado depois de TODA a gravação');
  assert.ok(ordem.filter((x) => x === 'grava').length >= 1);
  const linhas = [...ctx.banco.values()];
  assert.equal(linhas.length, 3);
  const alfa = linhas.find((l) => l.empresa === 'Alfa Construções');
  assert.equal(alfa.enriquecimento_status, 'pendente');
  assert.equal(linhas.find((l) => l.empresa === 'Beta Materiais').sinais[0].tipo, 'SEM_SITE', 'sem site: sinal imediato, sem rede');
  assert.ok(ctx.atualizacoes.some((a) => a.status === 'em_revisao' && a.etapa === 'coleta'), 'resultados parciais já revisáveis durante a coleta');
  assert.ok(ctx.atualizacoes.some((a) => a.status === 'em_revisao' && a.etapa === 'enriquecimento'));
  assert.equal(ctx.atualizacoes.at(-1).etapa, null, 'etapa limpa quando o enriquecimento termina');
  assert.equal(gravacoes.length, 1);
  assert.equal(gravacoes[0].dados.sinais[0].tipo, 'SITE_SEM_HTTPS');
  const m = r.metricas;
  assert.equal(m.encontrados, 4);
  assert.equal(m.duplicados, 1, '1 fundido no job');
  assert.equal(m.possiveis_duplicados, 1);
  assert.equal(m.bloqueados, 1);
  assert.equal(m.disponiveis, 2);
  for (const k of ['total_ms', 'coleta_ms', 'geocodificacao_ms', 'normalizacao_ms', 'dedup_ms', 'gravacao_ms']) assert.equal(typeof m[k], 'number', k);
  assert.equal(m.providers.geoapify.resultados, 2);
  assert.equal(m.providers.overpass.chamadas, 1);
});

test('v2: providers rodam em PARALELO (2 × 150 ms ≈ 150 ms, não 300 ms)', async () => {
  const ctx = depsFalsas();
  comEnriquecimentoFalso(ctx);
  ctx.deps.novoFluxo = true;
  const g = ctx.deps.coletar.geoapify; const o = ctx.deps.coletar.overpass;
  ctx.deps.coletar.geoapify = async (...a) => { await esperar(150); return g(...a); };
  ctx.deps.coletar.overpass = async (...a) => { await esperar(150); return o(...a); };
  const job = { id: 'job-par', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } };
  const r = await pipeline.executarPesquisa(job, ctx.deps);
  assert.ok(r.metricas.coleta_ms < 270, `coleta levou ${r.metricas.coleta_ms} ms`);
});

test('v2: provider travado estoura o PRAZO e não segura os outros (erro registrado, resultados do outro mantidos)', async () => {
  const ctx = depsFalsas();
  comEnriquecimentoFalso(ctx);
  ctx.deps.novoFluxo = true;
  ctx.deps.prazosMs = { overpass: 50, geoapify: 1000 };
  ctx.deps.coletar.overpass = () => new Promise(() => {}); // nunca responde
  const job = { id: 'job-prazo', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } };
  const t = Date.now();
  const r = await pipeline.executarPesquisa(job, ctx.deps);
  assert.ok(Date.now() - t < 3500, 'terminou no prazo + folga');
  assert.equal(r.metricas.providers.overpass.erros, 1);
  assert.match(r.metricas.providers.overpass.ultimo_erro, /overpass: sem resposta/);
  assert.equal(r.metricas.providers.geoapify.resultados, 2);
  assert.equal(r.status, 'em_revisao');
});

test('v2: cache — 2ª busca igual não chama o provider; geocodificação também vem do cache', async () => {
  const ctx = depsFalsas();
  comEnriquecimentoFalso(ctx);
  ctx.deps.novoFluxo = true;
  const store = new Map();
  ctx.deps.lerCache = async (k) => (store.has(k) ? { registros: store.get(k) } : null);
  ctx.deps.gravarCache = async (k, prov, params, regs) => { store.set(k, regs); };
  let chamadas = 0; let geos = 0;
  const g = ctx.deps.coletar.geoapify;
  ctx.deps.coletar.geoapify = async (...a) => { chamadas += 1; return g(...a); };
  const geo = ctx.deps.geocodificar;
  ctx.deps.geocodificar = async (c) => { geos += 1; return geo(c); };
  const job = { id: 'job-cache', providers: ['geoapify'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } };
  await pipeline.executarPesquisa(job, ctx.deps);
  await esperar(5);
  const r2 = await pipeline.executarPesquisa({ ...job, id: 'job-cache-2' }, ctx.deps);
  assert.equal(chamadas, 1);
  assert.equal(geos, 1);
  assert.equal(r2.metricas.providers.geoapify.cache, 1);
  assert.equal(r2.encontrados, 2);
});

test('v2: área do mapa — usa lat/lon/raio do job e NÃO geocodifica; área inválida cai nas cidades', async () => {
  const ctx = depsFalsas();
  comEnriquecimentoFalso(ctx);
  ctx.deps.novoFluxo = true;
  let geos = 0; let recebido = null;
  ctx.deps.geocodificar = async () => { geos += 1; return { lat: 1, lon: 1 }; };
  const g = ctx.deps.coletar.geoapify;
  ctx.deps.coletar.geoapify = async (params, ...rest) => { recebido = params; return g(params, ...rest); };
  const job = { id: 'job-area', providers: ['geoapify'], parametros: { setor: 'Construção', cidades: [], area: { latitude: -9.38, longitude: -40.51, raio_metros: 2500 } } };
  await pipeline.executarPesquisa(job, ctx.deps);
  assert.equal(geos, 0);
  assert.deepEqual([recebido.lat, recebido.lon, recebido.raioKm], [-9.38, -40.51, 2.5]);
  assert.equal(pipeline.areaValida({ latitude: 48.8, longitude: 2.3, raio_metros: 1000 }), null, 'fora do Brasil');
  assert.equal(pipeline.areaValida({ latitude: -9.3, longitude: -40.5, raio_metros: 100000 }), null, 'raio acima de 30 km');
  assert.equal(pipeline.areaValida({ latitude: 'x', longitude: -40.5, raio_metros: 1000 }), null);
});

test('v2: falha ao checar um site vira status "erro" naquele registro e não derruba o job', async () => {
  const ctx = depsFalsas();
  const gravacoes = comEnriquecimentoFalso(ctx);
  ctx.deps.novoFluxo = true;
  ctx.deps.verificarSite = async () => { throw new Error('bug inesperado'); };
  const job = { id: 'job-enr-erro', providers: ['geoapify'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } };
  const r = await pipeline.executarPesquisa(job, ctx.deps);
  assert.equal(r.status, 'em_revisao');
  assert.equal(gravacoes[0].dados.status, 'erro');
  assert.equal(r.metricas.enriquecimento.erro, 1);
});

test('limitador: nunca passa de N execuções simultâneas', async () => {
  const lim = pipeline.limitador(2);
  let ativos = 0; let pico = 0;
  await Promise.all(Array.from({ length: 6 }, () => lim(async () => { ativos += 1; pico = Math.max(pico, ativos); await esperar(10); ativos -= 1; })));
  assert.equal(pico, 2);
});

// ---------- Fase 3: captura progressiva ----------
function depsProgressivas({ atrasoOverpass = 0, overpassRegs, falhaOverpass } = {}) {
  const ctx = depsFalsas();
  comEnriquecimentoFalso(ctx);
  ctx.deps.novoFluxo = true;
  ctx.atualizacoesCaptura = [];
  ctx.deps.atualizarCaptura = async (jobId, prov, ext, campos) => { ctx.atualizacoesCaptura.push({ ext, campos }); };
  ctx.deps.coletar.geoapify = async () => ({ registros: [
    registro({ provider: 'geoapify', external_id: 'geoapify:x', empresa: 'Empresa X Engenharia', cidade: 'Petrolina', lat: -9.39, lon: -40.5 }),
  ], avisos: [] });
  ctx.deps.coletar.overpass = async () => {
    await esperar(atrasoOverpass);
    if (falhaOverpass) throw new Error(falhaOverpass);
    return { registros: overpassRegs || [
      registro({ provider: 'overpass', external_id: 'osm:node/x', empresa: 'Empresa X Engenharia', cidade: 'Petrolina', site: 'https://empresax.com.br', telefone: '(87) 3861-0001', lat: -9.39, lon: -40.5 }),
      registro({ provider: 'overpass', external_id: 'osm:node/y', empresa: 'Empresa Y', cidade: 'Petrolina' }),
      registro({ provider: 'overpass', external_id: 'osm:node/z', empresa: 'Empresa Z', cidade: 'Petrolina' }),
    ], avisos: [] };
  };
  return ctx;
}

test('progressivo: primeiros resultados ANTES do provider lento (TTFR < TTLC) e job já revisável', async () => {
  const ctx = depsProgressivas({ atrasoOverpass: 300 });
  const marcas = [];
  const atualizar = ctx.deps.atualizarJob;
  ctx.deps.atualizarJob = async (id, c) => { if (c.status === 'em_revisao') marcas.push({ t: Date.now(), etapa: c.etapa }); return atualizar(id, c); };
  const t0 = Date.now();
  const r = await pipeline.executarPesquisa({ id: 'job-ttfr', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } }, ctx.deps);
  assert.ok(marcas[0].t - t0 < 200, `1º resultado em ${marcas[0].t - t0} ms`);
  assert.equal(marcas[0].etapa, 'coleta', 'revisável com a coleta ainda em andamento');
  assert.ok(r.metricas.ttfr_ms < 200 && r.metricas.ttlc_ms >= 300, `ttfr ${r.metricas.ttfr_ms} / ttlc ${r.metricas.ttlc_ms}`);
  assert.equal(r.metricas.providers.geoapify.status, 'concluido');
  assert.equal(r.metricas.providers.overpass.status, 'concluido');
});

test('progressivo: o 2º provider NÃO duplica — X é completado (site/telefone), Y e Z entram', async () => {
  const ctx = depsProgressivas({ atrasoOverpass: 20 });
  const r = await pipeline.executarPesquisa({ id: 'job-dup', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } }, ctx.deps);
  const empresas = [...ctx.banco.values()].map((l) => l.empresa).sort();
  assert.deepEqual(empresas, ['Empresa X Engenharia', 'Empresa Y', 'Empresa Z']);
  const upd = ctx.atualizacoesCaptura.find((u) => u.ext === 'geoapify:x');
  assert.ok(upd, 'registro já exibido foi completado');
  assert.equal(upd.campos.site, 'https://empresax.com.br');
  assert.ok(!upd.campos.sinais.some((s) => s.tipo === 'SEM_SITE'), 'SEM_SITE removido quando outra fonte trouxe o site');
  assert.equal(upd.campos.enriquecimento_status, 'pendente');
  assert.equal(r.metricas.duplicados, 1);
  assert.equal(r.metricas.providers.overpass.novos, 2);
});

test('progressivo: Overpass estoura o orçamento → status "timeout" SÓ nele; Geoapify válido; captura não falha', async () => {
  const ctx = depsProgressivas({ atrasoOverpass: 2000 });
  ctx.deps.prazosMs = { overpass: 40, geoapify: 1000 };
  const r = await pipeline.executarPesquisa({ id: 'job-to', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } }, ctx.deps);
  assert.equal(r.metricas.providers.overpass.status, 'timeout');
  assert.equal(r.metricas.providers.geoapify.status, 'concluido');
  assert.equal(r.status, 'em_revisao');
  assert.equal([...ctx.banco.values()].length, 1);
});

test('progressivo: SEM_SITE cita só as fontes que já tinham respondido (evidência verdadeira no momento)', async () => {
  const ctx = depsProgressivas({ atrasoOverpass: 50, overpassRegs: [] });
  await pipeline.executarPesquisa({ id: 'job-ev', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } }, ctx.deps);
  const x = [...ctx.banco.values()][0];
  const s = x.sinais.find((y) => y.tipo === 'SEM_SITE');
  assert.match(s.evidencia, /Geoapify/);
  assert.doesNotMatch(s.evidencia, /OpenStreetMap/);
});

test('saúde: host em cooldown vai para o fim; melhor taxa de sucesso primeiro; sem histórico mantém a ordem', () => {
  const saude = require('../netlify/functions/_lib/captacao/saude');
  const urls = ['https://a.de/i', 'https://b.de/i', 'https://c.de/i'];
  const futuro = new Date(Date.now() + 60000).toISOString();
  const ord = saude.ordenar(urls, [
    { host: 'a.de', tentativas: 10, sucessos: 9, latencia_media_ms: 900, cooldown_ate: futuro },
    { host: 'b.de', tentativas: 10, sucessos: 2, latencia_media_ms: 300 },
    { host: 'c.de', tentativas: 10, sucessos: 8, latencia_media_ms: 1200 },
  ]);
  assert.deepEqual(ord, ['https://c.de/i', 'https://b.de/i', 'https://a.de/i']);
  assert.deepEqual(saude.ordenar(urls, []), urls);
});

test('saúde: cada tentativa no espelho é registrada com host, status e duração', async () => {
  const ctx = depsProgressivas();
  const regs = [];
  ctx.deps.registrarSaude = async (host, prov, status, ms) => { regs.push({ host, prov, status }); };
  ctx.deps.coletar.overpass = async (params, opcoes) => { opcoes.registrar('overpass-api.de', '429', 120); opcoes.registrar('overpass.kumi.systems', 'ok', 900); return { registros: [], avisos: [] }; };
  const r = await pipeline.executarPesquisa({ id: 'job-s', providers: ['geoapify', 'overpass'], parametros: { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15 } }, ctx.deps);
  assert.deepEqual(regs.map((x) => x.status), ['429', 'ok']);
  assert.equal(r.metricas.hosts.length, 2);
});
