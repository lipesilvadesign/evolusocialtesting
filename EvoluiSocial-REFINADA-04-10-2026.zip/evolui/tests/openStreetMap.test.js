const test = require('node:test');
const assert = require('node:assert/strict');

const MODULE_PATH = require.resolve('../netlify/functions/_lib/integrations/openStreetMap.js');

/** Recarrega o módulo do zero — ele guarda "qual espelho funcionou por
 * último" em variável de módulo, e cada teste precisa começar limpo. */
function carregarModuloFresco() {
  delete require.cache[MODULE_PATH];
  return require(MODULE_PATH);
}

test('buscarEmpresasOSM: pula espelho com erro de rede e espelho com 406, usa o que funciona', async () => {
  const osm = carregarModuloFresco();
  const chamadas = [];
  global.fetch = async (url) => {
    chamadas.push(url);
    if (url.includes('kumi.systems')) throw new Error('ECONNREFUSED (simulado)');
    if (url.includes('overpass-api.de')) return { ok: false, status: 406 };
    if (url.includes('private.coffee')) {
      return { ok: true, json: async () => ({ elements: [{ type: 'node', id: 1, tags: { name: 'Empresa Teste' } }] }) };
    }
    throw new Error('não deveria chegar a este espelho: ' + url);
  };

  const elementos = await osm.buscarEmpresasOSM('construtora', -9.38, -40.5);
  assert.equal(elementos.length, 1);
  assert.equal(elementos[0].tags.name, 'Empresa Teste');
  assert.equal(chamadas.length, 3, 'deveria ter tentado exatamente 3 espelhos');
});

test('buscarEmpresasOSM: lembra o último espelho que funcionou dentro da mesma execução', async () => {
  const osm = carregarModuloFresco();
  global.fetch = async (url) => {
    if (url.includes('kumi.systems')) throw new Error('fora do ar (simulado)');
    if (url.includes('overpass-api.de')) return { ok: true, json: async () => ({ elements: [] }) };
    throw new Error('não deveria chegar aqui: ' + url);
  };
  await osm.buscarEmpresasOSM('indústria', -9.38, -40.5); // kumi falha, overpass-api.de funciona

  const chamadasSegundaCidade = [];
  global.fetch = async (url) => {
    chamadasSegundaCidade.push(url);
    return { ok: true, json: async () => ({ elements: [] }) };
  };
  await osm.buscarEmpresasOSM('indústria', -9.5, -40.6);

  assert.ok(chamadasSegundaCidade[0].includes('overpass-api.de'), 'deveria já começar pelo espelho que funcionou antes');
});

test('buscarEmpresasOSM: quando todos os espelhos falham, o erro lista todos', async () => {
  const osm = carregarModuloFresco();
  global.fetch = async () => ({ ok: false, status: 406 });
  await assert.rejects(
    () => osm.buscarEmpresasOSM('atacado', -9.38, -40.5),
    (err) => {
      assert.match(err.message, /Todos os espelhos/);
      osm.OVERPASS_MIRRORS.forEach((m) => assert.ok(err.message.includes(m), `erro deveria mencionar ${m}`));
      return true;
    }
  );
});

test('buscarEmpresasOSM: resposta 200 sem "elements" válido é tratada como falha desse espelho', async () => {
  const osm = carregarModuloFresco();
  global.fetch = async (url) => {
    if (url.includes('kumi.systems')) return { ok: true, json: async () => ({ nao_tem_elements: true }) };
    return { ok: true, json: async () => ({ elements: [{ type: 'way', id: 9, tags: { name: 'Ok' } }] }) };
  };
  const elementos = await osm.buscarEmpresasOSM('hotel', -9.38, -40.5);
  assert.equal(elementos.length, 1);
});

test('buscarEmpresasOSM: espelho que trava é abortado por timeout e o próximo é usado', async () => {
  process.env.OSM_TIMEOUT_MS = '200';
  const osm = carregarModuloFresco();
  global.fetch = async (url, opts) => {
    if (url.includes('kumi.systems')) {
      return new Promise((_resolve, reject) => {
        opts.signal.addEventListener('abort', () => {
          const err = new Error('aborted');
          err.name = 'AbortError';
          reject(err);
        });
      });
    }
    return { ok: true, json: async () => ({ elements: [{ type: 'node', id: 1, tags: { name: 'Sobreviveu ao timeout' } }] }) };
  };

  const inicio = Date.now();
  const elementos = await osm.buscarEmpresasOSM('teste', -9, -40);
  const duracao = Date.now() - inicio;

  assert.equal(elementos.length, 1);
  assert.ok(duracao < 2000, `não deveria esperar os 20s completos (durou ${duracao}ms)`);
  delete process.env.OSM_TIMEOUT_MS;
});

test('geocodeCidade: Nominatim falha → cai pro Photon e inverte lon/lat corretamente', async () => {
  const osm = carregarModuloFresco();
  global.fetch = async (url) => {
    if (url.includes('nominatim')) throw new Error('timeout (simulado)');
    if (url.includes('photon')) return { ok: true, json: async () => ({ features: [{ geometry: { coordinates: [-40.5, -9.38] } }] }) };
    throw new Error('URL inesperada: ' + url);
  };
  const coords = await osm.geocodeCidade('Petrolina, PE');
  assert.equal(coords.lat, -9.38);
  assert.equal(coords.lon, -40.5);
});

test('geocodeCidade: Nominatim responde OK mas vazio → tenta Photon mesmo assim', async () => {
  const osm = carregarModuloFresco();
  global.fetch = async (url) => {
    if (url.includes('nominatim')) return { ok: true, json: async () => [] };
    if (url.includes('photon')) return { ok: true, json: async () => ({ features: [{ geometry: { coordinates: [-38.0, -9.0] } }] }) };
  };
  const coords = await osm.geocodeCidade('Cidade Muito Pequena, PE');
  assert.equal(coords.lat, -9.0);
});

test('geocodeCidade: Nominatim e Photon falham → erro final deixa isso claro', async () => {
  const osm = carregarModuloFresco();
  global.fetch = async () => { throw new Error('rede fora do ar'); };
  await assert.rejects(() => osm.geocodeCidade('Lugar Nenhum'), /Nominatim e Photon falharam/);
});

test('postOverpassQuery: usado pelo job semanal, também aplica o fallback entre espelhos', async () => {
  const osm = carregarModuloFresco();
  const chamadas = [];
  global.fetch = async (url) => {
    chamadas.push(url);
    if (url.includes('overpass-api.de')) return { ok: false, status: 406 }; // queda real medida em 01/10
    return { ok: true, json: async () => ({ elements: [{ type: 'node', id: 42, tags: { name: 'Construtora Encontrada Pelo Job Semanal' } }] }) };
  };
  const query = '[out:json][timeout:55];(node["name"~"construtora",i](around:90000,-9.3891,-40.503););out center tags;';
  const elementos = await osm.postOverpassQuery(query);
  assert.equal(elementos.length, 1);
  assert.equal(elementos[0].tags.name, 'Construtora Encontrada Pelo Job Semanal');
  assert.equal(chamadas.length, 2);
});

test('postOverpassQuery: manda User-Agent identificado (sem ele o overpass-api.de responde 406)', async () => {
  const osm = carregarModuloFresco();
  let ua = null;
  global.fetch = async (url, opts) => { ua = opts.headers['User-Agent']; return { ok: true, json: async () => ({ elements: [] }) }; };
  await osm.postOverpassQuery('query');
  assert.match(ua, /FelipeBrandingProspeccao\/1\.0/);
});

test('postOverpassQuery: 429 com espelhos sobrando pula na hora para o próximo (sem esperar)', async () => {
  const osm = carregarModuloFresco();
  const chamadas = [];
  const inicio = Date.now();
  global.fetch = async (url) => {
    chamadas.push(url);
    if (url.includes('overpass-api.de')) return { ok: false, status: 429, headers: { get: () => '30' } };
    return { ok: true, json: async () => ({ elements: [{ type: 'node', id: 2, tags: { name: 'Segundo espelho' } }] }) };
  };
  const elementos = await osm.postOverpassQuery('query');
  assert.equal(chamadas.filter((c) => c.includes('overpass-api.de')).length, 1);
  assert.equal(elementos[0].tags.name, 'Segundo espelho');
  assert.ok(Date.now() - inicio < 500, 'não esperou o Retry-After de 30 s');
});

test('postOverpassQuery: no ÚLTIMO espelho, 429 tenta de novo respeitando Retry-After (com teto)', async () => {
  const osm = carregarModuloFresco();
  const ultimo = osm.OVERPASS_MIRRORS[osm.OVERPASS_MIRRORS.length - 1];
  let noUltimo = 0;
  const inicio = Date.now();
  global.fetch = async (url) => {
    if (url !== ultimo) return { ok: false, status: 503 };
    noUltimo += 1;
    if (noUltimo === 1) return { ok: false, status: 429, headers: { get: (h) => (h === 'retry-after' ? '1' : null) } };
    return { ok: true, json: async () => ({ elements: [{ type: 'node', id: 1, tags: { name: 'Recuperou depois do 429' } }] }) };
  };
  const elementos = await osm.postOverpassQuery('query');
  assert.equal(noUltimo, 2);
  assert.equal(elementos[0].tags.name, 'Recuperou depois do 429');
  assert.ok(Date.now() - inicio >= 950, 'esperou ~1 s (Retry-After: 1)');
});

test('postOverpassQuery: 429 persistente no último espelho desiste depois da 2ª tentativa', async () => {
  const osm = carregarModuloFresco();
  let n = 0;
  global.fetch = async () => { n += 1; return { ok: false, status: 429, headers: { get: () => '0' } }; };
  await assert.rejects(() => osm.postOverpassQuery('query'), /espelhos/);
  assert.equal(n, osm.OVERPASS_MIRRORS.length + 1, '1 tentativa por espelho + 1 extra no último');
});

test('elementToLead: sem site → prioridade alta; com site → prioridade média', () => {
  const osm = carregarModuloFresco();
  const semSite = osm.elementToLead({ type: 'node', id: 1, tags: { name: 'Empresa A' } }, 'Petrolina, PE', 'Construtora');
  assert.equal(semSite.prioridade, 'alta');

  const comSite = osm.elementToLead(
    { type: 'node', id: 2, tags: { name: 'Empresa B', website: 'https://x.com' } },
    'Petrolina, PE',
    'Construtora'
  );
  assert.equal(comSite.prioridade, 'media');

  const semNome = osm.elementToLead({ type: 'way', id: 3, tags: {} }, 'Petrolina, PE', 'Construtora');
  assert.equal(semNome, null);
});

test('elementToLead: embute fonte="osm_manual" (busca combina Geoapify + OSM na mesma chamada, precisa saber de onde veio cada lead)', () => {
  const osm = carregarModuloFresco();
  const lead = osm.elementToLead({ type: 'node', id: 1, tags: { name: 'Empresa A' } }, 'Petrolina, PE', 'Construtora');
  assert.equal(lead.fonte, 'osm_manual');
});

test('buscarEmpresasOSM: usa o RADICAL da palavra na query, não a palavra inteira (bug real: "construção" não bate com "Construtora"/"Construções" como substring literal)', async () => {
  const osm = carregarModuloFresco();
  let queryEnviada = null;
  global.fetch = async (url, opts) => {
    queryEnviada = opts.body;
    return { ok: true, json: async () => ({ elements: [] }) };
  };
  await osm.buscarEmpresasOSM('construção', -9.38, -40.5);
  assert.ok(queryEnviada.includes('"constr"'), `query deveria usar o radical "constr", não a palavra inteira. Query enviada: ${queryEnviada}`);
  assert.ok(!queryEnviada.includes('"construção"'), 'query NÃO deveria conter a palavra inteira "construção" (não bate com "Construtora"/"Construções" como substring)');
});
