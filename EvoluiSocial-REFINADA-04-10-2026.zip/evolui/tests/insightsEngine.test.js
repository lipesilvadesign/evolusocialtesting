const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeSnapshot } = require('../netlify/functions/_lib/analyticsNormalizer');
const { generateInsights } = require('../netlify/functions/_lib/insightsEngine');

function baseRaw(overrides = {}) {
  return {
    rangeLabel: 'teste',
    overview: {
      current: { metrics: { activeUsers: 100, sessions: 120, screenPageViews: 300, engagementRate: 40, averageSessionDuration: 30 }, isEmpty: false },
      previous: { metrics: { activeUsers: 100, sessions: 120, screenPageViews: 300, engagementRate: 40, averageSessionDuration: 30 }, isEmpty: false },
    },
    pages: { current: [], previous: [] },
    events: { current: [], previous: [] },
    trafficSources: { current: [], previous: [] },
    devices: { current: [] },
    ...overrides,
  };
}

test('insightsEngine: crescimento significativo de usuários gera insight positivo', () => {
  const raw = baseRaw({
    overview: {
      current: { metrics: { activeUsers: 200, sessions: 120, screenPageViews: 300, engagementRate: 40, averageSessionDuration: 30 }, isEmpty: false },
      previous: { metrics: { activeUsers: 100, sessions: 120, screenPageViews: 300, engagementRate: 40, averageSessionDuration: 30 }, isEmpty: false },
    },
  });
  const insights = generateInsights(normalizeSnapshot(raw));
  const found = insights.find((i) => i.type === 'positive' && i.metric === 'activeUsers');
  assert.ok(found, 'esperava um insight positivo de crescimento de usuários');
});

test('insightsEngine: queda significativa gera alerta', () => {
  const raw = baseRaw({
    overview: {
      current: { metrics: { activeUsers: 50, sessions: 60, screenPageViews: 150, engagementRate: 40, averageSessionDuration: 30 }, isEmpty: false },
      previous: { metrics: { activeUsers: 100, sessions: 120, screenPageViews: 300, engagementRate: 40, averageSessionDuration: 30 }, isEmpty: false },
    },
  });
  const insights = generateInsights(normalizeSnapshot(raw));
  const found = insights.find((i) => i.type === 'alert' && i.metric === 'activeUsers');
  assert.ok(found, 'esperava um alerta de queda de usuários');
});

test('insightsEngine: sem tráfego nenhum, não gera insight nenhum (sem inventar dado)', () => {
  const raw = baseRaw({
    overview: {
      current: { metrics: { activeUsers: 0, sessions: 0, screenPageViews: 0, engagementRate: 0, averageSessionDuration: 0 }, isEmpty: true },
      previous: null,
    },
  });
  const insights = generateInsights(normalizeSnapshot(raw));
  assert.equal(insights.length, 0);
});

test('insightsEngine: nunca usa linguagem causal ("aconteceu porque") nas descrições', () => {
  const raw = baseRaw({
    overview: {
      current: { metrics: { activeUsers: 300, sessions: 120, screenPageViews: 300, engagementRate: 20, averageSessionDuration: 30 }, isEmpty: false },
      previous: { metrics: { activeUsers: 100, sessions: 120, screenPageViews: 300, engagementRate: 55, averageSessionDuration: 30 }, isEmpty: false },
    },
  });
  const insights = generateInsights(normalizeSnapshot(raw));
  insights.forEach((i) => {
    assert.doesNotMatch(i.description.toLowerCase(), /\baconteceu porque\b/);
  });
});
