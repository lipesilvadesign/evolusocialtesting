const test = require('node:test');
const assert = require('node:assert/strict');

const UMBLER_PATH = require.resolve('../netlify/functions/_lib/integrations/umblerSmtp.js');
const SERVICE_PATH = require.resolve('../netlify/functions/_lib/services/siteContatosService.js');
const FN_PATH = require.resolve('../netlify/functions/contato-criar.js');
const JOB_PATH = require.resolve('../netlify/functions/scheduled-sync-background.js');
const LIMITER_PATH = require.resolve('../netlify/functions/_lib/rateLimiter.js');

function carregar({ falharEmail = false } = {}) {
  const emails = [];
  require.cache[UMBLER_PATH] = {
    id: UMBLER_PATH, filename: UMBLER_PATH, loaded: true,
    exports: { async enviarEmail(msg) { emails.push(msg); if (falharEmail) throw new Error('SMTP recusou'); } },
  };
  for (const p of [SERVICE_PATH, FN_PATH, JOB_PATH, LIMITER_PATH]) delete require.cache[p];
  return { emails, fn: require(FN_PATH), service: require(SERVICE_PATH), job: require(JOB_PATH) };
}

function mockFetch(respostas = {}) {
  const chamadas = [];
  global.fetch = async (url, opts = {}) => {
    chamadas.push({ url: String(url), opts, body: opts.body ? JSON.parse(opts.body) : null });
    for (const [trecho, resp] of Object.entries(respostas)) {
      if (String(url).includes(trecho)) {
        const r = typeof resp === 'function' ? resp(url, opts) : resp;
        return { ok: (r.status || 200) < 400, status: r.status || 200, json: async () => r.json, text: async () => JSON.stringify(r.json || '') };
      }
    }
    return { ok: true, status: 201, json: async () => true, text: async () => '' };
  };
  return chamadas;
}

const VALIDO = {
  nome: '  Maria   Souza ', email: 'Maria@Loja.com', whatsapp: '(87) 99999-0000',
  servico: 'Identidade Visual', orcamento: '3-8k', mensagem: 'Quero uma marca nova para a loja.',
};
const ev = (body, ip = '1.1.1.1') => ({ httpMethod: 'POST', headers: { 'x-nf-client-connection-ip': ip }, body: JSON.stringify(body) });

test('contato-criar: grava só os campos do formulário, com id gerado, e manda aviso com Reply-To do visitante', async () => {
  process.env.UMBLER_SMTP_USER = 'marketing@felipebranding.com.br';
  process.env.UMBLER_SMTP_PASS = 'x';
  delete process.env.CONTATO_EMAIL_DESTINO;
  const { fn, emails } = carregar();
  const chamadas = mockFetch();
  const r = await fn.handler(ev(VALIDO));
  assert.equal(r.statusCode, 201);
  const insert = chamadas.find((c) => c.url.endsWith('/rest/v1/site_contatos'));
  assert.ok(insert, 'deveria gravar em site_contatos');
  assert.equal(insert.opts.headers.Prefer, 'return=minimal');
  assert.deepEqual(Object.keys(insert.body).sort(), ['email', 'id', 'mensagem', 'nome', 'orcamento', 'origem', 'servico', 'whatsapp']);
  assert.equal(insert.body.nome, 'Maria Souza');
  assert.equal(insert.body.email, 'maria@loja.com');
  assert.equal(insert.body.whatsapp, '87999990000');
  assert.equal(emails.length, 1);
  assert.equal(emails[0].para, 'marketing@felipebranding.com.br', 'sem CONTATO_EMAIL_DESTINO, avisa a própria caixa que envia');
  assert.equal(emails[0].responderPara, 'maria@loja.com');
  assert.match(emails[0].corpo, /wa\.me\/5587999990000/);
  const rpc = chamadas.find((c) => c.url.includes('/rpc/site_contato_registrar_email'));
  assert.deepEqual(rpc.body, { p_id: insert.body.id, p_status: 'enviado', p_erro: null });
});

test('contato-criar: SMTP falhando não perde o contato — responde 201 e registra "falhou"', async () => {
  process.env.UMBLER_SMTP_USER = 'u'; process.env.UMBLER_SMTP_PASS = 'p';
  const { fn } = carregar({ falharEmail: true });
  const chamadas = mockFetch();
  const r = await fn.handler(ev(VALIDO, '2.2.2.2'));
  assert.equal(r.statusCode, 201);
  const rpc = chamadas.find((c) => c.url.includes('/rpc/site_contato_registrar_email'));
  assert.equal(rpc.body.p_status, 'falhou');
  assert.match(rpc.body.p_erro, /SMTP recusou/);
});

test('contato-criar: sem SMTP configurado registra "sem_smtp" e não tenta enviar', async () => {
  delete process.env.UMBLER_SMTP_USER; delete process.env.UMBLER_SMTP_PASS;
  const { fn, emails } = carregar();
  const chamadas = mockFetch();
  const r = await fn.handler(ev(VALIDO, '3.3.3.3'));
  assert.equal(r.statusCode, 201);
  assert.equal(emails.length, 0);
  assert.equal(chamadas.find((c) => c.url.includes('/rpc/')).body.p_status, 'sem_smtp');
});

test('contato-criar: banco fora do ar → 502 com mensagem amigável, sem detalhe técnico', async () => {
  const { fn, emails } = carregar();
  mockFetch({ '/rest/v1/site_contatos': { status: 500, json: { message: 'relation "site_contatos" does not exist' } } });
  const r = await fn.handler(ev(VALIDO, '4.4.4.4'));
  assert.equal(r.statusCode, 502);
  assert.doesNotMatch(r.body, /relation|site_contatos/);
  assert.equal(emails.length, 0);
});

test('contato-criar: valida campos, honeypot e método', async () => {
  const { fn } = carregar();
  const chamadas = mockFetch();
  const r1 = await fn.handler(ev({ ...VALIDO, email: 'x', whatsapp: '123', servico: 'Hack', mensagem: 'oi' }, '5.5.5.5'));
  assert.equal(r1.statusCode, 400);
  assert.deepEqual(Object.keys(JSON.parse(r1.body).campos).sort(), ['email', 'mensagem', 'servico', 'whatsapp']);
  const r2 = await fn.handler(ev({ ...VALIDO, fb_hp_campo_vazio: 'bot' }, '5.5.5.6'));
  assert.equal(r2.statusCode, 201);
  assert.equal(chamadas.length, 0, 'honeypot não grava nada');
  assert.equal((await fn.handler({ httpMethod: 'GET', headers: {} })).statusCode, 405);
  assert.equal((await fn.handler({ httpMethod: 'POST', headers: {}, body: '{quebrado' })).statusCode, 400);
});

test('contato-criar: limita a 5 envios por IP em 15 minutos', async () => {
  delete process.env.UMBLER_SMTP_USER;
  const { fn } = carregar();
  mockFetch();
  for (let i = 0; i < 5; i++) assert.equal((await fn.handler(ev(VALIDO, '9.9.9.9'))).statusCode, 201);
  assert.equal((await fn.handler(ev(VALIDO, '9.9.9.9'))).statusCode, 429);
});

test('job agendado: reenvia avisos pendentes e marca "enviado"', async () => {
  process.env.UMBLER_SMTP_USER = 'u'; process.env.UMBLER_SMTP_PASS = 'p';
  const { job, emails } = carregar();
  const pend = { id: 'c1', nome: 'Ana', email: 'a@x.com', whatsapp: '87999990000', servico: 'Design Gráfico', mensagem: 'Oi, tudo bem com vocês?', email_tentativas: 1, created_at: new Date().toISOString() };
  const chamadas = mockFetch({ 'site_contatos?select=': { json: [pend] } });
  const origSetTimeout = global.setTimeout; global.setTimeout = (f) => origSetTimeout(f, 0);
  const r = await job._internos.runVerificacaoEmailsContatos('service-key');
  global.setTimeout = origSetTimeout;
  assert.deepEqual(r, { pendentes: 1, enviados: 1, desistidos: 0 });
  assert.equal(emails.length, 1);
  const patch = chamadas.find((c) => c.opts.method === 'PATCH');
  assert.equal(patch.body.email_status, 'enviado');
  assert.equal(patch.body.email_tentativas, 2);
});

test('job agendado: sem SMTP avisa no sino (uma vez por dia) e não envia', async () => {
  delete process.env.UMBLER_SMTP_USER; delete process.env.UMBLER_SMTP_PASS;
  const { job } = carregar();
  const pend = { id: 'c1', nome: 'Ana', email_tentativas: 0 };
  let chamadas = mockFetch({ 'site_contatos?select=': { json: [pend] }, 'admin_notificacoes?select=id': { json: [] } });
  const r = await job._internos.runVerificacaoEmailsContatos('k');
  assert.equal(r.semSmtp, true);
  const notif = chamadas.find((c) => c.url.endsWith('/rest/v1/admin_notificacoes') && c.opts.method === 'POST');
  assert.equal(notif.body.metadata.alerta, 'contatos_sem_smtp');
  chamadas = mockFetch({ 'site_contatos?select=': { json: [pend] }, 'admin_notificacoes?select=id': { json: [{ id: 'n1' }] } });
  await job._internos.runVerificacaoEmailsContatos('k');
  assert.equal(chamadas.filter((c) => c.opts.method === 'POST').length, 0, 'não repete o alerta no mesmo dia');
});

test('job agendado: na 5ª falha desiste e avisa no sino como erro', async () => {
  process.env.UMBLER_SMTP_USER = 'u'; process.env.UMBLER_SMTP_PASS = 'p';
  const { job } = carregar({ falharEmail: true });
  const pend = { id: 'c9', nome: 'Beto', email: 'b@x.com', whatsapp: '87999990000', servico: 'Design Gráfico', mensagem: 'Mensagem de teste', email_tentativas: 4 };
  const chamadas = mockFetch({ 'site_contatos?select=': { json: [pend] } });
  const origSetTimeout = global.setTimeout; global.setTimeout = (f) => origSetTimeout(f, 0);
  const r = await job._internos.runVerificacaoEmailsContatos('k');
  global.setTimeout = origSetTimeout;
  assert.equal(r.desistidos, 1);
  const notif = chamadas.find((c) => c.url.endsWith('/rest/v1/admin_notificacoes'));
  assert.equal(notif.body.tipo, 'erro');
});

test('montarAviso: texto simples com dados do contato e link do painel', () => {
  const { service } = carregar();
  const { assunto, corpo } = service.montarAviso({ ...VALIDO, nome: 'Maria', whatsapp: '87999990000', created_at: '2026-09-29T12:00:00Z' });
  assert.match(assunto, /Maria/);
  assert.match(corpo, /\(87\) 99999-0000/);
  assert.match(corpo, /R\$3 a 8 mil/);
  assert.match(corpo, /painel\/#\/contatos-site/);
  assert.doesNotMatch(corpo, /<[a-z]/i);
});
