const test = require('node:test');
const assert = require('node:assert/strict');

async function modulos() {
  const consulta = await import('../supabase/functions/evolui-api/consulta.ts');
  const plano = await import('../supabase/functions/evolui-api/eie/pesquisa/plano.ts');
  return { ...consulta, ...plano };
}

test('entendimento: ideia local não vira intenção de mercado', async () => {
  const { entender } = await modulos();
  const c = entender('quero ideias de reels para barbearia em Caruaru');
  assert.equal(c.assunto, 'barbearia');
  assert.equal(c.localizacao, 'Caruaru');
  assert.deepEqual(c.intencoes.map((x) => x.id), ['ideias']);
  assert.equal(c.formato, 'reels');
});

test('entendimento: cidades compostas preservam o nome completo', async () => {
  const { entender } = await modulos();
  const c = entender('lojas de maquiagem em juazeiro do norte');
  assert.equal(c.localizacao, 'Juazeiro do Norte');
  assert.equal(c.assunto, 'lojas de maquiagem');
});

test('entendimento: ano é contexto temporal e não assunto', async () => {
  const { entender } = await modulos();
  const c = entender('tendências de skincare em 2026');
  assert.equal(c.ano, '2026');
  assert.equal(c.assunto, 'skincare');
  assert.equal(c.termosBusca.includes('2026'), false);
});

test('planejamento: ramo duplicado não gera busca quase idêntica', async () => {
  const { entender, planejarPesquisa } = await modulos();
  const c = entender('o que está acontecendo no mercado de estética em 2026');
  const p = planejarPesquisa(c, { ramo: 'beleza', ramo_detalhe: 'estética' });
  assert.ok(p.consultas.some((x) => /tendências Brasil/i.test(x.texto)));
  assert.equal(p.consultas.some((x) => /estética estética/i.test(x.texto)), false);
  assert.ok(p.consultas.length <= 10);
});

test('planejamento: ideias ganham camada de aplicabilidade e formatos', async () => {
  const { entender, planejarPesquisa } = await modulos();
  const c = entender('ideias de conteúdo para fisioterapia no Instagram');
  const p = planejarPesquisa(c, { ramo: 'saude', ramo_detalhe: 'fisioterapia' });
  assert.ok(p.consultas.some((x) => /conteúdo.*Instagram.*ideias/i.test(x.texto)));
  assert.ok(p.consultas.some((x) => /reels formatos ganchos/i.test(x.texto)));
});

test('fusão: consolida a mesma URL encontrada em consultas diferentes', async () => {
  const { fundirResultados } = await import('../supabase/functions/evolui-api/eie/pesquisa/fusao.ts');
  const r = fundirResultados([[{
    url: 'https://www.exemplo.com/pagina?utm_source=x', titulo: 'A', snippet: 'um', dominio: 'exemplo.com', publicadoEm: new Date().toISOString(), engines: ['google'], engineCount: 1, queryIds: ['q1'], posicoes: [1],
  }], [{
    url: 'https://www.exemplo.com/pagina#secao', titulo: 'A', snippet: 'um conteúdo maior', dominio: 'exemplo.com', publicadoEm: null, engines: ['bing'], engineCount: 1, queryIds: ['q2'], posicoes: [2],
  }]], 2);
  assert.equal(r.resultados.length, 1);
  assert.deepEqual(r.resultados[0].queryIds.sort(), ['q1', 'q2']);
  assert.deepEqual(r.resultados[0].engines.sort(), ['bing', 'google']);
  assert.equal(r.evidencias[0].evidencia.coberturaQueries, 1);
});

test('orquestrador shadow: usa SearXNG sem alterar o modo quando está desligado', async () => {
  globalThis.Deno = { env: { get(name) {
    if (name === 'PESQUISA_AVANCADA_MODO') return 'off';
    if (name === 'SEARXNG_URL') return '';
    return undefined;
  } } };
  const { rodarPesquisaAvancada } = await import('../supabase/functions/evolui-api/eie/pesquisa/orquestrador.ts');
  const r = await rodarPesquisaAvancada({ consulta: (await import('../supabase/functions/evolui-api/consulta.ts')).entender('ideias para fisioterapia') });
  assert.equal(r.modo, 'off');
  assert.deepEqual(r.resultados, []);
});

test('orquestrador shadow: coleta resultados sintéticos pelo adaptador SearXNG', async () => {
  globalThis.Deno = { env: { get(name) {
    if (name === 'PESQUISA_AVANCADA_MODO') return 'shadow';
    if (name === 'SEARXNG_URL') return 'https://search.example';
    return undefined;
  } } };
  const oldFetch = globalThis.fetch;
  globalThis.fetch = async (url) => {
    assert.match(String(url), /format=json/);
    assert.match(String(url), /language=pt-BR/);
    return new Response(JSON.stringify({ results: [
      { url: 'https://example.com/a', title: 'Resultado', content: 'conteúdo', engines: ['google','bing'], publishedDate: new Date().toISOString() },
    ] }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  try {
    const { rodarPesquisaAvancada } = await import('../supabase/functions/evolui-api/eie/pesquisa/orquestrador.ts?shadowtest=1');
    const { entender } = await import('../supabase/functions/evolui-api/consulta.ts');
    const r = await rodarPesquisaAvancada({ consulta: entender('tendências de skincare em 2026') });
    assert.equal(r.modo, 'shadow');
    assert.ok(r.consultas.length > 0);
    assert.equal(r.resultados.length, 1);
    assert.equal(r.resultados[0].engineCount, 2);
    assert.equal(r.falhas.length, 0);
  } finally {
    globalThis.fetch = oldFetch;
  }
});
