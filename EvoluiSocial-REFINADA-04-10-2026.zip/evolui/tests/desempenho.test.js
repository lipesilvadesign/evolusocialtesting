const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

async function carregarView() {
  const url = 'file://' + path.resolve(__dirname, '../painel/assets/js/views/desempenho.js');
  return import(url);
}

test('calcularDesempenhoPorPessoa: agrupa mensagens/respostas por responsável do lead', async () => {
  const { calcularDesempenhoPorPessoa } = await carregarView();
  const statusAtual = [
    { id: 'l1', responsavel_id: 'p1', status: 'contatado' },
    { id: 'l2', responsavel_id: 'p2', status: 'cliente' },
  ];
  const atividades = [
    { lead_id: 'l1', tipo: 'whatsapp_enviado' },
    { lead_id: 'l1', tipo: 'whatsapp_enviado' },
    { lead_id: 'l2', tipo: 'whatsapp_enviado' },
    { lead_id: 'l2', tipo: 'resposta_recebida' },
  ];
  const funcionarios = [{ id: 'p1', nome: 'Ana' }, { id: 'p2', nome: 'Bruno' }];

  const resultado = calcularDesempenhoPorPessoa(statusAtual, atividades, funcionarios);
  const ana = resultado.find((r) => r.funcionarioId === 'p1');
  const bruno = resultado.find((r) => r.funcionarioId === 'p2');

  assert.equal(ana.mensagensEnviadas, 2);
  assert.equal(ana.respostas, 0);
  assert.equal(bruno.mensagensEnviadas, 1);
  assert.equal(bruno.respostas, 1);
  assert.equal(bruno.conversoes, 1);
});

test('calcularDesempenhoPorPessoa: taxa de resposta só aparece com volume mínimo (nunca uma % enganosa)', async () => {
  const { calcularDesempenhoPorPessoa } = await carregarView();
  const statusAtual = [{ id: 'l1', responsavel_id: 'p1', status: 'contatado' }];
  const atividades = [
    { lead_id: 'l1', tipo: 'whatsapp_enviado' },
    { lead_id: 'l1', tipo: 'resposta_recebida' },
  ];
  const funcionarios = [{ id: 'p1', nome: 'Ana' }];

  const [ana] = calcularDesempenhoPorPessoa(statusAtual, atividades, funcionarios);
  assert.equal(ana.taxaResposta, null, 'Com só 1 mensagem enviada (abaixo do mínimo), não deve calcular taxa.');
});

test('calcularDesempenhoPorPessoa: lead sem responsavel_id ainda conta (agrupado como "Sem responsável")', async () => {
  const { calcularDesempenhoPorPessoa } = await carregarView();
  const statusAtual = [{ id: 'l1', responsavel_id: null, status: 'novo_lead' }];
  const atividades = [{ lead_id: 'l1', tipo: 'whatsapp_enviado' }];
  const resultado = calcularDesempenhoPorPessoa(statusAtual, atividades, []);
  assert.equal(resultado.length, 1);
  assert.equal(resultado[0].nome, 'Sem responsável');
  assert.equal(resultado[0].mensagensEnviadas, 1);
});
