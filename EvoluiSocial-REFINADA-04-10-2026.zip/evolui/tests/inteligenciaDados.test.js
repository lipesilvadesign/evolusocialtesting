import assert from "node:assert/strict";
import { normalizarComportamentoAgregado } from "../supabase/functions/evolui-api/eie/inteligencia-dados.ts";

const vazio = normalizarComportamentoAgregado([]);
assert.equal(vazio.sinais.length, 0);
assert.equal(vazio.protecao.semIdentificadorPessoal, true);

const abaixo = normalizarComportamentoAgregado([{ tema: "maquiagem", volume_atual: 2, volume_anterior: 1, crescimento: 100, confianca: .7 }]);
assert.equal(abaixo.sinais.length, 0);

const ok = normalizarComportamentoAgregado([{ tema: "maquiagem", ramo: "beleza", periodo: "7d_vs_7d", volume_atual: 18, volume_anterior: 9, crescimento: 100, confianca: .9 }]);
assert.equal(ok.sinais.length, 1);
assert.equal(ok.sinais[0].volumeAtual, 18);
assert.equal(ok.sinais[0].crescimento, 100);
console.log("inteligenciaDados.test.js: 3/3 OK");
