const test = require('node:test');
const assert = require('node:assert/strict');

const SVC = require.resolve('../netlify/functions/_lib/services/prospeccaoService.js');
const REST = require.resolve('../netlify/functions/_lib/supabaseRest.js');

function mockFetch(handler) {
  const chamadas = [];
  global.fetch = async (url, opts = {}) => {
    const c = { url: String(url), method: (opts.method || 'GET').toUpperCase(), body: opts.body ? JSON.parse(opts.body) : null, headers: opts.headers || {} };
    chamadas.push(c);
    const r = (await handler(c)) || {};
    const status = r.status || 200;
    const texto = r.json === undefined ? '' : JSON.stringify(r.json);
    return { ok: status < 400, status, headers: { get: (h) => (r.headers || {})[h.toLowerCase()] || null }, text: async () => texto, json: async () => r.json };
  };
  return chamadas;
}
const fresco = () => { delete require.cache[SVC]; delete require.cache[REST]; return require(SVC); };

test('create: grava TODOS os campos válidos do formulário (CNPJ, status, sinais, problema/evidência/oferta)', async () => {
  const svc = fresco();
  const chamadas = mockFetch(() => ({ status: 201, json: [{ id: 'n1' }] }));
  await svc.create('tok', {
    empresa: 'Alfa', cnpj: '11.222.333/0001-81', status: 'contatado', statusLead: 'qualificado', statusContato: 'whatsapp_disponivel',
    sinalPorteMedioGrande: true, sinalSiteDesatualizado: true, sinalInstagramDesorganizado: true, sinalGbpFraco: true,
    problemaIdentificado: 'P', evidenciaProblema: 'E', ofertaRecomendada: 'O', prioridade: 'alta', criadoPor: 'eu@x.com',
    score: 99, scoreMotivos: ['falso'], temperatura: 'quente', origem_id: 'x', arquivadoEm: '2020-01-01', fonte: 'geoapify',
  }, { ehAdmin: true });
  const b = chamadas[0].body;
  assert.equal(b.cnpj, '11.222.333/0001-81');
  assert.equal(b.status, 'contatado');
  assert.equal(b.status_lead, 'qualificado');
  assert.equal(b.status_contato, 'whatsapp_disponivel');
  assert.equal(b.sinal_porte_medio_grande, true);
  assert.equal(b.problema_identificado, 'P');
  assert.equal(b.evidencia_problema, 'E');
  assert.equal(b.oferta_recomendada, 'O');
  assert.equal(b.prioridade, 'alta');
  for (const protegido of ['score', 'score_motivos', 'temperatura', 'origem_id', 'arquivado_em']) assert.ok(!(protegido in b), `${protegido} não pode vir do cliente`);
  assert.equal(b.fonte, 'manual', 'fonte automática não pode ser declarada pelo formulário');
  assert.equal(b.metodo_captacao, 'prospeccao_manual');
});

test('create/update: valores inválidos são recusados com 400', async () => {
  const svc = fresco();
  mockFetch(() => ({ json: [] }));
  await assert.rejects(() => svc.create('t', { empresa: '' }), /obrigatório/);
  await assert.rejects(() => svc.create('t', { empresa: 'A', status: 'hackeado' }), /Status inválido/);
  await assert.rejects(() => svc.create('t', { empresa: 'A', campanha: 'Campanha Com Espaço' }), /Campanha/);
  await assert.rejects(() => svc.create('t', { empresa: 'A', responsavelId: 'outro' }, { ehAdmin: false, userId: 'eu' }), /sua responsabilidade/);
  await assert.rejects(() => svc.update('t', 'id', { responsavelId: 'outro' }, { ehAdmin: false, userId: 'eu' }), /Somente admin/);
});

test('update: score enviado pelo painel antigo é ignorado; corpo vazio do Supabase vira 404 (não sucesso falso)', async () => {
  const svc = fresco();
  const chamadas = mockFetch(() => ({ json: [] }));
  await assert.rejects(() => svc.update('t', 'abc', { score: 90, scoreMotivos: [], empresa: 'X' }), (e) => e.statusCode === 404);
  assert.ok(!('score' in chamadas[0].body));
  mockFetch(() => ({ json: [{ id: 'abc', empresa: 'X' }] }));
  assert.equal((await svc.update('t', 'abc', { empresa: 'X' })).id, 'abc');
});

test('listar: filtros no servidor, arquivados fora por padrão, paginação com teto', async () => {
  const svc = fresco();
  const chamadas = mockFetch(() => ({ json: [], headers: { 'content-range': '0-0/137' } }));
  const r = await svc.listar('t', { q: 'Construção', status: 'contatado,respondeu', faixa: 'prospectar', temperatura: 'quente', tem_site: '0', por_pagina: '999', pagina: '2', responsavel: 'me' }, 'uid-1');
  const u = decodeURIComponent(chamadas[0].url);
  assert.match(u, /empresa_norm=ilike\.\*construcao\*/);
  assert.match(u, /status=in\.\(contatado,respondeu\)/);
  assert.match(u, /score=gte\.61/);
  assert.match(u, /score=lte\.90/);
  assert.match(u, /temperatura=in\.\(quente\)/);
  assert.match(u, /site=is\.null/);
  assert.match(u, /arquivado_em=is\.null/);
  assert.match(u, /responsavel_id=eq\.uid-1/);
  assert.match(u, /limit=100&offset=100/);
  assert.equal(r.total, 137);
  const c2 = svc.montarConsulta({ arquivados: 'so', oportunidade: 'SEM_SITE' });
  assert.ok(c2.partes.includes('arquivado_em=not.is.null'));
  assert.match(c2.select, /admin_prospeccao_oportunidades!inner/);
  assert.equal(svc.montarConsulta({ oportunidade: 'INVENTADA' }).select, '*');
});

test('limite de e-mail: contagem pelo banco (RPC global, fuso de Recife)', async () => {
  const svc = fresco();
  const chamadas = mockFetch(() => ({ json: 7 }));
  assert.equal(await svc.countEmailsSentToday('t'), 7);
  assert.match(chamadas[0].url, /rpc\/prospeccao_emails_enviados_hoje/);
  mockFetch(() => ({ json: null }));
  await assert.rejects(() => svc.countEmailsSentToday('t'), /permissão/);
});

test('limpeza automática ARQUIVA (PATCH), nunca DELETE; respeita próxima ação agendada', async () => {
  const JOB = require.resolve('../netlify/functions/scheduled-sync-background.js');
  const NOTIF = require.resolve('../netlify/functions/_lib/services/notificationsService.js');
  delete require.cache[JOB];
  const notificacoes = [];
  require.cache[NOTIF] = { id: NOTIF, filename: NOTIF, loaded: true, exports: { create: async (_k, n) => notificacoes.push(n) } };
  const { _internos } = require(JOB);
  const velho = new Date(Date.now() - 60 * 86400000).toISOString();
  const futuro = new Date(Date.now() + 86400000).toISOString();
  const chamadas = mockFetch((c) => {
    if (c.method === 'GET') return { json: [
      { id: 'a', empresa: 'Parado', status: 'contatado', created_at: velho, ultima_atividade_em: null, proxima_atividade_em: null },
      { id: 'b', empresa: 'Agendado', status: 'contatado', created_at: velho, proxima_atividade_em: futuro },
      { id: 'c', empresa: 'Recente', status: 'novo_lead', created_at: velho, ultima_atividade_em: new Date().toISOString() },
    ] };
    if (c.method === 'PATCH') return { json: [{ id: 'a', empresa: 'Parado' }] };
    return { json: [] };
  });
  const n = await _internos.runStaleLeadCleanup('service-key');
  assert.equal(n, 1);
  assert.ok(!chamadas.some((c) => c.method === 'DELETE'), 'nenhum DELETE');
  const patch = chamadas.find((c) => c.method === 'PATCH');
  assert.match(patch.url, /id=in\.\(a\)/);
  assert.deepEqual(Object.keys(patch.body).sort(), ['arquivado_em', 'arquivado_por', 'motivo_arquivamento']);
  assert.equal(patch.body.motivo_arquivamento, 'inatividade_automatica');
  assert.equal(patch.body.arquivado_por, 'sistema');
  assert.match(chamadas[0].url, /arquivado_em=is\.null/);
  assert.match(notificacoes[0].mensagem, /Nada foi apagado/);
  assert.ok(_internos.STALE_DIAS >= 7);
  delete require.cache[NOTIF];
});

test('captação: validação do pedido antes de criar o job (setor, 6 cidades, raio, fontes, campanha)', () => {
  const { _internos } = require('../netlify/functions/captacao.js');
  const ok = { setor: 'Construção', cidades: ['Petrolina, PE'], raioKm: 15, providers: ['geoapify'] };
  assert.ok(_internos.validarPesquisa(ok).dados);
  assert.match(_internos.validarPesquisa({ ...ok, setor: 'Inventado' }).erro, /setor/);
  assert.match(_internos.validarPesquisa({ ...ok, cidades: ['a', 'b', 'c', 'd', 'e', 'f', 'g'] }).erro, /6 cidades/);
  assert.match(_internos.validarPesquisa({ ...ok, raioKm: 50 }).erro, /Raio/);
  assert.match(_internos.validarPesquisa({ ...ok, providers: ['google'] }).erro, /fonte/);
  assert.match(_internos.validarPesquisa({ ...ok, campanha: 'Com Espaço' }).erro, /Campanha/);
  assert.match(_internos.validarPesquisa({ ...ok, setor: 'Outro' }).erro, /termo/);
  // meia-noite de Recife = 03:00 UTC
  assert.equal(_internos.inicioDoDiaRecife(new Date('2026-09-30T02:00:00Z')).toISOString(), '2026-09-29T03:00:00.000Z');
  assert.equal(_internos.inicioDoDiaRecife(new Date('2026-09-30T15:00:00Z')).toISOString(), '2026-09-30T03:00:00.000Z');
});

test('captação semanal: cria JOB (não insere no CRM), só fonte OSM, setores estratégicos, 30 km', () => {
  const { _internos } = require('../netlify/functions/prospeccao-sync-osm.js');
  const job = _internos.montarJob(new Date('2026-10-05T10:00:00Z'));
  assert.equal(job.status, 'na_fila');
  assert.equal(job.metodo_captacao, 'sincronizacao_automatica');
  assert.deepEqual(job.providers, ['overpass']);
  assert.equal(job.parametros.raioKm, 30);
  assert.ok(job.parametros.setores.includes('Coworking'));
  assert.equal(job.criado_por_id, null);
  const src = require('fs').readFileSync(require.resolve('../netlify/functions/prospeccao-sync-osm.js'), 'utf8');
  assert.ok(!/admin_prospeccao_leads/.test(src), 'a rotina não toca no CRM');
});

test('nenhuma Function de captação escreve direto em admin_prospeccao_leads', () => {
  const fs = require('fs');
  for (const f of ['captacao.js', 'captacao-worker-background.js', 'prospeccao-sync-osm.js', 'prospeccao-buscar-empresas-background.js', '_lib/captacao/pipeline.js', '_lib/captacao/deps.js']) {
    const src = fs.readFileSync(require.resolve(`../netlify/functions/${f}`), 'utf8');
    assert.ok(!/rest\([^)]*['`]admin_prospeccao_leads[^'`]*['`],\s*\{\s*method:\s*'(POST|PATCH|DELETE)'/.test(src), f);
    assert.ok(!/bulkInsert/.test(src), f);
  }
});

test('e-mail de prospecção leva descadastro (rodapé + List-Unsubscribe) e Message-ID', async () => {
  const RAW = require.resolve('../netlify/functions/_lib/integrations/rawSmtp.js');
  const src = require('fs').readFileSync(RAW, 'utf8');
  assert.match(src, /Message-ID: </);
  assert.match(src, /List-Unsubscribe: </);
  const env = require('fs').readFileSync(require.resolve('../netlify/functions/prospeccao-enviar-email-background.js'), 'utf8');
  assert.match(env, /RODAPE_DESCADASTRO/);
  assert.match(env, /listaDescadastro/);
  assert.match(env, /tipo: 'email_enviado'/);
});
