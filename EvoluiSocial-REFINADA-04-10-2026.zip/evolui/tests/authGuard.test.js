const test = require('node:test');
const assert = require('node:assert/strict');
const { requireUser } = require('../netlify/functions/_lib/config/authGuard');

test('authGuard: sem header Authorization, rejeita com 401', async () => {
  const { user, token, error } = await requireUser({ headers: {} });
  assert.equal(user, null);
  assert.equal(token, null);
  assert.equal(error.statusCode, 401);
});

test('authGuard: token inválido (Supabase responde 401), rejeita', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => ({ ok: false, status: 401 });
  try {
    const { error } = await requireUser({ headers: { authorization: 'Bearer token-invalido' } });
    assert.equal(error.statusCode, 401);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

function fetchSimulado({ funcionario }) {
  return async (url) => {
    if (String(url).includes('/auth/v1/user')) return { ok: true, json: async () => ({ id: 'abc', email: 'teste@felipebranding.com.br' }) };
    return { ok: true, json: async () => (funcionario ? [{ role: 'admin' }] : []) };
  };
}

test('authGuard: conta logada que NÃO é funcionário ativo (ex.: usuário da EvoluiSocial), rejeita com 403', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = fetchSimulado({ funcionario: false });
  try {
    const { user, error } = await requireUser({ headers: { authorization: 'Bearer token-valido' } });
    assert.equal(user, null);
    assert.equal(error.statusCode, 403);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('authGuard: token válido de funcionário ativo, aceita', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = fetchSimulado({ funcionario: true });
  try {
    const { user, token, error } = await requireUser({ headers: { authorization: 'Bearer token-valido' } });
    assert.equal(error, null);
    assert.equal(user.email, 'teste@felipebranding.com.br');
    assert.equal(token, 'token-valido');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('authGuard: falha de rede ao validar, rejeita sem lançar exceção', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => {
    throw new Error('rede indisponível');
  };
  try {
    const { error } = await requireUser({ headers: { authorization: 'Bearer x' } });
    assert.ok(error);
    assert.equal(error.statusCode, 502);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
