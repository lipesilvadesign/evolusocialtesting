#!/usr/bin/env node
/**
 * Atalho: `node tests/run-all.js` roda a mesma coisa que
 * `node --test tests/*.test.js`, sem precisar lembrar o glob.
 * Usa node:test — nativo do Node 18+, zero dependência instalada.
 */
const { spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const testDir = __dirname;
const files = fs
  .readdirSync(testDir)
  .filter((f) => f.endsWith('.test.js'))
  .map((f) => path.join(testDir, f));

if (files.length === 0) {
  console.log('Nenhum arquivo *.test.js encontrado em /tests.');
  process.exit(0);
}

const result = spawnSync(process.execPath, ['--experimental-strip-types', '--test', ...files], { stdio: 'inherit' });
process.exit(result.status || 0);
