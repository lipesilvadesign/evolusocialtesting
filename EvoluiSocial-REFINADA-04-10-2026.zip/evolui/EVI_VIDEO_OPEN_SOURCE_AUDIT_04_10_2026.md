# Auditoria técnica — componentes open source do EVI

Data: 04/10/2026

## 1. faster-whisper

Repositório: https://github.com/SYSTRAN/faster-whisper

O GitHub lista a versão 1.2.1 como release mais recente no momento desta auditoria. O projeto é uma reimplementação do Whisper usando CTranslate2 e informa ganho de até 4x de velocidade em relação ao Whisper original para a mesma precisão, além de menor uso de memória e possibilidade de quantização em 8 bits.

Licença: MIT.

Decisão: usar como camada primária de ASR da v1.

## 2. WhisperX

Repositório: https://github.com/m-bain/whisperX

WhisperX fornece timestamps por palavra e suporte a diarização, além de alinhamento mais preciso. A release mais recente está na linha 3.8.x; a 3.8.6 aparece como latest estável e 3.8.7rc1 como pré-release.

Licença: BSD-2-Clause.

Decisão: não é dependência obrigatória da v1; fica preparado para uma camada futura de alinhamento/diarização.

## 3. PySceneDetect

Repositório: https://github.com/Breakthrough/PySceneDetect

A release 0.7.1 é a atual no momento da auditoria. Ela inclui correções de estabilidade e melhorias nos backends OpenCV/PyAV.

Licença: BSD-3-Clause.

Decisão: usar na detecção de cortes/cenas.

## 4. yt-dlp

Repositório: https://github.com/yt-dlp/yt-dlp

A release 2026.08.19 é a mais recente listada no GitHub nesta auditoria. O projeto é distribuído sob Unlicense, mas seus pacotes/bundles podem incorporar componentes de outras licenças. O próprio projeto informa que, para suporte completo a YouTube, o ecossistema atual depende também de `yt-dlp-ejs` e de um runtime JavaScript.

Decisão: usar como adaptador de aquisição de vídeos públicos, mantendo limites de domínio, tamanho, duração e timeout.

Observação operacional: a camada de aquisição é a parte mais sujeita a mudanças externas de plataformas; não tratar o downloader como garantia permanente de compatibilidade.

## 5. pyannote

Repositório: https://github.com/pyannote/pyannote-audio

O código atual contém licença MIT e oferece pipelines de diarização de falantes.

Decisão: preparado para futura extensão; não é necessário para a primeira versão.

## 6. Regra de arquitetura

Nenhuma dependência open source deve ocupar o lugar do EVI/EIE.

```text
Biblioteca open source
= capacidade técnica

EVI
= interpretação estruturada dos sinais

EIE/EKE
= decisão contextual
```
