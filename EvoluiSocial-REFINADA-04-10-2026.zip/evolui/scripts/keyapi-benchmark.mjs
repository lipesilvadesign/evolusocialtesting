#!/usr/bin/env node
/**
 * Evolui Social — KeyAPI Research Benchmark v1
 *
 * Objetivo: usar uma pequena cota controlada para descobrir se a KeyAPI
 * realmente melhora o motor de pesquisa da Evolui.
 *
 * SEGURANÇA DE CRÉDITO:
 * - padrão = dry-run (não faz chamadas);
 * - --live é obrigatório para gastar créditos;
 * - cada custo é reservado ANTES da chamada;
 * - custo reservado nunca é devolvido, mesmo em HTTP 4xx/5xx;
 * - o estado fica persistido em .keyapi-benchmark-state.json;
 * - nunca exibe a API key nos logs.
 */

import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CONFIG_PATH = path.join(ROOT, "scripts", "keyapi-benchmark.config.json");
const STATE_PATH = path.join(ROOT, "scripts", ".keyapi-benchmark-state.json");
const REPORT_DIR = path.join(ROOT, "reports");
const API = "https://api.keyapi.ai";

const ENDPOINTS = {
  tiktok_trending_hashtags: { method: "GET", path: "/v1/tiktok/trending/hashtags", credits: 2, platform: "tiktok" },
  tiktok_captions: { method: "GET", path: "/v1/tiktok/video/captions", credits: 2, platform: "tiktok" },
  instagram_reels_search: { method: "GET", path: "/v1/instagram/search_reels", credits: 2, platform: "instagram" },
  instagram_post_comments: { method: "GET", path: "/v1/instagram/fetch_post_comments", credits: 2, platform: "instagram" },
  instagram_shortcode: { method: "GET", path: "/v1/instagram/shortcode_to_media_id", credits: 2, platform: "instagram" },
  youtube_search: { method: "GET", path: "/v1/youtube/search_video", credits: 3, platform: "youtube" },
  youtube_video_info: { method: "GET", path: "/v1/youtube/get_video_info", credits: 3, platform: "youtube" },
  pinterest_search_users: { method: "GET", path: "/v1/pinterest/search", credits: 2, platform: "pinterest" },
  pinterest_user_info: { method: "GET", path: "/v1/pinterest/information", credits: 2, platform: "pinterest" }
};

function arg(name) { return process.argv.includes(name); }
function val(name, fallback) {
  const i = process.argv.indexOf(name);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); } catch { return fallback; }
}

async function writeJson(file, value) {
  await fs.writeFile(file, JSON.stringify(value, null, 2) + "\n", "utf8");
}

function summarizeData(data) {
  const out = { kind: Array.isArray(data) ? 'array' : (data && typeof data === 'object' ? 'object' : typeof data), items: Array.isArray(data) ? data.length : null, keys: [], textChars: 0, urlCount: 0, nestedObjectCount: 0 };
  const seen = new Set();
  const walk = (v, depth = 0) => {
    if (typeof v === 'string') {
      out.textChars += v.length;
      if (/^https?:\/\//i.test(v)) out.urlCount += 1;
      return;
    }
    if (!v || typeof v !== 'object' || depth > 4) return;
    if (seen.has(v)) return;
    seen.add(v);
    if (!Array.isArray(v)) {
      for (const k of Object.keys(v).slice(0, 80)) {
        if (out.keys.length < 80 && !out.keys.includes(k)) out.keys.push(k);
      }
      out.nestedObjectCount += 1;
      for (const value of Object.values(v).slice(0, 80)) walk(value, depth + 1);
    } else {
      for (const value of v.slice(0, 50)) walk(value, depth + 1);
    }
  };
  walk(data);
  return out;
}

function buildDefaultState() {
  return {
    version: "keyapi-benchmark-state-v1",
    hardCapCredits: 98,
    usedCredits: 0,
    reservedCredits: 0,
    runs: [],
    calls: []
  };
}

function resolveValues(config, source, count) {
  const map = {
    queries: config.queries || [],
    instagram_reels_keywords: config.instagram_reels_keywords || [],
    pinterest_user_queries: config.pinterest_user_queries || [],
    tiktok_video_ids: config.tiktok_video_ids || [],
    youtube_video_ids: config.youtube_video_ids || [],
    instagram_shortcode: config.instagram_shortcode ? [config.instagram_shortcode] : [],
    instagram_comments_url: config.instagram_comments_url ? [config.instagram_comments_url] : []
  };
  const values = map[source] || [];
  if (!values.length) return [];
  return Array.from({ length: count }, (_, i) => values[i % values.length]);
}

function buildParams(item, config, i) {
  const endpoint = item.endpoint;
  if (item.params) return { ...item.params };
  const source = item.paramsFrom;
  const value = resolveValues(config, source, item.count)[i];
  if (value === undefined || value === "") return null;
  switch (source) {
    case "queries":
    case "instagram_reels_keywords":
      return { search_query: value, keyword: value };
    case "pinterest_user_queries":
      return { username: value };
    case "tiktok_video_ids":
      return { video_id: value };
    case "youtube_video_ids":
      return { video_id: value, language_code: "pt-BR", need_format: "false" };
    case "instagram_shortcode":
      return { shortcode: value };
    case "instagram_comments_url":
      return { code_or_url: value, sort_by: "recent" };
    default:
      return {};
  }
}

function specializeParams(endpoint, generic) {
  if (endpoint === "instagram_reels_search") return { keyword: generic.keyword };
  if (endpoint === "youtube_search") return { search_query: generic.search_query, language_code: "pt", order_by: "this_month", country_code: "BR" };
  if (endpoint === "pinterest_search_users" || endpoint === "pinterest_user_info") return { username: generic.username };
  return generic;
}

function makePlan(config, recommendedCap) {
  const plan = [];
  for (const item of config.plan || []) {
    const meta = ENDPOINTS[item.endpoint];
    if (!meta) throw new Error(`Endpoint não conhecido no benchmark: ${item.endpoint}`);
    for (let i = 0; i < Number(item.count || 1); i++) {
      const params = buildParams(item, config, i);
      if (params === null && item.skipWhenEmpty) continue;
      if (params === null) throw new Error(`Não há fixture para ${item.endpoint}.`);
      plan.push({ endpoint: item.endpoint, params: specializeParams(item.endpoint, params), credits: meta.credits, platform: meta.platform });
    }
  }
  const total = plan.reduce((sum, x) => sum + x.credits, 0);
  if (total > recommendedCap) {
    throw new Error(`Plano excede o limite operacional recomendado: ${total} > ${recommendedCap} créditos.`);
  }
  return plan;
}

async function main() {
  const config = await readJson(CONFIG_PATH, null);
  if (!config) throw new Error("Configuração do benchmark não encontrada.");

  const hardCap = Number(val("--max-credits", config.hard_cap_credits || 98));
  const recommendedCap = Number(config.recommended_cap_credits || Math.max(0, hardCap - Number(config.reserve_credits || 0)));
  const live = arg("--live");
  const reset = arg("--reset");
  const state = reset ? buildDefaultState() : { ...buildDefaultState(), ...(await readJson(STATE_PATH, {})) };
  state.hardCapCredits = hardCap;

  const plan = makePlan(config, recommendedCap);
  const plannedCost = plan.reduce((sum, x) => sum + x.credits, 0);
  const remaining = hardCap - Number(state.usedCredits || 0);

  console.log(`\nKeyAPI Benchmark ${config.version}`);
  console.log(`Plano: ${plan.length} chamadas / ${plannedCost} créditos teóricos`);
  console.log(`Usados anteriormente: ${state.usedCredits} | Restantes: ${remaining} | Limite: ${hardCap}`);
  console.log(`Modo: ${live ? "LIVE — vai consumir créditos" : "DRY-RUN — nenhuma chamada será feita"}`);

  if (!live) {
    console.log("\nPlano de execução:");
    for (const [idx, item] of plan.entries()) console.log(`${idx + 1}. ${item.platform} :: ${item.endpoint} :: ${item.credits} cr`);
    console.log("\nPara executar: node scripts/keyapi-benchmark.mjs --live");
    return;
  }

  const apiKey = String(process.env.KEYAPI_API_KEY || "").trim();
  if (!apiKey) throw new Error("Defina KEYAPI_API_KEY no ambiente. Não cole a chave no código.");

  const runId = `run-${new Date().toISOString().replace(/[:.]/g, "-")}`;
  const startedAt = new Date().toISOString();
  const results = [];

  for (let i = 0; i < plan.length; i++) {
    const item = plan[i];
    const before = Number(state.usedCredits || 0);
    if (before + item.credits > hardCap) {
      throw new Error(`ABORTADO antes da chamada ${i + 1}: orçamento ultrapassaria ${hardCap} créditos.`);
    }

    // Reserva irreversível antes da chamada: protege contra cobrança em erro 4xx/5xx.
    state.usedCredits = before + item.credits;
    state.reservedCredits += item.credits;
    const url = new URL(API + ENDPOINTS[item.endpoint].path);
    for (const [k, v] of Object.entries(item.params)) if (v !== undefined && v !== "") url.searchParams.set(k, String(v));
    const t0 = Date.now();
    let status = 0;
    let body = null;
    let error = null;

    try {
      const r = await fetch(url, {
        method: "GET",
        headers: { Authorization: `Bearer ${apiKey}`, Accept: "application/json" }
      });
      status = r.status;
      body = await r.json().catch(() => null);
    } catch (e) {
      error = String(e);
    }

    const providerCode = body && typeof body === "object" ? body.code : undefined;
    const ok = status >= 200 && status < 300 && (providerCode === undefined || providerCode === 0);
    const record = {
      index: i + 1,
      endpoint: item.endpoint,
      platform: item.platform,
      credits_reserved: item.credits,
      http_status: status,
      provider_code: providerCode ?? null,
      ok,
      latency_ms: Date.now() - t0,
      request_id: body && typeof body === "object" ? body.requestId ?? null : null,
      message: body && typeof body === "object" ? body.message ?? null : error,
      params: item.params,
      data_shape: summarizeData(body && typeof body === 'object' ? body.data : null),
      observed_at: new Date().toISOString()
    };
    state.calls.push({ runId, ...record });
    results.push(record);
    console.log(`${String(i + 1).padStart(2, "0")}/${plan.length} ${item.endpoint} ${record.http_status || "ERR"} ${ok ? "OK" : "FALHOU"} ${item.credits}cr`);

    // Persistir a cada chamada para que uma interrupção não perca o orçamento contabilizado.
    await writeJson(STATE_PATH, state);
  }

  const finishedAt = new Date().toISOString();
  state.runs.push({ runId, startedAt, finishedAt, plannedCredits: plannedCost, consumedCredits: results.reduce((s, r) => s + r.credits_reserved, 0), resultsCount: results.length });
  await fs.mkdir(REPORT_DIR, { recursive: true });
  const report = {
    benchmark: config.version,
    runId,
    hardCapCredits: hardCap,
    recommendedCapCredits: recommendedCap,
    consumedCredits: results.reduce((s, r) => s + r.credits_reserved, 0),
    remainingCredits: hardCap - state.usedCredits,
    successCount: results.filter(r => r.ok).length,
    failureCount: results.filter(r => !r.ok).length,
    byPlatform: results.reduce((acc, r) => {
      acc[r.platform] ||= { calls: 0, credits: 0, success: 0, failures: 0 };
      acc[r.platform].calls += 1;
      acc[r.platform].credits += r.credits_reserved;
      acc[r.platform][r.ok ? "success" : "failures"] += 1;
      return acc;
    }, {}),
    results
  };
  await writeJson(STATE_PATH, state);
  await writeJson(path.join(REPORT_DIR, `${runId}.json`), report);
  console.log(`\nRelatório: reports/${runId}.json`);
  console.log(`Créditos consumidos no benchmark: ${report.consumedCredits}`);
  console.log(`Créditos restantes dentro do limite de segurança: ${report.remainingCredits}`);
}

main().catch((e) => {
  console.error(`\nBenchmark interrompido: ${e.message || e}`);
  process.exitCode = 1;
});
