#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..');

function run(label, command, args) {
  const r = spawnSync(command, args, { cwd: ROOT, stdio: 'inherit' });
  if (r.status !== 0) throw new Error(`${label} falhou com código ${r.status}`);
  console.log(`OK — ${label}`);
}

for (const file of [
  'scripts/keyapi-benchmark.mjs',
]) run(`node --check ${file}`, process.execPath, ['--check', file]);

for (const [file, args] of [
  ['tests/keyapiProvider.test.js', ['--experimental-strip-types', 'tests/keyapiProvider.test.js']],
  ['tests/keyapiBenchmark.test.js', ['tests/keyapiBenchmark.test.js']],
  ['tests/pinterestReferencias.test.js', ['tests/pinterestReferencias.test.js']],
  ['tests/inteligenciaDados.test.js', ['--experimental-strip-types', 'tests/inteligenciaDados.test.js']],
  ['tests/videoIntelligence.test.js', ['--experimental-strip-types', 'tests/videoIntelligence.test.js']],
]) run(file, process.execPath, args);

for (const file of [
  'supabase/functions/evolui-api/index.ts',
  'supabase/functions/evolui-api/eie/pesquisa/keyapi.ts',
  'supabase/functions/evolui-api/eie/video.ts',
  'supabase/functions/evolui-api/eie/conhecimento.ts',
]) run(`syntax ${file}`, process.execPath, ['--experimental-strip-types', '--check', file]);

run('suíte completa do projeto', process.execPath, ['tests/run-all.js']);


const req = fs.readFileSync(path.join(ROOT, 'evi-video-worker', 'requirements.txt'), 'utf8');
const docker = fs.readFileSync(path.join(ROOT, 'evi-video-worker', 'Dockerfile'), 'utf8');
if (!req.includes('yt-dlp[default]==2026.08.19') || !req.includes('yt-dlp-ejs==0.8.0')) throw new Error('Dependências yt-dlp/EJS do worker não estão fechadas nas versões esperadas.');
if (!docker.includes('DENO_VERSION=2.9.6') || !docker.includes('deno-x86_64-unknown-linux-gnu.zip')) throw new Error('Runtime Deno do worker não está fechado na imagem.');
const sql = fs.readFileSync(path.join(ROOT, 'SQL_EVOLUI_INTELIGENCIA_CONSOLIDADO_04_10_2026.sql'), 'utf8');
for (const marker of ['evolui_conhecimento', 'evolui_comportamento_agregado', 'evolui_registrar_sinal_agregado', 'evolui_obter_sinais_agregados', 'evolui_video_analises', 'grant all on public.evolui_video_analises to service_role']) {
  if (!sql.includes(marker)) throw new Error(`SQL consolidado sem marcador obrigatório: ${marker}`);
}
console.log('OK — dependências EVI + SQL consolidado');

run('python compileall EVI worker', 'python3', ['-m', 'compileall', '-q', 'evi-video-worker/app', 'evi-video-worker/tests']);

const suspicious = /pina_|sk_live_|sk-proj-/i;
function scan(dir) {
  let hits = [];
  for (const name of fs.readdirSync(dir)) {
    if (name === '.git' || name === 'node_modules' || name === 'validar-release.mjs' || name.endsWith('.zip')) continue;
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) hits = hits.concat(scan(p));
    else if (st.size < 2_000_000) {
      const txt = fs.readFileSync(p, 'utf8');
      if (suspicious.test(txt)) hits.push(p);
    }
  }
  return hits;
}
const hits = scan(ROOT);
if (hits.length) throw new Error(`Possível segredo detectado em ${hits.length} arquivo(s).`);
console.log('OK — varredura de segredos conhecida (sem valores expostos)');

console.log('\nVALIDAÇÃO FINAL: PASSOU');
