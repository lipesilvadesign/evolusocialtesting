from app.core import analyze_transcript, detect_cta, detect_hook


def test_hook_cta_and_dna():
    assert detect_hook("Você sabia que 3 erros fazem você perder clientes?")["tipo"] == "pergunta"
    assert detect_cta("Comenta aqui e salva este vídeo")["tipo"] == "comentario"
    result = analyze_transcript([
        {"start": 0, "end": 2, "text": "Você sabia que 3 erros podem fazer você perder clientes?"},
        {"start": 2, "end": 7, "text": "O primeiro erro é não explicar o benefício."},
        {"start": 7, "end": 11, "text": "Mostre um caso real e depois explique a solução."},
        {"start": 11, "end": 13, "text": "Comenta aqui se você quer mais."},
    ], 13.0, {"scene_count": 5, "movimento_medio": 0.11})
    assert result["dna"]["versao"] == "evi-dna-v1"
    assert result["retorica"]["cta"]["tipo"] == "comentario"
    assert result["evi_score"]["score"] > 0


def test_gap_detection():
    result = analyze_transcript([
        {"start": 0, "end": 3, "text": "Uma dica importante para sua empresa."},
        {"start": 3, "end": 8, "text": "Faça isso todos os dias."},
    ], 8.0, {"scene_count": 1})
    kinds = {x["tipo"] for x in result["lacunas"]}
    assert "cta_ausente" in kinds
    assert "baixa_variedade_de_cenas" in kinds


def test_fingerprint_and_context_fit_are_deterministic():
    payload = [
        {"start": 0, "end": 2, "text": "Você trabalha com imóveis e precisa explicar financiamento."},
        {"start": 2, "end": 5, "text": "Mostre um caso real antes da solução."},
        {"start": 5, "end": 7, "text": "Comenta aqui se quer mais dicas."},
    ]
    a = analyze_transcript(payload, 7.0, {"scene_count": 3}, {"ramo": "imobiliário", "objetivo": "comentarios", "rede": "instagram"})
    b = analyze_transcript(payload, 7.0, {"scene_count": 3}, {"ramo": "imobiliário", "objetivo": "comentarios", "rede": "instagram"})
    assert a["impressao_digital"] == b["impressao_digital"]
    assert len(a["impressao_digital"]) == 16
    assert a["ajuste_contextual_observavel"]["metodo"] == "interseccao_lexical_observavel"
