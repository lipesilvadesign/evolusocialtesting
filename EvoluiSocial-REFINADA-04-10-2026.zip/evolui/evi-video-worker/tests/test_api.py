from fastapi.testclient import TestClient

from app.main import app
from app.media import allowed_public_url


def test_health():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["engine"] == "evi-video-v1"


def test_invalid_public_url_rejected_without_processing():
    client = TestClient(app)
    response = client.post("/analyze", json={"url": "https://example.com/video.mp4"})
    assert response.status_code in (400, 502)


def test_allowed_domains_are_strict():
    assert allowed_public_url("https://www.youtube.com/watch?v=abc")
    assert allowed_public_url("https://www.tiktok.com/@x/video/123")
    assert allowed_public_url("https://www.instagram.com/reel/abc/")
    assert not allowed_public_url("http://www.youtube.com/watch?v=abc")
    assert not allowed_public_url("https://example.com/video.mp4")
