from __future__ import annotations

import os
import tempfile
from typing import Any

from .core import analyze_transcript
from .media import download_video, extract_audio
from .transcriber import transcribe
from .visuals import analyze_visuals


def build_prompt(context: dict[str, Any]) -> str:
    terms = [str(context.get(k)).strip() for k in ("ramo", "objetivo", "cidade", "rede", "formato") if context.get(k)]
    return "Contexto Evolui: " + ", ".join(terms) + "." if terms else ""


def analyze_url(url: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
    context = context or {}
    with tempfile.TemporaryDirectory(prefix="evi-") as tmp:
        video = download_video(url, tmp)
        visuals = analyze_visuals(str(video), sample_seconds=float(os.getenv("EVI_FRAME_SAMPLE_SEC", "1.5")))
        max_duration = float(os.getenv("EVI_MAX_DURATION_SEC", "180"))
        duration_video = float(visuals.get("duracao_seg", 0.0) or 0.0)
        if duration_video > max_duration:
            raise ValueError(f"Vídeo muito longo. O limite desta versão é {int(max_duration)} segundos.")
        audio = extract_audio(video, tmp)
        transcript = transcribe(str(audio), language=context.get("idioma") or None, initial_prompt=build_prompt(context))
        duration = max(duration_video, float(transcript.get("duracao_audio_seg", 0.0)))
        if duration > max_duration:
            raise ValueError(f"Vídeo muito longo. O limite desta versão é {int(max_duration)} segundos.")
        semantic = analyze_transcript(transcript["segmentos"], duration, visuals, context)
        return {
            "versao": "evi-video-v1",
            "modo": "video",
            "url": url,
            "plataforma": context.get("plataforma") or "video",
            "descricao": "; ".join(x for x in [semantic["dna"].get("formato_estrutural"), semantic["ritmo"].get("classificacao")] if x) or "Análise estrutural do conteúdo audiovisual concluída.",
            "transcricao": transcript["texto"],
            "transcricao_meta": {
                "idioma": transcript.get("idioma"),
                "probabilidade_idioma": transcript.get("probabilidade_idioma"),
                "segmentos": len(transcript.get("segmentos", [])),
                "palavras": len(transcript.get("palavras", [])),
                "duracao_audio_seg": transcript.get("duracao_audio_seg"),
            },
            "segmentos": transcript["segmentos"],
            "palavras": transcript["palavras"],
            "tema": semantic["termos"][0] if semantic["termos"] else None,
            "formato": semantic["dna"].get("formato_estrutural"),
            "gancho": semantic["retorica"].get("hook", {}).get("trecho"),
            "cta": semantic["retorica"].get("cta", {}).get("trecho"),
            "elementos_visuais": [
                f"{visuals.get('scene_count', 0)} cenas detectadas",
                f"movimento médio {visuals.get('movimento_medio')}" if visuals.get("movimento_medio") is not None else "movimento não calculado",
                f"presença de rosto em {visuals.get('presenca_rosto_amostras_pct')}% das amostras" if visuals.get("presenca_rosto_amostras_pct") is not None else "presença de rosto não calculada",
            ],
            "pontos_fortes": [],
            "pontos_atencao": [g["descricao"] for g in semantic["lacunas"]],
            "termos": semantic["termos"],
            "confianca": round(max(0.0, min(1.0, 0.82 * float(transcript.get("probabilidade_idioma") or 0.8))), 3),
            "estrutura": semantic["estrutura"],
            "retorica": semantic["retorica"],
            "ritmo": semantic["ritmo"],
            "cenas": visuals.get("cenas", []),
            "sinais_visuais": visuals,
            "dna": semantic["dna"],
            "lacunas": semantic["lacunas"],
            "oportunidades": semantic["oportunidades"],
            "evi_score": semantic["evi_score"],
            "impressao_digital": semantic["impressao_digital"],
            "ajuste_contextual_observavel": semantic["ajuste_contextual_observavel"],
            "proveniencia": {
                "aquisicao": "yt-dlp",
                "transcricao": "faster-whisper 1.2.1",
                "cenas": "PySceneDetect 0.7.1",
                "sinais_visuais": "OpenCV",
                "score": "EVI heuristico deterministico",
                "metricas_de_rede": "não fornecidas pelo vídeo e não inferidas",
                "contexto": context,
                "impressao_digital": semantic["impressao_digital"],
            },
        }
