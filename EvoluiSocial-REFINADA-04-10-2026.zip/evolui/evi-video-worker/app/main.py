from __future__ import annotations

import os
from typing import Any

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from .pipeline import analyze_url

app = FastAPI(title="EVI Video Worker", version="evi-video-v1")


class AnalyzeRequest(BaseModel):
    url: str = Field(min_length=10, max_length=1000)
    plataforma: str | None = None
    contexto: dict[str, Any] = Field(default_factory=dict)


def auth_ok(authorization: str | None) -> bool:
    expected = os.getenv("EVI_WORKER_TOKEN", "").strip()
    return not expected or authorization == f"Bearer {expected}"


@app.get("/health")
def health() -> dict[str, Any]:
    return {"ok": True, "engine": "evi-video-v1", "transcricao": "faster-whisper"}


@app.post("/analyze")
def analyze(req: AnalyzeRequest, authorization: str | None = Header(default=None)) -> dict[str, Any]:
    if not auth_ok(authorization):
        raise HTTPException(status_code=401, detail="Não autorizado")
    try:
        context = dict(req.contexto or {})
        context["plataforma"] = req.plataforma or context.get("plataforma")
        return {"ok": True, "analysis": analyze_url(req.url, context)}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Não foi possível processar o vídeo agora.") from exc
