"""Public video acquisition + audio extraction."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path
from urllib.parse import urlparse


ALLOWED_HOSTS = {
    "youtube.com", "www.youtube.com", "youtu.be", "m.youtube.com",
    "tiktok.com", "www.tiktok.com", "vm.tiktok.com", "vt.tiktok.com",
    "instagram.com", "www.instagram.com",
}


def allowed_public_url(url: str) -> bool:
    try:
        p = urlparse(url)
        if p.scheme != "https" or not p.hostname:
            return False
        host = p.hostname.lower()
        return host in ALLOWED_HOSTS or any(host.endswith("." + h) for h in ALLOWED_HOSTS)
    except Exception:
        return False


def _max_bytes() -> int:
    return max(10, int(os.getenv("EVI_MAX_VIDEO_MB", "150"))) * 1024 * 1024


def download_video(url: str, workdir: str) -> Path:
    if not allowed_public_url(url):
        raise ValueError("URL não permitida. Use YouTube, TikTok ou Instagram público.")
    try:
        from yt_dlp import YoutubeDL
    except Exception as exc:
        raise RuntimeError("yt-dlp não está instalado no worker.") from exc
    target = Path(workdir) / "video.%(ext)s"
    opts = {
        "outtmpl": str(target),
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "format": "bv*[height<=720][ext=mp4]+ba[ext=m4a]/b[height<=720][ext=mp4]/b[height<=720]/b",
        "merge_output_format": "mp4",
        "max_filesize": _max_bytes(),
        "socket_timeout": int(os.getenv("EVI_DOWNLOAD_TIMEOUT_SEC", "35")),
        "retries": 1,
        "cachedir": False,
    }
    with YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        path = Path(ydl.prepare_filename(info))
        if not path.exists():
            candidates = sorted(Path(workdir).glob("video.*"))
            if candidates:
                path = candidates[0]
        if not path.exists():
            raise RuntimeError("Não foi possível localizar o arquivo baixado.")
    return path


def extract_audio(video_path: Path, workdir: str) -> Path:
    audio_path = Path(workdir) / "audio.wav"
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(video_path),
        "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(audio_path),
    ]
    subprocess.run(cmd, check=True, timeout=int(os.getenv("EVI_FFMPEG_TIMEOUT_SEC", "45")))
    return audio_path
