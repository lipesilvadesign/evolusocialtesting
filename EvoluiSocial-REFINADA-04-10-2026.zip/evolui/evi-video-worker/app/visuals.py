"""Observable visual signals; no semantic claims about the actual content of frames."""
from __future__ import annotations

from pathlib import Path
from typing import Any


def analyze_visuals(video_path: str, sample_seconds: float = 1.5) -> dict[str, Any]:
    try:
        import cv2
    except Exception:
        return {"disponivel": False, "motivo": "opencv_nao_instalado", "scene_count": 0}
    try:
        from scenedetect import ContentDetector, SceneManager, open_video
    except Exception:
        ContentDetector = SceneManager = open_video = None

    path = Path(video_path)
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return {"disponivel": False, "motivo": "video_nao_aberto", "scene_count": 0}
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration = frames / fps if fps > 0 else 0.0
    sample_every = max(1, int(round((fps or 25.0) * max(0.5, sample_seconds))))
    brightness: list[float] = []
    motion: list[float] = []
    face_hits = 0
    face_samples = 0
    prev_gray = None
    face_cascade = None
    try:
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    except Exception:
        pass

    i = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if i % sample_every == 0:
            small = cv2.resize(frame, (320, 180))
            gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            brightness.append(float(gray.mean() / 255.0))
            if prev_gray is not None:
                motion.append(float(cv2.absdiff(gray, prev_gray).mean() / 255.0))
            prev_gray = gray
            if face_cascade is not None:
                faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(24, 24))
                face_hits += 1 if len(faces) else 0
                face_samples += 1
        i += 1
    cap.release()

    scene_count = 0
    scene_list: list[dict[str, Any]] = []
    if SceneManager and open_video and ContentDetector:
        try:
            video = open_video(str(path))
            manager = SceneManager()
            manager.add_detector(ContentDetector(threshold=27.0, min_scene_len=10))
            manager.detect_scenes(video=video)
            pairs = manager.get_scene_list()
            scene_count = len(pairs)
            scene_list = [{"inicio_seg": round(start.get_seconds(), 3), "fim_seg": round(end.get_seconds(), 3)} for start, end in pairs[:80]]
        except Exception:
            pass

    return {
        "disponivel": True,
        "duracao_seg": round(duration, 3),
        "fps": round(fps, 3),
        "frames": frames,
        "scene_count": scene_count,
        "cenas": scene_list,
        "amostras": len(brightness),
        "brilho_medio": round(sum(brightness) / len(brightness), 3) if brightness else None,
        "movimento_medio": round(sum(motion) / len(motion), 3) if motion else None,
        "presenca_rosto_amostras_pct": round(100 * face_hits / face_samples, 1) if face_samples else None,
        "metodo": ["amostragem_frames", "content_detector" if scene_count else "metadados_visuais"],
    }
