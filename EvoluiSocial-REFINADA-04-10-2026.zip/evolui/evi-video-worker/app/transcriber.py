"""Local ASR adapter. Model is loaded lazily and cached per worker process."""
from __future__ import annotations

import os
from typing import Any

_MODEL = None


def _model():
    global _MODEL
    if _MODEL is not None:
        return _MODEL
    from faster_whisper import WhisperModel
    model_name = os.getenv("EVI_WHISPER_MODEL", "large-v3-turbo")
    device = os.getenv("EVI_WHISPER_DEVICE", "cpu")
    compute = os.getenv("EVI_WHISPER_COMPUTE", "int8" if device == "cpu" else "float16")
    _MODEL = WhisperModel(model_name, device=device, compute_type=compute)
    return _MODEL


def transcribe(audio_path: str, language: str | None = None, initial_prompt: str | None = None) -> dict[str, Any]:
    model = _model()
    segments, info = model.transcribe(
        audio_path,
        language=language or None,
        task="transcribe",
        beam_size=int(os.getenv("EVI_BEAM_SIZE", "5")),
        vad_filter=True,
        word_timestamps=True,
        condition_on_previous_text=True,
        initial_prompt=initial_prompt or None,
    )
    output_segments = []
    words = []
    for seg in segments:
        output_segments.append({
            "id": int(seg.id),
            "start": float(seg.start),
            "end": float(seg.end),
            "text": str(seg.text).strip(),
            "avg_logprob": float(getattr(seg, "avg_logprob", 0.0)),
            "no_speech_prob": float(getattr(seg, "no_speech_prob", 0.0)),
        })
        for w in (getattr(seg, "words", None) or []):
            words.append({
                "start": float(w.start),
                "end": float(w.end),
                "word": str(w.word).strip(),
                "probabilidade": float(w.probability) if getattr(w, "probability", None) is not None else None,
            })
    return {
        "texto": " ".join(s["text"] for s in output_segments if s["text"]).strip(),
        "segmentos": output_segments,
        "palavras": words,
        "idioma": getattr(info, "language", None),
        "probabilidade_idioma": float(getattr(info, "language_probability", 0.0) or 0.0),
        "duracao_audio_seg": float(getattr(info, "duration", 0.0) or 0.0),
    }
