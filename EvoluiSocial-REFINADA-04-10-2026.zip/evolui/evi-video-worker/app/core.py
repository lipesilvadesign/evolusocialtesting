"""EVI v1 — deterministic video-content signal extraction.
The open-source models/tools are the sensors. This module is the Evolui-specific layer.
"""
from __future__ import annotations

import hashlib
import math
import re
import unicodedata
from collections import Counter
from typing import Any, Iterable

WORD_RE = re.compile(r"[\wÀ-ÖØ-öø-ÿ']+", re.UNICODE)
QUESTION_RE = re.compile(r"\?|\b(?:como|por que|por quê|o que|qual|quando|você sabia|sabia que)\b", re.I)
CTA_PATTERNS = [
    ("comentario", re.compile(r"\b(?:comenta|comente|coment[aá]rio|me diz|diz aqui)\b", re.I)),
    ("seguir", re.compile(r"\b(?:segue|seguir|siga|acompanha)\b", re.I)),
    ("salvar", re.compile(r"\b(?:salva|salvar|guarda|guardar)\b", re.I)),
    ("compartilhar", re.compile(r"\b(?:compartilha|compartilhar|envia|enviar)\b", re.I)),
    ("mensagem", re.compile(r"\b(?:manda mensagem|chama no direct|me chama|fale comigo)\b", re.I)),
    ("link", re.compile(r"\b(?:link na bio|acesse|clica|clique|link)\b", re.I)),
]
HOOK_PATTERNS = [
    ("pergunta", re.compile(r"\?|\b(?:você sabia|sabia que|já pensou|como)\b", re.I)),
    ("lista", re.compile(r"\b(?:\d+|três|dois|duas|5|3|4)\s+(?:erros|dicas|formas|passos|coisas|motivos|sinais)\b", re.I)),
    ("alerta", re.compile(r"\b(?:não faça|não cometa|cuidado|pare de|atenção)\b", re.I)),
    ("promessa", re.compile(r"\b(?:vou te mostrar|aprenda|descubra|veja como|te ensino)\b", re.I)),
]
STRUCTURE_PATTERNS = [
    ("cta", re.compile(r"\b(?:comenta|comente|segue|siga|salva|salvar|compartilha|compartilhar|link na bio|chama no direct)\b", re.I)),
    ("prova", re.compile(r"\b(?:resultado|prova|caso real|cliente|antes e depois|depoimento|dados|números|número)\b", re.I)),
    ("problema", re.compile(r"\b(?:erro|problema|dificuldade|perder|perde|falha|dor|medo|custa|caro|difícil)\b", re.I)),
    ("lista", re.compile(r"\b(?:primeiro|segundo|terceiro|1º|2º|3º|\d+\s+(?:erros|dicas|passos|formas))\b", re.I)),
    ("solucao", re.compile(r"\b(?:como resolver|faça|fazer|solução|solucione|passo a passo|o jeito é|recomendo)\b", re.I)),
]


def words(text: str) -> list[str]:
    return WORD_RE.findall(text.lower())


def normalize_phrase(text: str) -> str:
    base = unicodedata.normalize("NFKD", str(text or ""))
    return "".join(ch for ch in base if not unicodedata.combining(ch)).lower().strip()


def content_fingerprint(structure: list[dict[str, Any]], rhetoric: dict[str, Any], rhythm: dict[str, Any]) -> str:
    skeleton = [str(x.get("tipo") or "") for x in structure]
    duration = float(rhythm.get("duracao_seg") or 0.0)
    duration_bin = round(duration / 5.0) * 5 if duration else 0
    canonical = "|".join([
        "evi-dna-v1",
        ">".join(skeleton),
        str(rhetoric.get("hook", {}).get("tipo") or ""),
        str(rhetoric.get("cta", {}).get("tipo") or ""),
        str(rhythm.get("classificacao") or ""),
        str(duration_bin),
    ])
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]


def build_context_fit(terms: list[str], context: dict[str, Any] | None = None) -> dict[str, Any]:
    context = context or {}
    candidates = []
    for key in ("ramo", "objetivo", "rede", "formato"):
        value = normalize_phrase(str(context.get(key) or ""))
        if value:
            candidates.extend(value.split())
    candidate_set = {t for t in candidates if len(t) >= 4}
    observed = {normalize_phrase(t) for t in terms if len(normalize_phrase(t)) >= 4}
    overlap = sorted(candidate_set & observed)
    if not candidate_set:
        score = None
        level = "sem_contexto"
    else:
        score = round(100 * len(overlap) / max(1, min(len(candidate_set), 6)), 1)
        level = "alto" if score >= 50 else "medio" if score >= 20 else "baixo"
    return {"score": score, "nivel": level, "termos_contexto": sorted(candidate_set)[:12], "termos_observados_em_comum": overlap[:12], "metodo": "interseccao_lexical_observavel"}


def seconds(v: Any) -> float:
    try:
        return max(0.0, float(v))
    except Exception:
        return 0.0


def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def safe_mean(values: Iterable[float]) -> float:
    vals = list(values)
    return sum(vals) / len(vals) if vals else 0.0


def detect_cta(text: str) -> dict[str, Any]:
    for kind, pattern in CTA_PATTERNS:
        match = pattern.search(text or "")
        if match:
            return {"tipo": kind, "trecho": match.group(0)}
    return {"tipo": None, "trecho": None}


def detect_hook(text: str) -> dict[str, Any]:
    sample = " ".join((text or "").split()[:35])
    for kind, pattern in HOOK_PATTERNS:
        match = pattern.search(sample)
        if match:
            return {"tipo": kind, "trecho": sample[:240]}
    return {"tipo": "declaracao", "trecho": sample[:240] or None}


def classify_structure(segments: list[dict[str, Any]], duration: float) -> list[dict[str, Any]]:
    if not segments:
        return []
    ordered = sorted(segments, key=lambda s: seconds(s.get("start")))
    out: list[dict[str, Any]] = []
    for idx, seg in enumerate(ordered):
        text = str(seg.get("text") or "").strip()
        start = seconds(seg.get("start"))
        end = seconds(seg.get("end"))
        rel = start / duration if duration else 0.0
        label = None
        for kind, pattern in STRUCTURE_PATTERNS:
            if pattern.search(text):
                label = kind
                break
        if idx == 0 and rel < 0.18:
            label = "hook"
        elif idx == len(ordered) - 1 and (rel > 0.68 or len(ordered) == 1) and detect_cta(text)["tipo"]:
            label = "cta"
        if label is None:
            label = "desenvolvimento"
        out.append({"tipo": label, "inicio_seg": round(start, 3), "fim_seg": round(end, 3), "texto": text[:600]})
    return out


def build_rhythm(segments: list[dict[str, Any]], duration: float, scene_count: int = 0) -> dict[str, Any]:
    starts = [seconds(s.get("start")) for s in segments]
    ends = [seconds(s.get("end")) for s in segments]
    gaps = [max(0.0, b - a) for a, b in zip(ends, starts[1:])]
    words_count = sum(len(words(str(s.get("text") or ""))) for s in segments)
    words_per_minute = words_count / duration * 60.0 if duration > 0 else 0.0
    avg_segment = safe_mean([max(0.0, e - s) for s, e in zip(starts, ends)])
    cuts_per_min = max(0, scene_count - 1) / duration * 60.0 if duration > 0 else 0.0
    return {
        "duracao_seg": round(duration, 3),
        "palavras": words_count,
        "palavras_por_minuto": round(words_per_minute, 1),
        "segmentos_fala": len(segments),
        "duracao_media_fala_seg": round(avg_segment, 3),
        "pausa_media_seg": round(safe_mean(gaps), 3),
        "cortes_por_minuto": round(cuts_per_min, 2),
        "classificacao": (
            "muito_dinamico" if cuts_per_min >= 20 or words_per_minute >= 190 else
            "dinamico" if cuts_per_min >= 10 or words_per_minute >= 150 else
            "moderado" if cuts_per_min >= 4 or words_per_minute >= 110 else
            "calmo"
        ),
    }


def build_rhetoric(full_text: str, first_text: str, last_text: str, duration: float) -> dict[str, Any]:
    token_count = len(words(full_text))
    questions = len(re.findall(r"\?", full_text)) + len(QUESTION_RE.findall(full_text))
    numbers = len(re.findall(r"\b\d+\b", full_text))
    second_person = len(re.findall(r"\b(?:você|vocês|seu|sua|seus|suas|te|tua|tuas)\b", full_text, re.I))
    return {
        "perguntas": min(20, questions),
        "numeros": min(30, numbers),
        "segunda_pessoa": min(50, second_person),
        "densidade_palavras_por_seg": round(token_count / duration, 2) if duration else 0.0,
        "hook": detect_hook(first_text or full_text),
        "cta": detect_cta(last_text or full_text),
    }


def build_dna(structure: list[dict[str, Any]], rhetoric: dict[str, Any], rhythm: dict[str, Any], visuals: dict[str, Any]) -> dict[str, Any]:
    unique = []
    for item in structure:
        kind = item["tipo"]
        if not unique or unique[-1] != kind:
            unique.append(kind)
    return {
        "versao": "evi-dna-v1",
        "formato_estrutural": " → ".join(unique) if unique else None,
        "hook": rhetoric.get("hook"),
        "cta": rhetoric.get("cta"),
        "ritmo": rhythm.get("classificacao"),
        "cortes_por_minuto": rhythm.get("cortes_por_minuto"),
        "duracao_seg": rhythm.get("duracao_seg"),
        "palavras": rhythm.get("palavras"),
        "sinais_visuais": visuals,
    }


def infer_gaps(structure: list[dict[str, Any]], rhetoric: dict[str, Any], visuals: dict[str, Any]) -> list[dict[str, Any]]:
    types = {x["tipo"] for x in structure}
    gaps: list[dict[str, Any]] = []
    if "cta" not in types and not rhetoric.get("cta", {}).get("tipo"):
        gaps.append({"tipo": "cta_ausente", "descricao": "Não foi detectada uma chamada para ação textual no final/trechos analisados."})
    if "prova" not in types:
        gaps.append({"tipo": "prova_nao_detectada", "descricao": "Não foi detectado sinal textual de prova, caso ou evidência."})
    if visuals.get("scene_count", 0) <= 1:
        gaps.append({"tipo": "baixa_variedade_de_cenas", "descricao": "O vídeo parece utilizar uma única cena ou poucas mudanças de enquadramento."})
    return gaps[:6]


def build_opportunities(structure: list[dict[str, Any]], rhetoric: dict[str, Any], gaps: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ops: list[dict[str, Any]] = []
    kinds = {x["tipo"] for x in structure}
    if "hook" in kinds:
        ops.append({"tipo": "variar_hook", "titulo": "Manter a promessa e trocar o mecanismo do gancho", "razao": "A estrutura inicial já está identificada; a Evolui pode gerar outra entrada sem copiar o texto."})
    if any(g["tipo"] == "cta_ausente" for g in gaps):
        ops.append({"tipo": "adicionar_cta", "titulo": "Criar uma ação de continuidade", "razao": "Não foi detectada CTA textual na análise."})
    if any(g["tipo"] == "prova_nao_detectada" for g in gaps):
        ops.append({"tipo": "adicionar_prova", "titulo": "Transformar explicação em demonstração ou caso", "razao": "Não apareceu sinal textual de prova/caso."})
    if rhetoric.get("numeros", 0) > 0:
        ops.append({"tipo": "transformar_lista", "titulo": "Reaproveitar a lógica da lista em outra situação", "razao": "O vídeo usa números/listagem como recurso retórico."})
    return ops[:5]


def evi_score(rhetoric: dict[str, Any], rhythm: dict[str, Any], structure: list[dict[str, Any]], visuals: dict[str, Any]) -> dict[str, Any]:
    """Structural score only; never predicts virality."""
    hook = 1.0 if rhetoric.get("hook", {}).get("tipo") in {"pergunta", "lista", "alerta", "promessa"} else 0.65
    cta = 1.0 if rhetoric.get("cta", {}).get("tipo") else 0.45
    variety = clamp(len({x["tipo"] for x in structure}) / 5.0)
    rhythm_score = 0.7 if rhythm.get("classificacao") in {"dinamico", "moderado"} else 0.55
    scene_variety = clamp(math.log1p(max(0, visuals.get("scene_count", 0))) / math.log(9))
    score = 100 * (0.28 * hook + 0.18 * cta + 0.22 * variety + 0.17 * rhythm_score + 0.15 * scene_variety)
    return {
        "score": round(score, 1),
        "tipo": "adequacao_estrutural_observavel",
        "nao_e": ["viralizacao", "alcance_futuro", "garantia_de_desempenho"],
        "componentes": {
            "hook": round(hook * 100, 1),
            "cta": round(cta * 100, 1),
            "variedade_estrutura": round(variety * 100, 1),
            "ritmo": round(rhythm_score * 100, 1),
            "variedade_cenas": round(scene_variety * 100, 1),
        },
    }


def analyze_transcript(segments: list[dict[str, Any]], duration: float, visuals: dict[str, Any] | None = None, context: dict[str, Any] | None = None) -> dict[str, Any]:
    visuals = visuals or {}
    full_text = " ".join(str(s.get("text") or "").strip() for s in segments).strip()
    first_text = " ".join(str(s.get("text") or "").strip() for s in segments[:2]).strip()
    last_text = " ".join(str(s.get("text") or "").strip() for s in segments[-3:]).strip()
    structure = classify_structure(segments, duration)
    rhetoric = build_rhetoric(full_text, first_text, last_text, duration)
    rhythm = build_rhythm(segments, duration, int(visuals.get("scene_count") or 0))
    gaps = infer_gaps(structure, rhetoric, visuals)
    opportunities = build_opportunities(structure, rhetoric, gaps)
    dna = build_dna(structure, rhetoric, rhythm, visuals)
    score = evi_score(rhetoric, rhythm, structure, visuals)
    terms = [w for w, _ in Counter(words(full_text)).most_common(16)]
    fingerprint = content_fingerprint(structure, rhetoric, rhythm)
    fit = build_context_fit(terms, context)
    return {
        "estrutura": structure,
        "retorica": rhetoric,
        "ritmo": rhythm,
        "dna": dna,
        "lacunas": gaps,
        "oportunidades": opportunities,
        "evi_score": score,
        "termos": terms,
        "impressao_digital": fingerprint,
        "ajuste_contextual_observavel": fit,
    }
