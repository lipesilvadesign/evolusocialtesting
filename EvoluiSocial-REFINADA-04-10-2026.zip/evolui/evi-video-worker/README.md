# EVI Video Worker v1 — Evolui Video Intelligence

A camada própria da Evolui para transformar vídeo público em sinais estruturados de conteúdo.

```text
URL
 ↓
yt-dlp 2026.08.19
 ↓
FFmpeg
 ↓
faster-whisper 1.2.1
 ↓
segmentos + palavras + timestamps
 ↓
OpenCV + PySceneDetect 0.7.1
 ↓
EVI heurístico
 ↓
DNA + estrutura + retórica + ritmo + gaps + oportunidades + score estrutural
```

## O que é propriedade da Evolui nesta camada

Os componentes open source funcionam como sensores/infraestrutura. A camada EVI é responsável por organizar os sinais em uma representação própria: **EVI-DNA**, estrutura, lacunas, oportunidades e score estrutural observável.

## Endpoint

`GET /health`

`POST /analyze`

```json
{
  "url": "https://www.youtube.com/watch?v=...",
  "plataforma": "youtube",
  "contexto": {
    "ramo": "imobiliario",
    "objetivo": "gerar comentarios",
    "rede": "instagram"
  }
}
```

## Segurança

- aceita apenas HTTPS de YouTube, TikTok e Instagram públicos;
- impõe tamanho máximo configurável do arquivo;
- usa diretórios temporários por requisição;
- não persiste o arquivo do vídeo;
- `EVI_WORKER_TOKEN` é um segredo **interno da infraestrutura da Evolui** e recomendado quando o worker estiver público.

Não há API key de fornecedor de transcrição.

## Limites da v1

Ainda não há OCR, entendimento semântico profundo de frames, diarização, comparação com um corpus externo ou aprendizado de pesos por métricas reais.


## YouTube: observação de runtime JS

A distribuição usa `yt-dlp[default]`, que inclui o pacote `yt-dlp-ejs`. Para suporte completo ao YouTube, o ambiente de execução também precisa de um runtime JavaScript compatível, conforme a documentação atual do yt-dlp. Isso é uma dependência operacional do adaptador de aquisição, não do motor EVI.
