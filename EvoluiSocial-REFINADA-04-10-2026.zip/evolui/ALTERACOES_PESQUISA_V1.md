# Alterações — Pesquisa Avançada v1

## Adicionados
- `supabase/functions/evolui-api/eie/pesquisa/README.md`
- `supabase/functions/evolui-api/eie/pesquisa/tipos.ts`
- `supabase/functions/evolui-api/eie/pesquisa/plano.ts`
- `supabase/functions/evolui-api/eie/pesquisa/searxng.ts`
- `supabase/functions/evolui-api/eie/pesquisa/fusao.ts`
- `supabase/functions/evolui-api/eie/pesquisa/orquestrador.ts`
- `tests/pesquisaAvancada.test.js`
- `docs/AUDITORIA_MOTOR_PESQUISA_03_10_2026.md`

## Alterados
- `supabase/functions/evolui-api/consulta.ts`
  - corrige interpretação de negócio local;
  - preserva cidades compostas;
  - separa ano explícito do assunto;
  - evita ano em `termosBusca`.
- `supabase/functions/evolui-api/index.ts`
  - importa a pesquisa avançada;
  - executa apenas quando o modo shadow é habilitado;
  - adiciona campo opcional `pesquisa_avancada` à resposta;
  - não injeta resultados novos no ranking EIE.

## Não alterados
- SQL/schema do Supabase.
- Integração Claude/Anthropic.
- ranking EIE existente.
- EvoluiScore existente.
- fontes legadas existentes.
