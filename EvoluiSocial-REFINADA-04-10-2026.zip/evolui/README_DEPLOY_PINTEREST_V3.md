# Evolui Social — Deploy Pinterest v3

## Correções aplicadas

1. O frontend deixou de chamar a função inexistente `evolui-referencias`. Pinterest e YouTube usam o gateway autenticado real `evolui-api`.
2. O provedor Pinterest envia os termos contextuais da consulta para o backend.
3. O backend consulta o endpoint oficial de Pinterest Trends para o Brasil, com cache de 15 minutos, timeout de 3,5 s e disjuntor por fonte.
4. O ranking do Pinterest é filtrado por relevância contextual antes de chegar ao Laboratório. Crescimento WoW é sinal auxiliar, não substitui aderência.
5. O Laboratório mostra status da busca e a relevância contextual do sinal em uma barra visual.
6. O token continua exclusivamente no servidor em `PINTEREST_ACCESS_TOKEN`; nenhum token foi incluído no ZIP.

## O que ainda depende do ambiente remoto

Este pacote contém o código corrigido, mas não consegue alterar sozinho o projeto Supabase/Netlify remoto. Para colocar a integração em produção, faça o deploy da Edge Function `evolui-api` e publique o frontend deste diretório no mesmo projeto do site. O secret `PINTEREST_ACCESS_TOKEN` deve existir no ambiente de produção da Edge Function.

## Verificação esperada

Depois do deploy, abrir Laboratório → criar/editar um teste → definir o assunto do vídeo. O bloco de referências deve exibir o status de busca e, quando a API de Trends estiver habilitada para o aplicativo, cards com selo Pinterest, crescimento WoW, relevância contextual e botão `Ver inspiração`.

Se o aplicativo não tiver acesso ao endpoint de Trends, o Laboratório continua funcionando e não deve expor erro técnico nem o token.

## Limitação oficial

A API de Trends fornece palavras-chave e sinais de crescimento. A API não equivale a uma pesquisa pública irrestrita de todos os Pins com miniaturas. Por isso, o produto usa a tendência oficial como sinal e leva o usuário para a busca correspondente do Pinterest.
