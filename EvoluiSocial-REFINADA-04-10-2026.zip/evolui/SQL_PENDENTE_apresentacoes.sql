-- ============================================================
-- PROMPT 3 — Apresentação estratégica web + PDF
-- ============================================================
-- DECISÃO DE ARQUITETURA: `conteudo` aqui é um SNAPSHOT explicitamente
-- montado pelo usuário na aba Apresentação (não é uma view ao vivo do
-- briefing/diagnóstico/métricas). Isso cumpre a regra do prompt de nunca
-- publicar automaticamente tudo que está cadastrado — só entra o que foi
-- escolhido, na hora de publicar. Também é o que permite versionamento de
-- verdade (v1 continua existindo, intacta, mesmo depois de v2 existir).
--
-- RLS desta tabela é DIFERENTE de todas as outras do projeto: além da
-- policy padrão pra `authenticated` (o painel), existe uma policy pra
-- `anon` liberando SELECT só em linhas com status='publicado'. É assim que
-- a página pública /apresentacao/[slug] funciona sem exigir login — mas
-- ela nunca expõe rascunho, e a Function pública (apresentacao-publica.js)
-- ainda filtra as colunas retornadas (nunca devolve lead_id/criado_por).
-- ============================================================

create table if not exists admin_apresentacoes (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references admin_prospeccao_leads(id) on delete cascade,
  slug text not null unique,
  versao int not null default 1,
  status text not null default 'rascunho' check (status in ('rascunho', 'publicado')),
  tema jsonb not null default '{}'::jsonb,
  conteudo jsonb not null default '{}'::jsonb,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz,
  publicado_em timestamptz,
  unique (lead_id, versao)
);

alter table admin_apresentacoes enable row level security;

create policy "authenticated_select_apresentacoes" on admin_apresentacoes for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_apresentacoes" on admin_apresentacoes for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_apresentacoes" on admin_apresentacoes for update using (auth.role() = 'authenticated');
create policy "authenticated_delete_apresentacoes" on admin_apresentacoes for delete using (auth.role() = 'authenticated');

-- Acesso público (sem login) — só o que já foi publicado.
create policy "anon_select_apresentacoes_publicadas" on admin_apresentacoes for select
  using (status = 'publicado');

create index if not exists admin_apresentacoes_slug_idx on admin_apresentacoes (slug);
