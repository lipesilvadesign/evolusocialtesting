# Evolui Social — Release final EVI + KeyAPI Benchmark

Data: 04/10/2026
Versão de pacote: `evi-keyapi-final-2026-10-04`

## Conteúdo desta rodada

- EVI Video Intelligence v1;
- EKE Knowledge Engine;
- inteligência comportamental agregada;
- Pinterest oficial no Laboratório;
- provider KeyAPI isolado;
- benchmark KeyAPI com limite de créditos;
- SQL consolidado para as novas estruturas;
- correção da persistência EVI via service role;
- worker EVI preparado para YouTube com yt-dlp-ejs + runtime JS;
- documentação de deploy consolidado.

## Correções críticas antes do empacotamento

1. A persistência em `evolui_video_analises` foi ajustada de `sb` para `adm` (service role), compatível com a RLS/grants da tabela.
2. `yt-dlp` foi fixado em `2026.08.19`, versão estável verificada no repositório oficial.
3. `yt-dlp-ejs==0.8.0` foi adicionado.
4. Deno 2.9.6 foi adicionado ao container do worker para atender ao runtime JS recomendado/compatível do EJS.
5. O benchmark KeyAPI foi validado em DRY-RUN e mantém teto absoluto de 98 créditos; não há chave embutida.

## Cota KeyAPI

- saldo disponível informado pelo usuário: 98 créditos;
- teto absoluto no benchmark: 98;
- reserva operacional: 8;
- plano v1: 56 créditos;
- chamadas no plano: 26;
- restante esperado após uma execução completa do plano: 42 créditos.

A execução LIVE não foi feita neste ambiente porque a chave privada `KEYAPI_API_KEY` não está disponível aqui. Nenhuma chave do usuário foi reutilizada, copiada ou empacotada.

## Política de produção

A KeyAPI NÃO é ativada automaticamente no fluxo de pesquisa da Evolui nesta versão. O provider está pronto, mas o benchmark deve ser observado antes de consumir créditos em produção. O EIE continua sendo o responsável por retrieval/ranking/contextualização; KeyAPI é apenas aquisição complementar.
