# Consultas — copy do CTA com técnicas de vendas — 14/09 (10ª rodada)

## O que foi pedido

Você mandou um documento grande com metodologia de vendas (Eugene Schwartz, Alex Hormozi, Russell Brunson, Gary Halbert, Dan Kennedy e outros) e pediu pra usar como referência na página de consultas. Perguntei o alcance e você confirmou: **só nos pontos de conversão** (CTA final, botões, chamada pra WhatsApp/agendar), sem mexer no texto do diagnóstico em si (aquele gerado pelo motor pra cada pessoa).

## O que eu mudei

Três frases, nos três lugares onde elas aparecem (a página tem um texto padrão que só aparece antes do JavaScript carregar, e depois o próprio motor de diagnóstico confirma o mesmo texto):

**1. Frase de credibilidade (logo antes do CTA)**

- Antes: "Quem leu seu diagnóstico até aqui: essa análise saiu direto da Felipe Branding: branding e Instagram para negócios que querem parecer (e ser) sérios."
- Agora: "Quem chegou até aqui já viu do que a Felipe Branding é capaz: leitura direta, sem enrolação, pra negócios que querem parecer (e ser) sérios no Instagram."

Por quê: em vez de só dizer "de onde veio" a análise, a frase agora usa o próprio diagnóstico que a pessoa acabou de ler como prova (ela já viu do que você é capaz, na prática, não é só um discurso). É o princípio do Hormozi de aumentar a "probabilidade percebida" sem precisar inventar número ou depoimento (eu não tinha dado real pra usar, e não ia inventar estatística ou caso de cliente).

**2. Título do CTA**

- Antes: "Quer entender como transformar esse diagnóstico em um posicionamento mais forte?"
- Agora: "Esse diagnóstico foi só o ponto de partida. Numa conversa, a gente transforma isso em um plano de ação pro seu Instagram."

Por quê: a pessoa já recebeu valor de graça (o diagnóstico) — a frase reconhece isso e deixa claro o que ela ganha a mais na conversa (um "plano de ação", coisa concreta, não só "entender melhor"). É o AIDA do Halbert (a headline puxa desejo com um resultado específico) misturado com o "resultado sonhado" do Hormozi: quanto mais concreta a promessa, melhor.

**3. Botão principal**

- Antes: "Falar com Felipe"
- Agora: "Falar com Felipe agora"

Por quê: um empurrão de urgência bem pequeno, mas verdadeiro — é WhatsApp, então "agora" não é promessa vazia, é literalmente como funciona.

## O que eu decidi não mudar (e por quê)

- **A frase "Não criamos por views, criamos por pessoas."** — é a sua marca registrada nessa página, você mesmo pediu pra colocar numa rodada anterior. Não mexi.
- **A frase "Análise → percepção do momento atual → conversa → agendamento. Sem pressão, no seu tempo."** — já faz exatamente o que os métodos pedem: mostra o caminho (evita surpresa) e tira a pressão de decidir na hora (objeção mais comum: "vou ser empurrado a comprar?"). Já tava boa, mexer ia só arriscar piorar.
- **Escassez/urgência artificial** (tipo "só 3 vagas essa semana") — o Hormozi é bem direto sobre isso: só use se for verdade. Eu não sei se você realmente tem limite de vagas por semana, então não inventei. Se você tiver um limite real (de conversas por semana, por exemplo), me avisa que eu boto isso na página — vira um dos pontos mais fortes de conversão, mas só se for fato.
- **Número/estatística de resultado** (tipo "+200 perfis atendidos") — mesma lógica: só uso se você me passar o número real.
- **A quantidade de botões (3 opções de CTA)** — os métodos de vendas em geral preferem 1 ação só, pra não diluir a decisão. Mas isso é uma mudança de estrutura/design, não de texto, e você pediu especificamente "os pontos de conversão" no sentido de texto. Se quiser, posso sugerir numa próxima rodada como simplificar isso sem tirar as opções (por exemplo, deixando só "Falar com Felipe" em destaque e as outras duas como link mais discreto).

## Uma observação técnica

O título do CTA (item 2) é gerado dentro do arquivo do motor de diagnóstico (`diagnosticoEngine.js`), mas é sempre o mesmo texto fixo pra todo mundo (não varia por categoria nem por pessoa) — ele não é "análise do perfil", é literalmente a frase do convite pra conversa, só que por acaso mora nesse arquivo. Por isso considerei que estava dentro do combinado (só ponto de conversão), mesmo estando fisicamente no arquivo do motor. Se você preferir que eu não toque nesse arquivo de jeito nenhum, é só falar que eu reverto só essa parte.

## Verificação

- `node --check` nos três arquivos tocados (`consultas.html`, `assets/js/consultas.js`, `netlify/functions/_lib/diagnosticoEngine.js`): sem erro.
- Suíte de testes: **174 testes, todos passando** (o teste do motor só confere que `ctaTexto` é uma string, não o conteúdo exato, então não precisou mudar).
- Testei de ponta a ponta (celular 390px e computador 1440px): nenhum texto novo estourou o card ou os botões, tudo quebra linha direitinho.
- Sem travessão em nenhuma frase nova (mantive a regra da rodada anterior).
- Atualizei a prévia ao vivo de novo (mesmo link, agora Versão 4).

## O que fazer agora

Nada manual, sem mudança de banco. Só instalar o zip anexo por cima do anterior.

Se quiser, me manda um número real de resultado (clientes atendidos, perfis analisados, o que fizer sentido) ou me confirma se existe um limite real de vagas por semana — com isso eu já sei aplicar o próximo nível dessas técnicas (prova social real e escassez verdadeira) sem inventar nada.
