-- ==============================================================
-- Avatar ilustrado — galeria de escolha (pedido do Felipe, 14/09, 3ª
-- rodada). Roda no SQL Editor do Supabase (projeto real, produção).
--
-- Antes: o avatar ilustrado de quem não tem foto_url era escolhido pelo
-- campo `genero` (masculino/feminino → 1 de 2 desenhos fixos). Agora: a
-- pessoa escolhe diretamente entre 10 avatares numa galeria em "Meu
-- Perfil" (ver avatarIlustrado.js/perfil.js) — mais direto e sem forçar
-- ninguém a passar por uma pergunta de gênero só pra trocar de ícone.
--
-- `genero` NÃO é removido (nenhum DROP aqui) — só para de decidir o
-- avatar. O backfill abaixo preenche `avatar_escolhido` a partir do
-- `genero` que já existia, pra ninguém "perder" o avatar que já tinha
-- só por causa desta migração.
-- ==============================================================

-- ------------------------------------------------------------
-- 1) Coluna nova — mesmo esquema de sempre (nullable, dono da linha
-- edita a própria: já coberto pela policy "update_propria_linha_ou_admin"
-- e pelo trigger protege_colunas_sensiveis, que só trava role/ativo/
-- email/criado_por — nenhum dos dois precisa mudar pra isto funcionar).
-- ------------------------------------------------------------
alter table admin_funcionarios add column if not exists avatar_escolhido text;

comment on column admin_funcionarios.avatar_escolhido is 'Id de um dos avatares ilustrados da galeria (a1..a10, ver AVATARES_DISPONIVEIS em avatarIlustrado.js) — escolhido pela própria pessoa em "Meu Perfil". Nulo = ainda não escolheu: cai no avatar por gênero (compatibilidade) e, sem isso também, nas iniciais do nome.';

-- ------------------------------------------------------------
-- 2) Backfill — só preenche quem tem `genero` definido e ainda não tem
-- `avatar_escolhido` (idempotente: rodar de novo não sobrescreve uma
-- escolha que a pessoa já tenha feito na galeria nova). Mapeamento:
-- masculino → a1, feminino → a6 (os dois avatares "sucessores diretos"
-- dos antigos, mesma posição na galeria usada como fallback no código).
-- ------------------------------------------------------------
update admin_funcionarios
set avatar_escolhido = case genero when 'masculino' then 'a1' when 'feminino' then 'a6' else avatar_escolhido end
where avatar_escolhido is null and genero is not null;

-- ------------------------------------------------------------
-- 3) Schema cache do PostgREST — sem isto, a coluna nova pode continuar
-- dando 404/erro por alguns minutos até o cache expirar sozinho.
-- ------------------------------------------------------------
notify pgrst, 'reload schema';

-- ------------------------------------------------------------
-- 4) Conferência final — rode e confira:
--    avatar_escolhido_existe → esperado: true
--    linhas_com_genero_sem_backfill → esperado: 0 (ninguém com gênero
--    definido deveria ter ficado sem avatar_escolhido após o passo 2)
-- ------------------------------------------------------------
select
  exists (
    select 1 from information_schema.columns
      where table_name = 'admin_funcionarios' and column_name = 'avatar_escolhido'
  ) as avatar_escolhido_existe,
  (select count(*) from admin_funcionarios where genero is not null and avatar_escolhido is null) as linhas_com_genero_sem_backfill;
