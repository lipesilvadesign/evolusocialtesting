# Relatório — Refatoração do site e indexação (30/09/2026)

Os dois pedidos (refatoração master e indexação no Google) foram tratados juntos: as mudanças se sobrepõem. O site continua estático, sem biblioteca nova, e as funcionalidades existentes foram preservadas.

## A. O que foi alterado

| Arquivo | Mudança |
|---|---|
| `index.html` (gerado pelo modelo da home) | "Antes e Depois" removido. Nova seção **Consultoria gratuita** logo depois do hero. Hero, serviços, método, chamada final e rodapé reescritos. Novos title, description, canonical, og e JSON-LD. Menu com "Consultoria gratuita". |
| `assets/js/site.b87fa9c84d.js` | Código do comparador removido (4 funções e chamadas). Novos textos padrão (hero, 6 serviços, método em 6 etapas, chamada final). Serviços/método vazios no painel passam a usar o texto padrão. |
| `assets/css/main.6961b411ae.css` | CSS do comparador removido (cerca de 120 linhas). Estilos da seção de consultoria. Menu que não quebra linha entre 1080 e 1360 px. |
| `consultas.html` (servido em **/consultoria**) | Hero com a estrela da marca em motion. Textos sobre o que é analisado, como funciona, quem faz e perguntas frequentes. Um único H1. Novos title, description e canonical. JSON-LD de página, serviço, trilha e FAQ. |
| `assets/css/consultas.css` | Hero, animações com versão para "reduzir movimento" e layout dos novos blocos. |
| `assets/js/consultas.js` | Botão do hero abre direto a etapa 1. Trava contra envio duplicado. Mensagens de erro claras. Movimento do hero com scroll e mouse. |
| `admin.html` + `assets/js/admin.34654eadab.js` | Painel "Antes / Depois" removido do editor. Textos padrão sincronizados com o site. Novos ícones de serviço (bússola, tendência). Rótulo do seletor de ícone associado ao campo. |
| `_redirects` | Nova rota `/consultoria`. `/consultas` redireciona com **301** para `/consultoria`, então links antigos (bio, WhatsApp) continuam funcionando. |
| `_headers` | `X-Robots-Tag: noindex, nofollow` em /admin, /painel e /apresentacao/*. |
| `robots.txt`, `sitemap.xml`, **`llms.txt` (novo)** | Ver seções C e E. |
| `painel/.../consultorias.js` | Texto do painel aponta para /consultoria. |
| **Banco (site_content)** | Textos novos aplicados em produção (hero, serviços, método, chamada final, endereço, rodapé) e remoção do bloco `compare`. Backup do conteúdo anterior em `backup_auditoria.site_content_30_09`. |
| Robô | Testa /consultoria (inclusive o hero) e confere que não sobrou nada do "Antes e Depois" e que a consultoria vem logo depois do hero. |

## B. Bugs encontrados

| Bug | Causa | Correção |
|---|---|---|
| **Seção "Serviços" vazia em produção** (só o título aparecia) | O conteúdo salvo no painel tinha `services: []` | 6 serviços gravados. Lista vazia agora usa o padrão em vez de sumir. |
| **Domínio canônico errado**: canonical, sitemap, og:url e robots apontavam para `www.felipebranding.com.br` | O domínio principal no Netlify é **sem www** (o www redireciona). O Google recebia sinais conflitantes. | Tudo passa a usar `https://felipebranding.com.br`. |
| Chamada final prometia "baixe o guia gratuito / receba o material na hora" | O guia nunca existiu | Texto trocado pela consultoria gratuita (real). |
| Consultoria com 2 H1 na página | O nome do perfil no resultado era um H1 | Virou H2. |
| Erro de rede mostrava "Failed to fetch" (em inglês) e página de erro do provedor mostrava "Unexpected token <" | Mensagem técnica repassada ao visitante | Mensagens claras em português. |
| Clique duplo em "Tentar novamente" podia criar 2 leads iguais | Sem trava de envio | Trava enquanto o envio está em andamento (testado: 1 chamada). |
| Menu do topo quebrava em 2 linhas entre 1080 e 1360 px | Itens demais sem `nowrap` | "Depoimentos" saiu do menu desktop (continua no celular e na página). Espaçamento ajustado. Sem estouro de 320 a 1920 px. |
| "4 frentes de serviço" no hero e na biografia | Os serviços passaram a ser 6 | Atualizado para 6 frentes de atuação. |

## C. SEO

- **Title** e **meta description** próprios em cada página indexável, sem duplicação:
  - home: "Felipe Branding | Branding e Marketing em Petrolina e Vale do São Francisco";
  - consultoria: "Consultoria Gratuita de Marca para Instagram em Petrolina | Felipe Branding".
- **Canonical** correto (sem www) nas duas páginas. /consultas redireciona com 301 para /consultoria.
- **robots.txt**: libera o site todo e bloqueia só `/admin`, `/painel` e `/.netlify/` (APIs). Aponta para o sitemap no domínio certo.
- **sitemap.xml**: só `/` e `/consultoria`, com `lastmod`.
- Páginas privadas protegidas em duas camadas: `noindex` no HTML e `X-Robots-Tag` no servidor.
- **Headings**: um H1 por página; seções com H2 e H3 semânticos.
- **Links internos**: a consultoria agora aparece no menu (desktop e celular), no hero, na seção logo abaixo, na chamada final e no rodapé. A consultoria volta para a home pelo logo e por um link no texto. Nenhuma página órfã.
- **Conteúdo rastreável**: os textos da home e da consultoria estão no HTML. O Google não depende do JavaScript nem do banco para ler.

### Tabela de indexabilidade (rotas reais do projeto)

| URL | Pública | Indexável | Sitemap | Canonical | Link interno | Status |
|---|---|---|---|---|---|---|
| `/` | SIM | SIM | SIM | SIM | SIM | OK |
| `/consultoria` | SIM | SIM | SIM | SIM | SIM (6 links na home) | OK |
| `/consultas` | — | — | NÃO | — | — | 301 → /consultoria |
| `/index.html`, `/consultas.html` | acesso direto | canonical aponta para a URL limpa | NÃO | SIM | — | OK (duplicata resolvida pelo canonical) |
| `/apresentacao/<cliente>` | link privado | NÃO (noindex + header) | NÃO | — | — | Fora de propósito (proposta de cliente) |
| `/admin` | NÃO | NÃO | NÃO | — | — | Bloqueada |
| `/painel/*` | NÃO | NÃO | NÃO | — | — | Bloqueada |
| `/.netlify/functions/*` | API | NÃO | NÃO | — | — | Bloqueada no robots |
| `/llms.txt`, `/robots.txt`, `/sitemap.xml` | SIM | arquivos técnicos | — | — | — | OK |
| Arquivos internos (.md, .sql, testes) | NÃO | NÃO | NÃO | — | — | 404 forçado |

Rotas como /servicos, /branding e /identidade-visual **não existem** e não foram criadas: seriam páginas vazias só para gerar URL.

## D. SEO local

O site passou a dizer, em linguagem natural e sem repetição artificial:

- **Hero**: "Branding e marketing — Petrolina, PE · Vale do São Francisco" e "empresas de Petrolina, Juazeiro e do Vale do São Francisco".
- **Consultoria**: "a principal vitrine de muitas empresas do Vale do São Francisco" e "feita pela Felipe Branding, de Petrolina".
- **Endereço e rodapé**: "Petrolina, PE — Vale do São Francisco, com atendimento remoto para todo o Brasil".
- **Dados estruturados**:
  - `ProfessionalService` com endereço (Petrolina, PE, BR);
  - `areaServed` = Petrolina, Juazeiro, Vale do São Francisco e Brasil;
  - telefone e e-mail iguais aos do site;
  - fundador e ano de início (2015, como já está no site);
  - áreas de conhecimento.
- Mesmos dados em site, schema, rodapé, metadados e llms.txt.

## E. AI/GEO

- **`/llms.txt`** (novo): quem é, fundador, localização, região atendida, serviços com definição, método, consultoria gratuita (inclusive que ela não acessa a conta do Instagram), páginas importantes e contato. Tudo tirado do próprio site ou do briefing, sem nada inventado.
- A página /consultoria ganhou texto que responde de forma direta: o que é analisado (5 áreas), como funciona (3 passos), quem faz e perguntas frequentes.
- Entidades consistentes: "Felipe Branding", "Felipe Souto", "Petrolina", "Vale do São Francisco", ligadas por `@id` entre home e consultoria no JSON-LD.

## F. Performance

- Nenhuma biblioteca nova. O motion da consultoria é SVG + CSS (cerca de 3 KB) e um script pequeno.
- Animações só com `transform` e `opacity`. O scroll e o mouse só atualizam variáveis CSS dentro de `requestAnimationFrame`, e só enquanto o hero está na tela (IntersectionObserver).
- Cerca de 120 linhas de CSS e 4 funções JS mortas removidas (comparador).
- Arquivos da home e do admin com hash novo no nome (cache de 1 ano seguro). consultas.css e consultas.js já tinham exceção de cache.

## G. UX/UI

- A home responde em segundos: quem é, o que faz, região e **como pedir a consultoria**. O botão principal do hero leva à consultoria e o secundário leva a "Conhecer a Felipe Branding".
- A consultoria aparece **logo depois do hero**, explicando o que o diagnóstico cobre de verdade.
- "O que a Felipe Branding faz": 6 frentes (Branding, Identidade Visual, Posicionamento, Estratégia de Marca, Conteúdo, Marketing), cada uma com a sua função.
- Método: Posicionamento → Identidade → Conteúdo → Experiência → Prova → Decisão.
- Chamada final: consultoria gratuita + agendar conversa.
- /consultoria: o antigo passo 0 do formulário virou um hero. O botão abre direto a primeira pergunta com o cursor no campo. Durante o formulário, hero e textos saem de cena.
- Botão principal na primeira tela em todas as larguras (320 a 1920 px). Nenhuma rolagem lateral.

## H. Motion design

| Animação | Por quê |
|---|---|
| Estrela surge com blur → nítida e escala 0,72 → 1 | Entrada de marca, uma vez só |
| Linhas de conexão se desenham a partir da estrela | "Direção" e conexão entre pontos, a proposta do símbolo |
| Três órbitas tracejadas girando devagar (40–90 s por volta), com pequenos pontos | Precisão e tecnologia, sem distrair a leitura |
| Brilho que "respira" (7 s) | Luz controlada, sem neon |
| Seis partículas quase imperceptíveis | Profundidade, no limite do sutil |
| Parallax no scroll (estrela sobe e gira, fundo desce) | A estrela reage à rolagem |
| Inclinação de poucos pixels seguindo o mouse (só mouse, não toque) | Microinteração com a interface |
| Botão principal "acende" a estrela e as linhas | A interface conversa com a marca |
| Textos do hero entram em sequência (14 px, 80 ms entre cada) | Hierarquia de leitura |

Com **"reduzir movimento"** ativo, tudo fica parado, com a composição completa visível. Testado a 390 e 1440 px: nenhuma animação e nenhum parallax.

## I. Pendências (só o que depende de você)

1. **Publicar no Netlify** (arrastar o `site-completo-corrigido.zip` em Deploys). Os textos novos já estão no banco. Até a publicação, o site antigo mostra os textos novos no layout antigo; por exemplo, o botão "Conhecer a consultoria gratuita" ainda leva ao formulário de contato.
2. **Google Search Console**: adicionar a propriedade `felipebranding.com.br` (de preferência como Domínio), enviar `https://felipebranding.com.br/sitemap.xml`, usar "Inspeção de URL" em `/` e `/consultoria` e pedir indexação. O site fica elegível, mas quem decide quando indexar é o Google.
3. **Depoimentos**: "Mariana R.", "Lucas C." e "Paula A." vieram do modelo original do site. Não consigo confirmar se são clientes reais. Se não forem, remova ou substitua no editor (/admin → Depoimentos). O mesmo vale para os números do hero (10 anos, 100% direção estratégica).
4. **E-mail de contato**: o site mostra `contato@felipebranding.com.br`, mas a caixa que funciona no servidor de e-mail é `marketing@`. Confirme se contato@ existe (ou é um redirecionamento). Se não existir, troque no /admin → Contato. O mesmo e-mail está no JSON-LD e no llms.txt.
5. **Página /privacidade (LGPD)**: os formulários guardam nome, e-mail e WhatsApp. O texto da política é decisão jurídica sua; depois é só criar a página e linkar no rodapé.
6. **Diagnóstico da consultoria**: as avaliações por área são montadas pelas respostas e por variações de texto, não por leitura do perfil. A página agora diz isso com clareza (FAQ e llms.txt). Se quiser um diagnóstico que olhe o perfil de verdade, é um projeto à parte.
7. **"Tempo real"**: não existe hoje nenhum dado real de disponibilidade ou fila da consultoria, então não criei contador nem indicador. Os estados reais (carregando, sucesso, erro, reenvio) estão implementados. Para mostrar, por exemplo, "agenda disponível esta semana", o ponto de integração é uma Function nova (`netlify/functions/consultoria-status.js`) lendo uma configuração no Supabase. A página chamaria essa Function no carregamento de `assets/js/consultas.js`.

## Testes da segunda auditoria

- Testes do projeto: **208/208**.
- Robô: **0 crítico**. Bugs & código **95/100** (era 87). UX & conversão **74/100** (era 54).
- Fluxo completo de /consultoria no navegador (desktop e celular):
  - o hero sai de cena ao iniciar;
  - validações funcionam;
  - 16 segmentos carregados;
  - o diagnóstico aparece;
  - nada de "undefined".
- Home de 320 a 1920 px:
  - 0 px de rolagem lateral;
  - 0 restos do "Antes e Depois";
  - consultoria logo depois do hero;
  - 6 links para /consultoria;
  - 6 serviços.
- /consultoria em 11 larguras (320 a 1920):
  - 0 rolagem lateral;
  - botão principal na primeira tela;
  - 1 H1;
  - animações ligadas;
  - com "reduzir movimento", todas desligadas.
- Envio da consultoria:
  - erro de rede e erro 502 mostram mensagens claras;
  - clique duplo gera 1 chamada;
  - o foco vai para o primeiro campo.

### Checklist do index

- [x] "Antes e Depois" removido completamente (HTML, CSS, JS, textos padrão, editor do /admin, conteúdo no banco)
- [x] Consultoria gratuita aparece no início (logo depois do hero)
- [x] CTA da consultoria funciona (hero, seção, chamada final, menu, rodapé)
- [x] `/consultoria` abre corretamente (e `/consultas` redireciona)
- [x] Nenhum JavaScript depende do bloco removido
- [x] Nenhum CSS morto do bloco removido
- [x] Nenhum link quebrado
- [x] Celular e desktop funcionando

### Checklist da consultoria

- [x] Hero, estrela da marca e motion funcionando
- [x] Animações suaves, sem travamento (só transform/opacity)
- [x] `prefers-reduced-motion` funcionando
- [x] CTA, formulário, carregamento, sucesso e erro funcionando
- [x] Celular, tablet e desktop funcionando
- [x] SEO e schema configurados (WebPage, Service, BreadcrumbList, FAQPage)
