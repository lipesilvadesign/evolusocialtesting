-- Tabelas da ferramenta "Consultoria Gratuita de Perfil para Instagram"
-- (rota pública /consultas + área "Consultorias" na central administrativa).
-- Rode isto no SQL Editor do projeto Supabase (aligftypgtzlymmditeo) antes de
-- publicar a ETAPA 2. Sem isso, o formulário de /consultas responde com erro
-- tratado (não quebra o resto do site) e a aba "Consultorias" do painel mostra
-- erro tratado (não quebra o resto do painel).
--
-- Mesmo padrão de RLS já usado em admin_prospeccao_leads (ver
-- SQL_PENDENTE_prospeccao.sql), com uma diferença central: esta tabela recebe
-- ESCRITA DE VISITANTE ANÔNIMO (o formulário público não exige login), então
-- as políticas de "anon" abaixo são o ponto mais sensível deste arquivo —
-- leia os comentários antes de rodar.

-- ============================================================
-- TABELA PRINCIPAL: consultas_leads
-- ============================================================

create table if not exists consultas_leads (
  id uuid primary key default gen_random_uuid(),

  -- Campos coletados no formulário público (ETAPA 1/2). Como esta tabela
  -- aceita INSERT direto do papel "anon" (ver política mais abaixo), a
  -- validação feita em netlify/functions/consultas-criar.js pode ser
  -- contornada por quem chamar a REST do Supabase diretamente com a chave
  -- anônima (pública por padrão do projeto) — por isso os mesmos formatos já
  -- validados na Function são reforçados aqui também, como segunda camada.
  -- Isso também é o que protege o painel administrativo de XSS armazenado:
  -- sem isto, "nome"/"instagram" poderiam chegar com HTML/script arbitrário.
  nome text not null check (char_length(nome) between 2 and 120),
  instagram text not null check (instagram ~ '^[A-Za-z0-9._]{1,30}$'),
  whatsapp text not null check (whatsapp ~ '^[0-9]{10,13}$'),
  email text check (email is null or (char_length(email) <= 180 and email ~ '^[^\s@]+@[^\s@]+\.[^\s@]+$')),
  segmento text not null check (segmento in (
    'moda_vestuario','beleza_estetica','saude_bem_estar','fitness','alimentacao','imoveis',
    'educacao_cursos','servicos_profissionais','direito_contabilidade','construcao_arquitetura',
    'varejo_ecommerce','pet','tecnologia','artesanato_criativo','eventos','outro'
  )),
  objetivo text not null check (objetivo in (
    'crescer_seguidores','gerar_vendas','atrair_clientes_locais','fortalecer_autoridade',
    'organizar_identidade','converter_contatos','outro'
  )),

  -- De onde veio a solicitação (ex: "consultas_site", "instagram_bio",
  -- valor de uma querystring ?origem=... quando o link tiver origem
  -- rastreável). Nunca nulo — sempre tem um valor padrão.
  origem text not null default 'consultas_site' check (origem ~ '^[a-z0-9_]{1,60}$'),

  -- Pipeline da oportunidade (ETAPA 2).
  status text not null default 'novo'
    check (status in ('novo','analisando','analise_enviada','contatado','reuniao_agendada','convertido','arquivado')),

  -- Resultado do diagnóstico (ETAPA 3) — gerado pelo motor determinístico em
  -- netlify/functions/_lib/diagnosticoEngine.js no MESMO request que cria o
  -- lead (nunca calculado no navegador, pra não poder ser adulterado antes
  -- de chegar ao banco). Formato documentado no próprio motor.
  resultado_analise jsonb,
  resultado_gerado_em timestamptz,

  -- Conversão (ETAPA 4).
  consultoria_concluida_em timestamptz,
  cta_clicado text check (cta_clicado in ('whatsapp','agendamento','instagram')),
  cta_clicado_em timestamptz,
  tentativa_agendamento boolean not null default false,
  tentativa_agendamento_em timestamptz,

  -- Campos exclusivos do painel administrativo (ETAPA 2) — o visitante
  -- nunca escreve nestes, ver política anon_insert_consultas_leads abaixo.
  contato_realizado boolean not null default false,
  ultimo_contato_em timestamptz,
  observacoes_internas text,
  atualizado_por text,

  created_at timestamptz not null default now(),
  updated_at timestamptz
);

alter table consultas_leads enable row level security;

create index if not exists consultas_leads_status_idx on consultas_leads (status);
create index if not exists consultas_leads_created_at_idx on consultas_leads (created_at desc);

comment on table consultas_leads is 'Leads da Consultoria Gratuita de Perfil para Instagram (/consultas). Cada linha = uma solicitação preenchida no site; vira card na aba "Consultorias" do painel.';
comment on column consultas_leads.resultado_analise is 'JSON estruturado do diagnóstico (resumo, categorias, pontosFortes, pontosDeAtencao, oportunidades, proximasAcoes, ctaTexto). Ver diagnosticoEngine.js para o formato completo.';
comment on column consultas_leads.origem is 'Rastreio de onde veio a solicitação (bio do Instagram, link direto, etc.) — nunca um segredo, só analytics interno.';
comment on column consultas_leads.contato_realizado is 'Marcado manualmente pelo painel quando alguém da Felipe Branding efetivamente falou com o lead — nunca escrito pelo visitante.';

-- ---------- Autenticados (painel administrativo): acesso total ----------
-- Mesmo padrão de admin_prospeccao_leads: qualquer conta autenticada no
-- projeto (login real via Supabase Auth) pode ler e escrever. Sem
-- multiusuário/permissões diferenciadas aqui, igual ao resto do painel.
create policy "authenticated_select_consultas_leads" on consultas_leads
  for select using (auth.role() = 'authenticated');
create policy "authenticated_update_consultas_leads" on consultas_leads
  for update using (auth.role() = 'authenticated');
create policy "authenticated_delete_consultas_leads" on consultas_leads
  for delete using (auth.role() = 'authenticated');

-- ---------- Visitante anônimo: só pode CRIAR a própria consultoria ----------
-- Sem SELECT/UPDATE/DELETE nenhum pra "anon" aqui embaixo — o visitante nunca
-- lê ou altera nenhuma linha existente (nem a própria, por este caminho). O
-- WITH CHECK garante que, mesmo que alguém chame a REST API do Supabase
-- diretamente (sem passar pela Netlify Function consultas-criar.js), os
-- campos administrativos ficam travados no valor inicial esperado.
create policy "anon_insert_consultas_leads" on consultas_leads
  for insert to anon
  with check (
    status = 'novo'
    and contato_realizado = false
    and ultimo_contato_em is null
    and observacoes_internas is null
    and atualizado_por is null
    and tentativa_agendamento = false
    and tentativa_agendamento_em is null
    and cta_clicado is null
    and cta_clicado_em is null
  );

-- ---------- Visitante anônimo: eventos de conversão (ETAPA 4) ----------
-- A tela de resultado (ainda no navegador do próprio visitante, sem login)
-- precisa registrar "cliquei no WhatsApp" / "cliquei em agendar" / "cliquei
-- no Instagram" no MESMO lead que acabou de criar. Isto NÃO usa a service
-- role key (nunca exposta a request de frontend, ver
-- netlify/functions/_lib/config/supabaseServiceRole.js) — usa a mesma anon
-- key de sempre, com dois níveis de proteção combinados:
--
--   1) GRANT de coluna: o Postgres recusa a escrita de qualquer coluna que
--      não esteja nesta lista, não importa o que o WITH CHECK abaixo diga.
--   2) RLS WITH CHECK: mesmo dentro dessas colunas, só aceita os valores
--      esperados (cta_clicado só pode ser um dos 3 valores; tentativa_agen-
--      damento só pode virar true, nunca ser desfeita por essa via).
--
-- Risco aceito conscientemente: como o "USING" precisa enxergar a linha pra
-- poder atualizá-la e "anon" não tem política de SELECT, usamos
-- "using (true)" — ou seja, tecnicamente dá pra chamar isto com o id de
-- OUTRO lead, se alguém souber (ou adivinhar) o UUID dele. O impacto de um
-- abuso aqui é marcar erroneamente que aquele lead clicou num CTA — nunca
-- expõe dado nenhum (não há select) e nunca altera status, observações,
-- diagnóstico ou qualquer outro campo administrativo. Mitigado também pelo
-- espaço de UUID v4 ser praticamente impossível de adivinhar.
grant update (cta_clicado, cta_clicado_em, tentativa_agendamento, tentativa_agendamento_em, updated_at)
  on consultas_leads to anon;

create policy "anon_update_evento_consultas_leads" on consultas_leads
  for update to anon
  using (true)
  with check (
    cta_clicado is null or cta_clicado in ('whatsapp','agendamento','instagram')
  );

-- ============================================================
-- TABELA DE ATIVIDADES: consultas_atividades
-- ============================================================
-- Mesmo padrão de admin_prospeccao_atividades: histórico cronológico por
-- lead. Alimentada de duas formas: automaticamente (analise_concluida e os
-- 3 tipos de CTA, gravados pelas próprias Functions públicas) e manualmente
-- (observacao/contato_realizado/mudanca_status, gravados pelo painel).

create table if not exists consultas_atividades (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references consultas_leads(id) on delete cascade,
  tipo text not null check (tipo in (
    'analise_concluida','cta_whatsapp','cta_agendamento','cta_instagram',
    'contato_realizado','mudanca_status','observacao'
  )),
  descricao text,
  data timestamptz not null default now(),
  criado_por text,
  created_at timestamptz not null default now()
);

alter table consultas_atividades enable row level security;

create index if not exists consultas_atividades_lead_id_idx on consultas_atividades (lead_id, data desc);

comment on table consultas_atividades is 'Linha do tempo de eventos por lead da Consultoria de Instagram — mistura eventos automáticos (análise concluída, cliques de CTA) com anotações manuais do painel.';

-- Autenticados (painel): leitura + escrita manual (observação, contato
-- realizado, mudança de status registrada como nota).
create policy "authenticated_select_consultas_atividades" on consultas_atividades
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_consultas_atividades" on consultas_atividades
  for insert with check (auth.role() = 'authenticated');

-- Visitante anônimo: só INSERT, só os 4 tipos de evento que ele mesmo pode
-- gerar (nunca "observacao"/"contato_realizado"/"mudanca_status", exclusivos
-- do painel). Sem SELECT — o visitante nunca lê o histórico de ninguém.
create policy "anon_insert_consultas_atividades" on consultas_atividades
  for insert to anon
  with check (tipo in ('analise_concluida','cta_whatsapp','cta_agendamento','cta_instagram'));
