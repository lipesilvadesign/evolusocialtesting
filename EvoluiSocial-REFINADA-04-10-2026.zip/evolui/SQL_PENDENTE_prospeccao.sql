-- Tabela do módulo "Prospecção" (Central administrativa · Felipe Branding)
-- Rode isto no SQL Editor do projeto Supabase (aligftypgtzlymmditeo) antes de publicar.
-- Sem isso, a tela mostra erro tratado (não quebra o resto do painel), mas não funciona de verdade.

create table if not exists admin_prospeccao_leads (
  id uuid primary key default gen_random_uuid(),
  empresa text not null,
  setor text,
  telefone text,
  email text,
  endereco text,
  avaliacao_google text,
  motivo text,
  canal_sugerido text,
  status text not null default 'novo_lead'
    check (status in ('novo_lead','contatado','respondeu','reuniao_marcada','proposta_enviada','cliente','nao_convertido')),
  observacoes text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

alter table admin_prospeccao_leads enable row level security;

-- Mesmo padrão de acesso do restante do painel (admin_tarefas etc.): qualquer
-- usuário autenticado no projeto (login real via Supabase Auth, mesma conta do
-- admin.html) pode ler e escrever. Não há multiusuário/permissões diferenciadas
-- aqui — é a mesma política usada nas outras tabelas do painel.
create policy "authenticated_select_prospeccao" on admin_prospeccao_leads
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao" on admin_prospeccao_leads
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_prospeccao" on admin_prospeccao_leads
  for update using (auth.role() = 'authenticated');
create policy "authenticated_delete_prospeccao" on admin_prospeccao_leads
  for delete using (auth.role() = 'authenticated');

-- Carga inicial: as 28 empresas de Petrolina levantadas na pesquisa
-- (médio/grande porte, presença online fraca, perfil B2B da Felipe Branding).
-- Rode uma vez só — rodar de novo duplica as linhas (não há UNIQUE em "empresa").
insert into admin_prospeccao_leads (empresa, setor, telefone, endereco, avaliacao_google, motivo, canal_sugerido, status) values
  ('Medeiros Construtora', 'Construção Civil', '+55 87 99972-7753', 'Av. 1, 50 - Petrolina, PE', '5.0 (71 avaliações)', 'Construtora local de porte médio/grande, sem site próprio encontrado — presença só no Google/Instagram', 'WhatsApp', 'novo_lead'),
  ('Construtora NALDI', 'Construção Civil', '+55 87 4101-8161', 'R. Antônio Santana Filho, 921 - Centro, Petrolina', '4.9 (37 avaliações)', 'Construtora tradicional, avaliações fortes, identidade visual provavelmente amadora', 'WhatsApp', 'novo_lead'),
  ('SANFORTE ENGENHARIA Ltda', 'Engenharia/Construção', '+55 87 98103-9509', 'R. Crispim de Amorim Coelho, 392 - Centro, Petrolina', '5.0 (149 avaliações)', 'Alto volume de avaliações = empresa grande e ativa; posiciona-se como "alto padrão", ótimo fit para rebranding premium', 'WhatsApp', 'novo_lead'),
  ('Construtora Venâncio', 'Construção Civil', '+55 87 3866-8900', 'Dom Avelar, Petrolina', '4.6 (91 avaliações)', 'Uma das maiores construtoras da região (capital social R$20mi segundo cadastro empresarial)', 'WhatsApp/Ligação', 'novo_lead'),
  ('ALTIS Soluções em Engenharia', 'Engenharia', '+55 87 98165-0726', 'R. Raimundo Lacerda, 160 - São José, Petrolina', '5.0 (24 avaliações)', 'Escritório técnico B2B (presta serviço a outras empresas/incorporadoras), identidade provavelmente genérica', 'WhatsApp', 'novo_lead'),
  ('Gypsum', 'Indústria (materiais de construção)', '+55 800 282 9255', 'Av. Marginal, Distrito Industrial, Petrolina', '3.8 (27 avaliações)', 'Indústria local, avaliações mostram fraqueza operacional/imagem — oportunidade de reposicionamento', 'E-mail/WhatsApp', 'novo_lead'),
  ('Niagro Nichirei do Brasil Agrícola Ltda', 'Indústria/Agronegócio (exportação)', '+55 87 2101-1433', 'Av. Luiz de Souza, 721 - Distrito Industrial, Petrolina', '4.8 (69 avaliações)', '30 anos de mercado, exporta acerola — porte grande, marca institucional pode estar datada', 'E-mail', 'novo_lead'),
  ('Agroplast', 'Indústria (plásticos agrícolas)', '+55 87 98831-2877', 'Av. José de Santana, 17a - Distrito Industrial, Petrolina', '5.0 (11 avaliações)', 'Fabricante B2B para produtores rurais, marca provavelmente sem identidade visual forte', 'WhatsApp', 'novo_lead'),
  ('São Francisco Têxtil', 'Indústria Têxtil', '+55 87 3861-9454', 'Av. Ricardo Soares Coelho, 100 - Distrito Industrial, Petrolina', '4.6 (84 avaliações)', 'Indústria têxtil de porte considerável na região', 'E-mail/WhatsApp', 'novo_lead'),
  ('Renascer Indústria Têxtil', 'Indústria Têxtil', null, 'Distrito Industrial, Petrolina', '5.0 (2 avaliações)', 'Indústria têxtil local, pouquíssima presença online — forte candidata', 'Visita/WhatsApp', 'novo_lead'),
  ('Eco Embalagem Ind. e Com. de Plásticos', 'Indústria (embalagens)', null, 'Av. José de Santana - Distrito Industrial, Petrolina', '4.0 (4 avaliações)', 'Indústria B2B (fornece embalagens para outras empresas), sem presença digital relevante', 'Visita/E-mail', 'novo_lead'),
  ('Distribuidora Atacado das Bebidas', 'Atacado/Distribuição', '+55 87 98833-9348', 'R. João Amaro Ferreira, 525 - COHAB Massangano, Petrolina', '5.0 (2 avaliações)', 'Distribuidora de bebidas, presença digital mínima', 'WhatsApp', 'novo_lead'),
  ('Compare Distribuidora Petrolina', 'Atacado/Distribuição', '+55 87 99126-4533', 'Av. Dr. Ulisses Guimarães, 511 - Portal da Cidade, Petrolina', '4.8 (4 avaliações)', 'Distribuidora, marca aparentemente sem padronização visual', 'WhatsApp', 'novo_lead'),
  ('RP Transportes - Unidade Petrolina/PE', 'Transporte/Logística', '+55 800 042 0963', 'BR-407, 600 - Cosme e Damião, Petrolina', '4.0 (95 avaliações)', 'Transportadora regional de porte médio, marca funcional sem trabalho de identidade', 'E-mail', 'novo_lead'),
  ('PNZ Mudanças e Transportes', 'Transporte/Mudanças', '+55 87 98818-4180', 'Av. Jose Jared De Carvalho, 37 - Jatobá, Petrolina', '4.7 (41 avaliações)', 'Boa reputação, atende fora do estado — pode se beneficiar de marca mais profissional para expandir', 'WhatsApp', 'novo_lead'),
  ('Joafra Transportes', 'Transporte/Logística', '+55 87 3862-3689', 'Av. das Nações, 370 - Gercino Coelho, Petrolina', '3.1 (19 avaliações)', 'Avaliação baixa pode indicar problema de percepção de marca/comunicação — oportunidade de reposicionamento', 'Ligação/WhatsApp', 'novo_lead'),
  ('Cclog Transportadora', 'Transporte/Logística', '+55 87 3867-2240', 'R. Galileia, 20 - Vila Eulália, Petrolina', '3.8 (62 avaliações)', 'Transportadora B2B com problemas de percepção/comunicação nas avaliações', 'Ligação/WhatsApp', 'novo_lead'),
  ('COANA - New Alliance Agricultural Cooperative', 'Agronegócio/Cooperativa', '+55 87 99154-2262', 'BR-407, Km 119 - Lote 551, Petrolina', '4.8 (32 avaliações)', 'Cooperativa exportadora de uvas, porte grande, provavelmente sem marca institucional forte', 'E-mail', 'novo_lead'),
  ('Valexfruit - Cooperativa Agrícola Vale do São Francisco', 'Agronegócio/Cooperativa', '+55 87 3861-9489', 'R. J - Distrito Industrial, Petrolina', '5.0 (8 avaliações)', 'Cooperativa em crescimento, mencionada por influenciadores — bom momento para investir em marca', 'E-mail/WhatsApp', 'novo_lead'),
  ('Coopexvale', 'Agronegócio/Cooperativa', '+55 87 3862-5666', 'Rua Projetada - Boa Esperança, Petrolina', '4.3 (95 avaliações)', 'Cooperativa agrícola relevante na região, exporta uva sem sementes', 'E-mail', 'novo_lead'),
  ('COOPA', 'Agronegócio/Cooperativa', '+55 87 3864-3948', 'R. da Ingazeira, 136 - Areia Branca, Petrolina', '5.0 (3 avaliações)', 'Cooperativa, presença digital praticamente inexistente', 'Visita/Ligação', 'novo_lead'),
  ('F1 Veículos', 'Concessionária/Revenda de Veículos', '+55 87 3864-0907', 'Av. Cel. Antônio Hónorato Viana, 139 - Petrolina', '4.8 (31 avaliações)', 'Revenda bem avaliada, identidade visual provavelmente genérica (nome + logo simples)', 'WhatsApp', 'novo_lead'),
  ('Andrade Veículos', 'Concessionária/Revenda de Veículos', '+55 87 3024-2780', 'Rua praça do carro, N.10 - Gercino Coelho, Petrolina', '4.4 (38 avaliações)', 'Revenda de porte médio, avaliações mistas sobre atendimento — marca pode ajudar a reposicionar', 'WhatsApp', 'novo_lead'),
  ('PRIME MOTORS', 'Concessionária/Revenda de Veículos (alto padrão)', '+55 87 98171-4000', 'Av. Nilo Coelho, 2002 - Gercino Coelho, Petrolina', '4.6 (37 avaliações)', 'Já se posiciona como "alto padrão" — ótimo fit para branding premium alinhado ao discurso deles', 'WhatsApp', 'novo_lead'),
  ('Auto Parvi - Seminovos Petrolina', 'Concessionária (rede regional)', '+55 800 810 7777', 'Av. Monsenhor Ângelo Sampaio, 1100 - Vila Eduardo, Petrolina', '4.8 (20 avaliações)', 'Rede regional com presença em Recife também — potencial cliente maior', 'E-mail/WhatsApp', 'novo_lead'),
  ('Centro Educacional FESN - Petrolina', 'Educação (curso técnico/profissionalizante)', '+55 87 98101-1313', 'R. Cel. Amorim, 76 - Centro, Petrolina', '4.0 (61 avaliações)', 'Escola local (não é franquia nacional), reclamações de infraestrutura indicam marca institucional pouco cuidada', 'WhatsApp/E-mail', 'novo_lead'),
  ('UNIFAEL Petrolina', 'Educação (faculdade local)', '+55 87 3035-2544', 'Av. Monsenhor Ângelo Sampaio, 377 - Maria Auxiliadora, Petrolina', '4.3 (7 avaliações)', 'Faculdade local pequena/média, pouca presença digital — fit para site+marca institucional', 'E-mail/WhatsApp', 'novo_lead'),
  ('Petrolina Palace Hotel', 'Hotelaria (independente)', '+55 87 3866-3300', 'Av. Cardoso de Sá, 845 - Centro, Petrolina', '4.2 (1639 avaliações)', 'Hotel independente (não é rede como Ibis/Nobile), avaliações mencionam necessidade de modernização — inclui a marca', 'E-mail', 'novo_lead'),
  ('Hotel Grande Rio', 'Hotelaria (independente)', '+55 87 3866-8050', 'Av. das Nações, 2 - Centro, Petrolina', '4.1 (2512 avaliações)', 'Hotel local de grande porte, marca visual pode estar desatualizada', 'E-mail', 'novo_lead');

-- ============================================================
-- Migração adicional: automação semanal de busca (OpenStreetMap)
-- Rode isto depois do bloco acima (ele é seguro rodar mais de uma vez —
-- usa IF NOT EXISTS, não duplica nada mesmo se rodar de novo).
-- ============================================================

alter table admin_prospeccao_leads
  add column if not exists cidade text,
  add column if not exists origem_id text,
  add column if not exists fonte text not null default 'manual';

-- Evita duplicar o mesmo local do OpenStreetMap em execuções futuras.
-- (permite múltiplas linhas com origem_id nulo, que é o caso dos leads
-- manuais/da planilha original — a unicidade só se aplica a quem tem origem_id.)
create unique index if not exists admin_prospeccao_leads_origem_id_key
  on admin_prospeccao_leads (origem_id)
  where origem_id is not null;

-- ============================================================
-- Migração adicional: busca manual (Google Places) + envio de e-mail
-- Seguro rodar mais de uma vez (tudo IF NOT EXISTS).
-- ============================================================

alter table admin_prospeccao_leads
  add column if not exists site text,
  add column if not exists anos_mercado text,
  add column if not exists funcao_contato text,
  add column if not exists email_enviado_em timestamptz,
  add column if not exists email_status text;

comment on column admin_prospeccao_leads.site is 'Site da empresa, quando encontrado (tag OSM "website"/"contact:website", nem sempre presente — depende do que voluntários do OpenStreetMap preencheram).';
comment on column admin_prospeccao_leads.anos_mercado is 'Texto livre (ex: "12 anos", "desde 2008") — nenhuma fonte automática preenche isso, é sempre completado manualmente.';
comment on column admin_prospeccao_leads.funcao_contato is 'Cargo/função da pessoa de contato na empresa (ex: "Sócio-diretor", "Gerente de Marketing") — preenchimento manual.';
comment on column admin_prospeccao_leads.email_enviado_em is 'Timestamp do envio automático mais recente via aba Prospecção → Enviar e-mail. Null = nunca enviado por lá (pode já ter sido contatado manualmente por fora).';
comment on column admin_prospeccao_leads.email_status is 'Resultado do envio mais recente: "enviado" ou "erro: <mensagem>". Usado só pra feedback na interface, não trava reenvio.';

alter table admin_prospeccao_leads add column if not exists cnpj text;
comment on column admin_prospeccao_leads.cnpj is 'Preenchimento manual (ex: consultado no CNPJ.ws) — usado no fluxo de exportar/importar CSV pra enriquecer anos de mercado e porte sem integração automática com API externa.';

alter table admin_prospeccao_leads
  add column if not exists prioridade text not null default 'media'
    check (prioridade in ('alta','media','baixa'));

comment on column admin_prospeccao_leads.prioridade is 'Prioridade de contato — não é uma "chance de fechar contrato" calculada (não há dado histórico de conversão pra sustentar isso). Leads novos da busca OSM entram com "alta" quando nenhum site foi encontrado (presença online fraca = critério real da Felipe Branding) e "media" quando um site foi encontrado. Sempre editável manualmente.';

-- ============================================================
-- Migração adicional: progresso da busca manual (sem depender de notificações)
-- ============================================================

create table if not exists admin_prospeccao_buscas (
  id uuid primary key,
  cidades text[] not null,
  ramo text not null,
  status text not null default 'em_andamento' check (status in ('em_andamento','concluido','erro')),
  progresso jsonb not null default '[]'::jsonb,
  total_encontrado int,
  mensagem_erro text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

alter table admin_prospeccao_buscas enable row level security;

create policy "authenticated_select_prospeccao_buscas" on admin_prospeccao_buscas
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_buscas" on admin_prospeccao_buscas
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_prospeccao_buscas" on admin_prospeccao_buscas
  for update using (auth.role() = 'authenticated');

comment on table admin_prospeccao_buscas is 'Uma linha por clique no botão "Atualizar" — o painel consulta essa linha (por id, gerado no navegador) pra mostrar progresso em tempo real sem depender de admin_notificacoes.';

-- ============================================================
-- Migração adicional: progresso do envio de e-mail (mesmo padrão da busca)
-- ============================================================

create table if not exists admin_prospeccao_envios (
  id uuid primary key,
  total_selecionado int not null default 0,
  status text not null default 'em_andamento' check (status in ('em_andamento','concluido','erro')),
  progresso jsonb not null default '[]'::jsonb,
  resumo jsonb,
  mensagem_erro text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

alter table admin_prospeccao_envios enable row level security;

create policy "authenticated_select_prospeccao_envios" on admin_prospeccao_envios
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_envios" on admin_prospeccao_envios
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_prospeccao_envios" on admin_prospeccao_envios
  for update using (auth.role() = 'authenticated');

comment on table admin_prospeccao_envios is 'Uma linha por clique em "Enviar e-mail para selecionados" — o painel consulta essa linha (por id, gerado no navegador) pra mostrar progresso em tempo real, lead por lead, sem depender de admin_notificacoes.';

-- ============================================================
-- FASE 1 — CRM real: contatos, atividades, score, opt-out,
-- problema/evidência, e separação de status (lead/estágio/contato).
-- Seguro rodar mais de uma vez (tudo IF NOT EXISTS).
-- ============================================================

-- O "status" existente (novo_lead/contatado/respondeu/reuniao_marcada/...)
-- continua sendo o ESTÁGIO DA OPORTUNIDADE. As duas colunas novas abaixo
-- são dimensões separadas, como a análise recomendou: qualidade do lead
-- (status_lead) e prontidão de contato (status_contato) não são a mesma
-- coisa que "em que pé está a negociação".
alter table admin_prospeccao_leads
  add column if not exists status_lead text not null default 'novo'
    check (status_lead in ('novo','pesquisando','qualificado','nao_qualificado','duplicado','bloqueado')),
  add column if not exists status_contato text not null default 'sem_contato'
    check (status_contato in ('sem_contato','email_encontrado','email_validado','whatsapp_disponivel','decisor_identificado','optout_solicitado','nao_contatar')),
  add column if not exists problema_identificado text,
  add column if not exists evidencia_problema text,
  add column if not exists oferta_recomendada text,
  add column if not exists score int not null default 0,
  add column if not exists score_motivos jsonb not null default '[]'::jsonb,
  -- Sinais de score que não dá pra detectar automaticamente (não existe API
  -- que avalie "Instagram desorganizado" ou "porte da empresa") — o humano
  -- marca, o motor de score (calcularScore) só soma os pontos.
  add column if not exists sinal_site_desatualizado boolean not null default false,
  add column if not exists sinal_instagram_desorganizado boolean not null default false,
  add column if not exists sinal_gbp_fraco boolean not null default false,
  add column if not exists sinal_porte_medio_grande boolean not null default false,
  add column if not exists sinal_segmento_alto_potencial boolean not null default false,
  add column if not exists sinal_email_validado boolean not null default false,
  add column if not exists ultima_atividade_em timestamptz,
  add column if not exists proxima_atividade_em timestamptz;

comment on column admin_prospeccao_leads.status is 'ESTÁGIO DA OPORTUNIDADE (não confundir com status_lead/status_contato) — em que pé está a negociação: novo_lead → contatado → respondeu → reuniao_marcada → proposta_enviada → cliente/nao_convertido.';
comment on column admin_prospeccao_leads.status_lead is 'Qualidade/triagem do lead em si — independente de já ter sido contatado ou não.';
comment on column admin_prospeccao_leads.status_contato is 'Prontidão de contato — o que já se sabe sobre como falar com essa empresa. "optout_solicitado"/"nao_contatar" bloqueiam novo envio de e-mail (ver prospeccao-enviar-email-background.js).';
comment on column admin_prospeccao_leads.score is 'Calculado por calcularScore() (_lib/scoreEngine.js) a partir dos sinais marcados + do estágio da oportunidade. Recalculado a cada vez que o lead é salvo no editor — nunca editado direto.';
comment on column admin_prospeccao_leads.score_motivos is 'Array [{label, pontos}] explicando de onde veio o score — pra nunca virar um número opaco.';

create index if not exists admin_prospeccao_leads_score_idx on admin_prospeccao_leads (score desc);

-- ---------- Contatos (uma empresa pode ter vários) ----------

create table if not exists admin_prospeccao_contatos (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references admin_prospeccao_leads(id) on delete cascade,
  nome text not null,
  cargo text,
  email text,
  whatsapp text,
  linkedin text,
  principal boolean not null default false,
  criado_por text,
  created_at timestamptz not null default now()
);

alter table admin_prospeccao_contatos enable row level security;
create policy "authenticated_select_prospeccao_contatos" on admin_prospeccao_contatos
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_contatos" on admin_prospeccao_contatos
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_prospeccao_contatos" on admin_prospeccao_contatos
  for update using (auth.role() = 'authenticated');
create policy "authenticated_delete_prospeccao_contatos" on admin_prospeccao_contatos
  for delete using (auth.role() = 'authenticated');

comment on table admin_prospeccao_contatos is 'Pessoas de contato de uma empresa prospectada — decisor identificado conta ponto no score (ver scoreEngine.js).';

-- ---------- Atividades (histórico + próxima ação) ----------

create table if not exists admin_prospeccao_atividades (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references admin_prospeccao_leads(id) on delete cascade,
  tipo text not null check (tipo in (
    'email_enviado','whatsapp_enviado','ligacao','follow_up','resposta_recebida',
    'reuniao_marcada','reuniao_realizada','proposta_enviada','negociacao','nota'
  )),
  descricao text,
  data timestamptz not null default now(),
  proxima_em timestamptz,
  criado_por text,
  created_at timestamptz not null default now()
);

alter table admin_prospeccao_atividades enable row level security;
create policy "authenticated_select_prospeccao_atividades" on admin_prospeccao_atividades
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_atividades" on admin_prospeccao_atividades
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_delete_prospeccao_atividades" on admin_prospeccao_atividades
  for delete using (auth.role() = 'authenticated');

comment on table admin_prospeccao_atividades is 'Histórico de atividades por lead (e-mail enviado, follow-up, resposta...). Cada inserção atualiza admin_prospeccao_leads.ultima_atividade_em/proxima_atividade_em (feito em atividadesService.js, não em trigger de banco).';

-- ---------- Opt-out (bloqueio permanente, sobrevive à exclusão do lead) ----------

create table if not exists admin_prospeccao_optouts (
  id uuid primary key default gen_random_uuid(),
  email text,
  telefone text,
  origem_id text,
  motivo text,
  criado_por text,
  created_at timestamptz not null default now(),
  constraint admin_prospeccao_optouts_tem_algum_identificador
    check (email is not null or telefone is not null or origem_id is not null)
);

alter table admin_prospeccao_optouts enable row level security;
create policy "authenticated_select_prospeccao_optouts" on admin_prospeccao_optouts
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_optouts" on admin_prospeccao_optouts
  for insert with check (auth.role() = 'authenticated');

comment on table admin_prospeccao_optouts is 'Lista de bloqueio PERMANENTE — separada de admin_prospeccao_leads de propósito: se o lead for excluído e a busca automática/manual achar a mesma empresa de novo (mesmo origem_id), ela não pode voltar a ser contatada. Checado em prospeccao-buscar-empresas-background.js (não insere) e prospeccao-enviar-email-background.js (não envia).';
