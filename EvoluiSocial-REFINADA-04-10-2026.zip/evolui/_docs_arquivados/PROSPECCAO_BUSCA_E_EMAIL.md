# Busca manual (OpenStreetMap) + envio de e-mail — aba Prospecção

Complementa `PROSPECCAO_AUTOMACAO.md` (busca automática semanal, gratuita, via
OpenStreetMap, raio fixo de 90km ao redor de Petrolina). Isto aqui é o botão
**"Atualizar"** (sob demanda, cidades/ramo escolhidos na hora) + o botão
**"Enviar e-mail para selecionados"**.

> Histórico desta funcionalidade: começou com Google Places API (trocada
> por dificuldade de configuração no Google Cloud), depois OpenStreetMap
> puro (trocada depois de 406/429 constantes em produção, mesmo com 6
> espelhos e retry — servidores comunitários genuinamente sobrecarregados).
> Versão atual: **Geoapify** — infraestrutura de empresa por trás (plano
> gratuito, 3.000 créditos/dia, sem cartão de crédito), mais estável do que
> depender de servidores mantidos por voluntários. A geocodificação de
> cidade (Nominatim/Photon) nunca foi o problema e continua igual.
>
> A busca automática semanal continua 100% no OpenStreetMap/Overpass —
> gratuita, já com fallback entre 6 espelhos + retry em 429 (ver
> `_lib/integrations/openStreetMap.js`) — sem mudança nenhuma nela.
>
> Segunda mudança (independente da fonte de dados): o resultado da busca
> não depende mais de `admin_notificacoes` (que não estava aparecendo pro
> usuário). Tem sua própria tela de progresso (`admin_prospeccao_buscas`),
> cidade por cidade, em tempo real, e atualiza a lista de leads sozinha ao
> terminar.
>
> **Importante entender:** o Geoapify usa o OpenStreetMap como fonte de
> dados por baixo — não é uma base maior/diferente, só uma infraestrutura
> mais confiável entregando o mesmo dado. Se uma região tem pouco negócio
> mapeado no OSM, o Geoapify tem a mesma limitação que o Overpass tinha.
> Um bug real encontrado nessa migração: a categoria `building` (contornos
> de prédio, quase todos sem nome no OSM) lotava o limite de resultados
> antes dos negócios de verdade aparecerem — removida, e o limite por
> cidade subiu pra 500 (máximo da API) pra dar espaço de sobra ao filtro
> por nome.
>
> **Limitação estrutural encontrada depois (não era bug de código):**
> testado com nomes reais de Petrolina (ex: "Medeiros Construtora",
> "Construtora NALDI") — o filtro por nome funciona certo, mas o Geoapify
> **exige** que o lugar tenha uma categoria de negócio marcada no OSM pra
> aparecer. Muita empresa brasileira real existe no OSM só com nome e
> endereço, sem categoria — o Overpass antigo achava essas (busca por nome
> em qualquer ponto, categorizado ou não); o Geoapify sozinho, não.
>
> **Solução final: as duas fontes rodam juntas**, por cidade — Geoapify
> primeiro (rápido, confiável quando tem categoria), Overpass depois (pega
> o que não tem categoria, usando os 6 espelhos + retry já existentes). A
> mesma empresa encontrada pelas duas não duplica (comparação por nome,
> além do id de origem). Cada lead guarda de qual fonte especificamente
> veio (`geoapify_manual` ou `osm_manual`) — a tag "Manual" na lista cobre
> as duas.
>
> **Segundo bug real, também confirmado com teste**: a busca no Overpass
> usava a palavra digitada **inteira** como termo — mas "construção"
> (digitada) não é substring de "Construtora" nem de "Construções" (sufixo
> diferente: -ção vs -tora/-ções). O filtro local do Geoapify já usava um
> "radical" pra contornar isso; o Overpass não usava. Unificado: as duas
> fontes agora usam a mesma função de radical (`_lib/templateUtil.js`),
> pra nunca mais uma fonte achar o que a outra, pela mesma palavra, não
> acharia.

## O que foi implementado

1. **Botão "Atualizar"** na aba Prospecção → popup pra escolher cidades +
   ramo/segmento → geocodifica cada cidade (Nominatim) e busca num raio de
   15km ao redor dela (Overpass, mesmo motor do job semanal) → insere só
   empresas novas (nunca duplica — usa o mesmo namespace de `origem_id`
   `osm:<tipo>/<id>` do job semanal, então nunca insere duas vezes o mesmo
   local só por ter vindo por um caminho diferente).
   Entram como `fonte = 'osm_manual'` (tag "Manual" na lista), pedindo
   revisão manual — o OSM não traz e-mail nem anos de mercado.
   O popup mostra progresso real (cidade por cidade) enquanto a busca roda,
   e a lista de leads atualiza sozinha ao concluir — sem precisar recarregar
   a página nem depender de notificação.
2. **Prioridade** por lead (Alta/Média/Baixa) — não é uma "chance de
   fechar contrato" calculada (não há dado histórico de conversão pra
   sustentar esse tipo de número). Leads novos da busca OSM entram com
   "Alta" quando nenhum site foi encontrado pra empresa (presença online
   fraca = o critério real que a Felipe Branding já usava pra priorizar) e
   "Média" quando um site foi encontrado. Sempre editável manualmente, tem
   filtro na toolbar, e a lista ordena Alta → Média → Baixa por padrão.
3. **Seleção múltipla** na lista (checkbox por linha) + botão **"Enviar
   e-mail para selecionados"** → popup com modelo de assunto/corpo
   (variáveis `{{empresa}}`, `{{setor}}`, `{{cidade}}`) → envia via SMTP da
   Umbler, um e-mail de cada vez, com pausa entre envios e limite diário
   (padrão: 25/dia — configurável).
4. Novos campos no lead: **Site**, **Anos de mercado**, **Função do
   contato** (todos de preenchimento manual).

## Como funciona o progresso da busca (sem depender de notificações)

1. O navegador gera um `jobId` (`crypto.randomUUID()`) antes de chamar a
   Background Function.
2. A function cria uma linha em `admin_prospeccao_buscas` com esse id e
   status `em_andamento`, e vai atualizando o campo `progresso` (um item
   por cidade) conforme processa cada uma.
3. O painel consulta essa linha por id a cada ~2 segundos
   (`prospeccao-busca-status.js`, Function síncrona normal — só lê,
   é rápida) e atualiza a tela ao vivo.
4. Quando termina, `status` vira `concluido` (ou `erro`), o painel mostra
   o resumo e recarrega a lista de leads sozinho.

Essa tabela é independente de `admin_notificacoes` de propósito — mesmo que
a tabela de notificações esteja com problema (ausente ou RLS bloqueando),
a busca manual continua mostrando progresso normalmente.

## Por que os dois botões usam Background Function

- **Buscar empresas**: geocodificar várias cidades (respeitando o limite de
  uso do Nominatim, ~1 requisição/segundo) mais consultar o Overpass pra
  cada uma facilmente passa dos ~10 segundos de limite de uma Netlify
  Function normal.
- **Enviar e-mail**: mandar vários e-mails em sequência com pausa entre eles
  tem o mesmo problema.

Por isso os dois (`prospeccao-buscar-empresas-background.js` e
`prospeccao-enviar-email-background.js`) rodam como Background Function
(mesmo padrão de `scheduled-sync-background.js`, confirmado disponível em
qualquer plano do Netlify, inclusive o Free): o navegador recebe uma
resposta 202 vazia na hora (é assim que Background Function funciona no
Netlify — não dá pra devolver dado nenhum nessa resposta), e o trabalho de
verdade continua rodando por até 15 minutos.

## Por que o limite diário de e-mail existe (não é capricho)

A Umbler proíbe, nos termos de uso, disparo em massa/marketing a partir de
um e-mail profissional — o risco real é o bloqueio da conta de e-mail ou do
domínio inteiro (site + todos os e-mails @felipebranding.com.br). O limite
diário baixo, o envio um-de-cada-vez com pausa, e o corpo em texto simples
(sem HTML de "campanha") existem justamente pra não parecer disparo em
massa pro servidor da Umbler. Ver `netlify/functions/_lib/integrations/umblerSmtp.js`.

## Setup necessário (uma vez só)

1. Rode a migração adicional em `SQL_PENDENTE_prospeccao.sql` (bloco final,
   "busca manual + envio de e-mail").
2. Configure no Netlify (Site settings → Environment variables):
   - `GEOAPIFY_API_KEY` — crie uma conta grátis em geoapify.com (sem cartão
     de crédito), crie um projeto, copie a chave da API.
   - `UMBLER_SMTP_USER` — `contato@felipebranding.com.br`.
   - `UMBLER_SMTP_PASS` — senha **do e-mail** (painel Umbler → domínio →
     Contas de E-mail → editar → Senha). Não é a senha de login do painel.
   - `EMAIL_PROSPECCAO_LIMITE_DIARIO` — opcional, padrão 25 se omitido.
3. Depois de configurar/mudar qualquer variável de ambiente, é preciso
   **fazer um novo deploy** — o Netlify só aplica variáveis novas em
   deploys novos, não retroativamente nas functions já publicadas.
4. Nenhum `npm install` necessário — o projeto continua com zero
   dependências externas. O envio de e-mail usa um cliente SMTP mínimo
   escrito só com `net`/`tls` nativos do Node (`_lib/integrations/rawSmtp.js`),
   no lugar de uma biblioteca como nodemailer — isso mantém o deploy no
   Netlify instantâneo (puramente estático), sem etapa de instalação.

## Limitações honestas

- OpenStreetMap não traz e-mail, anos de mercado nem nota/avaliações —
  sempre preenchimento manual. Cobertura depende de voluntários terem
  cadastrado a empresa (mais fraca que o Google em cidades pequenas).
- **Prioridade não é ciência** — é um proxy razoável (site encontrado ou
  não) pro critério que a Felipe Branding já usava. Trate como ponto de
  partida pra organizar o trabalho, não como uma previsão confiável de
  quem vai fechar contrato.
- O limite diário de e-mail conta envios feitos **pela aba Prospecção**
  (`email_enviado_em`), não e-mails mandados por fora (webmail, etc.).
- Reenviar pra quem já recebeu não é bloqueado automaticamente — é
  responsabilidade de quem usa a tela evitar reenviar sem necessidade.

## Como funciona o progresso do envio de e-mail (mesmo padrão da busca)

Igual à busca de empresas: o navegador gera um `jobId`, a Background
Function grava progresso lead por lead em `admin_prospeccao_envios`, e o
painel consulta por polling (`prospeccao-envio-status.js`) — não depende de
`admin_notificacoes`. O popup mostra cada empresa selecionada passando de
"aguardando" pra "✅ enviado" ou "⚠️ erro" em tempo real, e a lista de leads
atualiza sozinha (badges "E-mail enviado"/"Falha no envio") ao concluir.

## O que eu testei de verdade, e o que só é confirmado no seu teste real

62 testes automatizados no projeto (todos passando), incluindo simulações
de:
- Preenchimento do template de e-mail (variáveis, campos vazios).
- A conversa SMTP inteira (EHLO, STARTTLS, AUTH LOGIN, MAIL FROM, RCPT TO,
  DATA, QUIT) contra um **servidor SMTP falso real, rodando em localhost**
  durante o teste — isso prova que o protocolo está implementado certo,
  mas **não prova que o servidor da Umbler aceita a senha configurada** —
  isso só um envio real confirma.
- Byte-stuffing de linhas começando com "." e sanitização de CRLF em campos
  vindos de dados do lead (evita injeção de header/comando SMTP).
- Propagação de erro quando o SMTP rejeita (autenticação inválida, destinatário recusado, etc.).

Não tenho como testar a entrega real de um e-mail — minha rede aqui não
tem acesso a `smtp.umbler.com`, e mesmo se tivesse, enviar um e-mail de
teste de verdade é uma ação que só faz sentido você disparar. **A primeira
prova real de que o envio funciona é você mandar pra um lead de teste (ou
pro seu próprio e-mail) e ver chegar.**

