# Busca automática semanal de leads (Vale do São Francisco)

## O que foi implementado

Uma Netlify Scheduled Function (`netlify/functions/prospeccao-sync-osm.js`) que roda
automaticamente **uma vez por semana** (`@weekly`, configurado em `netlify.toml`) e:

1. Consulta a **Overpass API** (OpenStreetMap) — pública, gratuita, **sem chave de API** —
   buscando por nome (regex) dentro de um raio de ~90km ao redor de Petrolina, cobrindo
   o polo Vale do São Francisco (Petrolina, Juazeiro, Lagoa Grande, Santa Maria da Boa
   Vista, Casa Nova, Sobradinho, Curaçá, Orocó, Dormentes, Afrânio).
2. Filtra pelos mesmos setores já usados na prospecção manual (construtora, indústria,
   cooperativa/agrícola, atacado/distribuidora, transportadora, concessionária,
   faculdade/escola técnica, hotel/pousada).
3. Compara com o que já existe na tabela (`admin_prospeccao_leads.origem_id`) e insere
   **só o que é novo** — nunca duplica.
4. Cria uma notificação ("N novo(s) lead(s) de prospecção") visível na tela de
   Notificações do painel sempre que encontra algo novo.

## Limitação honesta

O OpenStreetMap **não tem nota nem quantidade de avaliações** como o Google Maps — então
o job não consegue avaliar sozinho se a empresa é de médio/grande porte, que era o
critério original. Por isso, todo lead automático:

- entra com `fonte = 'osm_auto'` (aparece com uma tag "Auto" na lista do painel);
- vem com uma observação padrão pedindo revisão manual antes do primeiro contato;
- pode vir com telefone/endereço incompletos (o OSM depende de voluntários preenchendo
  esses dados, cobertura é mais fraca que o Google em cidades menores).

Trate os leads com a tag "Auto" como uma **lista para peneirar**, não como leads prontos
para contato imediato.

## Setup necessário (uma vez só)

1. Rode o SQL adicional em `SQL_PENDENTE_prospeccao.sql` (bloco no final do arquivo,
   depois do `-- Migração adicional`) — adiciona as colunas `cidade`, `origem_id`, `fonte`.
2. Confirme que a variável de ambiente `SUPABASE_SERVICE_ROLE_KEY` está configurada no
   Netlify (Site settings → Environment variables). Sem ela, o job simplesmente não roda
   (loga um aviso, não quebra nada) — é a mesma variável já usada por
   `scheduled-sync-background.js`.
3. Depois do deploy, o cron `@weekly` do Netlify assume sozinho. Não precisa fazer nada
   toda semana.

## Como testar sem esperar uma semana

No painel do Netlify → aba **Functions** → clique em `prospeccao-sync-osm` → tem um botão
para disparar a função manualmente (fora do agendamento). Depois, confira a tela de
**Notificações** e a aba **Prospecção** no painel.

## Ajustar o alcance ou os setores no futuro

Tudo está em `netlify/functions/prospeccao-sync-osm.js`:

- `RADIUS_METERS` — raio de busca ao redor de Petrolina.
- `SECTOR_KEYWORDS` — lista de palavras-chave (regex) → setor. Adicionar uma nova
  palavra-chave aqui é o suficiente para passar a capturar mais empresas daquele tipo.
- `MAX_NEW_LEADS_PER_RUN` — limite de segurança por execução (hoje: 60).
