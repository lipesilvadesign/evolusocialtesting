-- ============================================================
-- PROMPT 2 — CRM de clientes, briefing e diagnóstico
-- ============================================================
-- DECISÃO DE ARQUITETURA (documentada, como o PROMPT 1 pediu):
-- NÃO criei uma tabela `admin_clientes` separada. Comparando o cadastro
-- pedido (empresa, responsável, segmento, telefone, whatsapp, e-mail,
-- instagram, site, cidade, funcionário responsável, status, observações,
-- último/próximo contato) com o schema de `admin_prospeccao_leads`, quase
-- tudo já existe lá (empresa, telefone→whatsapp, email, setor→segmento,
-- cidade, observacoes, ultima_atividade_em, proxima_atividade_em) e
-- "responsável" (pessoa de contato) já tem tabela própria
-- (admin_prospeccao_contatos, campo principal=true). Criar uma tabela nova
-- exigiria sincronizar duas fontes de verdade pro mesmo registro — exatamente
-- a redundância que o PROMPT 1 pediu pra evitar. "Cliente" passa a ser só
-- um estágio do MESMO lead (status_lead = 'cliente'), não uma entidade nova.
-- Só 3 colunas realmente não existiam — adicionadas abaixo.
-- ============================================================

-- 1) Colunas novas em admin_prospeccao_leads (`site` já existe — só faltavam
-- estas duas).
alter table admin_prospeccao_leads
  add column if not exists instagram text,
  add column if not exists responsavel_interno text;
-- responsavel_interno: nome do funcionário responsável, em texto livre por
-- enquanto — ainda não existe tabela de funcionários/RBAC real (ver
-- PROMPT_1_AUDITORIA_E_ARQUITETURA.md, risco R4). Quando existir, este
-- campo migra para uma FK sem quebrar nada (mesma coluna, tipo compatível).

-- 2) [DESATIVADO em 30/09/2026 — Lead Capture Engine, item 0.12]
-- Este trecho redefinia status_lead com valores ('lead','contato_feito',...)
-- que NÃO são os do banco de produção (lá: novo, pesquisando, qualificado,
-- nao_qualificado, duplicado, bloqueado — ver SQL_PENDENTE_prospeccao.sql).
-- Rodar este arquivo de novo trocaria 'novo' por 'lead' e quebraria a
-- constraint. O pipeline de Clientes usa a coluna `status`, não status_lead.
-- Mantido só como histórico (comentado):
-- -- (hoje só tinha 'novo' como valor de fato usado). Migra dados existentes
-- -- ANTES de apertar a constraint, pra nenhuma linha ficar inválida.
-- update admin_prospeccao_leads set status_lead = 'lead' where status_lead = 'novo' or status_lead is null;

-- do $$
-- begin
--   alter table admin_prospeccao_leads drop constraint if exists admin_prospeccao_leads_status_lead_check;
-- exception when undefined_object then null;
-- end $$;

-- alter table admin_prospeccao_leads add constraint admin_prospeccao_leads_status_lead_check
--   check (status_lead in ('lead','contato_feito','respondeu','diagnostico','proposta','cliente','perdido'));


-- IMPORTANTE — SE ESSE COMANDO ACIMA FALHAR (constraint violation), é sinal
-- de que existem valores de status_lead em uso que eu não previ. Rode antes:
--   select distinct status_lead from admin_prospeccao_leads;
-- e me diga quais valores aparecem, que eu ajusto a lista.

-- 3) Briefing — um por lead/cliente, modular via JSONB (histórico/produtos/
-- diferenciais/público/posicionamento/personalidade/preferências/objetivos
-- vivem dentro de `conteudo`, sem precisar de dezenas de colunas rígidas).
create table if not exists admin_briefings (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null unique references admin_prospeccao_leads(id) on delete cascade,
  conteudo jsonb not null default '{}'::jsonb,
  atualizado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_briefings enable row level security;
create policy "authenticated_select_briefings" on admin_briefings for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_briefings" on admin_briefings for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_briefings" on admin_briefings for update using (auth.role() = 'authenticated');
create policy "authenticated_delete_briefings" on admin_briefings for delete using (auth.role() = 'authenticated');

-- 4) Métricas — histórico (várias entradas por lead/cliente ao longo do
-- tempo), por isso é tabela relacional de verdade, não JSONB.
create table if not exists admin_metricas (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references admin_prospeccao_leads(id) on delete cascade,
  nome text not null,
  valor numeric,
  valor_texto text,
  unidade text,
  origem text,
  periodo text,
  data_coleta date,
  definicao text,
  criado_por text,
  created_at timestamptz not null default now()
);
alter table admin_metricas enable row level security;
create policy "authenticated_select_metricas" on admin_metricas for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_metricas" on admin_metricas for insert with check (auth.role() = 'authenticated');
create policy "authenticated_delete_metricas" on admin_metricas for delete using (auth.role() = 'authenticated');

-- 5) Diagnóstico — versionado (v1, v2, v3...). Cada seção (dado fornecido /
-- cálculo / análise da IA / análise do especialista / recomendação) guarda
-- texto + visibilidade ('interna' | 'visivel_cliente') dentro de `conteudo`.
create table if not exists admin_diagnosticos (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references admin_prospeccao_leads(id) on delete cascade,
  versao int not null default 1,
  status text not null default 'rascunho' check (status in ('rascunho', 'publicado')),
  conteudo jsonb not null default '{}'::jsonb,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz,
  unique (lead_id, versao)
);
alter table admin_diagnosticos enable row level security;
create policy "authenticated_select_diagnosticos" on admin_diagnosticos for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_diagnosticos" on admin_diagnosticos for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_diagnosticos" on admin_diagnosticos for update using (auth.role() = 'authenticated');
create policy "authenticated_delete_diagnosticos" on admin_diagnosticos for delete using (auth.role() = 'authenticated');
