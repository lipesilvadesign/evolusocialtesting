-- ============================================================
-- CORREÇÃO — "Falha ao consultar envios (404)" no resumo operacional
-- ============================================================
-- Um 404 do PostgREST em /rest/v1/admin_prospeccao_envios significa que
-- essa tabela não existe (ou não está visível) no banco de produção — não
-- é um bug de código, é dado de banco faltando. As tabelas "irmãs" que já
-- funcionam (admin_prospeccao_leads, admin_prospeccao_atividades) vieram
-- do MESMO arquivo (SQL_PENDENTE_prospeccao.sql), então o mais provável é
-- que ele tenha rodado parcialmente — parou antes de chegar nestas duas
-- tabelas (buscas/envios ficam mais pra baixo no arquivo).
--
-- Idempotente: seguro rodar mesmo se uma das duas já existir.
-- ============================================================

create table if not exists admin_prospeccao_buscas (
  id uuid primary key,
  cidades text[] not null,
  ramo text not null,
  status text not null default 'em_andamento' check (status in ('em_andamento','concluido','erro')),
  progresso jsonb not null default '[]'::jsonb,
  total_encontrado int,
  mensagem_erro text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_prospeccao_buscas enable row level security;
drop policy if exists "authenticated_select_prospeccao_buscas" on admin_prospeccao_buscas;
drop policy if exists "authenticated_insert_prospeccao_buscas" on admin_prospeccao_buscas;
drop policy if exists "authenticated_update_prospeccao_buscas" on admin_prospeccao_buscas;
create policy "authenticated_select_prospeccao_buscas" on admin_prospeccao_buscas
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_buscas" on admin_prospeccao_buscas
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_prospeccao_buscas" on admin_prospeccao_buscas
  for update using (auth.role() = 'authenticated');

create table if not exists admin_prospeccao_envios (
  id uuid primary key,
  total_selecionado int not null default 0,
  status text not null default 'em_andamento' check (status in ('em_andamento','concluido','erro')),
  progresso jsonb not null default '[]'::jsonb,
  resumo jsonb,
  mensagem_erro text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_prospeccao_envios enable row level security;
drop policy if exists "authenticated_select_prospeccao_envios" on admin_prospeccao_envios;
drop policy if exists "authenticated_insert_prospeccao_envios" on admin_prospeccao_envios;
drop policy if exists "authenticated_update_prospeccao_envios" on admin_prospeccao_envios;
create policy "authenticated_select_prospeccao_envios" on admin_prospeccao_envios
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_envios" on admin_prospeccao_envios
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_prospeccao_envios" on admin_prospeccao_envios
  for update using (auth.role() = 'authenticated');

-- Força o PostgREST a recarregar o schema imediatamente (sem isso, às vezes
-- leva até 1 min pra reconhecer tabela nova, e pode parecer que "não
-- funcionou" mesmo com a tabela já criada).
notify pgrst, 'reload schema';

-- Conferência — as duas devem vir 'true'
select
  to_regclass('public.admin_prospeccao_buscas') is not null as buscas_existe,
  to_regclass('public.admin_prospeccao_envios') is not null as envios_existe;
