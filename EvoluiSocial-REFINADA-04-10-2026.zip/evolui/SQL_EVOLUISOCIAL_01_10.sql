-- =====================================================================
-- EvoluiSocial — tabelas no Supabase da Felipe Branding (01/10/2026)
-- JÁ APLICADO no Supabase em 01/10/2026 (fica aqui como registro/versão).
-- Se precisar recriar em outro projeto, rode uma vez no SQL Editor.
-- Tudo é ADITIVO: não altera nem apaga nenhuma tabela da agência.
-- Prefixo evolui_ em tudo, para nunca misturar com admin_* / consultas_*.
-- =====================================================================

-- 0) Segurança antes de abrir cadastro público com Google -------------
-- Qualquer conta logada (inclusive usuário da EvoluiSocial) conseguia
-- inserir registro de ponto para si mesma. Agora só funcionário ativo.
-- (política RESTRITIVA: soma-se à existente, sem precisar apagar nada)
create policy ponto_somente_funcionario_ativo on public.admin_ponto_registros
  as restrictive for insert to public with check (public.admin_eh_funcionario_ativo());

-- 1) Perfil do usuário ------------------------------------------------
create table if not exists public.evolui_perfis (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text check (char_length(nome) <= 80),
  ramo text check (char_length(ramo) <= 60),
  ramo_detalhe text check (char_length(ramo_detalhe) <= 80),
  uf char(2),
  cidade text check (char_length(cidade) <= 80),
  cidade_ibge text check (cidade_ibge ~ '^[0-9]{7}$'),
  objetivo text check (objetivo in ('vender','crescer','engajar','lancar')),
  plano text not null default 'free' check (plano in ('free','pro','master')),
  onboarding_ok boolean not null default false,
  lat double precision,
  lon double precision,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
comment on table public.evolui_perfis is 'EvoluiSocial: perfil do negócio do usuário (1 linha por conta). Plano só muda pelo backend (pagamento).';

-- 2) Redes sociais do usuário (só o nome do perfil, nunca senha) -------
create table if not exists public.evolui_redes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  rede text not null check (rede in ('instagram','tiktok','youtube')),
  usuario text not null check (usuario ~ '^[A-Za-z0-9._-]{1,40}$'),
  criado_em timestamptz not null default now(),
  unique (user_id, rede)
);

-- 3) Histórico de pesquisas ------------------------------------------
create table if not exists public.evolui_buscas (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  termo text not null check (char_length(termo) between 2 and 80),
  nivel text not null default 'brasil' check (nivel in ('cidade','estado','brasil','mundo')),
  local text,
  estado_tendencia text,
  resultado jsonb,               -- resumo para reabrir sem nova consulta
  criado_em timestamptz not null default now()
);
create index if not exists evolui_buscas_user_data on public.evolui_buscas (user_id, criado_em desc);

-- 4) Ideias e tendências salvas --------------------------------------
create table if not exists public.evolui_salvos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tipo text not null check (tipo in ('tendencia','ideia')),
  titulo text not null check (char_length(titulo) <= 140),
  dados jsonb not null default '{}'::jsonb,
  criado_em timestamptz not null default now()
);
create index if not exists evolui_salvos_user on public.evolui_salvos (user_id, criado_em desc);

-- 5) Laboratório: testes A/B de bio e legenda ------------------------
create table if not exists public.evolui_lab_testes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tipo text not null check (tipo in ('bio','legenda')),
  titulo text check (char_length(titulo) <= 80),
  versao_a text not null check (char_length(versao_a) <= 2200),
  versao_b text not null check (char_length(versao_b) <= 2200),
  nota_a smallint check (nota_a between 0 and 100),
  nota_b smallint check (nota_b between 0 and 100),
  resultado_a jsonb not null default '{}'::jsonb,   -- {alcance, curtidas, comentarios, mensagens}
  resultado_b jsonb not null default '{}'::jsonb,
  vencedora char(1) check (vencedora in ('a','b')),
  status text not null default 'rascunho' check (status in ('rascunho','testando','concluido')),
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists evolui_lab_user on public.evolui_lab_testes (user_id, criado_em desc);

-- 6) RLS: cada pessoa só vê e mexe nos próprios dados -----------------
alter table public.evolui_perfis     enable row level security;
alter table public.evolui_redes      enable row level security;
alter table public.evolui_buscas     enable row level security;
alter table public.evolui_salvos     enable row level security;
alter table public.evolui_lab_testes enable row level security;

drop policy if exists evolui_perfis_sel on public.evolui_perfis;
drop policy if exists evolui_perfis_ins on public.evolui_perfis;
drop policy if exists evolui_perfis_upd on public.evolui_perfis;
create policy evolui_perfis_sel on public.evolui_perfis for select to authenticated using (id = (select auth.uid()));
create policy evolui_perfis_ins on public.evolui_perfis for insert to authenticated with check (id = (select auth.uid()) and plano = 'free');
create policy evolui_perfis_upd on public.evolui_perfis for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

do $$ declare t text; begin
  foreach t in array array['evolui_redes','evolui_salvos','evolui_lab_testes'] loop
    execute format('drop policy if exists %1$s_all on public.%1$s', t);
    execute format('create policy %1$s_all on public.%1$s for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()))', t);
  end loop;
end $$;

-- Histórico: a pessoa lê e apaga o próprio; quem GRAVA é a função de busca
-- (com o token da própria pessoa), para o limite do plano não ser burlado.
drop policy if exists evolui_buscas_sel on public.evolui_buscas;
drop policy if exists evolui_buscas_ins on public.evolui_buscas;
drop policy if exists evolui_buscas_del on public.evolui_buscas;
create policy evolui_buscas_sel on public.evolui_buscas for select to authenticated using (user_id = (select auth.uid()));
create policy evolui_buscas_ins on public.evolui_buscas for insert to authenticated with check (user_id = (select auth.uid()));
create policy evolui_buscas_del on public.evolui_buscas for delete to authenticated using (user_id = (select auth.uid()));

-- 7) Plano não pode ser trocado pelo navegador -----------------------
create or replace function public.evolui_protege_plano() returns trigger
language plpgsql set search_path = public as $$
begin
  if coalesce(auth.role(),'') <> 'service_role' then
    new.plano := old.plano;
  end if;
  new.atualizado_em := now();
  return new;
end $$;
drop trigger if exists evolui_protege_plano on public.evolui_perfis;
create trigger evolui_protege_plano before update on public.evolui_perfis
  for each row execute function public.evolui_protege_plano();

create or replace function public.evolui_lab_atualizado() returns trigger
language plpgsql set search_path = public as $$ begin new.atualizado_em := now(); return new; end $$;
drop trigger if exists evolui_lab_atualizado on public.evolui_lab_testes;
create trigger evolui_lab_atualizado before update on public.evolui_lab_testes
  for each row execute function public.evolui_lab_atualizado();

-- 8) Uso do mês (para o limite do plano), calculado no banco ------------
create or replace function public.evolui_buscas_no_mes() returns integer
language sql stable security invoker set search_path = public as $$
  select count(*)::int from evolui_buscas
  where user_id = (select auth.uid()) and criado_em >= date_trunc('month', now());
$$;

-- 9) A pessoa pode apagar o próprio perfil (botão "Apagar meus dados")
create policy evolui_perfis_del on public.evolui_perfis for delete to authenticated using (id = (select auth.uid()));
revoke all on function public.evolui_buscas_no_mes() from anon, public;
grant execute on function public.evolui_buscas_no_mes() to authenticated;
