-- ============================================================
-- PROMPT 5 — Inteligência, automações e acabamento final
-- ============================================================

-- 1) Rastreabilidade de IA (item 7 do prompt): quem gerou, além do que já
-- existia (quando = created_at, qual versão = prompt_version/model, quais
-- dados = metrics_used). Coluna nova, aditiva — a análise de marketing/GA4
-- já existente continua funcionando sem passar isso (fica null pra ela).
alter table admin_ai_usage
  add column if not exists gerado_por text;

-- 2) Alertas de follow-up (item 6) — reaproveita admin_notificacoes que já
-- existe; só precisamos saber se JÁ notificamos um follow-up vencido, pra
-- não repetir notificação a cada execução do job agendado.
alter table admin_prospeccao_leads
  add column if not exists follow_up_notificado_em timestamptz;

-- 3) Registro de objeção (item 6: "resposta; objeção" no acompanhamento de
-- prospecção) — campo novo na atividade, não uma tabela nova.
alter table admin_prospeccao_atividades
  add column if not exists objecao text;
