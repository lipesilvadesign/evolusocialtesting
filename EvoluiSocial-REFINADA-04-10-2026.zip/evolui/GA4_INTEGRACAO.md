# Integração Google Analytics 4 — Felipe Branding Admin

## 1. Variáveis de ambiente (Netlify)

Configurar em **Netlify → Site settings → Environment variables** (nunca commitar):

| Variável | O que é | Segredo? |
|---|---|---|
| `GA_PROPERTY_ID` | Só o número da propriedade GA4 (ex: `123456789`) — **não** é o Measurement ID (`G-XXXXXXX`) usado no gtag.js do site público | Não é segredo, mas fica só no ambiente server-side por padrão |
| `GA_SERVICE_ACCOUNT_JSON` | Conteúdo **integral** do arquivo JSON da service account (cole o JSON inteiro como valor da variável) | **Sim — segredo.** Nunca vai para o frontend, nunca é logado |

Nenhuma outra variável é necessária nesta etapa.

## 2. Configuração no Google Cloud

1. Acesse [console.cloud.google.com](https://console.cloud.google.com) e selecione (ou crie) um projeto.
2. **APIs e serviços → Biblioteca** → busque **"Google Analytics Data API"** → **Ativar**.
3. **APIs e serviços → Credenciais → Criar credenciais → Conta de serviço**.
   - Nome sugerido: `felipe-branding-analytics-reader`.
   - Não é preciso conceder papéis (roles) do IAM do Google Cloud — o acesso real é concedido dentro do próprio GA4 (passo 4).
4. Na conta de serviço criada → aba **Chaves** → **Adicionar chave → Criar nova chave → JSON**.
   - Isso baixa um arquivo `.json`. É o conteúdo desse arquivo (inteiro) que vai na variável `GA_SERVICE_ACCOUNT_JSON`.
   - **Nunca** commite esse arquivo no repositório nem o deixe em `/painel` ou qualquer pasta pública.

## 3. Permissões necessárias (dentro do Google Analytics)

A conta de serviço só consegue ler dados da propriedade se for adicionada como usuária dela:

1. No GA4, vá em **Admin → Acesso à propriedade (Property Access Management)**.
2. **Adicionar usuário** → cole o `client_email` da conta de serviço (está dentro do JSON baixado, campo `client_email`, algo como `felipe-branding-analytics-reader@SEU-PROJETO.iam.gserviceaccount.com`).
3. Papel: **Leitor (Viewer)** — é o suficiente; a integração só faz leitura (`analytics.readonly`).

Sem este passo, toda consulta retorna erro de autenticação (`AUTH_ERROR` / HTTP 401-403), mesmo com as credenciais corretas.

## 4. Onde pegar o Property ID

GA4 → **Admin → Detalhes da propriedade** → o número no topo (não confundir com o Measurement ID `G-XXXXXXX`, que é outro identificador, usado no gtag.js do site — já configurado antes, sem relação com esta integração).

## 5. Como testar localmente

Este projeto não tem build nem `package.json` — as Netlify Functions rodam com zero dependências externas (só `fetch`/`crypto` nativos do Node). Para testar localmente:

```bash
npm install -g netlify-cli   # se ainda não tiver
cd pasta-do-site
netlify link                 # conecta ao site já existente no Netlify
netlify env:set GA_PROPERTY_ID "123456789"
netlify env:set GA_SERVICE_ACCOUNT_JSON "$(cat caminho/para/service-account.json)"
netlify dev
```

Isso sobe o site + as Functions localmente (normalmente em `http://localhost:8888`). Abra `/painel`, faça login e acesse a aba **Analytics**.

Alternativa sem CLI: crie um **branch deploy** ou **deploy preview** no Netlify e configure as variáveis de ambiente só nesse contexto (Netlify permite variáveis por *deploy context*), sem afetar produção enquanto testa.

## 6. Como validar em produção

1. Configure as duas variáveis de ambiente em produção (Netlify → Site settings → Environment variables → escopo "Production" ou "All").
2. Faça um novo deploy (variáveis de ambiente só são lidas por Functions criadas/atualizadas depois da mudança — um redeploy garante isso).
3. Acesse `/painel/#/configuracoes`, seção **Analytics**, clique em **"Testar conexão"**.
   - Sucesso → badge muda para "Conectado" e a mensagem mostra a hora do teste.
   - Falha → toast com a mensagem de erro (nunca mostra a credencial nem stack trace) — os detalhes técnicos completos vão só para os **logs da Function no Netlify** (Functions → analytics-ga → Logs), nunca para o navegador.
4. Acesse `/painel/#/analytics` e confira: Visão geral, Fontes de tráfego, Principais páginas, Dispositivos, Localização, Eventos e o card "Agora" (tempo real, atualiza sozinho a cada 20s).
5. Troque o período (topo da página) e confirme que os números mudam.

## 7. Limitações conhecidas (documentadas de propósito)

- **Cache**: só em memória, por instância "quente" da Function (2 min pra dados históricos, 15s pra realtime). Não é um cache distribuído — um cold start do Netlify reseta.
- **Comparação com período anterior**: calculada com um segundo `dateRanges` na mesma consulta; se essa segunda chamada falhar por qualquer motivo, a métrica principal ainda aparece, só sem o "vs. período anterior".
- **Realtime**: usa `runRealtimeReport` (janela de ~30 min da própria API do Google) — não é histórico, é tratado como "agora" na interface, nunca misturado com os números históricos.
- Nenhuma métrica é inventada: quando o GA4 responde sem linhas, a interface mostra "Sem dados" (Empty State), nunca zera silenciosamente números que pareceriam reais.
