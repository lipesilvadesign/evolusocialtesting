-- ============================================================
-- PROMPT 4 — Equipe, permissões e segurança
-- ============================================================
-- PRINCÍPIO SEGUIDO: negar por padrão, liberar o necessário. A partir daqui,
-- "estar logado" deixa de significar "pode tudo" — só quem tem uma linha em
-- admin_funcionarios (ativo=true) tem qualquer acesso, e o que exatamente
-- ele pode fazer depende do `role`.
--
-- MIGRAÇÃO SEM QUEBRAR O QUE JÁ EXISTE: todo auth.users atual (hoje, todo
-- mundo que já loga tem acesso total) é inserido aqui como role='admin' —
-- ninguém perde acesso ao rodar isto. Só CONTAS NOVAS, criadas depois desta
-- migração, precisam ser explicitamente cadastradas com um papel.
-- ============================================================

-- 1) Tabela de funcionários. id = auth.users.id de propósito — é o que
-- permite toda policy de RLS comparar direto com auth.uid(), sem tabela de
-- ligação extra.
create table if not exists admin_funcionarios (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  email text not null,
  role text not null check (role in ('admin', 'prospeccao', 'design')),
  ativo boolean not null default true,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_funcionarios enable row level security;

-- Backfill: toda conta que já existe vira admin (comportamento idêntico ao
-- de hoje — não muda nada pra quem já usa o sistema).
insert into admin_funcionarios (id, nome, email, role, ativo)
select id, coalesce(raw_user_meta_data->>'nome', split_part(email, '@', 1)), email, 'admin', true
from auth.users
on conflict (id) do nothing;

-- 2) Funções auxiliares (security definer — não recursivas por design: elas
-- é que decidem o RLS de admin_funcionarios, então precisam poder ler essa
-- tabela sem passar pela própria RLS dela).
create or replace function admin_funcionario_role()
returns text
language sql
security definer
stable
as $$
  select role from admin_funcionarios where id = auth.uid() and ativo = true limit 1;
$$;

create or replace function admin_eh_admin()
returns boolean
language sql
security definer
stable
as $$
  select coalesce(admin_funcionario_role() = 'admin', false);
$$;

-- "Este lead é atribuído a mim, ou eu sou admin?" — usado em quase toda
-- policy das tabelas ligadas a um lead/cliente.
create or replace function admin_pode_ver_lead(p_lead_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select admin_eh_admin() or exists (
    select 1 from admin_prospeccao_leads where id = p_lead_id and responsavel_id = auth.uid()
  );
$$;

-- 3) Atribuição de cliente/lead a funcionário — coluna nova, de verdade
-- (FK), separada de `responsavel_interno` (texto livre, mantido só como
-- rótulo legado de exibição; a autorização passa a usar SEMPRE esta aqui).
alter table admin_prospeccao_leads
  add column if not exists responsavel_id uuid references admin_funcionarios(id);

-- ============================================================
-- 4) RLS — admin_funcionarios
-- Ninguém enxerga a lista de colegas, exceto admin. Cada um enxerga a
-- PRÓPRIA linha (pra a interface saber seu nome/papel). Só admin
-- cria/edita/desativa.
-- ============================================================
drop policy if exists "authenticated_select_funcionarios" on admin_funcionarios;
drop policy if exists "authenticated_insert_funcionarios" on admin_funcionarios;
drop policy if exists "authenticated_update_funcionarios" on admin_funcionarios;
drop policy if exists "authenticated_delete_funcionarios" on admin_funcionarios;

create policy "select_propria_linha_ou_admin" on admin_funcionarios for select
  using (admin_eh_admin() or id = auth.uid());
create policy "somente_admin_insert_funcionarios" on admin_funcionarios for insert
  with check (admin_eh_admin());
create policy "somente_admin_update_funcionarios" on admin_funcionarios for update
  using (admin_eh_admin());
create policy "somente_admin_delete_funcionarios" on admin_funcionarios for delete
  using (admin_eh_admin());

-- ============================================================
-- 5) RLS — admin_prospeccao_leads (o núcleo: leads = clientes)
-- admin: tudo. prospeccao: só o que está atribuído a ele, e não pode
-- excluir. design: só lê o que está atribuído a ele (não cria/edita/exclui
-- lead — o trabalho de design mexe em briefing/apresentação, não no
-- cadastro comercial).
-- ============================================================
drop policy if exists "authenticated_select_prospeccao" on admin_prospeccao_leads;
drop policy if exists "authenticated_insert_prospeccao" on admin_prospeccao_leads;
drop policy if exists "authenticated_update_prospeccao" on admin_prospeccao_leads;
drop policy if exists "authenticated_delete_prospeccao" on admin_prospeccao_leads;

create policy "select_leads" on admin_prospeccao_leads for select
  using (admin_eh_admin() or responsavel_id = auth.uid());
create policy "insert_leads" on admin_prospeccao_leads for insert
  with check (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and responsavel_id = auth.uid()));
create policy "update_leads" on admin_prospeccao_leads for update
  using (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and responsavel_id = auth.uid()));
create policy "delete_leads" on admin_prospeccao_leads for delete
  using (admin_eh_admin());

-- ============================================================
-- 6) RLS — tabelas ligadas a um lead (contatos, atividades) — só
-- prospecção mexe aqui, sempre restrito ao lead atribuído.
-- ============================================================
drop policy if exists "authenticated_select_contatos" on admin_prospeccao_contatos;
drop policy if exists "authenticated_insert_contatos" on admin_prospeccao_contatos;
drop policy if exists "authenticated_delete_contatos" on admin_prospeccao_contatos;
drop policy if exists "authenticated_all_contatos" on admin_prospeccao_contatos;

create policy "select_contatos" on admin_prospeccao_contatos for select using (admin_pode_ver_lead(lead_id));
create policy "insert_contatos" on admin_prospeccao_contatos for insert
  with check (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and admin_pode_ver_lead(lead_id)));
create policy "delete_contatos" on admin_prospeccao_contatos for delete
  using (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and admin_pode_ver_lead(lead_id)));

drop policy if exists "authenticated_select_atividades" on admin_prospeccao_atividades;
drop policy if exists "authenticated_insert_atividades" on admin_prospeccao_atividades;
drop policy if exists "authenticated_all_atividades" on admin_prospeccao_atividades;

create policy "select_atividades" on admin_prospeccao_atividades for select using (admin_pode_ver_lead(lead_id));
create policy "insert_atividades" on admin_prospeccao_atividades for insert
  with check (admin_pode_ver_lead(lead_id));

-- ============================================================
-- 7) RLS — briefing (prospecção E design podem editar; leitura pra quem
-- enxerga o lead)
-- ============================================================
drop policy if exists "authenticated_select_briefings" on admin_briefings;
drop policy if exists "authenticated_insert_briefings" on admin_briefings;
drop policy if exists "authenticated_update_briefings" on admin_briefings;
drop policy if exists "authenticated_delete_briefings" on admin_briefings;

create policy "select_briefings" on admin_briefings for select using (admin_pode_ver_lead(lead_id));
create policy "insert_briefings" on admin_briefings for insert
  with check (admin_eh_admin() or (admin_funcionario_role() in ('prospeccao', 'design') and admin_pode_ver_lead(lead_id)));
create policy "update_briefings" on admin_briefings for update
  using (admin_eh_admin() or (admin_funcionario_role() in ('prospeccao', 'design') and admin_pode_ver_lead(lead_id)));
create policy "delete_briefings" on admin_briefings for delete using (admin_eh_admin());

-- ============================================================
-- 8) RLS — métricas (só prospecção/admin registram; dado comercial, não é
-- trabalho de design)
-- ============================================================
drop policy if exists "authenticated_select_metricas" on admin_metricas;
drop policy if exists "authenticated_insert_metricas" on admin_metricas;
drop policy if exists "authenticated_delete_metricas" on admin_metricas;

create policy "select_metricas" on admin_metricas for select using (admin_pode_ver_lead(lead_id));
create policy "insert_metricas" on admin_metricas for insert
  with check (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and admin_pode_ver_lead(lead_id)));
create policy "delete_metricas" on admin_metricas for delete
  using (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and admin_pode_ver_lead(lead_id)));

-- ============================================================
-- 9) RLS — diagnóstico (análise sensível — só admin cria/edita/publica;
-- prospecção/design só LEEM o que já foi publicado sobre um lead deles;
-- rascunho fica só com admin mesmo)
-- ============================================================
drop policy if exists "authenticated_select_diagnosticos" on admin_diagnosticos;
drop policy if exists "authenticated_insert_diagnosticos" on admin_diagnosticos;
drop policy if exists "authenticated_update_diagnosticos" on admin_diagnosticos;
drop policy if exists "authenticated_delete_diagnosticos" on admin_diagnosticos;

create policy "select_diagnosticos" on admin_diagnosticos for select
  using (admin_eh_admin() or (status = 'publicado' and admin_pode_ver_lead(lead_id)));
create policy "insert_diagnosticos" on admin_diagnosticos for insert with check (admin_eh_admin());
create policy "update_diagnosticos" on admin_diagnosticos for update using (admin_eh_admin());
create policy "delete_diagnosticos" on admin_diagnosticos for delete using (admin_eh_admin());

-- ============================================================
-- 10) RLS — apresentações (design monta/edita rascunho pro lead atribuído;
-- só admin publica de verdade — publicar é uma ação de negócio, não visual)
-- ============================================================
drop policy if exists "authenticated_select_apresentacoes" on admin_apresentacoes;
drop policy if exists "authenticated_insert_apresentacoes" on admin_apresentacoes;
drop policy if exists "authenticated_update_apresentacoes" on admin_apresentacoes;
drop policy if exists "authenticated_delete_apresentacoes" on admin_apresentacoes;
-- a policy pública (anon, status='publicado') já existe e NÃO é tocada aqui.

create policy "select_apresentacoes" on admin_apresentacoes for select
  using (admin_eh_admin() or admin_pode_ver_lead(lead_id));
create policy "insert_apresentacoes" on admin_apresentacoes for insert
  with check (admin_eh_admin() or (admin_funcionario_role() = 'design' and admin_pode_ver_lead(lead_id)));
create policy "update_apresentacoes" on admin_apresentacoes for update
  using (
    admin_eh_admin()
    or (admin_funcionario_role() = 'design' and admin_pode_ver_lead(lead_id) and status = 'rascunho')
  );
create policy "delete_apresentacoes" on admin_apresentacoes for delete using (admin_eh_admin());

-- ============================================================
-- 11) RLS — tabelas de administração geral: só admin. (configurações,
-- conteúdo do site, tarefas, uso de IA, insights, sistema)
-- Nada de prospecção/design aparece aqui — "negar por padrão".
--
-- ACHADO DE AUDITORIA (13/09): este loop dava erro e abortava o bloco
-- inteiro (e tudo que vem depois dele neste arquivo, seção 12 —
-- admin_audit_log) porque admin_tarefas/admin_ai_usage/
-- admin_insights_historico nunca tinham uma migração própria em nenhum
-- SQL_PENDENTE_*.sql — "alter/policy numa tabela inexistente" é erro em
-- Postgres. `admin_relatorios` foi removido da lista (a página Relatórios
-- foi excluída do painel). Se você está rodando este arquivo do zero,
-- use SQL_FIX_completo_13_09.sql em vez deste — ele já cria as 3 tabelas
-- que faltavam antes de repetir este mesmo loop, então este arquivo pode
-- ficar só como registro histórico da migração original.
-- ============================================================
do $$
declare
  tabela text;
begin
  foreach tabela in array array[
    'admin_settings', 'admin_posts', 'admin_pages', 'site_content',
    'admin_tarefas', 'admin_ai_usage', 'admin_insights_historico',
    'consultas_leads', 'consultas_atividades'
  ]
  loop
    execute format('drop policy if exists "authenticated_select_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "authenticated_insert_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "authenticated_update_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "authenticated_delete_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "authenticated_all_%1$s" on %1$s', tabela);
    execute format('create policy "somente_admin_select" on %1$s for select using (admin_eh_admin())', tabela);
    execute format('create policy "somente_admin_insert" on %1$s for insert with check (admin_eh_admin())', tabela);
    execute format('create policy "somente_admin_update" on %1$s for update using (admin_eh_admin())', tabela);
    execute format('create policy "somente_admin_delete" on %1$s for delete using (admin_eh_admin())', tabela);
  end loop;
end $$;

-- IMPORTANTE: o loop acima teria apagado também as policies públicas
-- (anon) de consultas_leads/consultas_atividades (formulário público
-- /consultas) — recriando-as aqui, IDÊNTICAS às originais.
create policy "anon_insert_consultas_leads" on consultas_leads for insert
  with check (true);
create policy "anon_update_evento_consultas_leads" on consultas_leads for update
  using (true) with check (true);
create policy "anon_insert_consultas_atividades" on consultas_atividades for insert
  with check (true);
-- ATENÇÃO: as duas policies acima usam `using/with check (true)` só pra
-- REPLICAR o comportamento já existente antes desta migração — confira o
-- texto exato das policies originais em SQL_PENDENTE_consultas.sql antes
-- de rodar isto, e ajuste aqui se a condição original for mais específica.

-- ============================================================
-- 12) RLS — admin_audit_log: qualquer funcionário ativo pode INSERIR (é
-- o próprio registro da ação dele), mas só admin pode LER a trilha
-- completa (ver ações de outros).
-- ============================================================
drop policy if exists "authenticated_select_audit" on admin_audit_log;
drop policy if exists "authenticated_insert_audit" on admin_audit_log;
drop policy if exists "authenticated_all_audit" on admin_audit_log;

create policy "select_audit_somente_admin" on admin_audit_log for select using (admin_eh_admin());
create policy "insert_audit_qualquer_funcionario_ativo" on admin_audit_log for insert
  with check (exists (select 1 from admin_funcionarios where id = auth.uid() and ativo = true));

-- ============================================================
-- 13) admin_notificacoes — mantido authenticated-geral de propósito
-- (notificações do sistema, ex.: "N novos leads", não têm dono individual
-- hoje). Se no futuro notificações forem por pessoa, revisar aqui.
-- ============================================================
-- (sem alteração)
