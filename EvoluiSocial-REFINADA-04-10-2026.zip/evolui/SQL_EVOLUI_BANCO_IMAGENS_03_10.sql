-- evolui_banco_imagens_taxonomia (aditivo, idempotente). Helper de admin: public.evolui_eh_admin()

create table if not exists public.evolui_tax_termos(
  id uuid primary key default gen_random_uuid(),
  tipo text not null check (tipo in ('area','subramo','tema','entidade')),
  pai_id uuid null references public.evolui_tax_termos(id) on delete restrict,
  chave text not null,
  rotulo text not null,
  sinonimos text[] not null default '{}',
  ativo boolean not null default true,
  criado_em timestamptz default now(),
  unique(tipo, chave)
);
alter table public.evolui_tax_termos enable row level security;
create index if not exists evolui_tax_termos_pai_idx on public.evolui_tax_termos(pai_id);
drop policy if exists tax_sel on public.evolui_tax_termos;
create policy tax_sel on public.evolui_tax_termos for select to authenticated using (true);
drop policy if exists tax_ins on public.evolui_tax_termos;
create policy tax_ins on public.evolui_tax_termos for insert to authenticated with check ((select public.evolui_eh_admin()));
drop policy if exists tax_upd on public.evolui_tax_termos;
create policy tax_upd on public.evolui_tax_termos for update to authenticated using ((select public.evolui_eh_admin())) with check ((select public.evolui_eh_admin()));
drop policy if exists tax_del on public.evolui_tax_termos;
create policy tax_del on public.evolui_tax_termos for delete to authenticated using ((select public.evolui_eh_admin()));
revoke all on public.evolui_tax_termos from anon, public;
grant select, insert, update, delete on public.evolui_tax_termos to authenticated;

create table if not exists public.evolui_imagens(
  id uuid primary key default gen_random_uuid(),
  arquivo text not null unique,
  titulo text not null,
  texto_alternativo text not null default '',
  largura int, altura int, peso int,
  area_id uuid references public.evolui_tax_termos(id),
  subramo_id uuid references public.evolui_tax_termos(id),
  tema_id uuid references public.evolui_tax_termos(id),
  tags text[] not null default '{}',
  plataformas text[] not null default '{}',
  formatos text[] not null default '{}',
  tipos_card text[] not null default '{}',
  origem text not null default 'propria' check (origem in ('propria','licenciada','banco_gratuito','cliente_autorizado','outra')),
  licenca text not null default '',
  autor text not null default '',
  url_fonte text not null default '',
  status text not null default 'rascunho' check (status in ('rascunho','ativa','revisao','arquivada')),
  usos int not null default 0,
  criado_em timestamptz default now(),
  criado_por uuid default auth.uid(),
  atualizado_em timestamptz default now(),
  constraint evolui_imagens_ativa_exige_licenca check (status <> 'ativa' or length(trim(licenca)) > 0)
);
alter table public.evolui_imagens enable row level security;
create index if not exists evolui_imagens_status_idx on public.evolui_imagens(status);
create index if not exists evolui_imagens_area_idx on public.evolui_imagens(area_id);
create index if not exists evolui_imagens_tema_idx on public.evolui_imagens(tema_id);
create index if not exists evolui_imagens_subramo_idx on public.evolui_imagens(subramo_id);
create index if not exists evolui_imagens_tags_gin on public.evolui_imagens using gin(tags);
drop policy if exists img_sel on public.evolui_imagens;
create policy img_sel on public.evolui_imagens for select to authenticated using ((select public.evolui_eh_admin()));
drop policy if exists img_ins on public.evolui_imagens;
create policy img_ins on public.evolui_imagens for insert to authenticated with check ((select public.evolui_eh_admin()));
drop policy if exists img_upd on public.evolui_imagens;
create policy img_upd on public.evolui_imagens for update to authenticated using ((select public.evolui_eh_admin())) with check ((select public.evolui_eh_admin()));
drop policy if exists img_del on public.evolui_imagens;
create policy img_del on public.evolui_imagens for delete to authenticated using ((select public.evolui_eh_admin()));
revoke all on public.evolui_imagens from anon, public;
grant select, insert, update, delete on public.evolui_imagens to authenticated;

create or replace function public.evolui_imagens_touch() returns trigger
language plpgsql set search_path = '' as $$
begin new.atualizado_em := now(); return new; end $$;
revoke all on function public.evolui_imagens_touch() from public, anon, authenticated;
drop trigger if exists evolui_imagens_touch on public.evolui_imagens;
create trigger evolui_imagens_touch before update on public.evolui_imagens
  for each row execute function public.evolui_imagens_touch();

create table if not exists public.evolui_imagem_usos(
  id bigint generated always as identity primary key,
  imagem_id uuid references public.evolui_imagens(id) on delete cascade,
  tipo_card text, tema text,
  criado_em timestamptz default now()
);
alter table public.evolui_imagem_usos enable row level security;
create index if not exists evolui_imagem_usos_img_idx on public.evolui_imagem_usos(imagem_id);
drop policy if exists usos_sel on public.evolui_imagem_usos;
create policy usos_sel on public.evolui_imagem_usos for select to authenticated using ((select public.evolui_eh_admin()));
revoke all on public.evolui_imagem_usos from anon, public;
grant select on public.evolui_imagem_usos to authenticated;

-- normalizacao (sem acento, minusculas)
create or replace function public.evolui_tax_norm(t text) returns text
language sql immutable set search_path = '' as $$
  select lower(btrim(translate(coalesce(t,''),
   'áàâãäéèêëíìîïóòôõöúùûüçñÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇÑ',
   'aaaaaeeeeiiiiooooouuuucnaaaaaeeeeiiiiooooouuuucn')))
$$;
revoke all on function public.evolui_tax_norm(text) from public, anon, authenticated;

-- RPC: escolher imagem para card
create or replace function public.evolui_imagem_para_card(p jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  v_area uuid; v_sub uuid; v_tema uuid; v_id uuid; v_arq text;
  v_alt text; v_tags text[]; v_evitar uuid[]; v_plat text; v_fmt text; v_card text;
begin
  if auth.uid() is null then return jsonb_build_object('src', null); end if;
  p := coalesce(p, '{}'::jsonb);
  select t.id into v_area from public.evolui_tax_termos t where t.tipo='area' and t.ativo
    and public.evolui_tax_norm(p->>'area') <> ''
    and (t.chave = public.evolui_tax_norm(p->>'area') or public.evolui_tax_norm(t.rotulo) = public.evolui_tax_norm(p->>'area')
      or public.evolui_tax_norm(p->>'area') in (select public.evolui_tax_norm(s) from unnest(t.sinonimos) s)) limit 1;
  select t.id into v_sub from public.evolui_tax_termos t where t.tipo='subramo' and t.ativo
    and public.evolui_tax_norm(p->>'subramo') <> ''
    and (t.chave = public.evolui_tax_norm(p->>'subramo') or public.evolui_tax_norm(t.rotulo) = public.evolui_tax_norm(p->>'subramo')
      or public.evolui_tax_norm(p->>'subramo') in (select public.evolui_tax_norm(s) from unnest(t.sinonimos) s)) limit 1;
  select t.id into v_tema from public.evolui_tax_termos t where t.tipo='tema' and t.ativo
    and public.evolui_tax_norm(p->>'tema') <> ''
    and (t.chave = public.evolui_tax_norm(p->>'tema') or public.evolui_tax_norm(t.rotulo) = public.evolui_tax_norm(p->>'tema')
      or public.evolui_tax_norm(p->>'tema') in (select public.evolui_tax_norm(s) from unnest(t.sinonimos) s)) limit 1;
  if v_area is null then return jsonb_build_object('src', null); end if;
  select coalesce(array_agg(public.evolui_tax_norm(x)), '{}') into v_tags
    from jsonb_array_elements_text(case when jsonb_typeof(p->'tags')='array' then p->'tags' else '[]'::jsonb end) x;
  select coalesce(array_agg(x::uuid), '{}') into v_evitar
    from jsonb_array_elements_text(case when jsonb_typeof(p->'evitar')='array' then p->'evitar' else '[]'::jsonb end) x
    where x ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
  v_plat := public.evolui_tax_norm(p->>'plataforma');
  v_fmt := public.evolui_tax_norm(p->>'formato');
  v_card := public.evolui_tax_norm(p->>'tipo_card');

  select i.id, i.arquivo, i.texto_alternativo into v_id, v_arq, v_alt
  from public.evolui_imagens i
  where i.status = 'ativa' and i.area_id = v_area and not (i.id = any(v_evitar))
    and (case when v_tema is not null and i.tema_id = v_tema then 50 else 0 end
       + case when v_sub is not null and i.subramo_id = v_sub then 25 else 0 end
       + 12
       + 4 * (select count(*) from unnest(i.tags) tg where public.evolui_tax_norm(tg) = any(v_tags))
       + case when v_plat <> '' and v_plat in (select public.evolui_tax_norm(z) from unnest(i.plataformas) z) then 3 else 0 end
       + case when v_fmt <> '' and v_fmt in (select public.evolui_tax_norm(z) from unnest(i.formatos) z) then 3 else 0 end
       + case when v_card <> '' and v_card in (select public.evolui_tax_norm(z) from unnest(i.tipos_card) z) then 2 else 0 end) >= 12
  order by (case when v_tema is not null and i.tema_id = v_tema then 50 else 0 end
       + case when v_sub is not null and i.subramo_id = v_sub then 25 else 0 end
       + 4 * (select count(*) from unnest(i.tags) tg where public.evolui_tax_norm(tg) = any(v_tags))
       + case when v_plat <> '' and v_plat in (select public.evolui_tax_norm(z) from unnest(i.plataformas) z) then 3 else 0 end
       + case when v_fmt <> '' and v_fmt in (select public.evolui_tax_norm(z) from unnest(i.formatos) z) then 3 else 0 end
       + case when v_card <> '' and v_card in (select public.evolui_tax_norm(z) from unnest(i.tipos_card) z) then 2 else 0 end) desc,
     i.usos asc, i.id
  limit 1;

  if v_id is null then return jsonb_build_object('src', null); end if;
  update public.evolui_imagens set usos = usos + 1 where id = v_id;
  insert into public.evolui_imagem_usos(imagem_id, tipo_card, tema) values (v_id, p->>'tipo_card', p->>'tema');
  return jsonb_build_object('id', v_id, 'arquivo', v_arq, 'alt', v_alt);
end $$;
revoke all on function public.evolui_imagem_para_card(jsonb) from public, anon;
grant execute on function public.evolui_imagem_para_card(jsonb) to authenticated;

-- RPC: lacunas (admin)
create or replace function public.evolui_imagens_lacunas(dias int default 30)
returns table(termo text, buscas bigint)
language plpgsql security definer set search_path = '' as $$
begin
  if not coalesce(public.evolui_eh_admin(), false) then
    raise exception 'acesso negado' using errcode = '42501';
  end if;
  return query
  with b as (
    select public.evolui_tax_norm(x.termo) n, count(*) c
    from public.evolui_buscas x
    where x.criado_em >= now() - make_interval(days => greatest(coalesce(dias,30),1))
      and public.evolui_tax_norm(x.termo) <> ''
    group by 1
  ), m as (
    select b.n, b.c,
      (select t.id from public.evolui_tax_termos t
        where t.tipo='tema' and t.ativo
          and (t.chave = b.n or public.evolui_tax_norm(t.rotulo) = b.n
            or b.n in (select public.evolui_tax_norm(s) from unnest(t.sinonimos) s)
            or position(t.chave in b.n) > 0)
        limit 1) tema_id
    from b
  )
  select m.n::text, m.c::bigint from m
  where m.tema_id is null
     or not exists (select 1 from public.evolui_imagens i where i.status='ativa' and i.tema_id = m.tema_id)
  order by m.c desc, m.n limit 30;
end $$;
revoke all on function public.evolui_imagens_lacunas(int) from public, anon;
grant execute on function public.evolui_imagens_lacunas(int) to authenticated;

-- SEED
insert into public.evolui_tax_termos(tipo,chave,rotulo) values
 ('area','doces','Doces e confeitaria'),('area','alimentacao','Alimentação e restaurantes'),
 ('area','beleza','Beleza e estética'),('area','moda','Moda e acessórios'),
 ('area','saude','Saúde e bem-estar'),('area','fitness','Academia e fitness'),
 ('area','pet','Pet'),('area','casa','Casa e decoração'),
 ('area','educacao','Educação e cursos'),('area','servicos','Serviços profissionais'),
 ('area','criador','Marca pessoal / criador'),('area','outro','Outro')
on conflict (tipo,chave) do nothing;

insert into public.evolui_tax_termos(tipo,pai_id,chave,rotulo)
select 'subramo', a.id, v.chave, v.rotulo from (values
 ('beleza','cuidados_pele','Cuidados com a pele'),('beleza','cabelo_barbearia','Cabelo / Barbearia'),
 ('fitness','treino','Treino'),('saude','clinicas','Clínicas'),
 ('alimentacao','restaurantes_pizzarias','Restaurantes / Pizzarias'),('pet','pet_shop','Pet shop'),
 ('casa','decoracao','Decoração'),('educacao','cursos','Cursos'),('doces','confeitaria','Confeitaria')
) v(area,chave,rotulo) join public.evolui_tax_termos a on a.tipo='area' and a.chave=v.area
on conflict (tipo,chave) do nothing;

insert into public.evolui_tax_termos(tipo,pai_id,chave,rotulo,sinonimos)
select 'tema', s.id, v.chave, v.rotulo, v.sin from (values
 ('cuidados_pele','skincare','Skincare',array['skincare','cuidados com a pele','protetor solar']),
 ('cabelo_barbearia','barbearia','Barbearia',array['barbearia','barbeiro','barba']),
 ('cabelo_barbearia','corte','Corte',array['corte','corte de cabelo']),
 ('treino','academia','Academia',array['academia','musculacao']),
 ('treino','treino_em_casa','Treino em casa',array['treino em casa','treino caseiro']),
 ('clinicas','clinica','Clínica',array['clinica','consultorio']),
 ('clinicas','odontologia','Odontologia',array['odontologia','dentista']),
 ('restaurantes_pizzarias','restaurante','Restaurante',array['restaurante','almoco']),
 ('restaurantes_pizzarias','pizzaria','Pizzaria',array['pizzaria','pizza']),
 ('pet_shop','petshop','Petshop',array['petshop','pet shop','banho e tosa']),
 ('decoracao','decoracao','Decoração',array['decoracao','decoração de interiores']),
 ('cursos','cursos','Cursos',array['curso','cursos online','aulas']),
 ('confeitaria','bolos','Bolos',array['bolo','bolos','brigadeiro'])
) v(sub,chave,rotulo,sin) join public.evolui_tax_termos s on s.tipo='subramo' and s.chave=v.sub
on conflict (tipo,chave) do nothing;

-- STORAGE
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('evolui-imagens','evolui-imagens',true,3145728,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true, file_size_limit=3145728, allowed_mime_types=array['image/jpeg','image/png','image/webp'];
drop policy if exists evolui_imagens_ler on storage.objects;
create policy evolui_imagens_ler on storage.objects for select to public using (bucket_id='evolui-imagens');
drop policy if exists evolui_imagens_enviar on storage.objects;
create policy evolui_imagens_enviar on storage.objects for insert to authenticated with check (bucket_id='evolui-imagens' and (select public.evolui_eh_admin()));
drop policy if exists evolui_imagens_atualizar on storage.objects;
create policy evolui_imagens_atualizar on storage.objects for update to authenticated using (bucket_id='evolui-imagens' and (select public.evolui_eh_admin())) with check (bucket_id='evolui-imagens' and (select public.evolui_eh_admin()));
drop policy if exists evolui_imagens_apagar on storage.objects;
create policy evolui_imagens_apagar on storage.objects for delete to authenticated using (bucket_id='evolui-imagens' and (select public.evolui_eh_admin()));
