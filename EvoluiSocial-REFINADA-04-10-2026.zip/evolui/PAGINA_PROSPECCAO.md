# Página de Prospecção — Felipe Branding

Documento único e atualizado de tudo que existe na aba **Prospecção** do
painel administrativo. Substitui a necessidade de juntar informação
espalhada em `PROSPECCAO_AUTOMACAO.md`, `PROSPECCAO_BUSCA_E_EMAIL.md` e o
histórico de decisões — este arquivo é o retrato de como a página funciona
hoje.

## O que a página faz

CRM simples de leads de prospecção B2B: empresas de médio/grande porte com
presença online fraca, encontradas automaticamente ou manualmente,
organizadas por prioridade, contatadas por WhatsApp ou e-mail direto do
painel.

## Visão geral da tela

- **Toolbar**: busca por nome, filtros (status, setor, prioridade, período),
  botão **Relatório**, botão **Atualizar** (busca manual), botão **+ Novo lead**.
- **Barra de seleção em massa**: aparece ao marcar checkboxes na lista —
  "Enviar e-mail para selecionados".
- **Lista de leads**: checkbox, empresa (com tag de origem e status de
  e-mail), prioridade, setor, cidade, ações de contato (WhatsApp, copiar
  mensagem, copiar e-mail), status, editar. Ordenada com prioridade Alta
  primeiro.
- **Editor de lead** (painel lateral): todos os campos do lead, incluindo os
  de preenchimento manual (e-mail, anos de mercado, função do contato, site).

## De onde vêm os leads

### 1. Automática — semanal, gratuita (já existia antes deste projeto)
`netlify/functions/prospeccao-sync-osm.js`, agendada (`@weekly` no
`netlify.toml`). Busca via OpenStreetMap/Overpass num raio de ~90km ao
redor de Petrolina, cobrindo o polo Vale do São Francisco (Petrolina,
Juazeiro, Lagoa Grande, Santa Maria da Boa Vista, Casa Nova, Sobradinho,
Curaçá, Orocó, Dormentes, Afrânio). Filtra por palavras-chave de setor
(`SECTOR_KEYWORDS`). Entra como `fonte = 'osm_auto'`.

### 2. Manual — botão "Atualizar", sob demanda
`netlify/functions/prospeccao-buscar-empresas-background.js`. Usuário
escolhe cidades (chips clicáveis) + ramo/segmento (texto livre) num popup.
Duas fontes rodam **em paralelo** pra cada cidade, e os resultados se
completam:

- **Geoapify Places API** (`_lib/integrations/geoapify.js`) — infraestrutura
  paga por trás (plano gratuito, 3.000 créditos/dia, sem cartão), mas só
  acha lugares com categoria de negócio marcada no OSM.
- **OpenStreetMap/Overpass** (`_lib/integrations/openStreetMap.js`) — mesmo
  motor da busca automática, com fallback entre **6 espelhos públicos** e
  retry em `429`. Acha qualquer lugar com nome batendo, categorizado ou não
  — cobre o que o Geoapify estruturalmente não alcança.

Empresa encontrada pelas duas fontes não duplica (comparação por nome, além
do id de origem). Cada lead guarda a fonte exata (`geoapify_manual` ou
`osm_manual`) — a tag "Manual" na lista cobre as duas.

**Por que as duas fontes**: testado em produção que muitas empresas
brasileiras reais (ex: construtoras) existem no OSM só com nome/endereço,
sem categoria — o Geoapify sozinho não encontra essas.

**Geocodificação** da cidade (Nominatim, com fallback pro Photon) é
compartilhada pelas duas fontes.

**Progresso em tempo real**: o navegador gera um `jobId` e o popup mostra,
cidade por cidade, uma barra de progresso + lista com ✅/⚠️ — consultando
`admin_prospeccao_buscas` por polling (`prospeccao-busca-status.js`), sem
depender de `admin_notificacoes`.

### 3. Prioridade automática
Lead novo (de qualquer busca) entra com `prioridade = 'alta'` se nenhum
site foi encontrado pra empresa, ou `'media'` se tem site — não é uma
"chance de fechar contrato" calculada (não há dado histórico de conversão
pra sustentar isso), é o critério real que a Felipe Branding já usava
(presença online fraca = prioridade). Sempre editável manualmente. Lista
tem filtro de prioridade e ordena Alta → Média → Baixa por padrão.

## Envio de e-mail

Botão **"Enviar e-mail para selecionados"** (aparece com a seleção em
massa) → popup com modelo de assunto/corpo (variáveis `{{empresa}}`,
`{{setor}}`, `{{cidade}}`) → `prospeccao-enviar-email-background.js`.

- SMTP da própria Umbler (`contato@felipebranding.com.br`), via
  `_lib/integrations/umblerSmtp.js` + `_lib/integrations/rawSmtp.js` (cliente
  SMTP mínimo, só net/tls nativos do Node — zero dependência externa, deploy
  no Netlify continua puramente estático).
- Um e-mail de cada vez, com pausa de 4s entre envios, texto simples (sem
  HTML) — a Umbler proíbe disparo em massa/marketing a partir de e-mail
  profissional nos termos de uso; esse cuidado existe pra não parecer
  disparo em massa e arriscar bloqueio da conta/domínio.
- Limite diário configurável (`EMAIL_PROSPECCAO_LIMITE_DIARIO`, padrão 25).
- Progresso em tempo real igual à busca (`admin_prospeccao_envios` +
  `prospeccao-envio-status.js`), com barra de progresso lead por lead.
- Cada lead guarda `email_enviado_em`/`email_status` do envio mais recente
  (badge "E-mail enviado"/"Falha no envio" na lista).

## Filtro de período e Relatório

- **Filtro de período** na toolbar (Hoje / 7 dias / 30 dias / Todo o
  período) — filtra a lista de leads pela data de cadastro.
- **Botão Relatório** (`prospeccao-relatorio.js`) — resumo agregado do
  período escolhido: e-mails enviados, falhas, buscas realizadas, empresas
  encontradas, leads novos por fonte — mais tabela detalhada de cada envio
  e cada busca feita. Sem tabela nova no banco: lê `admin_prospeccao_envios`,
  `admin_prospeccao_buscas` e `admin_prospeccao_leads` (cada clique em
  "Atualizar"/"Enviar e-mail" já vira uma linha permanente nessas tabelas).

## Estrutura de arquivos

```
netlify/functions/
  prospeccao.js                          CRUD de leads (list/create/update/delete)
  prospeccao-sync-osm.js                 job semanal automático (OSM)
  prospeccao-buscar-empresas-background.js  botão "Atualizar" (Geoapify + OSM em paralelo)
  prospeccao-busca-status.js             polling do progresso da busca
  prospeccao-enviar-email-background.js  envio de e-mail em lote
  prospeccao-envio-status.js             polling do progresso do envio
  prospeccao-relatorio.js                relatório agregado por período
  prospeccao-contatos.js                 CRUD de contatos por lead
  prospeccao-atividades.js               histórico de atividades por lead
  prospeccao-optout.js                   registrar bloqueio permanente
  _lib/integrations/
    geoapify.js                          Places API (categoria + filtro por nome/radical)
    openStreetMap.js                     Overpass (6 espelhos + retry) + geocodificação
    umblerSmtp.js                        envio SMTP (usa rawSmtp.js por baixo)
    rawSmtp.js                            cliente SMTP mínimo (net/tls nativos, zero dependência)
    googlePlaces.js                      não usado hoje (tentativa anterior, mantido no projeto)
  _lib/services/
    prospeccaoService.js                 CRUD + dedupe (origem_id) + contagem diária de e-mail
    buscaStatusService.js                progresso da busca (admin_prospeccao_buscas)
    envioStatusService.js                progresso do envio (admin_prospeccao_envios)
    relatorioService.js                  consultas do relatório por período
    contatosService.js                   CRUD de contatos
    atividadesService.js                 CRUD de atividades (atualiza ultima/proxima_atividade_em no lead)
    optoutService.js                     registrar/carregar lista de bloqueio
  _lib/
    templateUtil.js                      preencherModelo, normalizarNome, calcularRadical, agregarRelatorio, onlyDigits, candidatoEstaBloqueado, leadEstaBloqueado
    dateRangeProspeccao.js               resolve "hoje/semana/mes/tudo" em datas reais
    scoreEngine.js                       calcularScore/faixaScore (score de lead multi-critério)

painel/assets/js/
  views/prospeccao.js                    a tela inteira (toolbar, lista, popups, editor)
  services/prospeccaoClient.js           chamadas HTTP autenticadas pra tudo acima
  services/scoreEngine.js                espelho no navegador do motor de score
  assets/css/prospeccao-view.css         CSS isolado desta tela (não afeta outras)

tests/  — 101 testes automatizados (node:test), cobrindo toda a lógica pura
  acima (fallback entre espelhos, radical de palavra, template de e-mail,
  configuração SMTP simulada, agregação de relatório, cálculo de período,
  score de lead incluindo sincronia backend↔frontend, bloqueio de opt-out).
```

## Fase 1 do CRM (score, contatos, atividades, opt-out)

Implementada a partir de uma análise externa comparando o painel com
práticas de CRM/prospecção B2B maduras. Adiciona uma camada de
qualificação e histórico por cima do que já existia — nenhuma mudança no
que já funcionava (busca, envio, relatório continuam iguais).

### Score de lead (substituindo a prioridade single-sinal)
`_lib/scoreEngine.js` (backend) + `painel/assets/js/services/scoreEngine.js`
(espelho no navegador, testado pra nunca sair de sincronia com o backend).
Soma pontos por sinal presente — não é uma "chance de fechar contrato"
mágica, é uma soma pontuada e explicada (`score_motivos`):

| Sinal | Pontos | Como é obtido |
|---|---|---|
| Sem site encontrado | +30 | Automático (campo `site` vazio) |
| Site desatualizado/com problema | +20 | Manual (checkbox no editor) |
| Instagram ativo mas desorganizado | +15 | Manual |
| Google Business Profile fraco | +15 | Manual |
| Médio/grande porte | +15 | Manual |
| Segmento de alto potencial | +15 | Manual |
| Contato decisor identificado | +20 | Automático (tem ao menos 1 contato cadastrado) |
| E-mail validado | +10 | Manual |
| Respondeu ao contato | +40 | Automático (estágio da oportunidade) |
| Pediu proposta ou reunião | +70 | Automático (estágio da oportunidade) — substitui o de "respondeu", não soma junto |

Recalculado a cada vez que o lead é salvo no editor. Lista ordena por
score (prioridade manual como desempate).

### Três dimensões de status (antes só existia uma)
- **Estágio da oportunidade** (coluna `status`, já existia): novo_lead →
  contatado → respondeu → reuniao_marcada → proposta_enviada → cliente/nao_convertido.
- **Qualidade do lead** (`status_lead`, novo): novo, pesquisando,
  qualificado, não qualificado, duplicado, bloqueado.
- **Prontidão de contato** (`status_contato`, novo): sem contato, e-mail
  encontrado, e-mail validado, WhatsApp disponível, decisor identificado,
  optout solicitado, não contatar. **`nao_contatar`/`optout_solicitado`
  bloqueiam envio de e-mail automaticamente.**

### Contatos (uma empresa pode ter vários)
Tabela `admin_prospeccao_contatos` — nome, cargo, e-mail, WhatsApp,
LinkedIn, principal. CRUD inline no editor do lead (`prospeccao-contatos.js`).
Ter ao menos 1 contato conta ponto no score ("decisor identificado").

### Atividades (histórico + próxima ação)
Tabela `admin_prospeccao_atividades` — e-mail enviado, follow-up, resposta,
reunião, etc., com data e "próxima ação em". Cada atividade registrada
atualiza `ultima_atividade_em`/`proxima_atividade_em` no lead
(`prospeccao-atividades.js`). Histórico + formulário de nova atividade no
editor.

### Opt-out (bloqueio permanente, LGPD)
Tabela `admin_prospeccao_optouts` — **separada** de `admin_prospeccao_leads`
de propósito: sobrevive à exclusão do lead, então se a mesma empresa for
reencontrada numa busca futura (mesmo `origem_id`), ela não pode ser
recontatada. Botão "Registrar opt-out" no editor grava o bloqueio e marca
`status_contato = 'nao_contatar'`. Checado em dois pontos:
- **Busca manual** (`prospeccao-buscar-empresas-background.js`) — nunca
  insere um candidato bloqueado.
- **Envio de e-mail** (`prospeccao-enviar-email-background.js`) — nunca
  envia pra um lead bloqueado (por status_contato OU por estar na lista de
  opt-out), mesmo se selecionado por engano.

Lógica de bloqueio (`candidatoEstaBloqueado`/`leadEstaBloqueado`) e o motor
de score são testados isoladamente — 101 testes no total no projeto.

### O que NÃO entrou nesta fase (deixado pra depois, de propósito)
Dashboard inicial com indicadores agregados, automação por regras
(follow-up automático, mover pra nutrição), qualificação por IA, campos
LGPD completos (base legal, finalidade, aviso de privacidade), funil visual
de arrastar-e-soltar. A análise recebida propõe isso nas Fases 2 e 3 —
implementar quando a Fase 1 estiver validada em uso real.

### Enriquecimento manual via CSV (CNPJ/porte)
Botões "Exportar CSV" / "Importar CSV" na toolbar — fluxo deliberadamente
manual, sem integração automática com nenhuma API de CNPJ. Exporta os
leads filtrados (mesmas colunas sempre, incluindo `id` pra casar a
atualização de volta), o usuário preenche CNPJ/anos de mercado/porte fora
do sistema (ex: consultando um por um no CNPJ.ws, gratuito), reimporta o
mesmo arquivo editado. Só os campos que realmente mudaram viram
atualização — reimportar sem editar nada não escreve nada no banco.
`painel/assets/js/services/csvLeads.js` (puro, sem DOM) + 9 testes.

## Setup necessário (variáveis de ambiente no Netlify)

| Variável | Obrigatória | Descrição |
|---|---|---|
| `GEOAPIFY_API_KEY` | Recomendada | Busca manual sem ela roda só com OpenStreetMap |
| `UMBLER_SMTP_USER` | Sim, pra enviar e-mail | `contato@felipebranding.com.br` |
| `UMBLER_SMTP_PASS` | Sim, pra enviar e-mail | Senha do e-mail (painel Umbler → Contas de E-mail) |
| `EMAIL_PROSPECCAO_LIMITE_DIARIO` | Não | Padrão 25 |
| `GOOGLE_PLACES_API_KEY` | Não | Não usada por nenhum botão hoje |

SQL pendente (tabelas/colunas) em `SQL_PENDENTE_prospeccao.sql` — rodar no
SQL Editor do Supabase antes de publicar mudanças no schema.

## Limitações honestas

- **Prioridade não é ciência** — proxy razoável (site encontrado ou não),
  não uma previsão confiável de quem vai fechar contrato.
- **Geoapify e OpenStreetMap não têm dado 100% sobreposto** — cada um acha
  o que o outro pode não achar; mesmo os dois juntos podem não achar tudo
  que existe de verdade (cobertura depende de mapeamento voluntário).
- **Limite diário de e-mail** conta só envios feitos pela aba Prospecção —
  não sabe de e-mails mandados por fora (webmail etc.).
- Reenviar pra quem já recebeu não é bloqueado automaticamente.
- Buscas com muitas cidades de uma vez podem demorar 1–2 minutos (Geoapify
  e Overpass rodam em paralelo por cidade, mas cidades são processadas uma
  de cada vez, com pausa entre elas por causa do limite de uso do
  Nominatim).
