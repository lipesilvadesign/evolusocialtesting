// EvoluiSocial — teste das chaves de API (Edge Function "evolui-integracoes").
// Só o proprietário chama. Lê a chave no Vault com a chave de serviço, faz UMA chamada de leitura barata ao provedor
// e devolve apenas "funcionou" ou "não funcionou". O valor da chave NUNCA sai daqui.
import { createClient } from "jsr:@supabase/supabase-js@2";

const ORIGENS = ["https://felipebranding.com.br", "https://www.felipebranding.com.br", "http://localhost:8888", "http://localhost:8765"];
const URL_SB = Deno.env.get("SUPABASE_URL")!;
const adm = createClient(URL_SB, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

function cors(req: Request) {
  const o = req.headers.get("origin") || "";
  return {
    "Access-Control-Allow-Origin": ORIGENS.includes(o) ? o : ORIGENS[0],
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}
const json = (req: Request, body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors(req), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });

// youtube: videoCategories custa 1 ponto de cota (a busca custa 100). A chave vai no cabeçalho, nunca na URL.
// geoapify: só aceita a chave na URL; a URL nunca é registrada.
const TESTADORES: Record<string, { nome: string; url: (k: string) => string; headers: (k: string) => Record<string, string> }> = {
  openai: { nome: "OpenAI", url: () => "https://api.openai.com/v1/models", headers: (k) => ({ Authorization: `Bearer ${k}` }) },
  anthropic: { nome: "Anthropic", url: () => "https://api.anthropic.com/v1/models", headers: (k) => ({ "x-api-key": k, "anthropic-version": "2023-06-01" }) },
  youtube: { nome: "YouTube", url: () => "https://www.googleapis.com/youtube/v3/videoCategories?part=snippet&regionCode=BR", headers: (k) => ({ "X-Goog-Api-Key": k }) },
  geoapify: { nome: "Geoapify", url: (k) => `https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent("Curitiba, PR, Brasil")}&limit=1&format=json&apiKey=${encodeURIComponent(k)}`, headers: () => ({}) },
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  if (req.method !== "POST") return json(req, { erro: "Use POST." }, 405);
  const auth = req.headers.get("Authorization") || "";
  const sb = createClient(URL_SB, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
  const { data: u } = await sb.auth.getUser();
  if (!u?.user) return json(req, { erro: "Entre na sua conta para continuar." }, 401);
  const { data: dono } = await sb.rpc("evolui_eh_owner");
  if (dono !== true) return json(req, { erro: "Só o proprietário da plataforma testa chaves." }, 403);

  let corpo: Record<string, unknown> = {};
  try { corpo = await req.json(); } catch { return json(req, { erro: "Pedido inválido." }, 400); }
  if (corpo.acao !== "testar") return json(req, { erro: "Ação desconhecida." }, 400);
  const chave = String(corpo.chave || "");
  const t = TESTADORES[chave];
  if (!t) return json(req, { erro: "Esta chave não tem teste automático." }, 400);

  const { data: valor } = await adm.rpc("evolui_integracao_ler", { p_chave: chave });
  if (!valor) return json(req, { erro: "Salve a chave antes de testar." }, 400);

  let ok = false, msg = "";
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 9000);
  try {
    const r = await fetch(t.url(String(valor)), { headers: t.headers(String(valor)), signal: ctl.signal });
    if (r.ok) { ok = true; msg = `${t.nome} aceitou a chave.`; }
    else if (r.status === 401 || r.status === 403) msg = `${t.nome} recusou a chave (confira se foi copiada inteira, se está ativa e se não está restrita a sites ou apps).`;
    else if (r.status === 400 && chave === "youtube") msg = "O YouTube não reconheceu a chave. Confira se ela foi copiada inteira e se a YouTube Data API v3 está ativada no projeto.";
    else if (r.status === 429) { ok = true; msg = `${t.nome} aceitou a chave, mas está limitando o uso agora.`; }
    else msg = `${t.nome} respondeu com erro ${r.status}. Tente de novo mais tarde.`;
  } catch { msg = `Não foi possível falar com ${t.nome} agora.`; }
  finally { clearTimeout(timer); }

  await adm.rpc("evolui_integracao_registrar_teste", { p_chave: chave, p_status: ok ? "ok" : "falha", p_msg: msg });
  return json(req, { ok, msg });
});
