// evolui-criar — Format Intelligence (02/10/2026). Transforma UMA ideia em um dos 6 módulos de criação usando o perfil real.
// Isolada da busca (evolui-api): não consome a cota de pesquisas, não usa chave de terceiros e é 100% determinística (sem LLM).
// Segurança: JWT obrigatório; só lê o contexto do próprio usuário (RPC evolui_eie_contexto, que usa auth.uid()); sem service role.
import { createClient } from "jsr:@supabase/supabase-js@2";
import { entender } from "../evolui-api/consulta.ts";
import { prepararEIE, type ContextoBanco } from "../evolui-api/eie/integracao.ts";
import { criarModulo, FI_VERSION, MODULOS, type Modulo } from "../evolui-api/eie/formato.ts";
import { FORMATOS, type FormatoPlano, type HookTipo, planejarConteudo } from "../evolui-api/eie/plano.ts";

const ORIGENS = ["https://felipebranding.com.br", "https://www.felipebranding.com.br", "http://localhost:8888", "http://localhost:8765"];
const cors = (req: Request) => {
  const o = req.headers.get("origin") || "";
  return { "Access-Control-Allow-Origin": ORIGENS.includes(o) ? o : ORIGENS[0], "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Vary": "Origin" };
};
const json = (req: Request, body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors(req), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });

const URL_SB = Deno.env.get("SUPABASE_URL")!;
const janela = new Map<string, number[]>();
function limitado(uid: string, max = 30, ms = 60_000) {
  const agora = Date.now(), l = (janela.get(uid) || []).filter((t) => agora - t < ms);
  if (l.length >= max) { janela.set(uid, l); return true; }
  l.push(agora); janela.set(uid, l);
  if (janela.size > 2000) janela.delete(janela.keys().next().value as string);
  return false;
}
const lim = (x: unknown, n: number) => String(x ?? "").replace(/[<>"{}]/g, "").replace(/\s+/g, " ").trim().slice(0, n);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  if (req.method !== "POST") return json(req, { erro: "Use POST." }, 405);
  const sb = createClient(URL_SB, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") || "" } }, auth: { persistSession: false } });
  const { data: u } = await sb.auth.getUser();
  if (!u?.user) return json(req, { erro: "Entre na sua conta para continuar." }, 401);
  const uid = u.user.id;
  let corpo: Record<string, unknown> = {};
  try { corpo = await req.json(); } catch { return json(req, { erro: "Pedido inválido." }, 400); }
  if (limitado(uid)) return json(req, { erro: "Muitos pedidos em sequência. Aguarde um instante." }, 429);

  // acao "planejar" (Central de Conteúdo): plano completo de UMA ideia. Sem acao, segue o fluxo dos módulos como antes.
  const planejar = String(corpo.acao || "") === "planejar";
  const modulo = (planejar ? "video_curto" : String(corpo.modulo || "")) as Modulo;
  if (!MODULOS.includes(modulo)) return json(req, { erro: "Módulo inválido." }, 400);
  const bi = (corpo.ideia && typeof corpo.ideia === "object" ? corpo.ideia : {}) as Record<string, unknown>;
  const ideia = { titulo: lim(bi.titulo, 140), descricao: lim(bi.descricao, 400) || null, arquetipo: /^[a-z_]{3,20}$/.test(String(bi.arquetipo || "")) ? String(bi.arquetipo) : null, formato: lim(bi.formato, 30) || null };
  if (ideia.titulo.length < 4) return json(req, { erro: "Escolha uma ideia primeiro." }, 400);
  const objChave = /^[a-z0-9_]{2,40}$/.test(String(corpo.objetivo || "")) ? String(corpo.objetivo) : null;
  const termo = lim(corpo.termo, 120);
  const t0 = Date.now();
  try {
    const { data: perfil } = await sb.from("evolui_perfis").select("bloqueado").eq("id", uid).maybeSingle();
    if (perfil?.bloqueado) return json(req, { erro: "Sua conta está em análise pela nossa equipe. Fale com contato@felipebranding.com.br.", bloqueado: true }, 403);
    const [rpc, cat] = await Promise.all([
      sb.rpc("evolui_eie_contexto").then((r: { error: unknown; data: unknown }) => (r.error ? null : (r.data as ContextoBanco)), () => null),
      objChave ? sb.from("evolui_objetivos_catalogo").select("chave,rotulo,intencoes").eq("chave", objChave).eq("ativo", true).maybeSingle().then((r: { data: { chave: string; rotulo: string; intencoes: string[] } | null }) => r.data, () => null) : Promise.resolve(null),
    ]);
    const intencoes = termo ? entender(termo).intencoes.map((i) => i.id) : [];
    const prep = prepararEIE(rpc, intencoes);
    if (planejar) {
      const formato = (FORMATOS as readonly string[]).includes(String(corpo.formato)) ? String(corpo.formato) as FormatoPlano : "reels";
      const HOOKS = ["pergunta", "contraste", "erro_comum", "promessa", "dado", "demonstracao", "historia", "curiosidade", "provocacao"];
      const evitar = (Array.isArray(corpo.evitar_hooks) ? corpo.evitar_hooks : []).map(String).filter((x) => HOOKS.includes(x)).slice(0, 9) as HookTipo[];
      const plano = planejarConteudo({
        ideia, formato, ctx: prep.ctx, hist: prep.historico, seed: `${uid}:${ideia.titulo}:${formato}`,
        objetivo: cat ? { chave: cat.chave, rotulo: cat.rotulo, intencoes: cat.intencoes || [] } : null, intencoes,
        fato: lim(corpo.fato, 240) || null, tema: lim(corpo.tema || termo, 50) || null, evitarHooks: evitar,
      });
      console.log(JSON.stringify({ plano: plano.algorithm_version, formato, hook: plano.hook.tipo, ok: plano.qualidade.ok, ms: Date.now() - t0 }));
      return json(req, plano);
    }
    const variar = corpo.variar === true ? 1 + (Date.now() % 4) : 0;
    const out = criarModulo({ modulo, ideia, ctx: prep.ctx, hist: prep.historico, seed: `${uid}:${ideia.titulo}:${variar}`, objetivo: cat ? { chave: cat.chave, rotulo: cat.rotulo, intencoes: cat.intencoes || [] } : null, intencoes });
    console.log(JSON.stringify({ fi: FI_VERSION, modulo, ok: out.qualidade.ok, fallback: out.qualidade.fallback, tentativas: out.qualidade.tentativas, ms: Date.now() - t0 }));
    return json(req, out);
  } catch (e) {
    console.warn("criar:", String(e));
    return json(req, { erro: "Não foi possível adaptar a ideia agora." }, 500);
  }
});
