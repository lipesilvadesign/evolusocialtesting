// EvoluiSocial — Central de Repertório (Edge Function "evolui-repertorio"). Só administradores.
// O texto entra, o Evolui analisa (sem IA externa), conecta ao que já sabe e registra origem, relações e conflitos.
import { createClient } from "jsr:@supabase/supabase-js@2";
import { montarPayload, analisar, limpa, type Vizinho } from "./analise.ts";
import { normaliza } from "../evolui-api/consulta.ts";

const ORIGENS = ["https://felipebranding.com.br", "https://www.felipebranding.com.br", "http://localhost:8888", "http://localhost:8765"];
const URL_SB = Deno.env.get("SUPABASE_URL")!;
const adm = createClient(URL_SB, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

function cors(req: Request) {
  const o = req.headers.get("origin") || "";
  return { "Access-Control-Allow-Origin": ORIGENS.includes(o) ? o : ORIGENS[0], "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Vary": "Origin" };
}
const json = (req: Request, body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors(req), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });

async function sha256(s: string) {
  const b = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s)));
  return Array.from(b).map((x) => x.toString(16).padStart(2, "0")).join("");
}
const txt = (v: unknown, n: number) => (typeof v === "string" ? v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim().slice(0, n) : "");
const lista = (v: unknown, n: number, m: number) => (Array.isArray(v) ? v.map((x) => txt(x, n)).filter(Boolean).slice(0, m) : []);

/** Remove conceitos e categorias que ficaram sem nenhum conhecimento (a exclusão de um conhecimento já apagou os vínculos). */
async function limpaOrfaos() {
  const [{ data: c }, { data: kc }, { data: cat }, { data: kcat }] = await Promise.all([
    adm.from("evolui_rep_conceitos").select("id").limit(20000),
    adm.from("evolui_rep_conhec_conceito").select("conceito_id").limit(100000),
    adm.from("evolui_rep_categorias").select("id,pai_id").limit(5000),
    adm.from("evolui_rep_conhec_categoria").select("categoria_id").limit(50000),
  ]);
  const usadosC = new Set((kc || []).map((x) => x.conceito_id));
  const orfC = (c || []).map((x) => x.id).filter((id) => !usadosC.has(id));
  for (let i = 0; i < orfC.length; i += 200) await adm.from("evolui_rep_conceitos").delete().in("id", orfC.slice(i, i + 200));
  const usadosCat = new Set((kcat || []).map((x) => x.categoria_id)), pais = new Set((cat || []).map((x) => x.pai_id).filter(Boolean));
  const orfCat = (cat || []).map((x) => x.id).filter((id) => !usadosCat.has(id) && !pais.has(id));
  if (orfCat.length) await adm.from("evolui_rep_categorias").delete().in("id", orfCat);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  if (req.method !== "POST") return json(req, { erro: "Use POST." }, 405);
  const sb = createClient(URL_SB, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") || "" } }, auth: { persistSession: false } });
  const { data: u } = await sb.auth.getUser();
  if (!u?.user) return json(req, { erro: "Entre na sua conta para continuar." }, 401);
  const { data: admin } = await sb.rpc("evolui_eh_admin");
  if (admin !== true) return json(req, { erro: "Só administradores usam a Central de Repertório." }, 403);

  let c: Record<string, unknown> = {};
  try { c = await req.json(); } catch { return json(req, { erro: "Pedido inválido." }, 400); }
  try {
    if (c.acao === "adicionar") {
      const conteudo = limpa(String(c.conteudo || ""));
      if (conteudo.length < 40) return json(req, { erro: "Cole um texto um pouco maior (pelo menos 40 caracteres) para o Evolui conseguir analisar." }, 400);
      const hash = await sha256(normaliza(conteudo));
      const { data: ja } = await adm.from("evolui_rep_conhecimentos").select("id,titulo").eq("conteudo_hash", hash).maybeSingle();
      if (ja) return json(req, { erro: `Este conteúdo já está no repertório ("${ja.titulo}").` }, 409);
      const entrada = { conteudo, titulo: txt(c.titulo, 200), assunto: txt(c.assunto, 120), tags: lista(c.tags, 40, 12) };
      const previa = analisar(entrada);
      const chaves = previa.conceitos.filter((x) => x.tipo === "conceito").map((x) => x.chave);
      const { data: viz } = await adm.rpc("evolui_rep_contexto", { p_chaves: chaves });
      const r = montarPayload({ ...entrada, fonte: txt(c.fonte, 300), autor: txt(c.autor, 150), observacao: txt(c.observacao, 1000), hash, criado_por: u.user.id }, (Array.isArray(viz) ? viz : []) as Vizinho[]);
      const { data: id, error } = await adm.rpc("evolui_rep_gravar", { p: r.payload });
      if (error) { console.error("gravar:", error.message); return json(req, { erro: /duplicate|23505/.test(error.message) ? "Este conteúdo já está no repertório." : "Não foi possível guardar agora. Tente de novo." }, 400); }
      return json(req, { ok: true, id, resumo: r.resumo });
    }
    if (c.acao === "excluir") {
      const id = String(c.id || ""); if (!/^[0-9a-f-]{36}$/i.test(id)) return json(req, { erro: "Identificador inválido." }, 400);
      await adm.from("evolui_rep_insights").delete().contains("conhecimento_ids", [id]); // insights que dependiam dele deixam de ter base
      const { error } = await adm.from("evolui_rep_conhecimentos").delete().eq("id", id);
      if (error) return json(req, { erro: "Não foi possível excluir." }, 400);
      await limpaOrfaos();
      return json(req, { ok: true });
    }
    if (c.acao === "ajustar") {
      const id = String(c.id || ""); if (!/^[0-9a-f-]{36}$/i.test(id)) return json(req, { erro: "Identificador inválido." }, 400);
      const patch: Record<string, unknown> = { atualizado_em: new Date().toISOString() };
      if (typeof c.titulo === "string" && txt(c.titulo, 200)) patch.titulo = txt(c.titulo, 200);
      if ("assunto" in c) patch.assunto = txt(c.assunto, 120) || null;
      if ("observacao" in c) patch.observacao = txt(c.observacao, 1000) || null;
      if ("fonte" in c) patch.fonte = txt(c.fonte, 300) || null;
      if ("tags" in c) patch.tags = [...new Set(lista(c.tags, 40, 12).map((t) => t.toLowerCase()))];
      if ("status" in c && (c.status === "ativo" || c.status === "arquivado")) patch.status = c.status;
      const { error } = await adm.from("evolui_rep_conhecimentos").update(patch).eq("id", id);
      if (error) return json(req, { erro: "Não foi possível salvar." }, 400);
      if (Array.isArray(c.categorias)) {
        await adm.from("evolui_rep_conhec_categoria").delete().eq("conhecimento_id", id);
        for (const rot of lista(c.categorias, 120, 10)) {
          const chave = "admin/" + normaliza(rot).replace(/[^a-z0-9]+/g, "-");
          const { data: cat } = await adm.from("evolui_rep_categorias").upsert({ chave, rotulo: rot }, { onConflict: "chave", ignoreDuplicates: true }).select("id").maybeSingle();
          const catId = cat?.id || (await adm.from("evolui_rep_categorias").select("id").eq("chave", chave).maybeSingle()).data?.id;
          if (catId) await adm.from("evolui_rep_conhec_categoria").upsert({ conhecimento_id: id, categoria_id: catId, origem: "admin" }, { onConflict: "conhecimento_id,categoria_id" });
        }
        await limpaOrfaos();
      }
      return json(req, { ok: true });
    }
    return json(req, { erro: "Ação desconhecida." }, 400);
  } catch (e) {
    console.error("repertorio:", e instanceof Error ? e.message : e);
    return json(req, { erro: "Algo falhou do nosso lado. Tente de novo em instantes." }, 500);
  }
});
