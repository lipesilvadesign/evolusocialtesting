// Central de Repertório — análise determinística (sem IA, sem rede). Funções puras e testáveis.
// Separação de origem: "fonte" = trecho literal do texto; "sistema" = interpretação do Evolui; "derivado" = insight criado cruzando conhecimentos.
import { normaliza, radical, STOP } from "../evolui-api/consulta.ts";

export const REP_VERSAO = "REP-v1";
export type TipoConceito = "conceito" | "assunto" | "aplicacao" | "formato" | "segmento" | "objetivo" | "termo" | "expressao";
export type Conceito = { chave: string; rotulo: string; tipo: TipoConceito; peso: number; origem: "fonte" | "sistema" | "admin" };
export type Relacao = { de: string; para: string; tipo: "coocorre" | "aplica_em" | "serve_para" | "util_para" | "em_formato"; peso: number };
export type Afirmacao = { a: string; b: string; p: 1 | -1; f: string };
export type Categoria = { chave: string; rotulo: string; pai: string | null };
export type Insight = { chave: string; titulo: string; texto: string; conceitos: string[]; conhecimentos: string[] };
export type Conflito = { outro: string; conceito_a: string; conceito_b: string; descricao: string };
export type Entrada = { conteudo: string; titulo?: string; assunto?: string; tags?: string[] };

// ---------------------------------------------------------------- vocabulário controlado
type Voc = { chave: string; rotulo: string; gatilhos: string[]; cats: string[]; funcao?: string };
// gatilhos já normalizados (sem acento); casam por início de palavra
export const VOCAB: Voc[] = [
  { chave: "curiosidade", rotulo: "Curiosidade", gatilhos: ["curiosidade", "curioso", "intriga", "lacuna de informacao"], cats: ["hooks", "comportamento"], funcao: "deixar uma lacuna de informação que só se fecha no fim" },
  { chave: "retencao", rotulo: "Retenção", gatilhos: ["retencao", "reter", "manter a atencao", "assistir ate o fim", "tempo de exibicao"], cats: ["conteudo", "comportamento"], funcao: "dar um motivo para continuar assistindo" },
  { chave: "hook", rotulo: "Hook (gancho)", gatilhos: ["hook", "gancho", "abertura"], cats: ["hooks", "copywriting"], funcao: "prender a atenção nos primeiros segundos" },
  { chave: "abertura rapida", rotulo: "Abertura rápida", gatilhos: ["abertura rapida", "primeiros segundos", "primeiro segundo", "comecar rapido", "ir direto ao ponto"], cats: ["hooks", "conteudo"], funcao: "entrar no assunto nos primeiros segundos" },
  { chave: "pergunta", rotulo: "Pergunta aberta", gatilhos: ["pergunta", "perguntas abertas", "questionar", "enquete"], cats: ["hooks", "comportamento"], funcao: "abrir com uma pergunta que o público quer responder" },
  { chave: "expectativa", rotulo: "Expectativa", gatilhos: ["expectativa", "antecipacao", "suspense"], cats: ["storytelling", "comportamento"], funcao: "criar expectativa do que vem a seguir" },
  { chave: "recompensa", rotulo: "Recompensa", gatilhos: ["recompensa", "pagamento emocional", "entregar o prometido"], cats: ["comportamento", "storytelling"], funcao: "entregar o que foi prometido no começo" },
  { chave: "storytelling", rotulo: "Storytelling", gatilhos: ["storytelling", "narrativa", "contar uma historia", "historia"], cats: ["storytelling", "conteudo"], funcao: "contar uma história com começo, conflito e resolução" },
  { chave: "copywriting", rotulo: "Copywriting", gatilhos: ["copywriting", "copy", "texto persuasivo", "redacao publicitaria"], cats: ["copywriting"], funcao: "escrever para levar a pessoa a uma ação" },
  { chave: "titulo", rotulo: "Títulos", gatilhos: ["titulo", "headline", "manchete"], cats: ["copywriting", "hooks"], funcao: "resumir a promessa em uma linha" },
  { chave: "chamada para acao", rotulo: "Chamada para ação", gatilhos: ["chamada para acao", "cta", "call to action", "convite final"], cats: ["copywriting", "vendas"], funcao: "dizer com clareza qual é o próximo passo" },
  { chave: "prova social", rotulo: "Prova social", gatilhos: ["prova social", "depoimento", "avaliacao de cliente", "resultado de cliente"], cats: ["vendas", "comportamento"], funcao: "mostrar o resultado de outras pessoas" },
  { chave: "autoridade", rotulo: "Autoridade", gatilhos: ["autoridade", "credibilidade", "especialista", "referencia no assunto"], cats: ["marca", "comportamento"], funcao: "demonstrar que você entende do assunto" },
  { chave: "confianca", rotulo: "Confiança", gatilhos: ["confianca", "transparencia", "honestidade"], cats: ["marca", "comportamento"], funcao: "mostrar bastidores e fatos reais" },
  { chave: "urgencia", rotulo: "Urgência", gatilhos: ["urgencia", "escassez", "prazo", "ultimas unidades", "tempo limitado"], cats: ["vendas", "comportamento"], funcao: "dar um prazo real e verdadeiro" },
  { chave: "emocao", rotulo: "Emoção", gatilhos: ["emocao", "emocional", "sentimento", "empatia"], cats: ["comportamento", "storytelling"], funcao: "ligar o conteúdo a um sentimento real" },
  { chave: "atencao", rotulo: "Atenção", gatilhos: ["atencao", "distracao", "foco do publico"], cats: ["comportamento"], funcao: "ganhar e manter a atenção" },
  { chave: "engajamento", rotulo: "Engajamento", gatilhos: ["engajamento", "interacao", "participacao", "comentarios", "compartilhamento"], cats: ["redes sociais", "conteudo"], funcao: "convidar a pessoa a participar" },
  { chave: "alcance", rotulo: "Alcance", gatilhos: ["alcance", "viralizar", "viral", "distribuicao", "visualizacoes"], cats: ["redes sociais"], funcao: "ser entregue a mais pessoas" },
  { chave: "algoritmo", rotulo: "Algoritmo", gatilhos: ["algoritmo", "recomendacao da plataforma"], cats: ["redes sociais"] },
  { chave: "constancia", rotulo: "Constância", gatilhos: ["constancia", "consistencia", "frequencia de postagem", "rotina de postagem"], cats: ["conteudo"], funcao: "manter uma frequência possível de sustentar" },
  { chave: "publico", rotulo: "Público-alvo", gatilhos: ["publico alvo", "audiencia", "persona", "cliente ideal", "nicho"], cats: ["marca", "comportamento"], funcao: "falar com uma pessoa específica" },
  { chave: "dor do cliente", rotulo: "Dor do cliente", gatilhos: ["dor do cliente", "problema do cliente", "dificuldade do publico", "dor"], cats: ["vendas", "copywriting"], funcao: "começar pelo problema real do cliente" },
  { chave: "oferta", rotulo: "Oferta", gatilhos: ["oferta", "proposta de valor", "promocao", "desconto"], cats: ["vendas"], funcao: "deixar claro o que a pessoa recebe" },
  { chave: "conversao", rotulo: "Conversão", gatilhos: ["conversao", "converter", "fechar venda", "funil"], cats: ["vendas"] },
  { chave: "branding", rotulo: "Marca", gatilhos: ["branding", "identidade visual", "posicionamento", "marca pessoal"], cats: ["marca"] },
  { chave: "tendencia", rotulo: "Tendência", gatilhos: ["tendencia", "trend", "em alta", "assunto do momento"], cats: ["conteudo", "redes sociais"] },
  { chave: "bastidores", rotulo: "Bastidores", gatilhos: ["bastidores", "por tras", "processo de producao"], cats: ["conteudo", "storytelling"], funcao: "mostrar como o trabalho acontece" },
  { chave: "humor", rotulo: "Humor", gatilhos: ["humor", "piada", "comedia", "meme"], cats: ["conteudo", "comportamento"] },
  { chave: "contraste", rotulo: "Contraste", gatilhos: ["contraste", "antes e depois", "quebra de padrao", "contraria o senso comum"], cats: ["hooks", "storytelling"], funcao: "contrariar o que o público espera" },
  { chave: "legenda", rotulo: "Legenda", gatilhos: ["legenda", "descricao do post"], cats: ["copywriting", "conteudo"] },
  { chave: "roteiro", rotulo: "Roteiro", gatilhos: ["roteiro", "script"], cats: ["conteudo", "storytelling"] },
  { chave: "comportamento", rotulo: "Comportamento da audiência", gatilhos: ["comportamento", "psicologia", "vies", "decisao de compra"], cats: ["comportamento"] },
];
const CAT_ROTULO: Record<string, string> = { conteudo: "Conteúdo", copywriting: "Copywriting", hooks: "Hooks", storytelling: "Storytelling", comportamento: "Comportamento", "redes sociais": "Redes sociais", vendas: "Vendas", marca: "Marca" };

const FORMATOS: { chave: string; rotulo: string; tipo: TipoConceito; gatilhos: string[] }[] = [
  { chave: "reels", rotulo: "Vídeo curto (Reels/TikTok/Shorts)", tipo: "formato", gatilhos: ["reels", "reel", "tiktok", "shorts", "video curto", "videos curtos"] },
  { chave: "carrossel", rotulo: "Carrossel", tipo: "formato", gatilhos: ["carrossel", "carrosseis"] },
  { chave: "stories", rotulo: "Stories", tipo: "formato", gatilhos: ["stories", "story"] },
  { chave: "foto", rotulo: "Foto", tipo: "formato", gatilhos: ["foto", "fotografia", "imagem"] },
  { chave: "live", rotulo: "Live", tipo: "formato", gatilhos: ["live", "ao vivo"] },
  { chave: "titulo", rotulo: "Títulos", tipo: "aplicacao", gatilhos: ["titulo", "headline", "manchete"] },
  { chave: "hook", rotulo: "Hooks", tipo: "aplicacao", gatilhos: ["hook", "gancho"] },
  { chave: "legenda", rotulo: "Legendas", tipo: "aplicacao", gatilhos: ["legenda"] },
  { chave: "roteiro", rotulo: "Roteiros", tipo: "aplicacao", gatilhos: ["roteiro"] },
  { chave: "bio", rotulo: "Bio", tipo: "aplicacao", gatilhos: ["biografia", "bio do", "bio da", "sua bio"] },
];
const SEGMENTOS: { chave: string; rotulo: string; gatilhos: string[] }[] = [
  { chave: "doces", rotulo: "Doces e confeitaria", gatilhos: ["confeitaria", "doceria", "brigadeiro", "bolo", "doces"] },
  { chave: "alimentacao", rotulo: "Alimentação", gatilhos: ["restaurante", "lanchonete", "hamburguer", "delivery", "gastronomia", "cardapio"] },
  { chave: "beleza", rotulo: "Beleza e estética", gatilhos: ["salao", "estetica", "cabeleireiro", "maquiagem", "manicure"] },
  { chave: "moda", rotulo: "Moda", gatilhos: ["loja de roupa", "lojas de roupa", "moda", "vestuario", "boutique", "roupas"] },
  { chave: "saude", rotulo: "Saúde", gatilhos: ["clinica", "dentista", "nutricionista", "psicologo", "saude"] },
  { chave: "fitness", rotulo: "Fitness", gatilhos: ["academia", "personal trainer", "treino", "pilates"] },
  { chave: "pet", rotulo: "Pet", gatilhos: ["petshop", "pet shop", "veterinario", "banho e tosa"] },
  { chave: "casa", rotulo: "Casa e decoração", gatilhos: ["decoracao", "movel", "moveis", "arquitetura de interiores"] },
  { chave: "educacao", rotulo: "Educação", gatilhos: ["curso online", "escola", "professor", "aulas"] },
  { chave: "servicos", rotulo: "Serviços profissionais", gatilhos: ["advogado", "contador", "consultoria", "imobiliaria"] },
  { chave: "criador", rotulo: "Criador de conteúdo", gatilhos: ["criador de conteudo", "influenciador", "marca pessoal"] },
];
const OBJETIVOS: { chave: string; rotulo: string; gatilhos: string[] }[] = [
  { chave: "seguidores", rotulo: "Ganhar seguidores", gatilhos: ["seguidores", "crescer perfil", "crescimento do perfil"] },
  { chave: "alcance", rotulo: "Aumentar o alcance", gatilhos: ["alcance", "viral", "algoritmo", "retencao"] },
  { chave: "engajamento", rotulo: "Engajar", gatilhos: ["engajamento", "comentarios", "participacao", "interacao"] },
  { chave: "vendas", rotulo: "Vender mais", gatilhos: ["vender", "vendas", "conversao", "cliente", "compra"] },
  { chave: "autoridade", rotulo: "Passar confiança", gatilhos: ["autoridade", "confianca", "credibilidade"] },
  { chave: "ideias", rotulo: "Ideias de conteúdo", gatilhos: ["ideias de conteudo", "criatividade", "inspiracao"] },
  { chave: "planejamento", rotulo: "Planejar", gatilhos: ["calendario", "consistencia", "constancia", "planejamento"] },
  { chave: "tendencias", rotulo: "Tendências", gatilhos: ["tendencia", "em alta"] },
];
const SITUACOES: [string, RegExp][] = [
  ["lançamento", /lan[cç]amento|novidade|estreia/i], ["promoção", /promo[cç][aã]o|desconto|oferta/i],
  ["datas comemorativas", /dia das m[aã]es|natal|p[aá]scoa|black friday|datas comemorativas/i], ["começar do zero", /do zero|iniciante|perfil novo/i],
  ["atendimento ao cliente", /atendimento|p[oó]s-venda|sac\b/i], ["vídeo curto", /v[ií]deos? curtos?|reels|shorts|tiktok/i],
];

// ---------------------------------------------------------------- texto
const MAX_CHARS = 60000;
export function limpa(t: string): string { return String(t || "").replace(/\r/g, "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim().slice(0, MAX_CHARS); }
export function frases(t: string): string[] {
  return limpa(t).split(/(?<=[.!?…])\s+|\n+/).map((s) => s.trim()).filter((s) => s.length >= 12);
}
const cont = (hay: string, g: string) => { let n = 0, i = hay.indexOf(" " + g); while (i >= 0) { n++; i = hay.indexOf(" " + g, i + 1); } return n; };
const pad = (s: string) => " " + normaliza(s) + " ";
const corta = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1).trim() + "…" : s);

// ---------------------------------------------------------------- extração
export function extrairConceitos(texto: string, titulo: string, tags: string[] = []): Conceito[] {
  const norm = pad(texto), tit = pad(titulo + " " + tags.join(" "));
  const out: Conceito[] = [];
  for (const v of VOCAB) {
    const n = v.gatilhos.reduce((a, g) => a + cont(norm, g), 0);
    const nt = v.gatilhos.reduce((a, g) => a + cont(tit, g), 0);
    if (n + nt === 0) continue;
    out.push({ chave: v.chave, rotulo: v.rotulo, tipo: "conceito", peso: Math.round((1 + Math.log(1 + n) + (nt ? 1 : 0)) * 100) / 100, origem: "sistema" });
  }
  for (const f of FORMATOS) {
    const n = f.gatilhos.reduce((a, g) => a + cont(norm, g), 0);
    if (n) out.push({ chave: f.chave === "hook" || f.chave === "titulo" || f.chave === "legenda" ? "aplic:" + f.chave : f.chave, rotulo: f.rotulo, tipo: f.tipo, peso: Math.round((1 + Math.log(1 + n)) * 100) / 100, origem: "sistema" });
  }
  for (const s of SEGMENTOS) { const n = s.gatilhos.reduce((a, g) => a + cont(norm, g), 0); if (n) out.push({ chave: s.chave, rotulo: s.rotulo, tipo: "segmento", peso: 1 + Math.log(1 + n), origem: "sistema" }); }
  for (const o of OBJETIVOS) { const n = o.gatilhos.reduce((a, g) => a + cont(norm, g), 0); if (n) out.push({ chave: o.chave, rotulo: o.rotulo, tipo: "objetivo", peso: 1 + Math.log(1 + n), origem: "sistema" }); }
  // termos livres e expressões frequentes (vocabulário do texto)
  const toks = normaliza(texto).split(" ").filter(Boolean);
  const freq = new Map<string, { n: number; forma: Map<string, number> }>();
  const orig = limpa(texto).split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  const ign = new Set(VOCAB.flatMap((v) => v.gatilhos.flatMap((g) => g.split(" "))).map(radical));
  orig.forEach((w) => {
    const k = normaliza(w); if (k.length < 5 || STOP.has(k) || /^\d+$/.test(k)) return;
    const r = radical(k); if (ign.has(r)) return;
    const e = freq.get(r) || { n: 0, forma: new Map() }; e.n++; e.forma.set(w.toLowerCase(), (e.forma.get(w.toLowerCase()) || 0) + 1); freq.set(r, e);
  });
  [...freq.entries()].filter(([, e]) => e.n >= 2).sort((a, b) => b[1].n - a[1].n).slice(0, 12).forEach(([r, e]) => {
    const forma = [...e.forma.entries()].sort((a, b) => b[1] - a[1])[0][0];
    out.push({ chave: "termo:" + r, rotulo: forma, tipo: "termo", peso: Math.round(Math.log(1 + e.n) * 100) / 100, origem: "fonte" });
  });
  const bi = new Map<string, number>(), biOrig = new Map<string, string>();
  for (let i = 0; i < orig.length - 1; i++) {
    const a = normaliza(orig[i]), b = normaliza(orig[i + 1]);
    if (a.length < 4 || b.length < 4 || STOP.has(a) || STOP.has(b) || /^\d+$/.test(a + b)) continue;
    const k = radical(a) + " " + radical(b); bi.set(k, (bi.get(k) || 0) + 1); if (!biOrig.has(k)) biOrig.set(k, (orig[i] + " " + orig[i + 1]).toLowerCase());
  }
  [...bi.entries()].filter(([, n]) => n >= 2).sort((a, b) => b[1] - a[1]).slice(0, 8).forEach(([k, n]) => out.push({ chave: "expr:" + k, rotulo: biOrig.get(k) as string, tipo: "expressao", peso: Math.round(Math.log(1 + n) * 100) / 100, origem: "fonte" }));
  void toks;
  return out;
}

const POS = ["aument", "melhor", "elev", "ajud", "ampli", "favorec", "impuls", "ger", "cri", "fortalec", "estimul", "potencializ"];
const NEG = ["reduz", "diminu", "prejudic", "pior", "derrub", "enfraquec", "limit", "imped", "afast", "matam", "mata"];
export function afirmacoes(texto: string, conceitos: Conceito[]): Afirmacao[] {
  const vocab = VOCAB.filter((v) => conceitos.some((c) => c.chave === v.chave));
  const out: Afirmacao[] = [];
  for (const f of frases(texto)) {
    const n = pad(f), ws = n.trim().split(" ");
    const pos = vocab.map((v) => ({ v, i: Math.min(...v.gatilhos.map((g) => { const k = n.indexOf(" " + g); return k < 0 ? 1e9 : n.slice(0, k).trim().split(" ").filter(Boolean).length; })) })).filter((x) => x.i < 1e9).sort((a, b) => a.i - b.i);
    if (pos.length < 2) continue;
    const vi = ws.findIndex((w) => POS.some((p) => w.startsWith(p)) || NEG.some((p) => w.startsWith(p)));
    if (vi < 0) continue;
    const antes = pos.filter((x) => x.i < vi), depois = pos.filter((x) => x.i > vi);
    if (!antes.length || !depois.length) continue;
    let p: 1 | -1 = NEG.some((q) => ws[vi].startsWith(q)) ? -1 : 1;
    if (ws.slice(Math.max(0, vi - 3), vi).some((w) => w === "nao" || w === "nunca")) p = (p * -1) as 1 | -1;
    out.push({ a: antes[antes.length - 1].v.chave, b: depois[0].v.chave, p, f: corta(f, 160) });
    if (out.length >= 12) break;
  }
  return out;
}

export function detectarConflitos(novas: Afirmacao[], outros: { id: string; titulo: string; afirmacoes: Afirmacao[] }[]): Conflito[] {
  const r: Conflito[] = [], vistos = new Set<string>();
  for (const n of novas) for (const o of outros) for (const x of o.afirmacoes || []) {
    if (x.a === n.a && x.b === n.b && x.p !== n.p && !vistos.has(o.id + n.a + n.b)) {
      vistos.add(o.id + n.a + n.b);
      r.push({ outro: o.id, conceito_a: n.a, conceito_b: n.b, descricao: `Este texto diz que «${n.a}» ${n.p === 1 ? "favorece" : "prejudica"} «${n.b}»; «${o.titulo}» diz o oposto. As duas fontes foram mantidas.` });
    }
  }
  return r;
}

function linguagem(texto: string) {
  const fs = frases(texto), ls = limpa(texto).split("\n").map((l) => l.trim()).filter(Boolean);
  const titulos: { tipo: string; estrutura: string; exemplo: string }[] = [];
  for (const l of ls.filter((x) => x.length <= 90 && !/[.]$/.test(x)).slice(0, 25)) {
    const n = normaliza(l);
    let tipo = "", estrutura = "";
    if (/^como /.test(n)) { tipo = "como"; estrutura = "Como {fazer algo} {com resultado}"; }
    else if (/^por que |^porque /.test(n)) { tipo = "porque"; estrutura = "Por que {tema} {afirmação inesperada}?"; }
    else if (/^\d+ /.test(n)) { tipo = "lista"; estrutura = "{N} {coisas} sobre {tema}"; }
    else if (/\?$/.test(l)) { tipo = "pergunta"; estrutura = "{Pergunta que o público quer responder}?"; }
    else if (/^(o segredo|o erro|a verdade|o que )/.test(n)) { tipo = "revelacao"; estrutura = "{O segredo/erro} de {tema}"; }
    if (tipo && !titulos.some((t) => t.tipo === tipo)) titulos.push({ tipo, estrutura, exemplo: corta(l, 90) });
  }
  const paras = limpa(texto).split(/\n{2,}/).map((p) => frases(p)[0]).filter(Boolean) as string[];
  const aberturas: { tipo: string; estrutura: string; exemplo: string }[] = [];
  for (const s of [fs[0], ...paras].filter(Boolean).slice(0, 12)) {
    const n = normaliza(s); let tipo = "", estrutura = "";
    if (/\?$/.test(s)) { tipo = "pergunta"; estrutura = "Pergunta direta ao público"; }
    else if (/(nunca|ninguem|todo mundo|sempre|quase ninguem)/.test(n)) { tipo = "afirmacao forte"; estrutura = "Afirmação forte que contraria o esperado"; }
    else if (/^\d|\b\d+ ?%/.test(n)) { tipo = "dado"; estrutura = "Abrir com um número ou dado"; }
    else if (/(imagine|era uma vez|quando eu|um dia)/.test(n)) { tipo = "historia"; estrutura = "Abrir com uma cena ou história"; }
    else if (/^(mas|porem|so que)/.test(n)) { tipo = "contraste"; estrutura = "Abrir com um contraste"; }
    if (tipo && !aberturas.some((a) => a.tipo === tipo)) aberturas.push({ tipo, estrutura, exemplo: corta(s, 100) });
  }
  const ctas = fs.filter((s) => /^(salve|comente|compartilhe|siga|clique|aproveite|envie|chame|peca|garanta|acesse|baixe|responda|marque|conte|experimente|teste)\b/.test(normaliza(s))).slice(0, 6).map((s) => ({ texto: corta(s, 100), verbo: normaliza(s).split(" ")[0] }));
  return { padroes_titulo: titulos, aberturas, ctas };
}

export type Analise = ReturnType<typeof analisar>["analise"];
export function analisar(e: Entrada) {
  const texto = limpa(e.conteudo), tags = (e.tags || []).map((t) => t.trim()).filter(Boolean);
  const fs = frases(texto);
  const titulo = (e.titulo || "").trim() || corta(fs[0] || texto.slice(0, 80), 80);
  const conceitos = extrairConceitos(texto, titulo + " " + (e.assunto || ""), tags);
  // o que o administrador informou também vira conhecimento (origem admin)
  for (const t of tags) { const k = "tag:" + normaliza(t); if (k.length > 5) conceitos.push({ chave: k, rotulo: t, tipo: "termo", peso: 1.5, origem: "admin" }); }
  const cs = conceitos.filter((c) => c.tipo === "conceito").sort((a, b) => b.peso - a.peso);
  const assunto = (e.assunto || "").trim() || cs[0]?.rotulo || "Geral";
  if (e.assunto && normaliza(e.assunto).length >= 3) conceitos.push({ chave: "assunto:" + normaliza(e.assunto), rotulo: e.assunto.trim(), tipo: "assunto", peso: 2, origem: "admin" });
  else if (cs[0]) conceitos.push({ chave: "assunto:" + cs[0].chave, rotulo: cs[0].rotulo, tipo: "assunto", peso: 1.5, origem: "sistema" });

  // relações
  const rel = new Map<string, Relacao>();
  const add = (de: string, para: string, tipo: Relacao["tipo"], peso: number) => {
    if (de === para) return; const k = `${de}|${para}|${tipo}`; const r = rel.get(k);
    if (r) r.peso = Math.min(8, Math.round((r.peso + peso) * 100) / 100); else rel.set(k, { de, para, tipo, peso });
  };
  const top = cs.slice(0, 14);
  const fn = fs.map(pad);
  fn.forEach((f, i) => {
    const nesta = (top.map((c) => ({ c, v: VOCAB.find((v) => v.chave === c.chave) as Voc })).filter((x) => x.v.gatilhos.some((g) => f.includes(" " + g)) || (fn[i + 1] || "").length < 0)).map((x) => x.c.chave);
    for (let a = 0; a < nesta.length; a++) for (let b = a + 1; b < nesta.length; b++) { add(nesta[a], nesta[b], "coocorre", 1); }
    const fmts = conceitos.filter((c) => c.tipo === "formato" || c.tipo === "aplicacao").filter((c) => (FORMATOS.find((x) => (x.chave === "hook" || x.chave === "titulo" || x.chave === "legenda" ? "aplic:" + x.chave : x.chave) === c.chave)?.gatilhos || []).some((g) => f.includes(" " + g)));
    for (const c of nesta) for (const fm of fmts) add(c, fm.chave, "aplica_em", 1);
  });
  for (const c of top.slice(0, 6)) {
    for (const fm of conceitos.filter((x) => x.tipo === "formato" || x.tipo === "aplicacao")) add(c.chave, fm.chave, "em_formato", 0.5);
    for (const sg of conceitos.filter((x) => x.tipo === "segmento")) add(c.chave, sg.chave, "util_para", 0.5);
    for (const ob of conceitos.filter((x) => x.tipo === "objetivo")) add(c.chave, ob.chave, "serve_para", 0.5);
  }
  const ass = conceitos.find((c) => c.tipo === "assunto");
  if (ass) for (const c of top.slice(0, 8)) if (c.chave !== ass.chave.replace(/^assunto:/, "")) add(ass.chave, c.chave, "coocorre", 1);

  // categorias (rede: um conhecimento pertence a vários grupos)
  const catSet = new Set<string>();
  for (const c of top) VOCAB.find((v) => v.chave === c.chave)?.cats.forEach((x) => catSet.add(x));
  if (conceitos.some((c) => c.tipo === "formato" && c.chave === "reels")) catSet.add("redes sociais");
  const categorias: Categoria[] = [{ chave: "marketing", rotulo: "Marketing", pai: null }, ...[...catSet].map((c) => ({ chave: "marketing/" + c, rotulo: CAT_ROTULO[c] || c, pai: "marketing" }))];

  const ideias = fs.map((s, i) => {
    const n = pad(s); const dens = top.reduce((a, c) => a + (VOCAB.find((v) => v.chave === c.chave)?.gatilhos.some((g) => n.includes(" " + g)) ? c.peso : 0), 0);
    return { s, i, score: dens / Math.max(8, s.split(" ").length) };
  }).filter((x) => x.score > 0).sort((a, b) => b.score - a.score).slice(0, 3).sort((a, b) => a.i - b.i).map((x) => ({ texto: corta(x.s, 220), origem: "fonte" as const }));
  const argumentos = fs.filter((s) => /\b(porque|pois|portanto|por isso|ou seja|isso significa|logo)\b/i.test(s)).slice(0, 5).map((s) => ({ texto: corta(s, 220), origem: "fonte" as const }));
  const exemplos = fs.filter((s) => /\b(por exemplo|exemplo|como em|imagine|suponha)\b/i.test(s)).slice(0, 4).map((s) => ({ texto: corta(s, 220), origem: "fonte" as const }));
  const aplicacoes = conceitos.filter((c) => c.tipo === "formato" || c.tipo === "aplicacao").map((c) => c.rotulo);
  const afirm = afirmacoes(texto, conceitos);
  const analise = {
    versao: REP_VERSAO, metodo: "heuristico-v1", rotulo_origem: "Interpretação do sistema (os trechos marcados como fonte são literais)",
    assunto_principal: assunto,
    subassuntos: cs.slice(1, 6).map((c) => c.rotulo),
    ideias_principais: ideias, argumentos, exemplos, aplicacoes,
    linguagem: { termos: conceitos.filter((c) => c.tipo === "termo").slice(0, 10).map((c) => c.rotulo), expressoes: conceitos.filter((c) => c.tipo === "expressao").map((c) => c.rotulo), ...linguagem(texto) },
    contexto: {
      segmentos: conceitos.filter((c) => c.tipo === "segmento").map((c) => c.rotulo).concat(conceitos.some((c) => c.tipo === "segmento") ? [] : ["Geral (sem segmento específico)"]),
      situacoes: SITUACOES.filter(([, re]) => re.test(texto)).map(([n]) => n),
      tipos_conteudo: aplicacoes,
      objetivos: conceitos.filter((c) => c.tipo === "objetivo").map((c) => c.rotulo),
    },
    afirmacoes: afirm,
  };
  return { titulo, conceitos, relacoes: [...rel.values()], categorias, analise, afirmacoes: afirm };
}

// ---------------------------------------------------------------- insights derivados (conhecimento existente + novo = novas relações)
export type Vizinho = { id: string; titulo: string; conceitos: { chave: string; rotulo: string; tipo: string; peso: number }[]; afirmacoes?: Afirmacao[] };
const funcaoDe = (chave: string) => VOCAB.find((v) => v.chave === chave)?.funcao;
export function derivar(novo: { titulo: string; conceitos: Conceito[] }, vizinhos: Vizinho[], max = 4): Insight[] {
  const meus = novo.conceitos.filter((c) => c.tipo === "conceito").sort((a, b) => b.peso - a.peso).slice(0, 8);
  const meusK = new Set(meus.map((c) => c.chave));
  type Cand = { a: Conceito; b: { chave: string; rotulo: string; peso: number }; ponte: string; viz: Vizinho; score: number };
  const cands: Cand[] = [];
  for (const v of vizinhos) {
    const dele = v.conceitos.filter((c) => c.tipo === "conceito").slice(0, 8);
    const ponte = dele.find((c) => meusK.has(c.chave));
    if (!ponte) continue;
    for (const b of dele.filter((c) => !meusK.has(c.chave) && funcaoDe(c.chave))) {
      const a = meus.find((c) => c.chave !== ponte.chave && funcaoDe(c.chave)) || meus.find((c) => funcaoDe(c.chave));
      if (!a) continue;
      cands.push({ a, b, ponte: ponte.rotulo, viz: v, score: a.peso * b.peso });
    }
  }
  cands.sort((x, y) => y.score - x.score);
  const out: Insight[] = [], usados = new Set<string>();
  for (const c of cands) {
    // tripla (crescimento progressivo): se outro vizinho acrescenta uma terceira ideia ao mesmo par
    const terceiro = cands.find((d) => d !== c && d.a.chave === c.a.chave && d.viz.id !== c.viz.id && d.b.chave !== c.b.chave);
    const chaves = [c.a.chave, c.b.chave, ...(terceiro ? [terceiro.b.chave] : [])].sort();
    const chave = "ins:" + chaves.join("|");
    if (usados.has(chave)) continue; usados.add(chave);
    const partes = [c.a.chave, c.b.chave, ...(terceiro ? [terceiro.b.chave] : [])];
    const fs = partes.map((p) => funcaoDe(p)).filter(Boolean);
    const rot = [c.a.rotulo, c.b.rotulo, ...(terceiro ? [terceiro.b.rotulo] : [])];
    out.push({
      chave, titulo: rot.join(" + "),
      texto: `Hipótese derivada pelo Evolui (não está em nenhuma fonte): combinar ${rot.map((r) => `«${r}»`).join(" + ")}. Estrutura sugerida: ${fs.join("; ")}. Origem: «${c.a.rotulo}» vem de "${corta(novo.titulo, 60)}", «${c.b.rotulo}» vem de "${corta(c.viz.titulo, 60)}", ligados por «${c.ponte}». Teste antes de tratar como regra.`,
      conceitos: partes, conhecimentos: ["NOVO", c.viz.id, ...(terceiro ? [terceiro.viz.id] : [])],
    });
    if (out.length >= max) break;
  }
  return out;
}

export function montarPayload(e: Entrada & { fonte?: string; autor?: string; observacao?: string; hash: string; criado_por?: string }, vizinhos: Vizinho[]) {
  const a = analisar(e);
  const insights = derivar({ titulo: a.titulo, conceitos: a.conceitos }, vizinhos);
  const conflitos = detectarConflitos(a.afirmacoes, vizinhos.map((v) => ({ id: v.id, titulo: v.titulo, afirmacoes: v.afirmacoes || [] })));
  return {
    resumo: { titulo: a.titulo, conceitos: a.conceitos.length, relacoes: a.relacoes.length, categorias: a.categorias.length - 1, insights: insights.length, conflitos: conflitos.length },
    payload: {
      conhecimento: { titulo: a.titulo, fonte: e.fonte || null, autor: e.autor || null, assunto: e.assunto || a.analise.assunto_principal, tags: e.tags || [], observacao: e.observacao || null, conteudo: limpa(e.conteudo), hash: e.hash, analise: a.analise, criado_por: e.criado_por || null },
      conceitos: a.conceitos, relacoes: a.relacoes, categorias: a.categorias, insights, conflitos,
    },
  };
}
