// EvoluiSocial — pagamentos (Supabase Edge Function "evolui-pagamentos")
// Mercado Pago Checkout Pro. Cartão, Pix e boleto ficam 100% no Mercado Pago:
// aqui NUNCA passa número de cartão. Guardamos só status, valor, taxa e método.
//
// Segredos (Supabase › Edge Functions › Secrets), nunca no código:
//   MP_ACCESS_TOKEN    token de produção da SUA conta Mercado Pago (é nela que o dinheiro cai)
//   MP_WEBHOOK_SECRET  "assinatura secreta" das notificações (Mercado Pago › Suas integrações › Webhooks)
//
// Ações:
//   POST { acao: "checkout", plano: "pro"|"master", ciclo: "mensal"|"anual" }  (usuário logado)
//   POST ?origem=mp  (notificação do Mercado Pago; conferimos tudo direto na API deles)
import { createClient } from "jsr:@supabase/supabase-js@2";

const URL_SB = Deno.env.get("SUPABASE_URL")!;
const SERVICO = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const MP_TOKEN = Deno.env.get("MP_ACCESS_TOKEN") || "";
const MP_SEGREDO = Deno.env.get("MP_WEBHOOK_SECRET") || "";
const SITE = "https://felipebranding.com.br";
const ORIGENS = ["https://felipebranding.com.br", "https://www.felipebranding.com.br", "http://localhost:8765"];
const adm = createClient(URL_SB, SERVICO, { auth: { persistSession: false } });

function cors(req: Request) {
  const o = req.headers.get("origin") || "";
  return {
    "Access-Control-Allow-Origin": ORIGENS.includes(o) ? o : ORIGENS[0],
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}
const json = (req: Request, body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors(req), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });

const NOME: Record<string, string> = { pro: "Pro", master: "Master" };
const STATUS: Record<string, string> = {
  approved: "aprovado", authorized: "em_analise", pending: "pendente", in_process: "em_analise", in_mediation: "em_analise",
  rejected: "recusado", cancelled: "cancelado", refunded: "reembolsado", charged_back: "estornado",
};
function metodo(tipo: string): string {
  if (tipo === "credit_card" || tipo === "debit_card" || tipo === "prepaid_card") return "cartao";
  if (tipo === "bank_transfer") return "pix";
  if (tipo === "ticket") return "boleto";
  return "outro";
}

async function precos() {
  const { data } = await adm.from("evolui_config").select("chave,valor").in("chave", ["precos", "pagamento_ativo"]);
  const m = new Map((data || []).map((x: { chave: string; valor: unknown }) => [x.chave, x.valor]));
  return { tabela: (m.get("precos") || {}) as Record<string, Record<string, number>>, ativo: m.get("pagamento_ativo") === true };
}

async function hmacHex(segredo: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(segredo), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const s = new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg)));
  return Array.from(s).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function iguais(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

async function checkout(req: Request, corpo: Record<string, unknown>) {
  const auth = req.headers.get("Authorization") || "";
  const sb = createClient(URL_SB, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
  const { data: u } = await sb.auth.getUser();
  if (!u?.user) return json(req, { erro: "Entre na sua conta para continuar." }, 401);
  const plano = String(corpo.plano || ""), ciclo = String(corpo.ciclo || "");
  if (!["pro", "master"].includes(plano) || !["mensal", "anual"].includes(ciclo)) return json(req, { erro: "Plano inválido." }, 400);
  const { tabela, ativo } = await precos();
  if (!MP_TOKEN || !ativo) return json(req, { erro: "O pagamento online está sendo ativado. Fale com a gente pelo contato@felipebranding.com.br que liberamos seu plano.", inativo: true }, 503);
  const centavos = Number(tabela?.[plano]?.[ciclo]);
  if (!Number.isFinite(centavos) || centavos < 100) return json(req, { erro: "Preço não configurado." }, 503);

  const ref = `${u.user.id}|${plano}|${ciclo}|${crypto.randomUUID()}`;
  const r = await fetch("https://api.mercadopago.com/checkout/preferences", {
    method: "POST",
    headers: { "Authorization": `Bearer ${MP_TOKEN}`, "Content-Type": "application/json", "X-Idempotency-Key": ref },
    body: JSON.stringify({
      items: [{ id: `evolui-${plano}-${ciclo}`, title: `EvoluiSocial ${NOME[plano]} (${ciclo})`, quantity: 1, unit_price: centavos / 100, currency_id: "BRL" }],
      payer: { email: u.user.email },
      external_reference: ref,
      notification_url: `${URL_SB}/functions/v1/evolui-pagamentos?origem=mp`,
      back_urls: {
        success: `${SITE}/evoluisocial/app/?pagamento=ok#perfil`,
        pending: `${SITE}/evoluisocial/app/?pagamento=pendente#perfil`,
        failure: `${SITE}/evoluisocial/app/?pagamento=falhou#perfil`,
      },
      auto_return: "approved",
      statement_descriptor: "EVOLUISOCIAL",
    }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.init_point) { console.error("mp preference", r.status, JSON.stringify(j).slice(0, 300)); return json(req, { erro: "Não conseguimos abrir o pagamento agora. Tente de novo em instantes." }, 502); }
  await adm.from("evolui_eventos").insert({ user_id: u.user.id, tipo: "plano_interesse", dados: { plano, ciclo, etapa: "checkout" } });
  return json(req, { url: j.init_point });
}

async function webhook(req: Request, url: URL) {
  let corpo: Record<string, unknown> = {};
  try { corpo = await req.json(); } catch { /* notificação pode vir sem corpo */ }
  const tipo = String(url.searchParams.get("type") || url.searchParams.get("topic") || corpo.type || corpo.topic || "");
  const id = String(url.searchParams.get("data.id") || (corpo.data as { id?: unknown })?.id || url.searchParams.get("id") || "");
  if (tipo !== "payment" || !/^\d{3,20}$/.test(id)) return new Response("ok", { status: 200 });
  if (!MP_TOKEN) return new Response("inativo", { status: 503 });

  // assinatura do Mercado Pago (x-signature: ts=...,v1=...)
  if (MP_SEGREDO) {
    const sig = req.headers.get("x-signature") || "", rid = req.headers.get("x-request-id") || "";
    const ts = (sig.match(/ts=([^,]+)/) || [])[1] || "", v1 = (sig.match(/v1=([^,]+)/) || [])[1] || "";
    const esperado = await hmacHex(MP_SEGREDO, `id:${id};request-id:${rid};ts:${ts};`);
    if (!ts || !v1 || !iguais(esperado, v1)) return new Response("assinatura inválida", { status: 401 });
  }

  // fonte da verdade: a própria API do Mercado Pago (nunca o corpo da notificação)
  const r = await fetch(`https://api.mercadopago.com/v1/payments/${id}`, { headers: { "Authorization": `Bearer ${MP_TOKEN}` } });
  if (!r.ok) return new Response("erro ao consultar", { status: 502 });
  const p = await r.json();
  const [uid, plano, ciclo] = String(p.external_reference || "").split("|");
  if (!/^[0-9a-f-]{36}$/.test(uid || "") || !["pro", "master"].includes(plano) || !["mensal", "anual"].includes(ciclo)) return new Response("ok", { status: 200 });

  const status = STATUS[p.status] || "pendente";
  const valor = Math.round(Number(p.transaction_amount || 0) * 100);
  const taxa = Math.round(((p.fee_details || []) as { amount?: number }[]).reduce((s, f) => s + Number(f.amount || 0), 0) * 100);
  const { tabela } = await precos();
  const esperado = Number(tabela?.[plano]?.[ciclo] || 0);

  const { data: antes } = await adm.from("evolui_pagamentos").select("status").eq("provedor", "mercadopago").eq("provedor_id", id).maybeSingle();
  await adm.from("evolui_pagamentos").upsert({
    user_id: uid, provedor: "mercadopago", provedor_id: id, plano, ciclo,
    valor_centavos: valor, taxa_centavos: taxa, status, metodo: metodo(String(p.payment_type_id || "")),
    pago_em: p.date_approved || null, atualizado_em: new Date().toISOString(),
  }, { onConflict: "provedor,provedor_id" });

  if (status === "aprovado" && antes?.status !== "aprovado") {
    if (esperado && valor + 1 < esperado) {
      await adm.rpc("evolui_alerta", { p_user: uid, p_tipo: "pagamento_divergente", p_grav: "alta", p_det: { pago: valor, esperado, pagamento: id }, p_chave: `pag_div:${id}` });
      return new Response("ok", { status: 200 });
    }
    const { data: perf } = await adm.from("evolui_perfis").select("plano,plano_ate").eq("id", uid).maybeSingle();
    const base = perf?.plano === plano && perf?.plano_ate && new Date(perf.plano_ate) > new Date() ? new Date(perf.plano_ate) : new Date();
    const ate = new Date(base);
    if (ciclo === "anual") ate.setFullYear(ate.getFullYear() + 1); else ate.setMonth(ate.getMonth() + 1);
    await adm.from("evolui_perfis").update({ plano, plano_ate: ate.toISOString() }).eq("id", uid);
  }
  if ((status === "reembolsado" || status === "estornado") && antes?.status === "aprovado") {
    await adm.from("evolui_perfis").update({ plano: "free", plano_ate: null }).eq("id", uid);
    await adm.rpc("evolui_alerta", { p_user: uid, p_tipo: "pagamento_divergente", p_grav: status === "estornado" ? "alta" : "baixa", p_det: { status, pagamento: id }, p_chave: `pag_${status}:${id}` });
  }
  return new Response("ok", { status: 200 });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  if (req.method !== "POST") return json(req, { erro: "Use POST." }, 405);
  const url = new URL(req.url);
  try {
    if (url.searchParams.get("origem") === "mp") return await webhook(req, url);
    let corpo: Record<string, unknown> = {};
    try { corpo = await req.json(); } catch { return json(req, { erro: "Pedido inválido." }, 400); }
    if (corpo.acao === "checkout") return await checkout(req, corpo);
    return json(req, { erro: "Ação desconhecida." }, 400);
  } catch (e) {
    console.error("pagamentos", e instanceof Error ? e.message : e);
    return json(req, { erro: "Algo falhou do nosso lado." }, 500);
  }
});
