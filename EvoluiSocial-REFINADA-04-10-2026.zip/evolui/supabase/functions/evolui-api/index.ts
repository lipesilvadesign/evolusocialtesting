// EvoluiSocial — API (Supabase Edge Function "evolui-api") · v8 (02/10/2026) · Evolui Intelligence Engine EIE-v1
// Só fontes públicas, gratuitas e SEM chave de API:
//   Wikipédia (Wikimedia Pageviews) · GDELT (notícias em português; consultado pelo navegador da
//   pessoa e, se faltar, pelo servidor) · Google Trends (RSS público "em alta") ·
//   OpenStreetMap (Nominatim + Overpass) · IBGE (cidades) · oEmbed oficial (YouTube/TikTok)
// Pesquisa em camadas (v4): entende a frase (assunto × intenção × formato), tolera acento, plural e erro de
// digitação, amplia aos poucos quando há pouco resultado e busca também na biblioteca da EvoluiSocial.
// Regras de segurança:
//   - toda chamada exige usuário logado; leituras com o token DA PESSOA (RLS);
//   - o histórico e o contador de uso são gravados só aqui, com a chave de serviço;
//   - o conteúdo travado pelo plano NUNCA sai do servidor.
import { createClient } from "jsr:@supabase/supabase-js@2";
import { carregarOficios, registrarLacuna } from "./eie/oficios-db.ts";
import {
  bioSugerida, classifica, consultaOverpass, contaPorDia, escolheTitulo, ideias, normaliza, paraVoce, termoSemOficio,
  parseTrendsRss, PLANO_LIBERA, RAMOS, recortaPorPlano, ROTULO, sinal, TERMOS_RAMO, ultimosDias, validaNoticiasCliente,
  type Interesse, type Serie,
} from "./motor.ts";
import { casaAssunto, consultaNoticias, dimensoesDaConsulta, entender, objetivosDaConsulta, radical, type Consulta } from "./consulta.ts";
import { analisarLink, dadosOembed } from "./links.ts";
import { ProvedorOpenAI, type ProvedorGeracao } from "./eie/geracao.ts";
import { rodarEIE, type SaidaEIE } from "./eie/orquestrador.ts";
import {
  aplicarEmBiblioteca, aplicarEmIdeias, bibliotecaParaCandidatos, compacto, consultaParaEIE, ideiasParaCandidatos, itensParaLog, metaParaLog,
  modelosParaCandidatos, objetivoParaEIE, prepararEIE, sinalDaBusca, type ContextoBanco, type ModeloCta,
} from "./eie/integracao.ts";
import { blocoRepertorio, termosParaRepertorio, type RespostaRep } from "./eie/repertorio.ts";
import { detectarOportunidade, evidencia, parseYoutube, rrf, termosDeTitulos, type VideoYT } from "./eie/oportunidades.ts";
import { lerGeocode, lerLugares, urlGeocode, urlLugares } from "./eie/geoapify.ts";
import { EIE_VERSION, type ConfigEIE } from "./eie/config.ts";
import type { ContextoUsuario } from "./eie/contexto.ts";
import { rodarPesquisaAvancada } from "./eie/pesquisa/orquestrador.ts";
import { construirInteligenciaDados, normalizarComportamentoAgregado } from "./eie/inteligencia-dados.ts";
import { gerarIdeiasVideo, normalizarAnaliseVideo, promptAnaliseVideo } from "./eie/video.ts";
import { deveAdquirirConhecimento, estruturarConhecimento, criarPerguntasPesquisa, type ResultadoConhecimento } from "./eie/conhecimento.ts";

const UA = "EvoluiSocial/1.0 (+https://felipebranding.com.br/evoluisocial/; contato@felipebranding.com.br)";
const ORIGENS = ["https://felipebranding.com.br", "https://www.felipebranding.com.br", "http://localhost:8888", "http://localhost:8765"];
const LIMITE: Record<string, number> = { free: 20, pro: 300, master: 1000 };
const BIBLIOTECA_POR_PAGINA: Record<string, number> = { free: 6, pro: 8, master: 8 };
const BIBLIOTECA_MAX: Record<string, number> = { free: 6, pro: 120, master: 120 };
const POR_MINUTO = 6;
const URL_SB = Deno.env.get("SUPABASE_URL")!;
const SERVICO = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const adm = createClient(URL_SB, SERVICO, { auth: { persistSession: false } });

// cache em memória (por instância) — reduz carga nas fontes públicas
const cache = new Map<string, { ate: number; v: unknown }>();
async function emCache<T>(chave: string, segundos: number, fn: () => Promise<T>): Promise<T> {
  const c = cache.get(chave);
  if (c && c.ate > Date.now()) return c.v as T;
  const v = await fn();
  cache.set(chave, { ate: Date.now() + segundos * 1000, v });
  if (cache.size > 500) cache.delete(cache.keys().next().value as string);
  return v;
}

async function busca(url: string, opts: RequestInit = {}, ms = 7000): Promise<Response> {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    return await fetch(url, { ...opts, signal: ctl.signal, headers: { "User-Agent": UA, "Api-User-Agent": UA, ...(opts.headers || {}) } });
  } finally { clearTimeout(t); }
}

function cors(req: Request) {
  const o = req.headers.get("origin") || "";
  return {
    "Access-Control-Allow-Origin": ORIGENS.includes(o) ? o : ORIGENS[0],
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}
const json = (req: Request, body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors(req), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });

// saúde das fontes (aparece no painel). No máximo 1 gravação por fonte a cada 5 min por instância.
const ultimaGravacao = new Map<string, string>();
function registrarFonte(fonte: string, ok: boolean, erro?: unknown) {
  const marca = `${ok}:${Math.floor(Date.now() / 300000)}`;
  if (ultimaGravacao.get(fonte) === marca) return;
  ultimaGravacao.set(fonte, marca);
  const agora = new Date().toISOString();
  adm.from("evolui_fontes_status").upsert({
    fonte, ok, atualizado_em: agora,
    ...(ok ? { ultima_ok: agora } : { ultima_falha: agora, ultimo_erro: String(erro instanceof Error ? erro.message : erro || "falha").slice(0, 300) }),
  }, { onConflict: "fonte" }).then(() => {}, () => {});
}

// disjuntor: fonte que falhou fica um tempo de fora, para não atrasar todas as buscas
const fora = new Map<string, number>();
const videoJanela = new Map<string, number[]>();
function videoLimitado(uid: string, max = 3, ms = 60_000) {
  const agora = Date.now(), l = (videoJanela.get(uid) || []).filter((t) => agora - t < ms);
  if (l.length >= max) { videoJanela.set(uid, l); return true; }
  l.push(agora); videoJanela.set(uid, l);
  if (videoJanela.size > 2000) videoJanela.delete(videoJanela.keys().next().value as string);
  return false;
}
async function comDisjuntor<T>(nome: string, fn: () => Promise<T>): Promise<T> {
  if ((fora.get(nome) || 0) > Date.now()) throw new Error(nome + " em pausa");
  try { const v = await fn(); registrarFonte(nome, true); return v; } catch (e) {
    fora.set(nome, Date.now() + (String(e).includes("429") ? 60_000 : 5 * 60_000));
    console.warn("fonte falhou:", nome, e instanceof Error ? e.message : e);
    registrarFonte(nome, false, e);
    throw e;
  }
}

async function ipHash(req: Request): Promise<string | null> {
  const ip = (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() || req.headers.get("cf-connecting-ip") || "";
  if (!ip) return null;
  const dados = new TextEncoder().encode("evolui:" + SERVICO.slice(-24) + ":" + ip);
  const h = new Uint8Array(await crypto.subtle.digest("SHA-256", dados));
  return Array.from(h).map((b) => b.toString(16).padStart(2, "0")).join("").slice(0, 40);
}

// ------------------------------------------------------------- fontes
const cap = (s: string) => (s ? s.trim()[0].toUpperCase() + s.trim().slice(1) : s);
async function tituloExato(titulo: string): Promise<string | null> {
  const e = await busca(`https://pt.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(cap(titulo))}&redirects=1&prop=pageprops&ppprop=disambiguation&format=json`);
  if (!e.ok) return null;
  const pages = Object.values(((await e.json())?.query?.pages) || {}) as { title: string; missing?: string; pageprops?: Record<string, string> }[];
  const p = pages[0];
  return p && p.missing === undefined && !(p.pageprops && "disambiguation" in p.pageprops) ? p.title : null;
}
/** Wikipédia em cascata: título exato → singular → busca → sugestão de grafia ("brigadero" → "brigadeiro"). */
async function fonteWikipedia(assunto: string, tokens: string[], dias: string[], ramo: string | null) {
  return emCache(`wiki4:${normaliza(assunto)}:${ramo || ""}`, 3600, async () => {
    let exato = await tituloExato(assunto);
    let corrigidoPara: string | null = null;
    if (!exato && tokens.length === 1 && radical(tokens[0]) !== tokens[0]) exato = await tituloExato(radical(tokens[0]));
    const s = await busca(`https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(assunto)}&srlimit=10&srinfo=suggestion&format=json`);
    if (!s.ok && !exato) throw new Error("wikipedia " + s.status);
    const js = s.ok ? await s.json() : {};
    let titulos: string[] = (js?.query?.search || []).map((x: { title: string }) => x.title);
    let titulo = escolheTitulo(assunto, exato, titulos, ramo);
    const sugestao: string | undefined = js?.query?.searchinfo?.suggestion;
    if (!titulo && sugestao && tokens.length <= 2) {
      const ex2 = await tituloExato(sugestao);
      if (ex2) { titulo = ex2; corrigidoPara = sugestao; }
      if (titulo && ramo) {
        const s2 = await busca(`https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(sugestao)}&srlimit=10&format=json`);
        if (s2.ok) { titulos = ((await s2.json())?.query?.search || []).map((x: { title: string }) => x.title); titulo = escolheTitulo(sugestao, ex2, titulos, ramo) || titulo; }
      }
    }
    // último degrau: amplia para o núcleo do assunto ("bolos de festa" → "Bolo"), avisando que é um tema mais amplo
    let amplo = false;
    if (!titulo && tokens.length >= 2) {
      const nucleo = await tituloExato(radical(tokens[0]));
      if (nucleo) { titulo = nucleo; amplo = true; }
    }
    if (!titulo) return { serie: null, titulo: null, relacionados: titulos.slice(0, 10), corrigidoPara, amplo };
    const ini = dias[0].replaceAll("-", ""), fim = dias[dias.length - 1].replaceAll("-", "");
    const p = await busca(`https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/pt.wikipedia/all-access/user/${encodeURIComponent(titulo.replaceAll(" ", "_"))}/daily/${ini}/${fim}`);
    let valores = dias.map(() => 0);
    if (p.ok) {
      const itens: { timestamp: string; views: number }[] = (await p.json())?.items || [];
      const mapa = new Map(itens.map((i) => [`${i.timestamp.slice(0, 4)}-${i.timestamp.slice(4, 6)}-${i.timestamp.slice(6, 8)}`, i.views]));
      valores = dias.map((d) => mapa.get(d) || 0);
    }
    return {
      serie: { fonte: "Wikipédia", dias, valores, minimo: 70 } as Serie,
      titulo, url: `https://pt.wikipedia.org/wiki/${encodeURIComponent(titulo.replaceAll(" ", "_"))}`,
      relacionados: titulos.filter((t) => t !== titulo && !/\(desambigua/i.test(t)).slice(0, 10),
      corrigidoPara, amplo,
    };
  });
}

type Artigo = { titulo: string; url: string; site: string; data: string };
async function fonteGdelt(consulta: string, dias: string[]) {
  return emCache(`gdelt:${normaliza(consulta)}`, 6 * 3600, async () => {
    const q = consulta + " sourcelang:portuguese";
    const r = await busca(`https://api.gdeltproject.org/api/v2/doc/doc?query=${encodeURIComponent(q)}&mode=artlist&maxrecords=250&timespan=14d&sort=datedesc&format=json`, {}, 6000);
    if (!r.ok) throw new Error("gdelt " + r.status);
    let arts: { url: string; title: string; seendate: string; domain: string }[] = [];
    try { arts = JSON.parse(await r.text())?.articles || []; } catch { throw new Error("gdelt: resposta inesperada"); }
    return {
      datas: arts.map((a) => a.seendate),
      artigos: arts.slice(0, 10).map((a) => ({ titulo: a.title, url: a.url, site: a.domain, data: a.seendate?.slice(0, 8) })) as Artigo[],
    };
  });
}

async function fonteTrendsHoje() {
  return emCache("gtrends:BR", 1800, async () => {
    const r = await busca("https://trends.google.com/trending/rss?geo=BR");
    if (!r.ok) { registrarFonte("google_trends", false, "trends " + r.status); throw new Error("trends " + r.status); }
    registrarFonte("google_trends", true);
    return parseTrendsRss(await r.text()).slice(0, 25);
  });
}

async function cidadesUF(uf: string) {
  return emCache(`ibge:${uf}`, 86400, async () => {
    const r = await busca(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${uf}/municipios?orderBy=nome`);
    if (!r.ok) { registrarFonte("ibge", false, "ibge " + r.status); throw new Error("ibge " + r.status); }
    registrarFonte("ibge", true);
    return ((await r.json()) as { id: number; nome: string }[]).map((c) => ({ id: String(c.id), nome: c.nome }));
  });
}


// ------------------------------------------------------------- YouTube (OPCIONAL: só existe com a chave do painel Integrações)
// search.list custa 100 pontos da cota diária (padrão 10.000 = ~100 buscas/dia): cache de 6 h, só planos pagos e teto diário.
const chavesCache = new Map<string, { ate: number; v: string | null }>();
async function chaveDe(nome: string): Promise<string | null> {
  const c = chavesCache.get(nome);
  if (c && c.ate > Date.now()) return c.v;
  let v: string | null = null;
  try { const { data } = await adm.rpc("evolui_integracao_ler", { p_chave: nome }); v = typeof data === "string" && data.length > 10 ? data : null; } catch { v = null; }
  chavesCache.set(nome, { ate: Date.now() + 300_000, v });
  return v;
}
const ytDia = { dia: "", n: 0 };
const YT_TETO_DIA = 80;
async function fonteYoutube(consulta: string, dias: string[]): Promise<{ datas: string[]; videos: VideoYT[]; total: number; limitado: boolean } | null> {
  const chave = await chaveDe("youtube");
  if (!chave) return null; // sem chave: a busca segue com as outras fontes
  return emCache(`yt:${normaliza(consulta)}`, 6 * 3600, async () => {
    const hoje = new Date().toISOString().slice(0, 10);
    if (ytDia.dia !== hoje) { ytDia.dia = hoje; ytDia.n = 0; }
    if (ytDia.n >= YT_TETO_DIA) throw new Error("youtube: teto diário de cota");
    ytDia.n++;
    const apos = new Date(Date.now() - 14 * 86400000).toISOString().replace(/\.\d+Z$/, "Z");
    const u = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=50&order=date&regionCode=BR&relevanceLanguage=pt&publishedAfter=${encodeURIComponent(apos)}&q=${encodeURIComponent(consulta)}`;
    const r = await busca(u, { headers: { "X-Goog-Api-Key": chave } }, 6000);
    if (!r.ok) throw new Error("youtube " + r.status);
    return parseYoutube(await r.json(), dias);
  });
}

async function coordenadas(cidade: string, uf: string) {
  return emCache(`geo:${normaliza(cidade)}:${uf}`, 30 * 86400, async () => {
    const r = await busca(`https://nominatim.openstreetmap.org/search?city=${encodeURIComponent(cidade)}&state=${encodeURIComponent(uf)}&country=Brasil&format=json&limit=1`);
    if (!r.ok) throw new Error("nominatim " + r.status);
    const j = await r.json();
    const lat = Number(j?.[0]?.lat), lon = Number(j?.[0]?.lon);
    return Number.isFinite(lat) && Number.isFinite(lon) ? { lat, lon } : null;
  });
}

// ------------------------------------------------------------- Geoapify (OPCIONAL, chave no painel Integrações; falha → OpenStreetMap)
async function coordenadasGeoapify(cidade: string, uf: string) {
  const chave = await chaveDe("geoapify");
  if (!chave) return null;
  try {
    return await emCache(`geoapify:geo:${normaliza(cidade)}:${uf}`, 30 * 86400, async () => {
      const r = await busca(urlGeocode(cidade, uf, chave), {}, 6000);
      if (!r.ok) throw new Error("geoapify " + r.status);
      const v = lerGeocode(await r.json());
      if (!v) throw new Error("geoapify sem resultado");
      return v;
    });
  } catch (e) { registrarFonte("geoapify", false, e instanceof Error ? e.message.replace(/apiKey=[^&\s]+/g, "") : "falha"); return null; }
}
async function contagemGeoapify(lat: number, lon: number, ramo: string) {
  const chave = await chaveDe("geoapify");
  if (!chave) return null;
  const u = urlLugares(lat, lon, ramo, chave);
  if (!u) return null;
  try {
    const v = await emCache(`geoapify:pl:${lat.toFixed(3)}:${lon.toFixed(3)}:${ramo}`, 86400, async () => {
      const r = await busca(u, {}, 8000);
      if (!r.ok) throw new Error("geoapify " + r.status);
      const x = lerLugares(await r.json());
      if (!x) throw new Error("geoapify resposta inesperada");
      return x;
    });
    registrarFonte("geoapify", true);
    return v;
  } catch (e) { registrarFonte("geoapify", false, e instanceof Error ? e.message : "falha"); return null; }
}

const OVERPASS = ["https://overpass-api.de/api/interpreter", "https://overpass.private.coffee/api/interpreter", "https://overpass.kumi.systems/api/interpreter"];
async function concorrenciaLocal(lat: number, lon: number, ramo: string) {
  const q = consultaOverpass(lat, lon, ramo);
  if (!q) return null;
  return emCache(`osm:${lat.toFixed(3)}:${lon.toFixed(3)}:${ramo}`, 86400, async () => {
    for (const url of OVERPASS) {
      try {
        const r = await busca(`${url}?data=${encodeURIComponent(q)}`, {}, 12000);
        if (!r.ok) continue;
        const total = Number((await r.json())?.elements?.[0]?.tags?.total ?? NaN);
        if (Number.isFinite(total)) { registrarFonte("openstreetmap", true); return total; }
      } catch { /* tenta o próximo espelho */ }
    }
    registrarFonte("openstreetmap", false, "overpass indisponível");
    throw new Error("overpass indisponível");
  });
}

// ------------------------------------------------------------- objetivos (catálogo no banco; mesmo motor de intenção da pesquisa)
type ObjCat = { chave: string; rotulo: string; subtitulo: string; intencoes: string[]; formato_padrao: string | null };
async function catalogoObjetivos(): Promise<ObjCat[]> {
  return emCache("objetivos:catalogo", 600, async () => {
    const { data, error } = await adm.from("evolui_objetivos_catalogo").select("chave,rotulo,subtitulo,intencoes,formato_padrao").eq("ativo", true).order("ordem");
    if (error) throw new Error(error.message);
    return (data || []) as ObjCat[];
  });
}

// ------------------------------------------------------------- biblioteca (busca em camadas no banco)
type ItemBib = { id: string; titulo: string; motivo: string; [k: string]: unknown };
// deno-lint-ignore no-explicit-any
type Expansao = { termos: string[]; chaves: string[] };
const SEM_EXPANSAO: Expansao = { termos: [], chaves: [] };
const reTermo = /^[a-z0-9]{2,30}$/, reChave = /^[a-z0-9_]{2,60}$/;
/** Sinônimos e chaves da taxonomia para a frase (RPC opcional). Falhou, não existe ou demorou → busca segue só com as palavras digitadas.
 *  contexto_busca (do app, nunca confiado): só entram chaves em formato seguro. */
async function expandirConsulta(sb: any, termo: string, ctx: unknown): Promise<Expansao> {
  const extra: string[] = [];
  if (ctx && typeof ctx === "object") {
    for (const k of ["area", "subramo", "tema"]) {
      const ch = (ctx as Record<string, { chave?: unknown } | undefined>)[k]?.chave;
      if (typeof ch === "string" && reChave.test(ch)) extra.push(ch);
    }
  }
  try {
    const r = await Promise.race([
      Promise.resolve(sb.rpc("evolui_expandir_consulta", { p_texto: termo })).then((x: { data?: unknown; error?: unknown }) => (x.error ? null : (x.data as Partial<Expansao> | null))),
      new Promise<null>((ok) => setTimeout(() => ok(null), 1500)),
    ]);
    const termos = Array.isArray(r?.termos) ? r!.termos!.filter((t): t is string => typeof t === "string" && reTermo.test(t)).slice(0, 10) : [];
    const chaves = [...(Array.isArray(r?.chaves) ? r!.chaves!.filter((t): t is string => typeof t === "string" && reChave.test(t)) : []), ...extra];
    return { termos, chaves: [...new Set(chaves)].slice(0, 12) };
  } catch { return { termos: [], chaves: [...new Set(extra)] }; }
}

async function buscarBiblioteca(sb: any, c: Consulta, ramo: string | null, limite: number, offset: number, exp: Expansao = SEM_EXPANSAO) {
  const ints = c.intencoes.map((i) => i.id);
  const r1 = await sb.rpc("evolui_biblioteca_buscar_v2", { p_q: c.assunto || "", p_termos: c.termosBusca, p_intencoes: ints, p_ramo: ramo, p_formato: c.formato, p_limite: limite, p_offset: offset, p_expandidos: exp.termos, p_tax: exp.chaves });
  if (r1.error) throw new Error(r1.error.message);
  let total: number = r1.data?.total || 0;
  let itens: ItemBib[] = r1.data?.itens || [];
  let ampliada = false;
  // pouco resultado na 1ª página? amplia aos poucos: ramo da pessoa + intenção (ou "ideias"), sem repetir
  if (offset === 0 && total < 4) {
    const termosRamo = (TERMOS_RAMO[ramo || "outro"] || []).flatMap((t) => normaliza(t).split(" ")).filter((w) => w.length >= 4).map(radical);
    const r2 = await sb.rpc("evolui_biblioteca_buscar_v2", { p_q: "", p_termos: [...c.termosBusca, ...termosRamo].slice(0, 24), p_intencoes: ints.length ? ints : ["ideias"], p_ramo: ramo, p_formato: c.formato, p_limite: limite, p_offset: 0, p_expandidos: exp.termos, p_tax: exp.chaves });
    if (!r2.error) {
      const vistos = new Set(itens.map((i) => i.id));
      const extras = ((r2.data?.itens || []) as ItemBib[]).filter((i) => !vistos.has(i.id)).map((i) => ({ ...i, motivo: "Relacionado ao seu ramo" }));
      itens = [...itens, ...extras].slice(0, limite);
      total = Math.max(total, itens.length);
      ampliada = extras.length > 0;
    }
  }
  return { itens, total, ampliada };
}

// ------------------------------------------------------------- EIE (motor de inteligência): ajudantes
const POOL_EIE = 30;
/** LLM é opcional: só existe se o dono ligou (config llm.ativo) E colocou a chave no painel. Qualquer falha cai no texto determinístico. */
async function provedorOpcional(cfg: ConfigEIE): Promise<ProvedorGeracao | null> {
  if (!cfg.llm.ativo) return null;
  try {
    const { data } = await adm.rpc("evolui_integracao_ler", { p_chave: "openai" });
    return typeof data === "string" && data.length > 10 ? new ProvedorOpenAI(data, cfg.llm.modelo) : null;
  } catch { return null; }
}
// deno-lint-ignore no-explicit-any
async function contextoEIE(sb: any): Promise<ContextoBanco | null> {
  try { const r = await sb.rpc("evolui_eie_contexto"); return r.error ? null : (r.data as ContextoBanco); }
  catch { return null; }
}
/** Observabilidade: só ids, notas e latências. Nunca o texto dos cards. Falha aqui não afeta a resposta. */
// deno-lint-ignore no-explicit-any
async function registrarEIE(sb: any, origem: string, termo: string, cfg: ConfigEIE, saidas: SaidaEIE[], ms: number, extra: Record<string, unknown> = {}) {
  try {
    const itens = saidas.flatMap(itensParaLog);
    const meta = { partes: saidas.map(metaParaLog), total_ms: ms, ...extra };
    console.log(JSON.stringify({ eie: EIE_VERSION, origem, config: cfg.versaoConfig, itens: itens.length, ms, fallbacks: saidas.flatMap((x) => x.meta.fallbacks).length }));
    await sb.rpc("evolui_eie_log", { p_origem: origem, p_consulta: termo, p_algoritmo: EIE_VERSION, p_config: cfg.versaoConfig, p_itens: itens, p_meta: meta });
  } catch (e) { console.warn("eie_log:", String(e)); }
}


// -------------------------------------------------------------
// Pinterest Trends — sinal contextual opcional para o Laboratório.
// Usa somente a API oficial. O endpoint de Trends devolve o ranking de palavras
// em alta da região; a relevância para a pesquisa da pessoa é calculada pela Evolui.
type PinterestTrend = {
  keyword?: string;
  pct_growth_wow?: number;
  pct_growth_mom?: number;
  pct_growth_yoy?: number;
  time_series?: Record<string, number>;
};

function normalizarPinterestTexto(v: unknown): string {
  return String(v || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokensPinterest(v: unknown): string[] {
  const stop = new Set(["de","da","do","das","dos","para","com","sem","uma","um","e","em","no","na","o","a","os","as","por","que"]);
  return normalizarPinterestTexto(v).split(" ").filter((x) => x.length >= 3 && !stop.has(x));
}

function pontuarPinterest(keyword: string, qTokens: string[], crescimento: number | null) {
  const tokens = tokensPinterest(keyword);
  const inter = qTokens.filter((x) => tokens.includes(x));
  // Match por prefixo apenas para palavras com 5+ caracteres (ex.: "barbear" ↔ "barbearia").
  const aproximados = qTokens.filter((x) => x.length >= 5 && !inter.includes(x) && tokens.some((t) => t.startsWith(x) || x.startsWith(t)));
  const consultaNorm = normalizarPinterestTexto(qTokens.join(" "));
  const palavraNorm = normalizarPinterestTexto(keyword);
  const frase = consultaNorm.length >= 5 && palavraNorm.includes(consultaNorm);
  const cobertura = qTokens.length ? Math.min(1, (inter.length + aproximados.length * 0.5 + (frase ? 1 : 0)) / qTokens.length) : 0;
  const relevancia = Math.round(cobertura * 70);
  const crescimentoScore = crescimento != null && crescimento > 0
    ? Math.min(30, Math.round(crescimento / 10))
    : 0;
  return {
    score: Math.max(0, Math.min(100, relevancia + crescimentoScore)),
    afinidade_termos: Array.from(new Set(inter.concat(aproximados))).slice(0, 8),
    cobertura,
  };
}

async function buscarPinterestTendencias(consulta: string, termosSolicitados: unknown, limite = 8) {
  const token = Deno.env.get("PINTEREST_ACCESS_TOKEN") || "";
  if (!token) return { indisponivel: true, motivo: "PINTEREST_ACCESS_TOKEN não configurado", itens: [] };

  const q = String(consulta || "").trim().slice(0, 120);
  const qTokens = Array.isArray(termosSolicitados) && termosSolicitados.length
    ? termosSolicitados.map((x) => normalizarPinterestTexto(x)).filter((x) => x.length >= 3).slice(0, 8)
    : tokensPinterest(q);
  if (q.length < 2 || !qTokens.length) return { indisponivel: false, itens: [], consulta: q, fonte: "Pinterest Trends", regiao: "BR" };

  try {
    const body = await comDisjuntor("pinterest", () => emCache("pinterest:trends:BR:growing:v1", 15 * 60, async () => {
      const u = "https://api.pinterest.com/v5/trends/keywords/BR/top/growing?limit=50";
      const r = await busca(u, { headers: { Authorization: `Bearer ${token}`, Accept: "application/json" } }, 3500);
      if (!r.ok) {
        const detalhe = await r.text().catch(() => "");
        throw new Error(`Pinterest ${r.status} ${detalhe.slice(0, 160)}`);
      }
      return await r.json() as { trends?: PinterestTrend[] };
    }));

    const trends = Array.isArray(body?.trends) ? body.trends : [];
    const itens = trends.map((t) => {
      const keyword = String(t.keyword || "").trim();
      if (!keyword) return null;
      const crescimento = Number.isFinite(Number(t.pct_growth_wow)) ? Number(t.pct_growth_wow) : null;
      const p = pontuarPinterest(keyword, qTokens, crescimento);
      return {
        fonte: "pinterest",
        url: `https://br.pinterest.com/search/pins/?q=${encodeURIComponent(keyword)}`,
        id_externo: `trend:${keyword.toLowerCase()}`,
        titulo: keyword,
        autor: "Pinterest Trends",
        miniatura_url: null,
        score: p.score,
        crescimento_wow: crescimento,
        crescimento_mom: Number.isFinite(Number(t.pct_growth_mom)) ? Number(t.pct_growth_mom) : null,
        crescimento_yoy: Number.isFinite(Number(t.pct_growth_yoy)) ? Number(t.pct_growth_yoy) : null,
        time_series: t.time_series || null,
        afinidade_termos: p.afinidade_termos,
        porque: p.afinidade_termos.length
          ? `Combina com a pesquisa por ${p.afinidade_termos.join(", ")}${crescimento != null && crescimento > 0 ? ` e está crescendo ${crescimento}% WoW` : ""}.`
          : "Sinal de crescimento no Pinterest, mantido apenas quando há aderência suficiente à consulta.",
      };
    }).filter((x): x is NonNullable<typeof x> => !!x);

    itens.sort((a, b) => b.score - a.score || (b.crescimento_wow || -Infinity) - (a.crescimento_wow || -Infinity));
    // O Pinterest é complementar: não polui o Laboratório com tendências sem relação suficiente.
    const relevantes = itens.filter((x) => x.score >= 18 && (x.afinidade_termos.length > 0 || x.score >= 45));
    const finais = relevantes.slice(0, Math.max(1, Math.min(8, limite)));
    return { indisponivel: false, itens: finais, consulta: q, fonte: "Pinterest Trends", regiao: "BR", algoritmo: "pinterest-contextual-v1" };
  } catch (e) {
    console.warn("Pinterest Trends falhou:", String(e));
    return { indisponivel: true, motivo: "Pinterest indisponível ou sem permissão para Trends", itens: [] };
  }
}

// ------------------------------------------------------------- servidor
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  if (req.method !== "POST") return json(req, { erro: "Use POST." }, 405);

  const auth = req.headers.get("Authorization") || "";
  const sb = createClient(URL_SB, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
  const { data: u } = await sb.auth.getUser();
  if (!u?.user) return json(req, { erro: "Entre na sua conta para continuar." }, 401);
  const uid = u.user.id;

  let corpo: Record<string, unknown> = {};
  try { corpo = await req.json(); } catch { return json(req, { erro: "Pedido inválido." }, 400); }
  const acao = String(corpo.acao || "");

  try {
    await carregarOficios(adm as never); // ofícios editáveis no painel (tabela evolui_oficios); falha não derruba nada
    const { data: perfil } = await sb.from("evolui_perfis").select("plano,ramo,ramo_detalhe,cidade,uf,objetivo,lat,lon,bloqueado,personalizar,nome").eq("id", uid).maybeSingle();
    if (perfil?.bloqueado) return json(req, { erro: "Sua conta está em análise pela nossa equipe. Fale com contato@felipebranding.com.br.", bloqueado: true }, 403);
    const plano = (perfil?.plano as string) || "free";
    const ramo = (perfil?.ramo as string) || null;

    if (acao === "cidades") {
      const uf = String(corpo.uf || "").toUpperCase();
      if (!/^[A-Z]{2}$/.test(uf)) return json(req, { erro: "UF inválida." }, 400);
      return json(req, { cidades: await cidadesUF(uf) });
    }

    if (acao === "emalta") {
      try { return json(req, { itens: await fonteTrendsHoje(), fonte: "Google Trends (RSS público)", em: new Date().toISOString() }); }
      catch { return json(req, { itens: [], aviso: "Google Trends indisponível agora." }); }
    }

    if (acao === "sugestoes") {
      const interesse: Interesse = perfil?.personalizar === false ? {} : ((await sb.rpc("evolui_meu_interesse")).data || {});
      let alta: { termo: string }[] = [];
      try { alta = await fonteTrendsHoje(); } catch { /* segue sem */ }
      return json(req, { itens: paraVoce(ramo, interesse, alta), personalizado: perfil?.personalizar !== false });
    }

    // Entende a frase antes de buscar (sem rede, rápido): o navegador usa para montar a consulta de notícias.
    if (acao === "entender") {
      const c = entender(String(corpo.termo || "").slice(0, 120));
      const topico = c.assunto || (perfil?.ramo_detalhe as string) || (TERMOS_RAMO[ramo || "outro"] || ["pequenos negócios"])[0];
      return json(req, { assunto: c.assunto, topico, modo: c.modo, noticias: consultaNoticias(c.assunto ? c : entender(topico)) });
    }

    // Próximas páginas da biblioteca (mesma busca em camadas)
    if (acao === "biblioteca") {
      const c = entender(String(corpo.termo || "").slice(0, 120));
      const offset = Math.max(0, Math.min(300, Number(corpo.offset) || 0));
      const porPagina = BIBLIOTECA_POR_PAGINA[plano] || 6;
      if (offset + porPagina > (BIBLIOTECA_MAX[plano] || 6)) return json(req, { itens: [], total: 0, bloqueado: true, plano: "pro" });
      const excluir = Array.isArray(corpo.excluir) ? (corpo.excluir as unknown[]).filter((x): x is string => typeof x === "string" && x.length <= 60).slice(0, 200) : [];
      const t0 = Date.now();
      try {
        // EIE: busca um grupo maior, reordena por adequação ao contexto e devolve só a página, sem repetir o que já está na tela
        const exp = await expandirConsulta(sb, String(corpo.termo || "").slice(0, 120), corpo.contexto_busca);
        const [rpc, bruto] = await Promise.all([contextoEIE(sb), buscarBiblioteca(sb, c, ramo, Math.min(60, POOL_EIE + offset), 0, exp)]);
        const { ctx, cfg, historico } = prepararEIE(rpc, c.intencoes.map((i) => i.id));
        const saida = await rodarEIE({
          consulta: consultaParaEIE(c), candidatos: bibliotecaParaCandidatos(bruto.itens as never), contexto: ctx, historico, cfg, k: porPagina, excluirIds: excluir,
          provedor: await provedorOpcional(cfg),
        });
        if (!saida.itens.length) throw new Error("EIE sem itens");
        await registrarEIE(sb, "biblioteca", String(corpo.termo || ""), cfg, [saida], Date.now() - t0);
        return json(req, { itens: aplicarEmBiblioteca(saida, ctx), total: bruto.total, ampliada: bruto.ampliada, algoritmo: EIE_VERSION });
      } catch (e) {
        console.warn("eie biblioteca (reserva):", String(e));
        const r = await buscarBiblioteca(sb, c, ramo, porPagina, offset, await expandirConsulta(sb, String(corpo.termo || "").slice(0, 120), corpo.contexto_busca));
        return json(req, { ...r, itens: r.itens.filter((i) => !excluir.includes(i.id)), algoritmo: "basico" });
      }
    }

    // Pinterest: tendências oficiais para enriquecer as referências do Laboratório.
    // O ranking final continua no navegador, usando a consulta/contexto da Evolui.
    if (acao === "buscar_referencias_pinterest") {
      const consulta = String(corpo.consulta || "").replace(/[<>"]/g, "").replace(/\s+/g, " ").trim().slice(0, 120);
      if (consulta.length < 2) return json(req, { itens: [] });
      return json(req, await buscarPinterestTendencias(consulta, corpo.termos, Math.max(1, Math.min(8, Number(corpo.limite) || 8))));
    }

    // Análise profissional de vídeo — Pro/Master.
    // A análise pode usar o EVI Video Worker próprio da Evolui; o analisador legado permanece como fallback.
    // O frontend nunca recebe secrets do worker/analisador.
    if (acao === "analisar_video_pro") {
      if (plano !== "pro" && plano !== "master") return json(req, { bloqueado: true, plano: "pro", erro: "A análise de vídeo está disponível no Pro e no Master." }, 403);
      if (videoLimitado(uid)) return json(req, { erro: "Limite de análises atingido. Aguarde um instante." }, 429);
      const url = String(corpo.url || "").trim().slice(0, 600);
      if (!/^https:\/\/[^\s<>]+$/i.test(url)) return json(req, { erro: "Cole um link HTTPS válido de vídeo." }, 400);
      const l = analisarLink(url);
      if (!l) return json(req, { erro: "Cole um link de YouTube, TikTok ou Instagram." }, 400);

      let base: { titulo?: string | null; autor?: string | null } = {};
      if (l.oembed) {
        try {
          const om = await busca(l.oembed, {}, 6000);
          if (om.ok) base = dadosOembed(await om.json()) || {};
        } catch { /* metadados são opcionais */ }
      }

      const eviWorkerUrl = Deno.env.get("EVI_VIDEO_WORKER_URL") || "";
      const legacyAnalyzerUrl = Deno.env.get("EVOLUI_VIDEO_ANALYZER_URL") || "";
      const analyzerUrl = eviWorkerUrl || legacyAnalyzerUrl;
      if (!analyzerUrl) {
        return json(req, {
          configuracao_pendente: true,
          erro: "O analisador de vídeo ainda não está conectado ao servidor de inferência.",
          instrucoes: "Configure EVI_VIDEO_WORKER_URL apontando para o EVI Video Worker da Evolui. O analisador legado permanece como fallback compatível.",
          link: l,
          metadados: normalizarAnaliseVideo({ titulo: base.titulo, autor: base.autor }, { url, plataforma: l.plataforma, titulo: base.titulo, autor: base.autor }),
        }, 503);
      }

      const segredo = eviWorkerUrl ? (Deno.env.get("EVI_VIDEO_WORKER_TOKEN") || "") : (Deno.env.get("EVOLUI_VIDEO_ANALYZER_TOKEN") || "");
      const pedido = eviWorkerUrl ? {
        url,
        plataforma: l.plataforma,
        contexto: {
          ramo: (perfil?.ramo_detalhe as string | null) || ramo,
          objetivo: (perfil?.objetivo as string | null) || null,
          cidade: perfil?.personalizar === false ? null : ((perfil?.cidade as string | null) || null),
        },
      } : {
        url,
        plataforma: l.plataforma,
        prompt: promptAnaliseVideo({ url, ramo: (perfil?.ramo_detalhe as string | null) || ramo, objetivo: (perfil?.objetivo as string | null) || null, cidade: perfil?.personalizar === false ? null : ((perfil?.cidade as string | null) || null) }),
        contexto: {
          ramo: (perfil?.ramo_detalhe as string | null) || ramo,
          objetivo: (perfil?.objetivo as string | null) || null,
          cidade: perfil?.personalizar === false ? null : ((perfil?.cidade as string | null) || null),
        },
      };
      try {
        const r = await busca(analyzerUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", ...(segredo ? { Authorization: `Bearer ${segredo}` } : {}) },
          body: JSON.stringify(pedido),
        }, 25_000);
        if (!r.ok) return json(req, { erro: `O analisador de vídeo respondeu ${r.status}.` }, 502);
        const raw = await r.json();
        const analise = normalizarAnaliseVideo(raw?.analysis || raw?.analise || raw, { url, plataforma: l.plataforma, titulo: base.titulo, autor: base.autor });
        const ideiasVideo = gerarIdeiasVideo(analise, { ramo: (perfil?.ramo_detalhe as string | null) || ramo, objetivo: (perfil?.objetivo as string | null) || null });
        if (perfil?.personalizar !== false) {
          await sb.from("evolui_eventos").insert({ user_id: uid, tipo: "video_analisado", dados: { plataforma: l.plataforma, modo: analise.modo, termos: analise.termos.slice(0, 8), algoritmo: analise.versao } });
          try {
            await adm.from("evolui_video_analises").insert({
              user_id: uid, url, plataforma: l.plataforma, algoritmo: analise.versao, titulo: analise.titulo, tema: analise.tema, formato: analise.formato,
              transcricao: analise.transcricao, estrutura: analise.estrutura, retorica: analise.retorica, ritmo: analise.ritmo, cenas: analise.cenas,
              sinais_visuais: analise.sinaisVisuais, dna: analise.dna, lacunas: analise.lacunas, oportunidades: analise.oportunidades,
              evi_score: analise.eviScore, impressao_digital: analise.impressaoDigital, ajuste_contextual_observavel: analise.ajusteContextualObservavel, proveniencia: analise.proveniencia, transcricao_meta: (raw?.analysis?.transcricao_meta || {})
            });
          } catch (e) { console.warn("evi video persistence:", String(e)); }
        }
        return json(req, { analise, ideias: ideiasVideo, algoritmo: analise.versao, motor: eviWorkerUrl ? "evi-video-worker" : "legacy-video-analyzer" });
      } catch (e) {
        console.warn("video analyzer:", String(e));
        return json(req, { erro: "Não foi possível analisar o vídeo agora." }, 502);
      }
    }

    // Link de vídeo: reconhece a plataforma e lê só dados públicos pelo oEmbed oficial (YouTube, TikTok)
    if (acao === "analisar_link") {
      const l = analisarLink(String(corpo.url || "").slice(0, 600));
      if (!l) return json(req, { erro: "Cole um link de vídeo do YouTube, TikTok ou Instagram (começando com https://)." }, 400);
      let dados = null, aviso: string | null = null;
      if (l.oembed) {
        try {
          const r = await busca(l.oembed, {}, 6000);
          if (r.ok) { dados = dadosOembed(await r.json()); registrarFonte(`oembed_${l.plataforma}`, true); }
          else { aviso = "A plataforma não liberou os dados públicos deste vídeo (pode ser privado ou removido)."; registrarFonte(`oembed_${l.plataforma}`, r.status < 500, "oembed " + r.status); }
        } catch (e) { aviso = "Não conseguimos consultar a plataforma agora."; registrarFonte(`oembed_${l.plataforma}`, false, e); }
      } else if (l.plataforma === "instagram") aviso = "O Instagram só libera dados do vídeo para apps aprovados pela Meta. Por enquanto guardamos o link e o código do vídeo.";
      return json(req, { link: l, dados, aviso });
    }

    if (acao === "local") {
      if (!PLANO_LIBERA[plano]?.local) return json(req, { local: null, bloqueado: true, plano: "pro" });
      const p = perfil;
      if (!p?.cidade || !p?.uf || !p?.ramo) return json(req, { local: null, aviso: "Complete cidade e ramo no perfil." });
      let lat = p.lat as number | null, lon = p.lon as number | null;
      if (lat == null || lon == null) {
        try {
          const c = (await coordenadasGeoapify(p.cidade, p.uf)) || await coordenadas(p.cidade, p.uf);
          if (c) { lat = c.lat; lon = c.lon; await sb.from("evolui_perfis").update({ lat, lon }).eq("id", uid); }
        } catch { /* segue sem coordenadas */ }
      }
      let total: number | null = null, aviso: string | null = null, fonteLocal = "OpenStreetMap", limitado = false;
      // Geoapify é opcional: tenta primeiro se houver chave; qualquer falha cai no OpenStreetMap
      if (lat != null && lon != null) {
        const g = await contagemGeoapify(lat, lon, p.ramo);
        if (g) { total = g.total; limitado = g.limitado; fonteLocal = "Geoapify"; }
      }
      if (total === null && lat != null && lon != null) {
        try { total = await concorrenciaLocal(lat, lon, p.ramo); } catch { aviso = "O mapa (OpenStreetMap) está ocupado agora. Tente de novo mais tarde."; }
      } else if (total === null) aviso = "Não encontramos sua cidade no mapa.";
      if (total === null && !aviso) aviso = "Ainda não temos como contar esse ramo no mapa.";
      return json(req, { local: { total, raioKm: 8, cidade: p.cidade, uf: p.uf, ramo: RAMOS[p.ramo]?.rotulo || p.ramo, fonte: fonteLocal, ...(limitado ? { limitado: true } : {}) }, aviso });
    }

    // Nova sugestão de ação (CTA): o EIE escolhe o modelo; o banco preenche com os dados da pessoa e registra a explicação.
    if (acao === "cta") {
      const objetivo = String(corpo.objetivo || "").slice(0, 40);
      if (!/^[a-z0-9_]{2,40}$/.test(objetivo)) return json(req, { erro: "Objetivo inválido." }, 400);
      const tema = String(corpo.tema || "").replace(/[<>"{}]/g, "").replace(/\s+/g, " ").trim().slice(0, 60);
      const buscaTxt = String(corpo.busca || "").replace(/[<>"{}]/g, "").replace(/\s+/g, " ").trim().slice(0, 120);
      const trocar = typeof corpo.trocar === "string" && /^[0-9a-f-]{36}$/i.test(corpo.trocar) ? corpo.trocar : null;
      const cat = (await catalogoObjetivos()).find((o) => o.chave === objetivo);
      if (!cat) return json(req, { erro: "Objetivo desconhecido." }, 400);
      const t0 = Date.now();
      let modelo: string | null = null, eie: Record<string, unknown> | null = null, ctx: ContextoUsuario | null = null;
      try {
        const [rpc, mods] = await Promise.all([contextoEIE(sb), adm.rpc("evolui_eie_cta_candidatos", { p_objetivo: objetivo })]);
        const consulta = buscaTxt ? entender(buscaTxt) : null;
        const prep = prepararEIE(rpc, consulta ? consulta.intencoes.map((i) => i.id) : []);
        ctx = prep.ctx;
        const excl: string[] = [];
        if (trocar) { const r = await sb.from("evolui_ctas").select("modelo_id").eq("id", trocar).maybeSingle(); if (r.data?.modelo_id) excl.push(r.data.modelo_id as string); }
        const saida = await rodarEIE({
          consulta: consulta ? consultaParaEIE(consulta) : null, objetivo: objetivoParaEIE(cat), candidatos: modelosParaCandidatos((mods.data || []) as ModeloCta[], ctx.ramo),
          contexto: ctx, historico: prep.historico, cfg: prep.cfg, k: 1, excluirIds: excl,
        });
        if (saida.itens[0]) { modelo = saida.itens[0].candidato.id; eie = compacto(saida.itens[0]) as unknown as Record<string, unknown>; }
        await registrarEIE(sb, "cta", buscaTxt, prep.cfg, [saida], Date.now() - t0);
      } catch (e) { console.warn("eie cta (reserva):", String(e)); }
      const r = await sb.rpc("evolui_cta_gerar_eie", { p_objetivo: objetivo, p_tema: tema || null, p_busca: buscaTxt || null, p_trocar: trocar, p_modelo: modelo, p_eie: eie, p_sem_cidade: ctx ? !ctx.permissoes.local : true });
      if (r.error) return json(req, { erro: String(r.error.message || "Não foi possível gerar agora.").slice(0, 160) }, 400);
      return json(req, { cta: r.data, algoritmo: eie ? EIE_VERSION : "basico" });
    }

    if (acao === "buscar") {
      const termo = String(corpo.termo || "").replace(/[<>"]/g, "").replace(/\s+/g, " ").trim().slice(0, 80);
      if (termo.length < 2) return json(req, { erro: "Digite pelo menos 2 letras." }, 400);

      const desde = new Date(Date.now() - 60_000).toISOString();
      const [{ count: minuto }, { data: mes }] = await Promise.all([
        adm.from("evolui_buscas").select("id", { count: "exact", head: true }).eq("user_id", uid).gte("criado_em", desde),
        sb.rpc("evolui_buscas_no_mes"),
      ]);
      if ((minuto || 0) >= POR_MINUTO) {
        await adm.rpc("evolui_registra_negada", { p_user: uid });
        return json(req, { erro: "Muitas buscas seguidas. Espere um minuto." }, 429);
      }
      if ((mes || 0) >= LIMITE[plano]) {
        await adm.rpc("evolui_registra_negada", { p_user: uid });
        return json(req, { erro: `Você usou as ${LIMITE[plano]} pesquisas do seu plano este mês.`, limite: true }, 402);
      }

      // 1) entender a frase: assunto (do que fala) × intenção (o que quer) × formato
      const c = entender(termo);
      const temaDoRamo = !c.assunto;
      const topico = c.assunto || (perfil?.ramo_detalhe as string) || (TERMOS_RAMO[ramo || "outro"] || ["pequenos negócios"])[0];
      const ct = c.assunto ? c : entender(topico);

      // EKE: se a compreensão semântica estiver fraca ou o termo for ambíguo,
      // a Evolui pesquisa o próprio contexto antes de decidir que "não há dados".
      // Isso é uma camada de aquisição de conhecimento, não uma nova IA gerativa.
      const conhecimentoP: Promise<ResultadoConhecimento | null> = deveAdquirirConhecimento(termo, c)
        ? Promise.race([
            rodarPesquisaAvancada({
              consulta: entender(termo),
              perfil: {
                ramo: (ramo && RAMOS[ramo]?.rotulo) || ramo || null,
                ramo_detalhe: (perfil?.ramo_detalhe as string | null) || null,
                cidade: perfil?.personalizar === false ? null : ((perfil?.cidade as string | null) || null),
                objetivo: (perfil?.objetivo as string | null) || null,
              },
              limiteQueries: 4,
            }).then((r) => estruturarConhecimento(termo, r.resultados.map((x) => ({ titulo: x.titulo, snippet: x.snippet, url: x.url })))),
            new Promise<null>((resolve) => setTimeout(() => resolve(null), 2800)),
          ]).catch(() => null)
        : Promise.resolve(null);

      const dias28 = ultimosDias(28), dias14 = ultimosDias(14);
      const doNavegador = validaNoticiasCliente(corpo.gdelt, dias14);
      const qNoticias = consultaNoticias(ct);
      const interesseP: Promise<Interesse> = perfil?.personalizar === false
        ? Promise.resolve({})
        : Promise.resolve(sb.rpc("evolui_meu_interesse")).then((r) => (r.data || {}) as Interesse).catch(() => ({}));
      const porPagina = BIBLIOTECA_POR_PAGINA[plano] || 6;
      // Repertório do Evolui: uma fonte entre outras. Falhou ou vazio → a pesquisa segue sem ele. Só vão ramo, intenções e termos (nada pessoal).
      const repTermos = termosParaRepertorio(c, topico);
      const repP: Promise<RespostaRep | null> = Promise.race([
        Promise.resolve(adm.rpc("evolui_rep_consultar", { p_termos: repTermos.termos, p_ramo: ramo, p_intencoes: c.intencoes.map((i) => i.id), p_formato: c.formato, p_limite: 3, p_log: topico }))
          .then((r) => (r.error ? null : (r.data as RespostaRep))),
        new Promise<null>((ok) => setTimeout(() => ok(null), 2500)),
      ]).catch(() => null);
      // Entendimento por taxonomia (RPC opcional): falhou, não existe ou demorou → segue sem ela. Cidade só se a pessoa permite personalizar.
      const taxP: Promise<Record<string, unknown> | null> = Promise.race([
        Promise.resolve(sb.rpc("evolui_entender_termos", { p_texto: termo, p_cidade: perfil?.personalizar === false ? null : ((perfil?.cidade as string | null) || null) }))
          .then((r: { data?: unknown; error?: unknown }) => (r.error || !r.data || typeof r.data !== "object" ? null : (r.data as Record<string, unknown>))),
        new Promise<null>((ok) => setTimeout(() => ok(null), 1500)),
      ]).catch(() => null);
      // Pesquisa web avançada: começa cedo e trabalha em paralelo com as fontes legadas.
      // Ela só acrescenta descoberta; não substitui o cálculo de tendência nem o EIE/Claudia.
      const pesquisaAvancadaP = rodarPesquisaAvancada({
        consulta: c,
        perfil: {
          ramo: (ramo && RAMOS[ramo]?.rotulo) || ramo || null,
          ramo_detalhe: (perfil?.ramo_detalhe as string | null) || null,
          cidade: perfil?.personalizar === false ? null : ((perfil?.cidade as string | null) || null),
          objetivo: (perfil?.objetivo as string | null) || null,
        },
        // A taxonomia continua sendo lida pelo motor atual; a busca web não espera por ela para ganhar dianteira.
        taxonomia: null,
      }).catch((e) => ({
        modo: "off" as const, versao: "pesquisa-avancada-v2", consultas: [], resultados: [], evidencias: [], provedores: [], ms: 0, etapas: {},
        falhas: [e instanceof Error ? e.message.slice(0, 160) : "falha_pesquisa_avancada"],
      }));
      // sinônimos + chaves da taxonomia (e contexto_busca do app) para a biblioteca; entra em paralelo com as fontes externas
      const expP = expandirConsulta(sb, termo, corpo.contexto_busca);
      const tFontes = Date.now();
      const [wiki, gdelt, hoje, interesse, bib, catObj, rpcEie, yt, repRaw, pesquisaAvancada, conhecimento] = await Promise.all([
        comDisjuntor("wikipedia", () => fonteWikipedia(topico, ct.assuntoTokens, dias28, ramo)).then((v) => ({ ok: true as const, v }), (e) => ({ ok: false as const, e })),
        (doNavegador && doNavegador.datas.length
          ? Promise.resolve({ ...doNavegador, origem: "navegador" })
          : qNoticias
            ? comDisjuntor("gdelt", () => fonteGdelt(qNoticias.principal, dias14)).then((v) => ({ ...v, origem: "servidor" }))
            : Promise.reject(new Error("sem assunto para notícias")))
          .then((v) => ({ ok: true as const, v }), (e) => ({ ok: false as const, e })),
        fonteTrendsHoje().then((v) => ({ ok: true as const, v }), (e) => ({ ok: false as const, e })),
        interesseP,
        expP.then((exp) => buscarBiblioteca(sb, c, ramo, POOL_EIE, 0, exp)).catch((e) => { console.warn("biblioteca:", String(e)); return { itens: [], total: 0, ampliada: false }; }),
        catalogoObjetivos().catch((e) => { console.warn("objetivos:", String(e)); return [] as ObjCat[]; }),
        contextoEIE(sb),
        // YouTube é opcional e só nos planos pagos (cota diária da chave); qualquer falha apenas tira a fonte
        PLANO_LIBERA[plano]?.local
          ? comDisjuntor("youtube", async () => await fonteYoutube(topico, dias14)).then((v) => ({ ok: true as const, v }), (e) => ({ ok: false as const, e }))
          : Promise.resolve({ ok: true as const, v: null }),
        repP,
        pesquisaAvancadaP,
        conhecimentoP,
      ]);
      const msFontes = Date.now() - tFontes;
      if (doNavegador && doNavegador.datas.length) registrarFonte("gdelt_navegador", true);

      const fontes: { nome: string; ok: boolean; detalhe: string; link?: string }[] = [];
      const series: Serie[] = [];
      if (wiki.ok && wiki.v.serie) { series.push(wiki.v.serie); fontes.push({ nome: "Wikipédia", ok: true, detalhe: `Visitas à página "${wiki.v.titulo}"${wiki.v.amplo ? " (tema mais amplo)" : ""}`, link: wiki.v.url }); }
      else fontes.push({ nome: "Wikipédia", ok: false, detalhe: wiki.ok ? "Nenhuma página sobre o assunto" : "Indisponível agora" });
      let artigos: Artigo[] = [];
      if (gdelt.ok) {
        series.push({ fonte: "Notícias (GDELT)", dias: dias14, valores: contaPorDia(gdelt.v.datas, dias14), minimo: 3 });
        artigos = gdelt.v.artigos;
        fontes.push({ nome: "Notícias (GDELT)", ok: true, detalhe: `${gdelt.v.datas.length >= 250 ? "250+" : gdelt.v.datas.length} matérias em português nos últimos 14 dias` });
      } else fontes.push({ nome: "Notícias (GDELT)", ok: false, detalhe: "Indisponível agora (o serviço limita consultas; tente de novo em 1 minuto)" });

      // YouTube: vídeos novos por dia (limite da API: 50 por consulta → se lotar, mostramos o volume, mas não comparamos semanas)
      if (yt.ok && yt.v) {
        if (yt.v.limitado) fontes.push({ nome: "YouTube", ok: true, detalhe: `50+ vídeos novos em português nos últimos 14 dias (a API mostra no máximo 50, então não medimos crescimento)` });
        else {
          series.push({ fonte: "YouTube", dias: dias14, valores: contaPorDia(yt.v.datas, dias14), minimo: 8 });
          fontes.push({ nome: "YouTube", ok: true, detalhe: `${yt.v.datas.length} vídeos novos em português nos últimos 14 dias` });
        }
      } else if (!yt.ok) fontes.push({ nome: "YouTube", ok: false, detalhe: "Indisponível agora (a fonte é opcional)" });
      const videosYt = yt.ok && yt.v ? yt.v.videos.slice(0, 3) : [];

      const emAltaHoje = hoje.ok ? hoje.v.filter((i) => casaAssunto(ct.assuntoTokens, `${i.termo} ${i.noticia || ""}`)) : [];
      fontes.push({ nome: "Google Trends", ok: hoje.ok, detalhe: !hoje.ok ? "Indisponível agora" : emAltaHoje.length ? `Entre as buscas em alta no Brasil hoje (${emAltaHoje[0].trafego || "volume não informado"})` : "Não está entre as buscas em alta de hoje" });

      const sinais = series.map(sinal);
      const cl = classifica(sinais, emAltaHoje.length > 0);
      const fontesEvid = [
        ...sinais.map((s) => ({ nome: s.fonte, ok: true, temSinal: s.temSinal, quantidade: s.total14 })),
        ...(hoje.ok ? [{ nome: "Google Trends", ok: true, temSinal: emAltaHoje.length > 0, quantidade: emAltaHoje.length }] : []),
      ];
      const evid = evidencia(fontesEvid, cl.confianca);
      const perfilIdeias = { ...(perfil || {}), ramo: (ramo && RAMOS[ramo]?.rotulo) || ramo || null };
      // ---- EIE-v1: contexto da pessoa → candidatos → EvoluiScore → diversidade → explicação por item (com reserva sem EIE)
      const tEie = Date.now();
      const prep = prepararEIE(rpcEie, c.intencoes.map((i) => i.id));
      const conhecimentoSuficiente = !!conhecimento && conhecimento.confianca >= 0.55;
      const ideiasBase = cl.estado === "insuficiente" && !conhecimentoSuficiente ? [] : ideias(topico, cl.estado, perfilIdeias, interesse, { local: prep.ctx.permissoes.local });
      if (topico && termoSemOficio(topico)) registrarLacuna(adm as never, topico); // alimenta evolui_oficio_lacunas
      let ideiasFinal: unknown[] = ideiasBase, bibItens: unknown[] = bib.itens.slice(0, porPagina);
      const eieInfo: Record<string, unknown> = { algoritmo: "basico" };
      try {
        const consultaE = consultaParaEIE(c);
        const [sIdeias, sBib] = await Promise.all([
          ideiasBase.length
            ? rodarEIE({ consulta: consultaE, candidatos: ideiasParaCandidatos(ideiasBase, topico), contexto: prep.ctx, historico: prep.historico, cfg: prep.cfg, k: 5,
                sinalTendencia: sinalDaBusca(cl.estado, ROTULO[cl.estado], topico, cl.confianca, new Date().toISOString()) })
            : Promise.resolve(null),
          bib.itens.length
            ? provedorOpcional(prep.cfg).then((provedor) => rodarEIE({ consulta: consultaE, candidatos: bibliotecaParaCandidatos(bib.itens as never), contexto: prep.ctx, historico: prep.historico, cfg: prep.cfg, k: porPagina, provedor }))
            : Promise.resolve(null),
        ]);
        if (sIdeias?.itens.length) ideiasFinal = aplicarEmIdeias(sIdeias, ideiasBase, { rotulo: ROTULO[cl.estado], estado: cl.estado });
        if (sBib?.itens.length) bibItens = aplicarEmBiblioteca(sBib, prep.ctx);
        const partes = [sIdeias, sBib].filter((x): x is SaidaEIE => !!x);
        Object.assign(eieInfo, { algoritmo: EIE_VERSION, config: prep.cfg.versaoConfig, contexto: prep.ctx.nivel, ms: Date.now() - tEie, fallbacks: partes.reduce((n, x) => n + x.meta.fallbacks.length, 0) });
        await registrarEIE(sb, "busca", termo, prep.cfg, partes, Date.now() - tEie, { fontes: fontes.map((f) => ({ n: f.nome, ok: f.ok })), fontes_falhas: fontes.filter((f) => !f.ok).map((f) => f.nome), oportunidade: { estado: cl.estado, evidencia: evid.nivel, fontes: evid.fontes.length }, algoritmo_oportunidade: "oportunidade-v1+rrf", interpretacao: { ...dimensoesDaConsulta(c), taxonomia: !!(await taxP) } });
      } catch (e) { console.warn("eie busca (reserva):", String(e)); }
      // relacionados: Wikipédia + termos ligados ao que a pessoa quer, sem repetir e sem repetir a própria busca
      const visto = new Set([normaliza(termo), normaliza(topico)]);
      const relacionados: string[] = [];
      // RRF funde as listas das fontes (Wikipédia, intenção, títulos do YouTube) pela posição, sem somar escalas diferentes
      const listaYt = yt.ok && yt.v ? termosDeTitulos(yt.v.videos.map((v) => v.titulo), ct.assuntoTokens) : [];
      const listaWeb = pesquisaAvancada.resultados.map((x) => x.titulo).filter(Boolean).slice(0, 20);
      const listaWebTermos = termosDeTitulos(listaWeb, ct.assuntoTokens, 8);
      for (const { item: r } of rrf([wiki.ok ? wiki.v.relacionados : [], c.expansoes, listaYt, listaWebTermos])) {
        const k = normaliza(r);
        if (k && !visto.has(k)) { visto.add(k); relacionados.push(r); }
      }
      const correcoes = [...c.correcoes, ...(wiki.ok && wiki.v.corrigidoPara ? [{ de: c.assunto, para: wiki.v.corrigidoPara }] : [])];
      const taxonomia = await taxP;
      const dimensoes = dimensoesDaConsulta(c);
      // Nova camada de inteligência de dados: transforma fontes já consultadas em sinais
      // rastreáveis. Não adiciona coleta pessoal nem substitui o EIE existente.
      const inteligenciaDados = construirInteligenciaDados({
        termo,
        topico,
        ramo: (ramo && RAMOS[ramo]?.rotulo) || ramo || null,
        personalizado: perfil?.personalizar !== false,
        fontes,
        pesquisaAvancada,
        sinaisPesquisa: sinais.map((s) => ({ fonte: s.fonte, crescimento: s.crescimento, temSinal: s.temSinal, total14: s.total14 })),
        emAltaHoje: emAltaHoje.length,
      });

      const provedoresPesquisa = pesquisaAvancada.provedores || [];
      const provAtivos = provedoresPesquisa.filter((x) => x.ativo);
      if (provAtivos.some((x) => x.resultados > 0)) {
        fontes.push({ nome: "Busca web avançada", ok: true, detalhe: `${provAtivos.reduce((n, x) => n + x.resultados, 0)} resultados recuperados por ${provAtivos.map((x) => x.nome).join(" + ")}` });
      } else if (provAtivos.length) {
        fontes.push({ nome: "Busca web avançada", ok: false, detalhe: pesquisaAvancada.falhas.length ? "Nenhum resultado recuperado agora" : "Nenhum resultado adicional encontrado" });
      }
      // EKE: registra conhecimento adquirido com proveniência. Nunca grava a pergunta
      // como "verdade" sem estado: ambiguidade vira desambiguacao; demais ficam provisorias.
      if (conhecimento) {
        try {
          await adm.from("evolui_conhecimento").upsert({
            termo: conhecimento.termo.slice(0, 160),
            entidade: conhecimento.entidade.slice(0, 160),
            tipo: conhecimento.tipo,
            significados: conhecimento.significados.slice(0, 4),
            termos_relacionados: conhecimento.termosRelacionados.slice(0, 24),
            contexto: conhecimento.contexto.slice(0, 1000),
            confianca: conhecimento.confianca,
            status: conhecimento.necessitaDesambiguacao ? "desambiguacao" : conhecimento.confianca >= 0.78 ? "validado" : "provisorio",
            fontes: conhecimento.fontes.slice(0, 8),
            atualizado_em: new Date().toISOString(),
          }, { onConflict: "termo,entidade" });
        } catch (e) { console.warn("eke persistencia:", String(e)); }
      }

      // Inteligência comportamental agregada: consulta apenas sinais com limiar
      // mínimo e sem identificadores pessoais. Falha silenciosamente para não
      // transformar essa camada de enriquecimento em dependência da pesquisa.
      let comportamentoAgregado = normalizarComportamentoAgregado([]);
      try {
        const ag = await adm.rpc("evolui_obter_sinais_agregados", {
          p_tema: topico,
          p_ramo: (ramo && RAMOS[ramo]?.rotulo) || ramo || null,
          p_dias: 30,
        });
        if (!ag.error) comportamentoAgregado = normalizarComportamentoAgregado(ag.data);
      } catch (e) {
        console.warn("comportamento agregado:", String(e));
      }

      if (comportamentoAgregado.sinais.length) {
        const principal = comportamentoAgregado.sinais[0];
        inteligenciaDados.sinais.push({
          chave: "sinal_comportamental_agregado",
          valor: principal.crescimento == null ? principal.volumeAtual : principal.crescimento,
          tipo: "agregado",
          origem: "sistema",
          confianca: principal.confianca,
          explicacao: "Sinal calculado a partir de volume agregado de pesquisas da Evolui; não representa usuários individuais nem garante desempenho.",
          atualizadoEm: new Date().toISOString(),
        });
      }

      const completo = {
        termo, topico, estado: cl.estado, rotulo: ROTULO[cl.estado], confianca: cl.confianca, crescimento: cl.crescimento,
        fontesComSinal: cl.fontes, atualizadoEm: new Date().toISOString(),
        series: series.map((s) => ({ fonte: s.fonte, dias: s.dias, valores: s.valores })),
        sinais: sinais.map((s) => ({ fonte: s.fonte, ultimos7: s.ultimos7, anteriores7: s.anteriores7, crescimento: s.crescimento, temSinal: s.temSinal })),
        fontes,
        noticias: artigos,
        relacionados: relacionados.slice(0, 12),
        emAltaHoje: emAltaHoje.slice(0, 3),
        ideias: ideiasFinal as ReturnType<typeof ideias>,
        personalizado: perfil?.personalizar !== false && !!(interesse.respostas && Object.keys(interesse.respostas).length),
        interpretacao: {
          modo: c.modo, assunto: c.assunto, temaDoRamo, formato: c.formato,
          intencoes: c.intencoes.map((i) => i.rotulo), correcoes,
          // novas dimensões (só acrescentam; `intencoes` acima segue como lista de rótulos)
          plataforma: dimensoes.plataforma, localizacao: dimensoes.localizacao, intencoes_detalhe: dimensoes.intencoes_detalhe,
          confianca: dimensoes.confianca, entidades: dimensoes.entidades, origem: dimensoes.origem,
          entidades_taxonomia: (taxonomia as { entidades?: unknown } | null)?.entidades ?? null,
          cadeia: (taxonomia as { cadeia?: unknown } | null)?.cadeia ?? null,
          conhecimento: conhecimento ? { tipo: conhecimento.tipo, significados: conhecimento.significados, termosRelacionados: conhecimento.termosRelacionados.slice(0, 12), confianca: conhecimento.confianca, necessitaDesambiguacao: conhecimento.necessitaDesambiguacao } : null,
        },
        objetivos: objetivosDaConsulta(catObj, c).map(({ chave, rotulo, subtitulo }) => ({ chave, rotulo, subtitulo })),
        biblioteca: { itens: bibItens, total: Math.min(bib.total, BIBLIOTECA_MAX[plano] || 6), totalReal: bib.total, ampliada: bib.ampliada, porPagina },
        eie: eieInfo,
        inteligencia_dados: { ...inteligenciaDados, comportamento_agregado: comportamentoAgregado },
        oportunidade: detectarOportunidade({ tema: topico, estado: cl.estado, rotulo: ROTULO[cl.estado], crescimento: cl.crescimento, evid, ideiasN: ideiasBase.length, ramo: (ramo && RAMOS[ramo]?.rotulo) || null }),
        videos: videosYt,
        repertorio: blocoRepertorio(repRaw, topico, repTermos.associados, `${uid}:${new Date().toISOString().slice(0, 10)}`),
        telemetria: {
          fontes_ms: msFontes,
          pesquisa_avancada_ms: pesquisaAvancada.ms,
          pesquisa_avancada_etapas: pesquisaAvancada.etapas || {},
          eie_ms: eieInfo.ms || null,
        },
        conhecimento: conhecimento ? {
          versao: "eke-v1",
          adquirido: true,
          termo: conhecimento.termo,
          tipo: conhecimento.tipo,
          confianca: conhecimento.confianca,
          necessitaDesambiguacao: conhecimento.necessitaDesambiguacao,
          significados: conhecimento.significados,
          termosRelacionados: conhecimento.termosRelacionados.slice(0, 16),
          fontes: conhecimento.fontes,
          perguntasPesquisa: criarPerguntasPesquisa(conhecimento.termo),
        } : { versao: "eke-v1", adquirido: false },
        pesquisa_avancada: {
          ...pesquisaAvancada,
          resultados: pesquisaAvancada.resultados.slice(0, 12).map((x) => ({ ...x, snippet: String(x.snippet || "").slice(0, 500) })),
        },
      };
      const resultado = {
        ...recortaPorPlano(completo, plano, bioSugerida({ ...perfilIdeias, cidade: prep.ctx.permissoes.local ? (perfil?.cidade as string | null) : null }, interesse)),
        uso: { mes: (mes || 0) + 1, limite: LIMITE[plano], plano },
      };
      const { error: errIns } = await adm.from("evolui_buscas").insert({ user_id: uid, termo, nivel: "brasil", estado_tendencia: cl.estado, resultado, ip_hash: await ipHash(req) });
      if (errIns) console.error("historico:", errIns.message);
      try {
        await adm.rpc("evolui_registrar_sinal_agregado", {
          p_tema: topico,
          p_ramo: (ramo && RAMOS[ramo]?.rotulo) || ramo || null,
          p_origem: "pesquisa",
        });
      } catch (e) {
        console.warn("registro agregado:", String(e));
      }
      // compatibilidade: a versão antiga do app (sem "v: 2") não sabe desenhar ideia travada
      if (corpo.v !== 2) return json(req, { ...resultado, ideias: resultado.ideias.filter((x) => !("bloqueado" in x)) });
      return json(req, resultado);
    }

    return json(req, { erro: "Ação desconhecida." }, 400);
  } catch (e) {
    console.error(acao, e instanceof Error ? e.message : e);
    return json(req, { erro: "Algo falhou do nosso lado. Tente de novo em instantes." }, 500);
  }
});
