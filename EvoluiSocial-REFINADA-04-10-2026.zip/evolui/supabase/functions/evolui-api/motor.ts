// Motor de tendências da EvoluiSocial — funções puras (sem rede), testáveis.
// Regra do produto: nunca inventar número. Fonte sem dado = "sem dado".

export type Serie = { fonte: string; dias: string[]; valores: number[]; minimo: number };

import { casaAssunto, normaliza, STOP } from "./consulta.ts";
export { normaliza };
import { OFICIOS, OFICIO_NEUTRO, RAMO_OFICIO, type Oficio } from "./eie/formato-dados.ts";

/** Últimos N dias (UTC) no formato AAAA-MM-DD, do mais antigo ao mais novo. */
export function ultimosDias(n: number, hoje = new Date()): string[] {
  const out: string[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(hoje.getUTCFullYear(), hoje.getUTCMonth(), hoje.getUTCDate() - i));
    out.push(d.toISOString().slice(0, 10));
  }
  return out;
}

/** Conta ocorrências por dia a partir de datas ISO (ou AAAAMMDD...). */
export function contaPorDia(datas: string[], dias: string[]): number[] {
  const mapa = new Map(dias.map((d) => [d, 0]));
  for (const raw of datas) {
    const iso = /^\d{8}/.test(raw) ? `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)}` : raw.slice(0, 10);
    if (mapa.has(iso)) mapa.set(iso, (mapa.get(iso) || 0) + 1);
  }
  return dias.map((d) => mapa.get(d) || 0);
}

const soma = (a: number[]) => a.reduce((x, y) => x + y, 0);

export type Sinal = {
  fonte: string; total14: number; ultimos7: number; anteriores7: number;
  crescimento: number | null; temSinal: boolean; pico: boolean; valores: number[];
};

export function sinal(s: Serie): Sinal {
  const v = s.valores.slice(-14);
  const ult = soma(v.slice(-7)), ant = soma(v.slice(0, 7));
  const total = soma(v);
  const temSinal = total >= s.minimo;
  const crescimento = temSinal ? (ult - ant) / Math.max(ant, 1) : null;
  const base = v.slice(0, -2), fim = v.slice(-2);
  const media = soma(base) / Math.max(base.length, 1);
  // pico: os 2 últimos dias explodem (3x a média) e concentram metade da semana
  const pico = temSinal && media > 0 && Math.max(...fim) > 3 * media && soma(fim) >= 0.5 * ult;
  return { fonte: s.fonte, total14: total, ultimos7: ult, anteriores7: ant, crescimento, temSinal, pico, valores: v };
}

export type Estado = "em_alta" | "crescendo" | "comecando" | "estavel" | "caindo" | "pico" | "insuficiente";

export function classifica(sinais: Sinal[], noGoogleHoje: boolean): {
  estado: Estado; confianca: "alta" | "media" | "baixa" | null; crescimento: number | null; fontes: number;
} {
  const com = sinais.filter((s) => s.temSinal);
  const n = com.length;
  if (n === 0) return { estado: noGoogleHoje ? "em_alta" : "insuficiente", confianca: noGoogleHoje ? "baixa" : null, crescimento: null, fontes: noGoogleHoje ? 1 : 0 };
  // crescimento combinado: mediana das fontes com sinal (resiste a uma fonte maluca)
  const cs = com.map((s) => s.crescimento as number).sort((a, b) => a - b);
  const mediana = cs.length % 2 ? cs[(cs.length - 1) / 2] : (cs[cs.length / 2 - 1] + cs[cs.length / 2]) / 2;
  const fontes = n + (noGoogleHoje ? 1 : 0);
  const confianca = fontes >= 3 ? "alta" : fontes === 2 ? "media" : "baixa";
  let estado: Estado;
  if (noGoogleHoje) estado = "em_alta";
  else if (com.some((s) => s.pico)) estado = "pico";
  else if (mediana >= 0.25) estado = n >= 2 ? "crescendo" : "comecando";
  else if (mediana <= -0.15) estado = "caindo";
  else estado = "estavel";
  return { estado, confianca, crescimento: Math.round(mediana * 100) / 100, fontes };
}

export const ROTULO: Record<Estado, string> = {
  em_alta: "Em alta", crescendo: "Crescendo", comecando: "Começando", estavel: "Estável",
  caindo: "Caindo", pico: "Pico passageiro", insuficiente: "Dados insuficientes",
};

/** Lê o RSS público do Google Trends (buscas em alta do dia). */
export function parseTrendsRss(xml: string) {
  const itens: { termo: string; trafego: string | null; noticia: string | null; link: string | null }[] = [];
  const blocos = xml.split("<item>").slice(1);
  const tira = (s: string) => s.replace(/<!\[CDATA\[|\]\]>/g, "").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();
  for (const b of blocos) {
    const t = b.match(/<title>([\s\S]*?)<\/title>/);
    if (!t) continue;
    const tr = b.match(/<ht:approx_traffic>([\s\S]*?)<\/ht:approx_traffic>/);
    const nt = b.match(/<ht:news_item_title>([\s\S]*?)<\/ht:news_item_title>/);
    const nu = b.match(/<ht:news_item_url>([\s\S]*?)<\/ht:news_item_url>/);
    itens.push({ termo: tira(t[1]), trafego: tr ? tira(tr[1]) : null, noticia: nt ? tira(nt[1]) : null, link: nu ? tira(nu[1]) : null });
  }
  return itens;
}

/** Todas as palavras com conteúdo do termo aparecem no texto (ignora "para", "de", acento e plural). */
export function casaTermo(termo: string, texto: string): boolean {
  return casaAssunto(normaliza(termo).split(" ").filter((w) => !STOP.has(w)), texto);
}

// ---------- Ideias (regras, sem IA) — personalizadas pelo agente de perfil ----------
export type Perfil = { ramo?: string | null; ramo_detalhe?: string | null; cidade?: string | null; objetivo?: string | null; nome?: string | null };
export type Interesse = { termos?: string[]; formatos?: Record<string, number>; respostas?: Record<string, string> };

const CTA: Record<string, string> = {
  vender: "Peça pelo WhatsApp (link na bio)",
  crescer: "Siga para ver mais ideias como esta",
  engajar: "Comente o que você achou",
  lancar: "Responda QUERO para receber primeiro",
};
const CTA_CANAL: Record<string, string> = {
  "WhatsApp": "Chame no WhatsApp (link na bio)",
  "Direct do Instagram": "Mande um direct que eu te respondo",
  "Loja física": "Passe na loja e conheça de perto",
  "Site ou app de entrega": "Peça pelo app ou pelo site (link na bio)",
};
const HORARIO: Record<string, string> = { "Manhã": "entre 8h e 10h", "Almoço": "entre 11h30 e 13h", "Fim da tarde": "entre 17h e 19h", "Noite": "entre 19h e 21h" };
// formato -> palavra-chave para casar com o que a pessoa prefere
const FORMATO_CHAVE: Record<string, string> = { "Reels": "Reels", "Carrossel": "Carrossel", "Stories": "Stories", "Foto única": "Foto" };

export type Ideia = { formato: string; gancho: string; roteiro: string[]; legenda: string; porque: string; dica?: string };

/** `op.local === false`: o texto não pode citar a cidade (o EIE só libera quando há loja física ou pedido local). Sem `op`, mantém o comportamento antigo. */
export function ideias(termo: string, estado: Estado, p: Perfil, it: Interesse = {}, op: { local?: boolean } = {}): Ideia[] {
  const resp = it.respostas || {};
  const ramo = p.ramo || "seu negócio";
  const local = p.cidade && op.local !== false ? ` em ${p.cidade}` : "";
  const cta = (p.objetivo === "vender" || !p.objetivo) && resp.canal_venda && CTA_CANAL[resp.canal_venda]
    ? CTA_CANAL[resp.canal_venda] : (CTA[p.objetivo || "vender"] || CTA.vender);
  const semRosto = resp.aparecer === "Prefiro não aparecer" || resp.aparecer === "Só a voz";
  const tom = resp.tom || "";
  const emoji = tom === "Profissional" || tom === "Direto ao ponto" ? "" : " ✨";
  // só o que o usuário informou: o horário vem da resposta dele, não de uma estatística nossa
  const dica = resp.horario && HORARIO[resp.horario] ? `Você indicou esse horário: poste ${HORARIO[resp.horario]}.` : "";
  const quando = dica ? ` ${dica}` : "";
  // texto de reserva (usado só se o EIE não responder): cada ideia diz o que ela é, sem justificativa global nem alegação sem fonte
  const porque = (extra: string) => `${extra}.${quando}`;
  // Ofício: o assunto buscado (se casar com um ofício) > o que a pessoa informou (detalhe) > o ramo. O texto vem do vocabulário do ofício, não do assunto encaixado em frase pronta.
  const of = acharOficio(p, termo);
  const topico = of.porTermo ? "" : termo;
  const T = (base: string) => (topico ? `${cap(topico)}: ${base}` : cap(base));
  const q = (x: string) => `"${x}"`;
  const lista: Ideia[] = [
    {
      formato: "Reels de 15 a 20 s",
      gancho: of.generico ? q(topico ? `O que quase ninguém vê em ${topico}` : "O que quase ninguém vê no meu trabalho") : q(T(`quase ninguém vê ${of.o.invisivel}`)),
      roteiro: [
        semRosto ? `Sem mostrar o rosto: enquadre mãos, objeto ou tela mostrando ${of.o.cena}, nos 2 primeiros segundos` : `Abra mostrando ${of.o.cena} nos 2 primeiros segundos`,
        `Mostre em um corte rápido ${of.o.etapas[1][1]}`, `Feche com ${of.o.resultado}, de perto, e diga o próximo passo`],
      legenda: of.generico && topico ? `Um olhar de perto em ${topico}${emoji}\nMostro como o meu trabalho se liga a esse assunto.\n${cta}.` : `Poucos veem ${of.o.invisivel}${emoji}\nNeste vídeo, tudo gira em torno ${de(of.o.decisao)}.\n${cta}.`,
      porque: porque(`Vídeo curto que mostra ${of.o.invisivel}`), dica,
    },
    {
      formato: "Carrossel de 5 imagens",
      gancho: of.generico && topico ? q(`${cap(topico)}: o que vale saber antes de escolher`) : q(T(topico ? `o erro mais comum ${de(of.o.publico)}` : `o erro mais comum ${de(of.o.publico)} sobre ${of.o.decisao}`)),
      roteiro: of.generico && topico ? ["Capa com a pergunta que seu público faz", "Slides 2 a 4: uma dica por slide, com algo que você já viu acontecer", "Último slide: como falar com você"] : ["Capa com o erro, em uma frase", "Slide 2: por que esse erro acontece", `Slides 3 e 4: o jeito certo, mostrando ${of.o.ferramenta}`, `Último slide: ${of.o.resultado} e como falar com você`],
      legenda: `Salve para conferir depois${emoji ? " 📌" : ""}\n${of.generico && topico ? `${cap(topico)}: o que vale saber antes de escolher.` : `O erro mais comum ${de(of.o.publico)} e o jeito certo de evitar.`}\n${cta}.`,
      porque: porque("Carrossel que aponta um erro e mostra a correção"), dica,
    },
    {
      formato: "Stories com enquete",
      gancho: of.generico && topico ? q(`Qual parte de ${topico} você quer ver primeiro?`) : q(`Qual você escolheria: ${of.o.antes} ou ${of.o.depois}?`),
      roteiro: [`Story 1: mostre ${of.o.antes}`, `Story 2: enquete com as duas opções: ${of.o.antes} ou ${of.o.depois}`, `Story 3: mostre ${of.o.depois} e responda quem votou com um convite`],
      legenda: `Enquete do dia: ${of.o.antes} ou ${of.o.depois}?${emoji ? " 👀" : ""}`,
      porque: porque("Enquete que compara dois pontos do seu trabalho e convida a responder"), dica,
    },
    {
      formato: "Bastidores em vídeo",
      gancho: q(T(`o que acontece antes ${de(of.o.resultado)}`)),
      roteiro: [`Abra com ${of.o.resultado} (1 s)`, `Volte ao começo e mostre 3 etapas: ${of.o.etapas.slice(0, 3).map((e) => e[0]).join(", ")}`, semRosto ? "Narre com a voz ou use texto na tela" : "Termine olhando para a câmera com o convite"],
      legenda: `${of.generico && topico ? `Por trás do meu trabalho com ${topico}, tem cuidado em cada etapa` : `Por trás ${de(of.o.resultado)}, tem ${of.o.invisivel}`}${emoji}\nQuem acompanha o processo entende o valor.\n${cta}.`,
      porque: porque("Bastidores que mostram as etapas reais do seu trabalho"), dica,
    },
    {
      formato: "Post em parceria",
      gancho: of.generico && topico ? q(`${cap(topico)} + um perfil que atende o mesmo público`) : q(T(`uma parceria que ajuda ${of.o.publico}`)),
      roteiro: ["Escolha um perfil que atenda o mesmo público e não concorra com você", `Combine o que cada um mostra: você mostra ${of.o.resultado}`, "Publique pelo recurso Collab do Instagram, para o post aparecer nos dois perfis"],
      legenda: `Juntamos forças${local}${emoji}\n${of.generico && topico ? `${cap(topico)} com quem também entende do assunto.` : `Este conteúdo une ${of.o.resultado} ao trabalho de outro perfil.`}\nMarque quem precisa ver isso.`,
      porque: porque("Parceria com outro perfil que fala com o mesmo público"), dica,
    },
  ];
  if (estado === "pico") lista[0].porque = `${ROTULO[estado]} nas fontes analisadas: é um pico, publique logo ou não publique. ` + lista[0].porque;
  if (estado === "caindo") lista.forEach((b) => (b.porque += " O interesse no tema está caindo: use como gancho, não como campanha."));
  // ordena pelo que a pessoa prefere (resposta do dia + ideias que ela salvou/copiou)
  const pref = FORMATO_CHAVE[resp.formato_preferido || ""] || "";
  const forms = it.formatos || {};
  const peso = (i: Ideia) => (pref && i.formato.includes(pref) ? 100 : 0) + (forms[i.formato] || 0);
  return lista.map((x, i) => ({ x, i })).sort((a, b) => peso(b.x) - peso(a.x) || a.i - b.i).map((o) => o.x);
}
// ---------- Ofício (vocabulário por tipo de trabalho; mesmo léxico do Format Intelligence) ----------
const casaGatilho = (t: string, g: string) => g.length <= 4 ? new RegExp(`(^| )${g.trim()}(s|es)?( |$)`).test(t) : new RegExp(`(^| )${g.trim()}`).test(t);
function acharOficio(p: Perfil, termo: string): { o: Oficio; generico: boolean; porTermo: boolean } {
  const por = (txt: string | null | undefined) => {
    const t = normaliza(txt || "");
    return t ? OFICIOS.find((o) => o.gatilhos.some((g) => casaGatilho(t, g))) : undefined;
  };
  // o que a pessoa buscou manda: quem busca "designer" recebe ideias de design, mesmo que o negócio cadastrado seja outro
  const t = por(termo); if (t) return { o: t, generico: false, porTermo: true };
  const d = por(p.ramo_detalhe); if (d) return { o: d, generico: false, porTermo: false };
  const r = por(p.ramo) || OFICIOS.find((o) => o.id === RAMO_OFICIO[normaliza(p.ramo || "")] || o.id === RAMO_OFICIO[p.ramo || ""]);
  // "serviços profissionais" é amplo demais (designer, consultor, advogado...): sem detalhe, fica neutro
  if (r && r.id !== "servicos") return { o: r, generico: false, porTermo: false };
  return { o: OFICIO_NEUTRO, generico: true, porTermo: false };
}
/** true quando o assunto buscado não casa com nenhum ofício cadastrado (candidato a novo ofício em evolui_oficios) */
export function termoSemOficio(termo: string): boolean {
  const t = normaliza(termo || "");
  return !!t && !OFICIOS.some((o) => o.gatilhos.some((g) => casaGatilho(t, g)));
}
const de = (x: string) => { const m = x.match(/^(o|a|os|as)\s+(.*)$/i); return m ? `${({ o: "do", a: "da", os: "dos", as: "das" } as Record<string, string>)[m[1].toLowerCase()]} ${m[2]}` : `de ${x}`; };
function cap(s: string) { return s ? s[0].toUpperCase() + s.slice(1) : s; }

/** Bio sugerida (até 150 caracteres, limite do Instagram). */
export function bioSugerida(p: Perfil, it: Interesse = {}): string {
  const resp = it.respostas || {};
  const oque = (p.ramo_detalhe || p.ramo || "Seu negócio").trim();
  const ondeTxt = p.cidade ? ` em ${p.cidade}` : "";
  const dif: Record<string, string> = { "Qualidade": "Feito com capricho", "Preço": "Preço justo", "Atendimento": "Atendimento de perto", "Rapidez": "Entrega rápida" };
  const linha2 = dif[resp.diferencial || ""] || "Feito com capricho";
  const canal = resp.canal_venda === "Direct do Instagram" ? "Peça pelo direct ↓" : resp.canal_venda === "Loja física" ? "Venha conhecer ↓" : "Peça pelo WhatsApp ↓";
  let bio = `${cap(oque)}${ondeTxt}\n${linha2}\n${canal}`;
  if (bio.length > 150) bio = `${cap(oque)}\n${canal}`.slice(0, 150);
  return bio;
}

// ---------- Planos: o servidor só manda o que o plano libera ----------
export const PLANO_LIBERA: Record<string, { ideias: number; noticias: number; relacionados: number; dias: number; bio: boolean; local: boolean }> = {
  free: { ideias: 1, noticias: 2, relacionados: 3, dias: 14, bio: false, local: false },
  pro: { ideias: 3, noticias: 6, relacionados: 6, dias: 28, bio: true, local: true },
  master: { ideias: 5, noticias: 10, relacionados: 10, dias: 28, bio: true, local: true },
};
export function planoQueLibera(indiceIdeia: number): "pro" | "master" {
  return indiceIdeia < PLANO_LIBERA.pro.ideias ? "pro" : "master";
}
type Bloqueado = { bloqueado: true; formato: string; plano: "pro" | "master" };
/** Corta o resultado conforme o plano. O conteúdo travado NÃO é enviado (só o formato e o plano que libera). */
export function recortaPorPlano<T extends { ideias: Ideia[]; noticias: unknown[]; relacionados: string[]; series: { fonte: string; dias: string[]; valores: number[] }[] }>(
  r: T, plano: string, bio: string | null,
) {
  const L = PLANO_LIBERA[plano] || PLANO_LIBERA.free;
  const ideiasOut: (Ideia | Bloqueado)[] = r.ideias.map((d, i) => i < L.ideias ? d : { bloqueado: true, formato: d.formato, plano: planoQueLibera(i) });
  return {
    ...r,
    ideias: ideiasOut,
    noticias: r.noticias.slice(0, L.noticias),
    noticiasBloqueadas: Math.max(0, r.noticias.length - L.noticias),
    relacionados: r.relacionados.slice(0, L.relacionados),
    series: r.series.map((s) => ({ ...s, dias: s.dias.slice(-L.dias), valores: s.valores.slice(-L.dias) })),
    bio: L.bio ? bio : null,
    bioBloqueada: !L.bio,
    plano,
  };
}

// palavras que indicam o sentido certo de uma página ambígua para cada ramo ("Brigadeiro (doce)" e não a patente militar)
export const CONTEXTO_RAMO: Record<string, string[]> = {
  doces: ["doce", "culinaria", "confeitaria", "sobremesa", "bolo", "gastronomia", "alimento"],
  alimentacao: ["culinaria", "comida", "prato", "alimento", "gastronomia", "bebida"],
  beleza: ["estetica", "cosmetico", "cabelo", "beleza", "maquiagem"],
  moda: ["vestuario", "moda", "roupa", "calcado", "acessorio"],
  saude: ["medicina", "saude", "odontologia", "terapia"],
  fitness: ["exercicio", "esporte", "treino", "ginastica"],
  pet: ["animal", "cao", "gato", "pet", "veterinaria"],
  casa: ["decoracao", "mobiliario", "arquitetura", "jardinagem"],
  educacao: ["educacao", "ensino", "curso"],
  servicos: ["direito", "contabilidade", "profissao", "empresa"],
};

/** Escolhe a página da Wikipédia: título exato (com redirecionamento) > título que casa com o termo.
 *  Evita "Advocacia-Geral da União" para "advocacia" e usa o ramo para desempatar páginas ambíguas. */
export function escolheTitulo(termo: string, exato: string | null, titulos: string[], ramo?: string | null): string | null {
  const ctx = (ramo && CONTEXTO_RAMO[ramo]) || [];
  const base = normaliza(exato || termo);
  if (ctx.length) {
    const sentido = titulos.find((x) => {
      const m = x.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").match(/^(.*) \((.*)\)$/);
      return m && m[1] === base && ctx.some((c) => m[2].includes(c));
    });
    if (sentido) return sentido;
  }
  if (exato) return exato;
  const t = normaliza(termo);
  const bons = titulos.filter((x) => casaTermo(termo, x) && normaliza(x).length <= t.length + 18 && !/\(desambigua/i.test(x));
  const comeca = bons.find((x) => normaliza(x).startsWith(t.split(" ")[0].slice(0, Math.max(3, t.split(" ")[0].length - 1))) && !normaliza(x).includes("-"));
  return comeca || bons[0] || null;
}

/** Valida as notícias que o navegador da pessoa buscou no GDELT (nunca confiamos cegamente). */
export function validaNoticiasCliente(x: unknown, dias: string[]): { datas: string[]; artigos: { titulo: string; url: string; site: string; data: string }[] } | null {
  if (!x || typeof x !== "object") return null;
  const o = x as { datas?: unknown; artigos?: unknown };
  if (!Array.isArray(o.datas) || o.datas.length > 250 || !Array.isArray(o.artigos) || o.artigos.length > 10) return null;
  const ini = dias[0].replaceAll("-", ""), fim = dias[dias.length - 1].replaceAll("-", "");
  const datas = (o.datas as unknown[]).filter((d): d is string => typeof d === "string" && /^\d{8}(T\d{6}Z)?$/.test(d) && d.slice(0, 8) >= ini && d.slice(0, 8) <= fim);
  const artigos = (o.artigos as unknown[]).flatMap((a) => {
    if (!a || typeof a !== "object") return [];
    const v = a as Record<string, unknown>;
    const url = String(v.url || ""), titulo = String(v.titulo || "").slice(0, 300), site = String(v.site || "").slice(0, 100), data = String(v.data || "").slice(0, 8);
    if (!/^https:\/\/[^\s"<>]+$/.test(url) || url.length > 600 || !titulo) return [];
    return [{ titulo, url, site, data: /^\d{8}$/.test(data) ? data : "" }];
  });
  return { datas, artigos };
}

// ---------- Ramos → etiquetas do OpenStreetMap ----------
export const RAMOS: Record<string, { rotulo: string; osm: string[] }> = {
  doces: { rotulo: "Doces e confeitaria", osm: ['shop=confectionery', 'shop=pastry', 'shop=bakery', 'amenity=ice_cream'] },
  alimentacao: { rotulo: "Alimentação e restaurantes", osm: ['amenity=restaurant', 'amenity=fast_food', 'amenity=cafe'] },
  beleza: { rotulo: "Beleza e estética", osm: ['shop=hairdresser', 'shop=beauty', 'shop=cosmetics'] },
  moda: { rotulo: "Moda e acessórios", osm: ['shop=clothes', 'shop=shoes', 'shop=boutique', 'shop=jewelry'] },
  saude: { rotulo: "Saúde e bem-estar", osm: ['amenity=dentist', 'amenity=clinic', 'healthcare=physiotherapist'] },
  fitness: { rotulo: "Academia e fitness", osm: ['leisure=fitness_centre', 'leisure=sports_centre'] },
  pet: { rotulo: "Pet", osm: ['shop=pet', 'amenity=veterinary'] },
  casa: { rotulo: "Casa e decoração", osm: ['shop=furniture', 'shop=interior_decoration', 'shop=houseware'] },
  educacao: { rotulo: "Educação e cursos", osm: ['amenity=school', 'amenity=language_school', 'amenity=driving_school'] },
  servicos: { rotulo: "Serviços profissionais", osm: ['office=lawyer', 'office=accountant', 'office=estate_agent'] },
  criador: { rotulo: "Marca pessoal / criador", osm: [] },
  outro: { rotulo: "Outro", osm: [] },
};

export function consultaOverpass(lat: number, lon: number, ramo: string, raioM = 8000): string | null {
  const r = RAMOS[ramo];
  if (!r || !r.osm.length || !Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  const perto = `around:${Math.round(raioM)},${lat.toFixed(5)},${lon.toFixed(5)}`;
  const partes = r.osm.map((t) => { const [k, v] = t.split("="); return `nwr["${k}"="${v}"](${perto});`; }).join("");
  return `[out:json][timeout:15];(${partes});out count;`;
}

// ---------- Termos do ramo (sugestões "Para você") ----------
export const TERMOS_RAMO: Record<string, string[]> = {
  doces: ["bolo no pote", "brigadeiro gourmet", "doces para festa", "bolo de aniversário", "cesta de café da manhã"],
  alimentacao: ["marmita", "hambúrguer artesanal", "delivery", "comida saudável", "açaí"],
  beleza: ["corte de cabelo", "unhas", "skincare", "design de sobrancelha", "maquiagem"],
  moda: ["moda praia", "moda feminina", "tênis", "bijuteria", "moda fitness"],
  saude: ["saúde mental", "clareamento dental", "fisioterapia", "nutrição", "harmonização facial"],
  fitness: ["musculação", "treino funcional", "pilates", "corrida", "crossfit"],
  pet: ["banho e tosa", "ração natural", "adestramento", "petshop", "veterinário"],
  casa: ["decoração", "móveis planejados", "marmoraria", "plantas", "organização da casa"],
  educacao: ["curso online", "inglês", "concurso", "reforço escolar", "ENEM"],
  servicos: ["contabilidade", "advocacia", "imobiliária", "marketing digital", "energia solar"],
  criador: ["marca pessoal", "criador de conteúdo", "reels", "podcast", "LinkedIn"],
  outro: ["pequenos negócios", "empreendedorismo", "vendas", "instagram", "MEI"],
};

/** "Para você": mistura o que a pessoa já pesquisou, o ramo dela e o que está em alta hoje e casa com o ramo. */
export function paraVoce(ramo: string | null | undefined, it: Interesse, emAlta: { termo: string }[]): { termo: string; motivo: string }[] {
  const out: { termo: string; motivo: string }[] = [];
  const visto = new Set<string>();
  const add = (termo: string, motivo: string) => { const k = normaliza(termo); if (!k || visto.has(k)) return; visto.add(k); out.push({ termo, motivo }); };
  const base = TERMOS_RAMO[ramo || "outro"] || TERMOS_RAMO.outro;
  for (const a of emAlta) if (base.some((b) => casaTermo(b.split(" ")[0], a.termo))) add(a.termo, "Em alta hoje no Google");
  for (const t of (it.termos || []).slice(0, 3)) add(t, "Você pesquisou");
  for (const t of base) add(t, "Do seu ramo");
  return out.slice(0, 8);
}
