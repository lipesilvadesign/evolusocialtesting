// EvoluiSocial — entendimento da pesquisa (funções puras, sem rede, testáveis).
// Transforma o que a pessoa digitou em: assunto (do que ela fala), intenções (o que ela quer),
// formato (como quer postar), termos para cada fonte e sinônimos. "Simplicidade na frente, inteligência por trás."

export function normaliza(s: string): string {
  return String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9#@\s-]/g, " ").replace(/\s+/g, " ").trim();
}

// palavras que não carregam assunto (comparadas já normalizadas, sem acento)
export const STOP = new Set((
  "a o as os um uma uns umas de da do das dos d em no na nos nas num numa para pra pro pros pras por pelo pela pelos pelas com sem " +
  "que e ou ao aos se me te lhe nos vos meu minha meus minhas seu sua seus suas teu tua eu tu ele ela eles elas voce voces vc vcs " +
  "como qual quais quem onde quando porque pq quero queria quer preciso precisa precisando gostaria fazer faco faz fazendo ter tenho tem " +
  "ser sou estar estou esta isso esse essa este esta aquele aquela algo algum alguma alguns coisa coisas tipo jeito forma maneira " +
  "mais muito muita muitos muitas pouco pouca bem melhor melhores bom boa bons boas novo nova novos novas sobre ate ja so tambem " +
  "nao sim mas entao aqui ai la hoje agora dia dias vez vezes mim ajuda ajudar dica dicas modo"
).split(" "));

// verbos de ação: dizem o que a pessoa quer fazer, não do que ela fala
export const VERBOS = new Set((
  "conseguir consigo ganhar ganho aumentar aumento atrair conquistar crescer melhorar criar gravar usar divulgar mostrar chamar trazer " +
  "saber sei postar posto publicar fazer montar escrever aprender entender comecar iniciar ajudar deixar pegar subir bombar alavancar " +
  "achar encontrar descobrir pensar planejar organizar vender gerar chamar atingir acontece acontecendo ocorrer ocorrendo passa passando"
).split(" "));

// palavras de formato/canal: não são o assunto, viram o "formato" da busca
export const GENERICAS = new Set((
  "video videos post posts postagem postagens postar publicar publicacao conteudo conteudos ideia ideias reels reel story stories " +
  "carrossel carrosseis foto fotos imagem imagens live lives legenda legendas instagram insta ig tiktok tik tok youtube yt shorts " +
  "rede redes social sociais perfil perfis pagina feed facebook fb linkedin whatsapp zap wpp"
).split(" "));

const FORMATOS: [RegExp, string][] = [
  [/\b(video|videos|reels?|tiktok|shorts)\b/, "reels"],
  [/\b(carross[ea]is?|carrossel)\b/, "carrossel"],
  [/\b(stor(y|ies)|storys)\b/, "stories"],
  [/\b(foto|fotos|imagem|imagens)\b/, "foto"],
  [/\b(lives?|ao vivo)\b/, "live"],
];

/** Plural e variações simples do português (só para comparar; nunca para mostrar). */
export function radical(w: string): string {
  w = normaliza(w);
  if (w.length <= 3) return w;
  if (w === "maes") return "mae";
  if (w.endsWith("oes") || w.endsWith("aes")) return w.slice(0, -3) + "ao";
  if (w.endsWith("ais")) return w.slice(0, -3) + "al";
  if (w.endsWith("eis") && w.length > 5) return w.slice(0, -3) + "el";
  if (w.endsWith("ns")) return w.slice(0, -2) + "m";
  if (/(r|z|l)es$/.test(w) && w.length > 5) return w.slice(0, -2);
  if (w.endsWith("s") && !w.endsWith("ss") && !/(is|us)$/.test(w)) return w.slice(0, -1);
  return w;
}

/** Distância de edição (com troca de letras vizinhas), limitada para ser rápida. */
export function distancia(a: string, b: string, max = 2): number {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  const d: number[][] = Array.from({ length: a.length + 1 }, (_, i) => Array.from({ length: b.length + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0)));
  for (let i = 1; i <= a.length; i++) {
    let menor = Infinity;
    for (let j = 1; j <= b.length; j++) {
      const c = a[i - 1] === b[j - 1] ? 0 : 1;
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c);
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
      menor = Math.min(menor, d[i][j]);
    }
    if (menor > max) return max + 1;
  }
  return d[a.length][b.length];
}

// ---------------------------------------------------------------- intenções
// gatilhos: radicais/expressões já normalizados. expande: termos que também valem a pena buscar.
export type Intencao = { id: string; rotulo: string; gatilhos: string[]; expande: string[] };
export const INTENCOES: Intencao[] = [
  { id: "seguidores", rotulo: "Ganhar seguidores", gatilhos: ["seguidor", "seguir", "seguidore", "crescer perfil", "crescer o perfil", "crescer no", "crescimento", "audiencia", "comunidade", "fa", "atrair publico", "publico novo"], expande: ["ganhar seguidores", "aumentar seguidores", "crescer perfil", "atrair publico", "conquistar seguidores", "ideias de video para crescer", "aumentar alcance"] },
  { id: "alcance", rotulo: "Aumentar o alcance", gatilhos: ["alcance", "alcancar", "viral", "viraliz", "visualizac", "view", "aparecer mais", "entrega", "algoritmo", "explorar", "ser visto"], expande: ["aumentar alcance", "viralizar", "algoritmo", "mais visualizacoes", "aparecer no explorar"] },
  { id: "engajamento", rotulo: "Engajar quem já segue", gatilhos: ["engaj", "comentario", "curtida", "interac", "salvament", "compartilh", "conversa"], expande: ["engajamento", "comentarios", "interacao", "salvamentos", "compartilhamentos"] },
  { id: "vendas", rotulo: "Vender mais", gatilhos: ["vend", "venda", "cliente", "compr", "pedido", "encomenda", "faturar", "faturamento", "lucr", "converter"], expande: ["vender mais", "atrair clientes", "chamada para acao", "oferta", "prova social"] },
  { id: "ideias", rotulo: "Ideias do que postar", gatilhos: ["o que postar", "nao sei o que", "sem ideia", "ideia", "conteudo", "inspiracao", "inspirar", "criatividade", "bloqueio", "pauta", "sobre o que"], expande: ["ideias de conteudo", "inspiracao", "pautas", "formatos", "tendencias"] },
  { id: "planejamento", rotulo: "Planejar e ter constância", gatilhos: ["planej", "calendario", "cronograma", "organiz", "rotina de post", "rotina de publica", "rotina de conteudo", "rotina semanal de", "constancia", "frequencia", "quantas vezes", "agenda"], expande: ["calendario de posts", "planejamento", "constancia", "frequencia de postagem"] },
  { id: "primeiros", rotulo: "Começar do zero", gatilhos: ["comec", "iniciante", "do zero", "primeiro post", "primeiros post", "perfil novo", "criar perfil", "nunca postei"], expande: ["primeiros posts", "comecar do zero", "perfil novo", "primeiros conteudos"] },
  { id: "tendencias", rotulo: "Tendências", gatilhos: ["tendencia", "em alta", "trend", "viralizando", "moda do momento"], expande: ["tendencias", "em alta", "trends"] },
  { id: "bio", rotulo: "Melhorar a bio", gatilhos: ["bio", "biografia", "descricao do perfil"], expande: ["bio", "biografia do instagram", "link na bio"] },
  { id: "legenda", rotulo: "Escrever legendas", gatilhos: ["legenda", "texto do post", "copy", "escrever", "chamada"], expande: ["legenda", "gancho", "chamada para acao", "copy"] },
  { id: "autoridade", rotulo: "Passar confiança", gatilhos: ["autoridade", "confianca", "credibilidade", "especialista", "ser referencia", "profissionalismo"], expande: ["autoridade", "bastidores", "depoimentos", "prova social"] },
  { id: "local", rotulo: "Atrair gente da cidade", gatilhos: ["bairro", "cidade", "regiao", "perto", "local", "vizinh", "loja fisica"], expande: ["publico local", "negocio local", "clientes da regiao"] },
  { id: "lancamento", rotulo: "Lançar algo novo", gatilhos: ["lanc", "novidade", "produto novo", "inaugur", "estreia"], expande: ["lancamento", "novidade", "contagem regressiva"] },
  { id: "promocao", rotulo: "Promoção e oferta", gatilhos: ["promoc", "desconto", "oferta", "cupom", "liquidac", "black friday", "queima"], expande: ["promocao", "oferta", "cupom", "urgencia"] },
  { id: "datas", rotulo: "Datas comemorativas", gatilhos: ["dia das maes", "dia dos pais", "dia das criancas", "dia dos namorados", "natal", "pascoa", "sao joao", "data comemorativa", "fim de ano", "black friday"], expande: ["datas comemorativas", "campanha sazonal"] },
  // TODO(intencao x objetivo): hoje "intencao" mistura o que a pessoa QUER SABER (noticia, mercado, concorrencia...) com o que quer ALCANCAR
  // (seguidores, vendas...). A separacao em duas dimensoes sera feita fora daqui; os ids existentes seguem inalterados (EIE e colunas gravadas).
  { id: "noticia", rotulo: "Notícias do mercado", gatilhos: ["noticia", "novidade do mercado", "novidades do mercado", "aconteceu", "saiu", "ultimas do", "ultimas sobre"], expande: ["noticias", "novidades do mercado", "ultimas noticias"] },
  { id: "concorrencia", rotulo: "Concorrência", gatilhos: ["concorr", "quem mais faz", "rival", "benchmark"], expande: ["concorrentes", "concorrencia", "benchmark", "quem mais faz"] },
  { id: "mercado", rotulo: "Mercado", gatilhos: ["mercado de", "mercado do", "mercado da", "panorama", "segmento", "onde comprar", "quais lojas"], expande: ["mercado", "panorama", "segmento", "onde comprar"] },
  { id: "oportunidade", rotulo: "Oportunidades", gatilhos: ["oportunidade", "nicho", "o que falta", "onde crescer"], expande: ["oportunidades", "nichos", "onde crescer", "demanda"] },
  { id: "referencia", rotulo: "Referências", gatilhos: ["referencia", "exemplo", "inspiracao de perfi", "inspiracoes de perfi"], expande: ["referencias", "exemplos", "perfis de referencia"] },
  { id: "metrica", rotulo: "Métricas", gatilhos: ["metrica", "resultado", "desempenho", "taxa", "kpi"], expande: ["metricas", "resultados", "desempenho", "taxa de engajamento"] },
  { id: "estrategia", rotulo: "Estratégia", gatilhos: ["como divulgar", "divulgar", "estrategia", "posicionar", "posicionamento", "atrair cliente", "anunciar"], expande: ["estrategia", "como divulgar", "posicionamento", "atrair clientes"] },
];
const INTENCAO_POR_ID = new Map(INTENCOES.map((i) => [i.id, i]));

// Regra geral de confianca: gatilho de uma palavra so, curto e ambiguo, so vale com um SEGUNDO indicador
// (outra intencao nao ambigua, uma plataforma, ou uma cidade). Sem isso, nao vira intencao.
const AMBIGUOS = new Set(["fa", "view", "local", "perto", "copy", "agenda", "conversa", "entrega", "explorar", "chamada", "escrever", "cidade", "taxa"]);
// palavras ambiguas que descrevem o assunto: nunca consomem o texto do assunto
// gatilho fraco: vale sozinho, mas perde para qualquer outra intenção ("calendário de conteúdo" = planejamento)
const FRACOS = new Set(["conteudo"]);
const NAO_CONSOME = new Set(["local", "cidade", "perto", "agenda", "conversa", "entrega", "taxa", "chamada"]);

export const PLATAFORMAS: Record<string, string> = {
  instagram: "instagram", insta: "instagram", ig: "instagram", tiktok: "tiktok", youtube: "youtube", yt: "youtube",
  facebook: "facebook", fb: "facebook", linkedin: "linkedin", whatsapp: "whatsapp", zap: "whatsapp", wpp: "whatsapp",
};
// palavras que nunca sao cidade (alem de plataforma, formato, stop, verbos e gatilhos)
const NAO_CIDADE = new Set("beleza moda saude comida cosmeticos cosmetico skincare roupas pele cabelo estetica fitness pet pets doces bolos marketing negocios negocio mercado brasil instagram".split(" "));
const CIDADES_CONHECIDAS = new Set("petrolina recife juazeiro salvador fortaleza natal maceio aracaju teresina sao luis belem manaus goiania brasilia curitiba florianopolis porto alegre belo horizonte vitoria campinas santos osasco olinda caruaru garanhuns".split(" "));
const CONECTORES_CIDADE = new Set(["de", "da", "do", "dos", "das"]);
const PREP_CIDADE = new Set(["em", "de", "para", "pra", "na", "no"]);
const NEGOCIO_LOCAL = /\b(lojas?|empresas?|negocios?|estabelecimentos?|comercios?|clinicas?|saloes?|barbearias?|restaurantes?|lanchonetes?|academias?|mercadinhos?|padarias?|farmacias?)\b/;
const MARCADOR_MERCADO_LOCAL = /\b(quais|onde|lista|listar|encontre|encontrar|existem|concorrentes?|mercado|onde comprar)\b/;
const TEMPO = /^20\d{2}$/;


// vocabulário para corrigir erros de digitação (só em palavras de intenção/formato, nunca no assunto)
const VOCAB = Array.from(new Set([
  ...INTENCOES.flatMap((i) => i.gatilhos.filter((g) => !g.includes(" ") && g.length >= 5)),
  "seguidores", "engajamento", "visualizacoes", "inspiracao", "tendencias", "tendencia", "carrossel", "stories", "legenda", "legendas",
  "promocao", "lancamento", "planejamento", "calendario", "comentarios", "algoritmo", "biografia", "instagram", "conteudo", "conteudos",
  "postagem", "publicacao", "clientes", "vender", "vendas", "alcance", "viralizar",
]));

export type Consulta = {
  original: string;
  normalizado: string;
  palavras: string[];            // todas as palavras (normalizadas, já corrigidas)
  uteis: string[];               // sem palavras vazias
  radicais: string[];            // uteis no singular (para comparar)
  intencoes: { id: string; rotulo: string }[];
  formato: string | null;
  plataforma: string | null;     // instagram, tiktok... só quando a pessoa disse (nunca deduzida aqui)
  localizacao?: string | null;   // cidade dita ("em Petrolina"); null quando não há
  confianca?: "alta" | "media" | "baixa" | null; // da intenção; null quando não há intenção
  assunto: string;               // o "do que" (texto como a pessoa escreveu, sem as palavras de intenção)
  assuntoTokens: string[];       // assunto normalizado, sem palavras vazias
  ano?: string | null;           // ano explicitamente citado (ex.: 2026); não vira assunto
  modo: "palavra" | "intencao" | "misto";
  correcoes: { de: string; para: string }[];
  expansoes: string[];           // sinônimos/termos relacionados (normalizados)
  termosBusca: string[];         // radicais para a biblioteca (assunto + intenção + sinônimos)
};


/** Cidade dita na frase: preposição + palavra(s) Capitalizada(s) ("em Petrolina", "para Recife", "de Juazeiro do Norte").
 *  Plataforma, formato e palavras da taxonomia nunca são cidade. Cidades muito conhecidas valem também em minúsculas. */
function acharLocalizacao(orig: string[], pal: string[]): { nome: string; idx: number[]; prep: number } | null {
  const taxo = (w: string) => STOP.has(w) || VERBOS.has(w) || GENERICAS.has(w) || NAO_CIDADE.has(w) || !!PLATAFORMAS[w] || FORMATOS.some(([re]) => re.test(" " + w + " ")) ||
    INTENCOES.some((it) => it.gatilhos.some((g) => !g.includes(" ") && (w === g || (g.length >= 4 && w.startsWith(g)) || radical(w) === g)));
  const cap = (t: string) => /^\p{Lu}/u.test(t.replace(/[^\p{L}]/gu, ""));
  for (let i = 1; i < pal.length; i++) {
    if (!PREP_CIDADE.has(pal[i - 1])) continue;
    const a = pal[i];
    const conhecida = CIDADES_CONHECIDAS.has(a);
    if (taxo(a) || a.length < 3 || /\d/.test(a) || (!cap(orig[i]) && !conhecida)) continue;
    const idx = [i];
    let j = i + 1;
    while (j < pal.length) {
      if (cap(orig[j]) && !taxo(pal[j])) { idx.push(j); j++; }
      else if (CONECTORES_CIDADE.has(pal[j]) && j + 1 < pal.length && !taxo(pal[j + 1]) && (cap(orig[j + 1]) || (CIDADES_CONHECIDAS.has(a) && pal[j + 1].length >= 3))) { idx.push(j, j + 1); j += 2; }
      else break;
    }
    const nome = idx.map((k) => { const o = orig[k].replace(/[^\p{L}\p{N}-]/gu, ""); return CONECTORES_CIDADE.has(pal[k]) ? pal[k] : o.charAt(0).toUpperCase() + o.slice(1); }).join(" ");
    return { nome, idx, prep: i - 1 };
  }
  return null;
}

/** Entende a pesquisa. Nunca joga fora o que a pessoa digitou: só organiza. */
export function entender(texto: string): Consulta {
  const original = String(texto || "").replace(/\s+/g, " ").trim().slice(0, 120);
  const origTokens = original.split(" ").filter((t) => normaliza(t));
  const correcoes: { de: string; para: string }[] = [];
  let palavras = origTokens.map((t) => normaliza(t));
  // 0) cidade dita ("em Petrolina", "para Recife"): sai do assunto e não é corrigida nem lida como intenção
  const loc = acharLocalizacao(origTokens, palavras);
  const locIdx = new Set<number>(loc ? loc.idx : []);
  // 1) tolerância a erro de digitação (só em palavras de intenção/formato conhecidas)
  palavras = palavras.map((w, i) => {
    if (locIdx.has(i) || w.length < 5 || STOP.has(w) || GENERICAS.has(w) || VOCAB.includes(w) || VOCAB.includes(radical(w)) || /\d/.test(w)) return w;
    const max = w.length >= 8 ? 2 : 1;
    let melhor = "", dist = max + 1;
    for (const v of VOCAB) { const dd = distancia(w, v, max); if (dd < dist) { dist = dd; melhor = v; } }
    if (melhor && dist <= max) { correcoes.push({ de: w, para: melhor }); return melhor; }
    return w;
  });
  const frase = " " + palavras.join(" ") + " ";
  // 2) intenções: expressões inteiras primeiro, depois radicais
  const usados = new Set<number>(loc ? loc.idx : []);
  if (loc) usados.add(loc.prep);
  const achadas: { id: string; peso: number; ambiguo: boolean; marcar?: number[] }[] = [];
  for (const it of INTENCOES) {
    let peso = 0, ambiguo = true; // ambiguo: só gatilhos curtos de uma palavra
    const marcar: number[] = [];
    for (const g of it.gatilhos) {
      if (g.includes(" ")) {
        if (frase.includes(" " + g + " ") || frase.includes(" " + g)) {
          peso += 2; ambiguo = false;
          const gp = g.split(" ");
          for (let i = 0; i <= palavras.length - gp.length; i++) if (!locIdx.has(i) && gp.every((x, k) => palavras[i + k] === x || palavras[i + k].startsWith(x))) gp.forEach((_, k) => { if (!STOP.has(palavras[i + k])) marcar.push(i + k); });
        }
      } else {
        palavras.forEach((w, i) => {
          if (locIdx.has(i)) return;
          if (w === g || (g.length >= 4 && w.startsWith(g)) || radical(w) === g) {
            if (g.length <= 2 && w !== g) return; // "fa" só vale como palavra inteira
            if (FRACOS.has(g)) { peso += 0.5; ambiguo = false; marcar.push(i); }
            else if (AMBIGUOS.has(g)) { peso += 0.5; if (!NAO_CONSOME.has(g)) marcar.push(i); }
            else { peso += 1; ambiguo = false; marcar.push(i); }
          }
        });
      }
    }
    if (peso) { achadas.push({ id: it.id, peso, ambiguo, marcar }); }
  }
  // plataforma dita (instagram, insta, ig...): não é assunto nem cidade
  let plataforma: string | null = null;
  palavras.forEach((w, i) => { const pl = PLATAFORMAS[w]; if (pl && !locIdx.has(i)) { plataforma = plataforma || pl; usados.add(i); } });
  if (!plataforma && /\btik tok\b/.test(frase)) plataforma = "tiktok";
  // "lojas de X em <cidade>" / "quais clínicas em <cidade>": panorama local.
  // Categoria de negócio sozinha NÃO implica intenção de mercado (ex.: "ideias para barbearia em Caruaru").
  const mercadoLocal = !!loc && (
    MARCADOR_MERCADO_LOCAL.test(frase) ||
    (NEGOCIO_LOCAL.test(frase) && /\b(quais|onde|lista|listar|encontre|encontrar|existem)\b/.test(frase))
  );
  if (mercadoLocal) {
    // A categoria do negócio continua no assunto. Ela é essencial para a busca local
    // (ex.: "clínicas odontológicas em Recife"). A intenção "mercado" é uma dimensão
    // separada e não deve consumir o termo que identifica o universo pesquisado.
    const ex = achadas.find((a) => a.id === "mercado");
    if (ex) { ex.peso += 2; ex.ambiguo = false; } else achadas.push({ id: "mercado", peso: 2, ambiguo: false });
  }
  if (/\bquais\b.*\bexist/.test(frase) && !achadas.some((a) => a.id === "mercado")) achadas.push({ id: "mercado", peso: 2, ambiguo: false });
  // confiança: ambíguo sozinho não vale; com segundo indicador (outra intenção firme, plataforma ou cidade) vale com peso baixo
  const firmes = achadas.filter((a) => !a.ambiguo);
  const noticiaOuMercado = firmes.some((a) => a.id === "noticia" || a.id === "mercado");
  for (let k = achadas.length - 1; k >= 0; k--) {
    const a = achadas[k];
    if (!a.ambiguo) continue;
    const outro = firmes.some((f) => f.id !== a.id) || !!plataforma || (!!loc && a.id !== "local");
    if (!outro || (a.id === "local" && noticiaOuMercado)) achadas.splice(k, 1);
  }
  achadas.forEach((a) => (a.marcar || []).forEach((i) => usados.add(i)));
  achadas.sort((a, b) => b.peso - a.peso);
  // 3) formato
  let formato: string | null = null;
  for (const [re, f] of FORMATOS) if (re.test(frase)) { formato = f; break; }
  // 3b) formato sem nenhuma intenção ("reels para restaurante"): ideias, com confiança baixa
  let confianca: "alta" | "media" | "baixa" | null = null;
  if (achadas.length) confianca = achadas[0].peso >= 2 || achadas.length > 1 ? "alta" : "media";
  else if (formato) { achadas.push({ id: "ideias", peso: 0.5, ambiguo: false }); confianca = "baixa"; }
  // 4) assunto: o que sobra (mantém palavras vazias que ficam ENTRE palavras do assunto: "bolo no pote")
  const ehAssunto = palavras.map((w, i) => !usados.has(i) && !STOP.has(w) && !GENERICAS.has(w) && !VERBOS.has(w) && !TEMPO.test(w) && w.length >= 2);
  let ini = ehAssunto.indexOf(true), fim = ehAssunto.lastIndexOf(true);
  let assuntoIdx: number[] = [];
  if (ini >= 0) {
    // trecho contínuo mais longo, permitindo palavras vazias no meio
    let melhor: number[] = [], atual: number[] = [];
    for (let i = ini; i <= fim; i++) {
      if (ehAssunto[i]) atual.push(i);
      else if (STOP.has(palavras[i]) && atual.length && i < fim && ehAssunto.slice(i + 1).some(Boolean) && (ehAssunto[i + 1] || (STOP.has(palavras[i + 1]) && ehAssunto[i + 2]))) atual.push(i);
      else { if (atual.filter((k) => ehAssunto[k]).length > melhor.filter((k) => ehAssunto[k]).length) melhor = atual; atual = []; }
    }
    if (atual.filter((k) => ehAssunto[k]).length > melhor.filter((k) => ehAssunto[k]).length) melhor = atual;
    // tira palavras vazias das pontas
    while (melhor.length && STOP.has(palavras[melhor[0]])) melhor.shift();
    while (melhor.length && STOP.has(palavras[melhor[melhor.length - 1]])) melhor.pop();
    assuntoIdx = melhor;
    // outras palavras de assunto soltas (fora do trecho) entram também
    ehAssunto.forEach((v, i) => { if (v && !assuntoIdx.includes(i)) assuntoIdx.push(i); });
    assuntoIdx.sort((a, b) => a - b);
  }
  const ano = palavras.find((w) => TEMPO.test(w)) || null;
  const corrigido = new Map(correcoes.map((c) => [c.de, c.para]));
  const assunto = assuntoIdx.map((i) => {
    const o = origTokens[i] || palavras[i];
    return corrigido.has(normaliza(o)) ? palavras[i] : o.replace(/[^\p{L}\p{N}#@-]/gu, "");
  }).filter(Boolean).join(" ").trim();
  const assuntoTokens = assuntoIdx.map((i) => palavras[i]).filter((w) => !STOP.has(w));
  const uteis = palavras.filter((w) => !STOP.has(w) && !VERBOS.has(w));
  const intencoes = achadas.slice(0, 3).map((a) => ({ id: a.id, rotulo: INTENCAO_POR_ID.get(a.id)!.rotulo }));
  const expansoes = Array.from(new Set(intencoes.flatMap((i) => INTENCAO_POR_ID.get(i.id)!.expande)));
  const modo = intencoes.length && assuntoTokens.length ? "misto" : intencoes.length ? "intencao" : "palavra";
  const termosBusca = Array.from(new Set([
    ...uteis.filter((w) => !GENERICAS.has(w) || formato).map(radical),
    ...expansoes.flatMap((e) => e.split(" ")).filter((w) => !STOP.has(w) && !TEMPO.test(w) && w.length >= 3).map(radical),
  ])).filter((w) => !TEMPO.test(w) && /^[a-z0-9]{2,}$/.test(w)).slice(0, 24);
  return { original, normalizado: palavras.join(" "), palavras, uteis, radicais: uteis.map(radical), intencoes, formato, plataforma, localizacao: loc ? loc.nome : null, confianca, assunto, assuntoTokens, ano, modo, correcoes, expansoes, termosBusca };
}

/** Consulta para o GDELT: assunto como frase (até 4 palavras) — nunca a frase inteira com "para", "que" etc. */
export function consultaNoticias(c: Consulta): { principal: string; ampla: string | null } | null {
  const t = c.assuntoTokens;
  if (!t.length) return null;
  const limpa = (s: string) => s.replace(/["()]/g, "").trim();
  if (t.length === 1) return { principal: limpa(c.assunto.split(" ").find((w) => normaliza(w) === t[0]) || t[0]), ampla: null };
  const frase = limpa(c.assunto);
  return {
    principal: frase.split(" ").length <= 4 ? `"${frase}"` : t.slice(0, 4).join(" "),
    ampla: t.slice(0, 4).join(" "), // todas as palavras, em qualquer ordem
  };
}

/** Comparação tolerante: ignora palavras vazias, acentos e plural. Todas as palavras do assunto precisam aparecer. */
export function casaAssunto(assuntoTokens: string[], texto: string): boolean {
  const t = assuntoTokens.filter((w) => w.length >= 3 && !STOP.has(w));
  if (!t.length) return false;
  const x = " " + normaliza(texto).split(" ").map(radical).join(" ") + " ";
  return t.every((w) => { const r = radical(w); return x.includes(" " + r) || (r.length > 5 && x.includes(r.slice(0, r.length - 1))); });
}

/** Objetivos do catálogo que combinam com a pesquisa. Reaproveita as intenções que entender() já detectou (não cria outra busca).
 *  Cada intenção vale 1/(posição na lista do objetivo): a intenção principal do objetivo pesa mais. */
export function objetivosDaConsulta<T extends { chave: string; intencoes: string[] }>(catalogo: T[], c: Consulta, max = 3): T[] {
  const ids = new Set(c.intencoes.map((i) => i.id));
  const pontos = catalogo
    .map((o, ordem) => ({ o, ordem, p: o.intencoes.reduce((s, x, i) => s + (ids.has(x) ? 1 / (i + 1) : 0), 0) }))
    .filter((x) => x.p > 0)
    .sort((a, b) => b.p - a.p || a.ordem - b.ordem)
    .map((x) => x.o);
  // pediu vídeo/reels: uma ideia de vídeo sempre ajuda
  const video = catalogo.find((o) => o.chave === "ideia_video");
  if (c.formato === "reels" && video && !pontos.includes(video)) pontos.push(video);
  return pontos.slice(0, max);
}

/** Dimensões entendidas da consulta, para gravar em resultado.interpretacao e no log do EIE. Tudo vem do que a pessoa DISSE
 *  (`origem: "dita"`); o que for deduzido depois (ex.: plataforma pelo formato) fica a cargo de quem consome. */
export function dimensoesDaConsulta(c: Consulta) {
  const dita = <T>(valor: T) => ({ valor, origem: "dita" as const });
  return {
    plataforma: c.plataforma ?? null,
    localizacao: c.localizacao ?? null,
    intencoes_detalhe: c.intencoes.map((i) => ({ id: i.id, rotulo: i.rotulo, origem: c.confianca === "baixa" ? ("inferida" as const) : ("dita" as const) })),
    confianca: c.confianca ?? null,
    entidades: [
      ...(c.assunto ? [{ tipo: "assunto", ...dita(c.assunto) }] : []),
      ...(c.formato ? [{ tipo: "formato", ...dita(c.formato) }] : []),
      ...(c.plataforma ? [{ tipo: "plataforma", ...dita(c.plataforma) }] : []),
      ...(c.localizacao ? [{ tipo: "localizacao", ...dita(c.localizacao) }] : []),
    ],
    origem: { plataforma: c.plataforma ? "dita" : null, localizacao: c.localizacao ? "dita" : null, intencoes: c.intencoes.length ? (c.confianca === "baixa" ? "inferida" : "dita") : null, formato: c.formato ? "dita" : null },
  };
}
