// EvoluiSocial — leitura de links de vídeo (funções puras). Só reconhece o endereço;
// dados públicos vêm do oEmbed OFICIAL de cada plataforma (sem scraping, sem copiar conteúdo).

export type LinkVideo = {
  plataforma: "instagram" | "tiktok" | "youtube" | "outra";
  url: string;            // como a pessoa colou (só https)
  normalizada: string;    // forma canônica, sem rastreadores (evita duplicar o mesmo vídeo)
  idExterno: string | null;
  autor: string | null;   // quando o próprio endereço já diz (ex.: tiktok.com/@perfil/...)
  tipo: string | null;    // reel, post, video, short...
  oembed: string | null;  // endpoint oficial e público de incorporação, quando existe sem chave
};

const OEMBED: Record<string, (u: string) => string> = {
  youtube: (u) => `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(u)}`,
  tiktok: (u) => `https://www.tiktok.com/oembed?url=${encodeURIComponent(u)}`,
};

export function analisarLink(entrada: string): LinkVideo | null {
  let u: URL;
  try { u = new URL(String(entrada || "").trim()); } catch { return null; }
  if (u.protocol !== "https:" || u.username || u.password) return null;
  const host = u.hostname.toLowerCase().replace(/^(www|m|mobile|vm|vt)\./, "");
  const partes = u.pathname.split("/").filter(Boolean);
  const base = (plataforma: LinkVideo["plataforma"], normalizada: string, idExterno: string | null, autor: string | null, tipo: string | null): LinkVideo =>
    ({ plataforma, url: u.toString(), normalizada, idExterno, autor, tipo, oembed: OEMBED[plataforma] ? OEMBED[plataforma](normalizada) : null });

  if (host === "youtube.com" || host === "music.youtube.com") {
    if (partes[0] === "shorts" && /^[\w-]{6,20}$/.test(partes[1] || "")) return base("youtube", `https://www.youtube.com/shorts/${partes[1]}`, partes[1], null, "short");
    const v = u.searchParams.get("v");
    if (partes[0] === "watch" && v && /^[\w-]{6,20}$/.test(v)) return base("youtube", `https://www.youtube.com/watch?v=${v}`, v, null, "video");
    if (partes[0] === "live" && /^[\w-]{6,20}$/.test(partes[1] || "")) return base("youtube", `https://www.youtube.com/watch?v=${partes[1]}`, partes[1], null, "live");
    return null;
  }
  if (host === "youtu.be" && /^[\w-]{6,20}$/.test(partes[0] || "")) return base("youtube", `https://www.youtube.com/watch?v=${partes[0]}`, partes[0], null, "video");

  if (host === "tiktok.com") {
    const i = partes.indexOf("video");
    if (partes[0]?.startsWith("@") && i === 1 && /^\d{8,25}$/.test(partes[2] || "")) {
      const autor = partes[0].slice(1).slice(0, 60);
      return base("tiktok", `https://www.tiktok.com/@${autor}/video/${partes[2]}`, partes[2], autor, "video");
    }
    return null;
  }
  // link curto do TikTok (vm./vt.tiktok.com/XXXX): reconhecemos, mas só o oEmbed oficial resolve o vídeo
  if (/^(vm|vt)\.tiktok\.com$/.test(u.hostname.toLowerCase()) && /^[\w]{5,20}$/.test(partes[0] || "")) {
    return { plataforma: "tiktok", url: u.toString(), normalizada: `https://${u.hostname.toLowerCase()}/${partes[0]}/`, idExterno: null, autor: null, tipo: "video", oembed: OEMBED.tiktok(u.toString()) };
  }

  if (host === "instagram.com") {
    const tipos: Record<string, string> = { reel: "reel", reels: "reel", p: "post", tv: "video" };
    const k = tipos[partes[0]] ? 0 : (tipos[partes[1]] ? 1 : -1); // instagram.com/<perfil>/reel/<codigo>
    if (k >= 0 && /^[\w-]{5,40}$/.test(partes[k + 1] || "")) {
      const autor = k === 1 ? partes[0].slice(0, 60) : null;
      const tipo = tipos[partes[k]];
      // o oEmbed do Instagram exige app aprovado da Meta (token): fica para a etapa de integração oficial
      return { ...base("instagram", `https://www.instagram.com/${tipo === "reel" ? "reel" : "p"}/${partes[k + 1]}/`, partes[k + 1], autor, tipo), oembed: null };
    }
    return null;
  }
  return null; // outras plataformas: preparado para incluir quando houver mecanismo oficial
}

/** Limpa a resposta do oEmbed: só campos públicos e seguros (nada de HTML/script). */
export function dadosOembed(j: unknown): { titulo: string | null; autor: string | null; autorUrl: string | null; miniatura: string | null; provedor: string | null } {
  const o = (j && typeof j === "object" ? j : {}) as Record<string, unknown>;
  const txt = (v: unknown, n: number) => (typeof v === "string" && v.trim() ? v.trim().slice(0, n) : null);
  const https = (v: unknown) => (typeof v === "string" && /^https:\/\/[^\s"<>]+$/.test(v) && v.length <= 600 ? v : null);
  return { titulo: txt(o.title, 200), autor: txt(o.author_name, 120), autorUrl: https(o.author_url), miniatura: https(o.thumbnail_url), provedor: txt(o.provider_name, 40) };
}
