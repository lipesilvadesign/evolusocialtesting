// EIE — Camada de Inteligência de Dados v1
// Refatoração aditiva inspirada em padrões de plataformas de dados:
// fontes -> sinais -> inferências -> agregados.
// Não coleta dados novos por conta própria e não substitui as fontes existentes.

export type OrigemDado = "usuario" | "pesquisa" | "biblioteca" | "integracao" | "publico" | "sistema";
export type TipoSinal = "explicito" | "observado" | "derivado" | "agregado";

export type SinalDado = {
  chave: string;
  valor: string | number | boolean;
  tipo: TipoSinal;
  origem: OrigemDado;
  confianca: number;
  explicacao: string;
  atualizadoEm: string;
};

export type FonteDado = {
  nome: string;
  origem: OrigemDado;
  ativo: boolean;
  resultados?: number;
};


export type SinalAgregado = {
  tema: string;
  ramo: string | null;
  periodo: string;
  volumeAtual: number;
  volumeAnterior: number;
  crescimento: number | null;
  confianca: number;
};

export type InteligenciaComportamento = {
  versao: string;
  sinais: SinalAgregado[];
  protecao: { semIdentificadorPessoal: true; limiarMinimo: number };
};

/**
 * Normaliza a saída agregada do banco. A tabela agregada nunca deve retornar
 * identificadores individuais; resultados abaixo do limiar são omitidos pelo RPC.
 */
export function normalizarComportamentoAgregado(rows: unknown, limiarMinimo = 3): InteligenciaComportamento {
  const arr = Array.isArray(rows) ? rows : [];
  const sinais = arr.map((r: any) => ({
    tema: String(r.tema || ''),
    ramo: r.ramo == null ? null : String(r.ramo),
    periodo: String(r.periodo || ''),
    volumeAtual: Math.max(0, Number(r.volume_atual || 0)),
    volumeAnterior: Math.max(0, Number(r.volume_anterior || 0)),
    crescimento: r.crescimento == null ? null : Number(r.crescimento),
    confianca: limitar(Number(r.confianca ?? 0.7)),
  })).filter((x) => x.tema && x.volumeAtual >= limiarMinimo);
  return {
    versao: 'comportamento-agregado-v1',
    sinais,
    protecao: { semIdentificadorPessoal: true, limiarMinimo },
  };
}

export type InteligenciaDados = {
  versao: string;
  fontes: FonteDado[];
  sinais: SinalDado[];
  principios: {
    minimizacao: true;
    semDadosPessoaisNaCamadaAgregada: true;
    inferenciasMarcadas: true;
    origemPreservada: true;
  };
};

function limitar(n: number) {
  return Math.max(0, Math.min(1, Number.isFinite(n) ? n : 0));
}

function sinal(
  chave: string,
  valor: string | number | boolean,
  tipo: TipoSinal,
  origem: OrigemDado,
  confianca: number,
  explicacao: string,
): SinalDado {
  return { chave, valor, tipo, origem, confianca: limitar(confianca), explicacao, atualizadoEm: new Date().toISOString() };
}

/**
 * Converte as fontes que já participaram da pesquisa em uma visão de dados.
 * Importante: não envia IP, e-mail, nome ou identificador para esta camada.
 */
export function construirInteligenciaDados(args: {
  termo: string;
  topico: string;
  ramo?: string | null;
  personalizado?: boolean;
  fontes: { nome: string; ok: boolean; detalhe?: string }[];
  pesquisaAvancada?: { provedores?: { nome: string; ativo: boolean; resultados: number }[]; resultados?: unknown[] } | null;
  sinaisPesquisa?: { fonte: string; crescimento: number; temSinal: boolean; total14?: number }[];
  emAltaHoje?: number;
}): InteligenciaDados {
  const agora = new Date().toISOString();
  const fontes: FonteDado[] = args.fontes.map((f) => ({
    nome: f.nome,
    origem: f.nome.toLowerCase().includes("biblioteca") ? "biblioteca" : "pesquisa",
    ativo: f.ok,
  }));

  const sinais: SinalDado[] = [
    sinal("tema_pesquisado", args.topico, "explicito", "usuario", 1, "Tema informado ou resolvido a partir da pesquisa atual."),
  ];

  if (args.ramo) sinais.push(sinal("ramo_contextual", args.ramo, "explicito", "usuario", 1, "Ramo usado para contextualizar a pesquisa."));

  const sinaisPesquisa = args.sinaisPesquisa || [];
  const positivos = sinaisPesquisa.filter((s) => s.temSinal).length;
  const crescimentoMedio = sinaisPesquisa.length
    ? sinaisPesquisa.reduce((acc, s) => acc + (Number.isFinite(s.crescimento) ? s.crescimento : 0), 0) / sinaisPesquisa.length
    : 0;

  if (sinaisPesquisa.length) {
    sinais.push(sinal(
      "fontes_com_sinal",
      positivos,
      "observado",
      "pesquisa",
      Math.min(1, sinaisPesquisa.length / 3),
      "Quantidade de fontes da pesquisa que apresentaram sinal relevante; não representa probabilidade de sucesso."
    ));
    sinais.push(sinal(
      "crescimento_medio_fontes",
      Number(crescimentoMedio.toFixed(3)),
      "derivado",
      "pesquisa",
      Math.min(1, sinaisPesquisa.length / 3),
      "Média simples dos crescimentos calculados pelas fontes disponíveis."
    ));
  }

  if (typeof args.emAltaHoje === "number") {
    sinais.push(sinal(
      "presenca_em_alta",
      args.emAltaHoje > 0,
      "observado",
      "pesquisa",
      0.9,
      "O tema apareceu entre os sinais de alta consultados para o Brasil."
    ));
  }

  const prov = args.pesquisaAvancada?.provedores || [];
  for (const p of prov) {
    fontes.push({ nome: p.nome, origem: "pesquisa", ativo: p.ativo, resultados: p.resultados });
  }

  if (args.pesquisaAvancada?.resultados?.length) {
    sinais.push(sinal(
      "evidencias_web_recuperadas",
      args.pesquisaAvancada.resultados.length,
      "observado",
      "pesquisa",
      0.85,
      "Quantidade de evidências recuperadas pela busca web avançada antes do recorte final."
    ));
  }

  if (args.personalizado !== undefined) {
    sinais.push(sinal(
      "personalizacao_ativa",
      args.personalizado,
      "explicito",
      "usuario",
      1,
      "Indica apenas se a personalização foi autorizada para esta pesquisa."
    ));
  }

  // Não transformamos inferências em fatos sobre a pessoa. Elas permanecem explicitamente marcadas.
  if (positivos >= 2) {
    sinais.push(sinal(
      "convergencia_de_fontes",
      true,
      "derivado",
      "pesquisa",
      Math.min(0.95, 0.55 + positivos * 0.12),
      "Duas ou mais fontes apresentaram sinais compatíveis. Convergência é evidência contextual, não garantia de desempenho."
    ));
  }

  return {
    versao: "inteligencia-dados-v1",
    fontes,
    sinais,
    principios: {
      minimizacao: true,
      semDadosPessoaisNaCamadaAgregada: true,
      inferenciasMarcadas: true,
      origemPreservada: true,
    },
  };
}
