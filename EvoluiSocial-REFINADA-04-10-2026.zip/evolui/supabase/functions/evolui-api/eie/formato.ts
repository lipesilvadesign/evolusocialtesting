// Format Intelligence (02/10/2026): cada módulo de criação tem função, entrada e saída próprias; o perfil é entrada real.
// Funções puras e determinísticas (sem rede, sem LLM). Fluxo por módulo:
//   módulo → intenção do módulo → análise do perfil → estratégia de transformação → schema de saída → geração → quality gate.
import { normaliza } from "../consulta.ts";
import { afirmacoesNaoSuportadas, genericidadeTexto, limparTitulo, type ContextoUsuario } from "./contexto.ts";
import { detectarArquetipo } from "./geracao.ts";
import type { HistoricoEIE } from "./ranking.ts";
import {
  ENFASES, ESTRUTURAS, FI_VERSION, INTENCAO_ENFASE, MODULE_INTELLIGENCE, OBJETIVO_ENFASE, OFICIOS, OFICIO_NEUTRO, RAMO_OFICIO,
  type Enfase, type EnfaseId, type EstruturaId, type Modulo, type Oficio,
} from "./formato-dados.ts";

export { FI_VERSION, MODULE_INTELLIGENCE };
export type { Modulo };
export const MODULOS = Object.keys(MODULE_INTELLIGENCE) as Modulo[];

export type IdeiaEntrada = { titulo: string; descricao?: string | null; arquetipo?: string | null; formato?: string | null };

// ---------------------------------------------------------------- análise do perfil → profile_signals
export type PerfilSinais = {
  business_type: string | null; content_context: string; likely_audience: string | null;
  available_formats: { preferido: string | null; restricoes: string[] };
  preferred_networks: string[]; relevant_services: string[]; observed_preferences: string[]; content_history: boolean;
  /** de onde vem cada sinal: informado | derivado do tipo de trabalho | ausente */
  origem: Record<string, "informado" | "derivado" | "ausente">;
  oficio: string; oficio_generico: boolean; faltando: string[];
};

const casa = (norm: string, g: string) => g.endsWith(" ") ? new RegExp(`(^| )${g.trim()}( |$)`).test(norm) : new RegExp(`(^| )${g}`).test(norm);
export function escolherOficio(ctx: ContextoUsuario): Oficio {
  const det = normaliza(ctx.negocio || "");
  if (det) { const o = OFICIOS.find((x) => x.gatilhos.some((g) => casa(det, g))); if (o) return o; }
  const rot = normaliza(ctx.ramoRotulo || "");
  if (rot) { const o = OFICIOS.find((x) => x.gatilhos.some((g) => casa(rot, g))); if (o) return o; }
  const id = ctx.ramo ? RAMO_OFICIO[ctx.ramo] : null;
  return OFICIOS.find((x) => x.id === id) || OFICIO_NEUTRO;
}

export function analisarPerfil(ctx: ContextoUsuario, hist?: HistoricoEIE | null): PerfilSinais {
  const of = escolherOficio(ctx);
  const faltando: string[] = [];
  if (!ctx.ramo) faltando.push("ramo");
  if (!ctx.negocio) faltando.push("detalhe do negócio");
  if (!ctx.redes.length) faltando.push("redes");
  if (!ctx.canalVenda) faltando.push("canal de venda");
  const restricoes: string[] = [];
  if (ctx.aparecer === "nao") restricoes.push("sem aparecer: usar mãos, objeto, tela ou texto");
  if (ctx.aparecer === "voz") restricoes.push("só a voz: narração sem rosto");
  const afin = hist?.afinidadeFormato || {};
  const obs = Object.entries(afin).filter(([, v]) => v >= 0.2).sort((a, b) => b[1] - a[1]).map(([k]) => k);
  const generico = of.generico === true;
  return {
    business_type: ctx.negocio || ctx.ramoRotulo || null,
    content_context: of.rotulo,
    likely_audience: generico ? null : of.publico,
    available_formats: { preferido: ctx.formatoPreferido, restricoes },
    preferred_networks: ctx.redes, relevant_services: ctx.negocio ? [ctx.negocio] : [],
    observed_preferences: obs, content_history: !!hist?.temHistorico,
    origem: {
      business_type: ctx.negocio || ctx.ramoRotulo ? "informado" : "ausente",
      content_context: generico ? "ausente" : ctx.negocio && escolherOficioPorDetalhe(ctx) ? "derivado" : "derivado",
      likely_audience: generico ? "ausente" : "derivado",
      preferred_networks: ctx.redes.length ? "informado" : "ausente",
      relevant_services: ctx.negocio ? "informado" : "ausente",
    },
    oficio: of.id, oficio_generico: generico, faltando,
  };
}
const escolherOficioPorDetalhe = (ctx: ContextoUsuario) => !!ctx.negocio;

// ---------------------------------------------------------------- utilidades determinísticas
const hash = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const pick = <T>(a: T[], n: number): T => a[((n % a.length) + a.length) % a.length];
/** contrações do português: de/em/a + artigo (o, a, os, as) */
const contrai = (prep: "de" | "em" | "a", t: string) => {
  const m = t.match(/^(o|a|os|as)\s+(.*)$/i);
  if (!m) return `${prep} ${t}`;
  const art = m[1].toLowerCase();
  const tab: Record<string, Record<string, string>> = { de: { o: "do", a: "da", os: "dos", as: "das" }, em: { o: "no", a: "na", os: "nos", as: "nas" }, a: { o: "ao", a: "à", os: "aos", as: "às" } };
  return `${tab[prep][art]} ${m[2]}`;
};
export const dePt = (t: string) => contrai("de", t), emPt = (t: string) => contrai("em", t), aPt = (t: string) => contrai("a", t);
const cap = (s: string) => s ? s[0].toUpperCase() + s.slice(1) : s;
/** corta em fronteira de palavra e nunca termina em "de/do/por..." */
const curto = (t: string, n: number) => {
  if (t.length <= n) return t;
  let c = t.slice(0, n); const i = c.lastIndexOf(" "); if (i > 10) c = c.slice(0, i);
  return c.replace(/(\s+(?:de|do|da|dos|das|a|o|as|os|e|por|para|com|em|no|na|um|uma))+$/i, "").replace(/[,;:\s]+$/, "");
};
const semPonto = (s: string) => s.replace(/[.!?\s]+$/, "");

export function escolherEnfase(objetivoChave: string | null | undefined, objetivoIntencoes: string[] | null | undefined, intencoes: string[]): Enfase {
  if (objetivoChave && OBJETIVO_ENFASE[objetivoChave]) return ENFASES[OBJETIVO_ENFASE[objetivoChave]];
  for (const i of objetivoIntencoes || []) if (INTENCAO_ENFASE[i]) return ENFASES[INTENCAO_ENFASE[i]];
  for (const i of intencoes) if (INTENCAO_ENFASE[i]) return ENFASES[INTENCAO_ENFASE[i]];
  return ENFASES.neutro;
}

type Beat = { rotulo: string; orient: string };
type Nucleo = { arq: string; tema: string; beats: Beat[]; promessa: string };

const TEMA_VERBOS = /^(mostre|mostrar|fa[cç]a|crie|criar|compartilhe|conte|explique|apresente|poste|grave)\s+(?:os|as|o|a|um|uma|seu|sua|seus|suas)?\s*/i;
export const temaDaIdeia = (titulo: string) => semPonto(titulo.replace(TEMA_VERBOS, "").trim()) || semPonto(titulo);

function nucleo(ideia: IdeiaEntrada, of: Oficio): Nucleo {
  const arq = ideia.arquetipo || detectarArquetipo({ titulo: ideia.titulo, descricao: ideia.descricao || "", tags: [], tipo: "ideia" } as never) || "generica";
  const tema = temaDaIdeia(ideia.titulo);
  const B = (rotulo: string, orient: string): Beat => ({ rotulo, orient });
  let beats: Beat[]; let promessa: string;
  switch (arq) {
    case "bastidores":
      beats = of.etapas.map(([r, o]) => B(cap(r), cap(o) + (of.generico ? "" : ""))); promessa = `o caminho até ${of.resultado}`; break;
    case "erro_comum":
      beats = [B("O erro", `Mostre o erro mais comum ${dePt(of.publico)} sobre ${of.decisao}`), B("Por que acontece", "Explique em uma frase o motivo, sem culpar quem erra"), B("O que fazer no lugar", `Mostre o jeito certo usando ${of.ferramenta}`), B("Como conferir", `Mostre ${of.resultado} depois da correção`)]; promessa = `evitar o erro mais comum ${emPt(of.decisao)}`; break;
    case "antes_depois":
      beats = [B("Antes", `Mostre ${of.antes}`), B("O que mudou", `Explique ${of.decisao} que fez a diferença`), B("Depois", `Mostre ${of.depois}`)]; promessa = `a diferença entre ${of.antes} e ${of.depois}`; break;
    case "dica":
      beats = [B("O problema", `Diga qual problema a dica resolve para ${of.publico}`), B("A dica", "Entregue a dica em uma frase curta"), B("Como aplicar", `Mostre o passo a passo usando ${of.ferramenta}`), B("O que muda", `Mostre ${of.resultado} depois de aplicar`)]; promessa = "uma dica que dá para aplicar hoje"; break;
    case "prova_social":
      beats = [B("A situação", "Conte qual era a necessidade da pessoa, sem expor dados dela"), B("O que foi feito", `Mostre ${of.decisao} aplicada nesse caso`), B("O resultado", `Mostre ${of.resultado}, só com autorização de quem aparece`)]; promessa = "um resultado real, com autorização"; break;
    case "oferta":
      beats = [B("O que é", "Diga em uma frase o que está sendo oferecido"), B("Para quem serve", `Diga para quem a oferta faz sentido: ${of.publico}`), B("O que a pessoa recebe", `Mostre ${of.resultado}`), B("Como pedir", "Diga o passo para pedir ou reservar")]; promessa = "o que a pessoa recebe e como pedir"; break;
    case "lancamento":
      beats = [B("A novidade", "Diga o que é novo em uma frase"), B("O que muda", `Mostre ${of.ferramenta} ou ${of.resultado} da novidade`), B("Quando e como", "Informe data ou forma de conseguir, só o que for real")]; promessa = "a novidade e como aproveitar"; break;
    case "pergunta":
      beats = [B("A pergunta", `Faça uma pergunta específica sobre ${of.decisao}`), B("As opções", "Apresente 2 caminhos possíveis"), B("Sua resposta", "Dê a sua posição e o motivo")]; promessa = "uma pergunta que convida a escolher um lado"; break;
    case "apresentacao":
      beats = [B("Quem faz", `Diga em uma frase o que você faz e para ${of.publico}`), B("Como trabalha", `Mostre ${of.cena}`), B("O que entrega", `Mostre ${of.resultado}`)]; promessa = "quem você é e o que entrega"; break;
    default:
      beats = [B("O ponto de partida", `Apresente o assunto: ${tema}`), B("O ponto principal", `Explique ${of.decisao} no contexto do assunto`), B("Na prática", `Mostre ${of.ferramenta} ou ${of.resultado} na prática, ligados ao assunto`)]; promessa = `o essencial sobre ${tema}`;
  }
  return { arq, tema, beats, promessa };
}

// ---------------------------------------------------------------- ganchos e CTAs (dependem do objetivo + do perfil)
function gancho(e: Enfase, n: Nucleo, of: Oficio, v: number): string {
  const t = n.tema;
  const por: Record<Enfase["gancho"], string[]> = {
    curiosidade: [`Tem uma etapa de ${t} que quase ninguém vê.`, `Quase ninguém vê ${of.invisivel}.`, `Hoje você vê ${n.promessa}.`],
    pergunta: [`Você sabe como é ${n.promessa}?`, `Qual etapa ${dom(of)} você nunca viu?`, `O que você acha que muda ${emPt(of.resultado)}?`],
    contraste: [`${cap(of.antes)} e ${of.depois}: o que fica no meio?`, `Parece simples, mas ${of.decisao} muda tudo.`, `Tem um detalhe ${dom(of)} que muda tudo: ${of.decisao}.`],
    promessa: [`Em poucos segundos: ${n.promessa}.`, `Veja ${n.promessa}, na prática.`, `Aqui está ${n.promessa}.`],
  };
  return pick(por[e.gancho], v);
}
function cta(e: Enfase, ctx: ContextoUsuario, v: number): string {
  const canal = ctx.canalVenda;
  const contato = canal === "WhatsApp" ? "Chame no WhatsApp" : canal === "Direct" || canal === "Instagram" ? "Chame no Direct" : canal === "Loja física" ? "Fale com a gente na loja" : canal === "Site" ? "Veja no site" : canal ? `Fale pelo canal ${canal}` : "Chame pelo seu canal de contato";
  switch (e.id) {
    case "seguidores": return pick(["Siga para ver a próxima etapa.", "Siga para acompanhar o resto do processo."], v);
    case "alcance": return pick(["Envie para alguém que precisa ver isso.", "Compartilhe com quem se interessa pelo assunto."], v);
    case "interesse": return pick(["Conte nos comentários o que você quer ver a seguir.", "Responda: qual parte te surpreendeu?"], v);
    case "apresentar": case "vender": return pick([`${contato} para saber como funciona.`, `${contato} e peça o seu.`], v);
    case "tendencia": return pick(["Comente o que você acha desse assunto.", "Conte como isso aparece no seu dia a dia."], v);
    default: return pick(["Salve para consultar depois.", "Salve este conteúdo para usar depois."], v);
  }
}
const dom = (of: Oficio) => of.generico ? "do seu trabalho" : `de ${of.rotulo}`;
const semRosto = (ctx: ContextoUsuario) => ctx.aparecer === "nao" ? "sem mostrar o rosto: enquadre mãos, objeto ou tela" : ctx.aparecer === "voz" ? "narração em off, sem aparecer" : "";

// ---------------------------------------------------------------- geradores por módulo (schemas distintos)
export type Cena = { tempo: string; funcao: string; acao_visual: string; fala: string; texto_na_tela: string };
export type Entrada = { ideia: IdeiaEntrada; ctx: ContextoUsuario; hist?: HistoricoEIE | null; enfase: Enfase; seed: string };

function genVideo(i: Entrada, of: Oficio, n: Nucleo, v: number) {
  const rapido = i.enfase.ritmo === "rapido";
  const meio = n.beats.length > 3 ? n.beats.slice(1, 4) : n.beats.slice(1, -1).length ? n.beats.slice(1, -1) : n.beats.slice(0, 1);
  const dur = rapido ? 2 : 4;
  const rosto = semRosto(i.ctx);
  const cenas: Cena[] = [];
  let t = 0;
  const add = (funcao: string, d: number, acao: string, fala: string, texto: string) => { cenas.push({ tempo: `${t}–${t + d}s`, funcao, acao_visual: acao, fala, texto_na_tela: texto }); t += d; };
  add("Gancho", rapido ? 2 : 3, `Abra direto na cena: ${of.cena}${rosto ? ` (${rosto})` : ""}`, gancho(i.enfase, n, of, v), cap(curto(semPonto(gancho(i.enfase, n, of, v + 1)), 48)));
  for (const b of meio) add(`Desenvolvimento · ${b.rotulo}`, dur, b.orient, `${cap(b.rotulo)}: [diga em uma frase o que acontece aqui].`, cap(b.rotulo));
  const fecha = n.beats[n.beats.length - 1];
  add("Fechamento", dur, `Termine mostrando ${of.resultado}, de perto`, `É assim: ${n.promessa}.`, cap(fecha.rotulo));
  add("CTA", 2, "Volte ao enquadramento principal e pare por 1 segundo", cta(i.enfase, i.ctx, v), "");
  return { duracao_aprox: `${t} segundos`, ritmo: rapido ? "rápido: cortes de 1 a 2 segundos" : "médio: um corte a cada 3 a 4 segundos", cenas, observacao: rosto || null };
}

function genTexto(i: Entrada, of: Oficio, n: Nucleo, v: number) {
  const ex = (s: string) => `Ex.: "${s}"`;
  const dev = n.beats.slice(0, Math.min(3, n.beats.length));
  return {
    secoes: [
      { secao: "Abertura", orientacao: "Comece pela situação ou pela dúvida, em 1 ou 2 frases, sem apresentar o assunto inteiro.", exemplo: ex(gancho(i.enfase, n, of, v)) },
      { secao: "Desenvolvimento", orientacao: `Conte ${n.promessa} em ${dev.length} parágrafos curtos: ${dev.map((b) => b.rotulo.toLowerCase()).join(", ")}.`, exemplo: ex(`${dev[0].rotulo}: ${dev[0].orient.charAt(0).toLowerCase() + dev[0].orient.slice(1)}.`) },
      { secao: "Argumentação", orientacao: `Explique o motivo por trás ${dePt(of.decisao)}: o que você escolhe e por que escolhe assim.`, exemplo: ex(`Eu faço assim porque [motivo real do seu trabalho].`) },
      { secao: "Encerramento", orientacao: `Feche com ${of.resultado} ou com a lição que fica, em uma frase.`, exemplo: ex(`No fim, o que importa é [o que fica para quem lê].`) },
      { secao: "CTA", orientacao: "Uma única ação, coerente com o objetivo.", exemplo: ex(cta(i.enfase, i.ctx, v)) },
    ],
    tamanho_sugerido: i.enfase.ritmo === "rapido" ? "até 600 caracteres" : "600 a 1.200 caracteres",
  };
}

function genStories(i: Entrada, of: Oficio, n: Nucleo, v: number) {
  const e = i.enfase;
  const interativo = ["interesse", "tendencia"].includes(e.id) || ["pergunta", "erro_comum"].includes(n.arq);
  const caixa = ["dica", "pergunta"].includes(n.arq);
  const link = ["apresentar", "vender"].includes(e.id) && !!i.ctx.canalVenda;
  const sticker3 = interativo ? (caixa ? "caixa de perguntas" : "enquete com 2 opções") : null;
  const corpo = n.beats.length > 4 ? n.beats.slice(1, 3) : n.beats.slice(1, 2).length ? n.beats.slice(1, 2) : n.beats.slice(0, 1);
  const seq = [
    { story: 1, funcao: "Gancho", conteudo: gancho(e, n, of, v), recurso: null as string | null },
    { story: 2, funcao: "Contexto", conteudo: `Mostre ${of.cena} e diga em uma frase o que vem a seguir.`, recurso: null },
    { story: 3, funcao: "Interação", conteudo: sticker3 ? `Convide a pessoa a escolher ou perguntar sobre ${of.decisao}.` : `Faça uma pergunta falada ligada ${aPt(of.decisao)} e peça para responder por mensagem.`, recurso: sticker3 },
    ...corpo.map((b, k) => ({ story: 4 + k, funcao: `Desenvolvimento · ${b.rotulo}`, conteudo: b.orient + ".", recurso: null as string | null })),
  ];
  seq.push({ story: seq.length + 1, funcao: "CTA", conteudo: cta(e, i.ctx, v), recurso: link ? "link ou botão do canal informado" : null });
  return { sequencia: seq, total: seq.length, nota: "Recursos interativos só entram onde fazem sentido para a ideia e o objetivo." };
}

function genCarrossel(i: Entrada, of: Oficio, n: Nucleo, v: number) {
  const slides = [
    { slide: 1, papel: "Gancho", titulo: cap(curto(semPonto(gancho(i.enfase, n, of, v)), 60)), texto: `Apresente ${n.promessa} em uma frase.`, visual: `Imagem: ${of.cena}` },
    ...n.beats.map((b, k) => ({ slide: k + 2, papel: k === 0 && n.beats.length > 3 ? "Contexto" : "Ponto", titulo: b.rotulo, texto: b.orient + ".", visual: `Imagem ou texto que sustente: ${b.rotulo.toLowerCase()}` })),
  ];
  slides.push({ slide: slides.length + 1, papel: "Conclusão e CTA", titulo: cap(semPonto(cta(i.enfase, i.ctx, v))), texto: `Feche com ${of.resultado} e uma única ação.`, visual: `Imagem final: ${of.resultado}` });
  return { slides, total: slides.length, nota: `A quantidade de slides (${slides.length}) vem do que a ideia precisa, sem slide de enfeite.` };
}

const ESQUELETO: Record<EstruturaId, (of: Oficio, n: Nucleo) => string[]> = {
  lista: (of, n) => ["Capa com a promessa", `Item 1: ${of.decisao}`, `Item 2: ${of.ferramenta}`, `Item 3: ${of.invisivel}`, "Fechamento com a ação"],
  passo_a_passo: (of) => ["Capa: o que será feito", ...of.etapas.slice(0, 3).map(([r], k) => `Passo ${k + 1}: ${r}`), `Resultado: ${of.resultado}`],
  erro_solucao: (of) => ["Capa: o erro", "Por que acontece", `Como corrigir: ${of.decisao}`, `Como confirmar: ${of.resultado}`],
  antes_depois: (of) => [`Capa: ${of.antes} e ${of.depois}`, `Antes: ${of.antes}`, `O que mudou: ${of.decisao}`, `Depois: ${of.depois}`],
  problema_solucao: (of) => ["Capa: o problema", "O que ele causa", `A solução: ${of.ferramenta}`, "Como pedir ou aplicar"],
  mito_verdade: (of) => ["Capa: o mito", "Por que muita gente acredita", `A verdade sobre ${of.decisao}`, "O que fazer então"],
  comparacao: (of) => ["Capa: duas opções", "Opção A", "Opção B", `Quando escolher cada uma ${emPt(of.decisao)}`],
  checklist: (of) => ["Capa: o que conferir", `Confira: ${of.ferramenta}`, `Confira: ${of.decisao}`, `Confira: ${of.resultado}`],
  tutorial: (of) => ["Capa: o que você vai aprender", `Material: ${of.ferramenta}`, "Execução, passo a passo", `Resultado: ${of.resultado}`],
  historia: (of) => ["Capa: o começo", "O desafio", `O caminho: ${of.decisao}`, `O desfecho: ${of.resultado}`],
  estudo_de_caso: (of) => ["Capa: o caso", "A situação", `O que foi feito: ${of.decisao}`, `O resultado: ${of.resultado} (com autorização)`],
};

export function pontuarEstruturas(arq: string, enfase: EnfaseId, ctx: ContextoUsuario, hist?: HistoricoEIE | null) {
  const pref = hist?.afinidadeFormato?.carrossel ?? 0;
  return (Object.keys(ESTRUTURAS) as EstruturaId[]).map((id) => {
    const E = ESTRUTURAS[id];
    const a = E.arq[arq] ?? E.arq.generica ?? 0.2;
    const o = E.enfase[enfase] ?? 0.25;
    return { id, rotulo: E.rotulo, score: Math.round((a * 0.6 + o * 0.35 + Math.max(0, pref) * 0.05) * 100) / 100 };
  }).sort((x, y) => y.score - x.score || x.id.localeCompare(y.id));
}

function genFormatoCarrossel(i: Entrada, of: Oficio, n: Nucleo, v: number) {
  const rank = pontuarEstruturas(n.arq, i.enfase.id, i.ctx, i.hist);
  const top = rank[0], alt = rank.slice(1, 3);
  const escolhida = v > 0 && alt[0] && rank[0].score - alt[0].score < 0.05 ? alt[0] : top;
  return {
    estrutura_escolhida: { id: escolhida.id, rotulo: escolhida.rotulo, porque: `Combina com uma ideia de ${n.arq === "generica" ? "assunto geral" : n.arq.replace("_", " ")} e com o objetivo ${i.enfase.rotulo}: ${i.enfase.foco}.` },
    alternativas: rank.filter((r) => r.id !== escolhida.id).slice(0, 2).map((r) => ({ id: r.id, rotulo: r.rotulo, quando_usar: `Se a ideia ficar mais perto de ${r.rotulo.toLowerCase()}.` })),
    esqueleto: ESQUELETO[escolhida.id](of, n).map((t, k) => ({ slide: k + 1, conteudo: t })),
    compatibilidade: rank.slice(0, 4).map((r) => ({ id: r.id, rotulo: r.rotulo, score: r.score })),
  };
}

// mais ideias: ângulos NOVOS a partir da ideia, nunca outro formato
type Angulo = { id: string; rotulo: string; arq: string; enfase: EnfaseId[]; titulo: (of: Oficio) => string; desc: (of: Oficio) => string; passos: (of: Oficio) => string[] };
const ANGULOS: Angulo[] = [
  { id: "decisao", rotulo: "A decisão por trás", arq: "dica", enfase: ["interesse", "seguidores"], titulo: (o) => `${cap(o.decisao)}: o que muda ${emPt(o.resultado)}`, desc: (o) => `Explique ${o.decisao} e o motivo, com um exemplo do seu trabalho.`, passos: (o) => [`Escolha um caso em que ${o.decisao} fez diferença`, "Explique o motivo em uma frase", `Mostre ${o.resultado}`] },
  { id: "invisivel", rotulo: "O que ninguém vê", arq: "bastidores", enfase: ["seguidores", "alcance"], titulo: (o) => `O que acontece antes ${dePt(o.resultado)}`, desc: (o) => `Revele ${o.invisivel}, que quem vê de fora não percebe.`, passos: (o) => [`Escolha um detalhe de ${o.invisivel}`, "Mostre-o de perto", "Diga por que ele importa"] },
  { id: "erro", rotulo: "Erro comum", arq: "erro_comum", enfase: ["alcance", "interesse"], titulo: (o) => `O erro mais comum ${dePt(o.publico)}`, desc: (o) => `Mostre um erro frequente sobre ${o.decisao} e como evitá-lo.`, passos: () => ["Descreva o erro", "Explique por que acontece", "Mostre o jeito certo"] },
  { id: "contraste", rotulo: "Antes e depois", arq: "antes_depois", enfase: ["apresentar", "vender"], titulo: (o) => `${cap(dePt(o.antes))} ${aPt(o.depois)}`, desc: (o) => `Compare ${o.antes} com ${o.depois} e explique o que mudou.`, passos: (o) => [`Mostre ${o.antes}`, `Explique ${o.decisao}`, `Mostre ${o.depois}`] },
  { id: "duvida", rotulo: "Dúvida frequente", arq: "pergunta", enfase: ["interesse", "tendencia"], titulo: (o) => `A dúvida mais comum ${dePt(o.publico)}`, desc: (o) => `Responda a dúvida mais comum sobre ${o.decisao}, em linguagem simples.`, passos: () => ["Cite a dúvida", "Responda em uma frase", "Dê um exemplo real do seu trabalho"] },
  { id: "ferramenta", rotulo: "A ferramenta", arq: "dica", enfase: ["seguidores", "apresentar"], titulo: (o) => `Por que eu uso ${o.ferramenta}`, desc: (o) => `Mostre ${o.ferramenta} e o que isso resolve no seu trabalho.`, passos: (o) => [`Mostre ${o.ferramenta}`, "Diga o que isso resolve", `Mostre ${o.resultado}`] },
  { id: "resultado", rotulo: "O resultado de perto", arq: "oferta", enfase: ["vender", "apresentar"], titulo: (o) => `${cap(o.resultado)} em detalhe`, desc: (o) => `Mostre ${o.resultado} de perto e diga como pedir.`, passos: (o) => [`Mostre ${o.resultado} de perto`, "Diga o que está incluído", "Diga como pedir"] },
];
function genMaisIdeias(i: Entrada, of: Oficio, n: Nucleo, v: number) {
  const base = ANGULOS.filter((a) => a.arq !== n.arq || a.id === "decisao");
  const pontuado = base.map((a, k) => ({ a, s: (a.enfase.includes(i.enfase.id) ? 1 : 0) + ((hash(i.seed + a.id) + v * 7) % 100) / 1000 + (a.arq === n.arq ? -0.5 : 0) + (k === 0 ? 0 : 0) }))
    .sort((x, y) => y.s - x.s);
  const ideias = pontuado.slice(0, 5).map(({ a }) => ({ angulo: a.rotulo, titulo: a.titulo(of), descricao: a.desc(of), execucao: a.passos(of) }));
  return { ideia_original: n.tema, ideias, nota: "Cada ideia é um ângulo diferente do mesmo tema; o formato você escolhe depois." };
}

// ---------------------------------------------------------------- quality gate
const UNIVERSAIS = [/\b3 ideias de\b/, /^faca um post\b/, /^crie um reels\b/, /\bmostre os bastidores\b/, /\bfaca uma pergunta para (?:o )?seu publico\b/];
const ENCHIMENTO = ["gere conexao", "humanize sua marca", "aproxime seu publico", "fortaleca sua presenca", "mostre o lado real", "onde a magica acontece"];
const textos = (o: unknown, acc: string[] = []): string[] => {
  if (typeof o === "string") acc.push(o); else if (Array.isArray(o)) o.forEach((x) => textos(x, acc)); else if (o && typeof o === "object") Object.values(o).forEach((x) => textos(x, acc));
  return acc;
};
const VAZ = /(undefined|null|NaN|\[object|\{[a-z_]+\})/;

export type Qualidade = { ok: boolean; falhas: string[]; genericidade: number; tentativas: number; fallback: boolean };
function estruturaOk(m: Modulo, r: Record<string, unknown>): boolean {
  const arr = (k: string) => Array.isArray(r[k]) ? r[k] as Record<string, unknown>[] : [];
  switch (m) {
    case "mais_ideias": { const a = arr("ideias"); return a.length >= 3 && new Set(a.map((x) => x.angulo)).size === a.length; }
    case "video_curto": { const c = arr("cenas"); return c.length >= 4 && /Gancho/.test(String(c[0]?.funcao)) && /CTA/.test(String(c[c.length - 1]?.funcao)) && c.some((x) => /Desenvolvimento/.test(String(x.funcao))) && c.some((x) => /Fechamento/.test(String(x.funcao))) && c.every((x) => x.acao_visual && x.fala); }
    case "guia_texto": return arr("secoes").map((s) => s.secao).join("|") === "Abertura|Desenvolvimento|Argumentação|Encerramento|CTA";
    case "stories": { const s = arr("sequencia"); return s.length >= 4 && s.length <= 7 && /Gancho/.test(String(s[0]?.funcao)) && /CTA/.test(String(s[s.length - 1]?.funcao)); }
    case "carrossel": { const s = arr("slides"); return s.length >= 4 && s.length <= 10 && s[0].papel === "Gancho" && s[s.length - 1].papel === "Conclusão e CTA"; }
    case "formato_carrossel": return !!r.estrutura_escolhida && arr("alternativas").length >= 1 && arr("esqueleto").length >= 4;
  }
}

export function avaliarModulo(m: Modulo, r: Record<string, unknown>, ctx: ContextoUsuario, of: Oficio, enfase: Enfase, ideiaTitulo: string): Omit<Qualidade, "tentativas" | "fallback"> {
  const I = MODULE_INTELLIGENCE[m];
  const falhas: string[] = [];
  const ts = textos(r);
  const todo = ts.join(" \n ");
  const norm = normaliza(todo);
  if (!estruturaOk(m, r)) falhas.push("estrutura");
  if (I.forbidden_patterns.some((re) => re.test(todo))) falhas.push("funcao: mistura de formato");
  if (afirmacoesNaoSuportadas(todo, ctx).length) falhas.push("contexto_inventado");
  if (VAZ.test(todo)) falhas.push("executabilidade: vazamento");
  if (UNIVERSAIS.some((re) => re.test(norm)) || ts.some((t) => UNIVERSAIS.some((re) => re.test(normaliza(t))))) falhas.push("originalidade: modelo universal");
  if (ENCHIMENTO.some((c) => norm.includes(c))) falhas.push("genericidade: enchimento");
  if (!["mais_ideias", "formato_carrossel"].includes(m) && enfase.marcador && !enfase.marcador.test(todo)) falhas.push("objetivo: sem ação coerente");
  if (!of.generico) {
    const termos = [...of.etapas.map(([x]) => x), of.ferramenta, of.resultado, of.decisao, of.cena].map((x) => normaliza(x).split(" ").filter((w) => w.length > 4)).flat();
    if (!termos.some((t) => norm.includes(t))) falhas.push("perfil: sem termos do ofício");
  }
  const g = Math.round((ts.filter((t) => t.length > 20).reduce((s, t) => s + genericidadeTexto(t), 0) / Math.max(1, ts.filter((t) => t.length > 20).length)) * 100) / 100;
  if (g > 0.45) falhas.push("genericidade");
  if (norm.includes(normaliza(ideiaTitulo)) && m === "mais_ideias" && Array.isArray(r.ideias) && (r.ideias as { titulo: string }[]).some((x) => normaliza(x.titulo) === normaliza(ideiaTitulo))) falhas.push("diferenciação: repete a ideia");
  return { ok: falhas.length === 0, falhas, genericidade: g };
}

// ---------------------------------------------------------------- orquestração
export type EntradaCriar = {
  modulo: Modulo; ideia: IdeiaEntrada; ctx: ContextoUsuario; hist?: HistoricoEIE | null; seed?: string;
  objetivo?: { chave: string; rotulo?: string; intencoes?: string[] } | null; intencoes?: string[];
};
const GERADORES: Record<Modulo, (i: Entrada, of: Oficio, n: Nucleo, v: number) => Record<string, unknown>> = {
  mais_ideias: genMaisIdeias, video_curto: genVideo, guia_texto: genTexto, stories: genStories, carrossel: genCarrossel, formato_carrossel: genFormatoCarrossel,
};

const Deno_dbg = false;
export function criarModulo(e0: EntradaCriar) {
  // o título da ideia só entra no texto se não afirmar contexto que a pessoa não tem (loja, cidade...)
  const tituloSeguro = limparTitulo(e0.ideia.titulo, e0.ctx) ?? "o tema da ideia";
  const e: EntradaCriar = { ...e0, ideia: { ...e0.ideia, titulo: tituloSeguro } };
  const I = MODULE_INTELLIGENCE[e.modulo];
  const perfil = analisarPerfil(e.ctx, e.hist);
  const of = escolherOficio(e.ctx);
  const enfase = escolherEnfase(e.objetivo?.chave, e.objetivo?.intencoes, e.intencoes || []);
  const seed = e.seed || e.ideia.titulo;
  const entrada: Entrada = { ideia: e.ideia, ctx: e.ctx, hist: e.hist, enfase, seed };
  const nuc = nucleo(e.ideia, of);
  const base = hash(seed + e.modulo) % 997;
  let resultado: Record<string, unknown> = {}, q: Omit<Qualidade, "tentativas" | "fallback"> = { ok: false, falhas: ["não gerado"], genericidade: 1 };
  let tent = 0, fallback = false;
  for (let v = 0; v < 3; v++) {
    tent++;
    resultado = GERADORES[e.modulo](entrada, of, nuc, base + v);
    q = avaliarModulo(e.modulo, resultado, e.ctx, of, enfase, e.ideia.titulo);
    if (Deno_dbg) console.log("tent", v, q.falhas);
    if (q.ok) break;
  }
  if (!q.ok) {
    // reserva segura: vocabulário neutro, sem nada que dependa do perfil
    fallback = true;
    const nuc2 = nucleo({ titulo: e.ideia.titulo, arquetipo: "generica" }, OFICIO_NEUTRO);
    resultado = GERADORES[e.modulo]({ ...entrada, ctx: { ...e.ctx, canalVenda: null } }, OFICIO_NEUTRO, nuc2, 0);
    q = avaliarModulo(e.modulo, resultado, e.ctx, OFICIO_NEUTRO, enfase, e.ideia.titulo);
  }
  return {
    algorithm_version: FI_VERSION, modulo: e.modulo, rotulo: I.rotulo, funcao: I.primary_goal, estrutura: I.output_structure,
    ideia_original: { titulo: e.ideia.titulo, arquetipo: nuc.arq },
    perfil: {
      business_type: perfil.business_type, content_context: perfil.content_context, likely_audience: perfil.likely_audience,
      redes: perfil.preferred_networks, observed_preferences: perfil.observed_preferences, origem: perfil.origem, faltando: perfil.faltando,
      aviso: perfil.oficio_generico ? "Sem detalhe do seu trabalho, usei etapas neutras. Complete o perfil para ficar mais específico." : "As etapas vêm do tipo de trabalho; confirme o que acontece de verdade no seu.",
    },
    objetivo: { id: enfase.id, rotulo: enfase.rotulo, foco: enfase.foco },
    resultado,
    qualidade: { ...q, tentativas: tent, fallback },
  };
}
