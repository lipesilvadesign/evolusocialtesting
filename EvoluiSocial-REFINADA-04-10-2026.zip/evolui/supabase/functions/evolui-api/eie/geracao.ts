// EIE — Context Engine (explicação e enriquecimento por candidato) e provedor de geração de texto (opcional).
// O texto do card é montado só com fatos conhecidos (ver contexto.ts). Nada de justificativa global reaproveitada.
import { casaAssunto, INTENCOES, normaliza } from "../consulta.ts";
import {
  afirmacoesNaoSuportadas, avaliarCard, genericidadeTexto, limparTitulo, sanitizarTexto,
  type Card, type ContextoUsuario, type Origem,
} from "./contexto.ts";
import type { Candidato, ConsultaEIE, Explicacao, Features, ObjetivoEIE } from "./ranking.ts";

export const FORMATO_ROTULO: Record<string, string> = {
  reels: "vídeo curto", carrossel: "carrossel", stories: "stories", foto: "foto", live: "live", post: "post", texto: "texto",
};
const REDE_ROTULO: Record<string, string> = { instagram: "Instagram", tiktok: "TikTok", youtube: "YouTube", facebook: "Facebook", linkedin: "LinkedIn", kwai: "Kwai", pinterest: "Pinterest" };

// ---------------------------------------------------------------- fatos permitidos
type Fatos = { clientes: string; cena: string; semRosto: boolean; rostoDesconhecido: boolean; contato: string; onde: string };
function fatosDe(ctx: ContextoUsuario): Fatos {
  const c = ctx.ramoCtx?.clientes;
  const contato = ctx.canalVenda === "WhatsApp" ? "chamar no WhatsApp" : ctx.canalVenda === "Direct do Instagram" ? "mandar um direct"
    : ctx.canalVenda === "Loja física" ? "visitar a loja" : ctx.canalVenda === "Site ou app de entrega" ? "pedir pelo app ou pelo site" : "falar com você pelo link da bio";
  return {
    clientes: c ? `seus ${c}` : "o seu público",
    cena: ctx.ramoCtx?.cena || "o seu trabalho de perto",
    semRosto: ctx.permissoes.rosto === false,
    rostoDesconhecido: ctx.permissoes.rosto === null,
    contato,
    onde: ctx.permissoes.presencial ? "o seu espaço de trabalho" : "como o seu trabalho acontece",
  };
}
const fecho = (f: Fatos) => (f.semRosto ? "Narre com a voz ou escreva na tela o que está acontecendo." : "Termine com uma frase direta dizendo o próximo passo.");

// ---------------------------------------------------------------- arquétipos: o que a ideia é, de verdade
type Arq = { re: RegExp; tituloSeguro: string; descricao: (f: Fatos) => string; passos: (f: Fatos) => string[] };
export const ARQUETIPOS: Record<string, Arq> = {
  bastidores: {
    re: /bastidor|tour|dia no meu|processo|making|como (?:eu )?fa[cç]o/,
    tituloSeguro: "Mostre como o seu trabalho acontece",
    descricao: (f) => `Mostre ${f.onde} em poucos cortes, do começo ao resultado. O foco é ${f.cena}, sem produção sofisticada.`,
    passos: (f) => ["Abra com o resultado pronto, por 1 ou 2 segundos.", `Volte ao início e mostre ${f.cena} em 2 ou 3 cortes rápidos.`, fecho(f)],
  },
  erro_comum: {
    re: /erro|mito|verdade|engano/,
    tituloSeguro: "Conte um erro comum e como evitá-lo",
    descricao: (f) => `Aponte um erro que ${f.clientes} costumam cometer e mostre o jeito certo de fazer.`,
    passos: (f) => ["Escolha um erro que você já viu acontecer de verdade. Não invente números.", "Mostre o erro em uma frase ou uma cena.", "Mostre o jeito certo em até 3 itens.", "Feche convidando a salvar o conteúdo para consultar depois."],
  },
  antes_depois: {
    re: /antes e depois|antes\/depois|transforma/,
    tituloSeguro: "Mostre um antes e depois real",
    descricao: (f) => `Mostre uma mudança que aconteceu de verdade no seu trabalho, com ${f.cena} como foco.`,
    passos: () => ["Use só um resultado real seu, com autorização de quem aparece.", "Mostre o antes primeiro, sem filtro.", "Mostre o depois e diga em uma frase o que foi feito.", "Convide a pessoa a perguntar como funciona."],
  },
  dica: {
    re: /dica|passo a passo|tutorial|aprenda|ensin|como (?:escolher|usar|cuidar)/,
    tituloSeguro: "Ensine uma dica rápida",
    descricao: (f) => `Ensine algo útil que ${f.clientes} podem aplicar sozinhos e que mostre que você entende do assunto.`,
    passos: () => ["Escolha uma única dica que caiba em 30 segundos ou 4 telas.", "Diga o problema na primeira frase.", "Mostre a solução em passos curtos.", "Peça para salvar e compartilhar com quem precisa."],
  },
  pergunta: {
    re: /enquete|pergunta|caixinha|faq|duvida/,
    tituloSeguro: "Responda uma pergunta frequente",
    descricao: (f) => `Pegue uma pergunta que ${f.clientes} realmente fazem e responda de forma direta.`,
    passos: (f) => ["Escolha a pergunta que você mais ouve nas suas conversas.", "Leia a pergunta na tela ou em voz alta.", "Responda em até 30 segundos.", `Se fizer sentido, convide a ${f.contato}.`],
  },
  prova_social: {
    re: /depoiment|prova social|avalia[cç]|feedback|resultado de cliente/,
    tituloSeguro: "Compartilhe um depoimento real",
    descricao: () => "Compartilhe o que uma pessoa realmente disse sobre o seu trabalho, com autorização dela.",
    passos: () => ["Peça autorização a quem fez o elogio antes de publicar.", "Mostre a mensagem original, sem editar o sentido.", "Conte em uma frase o contexto do que foi feito.", "Agradeça e convide outras pessoas a contar a experiência."],
  },
  oferta: {
    re: /promo[cç]|oferta|desconto|cupom|queima|liquida/,
    tituloSeguro: "Divulgue uma condição especial",
    descricao: () => "Divulgue uma condição que você realmente consegue cumprir, com regra e prazo claros.",
    passos: (f) => ["Defina a condição e o prazo. Não invente preço nem escassez.", "Mostre o que está incluído em uma imagem ou cena.", "Explique em uma frase como aproveitar.", `Feche com o convite: ${f.contato}.`],
  },
  lancamento: {
    re: /lan[cç]amento|novidade|estreia|apresent(?:e|ar|ando) (?:um|o|a|seu|sua)/,
    tituloSeguro: "Apresente uma novidade",
    descricao: (f) => `Apresente algo novo do seu trabalho e mostre ${f.cena} para despertar curiosidade.`,
    passos: (f) => ["Mostre a novidade logo no início.", "Diga em uma frase o que ela resolve ou oferece.", "Mostre um detalhe de perto.", `Convide a ${f.contato}.`],
  },
  sorteio: {
    re: /sorteio/,
    tituloSeguro: "Faça um sorteio com regras claras",
    descricao: () => "Faça um sorteio com prêmio do seu próprio trabalho e regras simples, para atrair pessoas que podem virar clientes.",
    passos: () => ["Defina o prêmio e o prazo.", "Escreva a regra em poucas linhas, para participar e para saber quem ganhou.", "Publique o regulamento junto do post.", "Anuncie o resultado no prazo combinado."],
  },
  parceria: {
    re: /parceria|collab|colabora/,
    tituloSeguro: "Faça um post em parceria",
    descricao: () => "Crie um conteúdo junto com outro perfil que fala com o mesmo público sem concorrer com você.",
    passos: () => ["Escolha um perfil que atenda o mesmo público e combine a ideia.", "Combine quem grava, quem publica e a data.", "Publique pelo recurso de colaboração, para o post aparecer nos dois perfis.", "Responda os comentários dos dois lados."],
  },
  apresentacao: {
    re: /rosto|quem somos|quem faz|historia|apresentacao|apresente quem/,
    tituloSeguro: "Apresente quem está por trás do trabalho",
    descricao: (f) => (f.semRosto ? "Apresente quem faz o trabalho sem mostrar o rosto, usando as mãos, a voz ou texto na tela." : "Apresente quem faz o trabalho e como tudo começou."),
    passos: (f) => [f.semRosto ? "Mostre suas mãos trabalhando ou use só a sua voz." : "Diga seu nome e o que você faz, na primeira frase.", "Conte em uma frase por que você faz isso.", "Mostre um momento real do trabalho.", fecho(f)],
  },
  gancho: {
    re: /gancho|primeiros segundos|abertura|hook/,
    tituloSeguro: "Teste uma abertura forte",
    descricao: () => "Teste frases de abertura nos primeiros segundos para ver qual segura mais a atenção.",
    passos: () => ["Escolha duas frases de abertura da lista.", "Grave o mesmo conteúdo com cada uma.", "Compare qual teve mais pessoas assistindo até o fim.", "Guarde a que funcionou para os próximos."],
  },
  bio: {
    re: /\bbio\b|biografia/,
    tituloSeguro: "Ajuste a bio do seu perfil",
    descricao: (f) => `Reescreva a bio para dizer, em poucas linhas, o que você faz e como ${f.contato}.`,
    passos: (f) => ["Escreva em uma linha o que você faz.", `Diga como a pessoa pode ${f.contato}.`, "Releia: dá para entender em 5 segundos?"],
  },
  tendencia: {
    re: /tend[eê]ncia|data comemorativa|dia das|natal|p[aá]scoa|trend/,
    tituloSeguro: "Aproveite um assunto do momento",
    descricao: () => "Entre em um assunto do momento só se ele tiver relação real com o que você faz.",
    passos: () => ["Confirme que o assunto tem ligação verdadeira com o seu trabalho.", "Dê a sua visão em uma frase.", "Mostre um exemplo do seu dia a dia ligado ao assunto.", "Publique enquanto o assunto ainda está no ar."],
  },
  planejamento: {
    re: /calend[aá]rio|planej|rotina de post|const[aâ]ncia|cronograma/,
    tituloSeguro: "Planeje seus próximos posts",
    descricao: () => "Defina os próximos posts em uma lista simples, com data e formato, para manter a constância.",
    passos: () => ["Escolha quantos posts por semana você consegue manter.", "Anote o tema e o formato de cada um.", "Agrupe a produção em um dia só.", "Revise a lista a cada semana."],
  },
};
const POR_FORMATO: Record<string, (f: Fatos) => { descricao: string; passos: string[] }> = {
  reels: (f) => ({ descricao: `Um vídeo curto que mostra ${f.cena} de forma direta.`, passos: ["Abra mostrando o resultado ou a pergunta, nos 2 primeiros segundos.", `Mostre ${f.cena} em poucos cortes.`, fecho(f)] }),
  carrossel: (f) => ({ descricao: `Um carrossel curto que explica o assunto para ${f.clientes}.`, passos: ["A capa traz a promessa ou a pergunta.", "Use de 3 a 5 telas, com uma ideia por tela.", "A última tela diz o que fazer em seguida."] }),
  stories: (f) => ({ descricao: `Uma sequência de stories para conversar com ${f.clientes}.`, passos: ["Story 1: apresente o assunto.", "Story 2: faça uma pergunta ou enquete.", "Story 3: responda quem participou."] }),
  foto: (f) => ({ descricao: `Uma foto que mostra ${f.cena}, com uma legenda clara.`, passos: ["Escolha a foto com boa luz e um único foco.", "Escreva a primeira linha da legenda como se fosse um título.", "Feche a legenda dizendo o próximo passo."] }),
  live: (f) => ({ descricao: `Uma conversa ao vivo com ${f.clientes}.`, passos: ["Avise o dia e a hora com antecedência.", "Prepare 3 tópicos e deixe espaço para perguntas.", "Salve o vídeo depois para quem não viu."] }),
};
const PADRAO = (f: Fatos) => ({ descricao: `Uma ideia de conteúdo para mostrar ${f.cena} a ${f.clientes}.`, passos: ["Escolha o que vai mostrar, em uma frase.", "Grave ou fotografe de perto, com boa luz.", fecho(f)] });

export function detectarArquetipo(c: Pick<Candidato, "titulo" | "descricao" | "tags" | "tipo">): string | undefined {
  const t = normaliza(`${c.titulo} ${(c.tags || []).join(" ")} ${c.descricao || ""}`);
  const tt = normaliza(c.titulo);
  if (c.tipo === "biblioteca" && /\b(modelo de bio|bio)\b/.test(tt) && ARQUETIPOS.bio.re.test(tt)) return "bio";
  // o título decide primeiro; descrição e tags só desempatam
  for (const [id, a] of Object.entries(ARQUETIPOS)) if (a.re.test(tt)) return id;
  for (const [id, a] of Object.entries(ARQUETIPOS)) if (a.re.test(t)) return id;
  return undefined;
}

// ---------------------------------------------------------------- sinal externo (tendência): só entra se for do candidato
export type SinalTendencia = { fonte: string; termo: string; rotulo: string; estado: string; escopo: "consulta"; em: string; confianca: "alta" | "media" | "baixa" | null };
export function sinalRelacionado(c: Candidato, s: SinalTendencia | null | undefined, consulta?: ConsultaEIE | null): boolean {
  if (!s || s.estado === "insuficiente" || !s.termo || s.escopo !== "consulta") return false;
  const alvo = `${c.titulo} ${(c.tags || []).join(" ")} ${c.descricao || ""}`;
  return casaAssunto(consulta?.assuntoTokens?.length ? consulta.assuntoTokens : normaliza(s.termo).split(" "), alvo);
}

// ---------------------------------------------------------------- por que apareceu
export type PorQue = { kind: string; texto: string; origem: Origem };
export type EntradaPorQue = {
  c: Candidato; ctx: ContextoUsuario; f: Features; ex: Explicacao; consulta?: ConsultaEIE | null; objetivo?: ObjetivoEIE | null;
  sinal?: SinalTendencia | null;
  /** frases de justificativa já usadas em outros cards (texto → contagem) */
  usados?: Map<string, number>;
};
const asp = (s: string) => `“${s}”`;
const ROTULO_ARQ: Record<string, string> = {
  bastidores: "bastidores", erro_comum: "erro comum", antes_depois: "antes e depois", dica: "dica rápida", pergunta: "pergunta frequente",
  prova_social: "depoimento", oferta: "oferta", lancamento: "novidade", sorteio: "sorteio", parceria: "parceria", apresentacao: "apresentação",
  gancho: "abertura", bio: "bio", tendencia: "assunto do momento", planejamento: "planejamento",
};

function termoCasado(c: Candidato, consulta?: ConsultaEIE | null): string | null {
  if (!consulta) return null;
  const alvo = " " + normaliza(`${c.titulo} ${(c.tags || []).join(" ")}`) + " ";
  const t = consulta.termosBusca.find((w) => w.length >= 4 && alvo.includes(" " + w));
  return t || null;
}

export function explicarPorque(e: EntradaPorQue): PorQue[] {
  const { c, ctx, f, consulta, objetivo, ex } = e;
  const v = f.valor, d = f.disponivel;
  const cand: PorQue[] = [];
  if (d.objetivo && v.objetivo >= 0.5 && objetivo) {
    // frase específica do candidato: modelo + intenções em comum (nunca a mesma frase para todos os cards)
    const comuns = (c.intencoes || []).filter((i) => objetivo.intencoes.includes(i)).map((i) => INTENCOES.find((x) => x.id === i)?.rotulo.toLowerCase()).filter(Boolean) as string[];
    const modelo = c.arquetipo && ROTULO_ARQ[c.arquetipo] ? `um modelo de ${ROTULO_ARQ[c.arquetipo]}` : "este modelo";
    cand.push({ kind: "objetivo", texto: comuns.length ? `Combina com o objetivo ${asp(objetivo.rotulo)}: ${modelo} indicado para ${comuns.slice(0, 2).join(" e ")}.` : `Combina com o objetivo ${asp(objetivo.rotulo)}: ${modelo}.`, origem: "derived" });
  }
  if ((v.lexical >= 0.5 || v.semantico >= 0.5) && consulta?.original) {
    const t = termoCasado(c, consulta);
    const rot = c.arquetipo ? ROTULO_ARQ[c.arquetipo] : undefined;
    cand.push({ kind: "consulta", texto: rot ? `Modelo de ${rot} aplicado ao assunto da sua busca ${asp(consulta.original)}.` : t ? `Fala de ${t}, que aparece na sua busca ${asp(consulta.original)}.` : `Tem a ver com a sua busca ${asp(consulta.original)}.`, origem: "derived" });
  }
  if (d.segmento && v.segmento === 1 && ctx.ramoRotulo && (c.ramos || []).length) cand.push({ kind: "segmento", texto: `Foi pensada para quem atua em ${ctx.ramoRotulo}.`, origem: "explicit" });
  if (d.contexto_negocio && v.contexto_negocio === 1 && ctx.negocio) cand.push({ kind: "negocio", texto: `Combina com o que você disse que faz (${ctx.negocio}).`, origem: "explicit" });
  if (d.formato && v.formato === 1 && c.formato && FORMATO_ROTULO[c.formato]) {
    cand.push({ kind: "formato", texto: consulta?.formato ? `É ${FORMATO_ROTULO[c.formato]}, o formato que você pediu.` : ctx.formatoPreferido ? `É ${FORMATO_ROTULO[c.formato]}, o formato que você disse preferir.` : `É ${FORMATO_ROTULO[c.formato]}, o formato indicado para este objetivo.`, origem: consulta?.formato || ctx.formatoPreferido ? "explicit" : "derived" });
  }
  if (d.rede && v.rede === 1 && c.redes?.length) {
    const r = c.redes.find((x) => ctx.redes.includes(x.toLowerCase()));
    if (r) cand.push({ kind: "rede", texto: `Funciona no ${REDE_ROTULO[r.toLowerCase()] || r}, uma das redes que você cadastrou.`, origem: "explicit" });
  }
  if (d.historico && v.historico >= 0.7) cand.push({ kind: "historico", texto: "É parecida com ações que você já iniciou ou concluiu.", origem: "derived" });
  if (e.sinal && sinalRelacionado(c, e.sinal, consulta) && ex.signals.lexical !== undefined) {
    cand.push({ kind: "tendencia", texto: `O assunto ${asp(e.sinal.termo)} aparece como ${e.sinal.rotulo.toLowerCase()} nas fontes que consultamos.`, origem: "retrieved" });
  }
  if (f.exposicao === 0 && ctx.personalizar && d.historico) cand.push({ kind: "novidade", texto: "Ainda não foi sugerida para você.", origem: "derived" });

  if (!cand.length) {
    return [{ kind: "geral", texto: "Sugestão geral.", origem: "derived" }];
  }
  // a mesma frase nunca se repete entre cards: só entram razões cujo texto ainda não foi usado (usados é indexado pelo texto)
  const livres = cand.filter((x) => !e.usados?.get(x.texto));
  if (!livres.length) return [{ kind: "geral", texto: "Sugestão geral.", origem: "derived" }];
  return livres.slice(0, 2);
}

// ---------------------------------------------------------------- Context Engine
export type SaidaContexto = { card: Card; sanitizadas: number; arquetipo: string | null; titulo_ajustado: boolean };

export function contextualizar(c: Candidato, ctx: ContextoUsuario, porque: PorQue[]): SaidaContexto {
  const f = fatosDe(ctx);
  const arq = c.arquetipo || detectarArquetipo(c);
  const A = arq ? ARQUETIPOS[arq] : undefined;
  const enriq = A ? { descricao: A.descricao(f), passos: A.passos(f) } : (c.formato && POR_FORMATO[c.formato] ? POR_FORMATO[c.formato](f) : PADRAO(f));

  // título
  let titulo = limparTitulo(c.titulo, ctx);
  let ajustado = false;
  if (!titulo) { titulo = A?.tituloSeguro || (c.formato && FORMATO_ROTULO[c.formato] ? `Uma ideia de ${FORMATO_ROTULO[c.formato]} para o seu perfil` : "Uma ideia para o seu perfil"); ajustado = true; }
  else if (titulo !== c.titulo) ajustado = true;

  // descrição: aproveita o texto original se ele for concreto; senão usa o do arquétipo
  const orig = sanitizarTexto((c.descricao || "").trim(), ctx);
  const origBom = orig.texto.length >= 30 && genericidadeTexto(orig.texto) <= 0.35;
  let descricao = origBom ? `${orig.texto.replace(/\s+$/, "")} ${enriq.descricao}` : enriq.descricao;
  if (descricao.length > 320) descricao = enriq.descricao;

  const execucao = enriq.passos;
  return { card: { titulo, descricao, execucao, porque: porque.map((p) => p.texto).join(" ") }, sanitizadas: orig.removidas, arquetipo: arq || null, titulo_ajustado: ajustado };
}

// ---------------------------------------------------------------- provedor de geração (opcional; o EIE funciona sem ele)
export type EntradaGeracao = { id: string; titulo: string; descricao: string; execucao: string[]; fatos: string[] };
export type SaidaGeracao = Record<string, { descricao?: string; execucao?: string[] }>;
export interface ProvedorGeracao {
  nome: string;
  gerar(itens: EntradaGeracao[], sinal?: AbortSignal): Promise<SaidaGeracao>;
}
/** Padrão: não altera nada. Todo texto vem das regras acima. */
export class ProvedorDeterministico implements ProvedorGeracao {
  nome = "deterministico";
  gerar(): Promise<SaidaGeracao> { return Promise.resolve({}); }
}
/** OpenAI (chat/completions). Usado só para reescrever descrição e passos de poucos itens, em UMA chamada. */
export class ProvedorOpenAI implements ProvedorGeracao {
  nome = "openai";
  constructor(private chave: string, private modelo: string, private http: typeof fetch = fetch) {}
  async gerar(itens: EntradaGeracao[], sinal?: AbortSignal): Promise<SaidaGeracao> {
    const r = await this.http("https://api.openai.com/v1/chat/completions", {
      method: "POST", signal: sinal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.chave}` },
      body: JSON.stringify({
        model: this.modelo, temperature: 0.4, response_format: { type: "json_object" },
        messages: [
          { role: "system", content: "Você reescreve instruções de conteúdo para redes sociais em português do Brasil, de forma clara e executável. Use SOMENTE os fatos informados. Não invente cidade, loja, estúdio, clientes, números, preços, resultados nem depoimentos. Não use clichês como 'onde a mágica acontece'. Responda apenas JSON no formato {\"itens\":{\"<id>\":{\"descricao\":\"...\",\"execucao\":[\"...\",\"...\"]}}}." },
          { role: "user", content: JSON.stringify({ itens }) },
        ],
      }),
    });
    if (!r.ok) throw new Error("openai " + r.status);
    const j = await r.json();
    const txt = j?.choices?.[0]?.message?.content;
    const o = JSON.parse(typeof txt === "string" ? txt : "{}")?.itens;
    const saida: SaidaGeracao = {};
    if (o && typeof o === "object") for (const [id, v] of Object.entries(o as Record<string, { descricao?: unknown; execucao?: unknown }>)) {
      saida[id] = {
        descricao: typeof v?.descricao === "string" ? v.descricao : undefined,
        execucao: Array.isArray(v?.execucao) ? v.execucao.filter((x): x is string => typeof x === "string") : undefined,
      };
    }
    return saida;
  }
}

/** Aceita o texto gerado só se passar no mesmo controle de qualidade e não trouxer números ou fatos novos. */
export function validarGerado(base: Card, novo: { descricao?: string; execucao?: string[] }, ctx: ContextoUsuario, genericidadeMaxima: number): Card | null {
  const descricao = (novo.descricao || "").trim(), execucao = (novo.execucao || []).map((s) => s.trim()).filter(Boolean);
  if (descricao.length < 20 || descricao.length > 320 || execucao.length < 2 || execucao.length > 6) return null;
  const baseTxt = `${base.titulo} ${base.descricao} ${base.execucao.join(" ")}`;
  const numerosBase = new Set(baseTxt.match(/\d+/g) || []);
  const novosNumeros = `${descricao} ${execucao.join(" ")}`.match(/\d+/g) || [];
  if (novosNumeros.some((n) => !numerosBase.has(n))) return null;
  const card: Card = { ...base, descricao, execucao };
  const q = avaliarCard(card, ctx, { vistos: new Set(), sinalExternoValido: true, genericidadeMaxima });
  const bloqueantes = q.falhas.filter((x) => !x.startsWith("sinal_") && x !== "texto_repetido");
  return bloqueantes.length || afirmacoesNaoSuportadas(`${descricao} ${execucao.join(" ")}`, ctx).length ? null : card;
}
