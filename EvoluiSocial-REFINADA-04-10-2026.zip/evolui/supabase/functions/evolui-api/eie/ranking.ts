// EIE — candidatos, features, EvoluiScore, novidade, aprendizado e diversidade (MMR).
// Funções puras: sem rede e sem banco, 100% testáveis.
import { normaliza, radical, STOP, type Consulta } from "../consulta.ts";
import { EIE_VERSION, type ConfigEIE, type Pesos } from "./config.ts";
import { conceitosDe, conceitosDeIntencoes, cosseno } from "./conceitos.ts";
import { exigeContextoAusente, type ContextoUsuario } from "./contexto.ts";

export type Candidato = {
  id: string;
  tipo: "biblioteca" | "ideia" | "cta_modelo";
  titulo: string;
  descricao?: string;
  texto?: string;
  formato?: string | null;
  tags?: string[];
  intencoes?: string[];
  ramos?: string[];
  redes?: string[];
  requer?: string[];
  /** para modelos de ação: o objetivo a que pertencem */
  objetivo?: string;
  nivel?: string | null;
  atualizadoEm?: string | null;
  arquetipo?: string;
  rosto?: boolean;
  /** componentes e nota lexical vindos do SQL (biblioteca) */
  comp?: { exata: number; parcial: number; palavras: number; parecida: number; intencao: number; tags: number; ramo: number; formato: number };
  scoreSql?: number;
  /** ideia gerada a partir do próprio assunto pesquisado */
  doAssunto?: boolean;
  /** conteúdo já pronto (ideias do motor): o Context Engine só valida e explica, não reescreve */
  cardBase?: { titulo: string; descricao: string; execucao: string[] };
  /** dado original do motor, devolvido sem alteração */
  carga?: unknown;
};

export type ConsultaEIE = Pick<Consulta, "original" | "termosBusca" | "intencoes" | "formato" | "assunto" | "assuntoTokens">;
export type ObjetivoEIE = { chave: string; rotulo: string; intencoes: string[]; formatoPadrao?: string | null };

// ---------------------------------------------------------------- histórico, novidade e aprendizado
export type EventoEIE = { tipo: string; candidato_id: string; formato?: string | null; objetivo?: string | null; criado_em: string };
export type RecomEIE = { id: string; formato?: string | null; em: string };
export type CtaHist = { modelo_id: string | null; status: string; formato?: string | null; criado_em: string };
export type HistoricoEIE = {
  /** 0 a 1: o quanto este candidato já "gastou" a atenção do usuário (com decaimento no tempo) */
  exposicao: Map<string, number>;
  /** −1 a 1 por formato, a partir do que a pessoa iniciou, concluiu, salvou ou recusou */
  afinidadeFormato: Record<string, number>;
  temHistorico: boolean;
};
export const HISTORICO_VAZIO: HistoricoEIE = { exposicao: new Map(), afinidadeFormato: {}, temHistorico: false };

const dias = (de: string, agora: Date) => Math.max(0, (agora.getTime() - new Date(de).getTime()) / 86_400_000);
/** Meia-vida: depois de `meia` dias, vale metade. */
export const decaimento = (d: number, meia: number) => Math.pow(0.5, d / Math.max(meia, 0.1));

const EXPO_EVENTO: Record<string, keyof ConfigEIE["novidade"]["exposicao"]> = {
  view: "visto", start: "iniciado", complete: "concluido", discard: "descartado", not_for_me: "nao_para_mim", copy: "visto", save: "visto",
};
const EXPO_CTA: Record<string, keyof ConfigEIE["novidade"]["exposicao"]> = { novo: "recomendado", iniciado: "iniciado", concluido: "concluido", descartado: "descartado" };

export function construirHistorico(ev: EventoEIE[], rec: RecomEIE[], ctas: CtaHist[], cfg: ConfigEIE, agora = new Date()): HistoricoEIE {
  const expo = new Map<string, number>();
  const soma = (id: string, peso: number) => {
    if (!id || peso <= 0) return;
    const antes = expo.get(id) || 0;
    expo.set(id, 1 - (1 - antes) * (1 - Math.min(1, peso))); // "ou" probabilístico: acumula, nunca passa de 1
  };
  const jan = cfg.novidade.janelaDias, meia = cfg.novidade.meiaVidaDias;
  for (const r of rec) { const d = dias(r.em, agora); if (d <= jan) soma(r.id, cfg.novidade.exposicao.recomendado * decaimento(d, meia)); }
  for (const e of ev) {
    const k = EXPO_EVENTO[e.tipo]; const d = dias(e.criado_em, agora);
    // "não é para mim" vale por toda a janela (depois a ideia pode voltar); o resto, inclusive "outra sugestão", decai pela meia-vida
    const recusa = e.tipo === "not_for_me";
    if (k && d <= jan) soma(e.candidato_id, cfg.novidade.exposicao[k] * (recusa ? 1 : decaimento(d, meia)));
  }
  for (const c of ctas) { const k = EXPO_CTA[c.status]; const d = dias(c.criado_em, agora); if (k && c.modelo_id && d <= jan) soma(c.modelo_id, cfg.novidade.exposicao[k] * decaimento(d, meia)); }

  const bruto: Record<string, number> = {};
  const g = cfg.aprendizado.ganho as Record<string, number>;
  for (const e of ev) {
    if (!e.formato || g[e.tipo] === undefined) continue;
    bruto[e.formato] = (bruto[e.formato] || 0) + g[e.tipo] * decaimento(dias(e.criado_em, agora), cfg.aprendizado.meiaVidaDias);
  }
  for (const c of ctas) {
    if (!c.formato) continue;
    const ganho = c.status === "concluido" ? g.complete : c.status === "iniciado" ? g.start : c.status === "descartado" ? g.discard : 0;
    bruto[c.formato] = (bruto[c.formato] || 0) + ganho * 0.5 * decaimento(dias(c.criado_em, agora), cfg.aprendizado.meiaVidaDias);
  }
  const afinidadeFormato: Record<string, number> = {};
  for (const [f, v] of Object.entries(bruto)) afinidadeFormato[f] = Math.round(Math.tanh(v / 3) * 100) / 100;
  return { exposicao: expo, afinidadeFormato, temHistorico: ev.length + ctas.length > 0 };
}

// ---------------------------------------------------------------- features
const tokens = (t: string) => normaliza(t).split(" ").filter((w) => w.length >= 3 && !STOP.has(w)).map(radical);
const textoDe = (c: Candidato) => `${c.titulo} ${c.descricao || ""} ${(c.tags || []).join(" ")} ${c.texto || ""}`.replace(/[{}]/g, " ");

export type Features = {
  disponivel: Record<keyof Pesos, boolean>;
  valor: Record<keyof Pesos, number>;
  contextoAusente: string[];
  exposicao: number;
};
export type EntradaFeatures = {
  consulta?: ConsultaEIE | null; objetivo?: ObjetivoEIE | null; ctx: ContextoUsuario; historico: HistoricoEIE; cfg: ConfigEIE;
  /** maior nota lexical do lote (normaliza a nota do SQL) */
  maxScoreSql: number; agora: Date;
  /** pontos 0..1 vindos de um índice semântico externo (embeddings). Opcional: PREPARADO, sem uso na v1. */
  semanticoExterno?: Map<string, number>;
};

export function extrairFeatures(c: Candidato, e: EntradaFeatures): Features {
  const { consulta, objetivo, ctx, historico } = e;
  const valor = {} as Record<keyof Pesos, number>, disponivel = {} as Record<keyof Pesos, boolean>;
  const set = (k: keyof Pesos, ok: boolean, v: number) => { disponivel[k] = ok; valor[k] = ok ? Math.max(0, Math.min(1, v)) : 0; };
  const txt = textoDe(c), tk = new Set(tokens(txt)), vecC = conceitosDe(txt);
  const temConsulta = !!consulta && (consulta.termosBusca.length > 0 || consulta.intencoes.length > 0);

  // lexical
  if (c.comp || c.scoreSql !== undefined) {
    const bruto = c.scoreSql ?? Object.values(c.comp || {}).reduce((s, x) => s + x, 0);
    set("lexical", true, bruto / Math.max(1, e.maxScoreSql));
  } else if (temConsulta && consulta!.termosBusca.length) {
    const q = consulta!.termosBusca.filter((w) => w.length >= 3);
    const hit = q.filter((w) => tk.has(radical(w))).length;
    set("lexical", true, Math.max(q.length ? Math.min(1, hit / Math.min(q.length, 4)) : 0, c.doAssunto ? 0.75 : 0));
  } else set("lexical", false, 0);

  // semântico (conceitos; ou índice externo, se existir)
  if (temConsulta) {
    const vq = conceitosDe(consulta!.original);
    const viaIntencao = conceitosDeIntencoes(consulta!.intencoes.map((i) => i.id));
    for (const [k, v] of Object.entries(viaIntencao)) vq[k] = (vq[k] || 0) + v * 0.5;
    const ext = e.semanticoExterno?.get(c.id);
    set("semantico", true, ext !== undefined ? Math.max(ext, cosseno(vq, vecC)) : cosseno(vq, vecC));
  } else set("semantico", false, 0);

  // intenção (o que a pessoa quis dizer) — é feature, não filtro: casamento direto OU indireto por conceito
  if (consulta && consulta.intencoes.length) {
    const ids = consulta.intencoes.map((i) => i.id);
    const direto = (c.intencoes || []).map((i) => ids.indexOf(i)).filter((i) => i >= 0);
    const indireto = 0.5 * cosseno(conceitosDeIntencoes(ids), vecC);
    set("intencao", true, direto.length ? Math.max(1 - 0.25 * Math.min(...direto), indireto) : indireto);
  } else set("intencao", false, 0);

  // objetivo escolhido
  if (objetivo) {
    const pos = (c.intencoes || []).map((i) => objetivo.intencoes.indexOf(i)).filter((i) => i >= 0);
    const direto = c.objetivo === objetivo.chave ? 1 : pos.length ? 1 / (1 + Math.min(...pos)) : 0;
    set("objetivo", true, Math.max(direto, 0.6 * cosseno(conceitosDeIntencoes(objetivo.intencoes), vecC)));
  } else set("objetivo", false, 0);

  // segmento (ramo)
  if (ctx.ramo) set("segmento", true, !c.ramos || c.ramos.length === 0 ? 0.5 : c.ramos.includes(ctx.ramo) ? 1 : 0);
  else set("segmento", false, 0);

  // rede
  if (ctx.redes.length && c.redes && c.redes.length) set("rede", true, c.redes.some((r) => ctx.redes.includes(r.toLowerCase())) ? 1 : 0);
  else set("rede", false, 0);

  // formato
  const quer = consulta?.formato || ctx.formatoPreferido || objetivo?.formatoPadrao || null;
  if (quer) set("formato", true, !c.formato || c.formato === "texto" ? 0.3 : c.formato === quer ? 1 : 0);
  else set("formato", false, 0);

  // contexto do negócio (detalhe informado pelo usuário)
  if (ctx.negocio) {
    const nt = tokens(ctx.negocio).filter((w) => w.length >= 4);
    set("contexto_negocio", nt.length > 0, nt.some((w) => tk.has(w)) ? 1 : 0);
  } else set("contexto_negocio", false, 0);

  // histórico (afinidade por formato)
  if (historico.temHistorico && c.formato) set("historico", true, ((historico.afinidadeFormato[c.formato] ?? 0) + 1) / 2);
  else set("historico", false, 0);

  // novidade
  const exposicao = historico.exposicao.get(c.id) || 0;
  set("novidade", true, 1 - exposicao);

  // qualidade (do conteúdo, não da tendência)
  let q = 0.5;
  if ((c.descricao || "").length >= 50) q += 0.2;
  if (c.texto) q += 0.1;
  if (c.nivel) q += 0.1;
  set("qualidade", true, q);

  // recência (conteúdo editorial envelhece devagar)
  if (c.atualizadoEm) { const d = dias(c.atualizadoEm, e.agora); set("recencia", true, d <= 30 ? 1 : Math.max(0.3, 1 - ((d - 30) / 335) * 0.7)); }
  else set("recencia", false, 0);

  const ausente: string[] = [...exigeContextoAusente(c, ctx)];
  if (c.rosto && ctx.permissoes.rosto === false) ausente.push("rosto");
  return { disponivel, valor, contextoAusente: ausente, exposicao };
}

// ---------------------------------------------------------------- EvoluiScore + explicabilidade
export type Explicacao = {
  algorithm_version: string;
  config_version: string;
  /** adequação ao contexto, 0 a 100. NÃO é previsão de resultado. */
  score: number;
  signals: Record<string, number>;
  penalties: { repetition: number; duplication: number; context_missing: number };
  unavailable: string[];
  context_missing: string[];
};
export type Pontuado = { c: Candidato; f: Features; explicacao: Explicacao };

const NOME_SINAL: Record<keyof Pesos, string> = {
  lexical: "lexical", semantico: "semantic", intencao: "intent", objetivo: "objective", segmento: "segment", rede: "network",
  formato: "format", contexto_negocio: "business_context", historico: "history", novidade: "novelty", qualidade: "quality", recencia: "recency",
};
const r1 = (n: number) => Math.round(n * 10) / 10;

export function evoluiScore(c: Candidato, f: Features, cfg: ConfigEIE): Pontuado {
  const chaves = Object.keys(cfg.pesos) as (keyof Pesos)[];
  const wDisp = chaves.reduce((s, k) => s + (f.disponivel[k] ? cfg.pesos[k] : 0), 0) || 1;
  const signals: Record<string, number> = {};
  let base = 0;
  for (const k of chaves) {
    if (!f.disponivel[k]) continue;
    const pts = (cfg.pesos[k] * f.valor[k] / wDisp) * 100;
    signals[NOME_SINAL[k]] = r1(pts); base += pts;
  }
  const pen = {
    repetition: r1(f.exposicao * cfg.penalidades.repeticao),
    duplication: 0,
    context_missing: f.contextoAusente.length ? r1(cfg.penalidades.contexto_ausente) : 0,
  };
  const score = r1(Math.max(0, Math.min(100, base - pen.repetition - pen.context_missing)));
  return {
    c, f,
    explicacao: {
      algorithm_version: EIE_VERSION, config_version: cfg.versaoConfig, score, signals, penalties: pen,
      unavailable: chaves.filter((k) => !f.disponivel[k]).map((k) => NOME_SINAL[k]), context_missing: f.contextoAusente,
    },
  };
}

// ---------------------------------------------------------------- diversidade (MMR + deduplicação)
export function similaridade(a: Candidato, b: Candidato): number {
  const ta = new Set(tokens(`${a.titulo} ${a.descricao || ""}`)), tb = new Set(tokens(`${b.titulo} ${b.descricao || ""}`));
  let inter = 0; for (const w of ta) if (tb.has(w)) inter++;
  const jac = ta.size + tb.size - inter ? inter / (ta.size + tb.size - inter) : 0;
  const tit = new Set(tokens(a.titulo)), tit2 = new Set(tokens(b.titulo));
  let ti = 0; for (const w of tit) if (tit2.has(w)) ti++;
  const jt = tit.size + tit2.size - ti ? ti / (tit.size + tit2.size - ti) : 0;
  let s = 0.45 * jac + 0.35 * jt;
  if (a.arquetipo && a.arquetipo === b.arquetipo) s += 0.25;
  if (a.formato && a.formato === b.formato) s += 0.05;
  return Math.min(1, s);
}

/** Escolhe k itens equilibrando relevância e diversidade. `jaEscolhidos` evita repetir o que já está na tela. */
export function selecionarMMR(pool: Pontuado[], k: number, cfg: ConfigEIE, jaEscolhidos: Candidato[] = []): Pontuado[] {
  const resto = [...pool].sort((a, b) => b.explicacao.score - a.explicacao.score);
  const escolhidos: Pontuado[] = [];
  const ref = () => [...jaEscolhidos, ...escolhidos.map((x) => x.c)];
  const redundancia = (p: Pontuado) => ref().reduce((m, o) => Math.max(m, similaridade(p.c, o)), 0);
  const { lambda, limiarSimilaridade } = cfg.mmr;
  while (escolhidos.length < k && resto.length) {
    const info = resto.map((p) => ({ p, red: redundancia(p) }));
    const novos = info.filter((x) => x.red < limiarSimilaridade);
    const base = novos.length ? novos : info;
    let melhor = base[0], mv = -Infinity;
    for (const x of base) { const v = lambda * (x.p.explicacao.score / 100) - (1 - lambda) * x.red; if (v > mv) { mv = v; melhor = x; } }
    if (melhor.red >= limiarSimilaridade) {
      const pts = r1(melhor.red * cfg.penalidades.duplicacao);
      melhor.p.explicacao.penalties.duplication = pts;
      melhor.p.explicacao.score = r1(Math.max(0, melhor.p.explicacao.score - pts));
    }
    escolhidos.push(melhor.p);
    resto.splice(resto.indexOf(melhor.p), 1);
  }
  return escolhidos;
}
