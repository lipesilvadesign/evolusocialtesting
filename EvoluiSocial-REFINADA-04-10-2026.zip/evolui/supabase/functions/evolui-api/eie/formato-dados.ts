// Format Intelligence — dados centralizados (02/10/2026).
// ofícios (vocabulário do tipo de trabalho), ênfases por objetivo e matriz de módulos (module_intelligence).
// Regra: isto é conhecimento sobre o TIPO de trabalho ("etapas típicas"), nunca fato sobre o usuário. O texto gerado sempre pede
// para a pessoa confirmar/escolher o que é real no trabalho dela.
export const FI_VERSION = "eie-v1-format-intelligence-v1";

export type Modulo = "mais_ideias" | "video_curto" | "guia_texto" | "stories" | "carrossel" | "formato_carrossel";

export type Oficio = {
  id: string; rotulo: string; gatilhos: string[];
  /** [rótulo da etapa, o que mostrar/explicar nela] */
  etapas: [string, string][];
  cena: string; ferramenta: string; resultado: string; decisao: string; invisivel: string; antes: string; depois: string; publico: string;
  generico?: boolean;
};

export const OFICIOS: Oficio[] = [
  { id: "fotografo", rotulo: "fotografia", gatilhos: ["fotograf", "ensaio", "fotografia"],
    etapas: [["preparação", "o que é organizado antes do primeiro clique"], ["equipamento", "a câmera e os acessórios escolhidos para esse trabalho"], ["cenário", "o local e a luz antes de a pessoa entrar no quadro"], ["processo", "o momento do trabalho acontecendo"], ["resultado final", "a foto escolhida, já editada"]],
    cena: "a câmera, a luz e o cenário", ferramenta: "câmera e iluminação", resultado: "a foto final", decisao: "a escolha de luz e enquadramento", invisivel: "a seleção e a edição das fotos", antes: "a foto bruta", depois: "a foto editada", publico: "quem procura fotografia" },
  { id: "designer", rotulo: "design", gatilhos: ["designer", "design grafico", "identidade visual", "logotipo", "design"],
    etapas: [["processo criativo", "o rascunho e as referências do início"], ["decisões visuais", "uma escolha de cor, tipografia ou composição e o motivo"], ["ferramentas", "o programa ou recurso usado nessa etapa"], ["antes e depois", "a versão inicial ao lado da versão final"], ["resultado", "o material finalizado em uso"]],
    cena: "a tela, as referências e as versões do projeto", ferramenta: "as ferramentas de design", resultado: "o material finalizado", decisao: "a escolha de cores, tipografia e composição", invisivel: "as versões descartadas e o motivo de cada uma", antes: "o rascunho inicial", depois: "a versão final", publico: "quem precisa de identidade visual" },
  { id: "restaurante", rotulo: "restaurante e comida pronta", gatilhos: ["restaurante", "lanchonete", "hamburguer", "pizzaria", "marmita", "cozinha", "delivery de comida", "bar "],
    etapas: [["preparação", "a cozinha organizada antes do serviço"], ["ingredientes", "os ingredientes do prato separados"], ["montagem", "o prato sendo montado"], ["cozinha", "o momento do preparo, com o som e o movimento"], ["prato final", "o prato pronto, de perto"]],
    cena: "a cozinha e a montagem do prato", ferramenta: "os ingredientes e utensílios", resultado: "o prato final", decisao: "o ponto de preparo e a montagem", invisivel: "o que acontece na cozinha antes de o prato sair", antes: "os ingredientes separados", depois: "o prato pronto", publico: "quem procura comida pronta" },
  { id: "confeitaria", rotulo: "confeitaria e doces", gatilhos: ["confeit", "doceria", "doce", "bolo", "brigadeiro", "padaria", "chocolate"],
    etapas: [["receita e ingredientes", "os ingredientes separados"], ["preparo da massa", "o ponto da massa ou da calda"], ["montagem", "as camadas ou a modelagem"], ["decoração", "o acabamento, de perto"], ["produto final", "o doce pronto, inteiro e cortado"]],
    cena: "a massa, a montagem e a decoração", ferramenta: "os ingredientes e utensílios", resultado: "o doce pronto", decisao: "o ponto da massa e o acabamento", invisivel: "as horas de preparo por trás do produto", antes: "os ingredientes separados", depois: "o doce decorado", publico: "quem procura doces para ocasiões" },
  { id: "beleza", rotulo: "beleza e estética", gatilhos: ["salao", "cabelo", "cabeleir", "estetica", "manicure", "maquiagem", "barbeiro", "barbearia", "sobrancelha", "unha"],
    etapas: [["conversa inicial", "o alinhamento do que a pessoa quer, sem expor dados"], ["preparo", "os produtos e ferramentas separados"], ["técnica aplicada", "a técnica em andamento, de perto"], ["finalização", "o acabamento"], ["resultado", "o resultado, com autorização de quem aparece"]],
    cena: "a técnica sendo aplicada", ferramenta: "os produtos e ferramentas de trabalho", resultado: "o resultado final", decisao: "a escolha da técnica e dos produtos", invisivel: "a avaliação feita antes de começar", antes: "o ponto de partida", depois: "o resultado final", publico: "quem procura cuidados de beleza" },
  { id: "moda", rotulo: "moda", gatilhos: ["roupa", "moda", "boutique", "vestuario", "brecho", "loja de roupa"],
    etapas: [["escolha das peças", "como as peças são selecionadas"], ["curadoria", "o que combina com o quê"], ["combinação", "o look sendo montado"], ["caimento", "a peça vestida, de perto"], ["look final", "o look completo"]],
    cena: "as peças, o caimento e as combinações", ferramenta: "as peças e acessórios", resultado: "o look montado", decisao: "a combinação entre as peças", invisivel: "como as peças são escolhidas", antes: "a peça sozinha", depois: "a peça combinada em um look", publico: "quem procura peças e looks" },
  { id: "saude", rotulo: "saúde", gatilhos: ["clinica", "dentista", "nutri", "psicolog", "fisioterap", "medic", "odonto"],
    etapas: [["acolhimento", "como a conversa começa, sem expor ninguém"], ["avaliação", "o que é observado antes de qualquer conduta"], ["explicação", "a explicação do cuidado em linguagem simples"], ["acompanhamento", "como o cuidado continua"], ["orientação final", "a orientação que a pessoa leva"]],
    cena: "a explicação de um cuidado, sem expor ninguém", ferramenta: "a avaliação e os recursos do atendimento", resultado: "o cuidado explicado com clareza", decisao: "como o cuidado é explicado", invisivel: "o que é avaliado antes de qualquer conduta", antes: "a dúvida mais comum", depois: "a explicação clara", publico: "quem procura cuidado em saúde" },
  { id: "fitness", rotulo: "treino e atividade física", gatilhos: ["academia", "personal trainer", "treino", "pilates", "crossfit", "yoga", "fitness"],
    etapas: [["objetivo da aula", "o que será trabalhado"], ["aquecimento", "como o corpo é preparado"], ["execução", "o exercício sendo executado"], ["ajuste de postura", "um ajuste e o motivo dele"], ["fechamento", "como a sessão termina"]],
    cena: "o exercício sendo executado", ferramenta: "os exercícios e equipamentos", resultado: "o exercício executado com técnica", decisao: "o ajuste de postura", invisivel: "o planejamento por trás do treino", antes: "a execução comum", depois: "a execução ajustada", publico: "quem quer treinar com orientação" },
  { id: "pet", rotulo: "cuidados com pets", gatilhos: ["pet", "banho e tosa", "veterin", "adestr"],
    etapas: [["recepção", "como o animal é recebido"], ["preparo", "os produtos e equipamentos"], ["procedimento", "o cuidado em andamento"], ["finalização", "o acabamento"], ["resultado", "o animal pronto, com autorização do tutor"]],
    cena: "o atendimento ao animal", ferramenta: "os produtos e equipamentos de cuidado", resultado: "o animal pronto", decisao: "o cuidado escolhido para cada animal", invisivel: "o preparo antes do banho ou do atendimento", antes: "o animal ao chegar", depois: "o animal ao sair", publico: "quem tem animal de estimação" },
  { id: "casa", rotulo: "casa, decoração e projetos", gatilhos: ["decor", "arquitet", "movel", "marcener", "interiores", "reforma"],
    etapas: [["briefing", "o que foi pedido"], ["referências", "as referências e medidas"], ["projeto", "o projeto ou desenho"], ["execução", "o trabalho em andamento"], ["ambiente final", "o ambiente pronto"]],
    cena: "o ambiente, as medidas e os materiais", ferramenta: "o projeto e os materiais", resultado: "o ambiente pronto", decisao: "a escolha de materiais e disposição", invisivel: "as medidas e ajustes de projeto", antes: "o ambiente original", depois: "o ambiente transformado", publico: "quem quer transformar um ambiente" },
  { id: "educacao", rotulo: "ensino", gatilhos: ["curso", "aula", "professor", "escola", "ingles", "mentor", "reforco"],
    etapas: [["tema da aula", "o assunto do dia"], ["exemplo", "um exemplo concreto"], ["explicação", "a explicação passo a passo"], ["exercício", "uma atividade para fixar"], ["resumo", "o resumo do que ficou"]],
    cena: "a explicação em andamento", ferramenta: "o material didático", resultado: "o conceito entendido", decisao: "o exemplo escolhido para explicar", invisivel: "como a aula é preparada", antes: "a dúvida do aluno", depois: "a explicação clara", publico: "quem quer aprender o assunto" },
  { id: "servicos", rotulo: "serviços profissionais", gatilhos: ["advog", "contab", "consultor", "imobili", "despachante", "seguro"],
    etapas: [["a dúvida do cliente", "a pergunta mais comum, sem expor ninguém"], ["análise", "o que é analisado primeiro"], ["explicação", "a resposta em linguagem simples"], ["solução", "o caminho indicado"], ["próximo passo", "o que a pessoa faz depois"]],
    cena: "uma explicação simples de um assunto do dia a dia", ferramenta: "a análise e os documentos", resultado: "a dúvida respondida", decisao: "como o problema é analisado", invisivel: "a análise feita antes da resposta", antes: "a dúvida", depois: "a resposta clara", publico: "quem tem essa dúvida" },
  { id: "criador", rotulo: "criação de conteúdo", gatilhos: ["criador", "influenc", "conteudo", "social media", "videomaker", "youtuber"],
    etapas: [["ideia", "de onde a ideia vem"], ["roteiro", "o roteiro ou os tópicos"], ["gravação", "a gravação em andamento"], ["edição", "um corte ou ajuste de ritmo"], ["publicação", "o conteúdo pronto"]],
    cena: "a gravação e a edição", ferramenta: "a câmera, o celular e o editor", resultado: "o conteúdo publicado", decisao: "o corte e o ritmo", invisivel: "as tentativas descartadas", antes: "o material bruto", depois: "o conteúdo editado", publico: "quem acompanha seu conteúdo" },
  { id: "artesanato", rotulo: "artesanato", gatilhos: ["artesan", "croche", "trico", "ceramica", "costura", "feito a mao", "ateli"],
    etapas: [["materiais", "os materiais escolhidos"], ["modelagem", "a peça tomando forma"], ["técnica", "a técnica em detalhe"], ["acabamento", "o acabamento, de perto"], ["peça final", "a peça pronta"]],
    cena: "as mãos, os materiais e a peça tomando forma", ferramenta: "os materiais e ferramentas", resultado: "a peça pronta", decisao: "a escolha de materiais e do acabamento", invisivel: "o tempo de produção de cada peça", antes: "os materiais soltos", depois: "a peça pronta", publico: "quem procura peças feitas à mão" },
];

/** ramo cadastrado → ofício de reserva (usado só quando o detalhe do negócio não permite algo mais específico) */
export const RAMO_OFICIO: Record<string, string> = {
  doces: "confeitaria", alimentacao: "restaurante", beleza: "beleza", moda: "moda", saude: "saude", fitness: "fitness", pet: "pet",
  casa: "casa", educacao: "educacao", servicos: "servicos", criador: "criador",
};

export const OFICIO_NEUTRO: Oficio = {
  id: "neutro", rotulo: "o seu trabalho", gatilhos: [], generico: true,
  etapas: [["ponto de partida", "como o trabalho começa"], ["o que você usa", "uma ferramenta ou material que você usa de verdade"], ["passo principal", "o momento central do trabalho"], ["detalhe de cuidado", "algo que exige atenção"], ["resultado", "o resultado, de perto"]],
  cena: "o seu trabalho de perto", ferramenta: "o que você usa no trabalho", resultado: "o resultado", decisao: "uma decisão que você toma no trabalho", invisivel: "algo do processo que quem vê de fora não percebe", antes: "o começo", depois: "o resultado", publico: "o seu público",
};

// ---------------------------------------------------------------- ênfase por objetivo (catálogo atual: chaves de evolui_objetivos_catalogo)
export type EnfaseId = "seguidores" | "alcance" | "interesse" | "apresentar" | "vender" | "tendencia" | "neutro";
export type Gancho = "curiosidade" | "pergunta" | "contraste" | "promessa";
export type Enfase = { id: EnfaseId; rotulo: string; gancho: Gancho; ritmo: "rapido" | "normal"; foco: string; marcador: RegExp | null };
export const ENFASES: Record<EnfaseId, Enfase> = {
  seguidores: { id: "seguidores", rotulo: "ganhar seguidores", gancho: "curiosidade", ritmo: "normal", foco: "criar um motivo para a pessoa querer ver a continuação", marcador: /\bsiga\b|\bseguir\b/i },
  alcance: { id: "alcance", rotulo: "aumentar o alcance", gancho: "contraste", ritmo: "rapido", foco: "ser entendido logo e valer a pena enviar para alguém", marcador: /envie|mande|compartilh/i },
  interesse: { id: "interesse", rotulo: "gerar interesse", gancho: "pergunta", ritmo: "normal", foco: "despertar curiosidade e provocar resposta", marcador: /comente|responda|conte/i },
  apresentar: { id: "apresentar", rotulo: "apresentar um produto ou serviço", gancho: "promessa", ritmo: "normal", foco: "mostrar o produto ou serviço em uso e como contratar", marcador: /whatsapp|direct|app|site|loja|canal|falar com voc|chame|chamar|pergunte/i },
  vender: { id: "vender", rotulo: "divulgar o negócio", gancho: "promessa", ritmo: "normal", foco: "mostrar o que a pessoa recebe e como pedir", marcador: /whatsapp|direct|app|site|loja|canal|falar com voc|chame|chamar|pe[cç]a|pergunte/i },
  tendencia: { id: "tendencia", rotulo: "aproveitar uma tendência", gancho: "contraste", ritmo: "rapido", foco: "ligar o assunto do momento ao seu trabalho", marcador: /comente|opini|conte/i },
  neutro: { id: "neutro", rotulo: "sem objetivo definido", gancho: "curiosidade", ritmo: "normal", foco: "ser claro e fácil de executar", marcador: null },
};
export const OBJETIVO_ENFASE: Record<string, EnfaseId> = {
  seguidores: "seguidores", visualizacoes: "alcance", ideia_video: "interesse", apresentar: "apresentar", divulgar: "vender", tendencia: "tendencia",
};
/** quando não há objetivo escolhido: a intenção da pesquisa decide */
export const INTENCAO_ENFASE: Record<string, EnfaseId> = {
  seguidores: "seguidores", alcance: "alcance", engajamento: "interesse", vendas: "vender", promocao: "vender", lancamento: "apresentar", autoridade: "interesse", tendencias: "tendencia", datas: "tendencia",
};

// ---------------------------------------------------------------- matriz de módulos (module_intelligence) — única fonte das regras por módulo
export type ModuloIntel = {
  modulo: Modulo; rotulo: string; pergunta: string; primary_goal: string; transformation: string;
  required_elements: string[]; optional_elements: string[]; forbidden_patterns: RegExp[]; output_structure: string[];
  quality_rules: string[]; profile_dependencies: string[];
};
const FMT_PALAVRAS = /\b(stories|story|slides?|carross[eé]is?|carrossel|reels|v[ií]deo curto|post)\b/i;
export const MODULE_INTELLIGENCE: Record<Modulo, ModuloIntel> = {
  mais_ideias: {
    modulo: "mais_ideias", rotulo: "Mais ideias para isso", pergunta: "Que outras ideias relevantes podem nascer desta ideia para este perfil?",
    primary_goal: "expandir a ideia original em ângulos diferentes", transformation: "expansão",
    required_elements: ["ideias[].angulo", "ideias[].titulo", "ideias[].descricao"], optional_elements: ["ideias[].execucao"],
    forbidden_patterns: [FMT_PALAVRAS], output_structure: ["ideias"],
    quality_rules: ["≥3 ideias", "ângulos distintos", "sem formato embutido", "diversidade (MMR)"], profile_dependencies: ["business_type", "content_context", "relevant_services"],
  },
  video_curto: {
    modulo: "video_curto", rotulo: "Ideia vídeo curto", pergunta: "Como essa ideia funciona especificamente como vídeo curto para este perfil?",
    primary_goal: "conceito executável de vídeo curto", transformation: "audiovisual",
    required_elements: ["cenas[gancho]", "cenas[desenvolvimento]", "cenas[fechamento]", "cenas[cta]"], optional_elements: ["ritmo", "duracao_aprox"],
    forbidden_patterns: [/\bslides?\b/i, /\bstor(?:y|ies)\b/i, /\bcarross/i], output_structure: ["gancho", "desenvolvimento", "fechamento", "cta"],
    quality_rules: ["cada cena tem ação visual, fala e texto na tela", "respeita preferência de aparecer"], profile_dependencies: ["content_context", "constraints", "preferred_networks"],
  },
  guia_texto: {
    modulo: "guia_texto", rotulo: "Guia de texto", pergunta: "Como desenvolver essa ideia por escrito para este perfil?",
    primary_goal: "estrutura textual: abertura, desenvolvimento, argumentação, encerramento e CTA", transformation: "desenvolvimento textual",
    required_elements: ["secoes[abertura]", "secoes[desenvolvimento]", "secoes[argumentacao]", "secoes[encerramento]", "secoes[cta]"], optional_elements: ["exemplo"],
    forbidden_patterns: [/\bcenas?\b/i, /\bslides?\b/i, /\bstor(?:y|ies)\b/i, /\bcortes?\b/i], output_structure: ["abertura", "desenvolvimento", "argumentacao", "encerramento", "cta"],
    quality_rules: ["cada seção traz orientação e exemplo de frase"], profile_dependencies: ["content_context", "relevant_services", "constraints"],
  },
  stories: {
    modulo: "stories", rotulo: "Ideia Stories", pergunta: "Como essa ideia vira uma sequência de Stories para este perfil?",
    primary_goal: "sequência interativa de Stories", transformation: "sequência interativa",
    required_elements: ["sequencia[Gancho]", "sequencia[Contexto]", "sequencia[Desenvolvimento]", "sequencia[CTA]"], optional_elements: ["recurso interativo (só quando pertinente)"],
    forbidden_patterns: [/\bslides?\b/i, /\bcenas?\b/i, /\bcarross/i], output_structure: ["Gancho", "Contexto", "Interação", "Desenvolvimento", "CTA"],
    quality_rules: ["4 a 7 stories", "recurso só quando há motivo"], profile_dependencies: ["content_context", "constraints", "observed_preferences"],
  },
  carrossel: {
    modulo: "carrossel", rotulo: "Ideia carrossel", pergunta: "Como transformar esta ideia em um carrossel?",
    primary_goal: "narrativa distribuída em slides", transformation: "narrativa em slides",
    required_elements: ["slides[Gancho]", "slides[Ponto]", "slides[Conclusão e CTA]"], optional_elements: ["slides[Contexto]"],
    forbidden_patterns: [/\bstor(?:y|ies)\b/i, /\bcenas?\b/i, /\bcortes?\b/i], output_structure: ["Gancho", "Contexto", "Pontos", "Conclusão e CTA"],
    quality_rules: ["quantidade de slides depende da ideia (3 a 9)", "sem slide artificial"], profile_dependencies: ["content_context", "relevant_services"],
  },
  formato_carrossel: {
    modulo: "formato_carrossel", rotulo: "Ideia formato carrossel", pergunta: "Qual estrutura de carrossel é mais adequada para esta ideia e para este perfil?",
    primary_goal: "escolher e justificar a estrutura de carrossel", transformation: "escolha/adaptação de estrutura",
    required_elements: ["estrutura_escolhida", "alternativas", "esqueleto"], optional_elements: ["compatibilidade"],
    forbidden_patterns: [/\bstor(?:y|ies)\b/i, /\bcenas?\b/i, /\bcortes?\b/i], output_structure: ["estrutura_escolhida", "alternativas", "esqueleto"],
    quality_rules: ["escolhe entre estruturas compatíveis", "explica por que escolheu"], profile_dependencies: ["content_context", "observed_preferences"],
  },
};

// ---------------------------------------------------------------- estruturas de carrossel e compatibilidade com o tipo de ideia (arquétipo)
export type EstruturaId = "lista" | "passo_a_passo" | "erro_solucao" | "antes_depois" | "problema_solucao" | "mito_verdade" | "comparacao" | "checklist" | "tutorial" | "historia" | "estudo_de_caso";
export const ESTRUTURAS: Record<EstruturaId, { rotulo: string; arq: Record<string, number>; enfase: Partial<Record<EnfaseId, number>>; minPontos: number }> = {
  lista: { rotulo: "Lista", arq: { generica: 0.6, dica: 0.7, erro_comum: 0.5, oferta: 0.4, bastidores: 0.4 }, enfase: { alcance: 0.8, seguidores: 0.5 }, minPontos: 3 },
  passo_a_passo: { rotulo: "Passo a passo", arq: { bastidores: 0.9, dica: 0.7, generica: 0.3 }, enfase: { seguidores: 0.7, interesse: 0.5 }, minPontos: 3 },
  erro_solucao: { rotulo: "Erro → solução", arq: { erro_comum: 1, dica: 0.6 }, enfase: { alcance: 0.8, interesse: 0.7 }, minPontos: 3 },
  antes_depois: { rotulo: "Antes → depois", arq: { antes_depois: 1, bastidores: 0.5, prova_social: 0.6 }, enfase: { apresentar: 0.8, vender: 0.7 }, minPontos: 3 },
  problema_solucao: { rotulo: "Problema → solução", arq: { erro_comum: 0.7, oferta: 0.8, lancamento: 0.6, dica: 0.6 }, enfase: { vender: 0.9, apresentar: 0.8 }, minPontos: 3 },
  mito_verdade: { rotulo: "Mito → verdade", arq: { erro_comum: 0.9, pergunta: 0.7, dica: 0.5 }, enfase: { interesse: 0.9, alcance: 0.7, tendencia: 0.6 }, minPontos: 3 },
  comparacao: { rotulo: "Comparação", arq: { pergunta: 0.8, dica: 0.5, oferta: 0.6, lancamento: 0.5 }, enfase: { interesse: 0.8, vender: 0.6 }, minPontos: 3 },
  checklist: { rotulo: "Checklist", arq: { dica: 0.8, oferta: 0.5, generica: 0.5 }, enfase: { alcance: 0.7, seguidores: 0.6 }, minPontos: 3 },
  tutorial: { rotulo: "Tutorial", arq: { dica: 0.9, bastidores: 0.6 }, enfase: { seguidores: 0.7, interesse: 0.5 }, minPontos: 3 },
  historia: { rotulo: "História", arq: { apresentacao: 1, bastidores: 0.7, prova_social: 0.7, generica: 0.4 }, enfase: { seguidores: 0.8, interesse: 0.6 }, minPontos: 3 },
  estudo_de_caso: { rotulo: "Estudo de caso", arq: { prova_social: 1, antes_depois: 0.7, erro_comum: 0.4 }, enfase: { apresentar: 0.8, vender: 0.8 }, minPontos: 3 },
};
