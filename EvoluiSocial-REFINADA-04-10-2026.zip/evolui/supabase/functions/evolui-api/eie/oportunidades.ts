// Camada de oportunidades: sinais → evidência → oportunidade. Funções puras (sem rede, sem banco).
// Distinção: sinal = algo acontecendo; tendência = sinal com crescimento/recorrência; oportunidade = potencial de ação para a pessoa.
import { normaliza, STOP } from "../consulta.ts";

export type Nivel = "alta" | "media" | "baixa";

/** Fusão por posição (Reciprocal Rank Fusion): vários rankings → um só, sem somar escalas diferentes. */
export function rrf(listas: string[][], k = 60): { item: string; score: number; fontes: number }[] {
  const mapa = new Map<string, { item: string; score: number; fontes: number }>();
  for (const lista of listas) {
    const vistos = new Set<string>();
    lista.forEach((it, i) => {
      const chave = normaliza(it);
      if (!chave || vistos.has(chave)) return;
      vistos.add(chave);
      const e = mapa.get(chave) || { item: it, score: 0, fontes: 0 };
      e.score += 1 / (k + i + 1);
      e.fontes += 1;
      mapa.set(chave, e);
    });
  }
  return [...mapa.values()].sort((a, b) => b.score - a.score || b.fontes - a.fontes || a.item.localeCompare(b.item));
}

export type VideoYT = { titulo: string; canal: string; url: string; data: string };
/** Lê a resposta de youtube/v3/search (part=snippet). Só guarda dados públicos; ignora itens malformados. */
export function parseYoutube(j: unknown, dias: string[]): { datas: string[]; videos: VideoYT[]; total: number; limitado: boolean } {
  const itens = (j && typeof j === "object" && Array.isArray((j as { items?: unknown }).items)) ? (j as { items: unknown[] }).items : [];
  const videos: VideoYT[] = [];
  const datas: string[] = [];
  const set = new Set(dias);
  for (const it of itens) {
    const o = it as { id?: { videoId?: string }; snippet?: { title?: string; channelTitle?: string; publishedAt?: string } };
    const id = o?.id?.videoId, sn = o?.snippet;
    if (!id || !/^[\w-]{6,20}$/.test(id) || !sn?.title || !sn.publishedAt) continue;
    const dia = String(sn.publishedAt).slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dia)) continue;
    if (set.has(dia)) datas.push(dia);
    videos.push({ titulo: decodifica(String(sn.title)).slice(0, 140), canal: decodifica(String(sn.channelTitle || "")).slice(0, 80), url: `https://www.youtube.com/watch?v=${id}`, data: dia });
  }
  return { datas, videos, total: videos.length, limitado: videos.length >= 50 };
}
function decodifica(s: string): string {
  return s.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
}

/** Termos que mais aparecem nos títulos dos vídeos (menos o próprio assunto): alimentam os "relacionados". */
export function termosDeTitulos(titulos: string[], assuntoTokens: string[], max = 8): string[] {
  const ign = new Set(assuntoTokens.map(normaliza));
  const cont = new Map<string, { n: number; txt: string }>();
  for (const t of titulos) {
    const vistos = new Set<string>();
    for (const w of t.split(/[^\p{L}\p{N}]+/u)) {
      const k = normaliza(w);
      if (k.length < 4 || STOP.has(k) || ign.has(k) || /^\d+$/.test(k) || vistos.has(k)) continue;
      vistos.add(k);
      const e = cont.get(k) || { n: 0, txt: w.toLowerCase() };
      e.n++; cont.set(k, e);
    }
  }
  return [...cont.values()].filter((e) => e.n >= 2).sort((a, b) => b.n - a.n || a.txt.localeCompare(b.txt)).slice(0, max).map((e) => e.txt);
}

export type FonteEvid = { nome: string; ok: boolean; temSinal: boolean; quantidade?: number };
export type Evidencia = {
  nivel: Nivel; fontes: string[]; quantidadeSinais: number; fontesConsultadas: number; data: string; motivo: string;
};

/** Nível de evidência rastreável: quantas fontes independentes mostram sinal. Baixa nunca é apresentada como certeza. */
export function evidencia(fontes: FonteEvid[], confianca: Nivel | null, agora = new Date().toISOString()): Evidencia {
  const com = fontes.filter((f) => f.ok && f.temSinal);
  const ativas = fontes.filter((f) => f.ok);
  const nivel: Nivel = confianca ?? (com.length >= 3 ? "alta" : com.length === 2 ? "media" : "baixa");
  const qtd = com.reduce((n, f) => n + (f.quantidade || 0), 0);
  const nomes = com.map((f) => f.nome);
  const motivo = com.length === 0
    ? `Nenhuma das ${ativas.length} fonte(s) consultada(s) mostrou volume suficiente. Trate como pista, não como fato.`
    : nivel === "alta" ? `${com.length} fontes independentes apontam na mesma direção (${nomes.join(", ")}).`
    : nivel === "media" ? `2 fontes mostram sinal (${nomes.join(" e ")}). Vale testar, confirmando com seu próprio resultado.`
    : `Só 1 fonte mostra sinal (${nomes[0]}). É um indício fraco: teste em pequena escala antes de apostar.`;
  return { nivel, fontes: nomes, quantidadeSinais: qtd, fontesConsultadas: ativas.length, data: agora, motivo };
}

export type Oportunidade = {
  tema: string; estado: string; tipo: "agir_agora" | "testar" | "acompanhar" | "sem_evidencia";
  oQueEstaAcontecendo: string; porQueImporta: string; oQuePodeFazer: string;
  evidencia: Evidencia; ideiasRelacionadas: number[]; algoritmo: string;
};

const ACAO: Record<string, string> = {
  em_alta: "Publique rápido: o assunto está em alta agora e a janela costuma ser curta.",
  pico: "Aproveite hoje, mas sem planejar muito à frente: o pico tende a cair.",
  crescendo: "Crie 2 conteúdos esta semana, enquanto a concorrência ainda é pequena.",
  comecando: "Teste 1 conteúdo curto e veja a reação antes de investir mais.",
  estavel: "Use como conteúdo constante: o interesse é regular, sem pressa.",
  caindo: "Evite apostar nisso agora; prefira um tema relacionado em alta.",
};
const TIPO: Record<string, Oportunidade["tipo"]> = { em_alta: "agir_agora", pico: "agir_agora", crescendo: "testar", comecando: "testar", estavel: "acompanhar", caindo: "acompanhar" };

export function detectarOportunidade(p: {
  tema: string; estado: string; rotulo: string; crescimento: number | null; evid: Evidencia; ideiasN: number; ramo?: string | null;
}): Oportunidade {
  const sem = p.estado === "insuficiente";
  const cres = p.crescimento == null ? "" : ` (${p.crescimento >= 0 ? "+" : ""}${Math.round(p.crescimento * 100)}% na semana)`;
  return {
    tema: p.tema, estado: p.estado,
    tipo: sem ? "sem_evidencia" : TIPO[p.estado] || "acompanhar",
    oQueEstaAcontecendo: sem ? `Ainda não há sinais suficientes sobre "${p.tema}".` : `"${p.tema}": ${p.rotulo.toLowerCase()}${cres}.`,
    porQueImporta: sem ? "Sem volume público suficiente, qualquer aposta seria chute." : p.ramo ? `Para quem atua em ${p.ramo}, isso indica quanto o público está procurando o tema agora.` : "Mostra quanto o público está procurando o tema agora.",
    oQuePodeFazer: sem ? "Tente um termo mais amplo ou use a biblioteca de ideias." : (p.evid.nivel === "baixa" ? "Teste em pequena escala. " : "") + (ACAO[p.estado] || ACAO.estavel),
    evidencia: p.evid, ideiasRelacionadas: Array.from({ length: p.ideiasN }, (_, i) => i), algoritmo: "oportunidade-v1",
  };
}
