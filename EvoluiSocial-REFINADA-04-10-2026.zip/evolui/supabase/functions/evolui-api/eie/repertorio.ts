// Repertório do Evolui na pesquisa (REP-v1, 02/10/2026). Módulo puro: sem rede, sem banco.
// Regras: o repertório é UMA fonte entre outras; nunca copia o artigo (o texto original nem sai do banco para cá);
// usa estruturas aprendidas para montar algo novo com o tema da pessoa; diferencia
//  - "referencia"   → conhecimento que existe na fonte (só título/fonte/conceitos)
//  - "interpretacao" → estrutura que o sistema leu na fonte e adaptou ao tema
//  - "derivado"     → hipótese construída pelo Evolui combinando conhecimentos (não está em nenhuma fonte).
import { extrairConceitos } from "../../evolui-repertorio/analise.ts";
import { normaliza, radical, STOP } from "../consulta.ts";

/** O que um formato ou objetivo costuma pedir (associação do SISTEMA, não afirmação de fonte). */
const POR_FORMATO: Record<string, string[]> = {
  reels: ["hook", "retencao", "abertura rapida", "curiosidade"],
  carrossel: ["titulo", "hook", "storytelling"],
  stories: ["engajamento", "pergunta"],
  live: ["engajamento", "atencao"],
};
const POR_OBJETIVO: Record<string, string[]> = {
  alcance: ["retencao", "hook", "algoritmo"],
  engajamento: ["pergunta", "engajamento"],
  vendas: ["prova social", "oferta", "chamada para acao", "dor do cliente"],
  autoridade: ["autoridade", "confianca", "prova social"],
  ideias: ["curiosidade", "storytelling"],
  legenda: ["copywriting", "chamada para acao", "hook"],
  seguidores: ["engajamento", "constancia", "hook"],
};

export type ConsultaRep = { original: string; radicais: string[]; formato: string | null; intencoes: { id: string }[]; assunto: string };

/** Chaves de conceito para o banco (evolui_rep_consultar.p_termos). Só o essencial, sem duplicar. */
export function termosParaRepertorio(c: ConsultaRep, topico: string): { termos: string[]; associados: string[] } {
  const diretos = extrairConceitos(`${c.original} ${topico}`, "", []).filter((x) => x.tipo === "conceito").map((x) => x.chave);
  const assoc = [...(c.formato ? POR_FORMATO[c.formato] || [] : []), ...c.intencoes.flatMap((i) => POR_OBJETIVO[i.id] || [])];
  const rad = c.radicais.filter((r) => r.length >= 4 && !STOP.has(r)).slice(0, 8);
  const bigramas = rad.slice(0, -1).map((r, i) => `expr:${r} ${rad[i + 1]}`);
  const termos = [...new Set([...diretos, ...assoc, ...rad.map((r) => "termo:" + r), ...bigramas, ...(c.assunto ? ["assunto:" + normaliza(c.assunto)] : [])])].slice(0, 40);
  const associados = [...new Set(assoc.filter((a) => !diretos.includes(a)))];
  return { termos, associados };
}

type Padrao = { tipo: string; estrutura: string };
export type ItemRep = { id: string; titulo: string; fonte: string | null; conceitos: string[]; aplicacoes: string[]; linguagem?: { padroes_titulo?: Padrao[]; aberturas?: Padrao[] } };
export type RespostaRep = { itens?: ItemRep[]; relacionados?: string[]; insights?: { id: string; titulo: string; texto: string; origem?: string }[] };

const hash = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };

/** Moldes por tipo de estrutura lida no repertório. {t} = tema da pessoa. Várias formas por tipo, para não soar sempre igual. */
const MOLDES: Record<string, string[]> = {
  como: ["Como {t} sem complicar", "Como começar com {t} hoje", "O passo a passo de {t} que ninguém mostra"],
  porque: ["Por que {t} funciona (ou não) para você", "Por que quase ninguém acerta em {t}"],
  lista: ["3 detalhes de {t} que mudam o resultado", "5 erros comuns em {t}", "3 perguntas antes de investir em {t}"],
  pergunta: ["Você já parou para pensar em {t}?", "O que seu público realmente quer saber sobre {t}?"],
  revelacao: ["O erro que atrapalha {t}", "O que ninguém conta sobre {t}"],
  "afirmacao forte": ["{t}: o que você faz hoje pode estar custando atenção", "Quase ninguém repara nisto em {t}"],
  dado: ["Um número sobre {t} que muda a conversa"],
  historia: ["Uma cena do dia a dia que explica {t}", "Quando eu percebi isto sobre {t}…"],
  contraste: ["Todo mundo faz assim em {t}. Mas e se fosse o contrário?"],
};

export type Gancho = { texto: string; estrutura: string; baseadoEm: string; origem: "interpretacao" };
export type BlocoRepertorio = {
  itens: { titulo: string; fonte: string | null; conceitos: string[]; aplicacoes: string[]; origem: "referencia"; motivo: string }[];
  ganchos: Gancho[];
  relacionados: string[];
  insights: { titulo: string; texto: string; origem: "derivado"; rotulo: string }[];
  rotulos: { referencia: string; interpretacao: string; derivado: string };
};

export const ROTULOS = {
  referencia: "Conhecimento do repertório do Evolui (fonte indicada)",
  interpretacao: "Estrutura lida no repertório e adaptada ao seu tema pelo Evolui",
  derivado: "Hipótese construída pelo Evolui (não está em nenhuma fonte)",
};

/** Monta o bloco que vai para a pessoa. Nada do texto original; só títulos de fonte, conceitos e estruturas adaptadas.
 *  `semente` (ex.: id do usuário + dia) alterna os moldes entre pesquisas. */
export function blocoRepertorio(r: RespostaRep | null | undefined, tema: string, associados: string[], semente: string, max = 3): BlocoRepertorio | null {
  const itens = (r?.itens || []).slice(0, max);
  if (!itens.length) return null;
  const t = (tema || "").trim().slice(0, 60) || "o seu assunto";
  const ganchos: Gancho[] = [];
  const vistos = new Set<string>();
  for (const it of itens) {
    const padroes = [...(it.linguagem?.padroes_titulo || []), ...(it.linguagem?.aberturas || [])];
    for (const p of padroes) {
      const m = MOLDES[p.tipo];
      if (!m || vistos.has(p.tipo)) continue;
      vistos.add(p.tipo);
      ganchos.push({ texto: m[hash(`${semente}|${it.id}|${p.tipo}`) % m.length].replace("{t}", t), estrutura: p.estrutura, baseadoEm: it.titulo, origem: "interpretacao" });
    }
  }
  const direta = new Set(itens.flatMap((i) => i.conceitos.map((c) => normaliza(c))));
  return {
    itens: itens.map((i) => ({
      titulo: i.titulo, fonte: i.fonte || null, conceitos: i.conceitos.slice(0, 5), aplicacoes: i.aplicacoes.slice(0, 4), origem: "referencia" as const,
      motivo: i.conceitos.some((c) => direta.has(normaliza(c))) && i.conceitos.length ? `Fala de ${i.conceitos.slice(0, 3).join(", ")}` : "Relacionado ao que você pediu",
    })),
    ganchos: ganchos.slice(0, 4),
    relacionados: (r?.relacionados || []).slice(0, 6),
    insights: (r?.insights || []).slice(0, 2).map((i) => ({ titulo: i.titulo, texto: i.texto, origem: "derivado" as const, rotulo: ROTULOS.derivado })),
    rotulos: ROTULOS,
  };
}
void radical;
