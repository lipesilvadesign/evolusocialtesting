// EIE — representação semântica LEVE, em português, sem API e sem modelo externo.
// Cada texto vira um vetor de CONCEITOS (ex.: "ideacao", "publicar"). Dois textos são parecidos quando falam dos mesmos
// conceitos, mesmo sem repetir palavras ("não sei o que postar" ≈ "ideias de conteúdo para começar a publicar").
// Não é embedding neural: é um dicionário curado e transparente. A interface SemanticoExterno (orquestrador) deixa
// pronto o ponto de encaixe para embeddings reais quando houver um modelo multilíngue disponível.
import { normaliza, radical, STOP } from "../consulta.ts";

/** Prefixos (sem acento) ou frases. Frases têm espaço e são procuradas no texto normalizado. */
export const CONCEITOS: Record<string, string[]> = {
  ideacao: ["ideia", "inspir", "pauta", "criativ", "bloqueio", "nao sei", "sem ideia", "o que postar"],
  publicar: ["post", "public", "conteud", "feed", "divulg"],
  video: ["video", "reel", "grav", "short", "tiktok", "roteiro", "film"],
  alcance: ["alcance", "viral", "visualiz", "view", "algoritm", "explor", "descobert", "aparec"],
  seguidores: ["seguidor", "seguir", "cresc", "audienc", "comunidad", "publico novo"],
  engajamento: ["engaj", "comentar", "curtid", "salv", "compartilh", "interac", "enquete", "pergunt", "conversa", "caixinha"],
  vendas: ["vend", "cliente", "compr", "pedido", "encomend", "oferta", "promoc", "descont", "cupom", "preco", "orcament", "agend"],
  confianca: ["confian", "autoridad", "depoiment", "prova", "credibil", "resultado", "referenc", "profission"],
  bastidores: ["bastidor", "process", "rotina", "tour", "bancada", "como fazer", "por tras", "making", "dia no meu"],
  educar: ["dica", "erro", "tutorial", "passo", "ensin", "aprend", "explic", "mito", "verdade", "duvida"],
  lancamento: ["lanc", "novidad", "estreia", "apresent", "inaugur", "produto novo"],
  tendencia: ["tendenc", "trend", "comemorat", "sazonal", "pascoa", "natal", "maes", "namorados", "momento"],
  local: ["cidade", "bairro", "regiao", "local", "vizinh", "perto"],
  planejar: ["planej", "calendar", "constanc", "cronogram", "semana", "frequenc", "organiz"],
  comecar: ["comec", "inicio", "iniciant", "primeiro", "zero", "novo perfil"],
  bio: ["bio", "biografi", "link na bio"],
  parceria: ["parceri", "collab", "colabor"],
  rosto: ["rosto", "aparec na camera", "quem faz", "quem somos", "apresentacao"],
};

/** Intenção detectada pela pesquisa (consulta.ts) → conceito correspondente. */
export const INTENCAO_CONCEITO: Record<string, string> = {
  seguidores: "seguidores", alcance: "alcance", engajamento: "engajamento", vendas: "vendas", ideias: "ideacao",
  planejamento: "planejar", primeiros: "comecar", tendencias: "tendencia", bio: "bio", legenda: "publicar",
  autoridade: "confianca", local: "local", lancamento: "lancamento", promocao: "vendas", datas: "tendencia",
};

export type VetorConceitos = Record<string, number>;

export function conceitosDe(texto: string): VetorConceitos {
  const norm = normaliza(texto || "");
  if (!norm) return {};
  const tokens = norm.split(" ").filter((w) => w && !STOP.has(w));
  const radicais = tokens.map(radical);
  const frase = " " + norm + " ";
  const v: VetorConceitos = {};
  for (const [conceito, chaves] of Object.entries(CONCEITOS)) {
    let n = 0;
    for (const k of chaves) {
      if (k.includes(" ")) { if (frase.includes(" " + k + " ") || frase.includes(" " + k)) n++; continue; }
      for (let i = 0; i < tokens.length; i++) {
        const t = tokens[i], r = radicais[i];
        if (t === k || r === k || (k.length >= 4 && (t.startsWith(k) || r.startsWith(k))) || (k.length === 3 && (t === k))) n++;
      }
    }
    if (n) v[conceito] = n;
  }
  return v;
}

export function cosseno(a: VetorConceitos, b: VetorConceitos): number {
  let dot = 0, na = 0, nb = 0;
  for (const k of Object.keys(a)) { na += a[k] * a[k]; if (b[k]) dot += a[k] * b[k]; }
  for (const k of Object.keys(b)) nb += b[k] * b[k];
  return na && nb ? dot / Math.sqrt(na * nb) : 0;
}

export function similaridadeConceitos(textoA: string, textoB: string): number {
  return cosseno(conceitosDe(textoA), conceitosDe(textoB));
}

/** Conceitos de uma intenção/objetivo (para comparar com o candidato). */
export function conceitosDeIntencoes(ids: string[]): VetorConceitos {
  const v: VetorConceitos = {};
  ids.forEach((id, i) => { const c = INTENCAO_CONCEITO[id]; if (c) v[c] = (v[c] || 0) + 1 / (i + 1); });
  return v;
}
