// EIE — orquestrador do pipeline:
// candidatos → features → EvoluiScore → filtro → MMR → Context Engine → (provedor opcional) → quality gate → fallback seguro.
// Nenhuma etapa externa é obrigatória: sem provedor, sem índice semântico e sem sinal de tendência, o resultado continua válido.
import { EIE_VERSION, type ConfigEIE } from "./config.ts";
import { type Card, type ContextoUsuario, type Origem, avaliarCard, registrarFrases, sanitizarTexto, limparTitulo } from "./contexto.ts";
import {
  FORMATO_ROTULO, ARQUETIPOS, contextualizar, detectarArquetipo, explicarPorque, sinalRelacionado, validarGerado,
  type PorQue, type ProvedorGeracao, type SinalTendencia,
} from "./geracao.ts";
import {
  evoluiScore, extrairFeatures, HISTORICO_VAZIO, selecionarMMR,
  type Candidato, type ConsultaEIE, type Explicacao, type HistoricoEIE, type ObjetivoEIE, type Pontuado,
} from "./ranking.ts";

export type EntradaEIE = {
  consulta?: ConsultaEIE | null;
  objetivo?: ObjetivoEIE | null;
  candidatos: Candidato[];
  contexto: ContextoUsuario;
  historico?: HistoricoEIE;
  cfg: ConfigEIE;
  k: number;
  /** itens já na tela (não repetir, e contam para a diversidade) */
  jaEscolhidos?: Candidato[];
  excluirIds?: string[];
  provedor?: ProvedorGeracao | null;
  sinalTendencia?: SinalTendencia | null;
  semanticoExterno?: Map<string, number>;
  agora?: Date;
};

export type ExplicabilidadeEIE = Explicacao & {
  candidate_id: string;
  candidate_type: string;
  archetype: string | null;
  why: { kind: string; text: string; origin: Origem }[];
  provenance: { title: Origem; description: Origem; execution: Origem; why: Origem };
  quality: { ok: boolean; failures: string[]; genericity: number; fallback: boolean };
  context_level: ContextoUsuario["nivel"];
};
export type ItemEIE = { candidato: Candidato; card: Card; textoSeguro?: string; explicabilidade: ExplicabilidadeEIE };
export type SaidaEIE = {
  itens: ItemEIE[];
  meta: {
    algoritmo: string; configVersao: string; totalCandidatos: number; elegiveis: number; filtrados: { id: string; motivo: string }[];
    fallbacks: string[]; descartados: string[]; provedor: string | null; provedorErro?: string;
    latenciaMs: { ranking: number; contexto: number; total: number };
  };
};

const agoraMs = () => (typeof performance !== "undefined" ? performance.now() : Date.now());
const r1 = (n: number) => Math.round(n * 10) / 10;

/** Card que nunca afirma nada que dependa de contexto desconhecido. Usado quando o card normal falha no controle de qualidade. */
export function cardSeguro(c: Candidato, ctx: ContextoUsuario): Card {
  const arq = c.arquetipo || detectarArquetipo(c);
  const A = arq ? ARQUETIPOS[arq] : undefined;
  const fmt = c.formato && FORMATO_ROTULO[c.formato] ? FORMATO_ROTULO[c.formato] : null;
  const titulo = limparTitulo(c.titulo, ctx) || A?.tituloSeguro || (fmt ? `Uma ideia de ${fmt} para o seu perfil` : "Uma ideia para o seu perfil");
  const orig = sanitizarTexto(c.descricao || "", ctx).texto;
  return {
    titulo,
    descricao: orig.length >= 30 ? orig : `Uma ideia de conteúdo${fmt ? ` em formato de ${fmt}` : ""} sobre ${titulo.charAt(0).toLowerCase()}${titulo.slice(1)}.`,
    execucao: ["Escolha o que vai mostrar, em uma frase.", "Grave ou fotografe de perto, com boa luz.", "Termine dizendo qual é o próximo passo para quem assistiu."],
    porque: "Sugestão geral.",
  };
}

export async function rodarEIE(e: EntradaEIE): Promise<SaidaEIE> {
  const t0 = agoraMs();
  const { cfg, contexto: ctx, consulta = null, objetivo = null } = e;
  const agora = e.agora || new Date();
  const historico = e.historico || HISTORICO_VAZIO;
  const excluidos = new Set(e.excluirIds || []);
  const fora = new Set((e.jaEscolhidos || []).map((c) => c.id));
  const filtrados: { id: string; motivo: string }[] = [];

  // 1) arquétipo + features + EvoluiScore
  const base = e.candidatos.filter((c) => {
    if (excluidos.has(c.id) || fora.has(c.id)) { filtrados.push({ id: c.id, motivo: "ja_exibido" }); return false; }
    return true;
  });
  const maxScoreSql = Math.max(1, ...base.map((c) => c.scoreSql ?? (c.comp ? Object.values(c.comp).reduce((s, x) => s + x, 0) : 0)));
  const pontuados: Pontuado[] = base.map((c) => {
    const cand = c.arquetipo ? c : { ...c, arquetipo: detectarArquetipo(c) };
    const f = extrairFeatures(cand, { consulta, objetivo, ctx, historico, cfg, maxScoreSql, agora, semanticoExterno: e.semanticoExterno });
    return evoluiScore(cand, f, cfg);
  });

  // 2) filtro: candidato que depende de contexto que não temos só entra se faltar opção
  const sem = pontuados.filter((p) => p.f.contextoAusente.length === 0 && p.f.exposicao < 1);
  const comProblema = pontuados.filter((p) => !sem.includes(p));
  // item que declara depender de contexto ausente, ou cujo título já afirma isso, nunca entra. Se só um trecho da descrição afirma, o trecho é removido e o item entra com penalidade.
  const reparavel = (p: Pontuado) => !(p.c.requer || []).some((a) => (a === "local" || a === "presencial") && !ctx.permissoes[a]) && limparTitulo(p.c.titulo, ctx) !== null && !p.f.contextoAusente.includes("rosto");
  const pool = sem.length >= e.k ? sem : [...sem, ...comProblema.filter((p) => p.f.exposicao < 1 && reparavel(p)).sort((a, b) => b.explicacao.score - a.explicacao.score).slice(0, Math.max(0, e.k - sem.length + 2))];
  for (const p of pontuados) if (!pool.includes(p)) filtrados.push({ id: p.c.id, motivo: p.f.exposicao >= 1 ? "rejeitado_pelo_usuario" : "contexto_ausente:" + p.f.contextoAusente.join("+") });

  // 3) diversidade
  const escolhidos = selecionarMMR(pool, e.k, cfg, e.jaEscolhidos || []);
  const t1 = agoraMs();

  // 4) Context Engine + quality gate
  const vistos = new Set<string>();
  const usados = new Map<string, number>();
  let tendenciaUsada = false;
  const itens: ItemEIE[] = [];
  const fallbacks: string[] = [], descartados: string[] = [];

  for (const p of escolhidos) {
    const permiteSinal = !tendenciaUsada && sinalRelacionado(p.c, e.sinalTendencia, consulta);
    const porque: PorQue[] = explicarPorque({ c: p.c, ctx, f: p.f, ex: p.explicacao, consulta, objetivo, sinal: permiteSinal ? e.sinalTendencia : null, usados });
    const out = p.c.cardBase
      ? { card: { ...p.c.cardBase, porque: porque.map((x) => x.texto).join(" ") }, sanitizadas: 0, arquetipo: p.c.arquetipo || null, titulo_ajustado: false }
      : contextualizar(p.c, ctx, porque);
    let card = out.card, usouFallback = false;
    const temTendencia = porque.some((x) => x.kind === "tendencia");
    let q = avaliarCard(card, ctx, { vistos, sinalExternoValido: temTendencia, genericidadeMaxima: cfg.qualidade.genericidadeMaxima, repeticaoSoNoPorque: !!p.c.cardBase });
    let porqueFinal = porque;
    if (!q.ok && p.c.cardBase) { descartados.push(p.c.id); fallbacks.push(`${p.c.id}:${q.falhas[0] || "qualidade"}`); continue; }
    if (!q.ok) {
      const qOrig = q;
      const seg = cardSeguro(p.c, ctx);
      porqueFinal = [{ kind: "geral", texto: seg.porque, origem: "derived" }];
      const q2 = avaliarCard(seg, ctx, { vistos, sinalExternoValido: false, genericidadeMaxima: 1 });
      // o cartão seguro só falha por repetição de texto: nesse caso o item sai, para não duplicar
      if (!q2.ok && q2.falhas.some((x) => x !== "texto_repetido" && x !== "generico")) { descartados.push(p.c.id); continue; }
      card = seg; q = q2; usouFallback = true; fallbacks.push(`${p.c.id}:${(qOrig.falhas[0] || "qualidade")}`);
      if (q2.falhas.includes("texto_repetido")) { descartados.push(p.c.id); continue; }
    }
    if (!usouFallback && temTendencia) tendenciaUsada = true;
    for (const w of porqueFinal) usados.set(w.texto, (usados.get(w.texto) || 0) + 1);
    registrarFrases(card, vistos, !!p.c.cardBase);
    const textoSeguro = p.c.texto ? sanitizarTexto(p.c.texto, ctx).texto : undefined;
    itens.push({
      candidato: p.c, card, textoSeguro,
      explicabilidade: {
        ...p.explicacao,
        candidate_id: p.c.id, candidate_type: p.c.tipo, archetype: out.arquetipo,
        why: porqueFinal.map((x) => ({ kind: x.kind, text: x.texto, origin: x.origem })),
        provenance: { title: out.titulo_ajustado || usouFallback ? "generated" : "retrieved", description: "generated", execution: "generated", why: "derived" },
        quality: { ok: q.ok, failures: q.falhas, genericity: q.genericidade, fallback: usouFallback },
        context_level: ctx.nivel,
      },
    });
  }

  // 5) provedor opcional (texto mais natural). Nunca decide ranking e qualquer falha mantém o texto determinístico.
  let provedorUsado: string | null = null, provedorErro: string | undefined;
  if (cfg.llm.ativo && e.provedor && itens.length) {
    const alvo = itens.slice(0, cfg.llm.maxItens);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), cfg.llm.timeoutMs);
    try {
      const fatos: string[] = [];
      if (ctx.ramoRotulo) fatos.push(`ramo: ${ctx.ramoRotulo}`);
      if (ctx.negocio) fatos.push(`negócio: ${ctx.negocio}`);
      if (ctx.permissoes.local && ctx.cidade) fatos.push(`cidade: ${ctx.cidade}`);
      if (ctx.permissoes.presencial) fatos.push("atende em espaço físico");
      if (ctx.permissoes.rosto === false) fatos.push("não quer aparecer no vídeo");
      const gerado = await e.provedor.gerar(alvo.map((i) => ({ id: i.candidato.id, titulo: i.card.titulo, descricao: i.card.descricao, execucao: i.card.execucao, fatos })), ctrl.signal);
      provedorUsado = e.provedor.nome;
      for (const i of alvo) {
        const novo = gerado[i.candidato.id];
        if (!novo) continue;
        const ok = validarGerado(i.card, novo, ctx, cfg.qualidade.genericidadeMaxima);
        if (ok) { i.card = ok; i.explicabilidade.provenance.description = "generated"; i.explicabilidade.provenance.execution = "generated"; }
        else fallbacks.push(`${i.candidato.id}:texto_ia_rejeitado`);
      }
    } catch (err) {
      provedorErro = err instanceof Error ? err.message.slice(0, 80) : "erro";
      fallbacks.push("provedor:" + provedorErro);
    } finally { clearTimeout(timer); }
  }

  const t2 = agoraMs();
  return {
    itens,
    meta: {
      algoritmo: EIE_VERSION, configVersao: cfg.versaoConfig, totalCandidatos: e.candidatos.length, elegiveis: pool.length,
      filtrados, fallbacks, descartados, provedor: provedorUsado, ...(provedorErro ? { provedorErro } : {}),
      latenciaMs: { ranking: r1(t1 - t0), contexto: r1(t2 - t1), total: r1(t2 - t0) },
    },
  };
}
