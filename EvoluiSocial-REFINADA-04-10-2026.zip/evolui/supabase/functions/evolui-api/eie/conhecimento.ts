// Evolui Knowledge Engine (EKE) — aquisição semântica incremental.
// Não treina nem reescreve o modelo/código: pesquisa lacunas, estrutura conhecimento
// com proveniência e devolve contexto para o EIE. A camada é aditiva e reversível.

export type ResultadoConhecimento = {
  termo: string;
  entidade: string;
  tipo: "negocio" | "profissao" | "ramo" | "produto" | "conceito" | "outro";
  significados: string[];
  termosRelacionados: string[];
  contexto: string;
  confianca: number;
  necessitaDesambiguacao: boolean;
  perguntasPesquisa: string[];
  fontes: { titulo: string; url: string | null }[];
};

const STOP = new Set("a o e de da do das dos para por com em um uma no na os as que quero quero fazer ideia ideias video vídeo reels post conteúdo conteudo sobre meu minha meus minhas criar me dê me de".split(/\s+/));
const KNOWN = new Set("corretora corretor imobiliaria imobiliária seguros seguro enfermagem enfermagem marketing barbearia academia restaurante advogado advocacia dentista clínica clinica marmoraria contabilidade contabilidade fotografia fotógrafo fotografo salão salao construtora arquitetura engenharia".split(/\s+/));

function norm(s: string): string { return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9\s-]/g, " ").replace(/\s+/g, " ").trim(); }
function tokens(s: string): string[] { return norm(s).split(/\s+/).filter((x) => x.length > 2 && !STOP.has(x)); }
function unique(a: string[], n = 16): string[] { return [...new Set(a.map((x) => String(x || "").trim()).filter(Boolean))].slice(0, n); }

export function deveAdquirirConhecimento(termo: string, consulta: { assunto?: string | null; confianca?: string; intencoes?: unknown[] }): boolean {
  const t = tokens(termo);
  if (!t.length) return false;
  if (consulta.confianca === "baixa") return true;
  if (t.length <= 2 && t.some((x) => KNOWN.has(x))) return true;
  if (t.length <= 2 && !t.every((x) => KNOWN.has(x))) return true;
  return !consulta.assunto || (consulta.intencoes || []).length === 0;
}

function tipoEntidade(termo: string): ResultadoConhecimento["tipo"] {
  const t = norm(termo);
  if (/corretor|corretora|advogad|dentist|fotograf|contabil|engenh|arquit|barbeir/.test(t)) return "profissao";
  if (/seguro|imovel|imobili|academia|restaurante|clinica|marmoraria|construtora/.test(t)) return "negocio";
  return "conceito";
}

export function criarPerguntasPesquisa(termo: string, contexto = "marketing e conteúdo para redes sociais"): string[] {
  const t = String(termo).trim();
  return [
    `"${t}" significado ${contexto}`,
    `"${t}" ramo mercado profissão negócio`,
    `"${t}" termos relacionados público serviços`,
    `"${t}" ideias conteúdo títulos vídeos redes sociais`,
  ];
}

export function estruturarConhecimento(termo: string, resultados: Array<{ titulo?: string; snippet?: string; url?: string }>): ResultadoConhecimento {
  const t = String(termo).trim();
  const textos = resultados.flatMap((r) => [r.titulo || "", r.snippet || ""]);
  const rel = unique(textos.flatMap(tokens));
  const sig = unique(textos.filter((x) => /é|significa|consiste|empresa|profissional|mercado|serviço|servicos|ramo|atua|especializ/i.test(x)).slice(0, 6), 4);
  const amb = /^corretor(a)?$/i.test(t) || /^banco$/i.test(t) || /^consultor(a)?$/i.test(t);
  const confianca = Math.min(0.96, 0.45 + Math.min(0.45, resultados.length * 0.08) + (sig.length ? 0.08 : 0));
  return {
    termo: t,
    entidade: t,
    tipo: tipoEntidade(t),
    significados: sig,
    termosRelacionados: rel,
    contexto: textos.slice(0, 4).join(" | ").slice(0, 1000),
    confianca,
    necessitaDesambiguacao: amb,
    perguntasPesquisa: criarPerguntasPesquisa(t),
    fontes: resultados.slice(0, 8).map((r) => ({ titulo: String(r.titulo || "Pesquisa web"), url: r.url ? String(r.url) : null })),
  };
}
