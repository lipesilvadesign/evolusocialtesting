// EIE — contexto do usuário, procedência dos dados, regra "não inventar contexto" e controle de qualidade (quality gate).
import { normaliza, radical, STOP } from "../consulta.ts";
import { RAMOS } from "../motor.ts";

/** De onde veio cada informação. explicit = o usuário informou; retrieved = veio do banco; derived = calculada; generated = texto gerado. */
export type Origem = "explicit" | "retrieved" | "derived" | "generated";
export type RamoCtx = { termo: string; cena: string; clientes: string };

export type ContextoUsuario = {
  ramo: string | null;
  ramoRotulo: string | null;
  /** Detalhe informado pelo usuário (ex.: "bolos de festa"). Nunca é inventado a partir do ramo. */
  negocio: string | null;
  cidade: string | null;
  canalVenda: string | null;
  formatoPreferido: string | null;
  aparecer: "nao" | "voz" | null;
  tom: string | null;
  horario: string | null;
  redes: string[];
  ramoCtx: RamoCtx | null;
  /** O que o motor PODE afirmar. Sem permissão, qualquer frase que dependa disso é removida. */
  permissoes: { local: boolean; presencial: boolean; rosto: boolean | null };
  origem: Record<string, Origem>;
  nivel: "vazio" | "parcial" | "completo";
  personalizar: boolean;
};

const FORMATO_PREF: Record<string, string> = { "Reels": "reels", "Carrossel": "carrossel", "Stories": "stories", "Foto única": "foto" };

export type EntradaContexto = {
  perfil?: { ramo?: string | null; ramo_detalhe?: string | null; cidade?: string | null; objetivo?: string | null; personalizar?: boolean | null } | null;
  respostas?: Record<string, string> | null;
  redes?: string[] | null;
  ramoCtx?: RamoCtx | null;
  /** ids de intenção detectados na pesquisa (consulta.ts) */
  intencoes?: string[];
};

const limpo = (s: unknown, max = 80) => (typeof s === "string" ? s.replace(/[{}<>"]/g, "").replace(/\s+/g, " ").trim().slice(0, max) : "");

export function montarContexto(e: EntradaContexto): ContextoUsuario {
  const p = e.perfil || {};
  const personalizar = p.personalizar !== false;
  const r = personalizar ? (e.respostas || {}) : {};
  const origem: Record<string, Origem> = {};
  const marca = (k: string, v: unknown) => { if (v) origem[k] = "explicit"; return v; };
  const ramo = limpo(p.ramo, 30) || null; marca("ramo", ramo);
  const negocio = limpo(p.ramo_detalhe, 60) || null; marca("negocio", negocio);
  const cidade = limpo(p.cidade, 60) || null; marca("cidade", cidade);
  const canalVenda = limpo(r.canal_venda, 40) || null; marca("canal_venda", canalVenda);
  const formatoPreferido = FORMATO_PREF[r.formato_preferido || ""] || null; marca("formato_preferido", formatoPreferido);
  const aparecer = r.aparecer === "Prefiro não aparecer" ? "nao" : r.aparecer === "Só a voz" ? "voz" : null; marca("aparecer", aparecer);
  const tom = limpo(r.tom, 30) || null, horario = limpo(r.horario, 30) || null;
  const redes = (e.redes || []).map((x) => limpo(x, 30).toLowerCase()).filter(Boolean);
  if (redes.length) origem.redes = "explicit";
  const intencoes = e.intencoes || [];
  const ramoCtx = ramo && e.ramoCtx ? e.ramoCtx : null; if (ramoCtx) origem.ramo_ctx = "retrieved";
  // Cidade só vira afirmação quando há motivo: loja física informada ou o próprio pedido é local. Cidade sozinha não basta.
  const presencial = canalVenda === "Loja física";
  const local = !!cidade && (presencial || intencoes.includes("local"));
  const campos = [ramo, negocio, cidade, canalVenda, redes.length ? "r" : null].filter(Boolean).length;
  return {
    ramo, ramoRotulo: ramo ? (RAMOS[ramo]?.rotulo || null) : null, negocio, cidade, canalVenda, formatoPreferido, aparecer, tom, horario, redes, ramoCtx,
    permissoes: { local, presencial, rosto: aparecer ? false : null },
    origem, nivel: campos === 0 ? "vazio" : campos >= 4 ? "completo" : "parcial", personalizar,
  };
}

// ---------------------------------------------------------------- "não inventar contexto"
export type Afirmacao = "local" | "presencial";
const pal = (alt: string) => new RegExp(`(?<![\\p{L}\\p{N}])(?:${alt})(?![\\p{L}\\p{N}])`, "iu");
const RE_AFIRMACAO: Record<Afirmacao, RegExp> = {
  local: pal("cidade|bairro|regi[aã]o|vizinh[\\p{L}]*|moradores|perto de voc[eê]"),
  presencial: pal("loja|ateli[eê]|est[uú]dio|bancada|balc[aã]o|vitrine|presencial|visite|passe na loja"),
};

export function afirmacoesDe(texto: string): Afirmacao[] {
  return (Object.keys(RE_AFIRMACAO) as Afirmacao[]).filter((k) => RE_AFIRMACAO[k].test(texto || ""));
}
export function afirmacoesNaoSuportadas(texto: string, ctx: ContextoUsuario): Afirmacao[] {
  return afirmacoesDe(texto).filter((a) => !ctx.permissoes[a]);
}
/** O candidato declara (requer) ou o texto revela dependência de contexto que o usuário não tem. */
export function exigeContextoAusente(c: { requer?: string[]; titulo?: string; descricao?: string; texto?: string }, ctx: ContextoUsuario): Afirmacao[] {
  const decl = (c.requer || []).filter((a): a is Afirmacao => (a === "local" || a === "presencial") && !ctx.permissoes[a]);
  const detectado = afirmacoesNaoSuportadas(`${c.titulo || ""} ${c.descricao || ""} ${c.texto || ""}`, ctx);
  return Array.from(new Set([...decl, ...detectado]));
}

/** Remove frases que afirmam o que não sabemos. */
export function sanitizarTexto(texto: string, ctx: ContextoUsuario): { texto: string; removidas: number } {
  let removidas = 0;
  const out = (texto || "").replace(/[^.!?\n]+[.!?]*[ \t]*/g, (s) => {
    if (afirmacoesNaoSuportadas(s, ctx).length) { removidas++; return ""; }
    return s;
  });
  return { texto: out.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim(), removidas };
}

const PENDENTES = new Set(["por", "quem", "e", "é", "para", "pra", "de", "da", "do", "a", "o", "com", "em", "na", "no", "que", "ou", "e", "ao"]);
/** Tira o trecho local do título (ex.: "… da sua cidade"). Se o título perder o sentido, devolve null. */
export function limparTitulo(titulo: string, ctx: ContextoUsuario): string | null {
  if (!afirmacoesNaoSuportadas(titulo, ctx).length) return titulo;
  const t = titulo.replace(/\s+(?:da|na|de|em|do|no)\s+(?:sua|seu)\s+(?:cidade|regi[aã]o|bairro)(?![\p{L}])/giu, "").trim();
  if (!t || afirmacoesNaoSuportadas(t, ctx).length) return null;
  const ultimo = normaliza(t).split(" ").pop() || "";
  return PENDENTES.has(ultimo) || t.length < 10 ? null : t;
}

// ---------------------------------------------------------------- quality gate
export type Card = { titulo: string; descricao: string; execucao: string[]; porque: string };
export type ResultadoQualidade = { ok: boolean; falhas: string[]; genericidade: number };

/** Expressões que enchem linguiça. Aparecem só se o texto disser algo concreto além delas. */
export const CLICHES = [
  "onde a magica acontece", "gere conexao", "humanize sua marca", "aproxime seu publico", "mostre o lado real", "fortaleca sua presenca",
  "conexao genuina", "conteudo de valor", "engaje seu publico", "autenticidade", "lado humano", "conquiste seu publico",
];

export function genericidadeTexto(texto: string): number {
  const norm = normaliza(texto);
  if (!norm) return 1;
  const palavras = norm.split(" ").filter((w) => w && !STOP.has(w));
  const unicas = new Set(palavras.map(radical));
  const cliches = CLICHES.filter((c) => norm.includes(c)).length;
  const densidade = palavras.length ? unicas.size / palavras.length : 0;
  let g = cliches * 0.4;
  if (palavras.length < 6) g += 0.25;
  if (densidade < 0.65) g += 0.2;
  return Math.min(1, Math.round(g * 100) / 100);
}

const RE_VAZAMENTO = /(undefined|null|NaN|\[object|\{[a-z_]+\})/;
const RE_NUMERO_SOLTO = /\b\d+\s*%/;
const RE_SINAL_EXTERNO = /(nas fontes analisadas|est[aá] (?:est[aá]vel|em alta|crescendo|caindo)|o formato que mais|buscas em alta)/i;
const RE_APARECER = /(olhe para a c[aâ]mera|mostre (?:o )?seu rosto|apare[cç]a (?:no v[ií]deo|na c[aâ]mera)|fale olhando|termine olhando para a c[aâ]mera)/i;

export type OpcoesQualidade = {
  /** frases (normalizadas) já usadas em outros cards desta resposta */
  vistos: Set<string>;
  /** o card pode citar sinal externo (tendência) porque ele foi validado para este candidato */
  sinalExternoValido?: boolean;
  genericidadeMaxima: number;
  /** conteúdo pronto (ideias do motor): a repetição só é checada na justificativa, pois a chamada para ação pode ser a mesma */
  repeticaoSoNoPorque?: boolean;
};

const frasesDe = (t: string) => t.split(/(?<=[.!?])\s+|\n+/).map((s) => normaliza(s)).filter((s) => s.length >= 25);

export function avaliarCard(card: Card, ctx: ContextoUsuario, o: OpcoesQualidade): ResultadoQualidade {
  const falhas: string[] = [];
  const todo = [card.titulo, card.descricao, ...card.execucao, card.porque].join("\n");
  // coerência
  if (!card.titulo || card.titulo.length < 8 || card.titulo.length > 160) falhas.push("titulo_invalido");
  if (!card.descricao || card.descricao.length < 20) falhas.push("descricao_curta");
  if (RE_VAZAMENTO.test(todo)) falhas.push("texto_com_marcador");
  // contexto: nada que dependa de informação que não temos
  const naoSup = afirmacoesNaoSuportadas(todo, ctx);
  if (naoSup.length) falhas.push("contexto_inventado:" + naoSup.join("+"));
  // grounding: números e sinais externos só com fonte validada
  if (!o.sinalExternoValido && RE_SINAL_EXTERNO.test(card.porque)) falhas.push("sinal_sem_fonte");
  if (RE_NUMERO_SOLTO.test(card.porque)) falhas.push("numero_sem_fonte");
  // contradição entre campos e preferências
  if (ctx.permissoes.rosto === false && RE_APARECER.test(card.execucao.join(" "))) falhas.push("contradiz_preferencia_rosto");
  // executabilidade
  if (card.execucao.length < 2 || card.execucao.some((s) => s.length < 8 || s.length > 260)) falhas.push("nao_executavel");
  // linguagem
  if (/\s{2,}|\b([\p{L}]{2,})\s+\1\b/iu.test(todo.replace(/\n/g, " "))) falhas.push("linguagem");
  // repetição entre cards
  const frases = o.repeticaoSoNoPorque ? frasesDe(card.porque) : [...frasesDe(card.porque), ...frasesDe(card.descricao)];
  if (frases.some((f) => o.vistos.has(f))) falhas.push("texto_repetido");
  // genericidade
  const gen = genericidadeTexto(`${card.titulo}. ${card.descricao} ${card.execucao.join(" ")}`);
  if (gen > o.genericidadeMaxima) falhas.push("generico");
  return { ok: falhas.length === 0, falhas, genericidade: gen };
}
export function registrarFrases(card: Card, vistos: Set<string>, soPorque = false) {
  for (const f of soPorque ? frasesDe(card.porque) : [...frasesDe(card.porque), ...frasesDe(card.descricao)]) vistos.add(f);
}
