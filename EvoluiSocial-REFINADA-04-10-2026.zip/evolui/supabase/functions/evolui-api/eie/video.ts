// Evolui Social — Video Intelligence (Pro/Master)
// Camada agnóstica de inferência: pode usar um modelo open-source
// (ex.: Qwen2.5-VL) hospedado em um serviço próprio/compatível.

export type AnaliseVideo = {
  versao: string;
  modo: "video" | "metadados";
  url: string;
  plataforma: string;
  titulo: string | null;
  autor: string | null;
  descricao: string;
  transcricao: string | null;
  tema: string | null;
  formato: string | null;
  gancho: string | null;
  cta: string | null;
  elementosVisuais: string[];
  pontosFortes: string[];
  pontosAtencao: string[];
  termos: string[];
  confianca: number;
  estrutura: Array<{ tipo: string; inicio_seg: number; fim_seg: number; texto: string }>;
  retorica: Record<string, unknown>;
  ritmo: Record<string, unknown>;
  cenas: Array<Record<string, unknown>>;
  sinaisVisuais: Record<string, unknown>;
  dna: Record<string, unknown>;
  lacunas: Array<Record<string, unknown>>;
  oportunidades: Array<Record<string, unknown>>;
  eviScore: Record<string, unknown>;
  proveniencia: Record<string, unknown>;
  impressaoDigital: string | null;
  ajusteContextualObservavel: Record<string, unknown>;
};

export type IdeiaVideo = {
  titulo: string;
  angulo: string;
  motivo: string;
  formato: string;
  prioridade: number;
};

const texto = (v: unknown, max = 600) => String(v ?? "").replace(/[<>"{}]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
const lista = (v: unknown, max = 8, itemMax = 180) => Array.isArray(v) ? v.map((x) => texto(x, itemMax)).filter(Boolean).slice(0, max) : [];
const objeto = (v: unknown) => (v && typeof v === "object" && !Array.isArray(v) ? v as Record<string, unknown> : {});

export function normalizarAnaliseVideo(raw: unknown, base: { url: string; plataforma?: string; titulo?: string | null; autor?: string | null }): AnaliseVideo {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const descricao = texto(r.descricao || r.summary || r.description, 1200);
  const confianca = Math.max(0, Math.min(1, Number(r.confianca ?? r.confidence ?? 0.75) || 0.75));
  return {
    versao: texto(r.versao, 50) || "video-intelligence-v1",
    modo: descricao ? "video" : "metadados",
    url: base.url,
    plataforma: texto(r.plataforma || base.plataforma || "video", 30),
    titulo: texto(r.titulo || base.titulo, 180) || null,
    autor: texto(r.autor || base.autor, 120) || null,
    descricao: descricao || "Não foi possível obter a descrição completa do vídeo; os dados abaixo são uma leitura básica do link.",
    transcricao: texto(r.transcricao || r.transcript, 5000) || null,
    tema: texto(r.tema || r.topic, 160) || null,
    formato: texto(r.formato || r.format, 80) || null,
    gancho: texto(r.gancho || r.hook, 240) || null,
    cta: texto(r.cta, 240) || null,
    elementosVisuais: lista(r.elementos_visuais || r.elementosVisuais || r.visual_elements),
    pontosFortes: lista(r.pontos_fortes || r.pontosFortes || r.strengths),
    pontosAtencao: lista(r.pontos_atencao || r.pontosAtencao || r.attention_points),
    termos: lista(r.termos || r.keywords || r.terms, 12, 80),
    confianca,
    estrutura: Array.isArray(r.estrutura) ? (r.estrutura as unknown[]).slice(0, 80).map((x) => { const o = objeto(x); return { tipo: texto(o.tipo, 60), inicio_seg: Number(o.inicio_seg) || 0, fim_seg: Number(o.fim_seg) || 0, texto: texto(o.texto, 600) }; }) : [],
    retorica: objeto(r.retorica),
    ritmo: objeto(r.ritmo),
    cenas: Array.isArray(r.cenas) ? (r.cenas as unknown[]).slice(0, 80).map((x) => objeto(x)) : [],
    sinaisVisuais: objeto(r.sinais_visuais || r.sinaisVisuais),
    dna: objeto(r.dna),
    lacunas: Array.isArray(r.lacunas) ? (r.lacunas as unknown[]).slice(0, 12).map((x) => objeto(x)) : [],
    oportunidades: Array.isArray(r.oportunidades) ? (r.oportunidades as unknown[]).slice(0, 12).map((x) => objeto(x)) : [],
    eviScore: objeto(r.evi_score || r.eviScore),
    proveniencia: objeto(r.proveniencia),
    impressaoDigital: texto(r.impressao_digital || r.impressaoDigital, 32) || null,
    ajusteContextualObservavel: objeto(r.ajuste_contextual_observavel || r.ajusteContextualObservavel),
  };
}

export function promptAnaliseVideo(ctx: { ramo?: string | null; objetivo?: string | null; cidade?: string | null; url: string }) {
  return [
    "Analise este vídeo para uma plataforma brasileira de inteligência de conteúdo chamada Evolui Social.",
    "Retorne SOMENTE JSON válido, sem markdown.",
    "Campos: descricao, transcricao, tema, formato, gancho, cta, elementos_visuais[], pontos_fortes[], pontos_atencao[], termos[], confianca.",
    "Descreva somente o que for observável ou transcrito; não invente métricas, intenção ou desempenho.",
    `Contexto do usuário: ramo=${texto(ctx.ramo, 100) || "não informado"}; objetivo=${texto(ctx.objetivo, 100) || "não informado"}; cidade=${texto(ctx.cidade, 100) || "não informado"}.`,
    `URL do vídeo: ${ctx.url}`,
  ].join("\n");
}

export function gerarIdeiasVideo(a: AnaliseVideo, ctx: { ramo?: string | null; objetivo?: string | null }): IdeiaVideo[] {
  const tema = a.tema || a.termos[0] || a.titulo || "este tema";
  const ramo = ctx.ramo || "seu segmento";
  const gancho = a.gancho || "a pergunta central do vídeo";
  const cta = a.cta || "uma chamada para a ação";
  const base = [
    { titulo: `Continuação: ${tema}`, angulo: "Levar o assunto um passo adiante", motivo: "Parte do tema identificado no vídeo e evita simplesmente repetir o conteúdo.", prioridade: 92 },
    { titulo: `O outro lado de ${tema}`, angulo: "Contraste / erro comum", motivo: `Explora uma nova perspectiva a partir do gancho: ${gancho}.`, prioridade: 86 },
    { titulo: `Como aplicar ${tema} na prática`, angulo: "Demonstração / passo a passo", motivo: `Transforma o assunto observado em uma ação prática para ${ramo}.`, prioridade: 82 },
    { titulo: `Resposta para quem viu este vídeo`, angulo: "Pergunta / sequência", motivo: `Cria continuidade usando a chamada para ação observada: ${cta}.`, prioridade: 76 },
  ];
  for (const op of a.oportunidades.slice(0, 2)) {
    const o = objeto(op);
    const tituloOp = texto(o.titulo, 140);
    const razaoOp = texto(o.razao, 240);
    if (tituloOp) base.push({ titulo: tituloOp, angulo: texto(o.tipo, 80) || "Oportunidade estrutural", motivo: razaoOp || "Sinal identificado pelo EVI.", prioridade: 80 });
  }
  return base.map((x) => ({ ...x, formato: a.formato || "vídeo curto" })).slice(0, 6);
}
