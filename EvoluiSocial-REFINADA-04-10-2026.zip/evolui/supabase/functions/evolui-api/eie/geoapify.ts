// Geoapify (OPCIONAL): geocodificação e contagem de estabelecimentos. Puro: só monta URLs e lê respostas.
// A chave vai na URL (exigência do provedor) e a URL NUNCA é registrada em log.
export const GEO_CATEGORIAS: Record<string, string[]> = {
  doces: ["commercial.food_and_drink.bakery", "catering.ice_cream", "commercial.food_and_drink.confectionery"],
  alimentacao: ["catering.restaurant", "catering.fast_food", "catering.cafe"],
  beleza: ["service.beauty", "service.beauty.hairdresser"],
  moda: ["commercial.clothing", "commercial.shoes", "commercial.jewelry"],
  saude: ["healthcare.dentist", "healthcare.clinic_or_praxis"],
  fitness: ["sport.fitness"],
  pet: ["pet.shop", "pet.veterinary"],
  casa: ["commercial.furniture_and_interior", "commercial.houseware_and_hardware"],
  educacao: ["education.school"],
  servicos: ["office.lawyer", "office.accountant", "office.estate_agent"],
};
export function urlGeocode(cidade: string, uf: string, chave: string): string {
  return `https://api.geoapify.com/v1/geocode/search?text=${encodeURIComponent(`${cidade}, ${uf}, Brasil`)}&filter=countrycode:br&limit=1&format=json&apiKey=${encodeURIComponent(chave)}`;
}
export function urlLugares(lat: number, lon: number, ramo: string, chave: string, raioM = 8000): string | null {
  const cats = GEO_CATEGORIAS[ramo];
  if (!cats || !Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  return `https://api.geoapify.com/v2/places?categories=${cats.join(",")}&filter=circle:${lon.toFixed(5)},${lat.toFixed(5)},${Math.round(raioM)}&limit=100&apiKey=${encodeURIComponent(chave)}`;
}
export function lerGeocode(j: unknown): { lat: number; lon: number } | null {
  const r = (j as { results?: { lat?: number; lon?: number }[] })?.results?.[0];
  return r && Number.isFinite(r.lat) && Number.isFinite(r.lon) ? { lat: r.lat as number, lon: r.lon as number } : null;
}
/** A API devolve no máximo 100 por chamada: acima disso a contagem é "100 ou mais". */
export function lerLugares(j: unknown): { total: number; limitado: boolean } | null {
  const f = (j as { features?: unknown[] })?.features;
  if (!Array.isArray(f)) return null;
  return { total: f.length, limitado: f.length >= 100 };
}
