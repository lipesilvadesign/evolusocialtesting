// EIE — cola entre a API (index.ts) e o motor: monta contexto/histórico a partir do banco, converte os dados do
// projeto em candidatos e devolve a resposta com a explicação de cada item. Funções puras (testáveis sem rede).
import { normaliza, type Consulta } from "../consulta.ts";
import type { Ideia } from "../motor.ts";
import { CONFIG_PADRAO, mesclarConfig, type ConfigEIE } from "./config.ts";
import { montarContexto, sanitizarTexto, type ContextoUsuario, type RamoCtx } from "./contexto.ts";
import type { ProvedorGeracao, SinalTendencia } from "./geracao.ts";
import type { ItemEIE, SaidaEIE } from "./orquestrador.ts";
import { construirHistorico, type Candidato, type EventoEIE, type HistoricoEIE, type ObjetivoEIE, type RecomEIE, type CtaHist } from "./ranking.ts";

// ---------------------------------------------------------------- contexto + histórico (a partir de evolui_eie_contexto)
export type ContextoBanco = {
  perfil?: Record<string, unknown> | null; respostas?: Record<string, string> | null; redes?: string[] | null; ramo_ctx?: RamoCtx | null;
  personalizar?: boolean; eventos?: (EventoEIE & { candidato_tipo?: string })[]; recomendacoes?: (RecomEIE & { tipo?: string })[]; ctas?: CtaHist[];
  config?: { versao?: string; pesos?: unknown; params?: unknown } | null;
};
export function prepararEIE(rpc: ContextoBanco | null | undefined, intencoes: string[], agora = new Date()): { ctx: ContextoUsuario; cfg: ConfigEIE; historico: HistoricoEIE } {
  const b = rpc || {};
  const personalizar = b.personalizar !== false;
  const cfg = mesclarConfig(CONFIG_PADRAO, b.config ? { pesos: b.config.pesos, params: b.config.params } : null, b.config?.versao || "cfg-padrao");
  const ctx = montarContexto({
    perfil: { ...(b.perfil || {}), personalizar } as Parameters<typeof montarContexto>[0]["perfil"],
    respostas: b.respostas || {}, redes: Array.isArray(b.redes) ? b.redes.filter((x): x is string => typeof x === "string") : [],
    ramoCtx: b.ramo_ctx && typeof b.ramo_ctx.cena === "string" ? b.ramo_ctx : null, intencoes,
  });
  // sem personalização, nenhum histórico entra no ranking
  const historico = personalizar
    // as 5 ideias do motor são refeitas a cada busca: o id não "gasta" a ideia, mas o formato continua alimentando a afinidade
    ? construirHistorico((b.eventos || []).map((e) => (e.candidato_tipo === "ideia" ? { ...e, candidato_id: "" } : e)), (b.recomendacoes || []).filter((r) => r.tipo !== "ideia"), b.ctas || [], cfg, agora)
    : construirHistorico([], [], [], cfg, agora);
  return { ctx, cfg, historico };
}

// ---------------------------------------------------------------- ideias do motor → candidatos
const MODELOS_IDEIA: { casa: RegExp; slug: string; formato: string; arquetipo: string; intencoes: string[] }[] = [
  { casa: /^reels/i, slug: "reels", formato: "reels", arquetipo: "lancamento", intencoes: ["alcance", "ideias"] },
  { casa: /^carrossel/i, slug: "carrossel", formato: "carrossel", arquetipo: "dica", intencoes: ["engajamento", "autoridade"] },
  { casa: /^stories/i, slug: "stories", formato: "stories", arquetipo: "pergunta", intencoes: ["engajamento"] },
  { casa: /^bastidores/i, slug: "bastidores", formato: "reels", arquetipo: "bastidores", intencoes: ["autoridade", "engajamento"] },
  { casa: /^post em parceria/i, slug: "parceria", formato: "post", arquetipo: "parceria", intencoes: ["seguidores", "alcance"] },
];
const semAspas = (s: string) => s.replace(/^["“”]+|["“”]+$/g, "").trim();

/** O texto da ideia leva o termo pesquisado. Para a checagem de contexto o termo é neutralizado: pesquisar "decoração de loja" não é afirmar que o usuário tem loja. */
function neutro(s: string, termo: string): string {
  const t = termo.trim();
  if (t.length < 2) return s;
  return s.split(new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi")).join("o tema");
}
export function ideiasParaCandidatos(lista: Ideia[], termo: string): Candidato[] {
  const out: Candidato[] = [];
  for (const i of lista) {
    const m = MODELOS_IDEIA.find((x) => x.casa.test(i.formato));
    if (!m) continue;
    out.push({
      id: `ideia:${m.slug}`, tipo: "ideia", titulo: semAspas(i.gancho), descricao: i.legenda.replace(/\s*\n\s*/g, " "), formato: m.formato,
      intencoes: m.intencoes, arquetipo: m.arquetipo, doAssunto: true, carga: i,
      cardBase: {
        titulo: neutro(semAspas(i.gancho), termo), descricao: neutro(i.legenda.replace(/\s*\n\s*/g, " "), termo), execucao: i.roteiro.map((r) => neutro(r, termo)),
      },
    });
  }
  return out;
}
/** Ideias na ordem do EIE, com `porque` próprio de cada uma e explicação resumida. Se o EIE descartar tudo, devolve o original. */
export function aplicarEmIdeias(saida: SaidaEIE, original: Ideia[], estado?: { rotulo: string; estado: string }): (Ideia & { eie?: unknown })[] {
  const itens = saida.itens.filter((i) => i.candidato.tipo === "ideia");
  if (!itens.length) return original;
  return itens.map((i) => {
    const base = i.candidato.carga as Ideia;
    let porque = i.card.porque;
    if (estado && /nas fontes que consultamos/.test(porque)) {
      if (estado.estado === "pico") porque += " É um pico: publique logo ou não publique.";
      if (estado.estado === "caindo") porque += " O interesse está caindo: use como gancho, não como campanha.";
    }
    if (base.dica) porque += ` ${base.dica}`;
    return { ...base, porque, eie: compacto(i) };
  });
}

// ---------------------------------------------------------------- biblioteca
export type ItemBib = {
  id: string; tipo?: string; titulo: string; descricao?: string; texto?: string; formato?: string | null; tags?: string[]; intencoes?: string[];
  ramos?: string[]; requer?: string[]; nivel?: string | null; atualizado_em?: string | null; score?: number; motivo?: string;
  comp?: Candidato["comp"]; [k: string]: unknown;
};
const lexicalDe = (c?: Candidato["comp"]) => (c ? c.exata + c.parcial + c.palavras + 1.4 * c.parecida + 0.4 * c.tags : 0);
export function bibliotecaParaCandidatos(itens: ItemBib[]): Candidato[] {
  return itens.map((i) => ({
    id: String(i.id), tipo: "biblioteca" as const, titulo: i.titulo, descricao: i.descricao || "", texto: i.texto || undefined, formato: i.formato || null,
    tags: i.tags || [], intencoes: i.intencoes || [], ramos: i.ramos || [], requer: i.requer || [], nivel: i.nivel || null, atualizadoEm: i.atualizado_em || null,
    comp: i.comp, scoreSql: i.comp ? lexicalDe(i.comp) : undefined, carga: i,
  }));
}
/** Itens na ordem do EIE. Ideias recebem descrição e passos do Context Engine; ganchos e bios mantêm o texto pronto (sem as frases que dependem de contexto que falta). */
export function aplicarEmBiblioteca(saida: SaidaEIE, ctx: ContextoUsuario) {
  return saida.itens.filter((i) => i.candidato.tipo === "biblioteca").map((i) => {
    const orig = i.candidato.carga as ItemBib;
    const ideia = orig.tipo === "ideia";
    const descOrig = sanitizarTexto(orig.descricao || "", ctx).texto;
    return {
      ...orig,
      titulo: i.card.titulo,
      descricao: ideia ? i.card.descricao : descOrig,
      ...(ideia ? { execucao: i.card.execucao } : {}),
      ...(orig.texto ? { texto: i.textoSeguro ?? orig.texto } : {}),
      motivo: i.card.porque,
      eie: compacto(i),
    };
  });
}

// ---------------------------------------------------------------- modelos de CTA
export type ModeloCta = { id: string; objetivo: string; titulo: string; descricao: string; formato?: string | null; instrucoes?: string[]; gancho?: string; publico?: string; redes?: string[]; rosto?: boolean; ramos?: string[]; ordem?: number };
export function modelosParaCandidatos(modelos: ModeloCta[], ramo: string | null): Candidato[] {
  const limpa = (t: string) => t.replace(/\{[a-z_]+\}/g, "").replace(/\s+/g, " ").trim();
  return modelos.filter((m) => !m.ramos?.length || !ramo || m.ramos.includes(ramo)).map((m) => ({
    id: m.id, tipo: "cta_modelo" as const, titulo: limpa(m.titulo), descricao: limpa(`${m.descricao} ${(m.instrucoes || []).join(" ")}`), formato: m.formato || null,
    redes: m.redes || [], ramos: m.ramos || [], objetivo: m.objetivo, rosto: !!m.rosto, doAssunto: false,
    // o modelo traz {em_cidade}: quem decide se a cidade aparece é a permissão do contexto (p_sem_cidade), não o texto do modelo
    carga: m,
  }));
}

// ---------------------------------------------------------------- explicação para a resposta e para o log
export function compacto(i: ItemEIE) {
  const x = i.explicabilidade;
  return {
    versao: x.algorithm_version, config: x.config_version, nota: x.score, sinais: x.signals, penalidades: x.penalties,
    indisponiveis: x.unavailable, contexto_faltando: x.context_missing, arquetipo: x.archetype,
    porque: x.why, procedencia: x.provenance, qualidade: { ok: x.quality.ok, fallback: x.quality.fallback },
  };
}
/** Para evolui_eie_recomendacoes: só ids, nota e formato. Nenhum texto do usuário. */
export function itensParaLog(saida: SaidaEIE) {
  return saida.itens.map((i) => ({ id: i.candidato.id, tipo: i.candidato.tipo, formato: i.candidato.formato || null, score: i.explicabilidade.score, por: i.explicabilidade.why.map((w) => w.kind) }));
}
export function metaParaLog(saida: SaidaEIE) {
  const m = saida.meta;
  return { total: m.totalCandidatos, elegiveis: m.elegiveis, filtrados: m.filtrados.length, fallbacks: m.fallbacks, descartados: m.descartados.length, provedor: m.provedor, latencia_ms: m.latenciaMs };
}

// ---------------------------------------------------------------- sinal de tendência (só o que a busca realmente mediu)
export function sinalDaBusca(estado: string, rotulo: string, topico: string, confianca: "alta" | "media" | "baixa" | null, em: string): SinalTendencia | null {
  if (estado === "insuficiente" || !topico) return null;
  return { fonte: "wikipedia+gdelt+trends", termo: topico, rotulo, estado, escopo: "consulta", em, confianca };
}

export function consultaParaEIE(c: Consulta) {
  return { original: c.original, termosBusca: c.termosBusca, intencoes: c.intencoes, formato: c.formato, assunto: c.assunto, assuntoTokens: c.assuntoTokens, plataforma: c.plataforma ?? null, localizacao: c.localizacao ?? null };
}
export function objetivoParaEIE(o: { chave: string; rotulo: string; intencoes: string[]; formato_padrao?: string | null } | null | undefined): ObjetivoEIE | null {
  return o ? { chave: o.chave, rotulo: o.rotulo, intencoes: o.intencoes, formatoPadrao: o.formato_padrao ?? null } : null;
}

export type { ProvedorGeracao };
export const termoSeguro = (s: string) => normaliza(s);
