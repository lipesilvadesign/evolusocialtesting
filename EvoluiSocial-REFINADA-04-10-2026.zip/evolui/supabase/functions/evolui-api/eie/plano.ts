// Central de Conteúdo (02/10/2026): transforma UMA ideia em um planejamento executável (hook, promessa, roteiro, guia de gravação,
// texto na tela, legenda, hashtags, CTA). Função pura e determinística, sem rede e sem LLM. Reaproveita o gerador de roteiros
// do Format Intelligence (criarModulo) e o vocabulário do ofício; não substitui nada do que já existe.
// Regra de honestidade: o que vem de pesquisa (FATO) fica separado do que a Evolui deduz do perfil (INTERPRETAÇÃO) e do que ela
// recomenda (SUGESTÃO). Onde só a pessoa sabe o detalhe real, o texto traz um [campo] para ela preencher.
import { limparTitulo, type ContextoUsuario } from "./contexto.ts";
import type { EnfaseId } from "./formato-dados.ts";
import { aPt, criarModulo, dePt, escolherOficio, temaDaIdeia, type IdeiaEntrada } from "./formato.ts";
import type { HistoricoEIE } from "./ranking.ts";

export const PLANO_VERSION = "plano-v1";
export const FORMATOS = ["reels", "tiktok", "short", "carrossel", "imagem", "meme", "stories", "outro"] as const;
export type FormatoPlano = typeof FORMATOS[number];
export const FORMATO_ROTULO: Record<FormatoPlano, string> = {
  reels: "Reels", tiktok: "TikTok", short: "Short", carrossel: "Carrossel", imagem: "Imagem", meme: "Meme", stories: "Stories", outro: "Outro",
};
const VIDEO = new Set<FormatoPlano>(["reels", "tiktok", "short"]);
export const ehVideo = (f: FormatoPlano) => VIDEO.has(f);

export type HookTipo = "pergunta" | "contraste" | "erro_comum" | "promessa" | "dado" | "demonstracao" | "historia" | "curiosidade" | "provocacao";
const HOOK_PREF: Record<EnfaseId, HookTipo[]> = {
  seguidores: ["curiosidade", "historia", "demonstracao", "pergunta"],
  alcance: ["contraste", "provocacao", "erro_comum", "curiosidade"],
  interesse: ["pergunta", "provocacao", "curiosidade", "contraste"],
  apresentar: ["demonstracao", "promessa", "contraste", "historia"],
  vender: ["promessa", "demonstracao", "erro_comum", "pergunta"],
  tendencia: ["contraste", "dado", "provocacao", "pergunta"],
  neutro: ["curiosidade", "pergunta", "demonstracao", "promessa"],
};
const TODOS: HookTipo[] = ["pergunta", "contraste", "erro_comum", "promessa", "dado", "demonstracao", "historia", "curiosidade", "provocacao"];

export type EntradaPlano = {
  ideia: IdeiaEntrada; formato: FormatoPlano; ctx: ContextoUsuario; hist?: HistoricoEIE | null; seed: string;
  objetivo?: { chave: string; rotulo?: string; intencoes?: string[] } | null; intencoes?: string[];
  /** o que a pesquisa encontrou (texto curto vindo da fonte). Sem isso não há FATO. */
  fato?: string | null;
  /** tipos de hook a evitar (os já usados nesta ideia) */
  evitarHooks?: HookTipo[];
  /** assunto pesquisado (termo da busca); preferido para o hook e a legenda */
  tema?: string | null;
};

const cap = (s: string) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
const semPonto = (s: string) => s.replace(/[.\s]+$/, "").trim();
function hash(s: string) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
const FIM_FRACO = /\s+(de|do|da|dos|das|e|a|o|os|as|em|no|na|nos|nas|com|por|para|que|ou|um|uma)$/i;
function curto(s: string, n: number) {
  if (s.length <= n) return s;
  const c = s.slice(0, n);
  let r = c.slice(0, Math.max(c.lastIndexOf(" "), 12)).trim().replace(/[,;:\s]+$/, "");
  while (FIM_FRACO.test(r)) r = r.replace(FIM_FRACO, "");
  return r;
}

// ---------------------------------------------------------------- hook (guarda o tipo para análise futura)
function textoHook(t: HookTipo, tema: string, of: ReturnType<typeof escolherOficio>, fato: string | null): string | null {
  switch (t) {
    case "pergunta": return `Qual é a sua maior dúvida sobre ${tema}?`;
    case "contraste": return `${cap(of.antes)} ou ${of.depois}: o que muda no meio?`;
    case "erro_comum": return `O erro mais comum sobre ${tema} e como evitar.`;
    case "promessa": return `Em poucos segundos, você vê ${of.resultado} e entende ${of.decisao}.`;
    case "dado": return fato && /\d/.test(fato) ? `Dado do momento: ${curto(semPonto(fato), 90)}.` : null;
    case "demonstracao": return `Veja ${of.cena}, de perto e sem enrolação.`;
    case "historia": return `Uma situação do meu dia sobre ${tema}.`;
    case "curiosidade": return `Poucos sabem: ${of.invisivel}.`;
    case "provocacao": return `Pare de ignorar ${of.decisao}.`;
  }
}
export function gerarHooks(enfase: EnfaseId, tema: string, of: ReturnType<typeof escolherOficio>, fato: string | null, seed: string, evitar: HookTipo[] = [], n = 3) {
  const ordem = [...HOOK_PREF[enfase], ...TODOS.filter((t) => !HOOK_PREF[enfase].includes(t))];
  const livres = ordem.filter((t) => !evitar.includes(t));
  const base = livres.length >= n ? livres : ordem;
  const ini = hash(seed) % Math.min(4, base.length);
  const out: { tipo: HookTipo; texto: string }[] = [];
  for (let k = 0; k < base.length && out.length < n; k++) {
    const tipo = base[(ini + k) % base.length];
    const texto = textoHook(tipo, tema, of, fato);
    if (texto && !out.some((o) => o.tipo === tipo)) out.push({ tipo, texto });
  }
  // com um dado real da pesquisa, ele sempre aparece entre as opções (e abre a lista quando o objetivo é aproveitar a tendência)
  const dado = !evitar.includes("dado") ? textoHook("dado", tema, of, fato) : null;
  if (dado && !out.some((o) => o.tipo === "dado")) out[out.length - 1] = { tipo: "dado", texto: dado };
  if (dado && enfase === "tendencia") out.sort((x, y) => (y.tipo === "dado" ? 1 : 0) - (x.tipo === "dado" ? 1 : 0));
  return out;
}

// ---------------------------------------------------------------- promessa (depende do objetivo)
function promessaDe(e: EnfaseId, of: ReturnType<typeof escolherOficio>) {
  const m: Record<EnfaseId, string> = {
    seguidores: `conhecer ${of.cena} de perto e ter motivo para acompanhar`,
    alcance: `entender rápido ${of.decisao} e ter algo útil para enviar a alguém`,
    interesse: `pensar e responder com a sua opinião sobre ${of.decisao}`,
    apresentar: `conhecer ${of.resultado} em uso e saber como pedir`,
    vender: `conhecer ${of.resultado} e saber como pedir`,
    tendencia: `perceber como o assunto do momento combina com ${of.cena}`,
    neutro: `entender ${of.decisao} de forma simples`,
  };
  return `Quem ver até o final vai ${m[e]}.`;
}

// ---------------------------------------------------------------- guia de gravação / produção
type Guia = { chave: string; titulo: string; texto: string };
function guiaDe(f: FormatoPlano, ctx: ContextoUsuario, of: ReturnType<typeof escolherOficio>, duracao: string): Guia[] {
  if (VIDEO.has(f)) {
    const g: Guia[] = [{ chave: "orientacao", titulo: "Orientação", texto: "Grave na vertical (9:16), com o celular firme ou apoiado." }];
    if (ctx.aparecer === "nao") {
      g.push({ chave: "camera", titulo: "Enquadramento", texto: `Sem mostrar o rosto: enquadre as mãos e ${of.ferramenta}, com a câmera de frente ou levemente de cima.` });
      g.push({ chave: "pessoa", titulo: "Posição da pessoa", texto: "Fique fora do quadro; só as mãos entram. Mantenha o movimento das mãos lento." });
    } else if (ctx.aparecer === "voz") {
      g.push({ chave: "camera", titulo: "Enquadramento", texto: `Narração em off: enquadre ${of.cena}. A câmera pode ficar parada, com a voz gravada por cima.` });
      g.push({ chave: "pessoa", titulo: "Posição da pessoa", texto: "Você não precisa aparecer. Grave a voz em um lugar silencioso, perto do celular." });
    } else {
      g.push({ chave: "camera", titulo: "Enquadramento", texto: "Deixe a câmera na altura dos olhos, a mais ou menos um braço de distância, e enquadre da cintura para cima." });
      g.push({ chave: "pessoa", titulo: "Posição da pessoa", texto: "Fique de frente para a luz, no centro do quadro, com um pouco de espaço acima da cabeça. Olhe para a lente quando falar e para o objeto quando mostrá-lo." });
    }
    g.push({ chave: "luz", titulo: "Iluminação", texto: "Use luz de janela ou lâmpada de frente para você (ou o objeto). Evite luz forte atrás, que escurece o rosto e o produto." });
    g.push({ chave: "cenario", titulo: "Cenário", texto: `Deixe o fundo organizado e mostre ${of.cena}. Tire do quadro o que não tem a ver com o assunto.` });
    g.push({ chave: "movimento", titulo: "Movimento", texto: "Câmera parada ou movimentos lentos. Troque de ângulo a cada poucos segundos para o vídeo não ficar parado." });
    g.push({ chave: "texto", titulo: "Espaço para texto", texto: "Deixe livre a parte de baixo (cerca de um quinto da altura) e a lateral direita, onde a rede social coloca botões e legenda." });
    g.push({ chave: "duracao", titulo: "Duração", texto: `Aproximadamente ${duracao}. Se passar disso, corte o que não for essencial.` });
    return g;
  }
  if (f === "carrossel") return [
    { chave: "proporcao", titulo: "Proporção", texto: "Use 4:5 (1080 × 1350 px) em todos os slides." },
    { chave: "texto", titulo: "Texto", texto: "Uma ideia por slide, letra grande e curta o bastante para ler no celular em 3 segundos." },
    { chave: "visual", titulo: "Visual", texto: "Mantenha a mesma fonte e as mesmas cores do primeiro ao último slide. Fotos reais do seu trabalho funcionam melhor que imagens genéricas." },
  ];
  if (f === "stories") return [
    { chave: "orientacao", titulo: "Orientação", texto: "Grave na vertical. Cada story fica na tela por poucos segundos, então vá direto ao ponto." },
    { chave: "texto", titulo: "Espaço para texto", texto: "Deixe livre o topo e a base do quadro, onde ficam o perfil e a caixa de resposta." },
    { chave: "luz", titulo: "Iluminação", texto: "Luz natural ou de frente. Evite contraluz." },
  ];
  if (f === "meme") return [
    { chave: "estrutura", titulo: "Estrutura", texto: "Duas partes: a situação que seu público reconhece e a virada. Texto curto, no máximo duas linhas por parte." },
    { chave: "imagem", titulo: "Imagem", texto: "Use fotos ou ilustrações suas ou com direito de uso. Evite imagem de terceiros sem autorização." },
    { chave: "legenda", titulo: "Legenda", texto: "A legenda complementa a piada; não precisa explicá-la." },
  ];
  if (f === "imagem") return [
    { chave: "proporcao", titulo: "Proporção", texto: "Use 4:5 (1080 × 1350 px) para ocupar mais espaço no feed." },
    { chave: "luz", titulo: "Iluminação", texto: "Luz natural, de lado ou de frente. Fundo limpo e um único ponto de atenção." },
    { chave: "texto", titulo: "Texto na arte", texto: "Se houver texto, uma frase curta e legível, longe das bordas." },
  ];
  return [{ chave: "formato", titulo: "Formato", texto: "Escolha o formato em que você consegue produzir hoje, com o que já tem em mãos." }];
}

// ---------------------------------------------------------------- hashtags (ligadas ao contexto; nada genérico)
const PROIBIDAS = new Set(["fyp", "foryou", "foryoupage", "viral", "viralvideo", "explore", "explorepage", "love", "like4like", "likeforlike", "follow4follow", "followforfollow", "instagood", "trending", "trend", "instagram", "reels", "tiktok", "parati", "fy"]);
const tagDe = (s: string) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");
export function gerarHashtags(tema: string, ctx: ContextoUsuario, of: ReturnType<typeof escolherOficio>, f: FormatoPlano, enfase: EnfaseId, max = 6) {
  const cand: { tag: string; motivo: string }[] = [];
  const add = (txt: string, motivo: string) => { const t = tagDe(txt); if (t.length >= 4 && t.length <= 30 && !PROIBIDAS.has(t) && !cand.some((c) => c.tag === t)) cand.push({ tag: t, motivo }); };
  const palavrasTema = tema.split(/\s+/).filter((w) => w && !PROIBIDAS.has(tagDe(w)));
  if (palavrasTema.length >= 1 && palavrasTema.length <= 4) add(palavrasTema.map(tagDe).join(""), "assunto da ideia");
  if (!of.generico) for (const parte of of.rotulo.split(/\s+e\s+/)) add(parte, "seu tipo de trabalho");
  if (ctx.negocio) { const w = ctx.negocio.split(/\s+/).filter((x) => tagDe(x)); if (w.length && w.length <= 4) add(w.join(""), "seu negócio"); }
  if (ctx.ramoRotulo && of.generico) add(ctx.ramoRotulo.split(/\s+e\s+/)[0], "seu ramo");
  if (ctx.cidade && ["vender", "apresentar"].includes(enfase)) add(ctx.cidade, "sua cidade");
  if (f === "carrossel" || f === "imagem") { /* sem hashtag de formato: não agrega relevância */ }
  return { lista: cand.slice(0, max), origem: "perfil+tema", observacao: "Ligadas ao tema, ao seu trabalho e à sua cidade. Ainda sem dados de tendência de hashtags: revise antes de publicar." };
}

// ---------------------------------------------------------------- orquestração
const ZONA: Record<string, string> = { topo: "no terço de cima do quadro", centro: "no centro do quadro", base: "acima da faixa inferior (deixe o último quinto livre)" };

export function planejarConteudo(e: EntradaPlano) {
  const tituloSeguro = limparTitulo(e.ideia.titulo, e.ctx) ?? "o tema da ideia";
  // título em forma de frase pronta (pergunta ou entre aspas) não serve de assunto: nesse caso o assunto é o termo pesquisado
  const termoBase = (e.tema || "").replace(/\s+/g, " ").trim();
  const ehFrase = /[?"“”]/.test(tituloSeguro);
  const ideia: IdeiaEntrada = { ...e.ideia, titulo: ehFrase && termoBase.length >= 3 && termoBase.length <= 50 ? termoBase : tituloSeguro };
  const of = escolherOficio(e.ctx);
  const dosTitulo = (() => { const t = tituloSeguro.includes(":") ? tituloSeguro.split(":").slice(1).join(":").trim() : tituloSeguro; return curto(temaDaIdeia(t) || t, 50); })();
  const termo = (e.tema || "").replace(/\s+/g, " ").trim();
  const tema = termo.length >= 3 && termo.length <= 50 ? termo : dosTitulo;
  const entradaBase = { ideia, ctx: e.ctx, hist: e.hist, seed: e.seed, objetivo: e.objetivo ?? null, intencoes: e.intencoes ?? [] };
  const video = criarModulo({ ...entradaBase, modulo: "video_curto" });
  const enfase = video.objetivo.id as EnfaseId;
  const cenas = ((video.resultado as { cenas: { tempo: string; funcao: string; acao_visual: string; fala: string; texto_na_tela: string }[] }).cenas) || [];
  const duracaoVideo = String((video.resultado as { duracao_aprox?: string }).duracao_aprox || "30 segundos");
  const cta = semPonto(cenas[cenas.length - 1]?.fala || "Salve este conteúdo para usar depois") + ".";

  const fato = e.fato ? semPonto(e.fato).slice(0, 240) : null;
  const hooks = gerarHooks(enfase, tema, of, fato, e.seed, e.evitarHooks || []);
  const hook = hooks[0];

  let roteiro: { etapa: string; tempo?: string; fazer: string; falar?: string; texto?: string }[] = [];
  let textoTela: { momento: string; texto: string; onde: string }[] = [];
  let duracao = duracaoVideo;
  if (VIDEO.has(e.formato)) {
    roteiro = cenas.map((c, i) => ({ etapa: c.funcao, tempo: c.tempo, fazer: c.acao_visual, falar: i === 0 ? hook.texto : c.fala, texto: i === 0 ? cap(curto(semPonto(hook.texto), 48)) : c.texto_na_tela || undefined }));
    textoTela = roteiro.filter((r) => r.texto).map((r, i, a) => ({ momento: r.etapa, texto: r.texto as string, onde: i === 0 ? ZONA.topo : i === a.length - 1 ? ZONA.base : ZONA.centro }));
    textoTela.push({ momento: "CTA final", texto: curto(semPonto(cta), 44), onde: ZONA.base });
  } else if (e.formato === "carrossel") {
    const r = criarModulo({ ...entradaBase, modulo: "carrossel" }).resultado as { slides: { slide: number; papel: string; titulo: string; texto: string; visual: string }[] };
    roteiro = r.slides.map((s, i) => ({ etapa: `Slide ${s.slide} · ${s.papel}`, fazer: s.visual, texto: i === 0 ? hook.texto : `${s.titulo}. ${s.texto}` }));
    duracao = `${r.slides.length} slides`;
  } else if (e.formato === "stories") {
    const r = criarModulo({ ...entradaBase, modulo: "stories" }).resultado as { sequencia: { story: number; funcao: string; conteudo: string; recurso: string | null }[] };
    roteiro = r.sequencia.map((s, i) => ({ etapa: `Story ${s.story} · ${s.funcao}`, fazer: s.conteudo + (s.recurso ? ` (recurso: ${s.recurso})` : ""), falar: i === 0 ? hook.texto : undefined }));
    textoTela = [{ momento: "Story 1", texto: cap(curto(semPonto(hook.texto), 48)), onde: ZONA.centro }, { momento: "Último story", texto: curto(semPonto(cta), 44), onde: ZONA.centro }];
    duracao = `${r.sequencia.length} stories`;
  } else if (e.formato === "meme") {
    roteiro = [
      { etapa: "Situação", fazer: `Mostre em uma frase curta uma situação que ${of.publico} reconhece ligada a ${tema}.`, texto: "[escreva a situação]" },
      { etapa: "Virada", fazer: `Termine com a virada que liga a situação a ${of.decisao}.`, texto: "[escreva a virada]" },
    ];
    duracao = "1 imagem";
  } else if (e.formato === "imagem") {
    roteiro = [{ etapa: "Imagem", fazer: `Mostre ${of.resultado}, de perto, com fundo limpo.` }, { etapa: "Texto da arte", fazer: "Uma frase curta sobre a imagem.", texto: hook.texto }];
    duracao = "1 imagem";
  } else {
    const r = criarModulo({ ...entradaBase, modulo: "guia_texto" }).resultado as { secoes: { secao: string; orientacao: string; exemplo: string }[] };
    roteiro = r.secoes.map((s, i) => ({ etapa: s.secao, fazer: s.orientacao, falar: i === 0 ? hook.texto : undefined }));
    duracao = "texto curto";
  }

  const complemento = "Detalhe que não coube no conteúdo: [escreva um detalhe real do seu trabalho].";
  const abertura = ["vender", "apresentar"].includes(enfase) ? `${cap(of.resultado)}: o que importa é ${of.decisao}.` : `Hoje o assunto é ${tema}: o que importa é ${of.decisao}.`;
  const legenda = `${abertura}\n\n${complemento}\n\n${cta}`;
  const hashtags = gerarHashtags(tema, e.ctx, of, e.formato, enfase);

  const rotuloNegocio = e.ctx.negocio || e.ctx.ramoRotulo;
  const insight = {
    fato: fato ? { texto: fato, tipo: "pesquisa" } : null,
    interpretacao: rotuloNegocio
      ? `Pelo que você informou (${rotuloNegocio.toLowerCase()}), ${fato ? "esse assunto" : "esta ideia"} pode combinar com ${of.cena}.`
      : "Sem o seu ramo informado, a interpretação é geral. Complete o perfil para ficar mais específica.",
    sugestao: `Foco sugerido: ${video.objetivo.foco}.`,
    aviso: fato ? "O fato vem da pesquisa. A interpretação e a sugestão foram criadas pela Evolui a partir do seu perfil." : "Esta ideia foi criada pela Evolui a partir do seu perfil, não de uma fonte externa.",
  };

  return {
    algorithm_version: PLANO_VERSION,
    formato: e.formato, formato_rotulo: FORMATO_ROTULO[e.formato],
    objetivo: video.objetivo,
    insight,
    hook, hooks,
    promessa: promessaDe(enfase, of),
    roteiro, duracao,
    guia_gravacao: guiaDe(e.formato, e.ctx, of, duracao),
    texto_tela: textoTela,
    legenda, hashtags, cta,
    perfil: video.perfil,
    qualidade: { ...video.qualidade },
  };
}
