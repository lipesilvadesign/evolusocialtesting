// Evolui Intelligence Engine (EIE) — configuração central e tipos.
// Regra: NENHUM peso ou limiar fica espalhado pelo código. Tudo está aqui e pode ser sobrescrito pela tabela
// `evolui_eie_config` (linha ativa). Toda recomendação registra a versão do algoritmo e a versão desta configuração.
//
// EvoluiScore mede ADEQUAÇÃO da recomendação ao contexto atual. Não mede chance de viralizar nem prevê resultado.

export const EIE_VERSION = "EIE-v1";

export type Pesos = {
  lexical: number; semantico: number; intencao: number; objetivo: number; segmento: number; rede: number;
  formato: number; contexto_negocio: number; historico: number; novidade: number; qualidade: number; recencia: number;
};
export type Penalidades = { repeticao: number; duplicacao: number; contexto_ausente: number };

export type ConfigEIE = {
  versaoConfig: string;
  /** Pontos de cada sinal (somam a nota). Sinais sem dado são ignorados e os demais são reescalados: faltar contexto não pune. */
  pesos: Pesos;
  /** Pontos descontados (de 0 a 100) quando a penalidade vale 1. */
  penalidades: Penalidades;
  /** Diversidade (MMR): lambda alto = mais relevância; limiar = parecido demais. */
  mmr: { lambda: number; limiarSimilaridade: number };
  novidade: {
    /** Dias para a penalidade de um item já visto cair pela metade. */
    meiaVidaDias: number;
    janelaDias: number;
    /** Quanto cada tipo de contato "gasta" o item (0 a 1). */
    exposicao: { recomendado: number; visto: number; iniciado: number; concluido: number; descartado: number; nao_para_mim: number };
  };
  /** Aprendizado: meia-vida (dias) do peso de um evento e ganho de cada tipo (−1 a 1). */
  aprendizado: { meiaVidaDias: number; ganho: { complete: number; start: number; save: number; copy: number; view: number; discard: number; not_for_me: number } };
  qualidade: { genericidadeMaxima: number };
  /** Texto por IA é OPCIONAL, vem desligado e nunca decide ranking. */
  llm: { ativo: boolean; modelo: string; maxItens: number; timeoutMs: number };
};

export const CONFIG_PADRAO: ConfigEIE = {
  versaoConfig: "cfg-padrao",
  pesos: {
    lexical: 14, semantico: 10, intencao: 12, objetivo: 14, segmento: 10, rede: 3,
    formato: 6, contexto_negocio: 8, historico: 6, novidade: 5, qualidade: 5, recencia: 2,
  },
  penalidades: { repeticao: 18, duplicacao: 15, contexto_ausente: 40 },
  mmr: { lambda: 0.7, limiarSimilaridade: 0.55 },
  novidade: {
    meiaVidaDias: 7, janelaDias: 60,
    exposicao: { recomendado: 0.35, visto: 0.5, iniciado: 0.8, concluido: 0.9, descartado: 1, nao_para_mim: 1 },
  },
  aprendizado: { meiaVidaDias: 30, ganho: { complete: 1, start: 0.4, save: 0.6, copy: 0.4, view: 0, discard: -0.4, not_for_me: -0.8 } },
  qualidade: { genericidadeMaxima: 0.6 },
  llm: { ativo: false, modelo: "gpt-4o-mini", maxItens: 5, timeoutMs: 6000 },
};

const num = (v: unknown, min: number, max: number): number | null => (typeof v === "number" && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : null);

/** Junta a configuração do banco (se houver) por cima da padrão. Valor fora da faixa ou desconhecido é ignorado. */
export function mesclarConfig(base: ConfigEIE, ov: unknown, versao?: string): ConfigEIE {
  const c: ConfigEIE = JSON.parse(JSON.stringify(base));
  if (versao) c.versaoConfig = String(versao).slice(0, 30);
  if (!ov || typeof ov !== "object") return c;
  const o = ov as Record<string, unknown>;
  const pesos = (o.pesos && typeof o.pesos === "object" ? o.pesos : {}) as Record<string, unknown>;
  for (const k of Object.keys(c.pesos) as (keyof Pesos)[]) { const v = num(pesos[k], 0, 50); if (v !== null) c.pesos[k] = v; }
  const pen = (o.penalidades && typeof o.penalidades === "object" ? o.penalidades : {}) as Record<string, unknown>;
  for (const k of Object.keys(c.penalidades) as (keyof Penalidades)[]) { const v = num(pen[k], 0, 100); if (v !== null) c.penalidades[k] = v; }
  const p = (o.params && typeof o.params === "object" ? o.params : {}) as Record<string, Record<string, unknown>>;
  if (p.mmr) { const l = num(p.mmr.lambda, 0, 1), t = num(p.mmr.limiarSimilaridade, 0.1, 1); if (l !== null) c.mmr.lambda = l; if (t !== null) c.mmr.limiarSimilaridade = t; }
  if (p.novidade) { const m = num(p.novidade.meiaVidaDias, 0.5, 90); if (m !== null) c.novidade.meiaVidaDias = m; }
  if (p.llm) {
    if (typeof p.llm.ativo === "boolean") c.llm.ativo = p.llm.ativo;
    if (typeof p.llm.modelo === "string" && /^[\w.\-]{2,40}$/.test(p.llm.modelo)) c.llm.modelo = p.llm.modelo;
    const mi = num(p.llm.maxItens, 1, 8); if (mi !== null) c.llm.maxItens = Math.round(mi);
  }
  return c;
}
