// Ofícios editáveis pelo painel (tabela public.evolui_oficios) + registro de buscas sem ofício (public.evolui_oficio_lacunas).
// O dicionário embutido em formato-dados.ts continua como reserva: se a tabela estiver vazia, indisponível ou com linha inválida,
// nada quebra. Linhas da tabela têm prioridade sobre as embutidas de mesmo id; ativo=false desliga o ofício embutido de mesmo id.
import { OFICIOS, type Oficio } from "./formato-dados.ts";

const EMBUTIDOS: Oficio[] = OFICIOS.slice();
let carregadoEm = 0;
const TTL_MS = 5 * 60 * 1000;

type Linha = Record<string, unknown>;
type Cliente = {
  from: (t: string) => { select: (c: string) => PromiseLike<{ data: unknown; error: unknown }> };
  rpc: (f: string, a: Record<string, unknown>) => PromiseLike<unknown>;
};

const txt = (v: unknown): string | null => (typeof v === "string" && v.trim() ? v.trim() : null);

/** gatilho no mesmo formato do motor: minúsculo, sem acento, só letras/números/espaço (espaço no fim = palavra inteira). Nunca vira regex quebrada. */
export function limpaGatilho(g: unknown): string | null {
  if (typeof g !== "string") return null;
  const s = g.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/^\s+/, "").replace(/\s{2,}/g, " ");
  const fim = /\s$/.test(s);
  const base = s.trim();
  return base.length >= 2 ? (fim ? base + " " : base) : null;
}

/** converte uma linha da tabela em Oficio; devolve null se estiver incompleta (a linha é ignorada, não derruba nada) */
export function linhaParaOficio(l: Linha): Oficio | null {
  const id = txt(l.id), rotulo = txt(l.rotulo);
  if (!id || !rotulo || id === "neutro") return null;
  const gatilhos = Array.isArray(l.gatilhos) ? (l.gatilhos.map(limpaGatilho).filter(Boolean) as string[]) : [];
  if (!gatilhos.length) return null;
  const etapas: [string, string][] = [];
  if (Array.isArray(l.etapas)) for (const e of l.etapas) {
    if (Array.isArray(e) && txt(e[0]) && txt(e[1])) etapas.push([txt(e[0])!, txt(e[1])!]);
  }
  if (etapas.length < 3 || etapas.length > 8) return null;
  const campos = ["cena", "ferramenta", "resultado", "decisao", "invisivel", "antes", "depois", "publico"] as const;
  const v: Record<string, string> = {};
  for (const c of campos) { const t = txt(l[c]); if (!t) return null; v[c] = t; }
  return { id, rotulo, gatilhos, etapas, ...v } as Oficio;
}

/** mescla linhas do banco no dicionário (mutação no lugar: quem importou OFICIOS enxerga a mudança) */
export function aplicarLinhas(linhas: Linha[]): { ativos: number; ignoradas: number } {
  const ids = new Set<string>();
  const ativos: Oficio[] = [];
  let ignoradas = 0;
  for (const l of linhas) {
    const id = txt(l.id);
    if (id) ids.add(id); // inclui os desligados: ativo=false remove o embutido de mesmo id
    if (l.ativo === false) continue;
    const o = linhaParaOficio(l);
    if (o) ativos.push(o); else ignoradas++;
  }
  // linha inválida não deve apagar o embutido de mesmo id
  const validos = new Set(ativos.map((o) => o.id));
  const desligados = new Set([...ids].filter((i) => !validos.has(i) && linhas.some((l) => txt(l.id) === i && l.ativo === false)));
  ativos.sort((a, b) => a.id.localeCompare(b.id));
  OFICIOS.splice(0, OFICIOS.length, ...ativos, ...EMBUTIDOS.filter((o) => !validos.has(o.id) && !desligados.has(o.id)));
  return { ativos: ativos.length, ignoradas };
}

/** recarrega no máximo a cada 5 min por instância; qualquer falha mantém o que já estava valendo */
export async function carregarOficios(cli: Cliente, agora = Date.now()): Promise<void> {
  if (agora - carregadoEm < TTL_MS) return;
  carregadoEm = agora;
  try {
    const { data, error } = await cli.from("evolui_oficios").select("id,rotulo,gatilhos,etapas,cena,ferramenta,resultado,decisao,invisivel,antes,depois,publico,ativo");
    if (error || !Array.isArray(data) || !data.length) return;
    aplicarLinhas(data as Linha[]);
  } catch { /* mantém o dicionário atual */ }
}

const jaRegistrados = new Set<string>();
/** guarda a busca que não casou com nenhum ofício (uma vez por instância, sem esperar resposta) */
export function registrarLacuna(cli: Cliente, termo: string): void {
  const t = (termo || "").trim().toLowerCase().slice(0, 60);
  if (t.length < 3 || jaRegistrados.has(t) || jaRegistrados.size > 500) return;
  jaRegistrados.add(t);
  try { Promise.resolve(cli.rpc("evolui_oficio_lacuna_registrar", { p_termo: t })).then(() => {}, () => {}); } catch { /* ignora */ }
}

/** só para testes */
export function _resetOficiosParaTeste(): void {
  OFICIOS.splice(0, OFICIOS.length, ...EMBUTIDOS); carregadoEm = 0; jaRegistrados.clear();
}
