// EIE — Pesquisa Avançada: dois provedores trabalhando juntos na descoberta web.
// Esta camada continua sendo aditiva: não substitui motor.ts, EIE, Claudia ou Supabase.

import type { Consulta } from "../../consulta.ts";
import { planejarPesquisa } from "./plano.ts";
import { buscarSearXNG } from "./searxng.ts";
import { buscarFirecrawl } from "./firecrawl.ts";
import { fundirResultados } from "./fusao.ts";
import type { PesquisaAvancada, ResultadoPesquisa } from "./tipos.ts";

function limiteQueries(): number {
  const n = Number(Deno.env.get("PESQUISA_AVANCADA_MAX_QUERIES") || 5);
  return Math.max(1, Math.min(8, Number.isFinite(n) ? Math.floor(n) : 6));
}

export async function rodarPesquisaAvancada(args: {
  consulta: Consulta;
  perfil?: { ramo?: string | null; ramo_detalhe?: string | null; cidade?: string | null; objetivo?: string | null };
  taxonomia?: Record<string, unknown> | null;
  limiteQueries?: number;
}): Promise<PesquisaAvancada> {
  const inicio = Date.now();
  const etapas: Record<string, number> = {};
  const modoEnv = (Deno.env.get("PESQUISA_AVANCADA_MODO") || "integrada").toLowerCase();
  const habilitada = modoEnv !== "off";
  if (!habilitada) {
    return { modo: "off", versao: "pesquisa-avancada-v2", consultas: [], resultados: [], evidencias: [], provedores: [], ms: 0, etapas: {}, falhas: [] };
  }

  const tPlano = Date.now();
  const plano = planejarPesquisa(args.consulta, args.perfil, args.taxonomia || null);
  etapas.planejamento = Date.now() - tPlano;
  const consultas = plano.consultas.slice(0, Math.max(1, Math.min(limiteQueries(), args.limiteQueries || limiteQueries())));
  const falhas: string[] = [];
  const todos: ResultadoPesquisa[][] = [];
  const provedores: { nome: string; ativo: boolean; resultados: number; ms: number }[] = [];

  const searx = Boolean(Deno.env.get("SEARXNG_URL"));
  const firecrawl = Boolean(Deno.env.get("FIRECRAWL_API_KEY"));

  // Os dois provedores começam em paralelo. A intenção é ganhar cobertura sem tornar a Evolui
  // dependente da disponibilidade de um único serviço.
  const searxP = (async () => {
    if (!searx) return { nome: "SearXNG", ativo: false, resultados: [] as ResultadoPesquisa[], ms: 0 };
    const t0 = Date.now();
    const listas = await Promise.all(consultas.map(async (q) => {
      try { return await buscarSearXNG(q); }
      catch (e) { falhas.push(`searxng:${q.id}:${e instanceof Error ? e.message.slice(0, 100) : "falha"}`); return []; }
    }));
    return { nome: "SearXNG", ativo: true, resultados: listas.flat(), ms: Date.now() - t0 };
  })();

  const fireP = (async () => {
    if (!firecrawl) return { nome: "Firecrawl", ativo: false, resultados: [] as ResultadoPesquisa[], ms: 0 };
    const t0 = Date.now();
    // Menor fan-out no Firecrawl para preservar latência/custo; ele complementa a metabusca.
    const qs = consultas.slice(0, Math.min(2, consultas.length));
    const listas = await Promise.all(qs.map(async (q) => {
      try { return await buscarFirecrawl(q); }
      catch (e) { falhas.push(`firecrawl:${q.id}:${e instanceof Error ? e.message.slice(0, 100) : "falha"}`); return []; }
    }));
    return { nome: "Firecrawl", ativo: true, resultados: listas.flat(), ms: Date.now() - t0 };
  })();

  const limiteMs = Math.max(2500, Number(Deno.env.get("PESQUISA_AVANCADA_DEADLINE_MS") || 4000));
  const limiteP = new Promise<null>((resolve) => setTimeout(() => resolve(null), limiteMs));
  const resultado = await Promise.race([Promise.all([searxP, fireP]), limiteP]);
  const [sr, fr] = resultado || [
    { nome: "SearXNG", ativo: searx, resultados: [] as ResultadoPesquisa[], ms: Date.now() - inicio },
    { nome: "Firecrawl", ativo: firecrawl, resultados: [] as ResultadoPesquisa[], ms: Date.now() - inicio },
  ];
  etapas.searxng = sr.ms;
  etapas.firecrawl = fr.ms;
  etapas.descoberta = Date.now() - inicio;
  for (const x of [sr, fr]) {
    todos.push(x.resultados);
    provedores.push({ nome: x.nome, ativo: x.ativo, resultados: x.resultados.length, ms: x.ms });
  }

  if (!todos.length || !todos.some((x) => x.length)) {
    return {
      modo: "shadow", versao: "pesquisa-avancada-v2", consultas, resultados: [], evidencias: [], provedores,
      ms: Date.now() - inicio, etapas, falhas: [...new Set(falhas)],
    };
  }

  const f = fundirResultados(todos, consultas.length);
  return {
    modo: modoEnv === "shadow" ? "shadow" : "integrada", versao: "pesquisa-avancada-v2", consultas, resultados: f.resultados, evidencias: f.evidencias, provedores,
    ms: Date.now() - inicio, etapas, falhas: [...new Set(falhas)],
  };
}
