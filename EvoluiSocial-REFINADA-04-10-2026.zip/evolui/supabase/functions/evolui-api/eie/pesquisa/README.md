# Pesquisa Avançada — descoberta web integrada v2

Esta camada é aditiva e trabalha em conjunto com o motor existente da Evolui.

## Ordem de trabalho

1. O interpretador existente (`consulta.ts`) entende a frase.
2. `plano.ts` gera consultas complementares com motivo explícito.
3. **SearXNG** atua como metabusca de descoberta.
4. **Firecrawl** complementa a descoberta e pode trazer conteúdo limpo das páginas.
5. `fusao.ts` remove duplicações e calcula evidência de recuperação.
6. Os títulos encontrados alimentam os `relacionados` do motor existente.
7. O cálculo de tendência continua sendo responsabilidade das fontes já existentes (Wikipédia, GDELT, Google Trends, YouTube).
8. O EIE/Claudia continuam intactos.

## Configuração no Supabase Edge Function `evolui-api`

`PESQUISA_AVANCADA_MODO` agora assume `integrada` por padrão. Se nenhum provedor estiver configurado, a camada retorna vazia e não interfere no motor legado.

```text
PESQUISA_AVANCADA_MODO=integrada
SEARXNG_URL=https://seu-searxng.exemplo
FIRECRAWL_API_KEY=fc-...
FIRECRAWL_BASE_URL=https://api.firecrawl.dev/v2
FIRECRAWL_SCRAPE_PESQUISA=false
FIRECRAWL_LIMIT=5
PESQUISA_AVANCADA_MAX_QUERIES=6
```

SearXNG exige o formato JSON habilitado. Firecrawl pode ser auto-hospedado alterando `FIRECRAWL_BASE_URL`; quando `FIRECRAWL_API_KEY` não existe, ele simplesmente não é chamado.

## Segurança de arquitetura

- Nenhuma chave é enviada ao navegador.
- Nenhuma migração SQL é necessária.
- Nenhuma tabela existente é alterada.
- Nenhum resultado do Firecrawl ou SearXNG é tratado sozinho como prova de tendência.
- SearXNG + Firecrawl são **camada de descoberta**, não duas "fontes independentes" de tendência; a evidência de tendência continua sendo calculada pelas fontes de sinal existentes.


### Performance v1 — 03/10/2026
A busca Firecrawl opera como descoberta por padrão, sem scrape Markdown. O scrape profundo deve ser habilitado explicitamente e o timeout padrão do adaptador é 3500ms.
