// Evolui Social — KeyAPI Social Intelligence Provider
// Camada de aquisição complementar. Não contém inteligência de ranking.
// Secrets nunca são retornados ao frontend e a função não grava tokens.

export type KeyApiPlatform = "tiktok" | "instagram" | "youtube" | "pinterest";

export type KeyApiEndpoint = {
  id: string;
  platform: KeyApiPlatform;
  method: "GET";
  path: string;
  credits: number;
  purpose: string;
  required: string[];
};

export const KEYAPI_BASE_URL = "https://api.keyapi.ai";

// Custos conferidos na documentação pública em 04/10/2026.
// Não incluir endpoints com custo não confirmado no benchmark automático.
export const KEYAPI_ENDPOINTS: Record<string, KeyApiEndpoint> = {
  tiktok_captions: {
    id: "tiktok_captions",
    platform: "tiktok",
    method: "GET",
    path: "/v1/tiktok/video/captions",
    credits: 2,
    purpose: "legendas/subtítulos para EVI",
    required: ["video_id"],
  },
  tiktok_trending_hashtags: {
    id: "tiktok_trending_hashtags",
    platform: "tiktok",
    method: "GET",
    path: "/v1/tiktok/trending/hashtags",
    credits: 2,
    purpose: "sinal de crescimento de hashtags",
    required: [],
  },
  instagram_shortcode: {
    id: "instagram_shortcode",
    platform: "instagram",
    method: "GET",
    path: "/v1/instagram/shortcode_to_media_id",
    credits: 2,
    purpose: "resolver URL curta de post/reel para media_id",
    required: ["shortcode"],
  },
  instagram_reels_search: {
    id: "instagram_reels_search",
    platform: "instagram",
    method: "GET",
    path: "/v1/instagram/search_reels",
    credits: 2,
    purpose: "descoberta de Reels por palavra-chave",
    required: ["keyword"],
  },
  instagram_post_comments: {
    id: "instagram_post_comments",
    platform: "instagram",
    method: "GET",
    path: "/v1/instagram/fetch_post_comments",
    credits: 2,
    purpose: "voz da audiência / dores e objeções",
    required: ["code_or_url"],
  },
  youtube_search: {
    id: "youtube_search",
    platform: "youtube",
    method: "GET",
    path: "/v1/youtube/search_video",
    credits: 3,
    purpose: "demanda + oferta de conteúdo no YouTube",
    required: ["search_query"],
  },
  youtube_video_info: {
    id: "youtube_video_info",
    platform: "youtube",
    method: "GET",
    path: "/v1/youtube/get_video_info",
    credits: 3,
    purpose: "metadados e sinais de um vídeo",
    required: ["video_id"],
  },
  pinterest_search_users: {
    id: "pinterest_search_users",
    platform: "pinterest",
    method: "GET",
    path: "/v1/pinterest/search",
    credits: 2,
    purpose: "descoberta de perfis/contas visuais",
    required: ["username"],
  },
  pinterest_user_info: {
    id: "pinterest_user_info",
    platform: "pinterest",
    method: "GET",
    path: "/v1/pinterest/information",
    credits: 2,
    purpose: "enriquecimento de perfil visual",
    required: ["username"],
  },
};

export type KeyApiCall = {
  endpoint: keyof typeof KEYAPI_ENDPOINTS;
  params: Record<string, string | number | boolean | undefined>;
  /** Contexto da consulta para avaliação interna; nunca enviado ao provedor. */
  contexto?: Record<string, unknown>;
};

export type KeyApiResult = {
  endpoint: string;
  platform: KeyApiPlatform;
  ok: boolean;
  httpStatus: number;
  providerCode?: number;
  message?: string;
  requestId?: string;
  data: unknown;
  credits: number;
  latencyMs: number;
};

function texto(v: unknown, max = 500): string {
  return String(v ?? "").replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, max);
}

export function montarUrl(endpoint: KeyApiEndpoint, params: KeyApiCall["params"]): string {
  const u = new URL(`${KEYAPI_BASE_URL}${endpoint.path}`);
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === "") continue;
    u.searchParams.set(k, String(v));
  }
  return u.toString();
}

export function validarChamadaKeyApi(call: KeyApiCall): { ok: true; endpoint: KeyApiEndpoint } | { ok: false; erro: string } {
  const endpoint = KEYAPI_ENDPOINTS[call.endpoint];
  if (!endpoint) return { ok: false, erro: `Endpoint KeyAPI não registrado: ${String(call.endpoint)}` };
  for (const name of endpoint.required) {
    const value = call.params?.[name];
    if (value === undefined || value === null || String(value).trim() === "") {
      return { ok: false, erro: `Parâmetro obrigatório ausente: ${name}` };
    }
  }
  return { ok: true, endpoint };
}

export async function chamarKeyApi(
  call: KeyApiCall,
  apiKey: string,
  opts: { timeoutMs?: number; fetchImpl?: typeof fetch } = {},
): Promise<KeyApiResult> {
  const valid = validarChamadaKeyApi(call);
  if (!valid.ok) {
    return {
      endpoint: String(call.endpoint), platform: "tiktok", ok: false, httpStatus: 0,
      message: valid.erro, data: null, credits: 0, latencyMs: 0,
    };
  }
  if (!apiKey || apiKey.trim().length < 10) {
    throw new Error("KEYAPI_API_KEY não configurada.");
  }

  const fetchImpl = opts.fetchImpl || fetch;
  const timeoutMs = Math.max(1000, Math.min(20_000, opts.timeoutMs || 8_000));
  const url = montarUrl(valid.endpoint, call.params);
  const t0 = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetchImpl(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: "application/json",
      },
      signal: controller.signal,
    });
    const raw = await response.json().catch(() => ({}));
    const body = raw && typeof raw === "object" ? raw as Record<string, unknown> : {};
    return {
      endpoint: call.endpoint,
      platform: valid.endpoint.platform,
      ok: response.ok && Number(body.code ?? 0) === 0,
      httpStatus: response.status,
      providerCode: typeof body.code === "number" ? body.code : undefined,
      message: texto(body.message, 240) || (response.ok ? "success" : response.statusText),
      requestId: texto(body.requestId, 120) || undefined,
      data: body.data ?? null,
      credits: valid.endpoint.credits,
      latencyMs: Date.now() - t0,
    };
  } catch (e) {
    return {
      endpoint: call.endpoint,
      platform: valid.endpoint.platform,
      ok: false,
      httpStatus: 0,
      message: e instanceof DOMException && e.name === "AbortError" ? "timeout" : texto(e, 240),
      data: null,
      credits: valid.endpoint.credits,
      latencyMs: Date.now() - t0,
    };
  } finally {
    clearTimeout(timer);
  }
}

export function normalizarSinalSocial(resultado: KeyApiResult, contexto: Record<string, unknown> = {}) {
  return {
    fonte: "keyapi",
    plataforma: resultado.platform,
    endpoint: resultado.endpoint,
    confirmado: resultado.ok,
    recencia: 0,
    relevancia_contextual: 0,
    qualidade_dado: resultado.ok ? 0.75 : 0,
    latencia_ms: resultado.latencyMs,
    request_id: resultado.requestId || null,
    contexto: {
      ramo: texto(contexto.ramo, 100) || null,
      objetivo: texto(contexto.objetivo, 100) || null,
      consulta: texto(contexto.consulta, 140) || null,
    },
    origem: "retrieved",
    tipo_sinal: "observado",
    dados: resultado.data,
  };
}
