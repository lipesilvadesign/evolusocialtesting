// EIE — Pesquisa Avançada: fusão, deduplicação e evidência.

import type { EvidenciaPesquisa, ResultadoPesquisa } from "./tipos.ts";

const agora = () => Date.now();

function normalizaUrl(u: string): string {
  try {
    const x = new URL(u);
    x.hash = "";
    x.searchParams.delete("utm_source");
    x.searchParams.delete("utm_medium");
    x.searchParams.delete("utm_campaign");
    x.searchParams.delete("utm_content");
    x.searchParams.delete("utm_term");
    x.hostname = x.hostname.toLowerCase().replace(/^www\./, "");
    return x.toString().replace(/\/$/, "");
  } catch { return u.trim().toLowerCase().replace(/\/$/, ""); }
}

function recencia(data: string | null): number {
  if (!data) return 0.35;
  const ms = new Date(data).getTime();
  if (!Number.isFinite(ms)) return 0.35;
  const dias = Math.max(0, (agora() - ms) / 86_400_000);
  return dias <= 1 ? 1 : dias <= 7 ? 0.85 : dias <= 30 ? 0.65 : dias <= 90 ? 0.4 : 0.2;
}

function fusao(listas: ResultadoPesquisa[][]): ResultadoPesquisa[] {
  const mapa = new Map<string, ResultadoPesquisa>();
  for (const lista of listas) for (const item of lista) {
    const chave = normalizaUrl(item.url);
    if (!chave) continue;
    const atual = mapa.get(chave);
    if (!atual) { mapa.set(chave, { ...item, url: chave }); continue; }
    atual.queryIds = [...new Set([...atual.queryIds, ...item.queryIds])];
    atual.engines = [...new Set([...atual.engines, ...item.engines])];
    atual.engineCount = atual.engines.length || Math.max(atual.engineCount, item.engineCount);
    atual.posicoes = [...atual.posicoes, ...item.posicoes].slice(0, 12);
    if ((!atual.snippet || atual.snippet.length < item.snippet.length) && item.snippet) atual.snippet = item.snippet;
    if (!atual.publicadoEm && item.publicadoEm) atual.publicadoEm = item.publicadoEm;
  }
  return [...mapa.values()];
}

function pontuar(x: ResultadoPesquisa, totalQueries: number): EvidenciaPesquisa {
  const coberturaQueries = Math.min(1, x.queryIds.length / Math.max(1, Math.min(totalQueries, 4)));
  const coberturaEngines = Math.min(1, x.engineCount / 4);
  const rec = recencia(x.publicadoEm);
  const diversidade = Math.min(1, new Set(x.queryIds).size / 4);
  const autoridade = /(^|\.)(gov\.br|edu\.br|org\.br|wikipedia\.org|youtube\.com)$/i.test(x.dominio) ? 1 : 0.5;
  const score = Math.round((0.30 * coberturaQueries + 0.25 * coberturaEngines + 0.20 * rec + 0.15 * autoridade + 0.10 * diversidade) * 100) / 100;
  const motivo: string[] = [];
  if (x.queryIds.length >= 2) motivo.push("reapareceu_em_mais_de_uma_consulta");
  if (x.engineCount >= 2) motivo.push("concordancia_entre_mecanismos");
  if (rec >= 0.85) motivo.push("recente");
  if (autoridade >= 1) motivo.push("dominio_de_alta_confianca");
  return { score, coberturaQueries, coberturaEngines, recencia: rec, autoridade, diversidadeDominios: diversidade, motivo };
}

export function fundirResultados(listas: ResultadoPesquisa[][], totalQueries: number, limite = 40): { resultados: ResultadoPesquisa[]; evidencias: { url: string; evidencia: EvidenciaPesquisa }[] } {
  const resultados = fusao(listas);
  const ranqueados = resultados
    .map((r) => ({ r, e: pontuar(r, totalQueries) }))
    .sort((a, b) => b.e.score - a.e.score || b.e.coberturaEngines - a.e.coberturaEngines || b.e.recencia - a.e.recencia)
    .slice(0, limite);
  return { resultados: ranqueados.map((x) => x.r), evidencias: ranqueados.map((x) => ({ url: x.r.url, evidencia: x.e })) };
}
