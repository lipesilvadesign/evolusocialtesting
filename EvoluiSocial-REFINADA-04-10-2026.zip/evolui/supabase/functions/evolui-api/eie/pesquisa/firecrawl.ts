// EIE — Pesquisa Avançada: adaptador Firecrawl.
// O serviço é opcional: quando FIRECRAWL_API_KEY não existe, nenhum pedido é feito.
// Não usa SDK/dependência externa; funciona por HTTP para manter a Edge Function enxuta.

import type { QueryPesquisa, ResultadoPesquisa } from "./tipos.ts";

const UA = "EvoluiSocial/1.0 (+https://felipebranding.com.br/evoluisocial/; contato@felipebranding.com.br)";

function baseUrl(): string {
  const raw = (Deno.env.get("FIRECRAWL_BASE_URL") || "https://api.firecrawl.dev/v2").trim().replace(/\/+$/, "");
  return /^https?:\/\//i.test(raw) ? raw : "https://api.firecrawl.dev/v2";
}

function texto(v: unknown, max: number): string {
  return typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max) : "";
}

function dominio(url: string): string {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return ""; }
}

function dataValida(s: unknown): string | null {
  if (typeof s !== "string" || !s.trim()) return null;
  const d = new Date(s);
  return Number.isFinite(d.getTime()) ? d.toISOString() : null;
}

/**
 * Pesquisa uma consulta no Firecrawl.
 * A leitura completa da página é habilitada por FIRECRAWL_SCRAPE_PESQUISA=true.
 * Quando habilitada, limitamos a 3 resultados por consulta para controlar latência/custo.
 */
export async function buscarFirecrawl(q: QueryPesquisa, timeoutMs = 2500): Promise<ResultadoPesquisa[]> {
  const key = (Deno.env.get("FIRECRAWL_API_KEY") || "").trim();
  if (!key) return [];

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  const limite = Math.min(6, Math.max(3, Number(Deno.env.get("FIRECRAWL_LIMIT") || 5)));
  // Descoberta deve ser barata. Leitura Markdown profunda fica fora do caminho crítico;
  // só habilite explicitamente quando houver necessidade operacional.
  const scrape = String(Deno.env.get("FIRECRAWL_SCRAPE_PESQUISA") || "false").toLowerCase() === "true";

  try {
    const body: Record<string, unknown> = {
      query: q.texto,
      limit: limite,
      country: "BR",
      tbs: q.categoria === "news" ? "qdr:m" : undefined,
      scrapeOptions: scrape ? { formats: [{ type: "markdown" }] } : undefined,
    };
    Object.keys(body).forEach((k) => body[k] === undefined && delete body[k]);

    const r = await fetch(`${baseUrl()}/search`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": UA,
      },
      body: JSON.stringify(body),
      signal: ctl.signal,
    });
    if (!r.ok) throw new Error(`firecrawl ${r.status}`);
    const j = await r.json();
    const web = Array.isArray(j?.data?.web) ? j.data.web : Array.isArray(j?.web) ? j.web : [];
    const news = Array.isArray(j?.data?.news) ? j.data.news : Array.isArray(j?.news) ? j.news : [];
    const rows = [...web, ...news].slice(0, limite);

    return rows.flatMap((x: Record<string, unknown>, i: number) => {
      const url = texto(x.url, 1400);
      const title = texto(x.title, 260);
      const markdown = texto(x.markdown, 1600);
      const description = texto(x.description ?? x.snippet, 600);
      const snippet = markdown || description;
      if (!/^https?:\/\/[^\s]+$/i.test(url) || !title) return [];
      return [{
        url,
        titulo: title,
        snippet,
        dominio: dominio(url),
        publicadoEm: dataValida(x.publishedDate ?? x.published_date ?? x.date),
        engines: ["firecrawl"],
        engineCount: 1,
        queryIds: [q.id],
        posicoes: [i + 1],
        provedor: "firecrawl",
      }];
    });
  } finally {
    clearTimeout(t);
  }
}
