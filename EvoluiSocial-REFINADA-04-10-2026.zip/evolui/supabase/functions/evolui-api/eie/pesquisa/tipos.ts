// EIE — Pesquisa Avançada: contratos isolados da busca web.
// Esta camada é aditiva e não altera o contrato da API existente.

export type PrioridadeQuery = "direta" | "contextual" | "descoberta" | "validacao";
export type CategoriaQuery = "general" | "news";

export type QueryPesquisa = {
  id: string;
  texto: string;
  prioridade: PrioridadeQuery;
  categoria: CategoriaQuery;
  motivo: string;
};

export type ResultadoPesquisa = {
  url: string;
  titulo: string;
  snippet: string;
  dominio: string;
  publicadoEm: string | null;
  engines: string[];
  engineCount: number;
  queryIds: string[];
  posicoes: number[];
  provedor: "searxng" | "firecrawl";
};

export type PlanoPesquisa = {
  consultas: QueryPesquisa[];
  termosExpandidos: string[];
  versao: string;
};

export type EvidenciaPesquisa = {
  score: number;
  coberturaQueries: number;
  coberturaEngines: number;
  recencia: number;
  autoridade: number;
  diversidadeDominios: number;
  motivo: string[];
};

export type PesquisaAvancada = {
  modo: "off" | "shadow" | "integrada";
  versao: string;
  consultas: QueryPesquisa[];
  resultados: ResultadoPesquisa[];
  evidencias: { url: string; evidencia: EvidenciaPesquisa }[];
  provedores: { nome: string; ativo: boolean; resultados: number; ms: number }[];
  ms: number;
  etapas?: Record<string, number>;
  falhas: string[];
};
