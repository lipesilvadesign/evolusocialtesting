// EIE — Pesquisa Avançada: adaptador nativo SearXNG.
// Não usa SDK/dependência externa. SearXNG é opcional e só é consultado quando SEARXNG_URL existe.

import type { QueryPesquisa, ResultadoPesquisa } from "./tipos.ts";

const UA = "EvoluiSocial/1.0 (+https://felipebranding.com.br/evoluisocial/; contato@felipebranding.com.br)";

function baseUrl(): string | null {
  const raw = Deno.env.get("SEARXNG_URL") || "";
  const v = raw.trim().replace(/\/+$/, "");
  return /^https?:\/\//i.test(v) ? v : null;
}

function dominio(url: string): string {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return ""; }
}

function dataValida(s: unknown): string | null {
  if (typeof s !== "string" || !s.trim()) return null;
  const d = new Date(s);
  return Number.isFinite(d.getTime()) ? d.toISOString() : null;
}

function texto(v: unknown, max: number): string {
  return typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max) : "";
}

function enginesDe(v: Record<string, unknown>): string[] {
  const e = Array.isArray(v.engines) ? v.engines : v.engine ? [v.engine] : [];
  return [...new Set(e.filter((x): x is string => typeof x === "string" && x.trim()).map((x) => x.trim().slice(0, 50)))].slice(0, 12);
}

export async function buscarSearXNG(q: QueryPesquisa, timeoutMs = 3500): Promise<ResultadoPesquisa[]> {
  const base = baseUrl();
  if (!base) return [];
  const u = new URL(base + "/search");
  u.searchParams.set("q", q.texto);
  u.searchParams.set("format", "json");
  u.searchParams.set("language", "pt-BR");
  u.searchParams.set("safesearch", "1");
  u.searchParams.set("categories", q.categoria === "news" ? "news" : "general");

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const r = await fetch(u.toString(), { headers: { "User-Agent": UA, "Accept": "application/json" }, signal: ctl.signal });
    if (!r.ok) throw new Error(`searxng ${r.status}`);
    const j = await r.json();
    const rows = Array.isArray(j?.results) ? j.results : [];
    return rows.slice(0, 20).flatMap((x: Record<string, unknown>, i: number) => {
      const url = texto(x.url, 1200), title = texto(x.title, 220), snippet = texto(x.content ?? x.snippet, 600);
      if (!/^https?:\/\/[^\s]+$/i.test(url) || !title) return [];
      const engines = enginesDe(x);
      return [{
        url, titulo: title, snippet, dominio: dominio(url), publicadoEm: dataValida(x.publishedDate ?? x.published_date),
        engines, engineCount: engines.length || (typeof x.engine === "string" ? 1 : 0), queryIds: [q.id], posicoes: [i + 1], provedor: "searxng",
      }];
    });
  } finally { clearTimeout(t); }
}
