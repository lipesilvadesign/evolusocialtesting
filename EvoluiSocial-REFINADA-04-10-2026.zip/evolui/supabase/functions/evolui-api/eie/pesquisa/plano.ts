// EIE — Pesquisa Avançada: geração determinística de consultas.
// Regra: cada query precisa ter uma razão explícita. Nada de fan-out cego.

import { normaliza, type Consulta } from "../../consulta.ts";
import type { PlanoPesquisa, QueryPesquisa, CategoriaQuery } from "./tipos.ts";

type Taxonomia = {
  entidades?: unknown;
  cadeia?: unknown;
  [k: string]: unknown;
};

type PerfilPesquisa = {
  ramo?: string | null;
  ramo_detalhe?: string | null;
  cidade?: string | null;
  objetivo?: string | null;
};

const LIMITE_QUERIES = 10;
const STOP_QUERY = new Set(["de", "da", "do", "das", "dos", "em", "na", "no", "para", "por", "e", "ou"]);

function limpa(s: string): string {
  return String(s || "").replace(/\s+/g, " ").trim();
}

function semAspas(s: string): string {
  return limpa(s).replace(/^['\"]|['\"]$/g, "");
}

function adicionar(out: QueryPesquisa[], vistos: Set<string>, q: QueryPesquisa) {
  const texto = limpa(q.texto);
  const chave = normaliza(texto);
  if (!chave || chave.length < 3 || vistos.has(chave)) return;
  vistos.add(chave);
  out.push({ ...q, texto });
}

function cadeiaTermos(taxonomia: Taxonomia | null | undefined): string[] {
  const c = taxonomia?.cadeia;
  if (!c || typeof c !== "object") return [];
  const out: string[] = [];
  for (const k of ["area", "subramo", "tema"]) {
    const x = (c as Record<string, unknown>)[k];
    if (!x || typeof x !== "object") continue;
    const rot = (x as Record<string, unknown>).rotulo;
    const cha = (x as Record<string, unknown>).chave;
    if (typeof rot === "string" && rot.trim()) out.push(rot.trim());
    else if (typeof cha === "string" && cha.trim()) out.push(cha.replaceAll("_", " ").trim());
  }
  return [...new Set(out)].slice(0, 4);
}

function entidadesTermos(taxonomia: Taxonomia | null | undefined): string[] {
  const e = taxonomia?.entidades;
  if (!Array.isArray(e)) return [];
  const out: string[] = [];
  for (const item of e) {
    if (typeof item === "string" && item.trim()) out.push(item.trim());
    else if (item && typeof item === "object") {
      const r = item as Record<string, unknown>;
      for (const k of ["rotulo", "nome", "termo", "chave"]) {
        if (typeof r[k] === "string" && String(r[k]).trim()) { out.push(String(r[k]).trim()); break; }
      }
    }
  }
  return [...new Set(out)].slice(0, 6);
}

function assuntoBase(c: Consulta): string {
  return semAspas(c.assunto || c.original || "");
}

function termosAssunto(c: Consulta): string[] {
  // Para descoberta, use apenas os tokens do ASSUNTO.
  // `termosBusca` também contém expansões de intenção (ex.: "ideia", "tendencia"),
  // que gerariam queries circulares e de baixo valor como "barbearia ideia".
  const base = (c.assuntoTokens || []).map(normaliza).flatMap((x) => x.split(" "))
    .filter((x) => x.length >= 3 && !STOP_QUERY.has(x));
  return [...new Set(base)].slice(0, 8);
}

function tokens(s: string): Set<string> {
  return new Set(normaliza(s).split(" ").filter((x) => x.length >= 3 && !STOP_QUERY.has(x)));
}

function demasiadoParecida(a: string, b: string): boolean {
  const A = tokens(a), B = tokens(b);
  if (!A.size || !B.size) return true;
  let comuns = 0;
  for (const x of A) if (B.has(x)) comuns++;
  return comuns / Math.min(A.size, B.size) >= 0.8;
}

function termoAdjacenteValido(assunto: string, t: string): boolean {
  return !!t && !demasiadoParecida(assunto, t);
}

function categoriaPor(c: Consulta, texto: string): CategoriaQuery {
  const ids = new Set(c.intencoes.map((i) => i.id));
  if (ids.has("noticia")) return "news";
  if (/(not[ií]cia|atual|agora|hoje|mercado|tend[eê]ncia|crescendo|em alta)/i.test(texto)) return "news";
  return "general";
}

/**
 * Planeja um conjunto pequeno de buscas complementares.
 * O objetivo é transformar a interpretação existente em cobertura adicional,
 * sem substituir a busca atual.
 */
export function planejarPesquisa(c: Consulta, perfil: PerfilPesquisa = {}, taxonomia: Taxonomia | null = null): PlanoPesquisa {
  const out: QueryPesquisa[] = [];
  const vistos = new Set<string>();
  const assunto = assuntoBase(c);
  const ramo = limpa(perfil.ramo_detalhe || perfil.ramo || "");
  const cidade = limpa(c.localizacao || perfil.cidade || "");
  const ids = new Set(c.intencoes.map((i) => i.id));
  const categoria = (q: string) => categoriaPor(c, q);
  const ano = c.ano || "";
  const plataforma = c.plataforma || "";

  if (assunto) adicionar(out, vistos, {
    id: "direta",
    texto: assunto,
    prioridade: "direta",
    categoria: categoria(assunto),
    motivo: "assunto_exato",
  });

  if (assunto && ramo && termoAdjacenteValido(assunto, ramo)) adicionar(out, vistos, {
    id: "ramo",
    texto: `${assunto} ${ramo}${ano ? ` ${ano}` : ""}`,
    prioridade: "contextual",
    categoria: "general",
    motivo: "assunto_x_ramo",
  });

  if (assunto && cidade && (ids.has("local") || ids.has("mercado") || /lojas?|empresas?|cl[ií]nicas?|restaurantes?|barbearias?|sal[oõ]es?/i.test(assunto + " " + c.original))) {
    adicionar(out, vistos, {
      id: "local",
      texto: `${assunto} ${cidade}${ano ? ` ${ano}` : ""}`,
      prioridade: "contextual",
      categoria: "general",
      motivo: "assunto_x_local",
    });
  }

  if (assunto && (ids.has("tendencias") || ids.has("oportunidade") || ids.has("mercado") || ids.has("noticia"))) {
    adicionar(out, vistos, {
      id: "momento",
      texto: `${assunto} tendências Brasil${ano ? ` ${ano}` : ""}${plataforma ? ` ${plataforma}` : ""}` ,
      prioridade: "descoberta",
      categoria: "news",
      motivo: "sinais_de_momento",
    });
    adicionar(out, vistos, {
      id: "demanda",
      texto: `${assunto} demanda comportamento consumidor${ano ? ` ${ano}` : ""}`,
      prioridade: "descoberta",
      categoria: "general",
      motivo: "demanda_e_comportamento",
    });
  }

  if (assunto && (ids.has("oportunidade") || ids.has("mercado"))) {
    adicionar(out, vistos, {
      id: "lacunas",
      texto: `${assunto} problemas dúvidas necessidades${ano ? ` ${ano}` : ""}`,
      prioridade: "descoberta",
      categoria: "general",
      motivo: "dores_e_lacunas",
    });
  }

  if (assunto && (ids.has("concorrencia") || ids.has("referencia"))) {
    adicionar(out, vistos, {
      id: "concorrencia",
      texto: `${assunto} concorrentes referências${ano ? ` ${ano}` : ""}`,
      prioridade: "descoberta",
      categoria: "general",
      motivo: "concorrencia_e_benchmark",
    });
  }

  if (assunto && (ids.has("ideias") || ids.has("estrategia") || ids.has("alcance"))) {
    adicionar(out, vistos, {
      id: "conteudo",
      texto: `${assunto} conteúdo ${plataforma || "Instagram"} ideias${ano ? ` ${ano}` : ""}`,
      prioridade: "contextual",
      categoria: "general",
      motivo: "aplicabilidade_em_conteudo",
    });
  }

  if (assunto && ids.has("ideias")) adicionar(out, vistos, {
    id: "formatos",
    texto: `${assunto} reels formatos ganchos${ano ? ` ${ano}` : ""}`,
    prioridade: "descoberta",
    categoria: "general",
    motivo: "descoberta_de_formatos_e_ganchos",
  });

  if (assunto && ids.has("tendencias")) adicionar(out, vistos, {
    id: "sinais",
    texto: `${assunto} sinais de crescimento buscas interesse${ano ? ` ${ano}` : ""}`,
    prioridade: "descoberta",
    categoria: "news",
    motivo: "medicao_de_sinais_de_crescimento",
  });

  for (const t of [...cadeiaTermos(taxonomia), ...entidadesTermos(taxonomia), ...termosAssunto(c).slice(0, 3)]) {
    if (!assunto || !termoAdjacenteValido(assunto, t)) continue;
    adicionar(out, vistos, {
      id: `adj-${normaliza(t).replace(/[^a-z0-9]+/g, "-").slice(0, 24)}`,
      texto: `${assunto} ${t}`,
      prioridade: "descoberta",
      categoria: "general",
      motivo: "expansao_taxonomica",
    });
    if (out.length >= LIMITE_QUERIES) break;
  }

  if (out.length < LIMITE_QUERIES && assunto && categoria(assunto) === "news") {
    adicionar(out, vistos, {
      id: "noticias",
      texto: `"${assunto}" notícias Brasil`,
      prioridade: "validacao",
      categoria: "news",
      motivo: "validacao_editorial",
    });
  }

  return {
    consultas: out.slice(0, LIMITE_QUERIES),
    termosExpandidos: [...new Set([...cadeiaTermos(taxonomia), ...entidadesTermos(taxonomia), ...termosAssunto(c)])]
      .filter((t) => termoAdjacenteValido(assunto, t))
      .slice(0, 16),
    versao: "pesquisa-plano-v1",
  };
}
