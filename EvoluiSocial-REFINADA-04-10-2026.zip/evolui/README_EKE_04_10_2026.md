# Evolui Knowledge Engine (EKE) — v1

## Objetivo

Adicionar ao EIE uma camada de aquisição de conhecimento que pesquisa termos, entidades e contextos quando a interpretação da consulta estiver fraca, ambígua ou insuficiente.

A regra é:

> falta de conhecimento dispara investigação; não encerra a pesquisa.

## Fluxo

```text
consulta do usuário
  ↓
consulta.ts
  ↓
confiança semântica
  ↓
Knowledge Gap?
  ├─ não → fluxo EIE existente
  └─ sim
      ↓
   pesquisa web avançada
      ↓
   estruturação + proveniência
      ↓
   memória evolui_conhecimento
      ↓
   contexto devolvido ao EIE
      ↓
   recomendações
```

## O que o EKE faz

- detecta necessidade de aquisição sem substituir o interpretador atual;
- gera perguntas de pesquisa complementares;
- reutiliza SearXNG/Firecrawl por meio do `rodarPesquisaAvancada` existente;
- extrai significados e termos relacionados de títulos/snippets recuperados;
- atribui confiança;
- marca termos ambíguos para desambiguação;
- registra fontes e proveniência;
- guarda conhecimento estruturado no Supabase;
- permite que a resposta siga mesmo quando não existe sinal forte de tendência;
- não expõe ao usuário a limitação técnica como estado terminal quando existe conhecimento adquirido.

## O que NÃO faz

- não altera código automaticamente;
- não instala código encontrado na internet;
- não trata uma fonte isolada como verdade absoluta;
- não substitui o EvoluiScore;
- não substitui Claudia;
- não treina um modelo por conta própria.

## Banco

Aplicar `SQL_EKE_CONHECIMENTO_04_10_2026.sql` no Supabase. A migração é aditiva e usa uma tabela isolada: `public.evolui_conhecimento`.

## UX

Quando o termo é desconhecido/ambíguo, a tela não precisa mostrar “baixo”, “sem dados” ou “algoritmo não encontrou”. O usuário vê que a Evolui entendeu e pesquisou o contexto. A evidência de tendência continua separada do conhecimento semântico: conhecer o termo não significa afirmar que ele está em alta.

## Segurança

A pesquisa ocorre no servidor. Nenhuma chave de SearXNG, Firecrawl ou Pinterest é enviada ao navegador. O conhecimento persistido mantém fontes e confiança.
