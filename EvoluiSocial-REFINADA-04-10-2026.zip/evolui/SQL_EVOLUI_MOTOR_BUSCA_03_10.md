# Motor de busca — alterações aplicadas no Supabase (03/10/2026)
Todas aditivas. A fonte da verdade é o banco (aligftypgtzlymmditeo).
- evolui_biblioteca: coluna tax_chaves text[] (+ índice GIN), preenchida por retroalimentação (area/subramo/tema/serviço); 9 itens novos de beleza (skincare, cabelo, barbearia).
- evolui_tax_termos: sinônimos acrescentados em cabelo_barbearia (hair stylist, barber...) e cuidados_pele (skin, pele, rosto...).
- evolui_expandir_consulta(p_texto) -> {termos, chaves}: sinônimos e chaves da taxonomia para a frase.
- evolui_biblioteca_buscar_v2(..., p_expandidos, p_tax): busca com termos expandidos e adequação à taxonomia (+0,9 por chave, até 2).
- evolui_biblioteca_buscar (7 args, a que a evolui-api v15 chama): agora expande a frase sozinha e delega à v2. Se a expansão falhar, busca como antes.
Reversão: recriar evolui_biblioteca_buscar com o corpo anterior (guardado no backup da auditoria) — nada foi apagado.
