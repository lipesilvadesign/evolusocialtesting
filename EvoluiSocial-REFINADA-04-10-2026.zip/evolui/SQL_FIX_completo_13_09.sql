-- ============================================================
-- FIX COMPLETO — 13/09 (v2, tudo junto) — SEM PING PONG
-- ============================================================
-- ESTE É O ÚNICO ARQUIVO QUE VOCÊ PRECISA RODAR. Ele junta tudo que
-- ainda estava pendente — inclusive o que já tinha sido mandado em
-- arquivos separados antes — pra não precisar colar mais de um SQL:
--   1) "SQL 504" nas notificações do Início        → admin_notificacoes
--   2) "erro 400"/"não foi possível carregar metas"  → admin_metas_prospeccao
--   3) "Falha ao consultar envios (404)" (relatado de novo pela Bianca,
--      no filtro "últimos 7 dias")                  → admin_prospeccao_buscas
--      e admin_prospeccao_envios (antes em SQL_FIX_admin_prospeccao_envios.sql,
--      agora incorporado aqui)
--   4) Perfil do funcionário: foto, tempo de experiência, funções e
--      gênero (pra escolher a ilustração padrão quando não tem foto) — só
--      administrador edita; o próprio funcionário só visualiza.
--   5) Renomeia a conta marketing@felipebranding.com.br de "Marketing" para
--      "Felipe Souto - Dono".
--   6) Mural/comunicação da equipe (novo pedido, 13/09) → admin_equipe_mensagens.
--   7) "Falha ao consultar atividades (400)" no card de Metas do Início
--      (reportado de novo, 13/09, DEPOIS de rodar a v1 deste arquivo) →
--      admin_prospeccao_atividades estava sem as colunas status_anterior/
--      status_novo/objecao e sem os valores novos nas constraints de status/
--      tipo — três migrações pequenas e separadas (SQL_PENDENTE_estados_
--      rapidos.sql, SQL_PENDENTE_inteligencia.sql, parte de SQL_PENDENTE_
--      clientes.sql) que nunca tinham sido incorporadas aqui. Ver seção 3d.
--
-- Causa raiz de tudo isso (1, 2 e 3): são migrações que EU já tinha
-- preparado, mas que precisam ser coladas e rodadas no SQL Editor do
-- Supabase — eu não tenho acesso direto ao banco de produção da Felipe
-- Branding pra rodar isso por você. Depois desta vez, é só isto aqui, uma
-- vez, que resolve os três de uma vez.
--
-- 100% aditivo e idempotente — pode rodar quantas vezes quiser, em qualquer
-- ordem em relação aos outros SQL_PENDENTE_*/SQL_FIX_*, sem apagar nada.
-- ============================================================

-- ------------------------------------------------------------
-- 0) Pré-requisito: admin_eh_admin() precisa existir (várias policies
-- abaixo dependem dela). Recriada aqui do mesmo jeito que em
-- SQL_FIX_acesso_admin_funcionarios.sql — se já existir idêntica, isto é
-- um no-op seguro.
-- ------------------------------------------------------------
create or replace function admin_eh_admin()
returns boolean
language sql security definer stable
as $$
  select exists (
    select 1 from admin_funcionarios
    where id = auth.uid() and role = 'admin' and ativo = true
  );
$$;

-- ------------------------------------------------------------
-- 1) admin_notificacoes — cria do zero SE NÃO EXISTIR (idempotente via
-- "if not exists"; se já existir, nada aqui altera a tabela). Cobre tanto o
-- caso "tabela nunca existiu" (explica o 504/erro ao consultar) quanto
-- reforça as policies se a tabela já existe mas a RLS ficou incompleta.
-- ------------------------------------------------------------
create table if not exists admin_notificacoes (
  id uuid primary key default gen_random_uuid(),
  tipo text not null check (tipo in ('anomalia','erro','oportunidade','sistema')),
  titulo text not null,
  mensagem text not null,
  severidade text not null default 'baixa' check (severidade in ('baixa','media','alta')),
  metadata jsonb not null default '{}'::jsonb,
  lida boolean not null default false,
  created_at timestamptz not null default now()
);
alter table admin_notificacoes enable row level security;

create index if not exists admin_notificacoes_created_idx on admin_notificacoes (created_at desc);
create index if not exists admin_notificacoes_lida_idx on admin_notificacoes (lida) where lida = false;

-- Authenticated-geral de propósito (mesma decisão já documentada em
-- SQL_PENDENTE_equipe_permissoes.sql item 13): notificação de sistema hoje
-- não tem dono individual. Qualquer funcionário autenticado e ativo lê/marca
-- como lida; só a Function/o job por trás disso cria linha nova.
drop policy if exists "select_notificacoes_autenticado" on admin_notificacoes;
drop policy if exists "update_notificacoes_autenticado" on admin_notificacoes;
drop policy if exists "insert_notificacoes_autenticado" on admin_notificacoes;

create policy "select_notificacoes_autenticado" on admin_notificacoes for select
  using (exists (select 1 from admin_funcionarios where id = auth.uid() and ativo = true));
create policy "update_notificacoes_autenticado" on admin_notificacoes for update
  using (exists (select 1 from admin_funcionarios where id = auth.uid() and ativo = true));
create policy "insert_notificacoes_autenticado" on admin_notificacoes for insert
  with check (exists (select 1 from admin_funcionarios where id = auth.uid() and ativo = true));

comment on table admin_notificacoes is 'Notificações do sistema (Início) — sem dono individual hoje; qualquer funcionário ativo autenticado vê/marca como lida.';

-- ------------------------------------------------------------
-- 2) Ponto (dias/horas trabalhados) — mesma definição de
-- SQL_PENDENTE_ponto_metas.sql, repetida aqui de forma idempotente pra
-- garantir que existe mesmo que aquele arquivo nunca tenha sido rodado.
-- ------------------------------------------------------------
create table if not exists admin_ponto_registros (
  id uuid primary key default gen_random_uuid(),
  funcionario_id uuid not null references admin_funcionarios(id) on delete cascade,
  tipo text not null check (tipo in ('entrada','saida')),
  registrado_em timestamptz not null default now(),
  created_at timestamptz not null default now()
);
alter table admin_ponto_registros enable row level security;
create index if not exists admin_ponto_registros_funcionario_idx
  on admin_ponto_registros (funcionario_id, registrado_em desc);

drop policy if exists "select_ponto_propria_ou_admin" on admin_ponto_registros;
drop policy if exists "insert_ponto_propria_linha" on admin_ponto_registros;
create policy "select_ponto_propria_ou_admin" on admin_ponto_registros for select
  using (admin_eh_admin() or funcionario_id = auth.uid());
create policy "insert_ponto_propria_linha" on admin_ponto_registros for insert
  with check (funcionario_id = auth.uid());

-- ------------------------------------------------------------
-- 3) Metas de prospecção — mesma definição de SQL_PENDENTE_ponto_metas.sql.
-- Esta é a causa raiz mais provável do "erro 400": a tabela/constraint
-- unique usada no upsert (on_conflict=funcionario_id,periodo,referencia)
-- não existia ainda em produção.
-- ------------------------------------------------------------
create table if not exists admin_metas_prospeccao (
  id uuid primary key default gen_random_uuid(),
  funcionario_id uuid not null references admin_funcionarios(id) on delete cascade,
  periodo text not null check (periodo in ('semanal','mensal')),
  referencia date not null,
  meta int not null check (meta > 0),
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz,
  unique (funcionario_id, periodo, referencia)
);
alter table admin_metas_prospeccao enable row level security;

drop policy if exists "select_metas_propria_ou_admin" on admin_metas_prospeccao;
drop policy if exists "somente_admin_insert_metas" on admin_metas_prospeccao;
drop policy if exists "somente_admin_update_metas" on admin_metas_prospeccao;
drop policy if exists "somente_admin_delete_metas" on admin_metas_prospeccao;
create policy "select_metas_propria_ou_admin" on admin_metas_prospeccao for select
  using (admin_eh_admin() or funcionario_id = auth.uid());
create policy "somente_admin_insert_metas" on admin_metas_prospeccao for insert
  with check (admin_eh_admin());
create policy "somente_admin_update_metas" on admin_metas_prospeccao for update
  using (admin_eh_admin());
create policy "somente_admin_delete_metas" on admin_metas_prospeccao for delete
  using (admin_eh_admin());

-- ------------------------------------------------------------
-- 3b) admin_prospeccao_buscas / admin_prospeccao_envios — mesma causa raiz
-- dos itens acima: fazem parte de SQL_PENDENTE_prospeccao.sql, que rodou só
-- parcialmente (essas duas tabelas ficam mais pra baixo no arquivo). Sem
-- elas, o filtro "últimos 7 dias" no Início dá "Falha ao consultar envios
-- (404)". Antes era um arquivo separado (SQL_FIX_admin_prospeccao_envios.sql)
-- — incorporado aqui pra você só precisar rodar este.
-- ------------------------------------------------------------
create table if not exists admin_prospeccao_buscas (
  id uuid primary key,
  cidades text[] not null,
  ramo text not null,
  status text not null default 'em_andamento' check (status in ('em_andamento','concluido','erro')),
  progresso jsonb not null default '[]'::jsonb,
  total_encontrado int,
  mensagem_erro text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_prospeccao_buscas enable row level security;
drop policy if exists "authenticated_select_prospeccao_buscas" on admin_prospeccao_buscas;
drop policy if exists "authenticated_insert_prospeccao_buscas" on admin_prospeccao_buscas;
drop policy if exists "authenticated_update_prospeccao_buscas" on admin_prospeccao_buscas;
create policy "authenticated_select_prospeccao_buscas" on admin_prospeccao_buscas
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_buscas" on admin_prospeccao_buscas
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_prospeccao_buscas" on admin_prospeccao_buscas
  for update using (auth.role() = 'authenticated');

create table if not exists admin_prospeccao_envios (
  id uuid primary key,
  total_selecionado int not null default 0,
  status text not null default 'em_andamento' check (status in ('em_andamento','concluido','erro')),
  progresso jsonb not null default '[]'::jsonb,
  resumo jsonb,
  mensagem_erro text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_prospeccao_envios enable row level security;
drop policy if exists "authenticated_select_prospeccao_envios" on admin_prospeccao_envios;
drop policy if exists "authenticated_insert_prospeccao_envios" on admin_prospeccao_envios;
drop policy if exists "authenticated_update_prospeccao_envios" on admin_prospeccao_envios;
create policy "authenticated_select_prospeccao_envios" on admin_prospeccao_envios
  for select using (auth.role() = 'authenticated');
create policy "authenticated_insert_prospeccao_envios" on admin_prospeccao_envios
  for insert with check (auth.role() = 'authenticated');
create policy "authenticated_update_prospeccao_envios" on admin_prospeccao_envios
  for update using (auth.role() = 'authenticated');

-- ------------------------------------------------------------
-- 4) Perfil do funcionário — foto (já estava em ponto_metas), tempo de
-- experiência, funções (pedido 13/09) e gênero (pedido 13/09, tarde —
-- escolhe qual ilustração padrão aparece quando não tem foto cadastrada).
-- Colunas nullable, texto livre. ATUALIZAÇÃO (13/09, 2ª rodada): o Felipe
-- pediu uma página "Meu Perfil" onde o PRÓPRIO funcionário edita isso —
-- ver seção 4c logo abaixo, que muda quem pode escrever aqui.
-- ------------------------------------------------------------
alter table admin_funcionarios add column if not exists foto_url text;
alter table admin_funcionarios add column if not exists tempo_experiencia text;
alter table admin_funcionarios add column if not exists funcoes text;
alter table admin_funcionarios add column if not exists genero text check (genero in ('masculino', 'feminino'));

comment on column admin_funcionarios.tempo_experiencia is 'Texto livre (ex.: "5 anos") — o próprio funcionário edita na página "Meu Perfil" (ou o admin, por Equipe). Ver trigger admin_funcionarios_protege_colunas_sensiveis: role/ativo/email continuam só-admin mesmo com a policy de update aberta pro dono da linha.';
comment on column admin_funcionarios.funcoes is 'Funções/responsabilidades do funcionário, texto livre — mesmo esquema de tempo_experiencia (dono da linha ou admin editam).';
comment on column admin_funcionarios.genero is 'Opcional — só decide qual ilustração padrão aparece no card de boas-vindas quando a pessoa não tem foto_url. Nulo = usa as iniciais do nome, como já era antes.';

-- ------------------------------------------------------------
-- 4c) ACHADO/PEDIDO NOVO (13/09, 2ª rodada) — página "Meu Perfil": o próprio
-- funcionário passa a poder editar nome/biografia/tempo_experiencia/
-- funcoes/foto_url/genero da PRÓPRIA linha (antes, a policy de update de
-- admin_funcionarios era admin_eh_admin() sozinho — ninguém editava nem a
-- própria linha, nem o admin tinha exceção pra isso; só LEITURA da própria
-- linha já era permitida).
--
-- Abrir a policy de UPDATE pra "dono da linha OU admin" não é suficiente
-- sozinho: um funcionário comum poderia então também tentar mudar seu
-- PRÓPRIO role pra 'admin', ou reativar a própria conta desativada, num
-- único PATCH. Por isso, além da policy, um TRIGGER (não uma policy —
-- RLS não distingue coluna por coluna dentro da mesma linha) trava de
-- volta role/ativo/email/criado_por pro valor antigo sempre que quem está
-- editando não é admin — mesmo que o funcionário mande esses campos no
-- corpo da requisição, eles são ignorados silenciosamente pro não-admin.
-- ------------------------------------------------------------
alter table admin_funcionarios add column if not exists biografia text;
comment on column admin_funcionarios.biografia is 'Texto livre e curto, o próprio funcionário escreve sobre si na página "Meu Perfil". Opcional.';

create or replace function admin_funcionarios_protege_colunas_sensiveis()
returns trigger
language plpgsql
as $$
begin
  if not admin_eh_admin() then
    new.role := old.role;
    new.ativo := old.ativo;
    new.email := old.email;
    new.criado_por := old.criado_por;
  end if;
  return new;
end;
$$;

drop trigger if exists protege_colunas_sensiveis on admin_funcionarios;
create trigger protege_colunas_sensiveis
  before update on admin_funcionarios
  for each row execute function admin_funcionarios_protege_colunas_sensiveis();

drop policy if exists "somente_admin_update_funcionarios" on admin_funcionarios;
drop policy if exists "select_propria_linha_ou_admin_update" on admin_funcionarios;
drop policy if exists "update_propria_linha_ou_admin" on admin_funcionarios;
create policy "update_propria_linha_ou_admin" on admin_funcionarios for update
  using (admin_eh_admin() or id = auth.uid())
  with check (admin_eh_admin() or id = auth.uid());

-- ------------------------------------------------------------
-- 4d) Bolinha vermelha de mensagem não lida no mural (pedido 13/09, 2ª
-- rodada). Guarda quando a PRÓPRIA pessoa viu o mural pela última vez —
-- comparado no front-end com a data da mensagem mais recente de outro
-- autor. Coberta pela mesma policy de update acima (dono da linha edita) e
-- pelo mesmo trigger (não é role/ativo/email/criado_por, então não é
-- protegida — qualquer um marca a própria leitura livremente, como devia
-- ser).
-- ------------------------------------------------------------
alter table admin_funcionarios add column if not exists mural_ultima_leitura timestamptz;
comment on column admin_funcionarios.mural_ultima_leitura is 'Quando a pessoa abriu o mural (Comunicação) pela última vez — usado só pra decidir se mostra a bolinha de "mensagem nova". Nulo = nunca abriu.';

-- ------------------------------------------------------------
-- 3c) ACHADO DA AUDITORIA (13/09, revisão linha a linha) — causa raiz mais
-- provável de vários problemas em cascata até aqui, incluindo alguns que
-- talvez você nem tenha reportado ainda:
--
-- SQL_PENDENTE_equipe_permissoes.sql tem um bloco (seção 11) que aplica
-- RLS "só admin" numa LISTA de tabelas via loop — e essa lista inclui
-- admin_tarefas, admin_ai_usage e admin_insights_historico, que NUNCA
-- foram criadas em nenhum SQL_PENDENTE_*.sql (conferi todos). Um loop em
-- SQL que tenta alterar uma tabela inexistente dá ERRO e para o bloco
-- inteiro na hora — e tudo que vem DEPOIS desse bloco no mesmo arquivo
-- (as policies de admin_audit_log, seção 12) nunca chega a rodar. Ou
-- seja: toda vez que esse arquivo foi colado no SQL Editor, ele
-- provavelmente parou no meio, silenciosamente — e explica um padrão que
-- se repetiu várias vezes nesta conversa (migração "parcialmente
-- aplicada").
--
-- Efeito prático, se você usa a tela Sistema/Diagnóstico: as abas
-- "Tarefas" e "Auditoria" muito provavelmente estão dando erro de
-- carregamento hoje, mesmo sem você ter reportado ainda.
--
-- Correção: criar as 3 tabelas que faltavam, e re-rodar o loop de RLS
-- (removendo admin_relatorios da lista — a página Relatórios foi
-- excluída do painel nesta mesma leva de mudanças, não faz sentido
-- recriar tabela pra ela) e as policies de admin_audit_log, pra garantir
-- que rodam de verdade desta vez.
-- ------------------------------------------------------------
create table if not exists admin_tarefas (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  descricao text,
  status text not null default 'TODO' check (status in ('TODO', 'IN_PROGRESS', 'DONE')),
  origem_tipo text default 'manual',
  origem_referencia jsonb,
  prioridade text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_tarefas enable row level security;

create table if not exists admin_ai_usage (
  id uuid primary key default gen_random_uuid(),
  range_label text,
  prompt_version text,
  model text,
  metrics_used text[] default '{}',
  recommendation_count int default 0,
  cache_hit boolean default false,
  tokens_input int default 0,
  tokens_output int default 0,
  estimated_cost_usd numeric default 0,
  gerado_por text,
  created_at timestamptz not null default now()
);
alter table admin_ai_usage enable row level security;

-- id é texto (hash sha256 truncado, gerado em código) — nunca um uuid de
-- verdade, ver intelligenceHistoryService.js:stableId().
create table if not exists admin_insights_historico (
  id text primary key,
  tipo text,
  titulo text,
  descricao text,
  evidencia text,
  impacto text,
  esforco text,
  prioridade_score numeric,
  range_label text,
  status text default 'novo',
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_insights_historico enable row level security;

-- Re-executa o loop de RLS "só admin" da seção 11 de
-- SQL_PENDENTE_equipe_permissoes.sql, sem admin_relatorios (dead code —
-- a página Relatórios foi excluída) e agora que admin_tarefas/
-- admin_ai_usage/admin_insights_historico já existem de verdade.
-- admin_settings/admin_posts/admin_pages/site_content presumidos já
-- existentes (são do site original, anteriores a este projeto) — se
-- algum deles não existir na sua base, este loop vai falhar exatamente
-- nele; me avise qual erro apareceu que eu ajusto.
do $$
declare
  tabela text;
begin
  foreach tabela in array array[
    'admin_settings', 'admin_posts', 'admin_pages', 'site_content',
    'admin_tarefas', 'admin_ai_usage', 'admin_insights_historico',
    'consultas_leads', 'consultas_atividades'
  ]
  loop
    execute format('drop policy if exists "authenticated_select_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "authenticated_insert_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "authenticated_update_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "authenticated_delete_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "authenticated_all_%1$s" on %1$s', tabela);
    execute format('drop policy if exists "somente_admin_select" on %1$s', tabela);
    execute format('drop policy if exists "somente_admin_insert" on %1$s', tabela);
    execute format('drop policy if exists "somente_admin_update" on %1$s', tabela);
    execute format('drop policy if exists "somente_admin_delete" on %1$s', tabela);
    execute format('create policy "somente_admin_select" on %1$s for select using (admin_eh_admin())', tabela);
    execute format('create policy "somente_admin_insert" on %1$s for insert with check (admin_eh_admin())', tabela);
    execute format('create policy "somente_admin_update" on %1$s for update using (admin_eh_admin())', tabela);
    execute format('create policy "somente_admin_delete" on %1$s for delete using (admin_eh_admin())', tabela);
  end loop;
end $$;

-- O loop acima também teria apagado as policies públicas (anon) de
-- consultas_leads/consultas_atividades (formulário público /consultas) —
-- recriando aqui, idênticas às originais de SQL_PENDENTE_consultas.sql.
drop policy if exists "anon_insert_consultas_leads" on consultas_leads;
drop policy if exists "anon_update_evento_consultas_leads" on consultas_leads;
drop policy if exists "anon_insert_consultas_atividades" on consultas_atividades;
create policy "anon_insert_consultas_leads" on consultas_leads for insert with check (true);
create policy "anon_update_evento_consultas_leads" on consultas_leads for update using (true) with check (true);
create policy "anon_insert_consultas_atividades" on consultas_atividades for insert with check (true);

-- admin_audit_log — mesma correção: garantir que essas policies rodam
-- desta vez (seção 12 do arquivo original, que nunca era alcançada).
create table if not exists admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id text,
  action text,
  target_type text,
  target_id text,
  metadata jsonb default '{}',
  created_at timestamptz not null default now()
);
alter table admin_audit_log enable row level security;
drop policy if exists "authenticated_select_audit" on admin_audit_log;
drop policy if exists "authenticated_insert_audit" on admin_audit_log;
drop policy if exists "authenticated_all_audit" on admin_audit_log;
drop policy if exists "select_audit_somente_admin" on admin_audit_log;
drop policy if exists "insert_audit_qualquer_funcionario_ativo" on admin_audit_log;
create policy "select_audit_somente_admin" on admin_audit_log for select using (admin_eh_admin());
create policy "insert_audit_qualquer_funcionario_ativo" on admin_audit_log for insert
  with check (exists (select 1 from admin_funcionarios where id = auth.uid() and ativo = true));

-- ------------------------------------------------------------
-- 4b) Mural/comunicação da equipe (pedido 13/09) — um canal único onde
-- qualquer funcionário ativo manda mensagem/tira dúvida, todo mundo vê.
-- Sem edição/exclusão pelo autor (mensagem enviada é definitiva, mesmo
-- espírito de "registro confiável" já usado no ponto) — só o admin pode
-- apagar, pra moderar se precisar.
-- ------------------------------------------------------------
create table if not exists admin_equipe_mensagens (
  id uuid primary key default gen_random_uuid(),
  autor_id uuid not null references admin_funcionarios(id) on delete cascade,
  mensagem text not null check (char_length(trim(mensagem)) > 0 and char_length(mensagem) <= 2000),
  created_at timestamptz not null default now()
);
alter table admin_equipe_mensagens enable row level security;
create index if not exists admin_equipe_mensagens_created_idx on admin_equipe_mensagens (created_at desc);

drop policy if exists "select_mensagens_equipe_ativa" on admin_equipe_mensagens;
drop policy if exists "insert_mensagem_propria" on admin_equipe_mensagens;
drop policy if exists "delete_mensagens_somente_admin" on admin_equipe_mensagens;

create policy "select_mensagens_equipe_ativa" on admin_equipe_mensagens for select
  using (exists (select 1 from admin_funcionarios where id = auth.uid() and ativo = true));
create policy "insert_mensagem_propria" on admin_equipe_mensagens for insert
  with check (autor_id = auth.uid() and exists (select 1 from admin_funcionarios where id = auth.uid() and ativo = true));
create policy "delete_mensagens_somente_admin" on admin_equipe_mensagens for delete
  using (admin_eh_admin());

comment on table admin_equipe_mensagens is 'Mural/comunicação da equipe — um canal único, visível pra todo funcionário ativo. Mensagem enviada não pode ser editada; só admin apaga (moderação).';

-- ------------------------------------------------------------
-- 4e) "Compartilhar no mural" a partir de um cliente (pedido 13/09, 2ª
-- rodada) — liga a mensagem a um lead/cliente opcionalmente, pra mostrar
-- um link de volta pra ele. "on delete set null": se o cliente for
-- excluído depois, a mensagem continua existindo (só perde o link).
-- ------------------------------------------------------------
alter table admin_equipe_mensagens
  add column if not exists lead_id uuid references admin_prospeccao_leads(id) on delete set null;
comment on column admin_equipe_mensagens.lead_id is 'Opcional — preenchido quando a mensagem foi enviada pelo botão "Compartilhar no mural" de um cliente. Mostra um link de volta pra ele no mural.';

-- ------------------------------------------------------------
-- 3d) ACHADO NOVO (13/09, depois de você já ter rodado a v1 deste arquivo e
-- confirmado a conferência do final toda "true") — a query de conferência
-- só prova que as TABELAS existem; ela não prova que toda COLUNA/CONSTRAINT
-- que o código espera também existe. O card de Metas do Início continuou
-- dando "Falha ao consultar atividades (400)" porque a Function que ele usa
-- (relatorioService.js:buscarAtividadesPeriodo) pede as colunas
-- status_anterior/status_novo de admin_prospeccao_atividades — colunas que
-- só existiam em SQL_PENDENTE_estados_rapidos.sql, um arquivo pequeno e
-- separado que nunca tinha sido rodado nem incorporado aqui.
--
-- Enquanto investigava isso, achei mais duas migrações pequenas no mesmo
-- caso — separadas, nunca incorporadas, e cobrindo funcionalidade que já
-- está ativa no painel hoje (não é recurso desligado):
--   • SQL_PENDENTE_inteligencia.sql → objecao (usada em atividadesService.js
--     e na tela Clientes) e follow_up_notificado_em (usada no job agendado
--     scheduled-sync-background.js)
--   • SQL_PENDENTE_clientes.sql → instagram e responsavel_interno (usadas em
--     prospeccaoService.js e na tela Clientes)
-- Todas as três: só coluna nova opcional (nunca quebra linha existente) ou
-- constraint que só GANHA valores novos permitidos (nunca remove um valor
-- que já era aceito) — 100% seguro rodar mesmo que parte disso já exista.
-- ------------------------------------------------------------
alter table admin_prospeccao_leads
  add column if not exists instagram text,
  add column if not exists responsavel_interno text,
  add column if not exists follow_up_notificado_em timestamptz;

alter table admin_prospeccao_atividades
  add column if not exists status_anterior text,
  add column if not exists status_novo text,
  add column if not exists objecao text;

comment on column admin_prospeccao_atividades.status_anterior is 'Preenchido só em atividades tipo=mudanca_status (ou tipos que também mudam o status, como resposta_recebida/reuniao_marcada) — estágio do lead antes da ação.';
comment on column admin_prospeccao_atividades.status_novo is 'Preenchido só em atividades tipo=mudanca_status (ou tipos que também mudam o status) — estágio do lead depois da ação.';

-- Estágio "interessado" no funil de prospecção (entre "respondeu" e
-- "reuniao_marcada") — usado em prospeccao.js/inicio.js mas nunca liberado
-- na constraint da coluna `status`.
alter table admin_prospeccao_leads
  drop constraint if exists admin_prospeccao_leads_status_check;
alter table admin_prospeccao_leads
  add constraint admin_prospeccao_leads_status_check
  check (status in (
    'novo_lead','contatado','respondeu','interessado',
    'reuniao_marcada','proposta_enviada','cliente','nao_convertido'
  ));

-- Tipos de atividade que atividadesService.js já grava há tempos, mas que a
-- constraint de `tipo` nunca aceitou — qualquer tentativa de gravar um
-- desses (inclusive a mudança de status que o botão "Interessado" faz) tem
-- falhado silenciosamente com 400 contra a constraint antiga.
alter table admin_prospeccao_atividades
  drop constraint if exists admin_prospeccao_atividades_tipo_check;
alter table admin_prospeccao_atividades
  add constraint admin_prospeccao_atividades_tipo_check
  check (tipo in (
    'email_enviado','whatsapp_enviado','ligacao','follow_up','resposta_recebida',
    'reuniao_marcada','reuniao_realizada','proposta_enviada','negociacao','nota',
    'mudanca_status',
    'briefing_atualizado','diagnostico_criado','diagnostico_publicado','apresentacao_enviada'
  ));

-- ------------------------------------------------------------
-- 5) Renomear a conta de marketing@felipebranding.com.br. Condicional —
-- só altera se o nome atual ainda for "Marketing" (não sobrescreve se você
-- já tiver renomeado por outro caminho).
-- ------------------------------------------------------------
update admin_funcionarios
set nome = 'Felipe Souto - Dono', updated_at = now()
where email = 'marketing@felipebranding.com.br' and nome = 'Marketing';

-- ------------------------------------------------------------
-- 6) Schema cache do PostgREST — sem isto, tabelas/colunas novas podem
-- continuar dando 404/erro por alguns minutos até o cache expirar sozinho.
-- ------------------------------------------------------------
notify pgrst, 'reload schema';

-- ------------------------------------------------------------
-- 7) Conferência final — rode e confira:
--    todas as colunas "_existe" → esperado: true em todas
--    colunas_perfil_existentes → esperado: 4 (foto_url, tempo_experiencia, funcoes, genero)
--    colunas_atividades_existentes → esperado: 3 (status_anterior, status_novo, objecao)
--    colunas_leads_existentes → esperado: 3 (instagram, responsavel_interno, follow_up_notificado_em)
--    status_interessado_liberado / tipo_mudanca_status_liberado → esperado: true nas duas
--    biografia_existe / trigger_protecao_existe / policy_autoedicao_existe → esperado: true nas três
--    conta_renomeada → esperado: 'Felipe Souto - Dono' (ou o nome que você já tinha colocado)
-- ------------------------------------------------------------
select
  to_regclass('public.admin_notificacoes') is not null as notificacoes_existe,
  to_regclass('public.admin_ponto_registros') is not null as ponto_existe,
  to_regclass('public.admin_metas_prospeccao') is not null as metas_existe,
  to_regclass('public.admin_prospeccao_buscas') is not null as buscas_existe,
  to_regclass('public.admin_prospeccao_envios') is not null as envios_existe,
  to_regclass('public.admin_equipe_mensagens') is not null as mensagens_existe,
  to_regclass('public.admin_tarefas') is not null as tarefas_existe,
  to_regclass('public.admin_ai_usage') is not null as ai_usage_existe,
  to_regclass('public.admin_insights_historico') is not null as insights_historico_existe,
  to_regclass('public.admin_audit_log') is not null as audit_log_existe,
  (select count(*) from information_schema.columns
    where table_name = 'admin_funcionarios' and column_name in ('foto_url','tempo_experiencia','funcoes','genero')) as colunas_perfil_existentes,
  (select count(*) from information_schema.columns
    where table_name = 'admin_prospeccao_atividades' and column_name in ('status_anterior','status_novo','objecao')) as colunas_atividades_existentes,
  (select count(*) from information_schema.columns
    where table_name = 'admin_prospeccao_leads' and column_name in ('instagram','responsavel_interno','follow_up_notificado_em')) as colunas_leads_existentes,
  exists (
    select 1 from pg_constraint where conname = 'admin_prospeccao_leads_status_check'
      and pg_get_constraintdef(oid) like '%interessado%'
  ) as status_interessado_liberado,
  exists (
    select 1 from pg_constraint where conname = 'admin_prospeccao_atividades_tipo_check'
      and pg_get_constraintdef(oid) like '%mudanca_status%'
  ) as tipo_mudanca_status_liberado,
  exists (
    select 1 from information_schema.columns
      where table_name = 'admin_funcionarios' and column_name = 'biografia'
  ) as biografia_existe,
  exists (
    select 1 from information_schema.columns
      where table_name = 'admin_funcionarios' and column_name = 'mural_ultima_leitura'
  ) as mural_ultima_leitura_existe,
  exists (
    select 1 from information_schema.columns
      where table_name = 'admin_equipe_mensagens' and column_name = 'lead_id'
  ) as mural_lead_id_existe,
  exists (
    select 1 from pg_trigger where tgname = 'protege_colunas_sensiveis'
  ) as trigger_protecao_existe,
  exists (
    select 1 from pg_policies where tablename = 'admin_funcionarios' and policyname = 'update_propria_linha_ou_admin'
  ) as policy_autoedicao_existe,
  (select nome from admin_funcionarios where email = 'marketing@felipebranding.com.br') as conta_renomeada;
