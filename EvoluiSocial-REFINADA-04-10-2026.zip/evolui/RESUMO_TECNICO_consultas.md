# Consultoria Gratuita de Perfil para Instagram (/consultas) — Resumo técnico ETAPAS 1–5

Rota pública: `https://www.felipebranding.com.br/consultas`
Área administrativa: aba **Consultorias** na central `/painel` (menu lateral, junto de Prospecção).

Nada foi recriado do zero: toda a implementação reaproveita a identidade visual (Fraunces + Manrope, tokens de cor/espaço), a arquitetura (Netlify Functions + Supabase, sem bundler no site público, ES modules só no painel) e os padrões já existentes no projeto (tema claro/escuro, honeypot anti-spam, rate limiting em memória, `requireUser` para auth do painel, RLS, `_redirects`/`_headers`).

## 1. Arquivos criados

**Site público**
- `consultas.html` — página do wizard (8 etapas), estados de loading/erro/resultado, modal de agendamento reaproveitado.
- `assets/css/consultas.css` — só o que é específico do wizard/resultado; todo o resto vem de `main.a7ad8bfa81.css`.
- `assets/js/consultas.js` — lógica do wizard, validação, envio, renderização do diagnóstico, CTAs, telemetria.

**Backend (Netlify Functions)**
- `netlify/functions/consultas-criar.js` — pública: honeypot, rate limit (5/15min por IP), validação, gera o diagnóstico no servidor e grava o lead.
- `netlify/functions/consultas-evento.js` — pública: registra clique de CTA (whatsapp/agendamento/instagram) no mesmo lead, fire-and-forget, nunca bloqueia a navegação.
- `netlify/functions/consultas.js` — autenticada: GET/PATCH/DELETE administrativo (mesmo padrão de `prospeccao.js`).
- `netlify/functions/consultas-atividades.js` — autenticada: histórico de atividades do lead.
- `netlify/functions/_lib/diagnosticoEngine.js` — motor determinístico do diagnóstico (ver seção 4).
- `netlify/functions/_lib/services/consultasService.js` e `consultasAtividadesService.js`.

**Painel administrativo**
- `painel/assets/js/services/consultasClient.js` — cliente HTTP (mesmo padrão de `prospeccaoClient.js`).
- `painel/assets/js/views/consultorias.js` — view completa: lista com busca/filtro por status, modal de detalhe (dados de contato, diagnóstico, editor de status/contato/observações, linha do tempo de atividades, atalhos WhatsApp/Instagram/agendamento, exclusão com confirmação).
- `painel/assets/css/consultorias-view.css` — grid responsivo do formulário do modal (mesmo padrão de `prospeccao-view.css`).

**Migração de banco**
- `SQL_PENDENTE_consultas.sql` — **ainda não executado no Supabase**. Precisa ser rodado no SQL Editor do projeto antes do deploy desta funcionalidade (sem isso, o formulário e a aba Consultorias respondem com erro tratado, sem quebrar o resto do site/painel).

## 2. Arquivos alterados (existentes)

- `_redirects` — `/consultas → /consultas.html` (mesmo padrão de `/admin`).
- `_headers` — cache `must-revalidate` para os dois arquivos novos sem hash no nome (`consultas.css`/`consultas.js`); sem isso, uma correção futura neles ficaria até 1 ano em cache no navegador do visitante.
- `sitemap.xml` — nova entrada `/consultas`.
- `painel/assets/js/app.js` — rota `#/consultorias` registrada.
- `painel/index.html` — link de navegação "Consultorias" na barra lateral + `<link>` do novo CSS de view.

`robots.txt` não precisou de alteração (já permite tudo, exceto `/admin` e `/painel`).

## 3. Tabelas/migrations criadas

`SQL_PENDENTE_consultas.sql` cria:

- **`consultas_leads`** — um lead por solicitação. Campos do formulário (nome, instagram, whatsapp, email, segmento, objetivo, origem), diagnóstico (`resultado_analise` jsonb + `resultado_gerado_em`), conversão (`cta_clicado`, `tentativa_agendamento`, `consultoria_concluida_em`) e campos exclusivos do painel (`status`, `contato_realizado`, `ultimo_contato_em`, `observacoes_internas`, `atualizado_por`).
- **`consultas_atividades`** — linha do tempo por lead (análise concluída, cliques de CTA, contato realizado, mudança de status, observação).

Pipeline de status: `novo → analisando → analise_enviada → contatado → reuniao_agendada → convertido → arquivado`.

RLS: autenticado tem acesso total (mesmo padrão do resto do painel); `anon` só pode **criar** um lead (com todos os campos administrativos travados no valor inicial via `WITH CHECK`) e **atualizar 5 colunas específicas** de conversão (via `GRANT UPDATE` de coluna + RLS combinados) — nunca lê, nunca usa a service role key.

**Camada extra adicionada na revisão final (ETAPA 5):** como a tabela aceita INSERT direto do papel `anon`, a validação da Function `consultas-criar.js` pode ser contornada por quem chamar a REST do Supabase diretamente com a chave anônima (pública por padrão do projeto). Por isso, os mesmos formatos já validados na Function agora também são reforçados com `CHECK` constraints no banco (formato do @Instagram, dígitos do WhatsApp, e-mail, enum de segmento/objetivo/origem, tamanho do nome) — segunda camada de defesa, e o que efetivamente fecha um vetor de XSS armazenado (ver seção 5).

## 4. Motor de diagnóstico (ETAPA 3)

Determinístico, sem IA/API externa: mesma entrada (nome + instagram + segmento + objetivo) sempre produz o mesmo resultado (hash simples decide qual variante de texto usar em cada categoria — varia a redação sem precisar de aleatoriedade real). Categorias avaliadas: posicionamento, identidade visual, conteúdo, conversão, presença digital. Saída: resumo, categorias com avaliação (atenção/base/oportunidade), pontos fortes, pontos que limitam o perfil, oportunidades, próximas ações recomendadas e texto do CTA final.

Calculado **sempre no servidor** (nunca no navegador), para que o resultado salvo não possa ser adulterado pelo visitante antes de chegar ao banco.

Arquitetura preparada para IA futura sem depender dela agora: `MOTOR_VERSAO` versiona a saída, e o contrato de dados é o mesmo que um motor baseado em `aiProvider.js` (já existente no projeto para outras áreas) poderia produzir — trocar o motor não exige mudar o restante do sistema.

## 5. Integrações utilizadas

- Supabase REST (mesma chave anônima pública já usada em todo o projeto) — nunca a service role key em nenhum caminho que atenda requisição de visitante/frontend.
- Google Analytics (gtag.js, `G-PC9B5RBXDS`, já ativo no site) — eventos custom adicionados (`consulta_etapa`, `consulta_submit`, `consulta_resultado_visualizado`, `cta_whatsapp_click`, `cta_instagram_click`, `cta_agendamento_click`), sempre guardados por `typeof gtag === 'function'`, sem alterar a configuração existente.
- WhatsApp (`wa.me`) e Google Agenda ("quick add") — mesmos sistemas já usados na home, replicados porque o projeto não tem módulos compartilhados entre páginas HTML.
- Nenhuma chave/segredo novo é necessário — tudo usa a infraestrutura e as credenciais já existentes.

## 6. Problemas encontrados e corrigidos

Encontrados e corrigidos durante a implementação (antes de qualquer execução real):
- Erro de concordância verbal em 4 trechos do motor de diagnóstico (`diagnosticoEngine.js`).
- Bug na política RLS de eventos de CTA (exigia `tentativa_agendamento = true` incondicionalmente, o que rejeitaria os cliques de WhatsApp/Instagram).
- Lógica confusa (não incorreta, mas frágil) na função `showOnly()` do wizard — reescrita de forma mais clara.
- Condição errada que esconderia o botão "Voltar" na etapa 1 — removida.

Encontrados e corrigidos nesta revisão final (ETAPA 5):
- **XSS armazenado (segurança):** `nome`/`instagram` de um lead podiam chegar ao painel administrativo com HTML/script arbitrário (a validação de formato só existia na Function pública, contornável via chamada direta à REST do Supabase com a chave anônima) e dois pontos em `consultorias.js` inseriam esses campos sem escapar (link do Instagram e texto de confirmação de exclusão) — corrigido escapando os dois pontos e reforçando o formato com `CHECK` constraints no banco.
- **UX/visual:** o formulário do modal de detalhe (WhatsApp/e-mail/objetivo, status/observações, nova atividade) não tinha o CSS de grid responsivo que o padrão do painel exige (existia só para a tela de Prospecção, escopado por classe) — criado `consultorias-view.css` seguindo exatamente o mesmo padrão.
- **SEO/compartilhamento:** `/consultas` não tinha imagem de pré-visualização para Open Graph/Twitter Card (relevante porque a ETAPA 4 pede que o compartilhamento via Instagram/WhatsApp funcione bem) — adicionada usando a logomarca já existente no projeto (nenhuma arte nova).

## 7. Testes realizados

Sem ambiente de deploy real (Netlify/Supabase) disponível nesta sessão, todos os testes foram estáticos/manuais no código:
- `node --check` em todos os 11 arquivos JavaScript novos/alterados (site público, Functions, painel) — todos passam.
- Validação de HTML bem-formado (`consultas.html`, `painel/index.html`) via parser Python.
- Balanceamento de chaves `{ }` nos dois arquivos CSS novos.
- Referência cruzada manual de IDs entre HTML e JS (todo elemento referenciado por `getElementById` existe no HTML correspondente).
- Execução do motor de diagnóstico (`node -e`) com várias combinações de segmento/objetivo, conferindo concordância gramatical do texto gerado.
- Revisão de todas as políticas RLS e do fluxo completo Instagram → `/consultas` → preenchimento → análise → resultado → WhatsApp/Instagram/agendamento → registro no painel, campo a campo.
- Varredura de todo uso de `innerHTML` nos arquivos novos, conferindo escurecimento (`esc()`/`escapeHtml()`) de qualquer dado vindo do visitante.

**Pendente (requer ambiente real):** teste end-to-end após o deploy — rodar `SQL_PENDENTE_consultas.sql` no Supabase, publicar no Netlify e percorrer o fluxo completo num Android, um iPhone e um desktop de verdade, incluindo compartilhamento real via WhatsApp/Instagram.

## 8. Configuração necessária para publicar

1. Rodar `SQL_PENDENTE_consultas.sql` no SQL Editor do Supabase (projeto `aligftypgtzlymmditeo`) — **obrigatório antes do deploy**, senão o formulário e a aba Consultorias respondem com erro tratado.
2. Fazer o deploy normal do site (Netlify detecta as novas Functions automaticamente via `netlify/functions/*.js`, sem precisar editar `netlify.toml`).
3. **Nenhuma variável de ambiente nova é necessária** — tudo usa a chave anônima pública já configurada no projeto.
