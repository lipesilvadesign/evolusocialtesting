# Evolui Social — Video Intelligence Pro/Master

## Objetivo

Adicionar ao Laboratório uma ferramenta exclusiva para Pro e Master que recebe um link de vídeo e transforma a análise em sinais reutilizáveis pelo fluxo de criação da Evolui.

## Fluxo

```text
Link do vídeo
   ↓
oEmbed / metadados públicos
   ↓
Serviço de inferência de vídeo
   ↓
Video Intelligence v1
   ↓
Tema · gancho · CTA · elementos visuais · termos
   ↓
EIE / contexto do usuário
   ↓
4 ideias de continuação
   ↓
Laboratório / Documento
```

## Modelo open source

A camada é agnóstica. Para produção, a recomendação é conectar um serviço de inferência baseado em um modelo de compreensão de vídeo open-source, como Qwen2.5-VL, em vez de colocar o modelo pesado dentro da Edge Function.

## Secrets

Na Edge Function `evolui-api`:

- `EVOLUI_VIDEO_ANALYZER_URL` — endpoint HTTPS do serviço de inferência.
- `EVOLUI_VIDEO_ANALYZER_TOKEN` — opcional; enviado somente como Bearer para o serviço.

O frontend nunca recebe esses secrets.

## Contrato do serviço de inferência

A Evolui envia POST JSON:

```json
{
  "url": "https://...",
  "plataforma": "youtube",
  "prompt": "...",
  "contexto": {
    "ramo": "...",
    "objetivo": "...",
    "cidade": "..."
  }
}
```

O serviço deve retornar JSON com:

```json
{
  "descricao": "...",
  "transcricao": "...",
  "tema": "...",
  "formato": "...",
  "gancho": "...",
  "cta": "...",
  "elementos_visuais": [],
  "pontos_fortes": [],
  "pontos_atencao": [],
  "termos": [],
  "confianca": 0.0
}
```

## Segurança

- A funcionalidade é bloqueada no servidor para Free.
- Pro e Master possuem acesso.
- Há limite de 3 análises por minuto por usuário.
- URLs precisam ser HTTPS.
- O sistema não promete desempenho do vídeo.
- O prompt exige separar observação de inferência.
- Se o serviço de inferência não estiver configurado, a funcionalidade informa a configuração pendente em vez de fingir que analisou o vídeo.

## UX

- Cards com cantos arredondados.
- Motion leve e funcional.
- Carregamento progressivo.
- Mais espaço negativo no Laboratório desktop.
- Ideias podem ser levadas diretamente para o Documento.

## Preservação

A implementação é aditiva. O Pinterest Trends, EIE, referências, testes A/B, documentos e fluxo existente do Laboratório permanecem.
