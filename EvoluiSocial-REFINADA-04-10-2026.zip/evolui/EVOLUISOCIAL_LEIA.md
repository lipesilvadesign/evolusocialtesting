# Painel › EvoluiSocial › Integrações (02/10/2026): onde colocar as chaves de API

- Nova aba **Integrações** no painel (só o proprietário vê e altera). Cola a chave, salva, testa (OpenAI e Anthropic), substitui ou remove.
- Já vem a lista: OpenAI, Anthropic, Meta (ID e chave secreta do app). Para uma integração nova, use **Adicionar outra chave** (nome + identificador + chave).
- As chaves ficam **criptografadas no Supabase Vault**. A tela nunca recebe o valor de volta: só "Configurada" e os 4 últimos caracteres (quando a chave tem 16+ caracteres). Para trocar, cole outra.
- Todas são **opcionais**. Sem chave, o app e a pesquisa funcionam como antes.
- Cada salvar/remover entra no log do painel, sem o valor.
- Para o código ler uma chave (Edge Function com a chave de serviço): `adm.rpc('evolui_integracao_ler', { p_chave: 'openai' })`. Essa função não é liberada ao navegador.
- Banco: tabela `evolui_integracoes` (sem acesso direto), funções `evolui_integracoes_listar`, `evolui_integracao_salvar`, `evolui_integracao_remover` (só proprietário), `evolui_integracao_ler` e `evolui_integracao_registrar_teste` (só servidor). Edge Function nova: `evolui-integracoes` (testa a chave com uma leitura simples no provedor).
- Cadastrar a chave **não liga nada sozinho**: o código que a usa ainda precisa ser criado.
- Nunca envie chaves em conversa, e-mail ou arquivo. Se alguma já foi exposta, gere outra no provedor e troque aqui.

# EvoluiSocial — 4ª rodada (02/10/2026): Objetivos e CTAs

## O que o usuário vê
- Na tela **Buscar**, acima dos resultados: "O que você quer fazer?" com 7 objetivos (ideia de vídeo, não sei o que postar, mais visualizações, ganhar seguidores, divulgar o negócio, apresentar produto ou serviço, aproveitar uma tendência).
- Um toque gera uma **ação concreta** (CTA): título, o que fazer, passos numerados, gancho, chamada para ação, para quem, rede, dificuldade e tempo. Sem formulário antes.
- Botões: **Começar a criar** (passos marcáveis), **Concluí**, **Outra sugestão**, **Não é para mim** e **Testar a legenda no laboratório**.
- **Continue de onde parou**: a ação em andamento aparece no topo da tela Buscar.
- **Pesquisa → ação**: pesquisas como "não sei o que postar" mostram o cartão "Transformar em ação" com os objetivos relacionados. A pesquisa não foi duplicada: usa as intenções que o motor já detecta.
- **Histórico › Ações**: lista com status (Nova, Em andamento, Concluída, Descartada), abrir, concluir e descartar.

## Como a ação é escolhida (sem IA externa, sem API paga)
- 35 modelos editoriais (5 por objetivo) guardados no banco; o usuário nunca lê os modelos diretamente, só a ação gerada.
- Personalização por regras: ramo e detalhe do negócio, cidade, canal de venda e formato preferido (respostas do dia, só se "personalizar" estiver ligado), redes cadastradas e preferência por aparecer ou não. Sem perfil completo a ação sai genérica do objetivo, e continua útil.
- Não repete a mesma ação enquanto houver modelos novos para o usuário. Limite de 40 ações por dia por usuário.

## Banco (Supabase)
- Tabelas: `evolui_objetivos_catalogo`, `evolui_ramo_ctx`, `evolui_cta_modelos`, `evolui_ctas` (histórico: usuário, objetivo, ação, datas, status). Coluna nova `evolui_objetivos.chave`.
- Funções: `evolui_cta_gerar` e `evolui_cta_status` (SECURITY DEFINER, só usuário logado). `evolui_ctas` não aceita insert/update direto; cada pessoa só lê e apaga as próprias.
- A API `evolui-api` (v7) devolve `objetivos` no resultado da busca.
- "Baixar meus dados" e "Apagar meus dados" incluem ações e objetivos.

## Limitações
- As ações são modelos editoriais personalizados por regras, não geradas por IA. Com um detalhe de negócio muito específico o texto pode soar um pouco estranho (ex.: "sobre fotógrafo").
- O status "Em andamento" guarda só o estado; o progresso dos passos marcados não é salvo.

# EvoluiSocial — 3ª rodada (01/10/2026): pesquisa em camadas e estrutura administrativa

## Pesquisa
- A busca agora entende a frase: **assunto** (do que fala), **intenção** (o que a pessoa quer) e **formato** (vídeo, carrossel...).
- Tolera acento, plural e pequenos erros de digitação ("seguidres" → "seguidores", "brigadero" → "Brigadeiro (doce)").
- Nova **biblioteca da EvoluiSocial** (60 itens: ideias, ganchos, CTAs, guias), pesquisada no banco por título, descrição, texto, tags, palavras-chave, intenção, ramo e formato.
- Cascata: exato → parcial → variações → termos relacionados → categoria/tags → ampliação pelo ramo → sem repetidos → ordem por relevância, com variedade de formatos.
- No app (mesmo visual):
  - linha "Entendemos" abaixo do título;
  - bloco "Mais ideias para isso", com "Ver mais" (no Free, as seguintes ficam travadas);
  - busca e "Carregar mais" no Histórico.
- Notícias: o GDELT recebe só o assunto (antes recebia a frase inteira, com "para", "conseguir" etc.), e a consulta é ampliada se vier pouco.

## Papéis e área administrativa
- Papéis no banco: **user**, **admin** e **owner**. A autorização é toda feita no banco; o painel só esconde botões por conforto.
- Proprietários definidos: marketing@felipebranding.com.br e felipesilva.media@gmail.com. Só o proprietário muda papéis, e o banco sempre mantém pelo menos um.
- Painel › EvoluiSocial:
  - Usuários: papel, status, último login, forma de entrar e "Enviar redefinição de senha";
  - nova aba **Plataforma**: saúde das fontes, papéis, rotinas, agentes, conteúdos e conexões.
- Senhas: ninguém do painel vê ou define senha. O botão envia o e-mail oficial do Supabase. Conta que entra com Google não tem senha aqui, e o painel avisa isso.

## Estrutura preparada (ainda sem tela para o usuário)
- Cadeia de dados: Usuário → Objetivo → CTA → Conteúdo (link ou upload) → Rede → Publicação → Métricas → Resultado → Aprendizado.
- Tabelas `evolui_objetivos`, `evolui_conteudos`, `evolui_publicacoes`, `evolui_metricas`, `evolui_aprendizados`, `evolui_conexoes` e a visão `evolui_jornada`. Cada pessoa só vê o que é dela.
- Pasta privada `evolui-videos` para upload (até 100 MB: mp4, mov, webm).
- Ação `analisar_link` na API:
  - reconhece links de YouTube, TikTok e Instagram;
  - lê só dados públicos pelo oEmbed oficial (YouTube e TikTok);
  - nada de scraping. O Instagram exige app aprovado pela Meta.

## O que falta VOCÊ fazer (3ª rodada)
1. Publicar este pacote no Netlify.
2. Supabase › Authentication › URL Configuration: confirme que `https://felipebranding.com.br/evoluisocial/app/` está em Redirect URLs. É para onde o e-mail de redefinição de senha leva.

---

# EvoluiSocial — o que mudou em 01/10/2026 (2ª rodada) e o que falta você fazer

## 1. Visual na família Felipe Branding
- Mesma paleta do site principal: azul-meia-noite `#161f30`, papel `#f7f5f0`, dourado `#c9a667`.
- Mesmas fontes: Fraunces (títulos), Manrope (texto), IBM Plex Mono (rótulos) e a estrela de 4 pontas.
- Tema escuro por padrão, claro pelo botão de lua/sol. A escolha é a mesma do site (`fb_theme`).
- Efeitos mantidos, mais lentos e suaves. No celular, o fundo animado desliga, para ficar leve.
- Computador: a página usa a tela inteira (até 1.600 px). O app tem menu lateral e coluna "Para você / Em alta".
- Resultado da busca em pirâmide:
  1. **Veredito**: estado, recomendação de uma linha, números.
  2. **O que postar**: ideias e bio.
  3. **De onde vem**: gráfico, fontes e notícias.
- Testado em 320, 390, 768, 1280, 1440 e 1920 px, sem rolagem lateral e sem erros.

## 2. Busca (o principal)
- **Wikipédia:** agora acha a página certa ("advocacia" ia para "Advocacia-Geral da União"; agora vai para "Advogado").
- **Notícias (GDELT):** o servidor recebia "limite de uso" porque o endereço de nuvem é compartilhado. Agora o navegador de cada pessoa consulta o GDELT, e o servidor confere os dados antes de usar.
- **Google Notícias:** NÃO é usado. O feed proíbe uso comercial e isso violaria a regra de "sem violar políticas".
- **Agente de perfil:** as ideias passam a considerar:
  - o formato preferido;
  - se a pessoa aparece em vídeo;
  - o horário em que os clientes dela respondem;
  - o canal de venda e o tom da marca.
- Agora são 5 formatos de ideia: Reels, Carrossel, Stories, Bastidores e Parceria. O plano Pro em diante recebe também uma bio sugerida.
- **"Para você":** sugestões que misturam o ramo da pessoa, o que ela já pesquisou e o que está em alta hoje.

## 3. Planos com conteúdo borrado (protegido de verdade)
- O servidor só envia o que o plano libera. Ideia travada chega sem texto, só com o formato; o borrado é desenho.
- Por isso a ferramenta "Inspecionar" do navegador não revela nada: o texto travado nunca chegou ao navegador.
- Free: 1 ideia completa, 2 notícias, gráfico de 14 dias.
- Pro: 3 ideias, bio sugerida, 28 dias e mapa da cidade.
- Master: 5 ideias, mais notícias e relacionados.
- O texto dos planos e a tabela de comparação no site foram ajustados para prometer só o que existe.

## 4. Pergunta do dia
- Uma pergunta por dia, num cartão discreto que pode ser fechado.
- São 28 perguntas: formato, horário, desafio, canal de venda, tom etc.
- As respostas alimentam as ideias.
- LGPD: no Perfil há o interruptor "Personalização". Desligado, paramos de registrar. "Baixar meus dados" e "Apagar meus dados" incluem tudo.

## 5. Agentes (rodam sozinhos no banco, sem custo)
- **Agente de segurança** (a cada hora) procura:
  - rajadas de busca;
  - 3 ou mais contas usando o mesmo acesso à internet (guardado como código irreversível, nunca o IP);
  - quem força o limite do plano;
  - tentativas de trocar o plano sem pagar (testado: o banco bloqueia e gera alerta);
  - pagamentos com valor menor que o preço.
- **Agente de perfil** (todo dia, 6h17 UTC): calcula o segmento (novo, ativo, morno ou inativo) e o engajamento de 0 a 100.
- **Vencimento de planos** (a cada hora): volta para Free quem não renovou.
- **Brechas fechadas:**
  - Apagar o histórico "devolvia" pesquisas do mês. Agora o contador é separado e só o servidor mexe nele.
  - A pessoa conseguia gravar histórico falso direto pela API. Agora só o servidor grava.

## 6. Painel da Felipe Branding › Produtos › EvoluiSocial (só administradores)
- **Visão geral:**
  - usuários, ativos, pesquisas por dia, assinantes, arrecadado e alertas;
  - funil, o que pesquisam, ramos e cidades;
  - o que respondem na pergunta do dia;
  - status dos agentes e o botão "Rodar agentes agora".
- **Usuários:** plano, uso, segmento e redes. É possível dar ou tirar plano (cortesia com prazo) e bloquear, e tudo fica registrado.
- **Segurança:** alertas, com "Marcar como resolvido".
- **Financeiro:**
  - arrecadado por mês, taxas, líquido, por plano e por forma de pagamento;
  - últimos pagamentos;
  - preços (editáveis) e conta de recebimento.
- **Financeiro da agência:** ganhou um cartão "EvoluiSocial · arrecadado no mês", separado dos clientes.

## 7. Pagamento (Mercado Pago) — pronto, mas DESLIGADO até você configurar
- Função `evolui-pagamentos` já publicada:
  - checkout com Pix, cartão e boleto;
  - aviso automático confirmado direto na API do Mercado Pago;
  - libera o plano por 1 mês ou 1 ano;
  - reembolso ou estorno volta para Free e gera alerta.
- Cartão nunca passa pela Felipe Branding: ficamos só com status, valor, taxa e forma de pagamento.
- O dinheiro cai na conta Mercado Pago cujo token você colocar. Passo a passo em Painel › EvoluiSocial › Financeiro › "Como ligar o Mercado Pago".

## O que falta VOCÊ fazer
1. Publicar este pacote no Netlify (site + painel).
2. Não desligue o login por e-mail no Supabase: é ele que a equipe usa para entrar no painel. Ele já exige confirmar o e-mail, e conta nova sem linha em `admin_funcionarios` não entra no painel.
3. Apagar a conta de teste `qa.evolui+teste1@felipebranding.com.br`, em Authentication › Users. Ela já está bloqueada; o apagar ficou para você porque o Supabase pede confirmação manual.
4. Aprovar os preços em Painel › EvoluiSocial › Financeiro e ligar o Mercado Pago (quando quiser vender).
5. Opcional: ligar "Leaked password protection" em Authentication › Settings.

## Limites honestos
- GDELT: 1 consulta a cada 5 s por pessoa; se falhar, a busca segue sem notícias.
- OpenStreetMap é feito por voluntários: a contagem de concorrentes é um termômetro, não um número exato.
- As tabelas e funções do banco estão registradas no histórico de migrações do Supabase (`evolui_01` a `evolui_03f`).

## Motor de inteligência — EIE-v1 (Evolui Intelligence Engine)

Fica em `supabase/functions/evolui-api/eie/` e é usado pela busca, pela biblioteca ("Ver mais ideias") e pela sugestão de ação (objetivos/CTA). Cada recomendação carrega um objeto `eie` com a versão do algoritmo (`EIE-v1`), a versão da configuração, a nota (EvoluiScore, de 0 a 100, que mede **adequação ao contexto**, não chance de viralizar), cada sinal, penalidades, o que não estava disponível e o "por que apareceu" (com a origem: informado, buscado, derivado ou gerado).

**O que ele faz:** entende a busca (reaproveita `consulta.ts`) → candidatos (busca léxica do banco + semântica por conceitos em português + contexto do negócio) → EvoluiScore com pesos configuráveis → diversidade (MMR) e anti-repetição → Context Engine (título, descrição, passos, por que apareceu) → controle de qualidade com texto seguro de reserva → aprendizado por eventos (ver, copiar, salvar, começar, concluir, descartar e "Não é para mim" são eventos separados; ideia vista volta depois, não é excluída para sempre).

**Regras de segurança do conteúdo:** nunca afirma cidade, loja, atendimento presencial, rosto ou público que a pessoa não informou; nenhuma justificativa é reaproveitada entre cards; sinal de tendência só aparece com fonte e só em 1 card.

**Sem dependência nova e sem API:** a busca semântica é um dicionário de conceitos curado em português (não é embedding neural). Existe uma interface pronta para plugar embeddings reais no futuro. Texto por IA é opcional: vem **desligado**; só funciona se o dono ligar `llm.ativo` em `evolui_eie_config` e cadastrar a chave "openai" no painel (Integrações). Qualquer falha cai no texto determinístico.

**Configuração:** pesos e limiares ficam em `evolui_eie_config` (versão ativa). Todo registro grava a versão usada. Não há tela de pesos no painel ainda.

**Privacidade (LGPD):** sinais e recomendações ficam em `evolui_eie_eventos` e `evolui_eie_recomendacoes` (só ids, nota e formato; nenhum texto de card). Cada pessoa lê e apaga os próprios; entram em "Baixar meus dados" e em "Apagar tudo". Quem desliga "personalizar" não tem histórico considerado.

**Limpeza automática (precisa ser aplicada pelo dono no SQL Editor):**
```sql
create or replace function public.evolui_eie_limpar() returns void language sql security definer set search_path = public as $$
  delete from public.evolui_eie_recomendacoes where criado_em < now() - interval '90 days';
  delete from public.evolui_eie_eventos where criado_em < now() - interval '365 days';
$$;
revoke all on function public.evolui_eie_limpar() from public, anon, authenticated;
select cron.schedule('evolui_eie_limpeza','40 4 * * *','select public.evolui_eie_limpar()');
```
Também é seguro apagar as políticas duplicadas criadas por engano (`eie_eventos_ler_proprio`, `eie_eventos_apagar_proprio`, `eie_recs_ler_proprio`, `eie_recs_apagar_proprio`); as originais (`*_proprio_le`/`*_proprio_apaga`) já cobrem o caso.

**Testes:** `cd supabase/functions/evolui-api && tsx eie/eie.test.ts` (44 testes: normalização, intenção, EvoluiScore, contexto, penalidades, novidade, duplicatas, diversidade, feedback, fallback, versionamento, fotógrafo/barbearia/loja de roupas, contexto ausente, local×online, Problemas A e B).

**Publicação:** a função publicada no Supabase é um único arquivo compactado gerado a partir destes fontes (limite de tamanho do envio). Para republicar, gere o pacote a partir de `index.ts` com um empacotador (ex.: `bun build index.ts --minify --target=node --format=esm --external 'jsr:*'`) ou use a CLI do Supabase (`supabase functions deploy evolui-api`).
