# EVI Video Intelligence v1 — 04/10/2026

## Objetivo

O **EVI (Evolui Video Intelligence)** é a camada de inteligência audiovisual da Evolui Social.

A meta desta versão não é criar outro "transcritor". A transcrição é uma infraestrutura local para que a Evolui possa extrair sinais próprios de conteúdo e conectá-los ao EIE/EKE, ao EvoluiScore e ao Laboratório.

```text
vídeo público
  ↓
EVI Video Worker
  ↓
yt-dlp + FFmpeg
  ↓
faster-whisper
  ↓
transcrição + timestamps
  ↓
OpenCV + PySceneDetect
  ↓
sinais audiovisuais observáveis
  ↓
EVI heurístico determinístico
  ↓
DNA + estrutura + retórica + ritmo
  ↓
lacunas + oportunidades
  ↓
EvoluiScore estrutural
  ↓
evolui-api → Laboratório
```

## O que foi produzido

### IMPLEMENTADO

- worker FastAPI independente em `evi-video-worker/`;
- aquisição de vídeos públicos de YouTube, TikTok e Instagram via `yt-dlp`;
- extração de áudio mono 16 kHz com FFmpeg;
- transcrição local com `faster-whisper==1.2.1`;
- timestamps de segmentos e palavras;
- detecção de cenas com PySceneDetect 0.7.1;
- sinais visuais observáveis com OpenCV: FPS, duração, brilho médio, movimento médio e presença de rosto por amostragem;
- identificação determinística de gancho, CTA, prova, problema, lista e solução quando há evidência textual;
- métricas de ritmo e fala;
- **EVI-DNA** com esqueleto estrutural do vídeo;
- **impressão digital estrutural** determinística para comparar arquiteturas sem comparar texto palavra a palavra;
- ajuste contextual observável por interseção lexical com ramo/objetivo/rede/formato;
- lacunas observadas e oportunidades de adaptação;
- EvoluiScore estrutural observável, explicitamente não preditivo de viralização;
- persistência opcional e protegida em `public.evolui_video_analises`;
- integração aditiva com `analisar_video_pro` em `evolui-api`;
- compatibilidade de fallback com `EVOLUI_VIDEO_ANALYZER_URL` legado;
- frontend do Laboratório com EVI-DNA, ritmo, score estrutural, impressão e transcrição expansível.

### PREPARADO

- expansão para WhisperX para alinhamento ainda mais preciso e diarização;
- diarização com pyannote;
- OCR de texto presente na tela;
- análise semântica de frames com modelo multimodal;
- comparação contra um corpus de vídeos previamente analisados;
- agregação de padrões por ramo/período;
- Opportunity Gap de mercado cruzando EVI com pesquisa externa;
- aprendizado de pesos com métricas reais de conteúdo, quando integrações de rede estiverem disponíveis.

### AINDA NÃO IMPLEMENTADO

- treinamento de um modelo proprietário de visão/áudio da Evolui;
- previsão de alcance ou viralização;
- benchmark estatístico de desempenho do score contra métricas de redes;
- OCR;
- diarização;
- entendimento multimodal semântico profundo de frames;
- fila assíncrona de jobs para vídeos longos;
- cache distribuído do modelo entre hosts.

## Segredos e autenticação

A v1 **não exige API key de um fornecedor de transcrição**.

O único segredo específico do worker é opcional e interno:

```text
EVI_WORKER_TOKEN
```

Ele protege o endpoint `/analyze` quando o worker estiver exposto na internet.

No Supabase Edge Function `evolui-api`, configure:

```text
EVI_VIDEO_WORKER_URL=https://SEU-WORKER/analyze
EVI_VIDEO_WORKER_TOKEN=SEU_SEGREDO_INTERNO
```

Não coloque esse segredo no frontend.

O segredo antigo abaixo continua apenas para compatibilidade do analisador legado:

```text
EVOLUI_VIDEO_ANALYZER_URL
EVOLUI_VIDEO_ANALYZER_TOKEN
```

Com `EVI_VIDEO_WORKER_URL` presente, o EVI tem prioridade.

## Banco

Execute:

```text
SQL_EVI_VIDEO_INTELLIGENCE_04_10_2026.sql
```

A migração é aditiva e cria `public.evolui_video_analises`. Ela não armazena o arquivo de vídeo, apenas a representação estruturada necessária para memória e auditoria.

## Execução local do worker

```bash
cd evi-video-worker
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt

# configure .env a partir de .env.example
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

Ou com Docker:

```bash
cd evi-video-worker
docker build -t evolui-evi-video:v1 .
docker run --rm -p 8080:8080 --env-file .env evolui-evi-video:v1
```

Healthcheck:

```text
GET /health
```

Análise:

```text
POST /analyze
```

## Configuração de modelo

Padrão:

```text
EVI_WHISPER_MODEL=large-v3-turbo
EVI_WHISPER_DEVICE=cpu
EVI_WHISPER_COMPUTE=int8
```

Em host com GPU compatível, o modelo pode ser executado em GPU alterando as variáveis de dispositivo/compute.

O modelo é carregado de forma lazy e permanece em cache no processo do worker.

## Limites de proteção da v1

```text
EVI_MAX_VIDEO_MB=150
EVI_MAX_DURATION_SEC=180
EVI_DOWNLOAD_TIMEOUT_SEC=60
EVI_FFMPEG_TIMEOUT_SEC=90
```

A restrição de duração evita que uma chamada do produto seja convertida em um job arbitrariamente longo. O próximo passo recomendado para conteúdo longo é transformar a execução em job assíncrono.

## Dependências open source

| Componente | Versão fixada/esperada | Finalidade | Licença | Papel |
|---|---:|---|---|---|
| faster-whisper | 1.2.1 | ASR/transcrição local | MIT | infraestrutura de fala |
| PySceneDetect | 0.7.1 | detecção de cortes/cenas | BSD-3-Clause | infraestrutura visual |
| yt-dlp | 2026.08.19 | aquisição de vídeos públicos | Unlicense (com observações de terceiros) | aquisição |
| FFmpeg | imagem do sistema | extração de áudio/processamento | depende da build | infraestrutura multimídia |
| OpenCV | série 4.x | amostragem e sinais visuais observáveis | Apache-2.0 | infraestrutura visual |
| FastAPI | série 0.x | API do worker | MIT | serviço |

A lógica de decisão e representação EVI não é terceirizada para essas bibliotecas.

## Princípio de propriedade intelectual

```text
OPEN SOURCE
   ↓
SENSORES / INFRAESTRUTURA

EVI
   ↓
REPRESENTAÇÃO DOS SINAIS
+ DNA
+ ESTRUTURA
+ LACUNAS
+ OPORTUNIDADES
+ SCORE ESTRUTURAL
+ CONTEXTO

EIE/EKE
   ↓
RELEVÂNCIA
+ PESQUISA
+ RANKING
+ APRENDIZADO
```

O fato de a Evolui usar componentes abertos não transforma esses componentes no algoritmo proprietário da Evolui.

## Compatibilidade com a arquitetura atual

A integração mantém:

- `analisar_video_pro` como contrato de entrada;
- `video.ts` como normalizador compatível;
- o analisador legado como fallback;
- EIE/EKE e demais fontes da Evolui;
- Supabase como banco/autorização;
- frontend atual do Laboratório.

Nada foi removido para introduzir o EVI.
