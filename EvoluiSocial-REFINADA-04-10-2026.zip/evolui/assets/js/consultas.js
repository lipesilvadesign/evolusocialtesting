/**
 * /consultas — Consultoria Gratuita de Perfil para Instagram (ETAPA 1-4).
 *
 * Reaproveita padrões já existentes no projeto (não recria nada do zero):
 *  - Tema claro/escuro: mesma chave localStorage "fb_theme" de assets/js/site.bdacb7b1a8.js.
 *  - Leitura de site_content (WhatsApp/Instagram/e-mail de contato): mesmo
 *    fetch direto ao Supabase REST com a chave anônima pública, igual
 *    FBContent.loadContent() em site.bdacb7b1a8.js.
 *  - Link do WhatsApp e modal de agendamento (Google Agenda/e-mail): mesma
 *    lógica de site.bdacb7b1a8.js, replicada aqui porque esta é uma página
 *    HTML separada (o projeto não tem bundler/módulos compartilhados entre
 *    páginas — README de cada Function documenta a mesma tolerância a essa
 *    duplicação, ex: SUPABASE_URL/KEY repetidos em vários arquivos).
 */
(function () {
  'use strict';

  var SUPABASE_URL = 'https://aligftypgtzlymmditeo.supabase.co';
  var SUPABASE_ANON_KEY = 'sb_publishable_lLKYguXwi6isaw1C4X5uiA_25-MT7ym';
  var FALLBACK_WHATSAPP_DIGITS = '5587981798483';

  var $ = function (id) { return document.getElementById(id); };
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function track(evento, params) {
    try {
      if (typeof gtag === 'function') gtag('event', evento, params || {});
    } catch (e) { /* nunca deixa telemetria quebrar a experiência */ }
  }

  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // -------------------- Tema claro/escuro (mesmo padrão da home) --------------------
  (function initTheme() {
    var root = document.documentElement;
    try {
      var saved = localStorage.getItem('fb_theme');
      if (saved) root.setAttribute('data-theme', saved);
    } catch (e) {}
    var toggle = $('themeToggle');
    if (toggle) {
      toggle.addEventListener('click', function () {
        var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        root.setAttribute('data-theme', next);
        try { localStorage.setItem('fb_theme', next); } catch (e) {}
      });
    }
  })();

  // -------------------- Segmentos e objetivos (mesmas chaves do motor server-side) --------------------
  var SEGMENTOS = {
    moda_vestuario: 'Moda e vestuário',
    beleza_estetica: 'Beleza e estética',
    saude_bem_estar: 'Saúde e bem-estar',
    fitness: 'Fitness e esporte',
    alimentacao: 'Alimentação e gastronomia',
    imoveis: 'Imóveis',
    educacao_cursos: 'Educação e cursos',
    servicos_profissionais: 'Serviços profissionais e consultoria',
    direito_contabilidade: 'Direito, contabilidade e finanças',
    construcao_arquitetura: 'Construção, arquitetura e engenharia',
    varejo_ecommerce: 'Varejo e e-commerce',
    pet: 'Pet',
    tecnologia: 'Tecnologia e software',
    artesanato_criativo: 'Artesanato e criativo',
    eventos: 'Eventos e festas',
    outro: 'Outro',
  };
  var OBJETIVOS = [
    { chave: 'crescer_seguidores', label: 'Crescer o número de seguidores' },
    { chave: 'gerar_vendas', label: 'Gerar vendas diretas pelo Instagram' },
    { chave: 'atrair_clientes_locais', label: 'Atrair clientes da minha região' },
    { chave: 'fortalecer_autoridade', label: 'Fortalecer autoridade e profissionalismo' },
    { chave: 'organizar_identidade', label: 'Organizar a identidade visual do perfil' },
    { chave: 'converter_contatos', label: 'Converter seguidores em contatos (WhatsApp/e-mail)' },
    { chave: 'outro', label: 'Outro objetivo' },
  ];

  (function popularSelects() {
    var select = $('segmento');
    Object.keys(SEGMENTOS).forEach(function (chave) {
      var opt = document.createElement('option');
      opt.value = chave;
      opt.textContent = SEGMENTOS[chave];
      select.appendChild(opt);
    });

    var list = $('objetivoList');
    OBJETIVOS.forEach(function (obj) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'choice-card';
      btn.setAttribute('role', 'radio');
      btn.setAttribute('aria-checked', 'false');
      btn.dataset.value = obj.chave;
      btn.innerHTML = '<span>' + escapeHtml(obj.label) + '</span><span class="check-dot" aria-hidden="true"><svg viewBox="0 0 24 24"><use href="#ic-check"/></svg></span>';
      btn.addEventListener('click', function () {
        list.querySelectorAll('.choice-card').forEach(function (el) {
          el.classList.remove('is-selected');
          el.setAttribute('aria-checked', 'false');
        });
        btn.classList.add('is-selected');
        btn.setAttribute('aria-checked', 'true');
        state.objetivo = obj.chave;
        $('objetivoError').classList.remove('is-visible');
      });
      list.appendChild(btn);
    });
  })();

  // -------------------- Contato dinâmico (mesma fonte do site principal) --------------------
  var contact = { whatsapp: FALLBACK_WHATSAPP_DIGITS, instagram: '', email: '' };
  fetch(SUPABASE_URL + '/rest/v1/site_content?select=content&id=eq.1', {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: 'Bearer ' + SUPABASE_ANON_KEY },
  })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (rows) {
      var c = rows && rows[0] && rows[0].content && rows[0].content.contact;
      if (c) {
        contact.whatsapp = (c.whatsapp || FALLBACK_WHATSAPP_DIGITS).replace(/\D/g, '') || FALLBACK_WHATSAPP_DIGITS;
        contact.instagram = c.instagram || '';
        contact.email = c.email || '';
      }
    })
    .catch(function () { /* mantém os valores padrão — nunca bloqueia a página por isso */ });

  function waUrl(digits, text) {
    return 'https://wa.me/' + digits + (text ? '?text=' + encodeURIComponent(text) : '');
  }

  // Só usados pro contato em texto puro que aparece no PDF salvo (ver
  // .print-contato em consultas.html/css) — não tem link pra clicar no
  // papel, então o número e o @ precisam estar legíveis de olho.
  function formatarWhatsapp(digitsBrutos) {
    var d = String(digitsBrutos || '').replace(/\D/g, '');
    if (d.length > 11 && d.slice(0, 2) === '55') d = d.slice(2); // tira o 55 do Brasil
    if (d.length === 11) return '(' + d.slice(0, 2) + ') ' + d.slice(2, 7) + '-' + d.slice(7);
    if (d.length === 10) return '(' + d.slice(0, 2) + ') ' + d.slice(2, 6) + '-' + d.slice(6);
    return d;
  }
  function instagramHandle(url) {
    var m = /instagram\.com\/([^/?#]+)/i.exec(url || '');
    return m ? '@' + m[1] : url;
  }

  // -------------------- Estado e wizard --------------------
  var TOTAL_STEPS = 7; // etapas 1..7 (etapa 0 é a apresentação, fora da contagem)
  var state = { step: 0, nome: '', instagram: '', whatsapp: '', email: '', segmento: '', objetivo: '', origem: 'consultas_site' };

  (function initOrigem() {
    try {
      var qs = new URLSearchParams(window.location.search).get('origem');
      if (qs) state.origem = qs.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 60) || 'consultas_site';
    } catch (e) {}
  })();

  var wizard = $('wizard');
  var steps = Array.prototype.slice.call(wizard.querySelectorAll('.wizard-step'));
  var wizardNav = $('wizardNav');
  var progressFill = $('wizardProgressFill');
  var progressText = $('wizardProgressText');
  var progressWrap = $('wizardProgress');

  function fieldEl(name) { return $('field-' + name); }
  function setError(name, show) {
    var f = fieldEl(name);
    if (f) f.classList.toggle('has-error', !!show);
  }

  function validateStep(n) {
    if (n === 1) {
      var raw = $('instagram').value.trim().replace(/^@/, '');
      var ok = /^[a-zA-Z0-9._]{1,30}$/.test(raw);
      setError('instagram', !ok);
      if (ok) state.instagram = raw;
      return ok;
    }
    if (n === 2) {
      var nome = $('nome').value.trim();
      var ok2 = nome.length >= 2 && nome.length <= 120;
      setError('nome', !ok2);
      if (ok2) state.nome = nome;
      return ok2;
    }
    if (n === 3) {
      var digits = $('whatsapp').value.replace(/\D/g, '');
      var ok3 = digits.length >= 10 && digits.length <= 13;
      setError('whatsapp', !ok3);
      if (ok3) state.whatsapp = digits;
      return ok3;
    }
    if (n === 4) {
      var email = $('email').value.trim();
      var ok4 = !email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      setError('email', !ok4);
      if (ok4) state.email = email;
      return ok4;
    }
    if (n === 5) {
      var segmento = $('segmento').value;
      var ok5 = Object.prototype.hasOwnProperty.call(SEGMENTOS, segmento);
      setError('segmento', !ok5);
      if (ok5) state.segmento = segmento;
      return ok5;
    }
    if (n === 6) {
      var ok6 = !!state.objetivo;
      $('objetivoError').classList.toggle('is-visible', !ok6);
      return ok6;
    }
    return true;
  }

  function renderReview() {
    var objetivoLabel = (OBJETIVOS.filter(function (o) { return o.chave === state.objetivo; })[0] || {}).label || '';
    var rows = [
      ['Instagram', '@' + state.instagram],
      ['Nome', state.nome],
      ['WhatsApp', state.whatsapp],
      ['E-mail', state.email || '—'],
      ['Segmento', SEGMENTOS[state.segmento] || '—'],
      ['Objetivo', objetivoLabel],
    ];
    var card = $('reviewCard');
    card.innerHTML = '';
    rows.forEach(function (r) {
      var row = document.createElement('div');
      row.className = 'review-row';
      var label = document.createElement('span'); label.className = 'label'; label.textContent = r[0];
      var value = document.createElement('span'); value.className = 'value'; value.textContent = r[1];
      row.appendChild(label); row.appendChild(value);
      card.appendChild(row);
    });
  }

  function goToStep(n) {
    state.step = n;
    steps.forEach(function (el) {
      el.classList.toggle('is-active', Number(el.dataset.step) === n);
    });
    wizardNav.hidden = (n === 0 || n === 7);
    if (n >= 1 && n <= TOTAL_STEPS) {
      progressWrap.hidden = false;
      progressFill.style.width = Math.round((n / TOTAL_STEPS) * 100) + '%';
      progressText.textContent = 'Etapa ' + n + ' de ' + TOTAL_STEPS;
    } else {
      progressWrap.hidden = true;
    }
    if (n === 7) renderReview();
    // 30/09: com o formulário em andamento, o hero e os textos informativos
    // saem de cena (a etapa atual fica no topo da tela).
    document.body.classList.toggle('is-consulta-iniciada', n > 0);
    track('consulta_etapa', { etapa: n });
    var heading = steps[n] && steps[n].querySelector('h1, h2');
    if (heading && !reduceMotion) heading.setAttribute('tabindex', '-1');
    window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
  }

  $('wizardForward').addEventListener('click', function () {
    if (!validateStep(state.step)) return;
    goToStep(Math.min(state.step + 1, TOTAL_STEPS));
  });
  $('wizardBack').addEventListener('click', function () {
    goToStep(Math.max(state.step - 1, 0));
  });
  wizard.querySelectorAll('[data-next]').forEach(function (btn) {
    if (btn.id === 'wizardForward') return;
    btn.addEventListener('click', function () {
      if (!validateStep(state.step)) return;
      goToStep(Math.min(state.step + 1, TOTAL_STEPS));
    });
  });
  // 30/09: botões "Solicitar consultoria gratuita" (hero e fim da página)
  // abrem direto a etapa 1 — o antigo passo 0 virou o hero.
  function iniciarConsulta(e) {
    if (e) e.preventDefault();
    showOnly('wizard');
    goToStep(1);
    track('consulta_iniciada', { origem_botao: e && e.currentTarget ? e.currentTarget.id || 'cta' : 'cta' });
    setTimeout(function () {
      var campo = steps[1] && steps[1].querySelector('input, select, textarea');
      if (campo) campo.focus({ preventScroll: true });
    }, reduceMotion ? 0 : 350);
  }
  var heroCta = $('csHeroCta');
  if (heroCta) heroCta.addEventListener('click', iniciarConsulta);
  document.querySelectorAll('[data-start-consulta]').forEach(function (el) {
    el.addEventListener('click', iniciarConsulta);
  });

  // Enter avança a etapa atual em vez de tentar submeter o form direto.
  wizard.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && state.step < 7) {
      e.preventDefault();
      if (!validateStep(state.step)) return;
      goToStep(Math.min(state.step + 1, TOTAL_STEPS));
    }
  });

  // -------------------- Envio --------------------
  var wizardState = null; // { leadId, resultado } após sucesso

  function showOnly(id) {
    var telas = { wizard: wizard, loadingState: $('loadingState'), errorState: $('errorState'), resultState: $('resultState') };
    Object.keys(telas).forEach(function (key) { telas[key].hidden = key !== id; });
    progressWrap.hidden = id !== 'wizard' || state.step === 0;
  }

  // 30/09: trava contra envio duplicado (duplo clique em "Tentar novamente"
  // ou Enter repetido criava dois leads iguais).
  var enviando = false;

  function enviarConsulta() {
    if (enviando) return;
    enviando = true;
    showOnly('loadingState');
    track('consulta_submit', { segmento: state.segmento, objetivo: state.objetivo });

    var payload = {
      nome: state.nome,
      instagram: state.instagram,
      whatsapp: state.whatsapp,
      email: state.email,
      segmento: state.segmento,
      objetivo: state.objetivo,
      origem: state.origem,
      website: $('website').value, // honeypot — vazio para humanos
    };

    fetch('/.netlify/functions/consultas-criar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
      .then(function (res) {
        // Resposta que não é JSON (ex.: página de erro do provedor) não pode
        // virar "Unexpected token <" na tela do visitante.
        return res.json()
          .catch(function () { return {}; })
          .then(function (data) { return { ok: res.ok, status: res.status, data: data }; });
      })
      .then(function (r) {
        if (!r.ok) {
          var msg = (r.data && r.data.error) ||
            (r.status === 429 ? 'Muitas tentativas em pouco tempo. Aguarde alguns minutos e tente de novo.' : 'Não foi possível gerar o diagnóstico agora.');
          var erro = new Error(msg);
          erro.amigavel = true;
          throw erro;
        }
        wizardState = { leadId: r.data.leadId, resultado: r.data.resultado };
        renderResultado(r.data.resultado);
        showOnly('resultState');
        track('consulta_resultado_visualizado', { lead_id: r.data.leadId });
      })
      .catch(function (err) {
        // Falha de rede ("Failed to fetch", em inglês) vira uma mensagem clara.
        $('errorMessage').textContent = err && err.amigavel && err.message
          ? err.message
          : 'Não conseguimos falar com o servidor. Verifique sua conexão e tente novamente.';
        $('errorWhatsapp').href = waUrl(contact.whatsapp, 'Olá! Tentei fazer a consultoria gratuita de perfil no site, mas deu um erro. Pode me ajudar?');
        showOnly('errorState');
      })
      .then(function () { enviando = false; });
  }

  wizard.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!validateStep(6)) { goToStep(6); return; }
    enviarConsulta();
  });
  $('retryBtn').addEventListener('click', enviarConsulta);

  // -------------------- Renderização do resultado --------------------
  var AVALIACAO_LABEL = { atencao: 'Ponto de atenção', base: 'Base a confirmar', oportunidade: 'Oportunidade clara' };

  // Efeito "decodificando" nos selos de avaliação (diag-badge): já são
  // maiúsculos e em fonte monoespaçada, então o texto embaralhando por uma
  // fração de segundo antes de assentar no valor final lembra um terminal
  // "decifrando" o resultado, sem precisar de nenhuma biblioteca externa.
  var SCRAMBLE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  function scrambleTexto(el, textoFinal, atraso) {
    if (reduceMotion) { el.textContent = textoFinal; return; }
    var PASSOS = 14;
    var DURACAO = 420; // ms, do primeiro ao último quadro
    var passo = 0;
    el.textContent = '';
    setTimeout(function () {
      var intervalo = setInterval(function () {
        passo++;
        var revelados = Math.floor((passo / PASSOS) * textoFinal.length);
        var texto = '';
        for (var c = 0; c < textoFinal.length; c++) {
          texto += (c < revelados || textoFinal.charAt(c) === ' ')
            ? textoFinal.charAt(c)
            : SCRAMBLE_CHARS.charAt(Math.floor(Math.random() * SCRAMBLE_CHARS.length));
        }
        el.textContent = texto;
        if (passo >= PASSOS) {
          clearInterval(intervalo);
          el.textContent = textoFinal;
        }
      }, DURACAO / PASSOS);
    }, atraso || 0);
  }

  function preencherLista(id, itens) {
    var ul = $(id);
    ul.innerHTML = '';
    (itens || []).forEach(function (texto) {
      var li = document.createElement('li');
      li.textContent = texto;
      ul.appendChild(li);
    });
  }

  // Entrada "imersiva" do @handle: cada letra some/entra em sequência quando
  // .result-head ganha .is-visible (observer global, já existente, no fim
  // deste arquivo) — nada de biblioteca nova, só CSS pausado/retomado.
  function renderHandleImersivo(texto) {
    var h1 = $('resultHandle');
    h1.innerHTML = '';
    h1.setAttribute('aria-label', texto);
    texto.split('').forEach(function (ch, i) {
      var span = document.createElement('span');
      span.className = 'reveal-char';
      span.setAttribute('aria-hidden', 'true');
      span.style.animationDelay = (i * 0.028) + 's';
      span.textContent = ch === ' ' ? ' ' : ch;
      h1.appendChild(span);
    });
  }

  // Carrossel de dicas práticas (conteúdo premium) — um card por categoria,
  // navegação por toque (scroll-snap nativo), setas e bolinhas.
  function renderDicasCarrossel(categorias) {
    // "trilho" (não "track") de propósito: a função global track() de
    // telemetria já usa esse nome — uma variável local chamada "track" aqui
    // dentro esconderia a função e quebraria qualquer chamada track(...)
    // neste escopo (foi exatamente isso que aconteceu e foi corrigido).
    var trilho = $('dicasTrack');
    var dotsWrap = $('dicasDots');
    trilho.innerHTML = '';
    dotsWrap.innerHTML = '';
    var cards = [];

    (categorias || []).forEach(function (cat, idx) {
      if (!cat.dicasPraticas || !cat.dicasPraticas.length) return;

      var card = document.createElement('article');
      card.className = 'dica-card';

      var head = document.createElement('div');
      head.className = 'dica-card__head';
      var num = document.createElement('span');
      num.className = 'dica-card__num';
      var badge = document.createElement('span');
      badge.className = 'diag-badge diag-badge--' + cat.avaliacao;
      scrambleTexto(badge, cat.avaliacaoLabel || AVALIACAO_LABEL[cat.avaliacao] || '', idx * 90);
      head.appendChild(num);
      head.appendChild(badge);

      var h3 = document.createElement('h3');
      h3.textContent = cat.titulo;

      var ul = document.createElement('ul');
      ul.className = 'dica-card__lista';
      cat.dicasPraticas.forEach(function (texto) {
        var li = document.createElement('li');
        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('aria-hidden', 'true');
        var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
        use.setAttribute('href', '#ic-check');
        svg.appendChild(use);
        var span = document.createElement('span');
        span.textContent = texto;
        li.appendChild(svg);
        li.appendChild(span);
        ul.appendChild(li);
      });

      card.appendChild(head);
      card.appendChild(h3);
      card.appendChild(ul);
      trilho.appendChild(card);
      cards.push(card);

      var dot = document.createElement('button');
      dot.type = 'button';
      dot.className = 'dicas-dot';
      dotsWrap.appendChild(dot);
    });

    // Convite sutil pra arrastar — só no primeiro card, uma vez, se tiver
    // mais de 1 card e a pessoa não pediu redução de movimento.
    if (cards.length > 1 && !reduceMotion) {
      cards[0].classList.add('dica-card--hint');
    }

    // Card de conclusão: fecha a sequência de dicas emendando com a ideia de
    // agir agora — é o "final feliz" que leva pro cartão verificado + CTA
    // logo abaixo na página, no momento em que a pessoa mais está engajada.
    if (cards.length) {
      var finalCard = document.createElement('article');
      finalCard.className = 'dica-card dica-card--final';

      var finalIcon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      finalIcon.setAttribute('class', 'dica-card-final-icon');
      finalIcon.setAttribute('viewBox', '0 0 100 100');
      finalIcon.setAttribute('aria-hidden', 'true');
      var finalUse = document.createElementNS('http://www.w3.org/2000/svg', 'use');
      finalUse.setAttribute('href', '#ic-star4');
      finalIcon.appendChild(finalUse);

      var finalH3 = document.createElement('h3');
      finalH3.textContent = 'Você viu todas as dicas';
      var finalP = document.createElement('p');
      finalP.textContent = 'Agora é só colocar em prática. Ou, se quiser um empurrão, a gente conversa e eu te ajudo a aplicar isso direto no seu perfil.';
      var finalBtn = document.createElement('button');
      finalBtn.type = 'button';
      finalBtn.className = 'btn btn-primary';
      finalBtn.textContent = 'Ver como falar comigo';
      finalBtn.addEventListener('click', function () {
        track('dicas_final_cta_click', {});
        var alvo = $('ctaWhatsapp');
        if (alvo && alvo.scrollIntoView) alvo.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
      });

      finalCard.appendChild(finalIcon);
      finalCard.appendChild(finalH3);
      finalCard.appendChild(finalP);
      finalCard.appendChild(finalBtn);
      trilho.appendChild(finalCard);
      cards.push(finalCard);

      var finalDot = document.createElement('button');
      finalDot.type = 'button';
      finalDot.className = 'dicas-dot dicas-dot--final';
      finalDot.setAttribute('aria-label', 'Ir para o card final');
      dotsWrap.appendChild(finalDot);
    }

    cards.forEach(function (card, i) {
      var numEl = card.querySelector('.dica-card__num');
      if (numEl) numEl.textContent = (i + 1) + '/' + cards.length;
      dotsWrap.children[i].setAttribute('aria-label', 'Ir para o card ' + (i + 1) + ' de ' + cards.length);
    });

    function marcarAtivo(i) {
      Array.prototype.forEach.call(dotsWrap.children, function (d, di) {
        d.classList.toggle('is-active', di === i);
      });
      cards.forEach(function (card, di) {
        // toggle(true) num card que já tem a classe não reinicia a animação —
        // só "pulsa" de novo quando a pessoa REALMENTE volta pro card final.
        card.classList.toggle('is-active-card', di === i);
      });
    }

    function indiceAtivo() {
      var ativo = dotsWrap.querySelector('.dicas-dot.is-active');
      return ativo ? Array.prototype.indexOf.call(dotsWrap.children, ativo) : 0;
    }

    function irParaCard(i) {
      var card = cards[i];
      if (!card) return;
      trilho.scrollTo({ left: card.offsetLeft - trilho.offsetLeft, behavior: reduceMotion ? 'auto' : 'smooth' });
    }

    if (cards.length) marcarAtivo(0);
    trilho.scrollLeft = 0;

    var scrollTimer;
    trilho.onscroll = function () {
      clearTimeout(scrollTimer);
      scrollTimer = setTimeout(function () {
        var centro = trilho.scrollLeft + trilho.clientWidth / 2;
        var atual = 0; var menorDist = Infinity;
        cards.forEach(function (card, i) {
          var meio = card.offsetLeft - trilho.offsetLeft + card.offsetWidth / 2;
          var dist = Math.abs(centro - meio);
          if (dist < menorDist) { menorDist = dist; atual = i; }
        });
        marcarAtivo(atual);
      }, 100);
    };

    dotsWrap.onclick = function (e) {
      var btn = e.target.closest ? e.target.closest('.dicas-dot') : null;
      if (!btn) return;
      irParaCard(Array.prototype.indexOf.call(dotsWrap.children, btn));
    };
    $('dicasPrev').onclick = function () { irParaCard(Math.max(0, indiceAtivo() - 1)); };
    $('dicasNext').onclick = function () { irParaCard(Math.min(cards.length - 1, indiceAtivo() + 1)); };
  }

  function renderResultado(resultado) {
    renderHandleImersivo('@' + state.instagram);
    $('resultResumo').textContent = resultado.resumo;
    $('diagCtaTexto').textContent = resultado.ctaTexto || 'Esse diagnóstico foi só o ponto de partida. Numa conversa, a gente transforma isso em um plano de ação pro seu Instagram.';

    var wrap = $('diagCategorias');
    wrap.innerHTML = '';
    (resultado.categorias || []).forEach(function (cat, idx) {
      var card = document.createElement('div');
      card.className = 'diag-category';
      var head = document.createElement('div');
      head.className = 'diag-category-head';
      var h3 = document.createElement('h3'); h3.textContent = cat.titulo;
      var badge = document.createElement('span');
      badge.className = 'diag-badge diag-badge--' + cat.avaliacao;
      scrambleTexto(badge, cat.avaliacaoLabel || AVALIACAO_LABEL[cat.avaliacao] || '', idx * 90);
      head.appendChild(h3); head.appendChild(badge);
      var p = document.createElement('p'); p.textContent = cat.texto;
      card.appendChild(head); card.appendChild(p);
      wrap.appendChild(card);
    });

    renderDicasCarrossel(resultado.categorias);

    preencherLista('listPontosFortes', resultado.pontosFortes);
    preencherLista('listPontosAtencao', resultado.pontosDeAtencao);
    preencherLista('listOportunidades', resultado.oportunidades);
    preencherLista('listProximasAcoes', resultado.proximasAcoes);

    var msgWa = 'Olá! Acabei de fazer a consultoria gratuita de perfil do Instagram (@' + state.instagram + ') no site da Felipe Branding e quero entender melhor o diagnóstico.';
    $('ctaWhatsapp').href = waUrl(contact.whatsapp, msgWa);

    if (contact.instagram) {
      $('ctaInstagram').href = contact.instagram;
    } else {
      $('ctaInstagram').href = 'https://instagram.com/';
    }

    $('modalWa').href = waUrl(contact.whatsapp, 'Olá! Fiz a consultoria gratuita de perfil (@' + state.instagram + ') e quero agendar uma conversa.');
    $('modalEmail').href = 'mailto:' + (contact.email || 'contato@felipebranding.com.br') + '?subject=' + encodeURIComponent('Agendar conversa: consultoria de Instagram');

    // Contato em texto puro pro PDF salvo (ver .print-contato) — só aparece
    // na impressão, no lugar dos botões que não fazem sentido no papel.
    $('printWhatsapp').textContent = 'WhatsApp: ' + formatarWhatsapp(contact.whatsapp || FALLBACK_WHATSAPP_DIGITS);
    if (contact.instagram) {
      $('printInstagram').textContent = 'Instagram: ' + instagramHandle(contact.instagram);
      $('printInstagram').hidden = false;
    } else {
      $('printInstagram').hidden = true;
    }
    $('printEmail').textContent = 'E-mail: ' + (contact.email || 'contato@felipebranding.com.br');
  }

  // -------------------- CTAs: telemetria fire-and-forget --------------------
  function registrarEvento(evento) {
    if (!wizardState || !wizardState.leadId) return;
    try {
      fetch('/.netlify/functions/consultas-evento', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leadId: wizardState.leadId, evento: evento }),
        keepalive: true,
      });
    } catch (e) {}
  }

  $('btnSalvarPdf').addEventListener('click', function () {
    track('pdf_salvo', {});
    window.print();
  });

  $('ctaWhatsapp').addEventListener('click', function () {
    track('cta_whatsapp_click', {});
    registrarEvento('cta_whatsapp');
  });
  $('ctaInstagram').addEventListener('click', function () {
    track('cta_instagram_click', {});
    registrarEvento('cta_instagram');
  });

  // -------------------- Modal de agendamento (mesmo sistema da home) --------------------
  var scheduleModal = $('scheduleModal');
  function closeModal() {
    scheduleModal.classList.remove('is-open');
    document.body.style.overflow = '';
  }
  $('ctaAgendar').addEventListener('click', function () {
    track('cta_agendamento_click', {});
    registrarEvento('cta_agendamento');
    scheduleModal.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    var d1 = new Date(); d1.setDate(d1.getDate() + 7);
    var d2 = new Date(d1.getTime() + 30 * 60 * 1000);
    var fmt = function (d) { return d.toISOString().replace(/[-:]|\.\d{3}/g, '').slice(0, 15) + 'Z'; };
    $('gcalLink').href = 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=Conversa+sobre+consultoria+de+Instagram+-+Felipe+Branding&dates=' + fmt(d1) + '/' + fmt(d2) + '&details=Continuação+da+consultoria+gratuita+de+perfil+no+Instagram';
  });
  $('closeModal').addEventListener('click', closeModal);
  scheduleModal.addEventListener('click', function (e) { if (e.target === scheduleModal) closeModal(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

  // -------------------- Reveal (mesmo efeito da home, opcional) --------------------
  if ('IntersectionObserver' in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { entry.target.classList.add('is-visible'); io.unobserve(entry.target); }
      });
    }, { threshold: 0.1 });
    document.querySelectorAll('[data-reveal]').forEach(function (el) { io.observe(el); });
  } else {
    document.querySelectorAll('[data-reveal]').forEach(function (el) { el.classList.add('is-visible'); });
  }

  // -------------------- Réguas de alinhamento (ferramenta de revisão visual) --------------------
  // Não aparece pra visitante nenhum por padrão. Ative com a tecla "G" (fora de
  // um campo de texto) ou abrindo a página com ?guides=1 na URL — mostra a
  // linha central da tela, as bordas do container de conteúdo e uma régua
  // horizontal a cada 50px, pra apontar com precisão qualquer desalinhamento
  // em vez de "no olho". Pressione G de novo (ou recarregue) pra desligar.
  (function initReguasAlinhamento() {
    var host = null;
    function atualizar() {
      if (!host) return;
      host.innerHTML = '';
      host.style.height = document.documentElement.scrollHeight + 'px';

      var centro = document.createElement('div');
      centro.className = 'fb-guide fb-guide-center';
      host.appendChild(centro);

      var containerEl = document.querySelector('.consulta-container');
      if (containerEl) {
        // getBoundingClientRect() dá a caixa "de fora" do container — mas o
        // padding-inline é o que realmente define onde o CONTEÚDO começa e
        // termina visualmente. Sem descontar o padding, a régua ficava colada
        // na borda da tela, não na borda do texto/cards.
        var rect = containerEl.getBoundingClientRect();
        var csContainer = window.getComputedStyle(containerEl);
        var padLeft = parseFloat(csContainer.paddingLeft) || 0;
        var padRight = parseFloat(csContainer.paddingRight) || 0;
        var scrollX = window.pageXOffset;
        var bordaEsquerda = rect.left + padLeft + scrollX;
        var bordaDireita = rect.right - padRight + scrollX;
        [bordaEsquerda, bordaDireita].forEach(function (x) {
          var linha = document.createElement('div');
          linha.className = 'fb-guide fb-guide-edge';
          linha.style.left = x + 'px';
          host.appendChild(linha);
        });
      }

      var alturaTotal = document.documentElement.scrollHeight;
      for (var y = 0; y < alturaTotal; y += 50) {
        var major = y % 200 === 0;
        var tick = document.createElement('div');
        tick.className = 'fb-guide fb-guide-tick' + (major ? ' fb-guide-tick-major' : '');
        tick.style.top = y + 'px';
        if (major) tick.setAttribute('data-y', y + 'px');
        host.appendChild(tick);
      }

      var legenda = document.createElement('div');
      legenda.className = 'fb-guide-legenda';
      legenda.textContent = 'Réguas ativas — tecla G desliga · largura da tela ' + window.innerWidth + 'px';
      host.appendChild(legenda);
    }
    function ligar() {
      if (host) return;
      host = document.createElement('div');
      host.id = 'fbAlignGuides';
      host.setAttribute('aria-hidden', 'true');
      document.body.appendChild(host);
      atualizar();
      window.addEventListener('resize', atualizar);
      window.addEventListener('scroll', atualizar, { passive: true });
    }
    function desligar() {
      if (!host) return;
      window.removeEventListener('resize', atualizar);
      window.removeEventListener('scroll', atualizar);
      host.remove();
      host = null;
    }
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'g' && e.key !== 'G') return;
      var tag = (document.activeElement && document.activeElement.tagName) || '';
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (host) desligar(); else ligar();
    });
    try {
      if (/[?&]guides=1/.test(window.location.search)) ligar();
    } catch (e) {}
  })();

  // -------------------- Cabeçalho translúcido ao rolar (mesmo efeito da home) --------------------
  (function initHeaderScroll() {
    var header = $('siteHeader');
    if (!header) return;
    var ticking = false;
    function atualizar() {
      var y = window.scrollY || document.documentElement.scrollTop;
      header.classList.toggle('is-scrolled', y > 40);
      ticking = false;
    }
    atualizar();
    window.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(atualizar);
    }, { passive: true });
  })();

  // -------------------- Botões magnéticos (o botão "puxa" levemente pro cursor) --------------------
  (function initBotoesMagneticos() {
    if (reduceMotion) return;
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    var DESLOC_MAX = 10; // deslocamento máximo em px pra cada lado
    document.querySelectorAll('.btn-primary').forEach(function (btn) {
      btn.addEventListener('mousemove', function (e) {
        var rect = btn.getBoundingClientRect();
        var dx = ((e.clientX - rect.left) / rect.width - 0.5) * DESLOC_MAX * 2;
        var dy = ((e.clientY - rect.top) / rect.height - 0.5) * DESLOC_MAX * 2;
        btn.style.transform = 'translate(' + dx.toFixed(1) + 'px, ' + (dy - 3).toFixed(1) + 'px)';
      });
      btn.addEventListener('mouseleave', function () {
        btn.style.transform = '';
      });
    });
  })();

  // -------------------- Brilho no cursor (cards de categoria e dicas) --------------------
  // Delegado no document (em vez de um listener por card): os cards de
  // categoria e de dica são criados dinamicamente depois do diagnóstico, então
  // um listener fixado neles no carregamento da página não pegaria nada.
  (function initBrilhoCursor() {
    if (reduceMotion) return;
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    document.addEventListener('mousemove', function (e) {
      var card = e.target.closest && e.target.closest('.diag-category, .dica-card');
      if (!card) return;
      var rect = card.getBoundingClientRect();
      card.style.setProperty('--spot-x', (e.clientX - rect.left) + 'px');
      card.style.setProperty('--spot-y', (e.clientY - rect.top) + 'px');
    }, { passive: true });
  })();

  // -------------------- Hero: estrela da marca em movimento (30/09) --------------------
  // Só transform/opacity (GPU). O scroll e o mouse apenas atualizam variáveis
  // CSS dentro de um requestAnimationFrame, e só enquanto o hero está na tela
  // (IntersectionObserver). Com "reduzir movimento" nada disso roda.
  (function initHeroMotion() {
    var hero = $('csHero');
    var visual = $('csHeroVisual');
    if (!hero || !visual) return;
    hero.classList.add('is-ready');
    if (reduceMotion) return;

    var ticking = false;
    var visivel = true;
    var px = 0, py = 0;

    function aplicar() {
      ticking = false;
      var rect = hero.getBoundingClientRect();
      var progresso = Math.min(1, Math.max(0, -rect.top / Math.max(1, rect.height)));
      visual.style.setProperty('--scroll', progresso.toFixed(3));
      visual.style.setProperty('--px', px.toFixed(3));
      visual.style.setProperty('--py', py.toFixed(3));
    }
    function pedirQuadro() {
      if (!ticking && visivel) { ticking = true; requestAnimationFrame(aplicar); }
    }

    window.addEventListener('scroll', pedirQuadro, { passive: true });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entradas) {
        visivel = entradas[0].isIntersecting;
        if (visivel) pedirQuadro();
      }).observe(hero);
    }
    if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
      hero.addEventListener('pointermove', function (e) {
        var r = visual.getBoundingClientRect();
        px = Math.max(-1, Math.min(1, (e.clientX - (r.left + r.width / 2)) / (r.width / 2)));
        py = Math.max(-1, Math.min(1, (e.clientY - (r.top + r.height / 2)) / (r.height / 2)));
        pedirQuadro();
      }, { passive: true });
      hero.addEventListener('pointerleave', function () { px = 0; py = 0; pedirQuadro(); });
    }
    // O botão principal "acende" a estrela (a interface conversa com a marca).
    var cta = $('csHeroCta');
    if (cta) {
      ['mouseenter', 'focus'].forEach(function (ev) { cta.addEventListener(ev, function () { hero.classList.add('is-cta-ativo'); }); });
      ['mouseleave', 'blur'].forEach(function (ev) { cta.addEventListener(ev, function () { hero.classList.remove('is-cta-ativo'); }); });
    }
    pedirQuadro();
  })();

  goToStep(0);
})();
