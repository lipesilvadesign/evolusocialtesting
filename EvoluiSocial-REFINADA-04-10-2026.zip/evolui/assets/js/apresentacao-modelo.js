/**
 * MODELO EDITORIAL da apresentação pública — 01/10/2026.
 *
 *   SNAPSHOT publicado (admin_apresentacoes.conteudo, já filtrado pelo servidor)
 *        ↓  montarModelo()
 *   MODELO EDITORIAL (ordem, títulos, natureza de cada bloco)
 *        ├── WEB  (componentes HTML abaixo + apresentacao.js)
 *        └── PDF  (assets/js/apresentacao-pdf.js)
 *
 * Os dois saem do MESMO modelo: a composição visual muda, o conteúdo não.
 * Cada seção declara a NATUREZA do que mostra (dado ≠ análise):
 *   dado           — informação levantada/medida (com fonte quando houver)
 *   contexto       — informado pelo cliente
 *   interpretacao  — leitura do especialista sobre os dados
 *   recomendacao   — o que a Felipe Branding propõe
 *   plano          — próximos passos combinados
 * Nenhum número é criado aqui: métricas aparecem exatamente como publicadas.
 *
 * Uso: navegador → window.ApresentacaoModelo · Node (testes) → require().
 */
(function (raiz, fabrica) {
  const api = fabrica();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else raiz.ApresentacaoModelo = api;
}(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const NATUREZA = {
    dado: 'Dado',
    contexto: 'Contexto informado',
    interpretacao: 'Interpretação',
    recomendacao: 'Recomendação',
    plano: 'Plano',
  };

  const txt = (v) => (typeof v === 'string' ? v.trim() : typeof v === 'number' ? String(v) : '');
  const linhas = (v) => txt(v).split('\n').map((l) => l.trim()).filter(Boolean);
  const pares = (obj, mapa) => (obj && obj.incluir ? mapa.map(([k, rotulo]) => [rotulo, txt(obj[k])]).filter(([, v]) => v) : []);
  const HEX = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;

  function dataPorExtenso(v) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(v || ''));
    if (!m) return '';
    const meses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
    const mes = meses[Number(m[2]) - 1];
    return mes ? `${Number(m[3])} de ${mes} de ${m[1]}` : '';
  }

  /** @returns {{ capa: object, secoes: object[] }} */
  function montarModelo(conteudo) {
    const c = conteudo && typeof conteudo === 'object' ? conteudo : {};
    const capa = c.capa || {};
    const empresa = txt(capa.subtitulo);
    const secoes = [];

    const sobre = pares(c.sobreEmpresa, [['contexto', 'Contexto'], ['segmento', 'Segmento'], ['produtos', 'Produtos e serviços'], ['diferenciais', 'Diferenciais']]);
    if (sobre.length) secoes.push({ id: 'sobre', tipo: 'pares', natureza: 'contexto', eyebrow: 'Sobre a empresa', titulo: `Quem é ${empresa || 'a empresa'} hoje.`, tituloPdf: 'Sobre a empresa', itens: sobre });

    const presenca = pares(c.presencaAtual, [['instagram', 'Instagram'], ['site', 'Site'], ['identidade', 'Identidade'], ['comunicacao', 'Comunicação'], ['posicionamento', 'Posicionamento atual']]);
    if (presenca.length) secoes.push({ id: 'presenca', tipo: 'pares', natureza: 'dado', eyebrow: 'Presença atual', titulo: 'Como a marca aparece hoje.', tituloPdf: 'Presença atual', itens: presenca });

    const ids = new Set((Array.isArray(c.metricasIds) ? c.metricasIds : []).map(String));
    const metricas = (Array.isArray(c.metricasDisponiveis) ? c.metricasDisponiveis : [])
      .filter((m) => m && ids.has(String(m.id)))
      .map((m) => {
        const numerico = typeof m.valor === 'number' && Number.isFinite(m.valor);
        return { id: String(m.id), nome: txt(m.nome), numerico, valor: numerico ? m.valor : null, valorTexto: numerico ? '' : (txt(m.valor_texto) || '—'),
          unidade: txt(m.unidade), periodo: txt(m.periodo), origem: txt(m.origem) };
      });
    if (metricas.length) {
      // proporção só entre valores numéricos POSITIVOS publicados (cálculo, não dado novo)
      const maior = Math.max(1, ...metricas.map((m) => (m.numerico && m.valor > 0 ? m.valor : 0)));
      metricas.forEach((m) => { m.proporcao = m.numerico ? Math.max(0.04, Math.min(1, Math.max(0, m.valor) / maior)) : null; });
      secoes.push({ id: 'metricas', tipo: 'metricas', natureza: 'dado', eyebrow: 'Dados e métricas', titulo: 'O que os números mostram agora.', tituloPdf: 'Dados e métricas',
        nota: 'Barras comparam as métricas entre si (maior valor = barra cheia).', itens: metricas });
    }

    const interp = (Array.isArray(c.interpretacao) ? c.interpretacao : [])
      .map((r) => ({ dado: txt(r && r.dado), significado: txt(r && r.significado), impacto: txt(r && r.impacto) }))
      .filter((r) => r.dado || r.significado || r.impacto);
    if (interp.length) secoes.push({ id: 'interpretacao', tipo: 'interpretacao', natureza: 'interpretacao', eyebrow: 'Interpretação', titulo: 'Do dado ao que ele realmente significa.', tituloPdf: 'Interpretação', itens: interp });

    const ops = linhas(c.oportunidades);
    if (ops.length) secoes.push({ id: 'oportunidades', tipo: 'lista', natureza: 'recomendacao', eyebrow: 'Oportunidades', titulo: 'Onde está o maior potencial agora.', tituloPdf: 'Oportunidades', itens: ops });

    const estr = pares(c.direcaoEstrategica, [['posicionamento', 'Posicionamento'], ['percepcaoDesejada', 'Percepção desejada'], ['diferenciacao', 'Diferenciação'], ['comunicacao', 'Comunicação']]);
    if (estr.length) secoes.push({ id: 'estrategia', tipo: 'pares', natureza: 'recomendacao', eyebrow: 'Direção estratégica', titulo: 'Pra onde a marca vai.', tituloPdf: 'Direção estratégica', itens: estr });

    const dv = c.direcaoVisual;
    if (dv && dv.incluir) {
      const cores = txt(dv.cores).split(',').map((x) => x.trim()).filter(Boolean);
      const visual = { cores: cores.map((x) => ({ texto: x, hex: HEX.test(x) ? x : null })), tipografia: txt(dv.tipografia), referencias: txt(dv.referencias) };
      if (cores.length || visual.tipografia || visual.referencias) {
        secoes.push({ id: 'visual', tipo: 'visual', natureza: 'recomendacao', eyebrow: 'Direção visual', titulo: 'Como isso se traduz visualmente.', tituloPdf: 'Direção visual', itens: visual });
      }
    }

    // Plano: "Ação | Objetivo | Indicador" (opcional) — a ORDEM é a prioridade; nada de ranking melhor/pior
    const passos = linhas(c.proximosPassos).map((l, i) => {
      const [acao, objetivo, indicador] = l.split('|').map((x) => x.trim());
      return { prioridade: i + 1, acao: acao || l, objetivo: objetivo || '', indicador: indicador || '' };
    }).filter((x) => x.acao);
    if (passos.length) secoes.push({ id: 'passos', tipo: 'passos', natureza: 'plano', eyebrow: 'Próximos passos', titulo: 'O caminho a partir daqui.', tituloPdf: 'Próximos passos', itens: passos });

    return {
      capa: {
        eyebrow: 'Diagnóstico Estratégico da Marca', empresa, titulo: txt(capa.titulo), data: dataPorExtenso(capa.data),
        segmento: c.sobreEmpresa && typeof c.sobreEmpresa === 'object' ? txt(c.sobreEmpresa.segmento) : '',
        localizacao: txt(capa.localizacao),
      },
      secoes,
      rodape: 'Apresentação preparada pela Felipe Branding.',
    };
  }

  /** Todos os textos de CONTEÚDO do modelo (para conferir que web e PDF mostram o mesmo). */
  function textosDoModelo(modelo) {
    const out = [];
    const add = (t) => { if (t) out.push(String(t)); };
    add(modelo.capa.empresa); add(modelo.capa.titulo);
    for (const s of modelo.secoes) {
      if (s.tipo === 'pares') s.itens.forEach(([, v]) => add(v));
      else if (s.tipo === 'metricas') s.itens.forEach((m) => { add(m.nome); if (!m.numerico) add(m.valorTexto); });
      else if (s.tipo === 'interpretacao') s.itens.forEach((r) => { add(r.dado); add(r.significado); add(r.impacto); });
      else if (s.tipo === 'lista') s.itens.forEach(add);
      else if (s.tipo === 'passos') s.itens.forEach((x) => { add(x.acao); add(x.objetivo); add(x.indicador); });
      else if (s.tipo === 'visual') { s.itens.cores.forEach((x) => add(x.texto)); add(s.itens.tipografia); add(s.itens.referencias); }
    }
    return out;
  }

  // ------------------------------------------------------------------
  // Componentes WEB (strings HTML; todo texto passa por esc)
  // ------------------------------------------------------------------
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }
  const atraso = (i) => `ap-reveal-delay-${(i % 3) + 1}`;

  const componentes = {
    Hero(capa, logoHtml) {
      return `<header class="ap-capa">${logoHtml || ''}
        <span class="ap-capa-eyebrow">${esc(capa.eyebrow)}</span>
        <h1 class="ap-capa-titulo">${esc(capa.empresa)}</h1>
        ${capa.segmento || capa.localizacao ? `<p class="ap-capa-meta">${[capa.segmento, capa.localizacao].filter(Boolean).map(esc).join(' · ')}</p>` : ''}
        ${capa.titulo ? `<p class="ap-capa-subtitulo">${esc(capa.titulo)}</p>` : ''}
        ${capa.data ? `<span class="ap-capa-data">${esc(capa.data)}</span>` : ''}
        <div class="ap-capa-scrollcue" aria-hidden="true"></div></header>`;
    },
    SectionHeader(s) {
      return `<div class="ap-section-head"><span class="ap-eyebrow ap-reveal">${esc(s.eyebrow)}</span>
        <span class="ap-natureza ap-natureza-${esc(s.natureza)} ap-reveal" title="Natureza desta seção">${esc(NATUREZA[s.natureza] || '')}</span></div>
        <h2 class="ap-h2 ap-reveal" id="sec-${esc(s.id)}">${esc(s.titulo)}</h2>`;
    },
    StrategyBlock(itens) { // pares rótulo → texto
      return `<div class="ap-grid-2">${itens.map(([rotulo, v], i) => `
        <div class="ap-card ap-reveal ${atraso(i)}"><strong class="ap-rotulo">${esc(rotulo)}</strong><p>${esc(v)}</p></div>`).join('')}</div>`;
    },
    MetricCard(m, i) {
      return `<div class="ap-card ap-metric-card ap-reveal ${atraso(i)}">
        <div><span class="ap-metric-num" ${m.numerico ? `data-count-to="${esc(m.valor)}"` : ''}>${m.numerico ? '0' : esc(m.valorTexto)}</span>${m.unidade ? `<span class="ap-metric-unit">${esc(m.unidade)}</span>` : ''}</div>
        <div class="ap-metric-label">${esc(m.nome)}</div>
        ${m.numerico ? `<div class="ap-metric-bar-track" aria-hidden="true"><div class="ap-metric-bar-fill" data-bar-to="${Math.round(m.proporcao * 100)}"></div></div>` : ''}
        <div class="ap-metric-meta">${[m.periodo, m.origem ? `fonte: ${m.origem}` : ''].filter(Boolean).map(esc).join(' · ')}</div></div>`;
    },
    MetricGrid(s) {
      return `<div class="ap-grid-3">${s.itens.map((m, i) => componentes.MetricCard(m, i)).join('')}</div>${s.nota ? `<p class="ap-nota">${esc(s.nota)}</p>` : ''}`;
    },
    InsightBlock(itens) {
      return `<div class="ap-card">${itens.map((r, i) => `
        <div class="ap-interp-row ap-reveal ${atraso(i)}">
          <div><span class="ap-interp-col-label">Observação</span>${esc(r.dado)}</div><div class="ap-interp-arrow" aria-hidden="true">→</div>
          <div><span class="ap-interp-col-label">Interpretação</span>${esc(r.significado)}</div><div class="ap-interp-arrow" aria-hidden="true">→</div>
          <div><span class="ap-interp-col-label">Implicação</span>${esc(r.impacto)}</div></div>`).join('')}</div>`;
    },
    OpportunityList(itens) {
      return `<ol class="ap-card ap-lista">${itens.map((t, i) => `
        <li class="ap-oportunidade ap-reveal ${atraso(i)}"><span class="ap-oportunidade-num" aria-hidden="true">${String(i + 1).padStart(2, '0')}</span><p>${esc(t)}</p></li>`).join('')}</ol>`;
    },
    VisualDirection(v) {
      const sw = v.cores.filter((x) => x.hex);
      return `<div class="ap-card ap-reveal">
        ${v.cores.length ? `<strong class="ap-rotulo">Cores</strong>
          ${sw.length ? `<div class="ap-swatch-row">${sw.map((x) => `<span class="ap-swatch" style="background:${esc(x.hex)}" role="img" aria-label="Cor ${esc(x.hex)}"></span>`).join('')}</div>` : ''}
          <p>${v.cores.map((x) => esc(x.texto)).join(' · ')}</p>` : ''}
        ${v.tipografia ? `<p class="ap-bloco"><strong class="ap-rotulo">Tipografia</strong><br>${esc(v.tipografia)}</p>` : ''}
        ${v.referencias ? `<p class="ap-bloco"><strong class="ap-rotulo">Referências</strong><br>${esc(v.referencias)}</p>` : ''}</div>`;
    },
    NextSteps(itens) {
      return `<ol class="ap-card ap-lista">${itens.map((t, i) => `
        <li class="ap-passo ap-reveal ${atraso(i)}"><span class="ap-passo-marker" aria-hidden="true">${t.prioridade}</span>
          <div><p class="ap-passo-acao">${esc(t.acao)}</p>
          ${t.objetivo || t.indicador ? `<dl class="ap-passo-meta">${t.objetivo ? `<div><dt>Objetivo</dt><dd>${esc(t.objetivo)}</dd></div>` : ''}${t.indicador ? `<div><dt>Indicador</dt><dd>${esc(t.indicador)}</dd></div>` : ''}</dl>` : ''}</div></li>`).join('')}</ol>`;
    },
    Footer(texto) {
      return `<footer class="ap-footer"><img src="/assets/img/logo-icon-navy.png" alt="Felipe Branding" width="20" height="20"><p>${esc(texto)}</p></footer>`;
    },
  };

  function secaoHtml(s) {
    const corpo = s.tipo === 'pares' ? componentes.StrategyBlock(s.itens)
      : s.tipo === 'metricas' ? componentes.MetricGrid(s)
        : s.tipo === 'interpretacao' ? componentes.InsightBlock(s.itens)
          : s.tipo === 'lista' ? componentes.OpportunityList(s.itens)
            : s.tipo === 'visual' ? componentes.VisualDirection(s.itens)
              : s.tipo === 'passos' ? componentes.NextSteps(s.itens) : '';
    return `<section class="ap-section" aria-labelledby="sec-${esc(s.id)}">${componentes.SectionHeader(s)}${corpo}</section>`;
  }

  /** Página inteira (web) a partir do modelo. */
  function renderizarWeb(modelo, { logoHtml } = {}) {
    return componentes.Hero(modelo.capa, logoHtml) + '<main>' + modelo.secoes.map(secaoHtml).join('') + '</main>' + componentes.Footer(modelo.rodape);
  }

  return { montarModelo, textosDoModelo, renderizarWeb, componentes, NATUREZA, dataPorExtenso, esc };
}));
