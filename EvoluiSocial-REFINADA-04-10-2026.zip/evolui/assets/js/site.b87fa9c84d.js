/* ==========================================================================
   Felipe Branding — página inicial (index.html)
   --------------------------------------------------------------------------
   1) FBContent: conteúdo padrão + busca do conteúdo editado no painel
      (Supabase, tabela site_content). Também usado por partners-marquee.js.
   2) Interface da home: menu, tema, modal, portfólio, comparador,
      depoimentos, FAQ e formulário de contato.
   Código-fonte legível; o arquivo publicado leva um hash no nome
   (site.<hash>.js) para o cache de 1 ano do Netlify funcionar sem risco.
   ========================================================================== */
(function (window) {
  "use strict";

  var DEFAULT_CONTENT = {
    hero: {
      eyebrow: "Branding e marketing — Petrolina, PE · Vale do São Francisco",
      title: "Marcas que são percebidas antes de serem escolhidas.",
      lead: "A Felipe Branding cuida de posicionamento, identidade visual e comunicação de empresas de Petrolina, Juazeiro e do Vale do São Francisco. Marketing e conteúdo entram como ferramentas para gerar percepção e decisão.",
      ctaPrimary: "Conhecer a consultoria gratuita",
      ctaSecondary: "Conhecer a Felipe Branding",
      stat1Num: 10,
      stat1Label: "Anos no digital",
      stat2Num: 6,
      stat2Label: "Frentes de atuação",
      stat3Num: 100,
      stat3Label: "% direção estratégica",
      videoUrl: "",
    },
    founder: {
      eyebrow: "Fundador",
      title: "Quem está por trás da direção estratégica.",
      name: "Felipe Souto",
      role: "Fundador da Felipe Branding",
      bio: "Desde 2015 no digital, unindo design gráfico, produção audiovisual e gestão de redes sociais sob uma mesma direção estratégica. Cada projeto que assino carrega o mesmo compromisso: simplicidade, autenticidade e propósito.",
      photo: "",
      credentials:
        "10+ anos de atuação, base em Petrolina (PE) e atendimento em todo o Brasil",
    },
    about: {
      eyebrow: "Sobre a marca",
      title: "Uma marca nasceu para guiar, não para decorar.",
      p1: 'Desde 2015 transformando ideias em materialização visual e audiovisual, venho construindo uma forma própria de olhar para marcas: menos sobre "ficar bonito", mais sobre comunicar com clareza quem você é e para onde vai.',
      p2: 'O símbolo da marca — um "b" com uma estrela de quatro pontas vazada no centro — representa exatamente essa proposta: iluminação, direção e diferenciação. Cada projeto carrega esse compromisso.',
      values: [
        {
          title: "Simplicidade Estratégica",
          desc: "Decisões visuais que servem a um objetivo claro, sem ruído.",
        },
        {
          title: "Identidade Autêntica",
          desc: "Marca como extensão real de quem você é — nunca um molde genérico.",
        },
        {
          title: "Sofisticação Funcional",
          desc: "Estética refinada que também funciona no dia a dia do negócio.",
        },
        {
          title: "Inovação com Propósito",
          desc: "Criatividade a serviço de um resultado, não de uma tendência.",
        },
      ],
    },
    services: [
      {
        title: "Branding",
        desc: "Construção ou revisão da marca como um todo: o que ela promete, como fala e como quer ser lembrada.",
        tags: "Plataforma de marca, Naming, Arquitetura de marca",
        icon: "star4",
      },
      {
        title: "Identidade Visual",
        desc: "Logotipo, paleta, tipografia e manual de aplicação: o sistema visual que faz a marca ser reconhecida em qualquer ponto de contato.",
        tags: "Logotipo, Paleta, Manual de marca",
        icon: "layers",
      },
      {
        title: "Posicionamento",
        desc: "Para quem a marca é, com quem ela compete e por que deveria ser escolhida — definido antes de qualquer peça ser criada.",
        tags: "Público, Diferenciação, Proposta de valor",
        icon: "target",
      },
      {
        title: "Estratégia de Marca",
        desc: "Tom de voz, mensagens-chave e direção criativa que orientam todas as decisões de comunicação.",
        tags: "Tom de voz, Mensagens, Direção criativa",
        icon: "compass",
      },
      {
        title: "Conteúdo",
        desc: "Design gráfico, vídeo e peças para redes sociais que traduzem a estratégia no que as pessoas veem todos os dias.",
        tags: "Redes sociais, Vídeo, Design gráfico",
        icon: "spark",
      },
      {
        title: "Marketing",
        desc: "Presença digital, calendário editorial e ações que levam a percepção construída até o contato e a venda.",
        tags: "Presença digital, Calendário, Conversão",
        icon: "trend",
      },
    ],
    diff: {
      eyebrow: "Diferenciais",
      title: "O que muda quando existe direção estratégica.",
    },
    process: [
      {
        title: "Posicionamento",
        desc: "Entendemos o negócio, o público e a concorrência para definir o lugar que a marca deve ocupar.",
        deliver: "Diagnóstico e posicionamento definido",
      },
      {
        title: "Identidade",
        desc: "Traduzimos o posicionamento em um sistema visual e verbal coerente.",
        deliver: "Identidade visual e tom de voz",
      },
      {
        title: "Conteúdo",
        desc: "Planejamos e produzimos o que a marca vai dizer e mostrar, com um objetivo claro em cada peça.",
        deliver: "Linha editorial e peças produzidas",
      },
      {
        title: "Experiência",
        desc: "Cuidamos para que cada ponto de contato — perfil, site, atendimento, material impresso — conte a mesma história.",
        deliver: "Pontos de contato alinhados",
      },
      {
        title: "Prova",
        desc: "Organizamos evidências reais — trabalhos, resultados e relatos de clientes — que sustentam o que a marca promete.",
        deliver: "Portfólio e provas organizados",
      },
      {
        title: "Decisão",
        desc: "Com percepção construída e prova visível, o caminho até o contato e a compra fica mais curto.",
        deliver: "Caminho claro até o contato",
      },
    ],
    portfolioIntro: {
      eyebrow: "Trabalhos",
      title: "Estudos de caso, não apenas imagens bonitas.",
      desc: "Filtre por tipo de projeto ou pesquise por palavra-chave.",
    },
    portfolio: [
      {
        category: "identidade",
        categoryLabel: "Identidade Visual",
        title: "Sistema de marca — clínica de estética",
        desc: "Naming, logotipo e paleta para reposicionamento premium.",
        image: "",
      },
      {
        category: "social",
        categoryLabel: "Social Media",
        title: "Calendário editorial — moda autoral",
        desc: "Estratégia de conteúdo e identidade de feed.",
        image: "",
      },
      {
        category: "video",
        categoryLabel: "Vídeo",
        title: "Institucional — negócio local",
        desc: "Roteiro, captação e motion para vídeo de apresentação.",
        image: "",
      },
      {
        category: "identidade",
        categoryLabel: "Identidade Visual",
        title: "Rebranding — food service",
        desc: "Reconstrução completa de marca e aplicação em embalagens.",
        image: "",
      },
      {
        category: "social",
        categoryLabel: "Social Media",
        title: "Gestão de presença — consultoria",
        desc: "Direção de conteúdo e crescimento de engajamento.",
        image: "",
      },
      {
        category: "video",
        categoryLabel: "Vídeo",
        title: "Reels de lançamento — produto digital",
        desc: "Série de vídeos curtos para campanha de lançamento.",
        image: "",
      },
    ],
    testimonialsIntro: {
      eyebrow: "Depoimentos",
      title: "Palavra de quem já passou pelo processo.",
    },
    testimonials: [
      {
        quote:
          "Antes eu tinha uma logo. Depois do trabalho com a Felipe Branding, passei a ter uma marca que meus clientes reconhecem antes mesmo de eu falar o nome do negócio.",
        name: "Mariana R.",
        role: "Empreendedora, setor de estética",
      },
      {
        quote:
          "O processo de imersão foi o que mais me surpreendeu. Senti que a estratégia veio antes do design — e isso mudou completamente o resultado final.",
        name: "Lucas C.",
        role: "Fundador, marca de indumentária",
      },
      {
        quote:
          "Os vídeos de reposicionamento aumentaram nosso engajamento de forma visível já nas primeiras semanas. Direção clara, entrega no prazo.",
        name: "Paula A.",
        role: "Gestora de marketing",
      },
    ],
    faqIntro: {
      eyebrow: "Dúvidas frequentes",
      title: "Perguntas que ajudam antes de fechar.",
    },
    faq: [
      {
        q: "Quanto tempo leva um projeto de identidade visual?",
        a: "Em média de 3 a 5 semanas, dependendo da complexidade e da agilidade nas rodadas de feedback. Projetos que envolvem apenas peças gráficas avulsas costumam ser mais rápidos.",
      },
      {
        q: "Preciso já ter logotipo pronto para contratar?",
        a: "Não. Muitos projetos começam do zero, ainda na fase de imersão e estratégia, antes de qualquer elemento visual existir.",
      },
      {
        q: "Como funciona o orçamento?",
        a: "Cada projeto é orçado conforme escopo e prazo. Preencha o formulário de contato com a faixa de investimento estimada e você recebe uma proposta personalizada.",
      },
      {
        q: "Vocês atendem clientes fora de Petrolina?",
        a: "Sim, o atendimento é 100% remoto e cobre todo o Brasil, com reuniões por vídeo-chamada nas etapas-chave do processo.",
      },
      {
        q: "Existe suporte depois da entrega final?",
        a: "Sim. Todo projeto inclui um período de acompanhamento pós-entrega para ajustes de aplicação e dúvidas de uso do material.",
      },
    ],
    cta: {
      eyebrow: "Consultoria gratuita",
      title: "Comece pelo diagnóstico da sua marca.",
      desc: "Receba uma leitura estratégica do seu perfil no Instagram, sem custo. Se fizer sentido, a gente conversa sobre o próximo passo.",
      note: "Leva menos de 2 minutos. Sem compromisso.",
    },
    contactIntro: {
      eyebrow: "Contato",
      title: "Conte um pouco sobre o seu projeto.",
      desc: "Responda o formulário e retornamos em até 1 dia útil — ou fale agora mesmo pelo WhatsApp.",
    },
    contact: {
      whatsapp: "5587981798483",
      whatsappDisplay: "(87) 98179-8483",
      email: "contato@felipebranding.com.br",
      address: "Petrolina, PE — Vale do São Francisco, com atendimento remoto para todo o Brasil",
      hours: "Segunda a sexta, 9h às 18h",
      instagram: "",
      linkedin: "",
      behance: "",
    },
    footer: {
      desc: "Branding, posicionamento, identidade visual e marketing. Petrolina (PE), Vale do São Francisco — atendimento remoto para todo o Brasil.",
    },
  };

  var SUPABASE_URL = "https://aligftypgtzlymmditeo.supabase.co";
  // Chave PÚBLICA (publishable) — feita para ficar no navegador. As regras de
  // acesso do banco (RLS) só deixam o visitante LER site_content.
  var SUPABASE_PUBLIC_KEY = "sb_publishable_lLKYguXwi6isaw1C4X5uiA_25-MT7ym";
  var CONTENT_TIMEOUT_MS = 8000;

  function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function isPlainObject(value) {
    return value && typeof value === "object" && !Array.isArray(value);
  }

  /** Mescla o conteúdo salvo no painel por cima do padrão (arrays são substituídos inteiros). */
  function mergeDeep(target, source) {
    if (!source) return target;
    Object.keys(source).forEach(function (key) {
      if (Array.isArray(source[key])) target[key] = source[key];
      else if (isPlainObject(source[key]) && isPlainObject(target[key]))
        mergeDeep(target[key], source[key]);
      else target[key] = source[key];
    });
    return target;
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value).replace(
      /[&<>"']/g,
      function (ch) {
        return {
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        }[ch];
      },
    );
  }

  function getPath(obj, path) {
    return path.split(".").reduce(function (acc, key) {
      return acc == null ? undefined : acc[key];
    }, obj);
  }

  // Uma única requisição por carregamento de página: a home e a esteira de
  // parceiras (partners-marquee) compartilham a mesma resposta. Antes eram
  // duas buscas idênticas ao Supabase — e sem limite de tempo.
  var contentRequest = null;

  function fetchContent() {
    var controller = "AbortController" in window ? new AbortController() : null;
    var timer = controller
      ? setTimeout(function () {
          controller.abort();
        }, CONTENT_TIMEOUT_MS)
      : null;
    return fetch(
      SUPABASE_URL + "/rest/v1/site_content?select=content&id=eq.1",
      {
        headers: {
          apikey: SUPABASE_PUBLIC_KEY,
          Authorization: "Bearer " + SUPABASE_PUBLIC_KEY,
        },
        signal: controller ? controller.signal : undefined,
      },
    )
      .then(function (res) {
        if (!res.ok)
          throw new Error("Falha ao buscar conteúdo (HTTP " + res.status + ")");
        return res.json();
      })
      .then(function (rows) {
        var saved = rows && rows[0] && rows[0].content;
        return {
          content: mergeDeep(deepClone(DEFAULT_CONTENT), saved || {}),
          fromServer: Boolean(saved),
        };
      })
      .catch(function (err) {
        console.warn(
          "Conteúdo do site indisponível; usando o texto padrão embutido.",
          err,
        );
        return { content: deepClone(DEFAULT_CONTENT), fromServer: false };
      })
      .finally(function () {
        if (timer) clearTimeout(timer);
      });
  }

  function loadContentResult() {
    if (!contentRequest) contentRequest = fetchContent();
    return contentRequest.then(function (result) {
      return {
        content: deepClone(result.content),
        fromServer: result.fromServer,
      };
    });
  }

  window.FBContent = {
    DEFAULT_CONTENT: DEFAULT_CONTENT,
    deepClone: deepClone,
    mergeDeep: mergeDeep,
    /** Contrato mantido: resolve com o conteúdo mesclado (nunca rejeita). */
    loadContent: function () {
      return loadContentResult().then(function (result) {
        return result.content;
      });
    },
    loadContentResult: loadContentResult,
    escapeHtml: escapeHtml,
    get: getPath,
  };
})(window);

(function () {
  "use strict";

  var FB = window.FBContent;
  var esc = FB.escapeHtml;
  var reduceMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)",
  ).matches;
  var coarsePointer = window.matchMedia("(pointer: coarse)").matches;
  var root = document.documentElement;

  function byId(id) {
    return document.getElementById(id);
  }

  // Conteúdo em uso agora (começa no padrão; troca pelo do painel quando chegar).
  var content = FB.deepClone(FB.DEFAULT_CONTENT);

  // ---------------------------------------------------------------------------
  // URLs vindas do painel: só http(s), caminhos do próprio site e imagens data:.
  // Impede "javascript:" e similares em href/src/iframe.
  // ---------------------------------------------------------------------------
  function safeUrl(value, options) {
    var url = String(value || "").trim();
    if (!url) return "";
    var opts = options || {};
    if (/^https?:\/\//i.test(url)) return url;
    if (opts.allowRelative && /^\/(?!\/)/.test(url)) return url;
    if (
      opts.allowDataImage &&
      /^data:image\/(png|jpe?g|webp|gif|avif);base64,/i.test(url)
    )
      return url;
    return "";
  }

  function whatsappNumber() {
    return String((content.contact && content.contact.whatsapp) || "").replace(
      /\D/g,
      "",
    );
  }

  function whatsappUrl(text) {
    return (
      "https://wa.me/" +
      whatsappNumber() +
      (text ? "?text=" + encodeURIComponent(text) : "")
    );
  }

  // ---------------------------------------------------------------------------
  // Trava de rolagem compartilhada (menu móvel e modal). Antes cada um mexia em
  // body.style.overflow sozinho: fechar um destravava a página com o outro aberto.
  // ---------------------------------------------------------------------------
  var scrollLocks = {};
  function lockScroll(owner) {
    scrollLocks[owner] = true;
    root.classList.add("is-scroll-locked");
  }
  function unlockScroll(owner) {
    delete scrollLocks[owner];
    if (!Object.keys(scrollLocks).length)
      root.classList.remove("is-scroll-locked");
  }

  // ---------------------------------------------------------------------------
  // Tema claro/escuro (o tema salvo já foi aplicado no <head> por theme-init.js)
  // ---------------------------------------------------------------------------
  function initThemeToggle() {
    var button = byId("themeToggle");
    function sync() {
      var isLight = root.getAttribute("data-theme") === "light";
      button.setAttribute("aria-pressed", isLight ? "true" : "false");
      button.setAttribute(
        "aria-label",
        isLight ? "Mudar para o tema escuro" : "Mudar para o tema claro",
      );
    }
    button.addEventListener("click", function () {
      var next = root.getAttribute("data-theme") === "light" ? "dark" : "light";
      root.setAttribute("data-theme", next);
      try {
        localStorage.setItem("fb_theme", next);
      } catch (err) {
        /* navegação privada sem storage: o tema só vale nesta visita */
      }
      sync();
    });
    sync();
  }

  // ---------------------------------------------------------------------------
  // Cabeçalho, barra de progresso e "voltar ao topo" — 1 leitura de layout por frame
  // ---------------------------------------------------------------------------
  function initScrollChrome() {
    var header = byId("siteHeader");
    var progress = byId("scrollProgress");
    var backTop = byId("backTopBtn");
    var ticking = false;

    function update() {
      ticking = false;
      var y = window.scrollY || root.scrollTop;
      header.classList.toggle("is-scrolled", y > 40);
      backTop.classList.toggle("is-visible", y > 600);
      var max = root.scrollHeight - window.innerHeight;
      progress.style.transform =
        "scaleX(" + (max > 0 ? Math.min(y / max, 1) : 0) + ")";
    }
    function onScroll() {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(update);
      }
    }
    function toTop() {
      window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
      var skipTarget = byId("main");
      if (skipTarget) skipTarget.focus({ preventScroll: true });
    }

    document.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    update();
    backTop.addEventListener("click", toTop);
    byId("footerBackTop").addEventListener("click", toTop);
  }

  // ---------------------------------------------------------------------------
  // Menu móvel
  // ---------------------------------------------------------------------------
  function initMobileMenu() {
    var toggle = byId("menuToggle");
    var nav = byId("navMobile");
    var desktop = window.matchMedia("(min-width: 1080px)");

    function isOpen() {
      return nav.classList.contains("is-open");
    }
    function open() {
      nav.classList.add("is-open");
      nav.removeAttribute("inert");
      toggle.setAttribute("aria-expanded", "true");
      toggle.setAttribute("aria-label", "Fechar menu");
      lockScroll("menu");
      var first = nav.querySelector("a");
      if (first) first.focus({ preventScroll: true });
    }
    function close(returnFocus) {
      if (!isOpen()) return;
      nav.classList.remove("is-open");
      nav.setAttribute("inert", "");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Abrir menu");
      unlockScroll("menu");
      if (returnFocus) toggle.focus({ preventScroll: true });
    }

    nav.setAttribute("inert", "");
    toggle.addEventListener("click", function () {
      if (isOpen()) close(false);
      else open();
    });
    nav.addEventListener("click", function (event) {
      if (event.target.closest("a")) close(false);
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && isOpen()) close(true);
    });
    // Girou o celular / aumentou a janela com o menu aberto: fecha e destrava a rolagem.
    var onBreakpoint = function (event) {
      if (event.matches) close(false);
    };
    if (desktop.addEventListener)
      desktop.addEventListener("change", onBreakpoint);
    else desktop.addListener(onBreakpoint);
  }

  // ---------------------------------------------------------------------------
  // Modal "Agendar conversa"
  // ---------------------------------------------------------------------------
  function nextWeekdayAt10(daysAhead) {
    var d = new Date();
    d.setDate(d.getDate() + daysAhead);
    while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() + 1);
    d.setHours(10, 0, 0, 0);
    return d;
  }
  function calendarStamp(date) {
    function pad(n) {
      return String(n).padStart(2, "0");
    }
    // Sem "Z": o Google Agenda interpreta no fuso de quem abre o link.
    return (
      date.getFullYear() +
      pad(date.getMonth() + 1) +
      pad(date.getDate()) +
      "T" +
      pad(date.getHours()) +
      pad(date.getMinutes()) +
      "00"
    );
  }

  function initScheduleModal() {
    var overlay = byId("scheduleModal");
    var box = overlay.querySelector(".modal-box");
    var opener = byId("openScheduleModal");
    var lastFocus = null;

    function focusables() {
      return Array.prototype.slice.call(
        box.querySelectorAll("a[href], button:not([disabled])"),
      );
    }
    function isOpen() {
      return overlay.classList.contains("is-open");
    }
    function open() {
      lastFocus = document.activeElement;
      var start = nextWeekdayAt10(7);
      var end = new Date(start.getTime() + 30 * 60 * 1000);
      byId("gcalLink").href =
        "https://calendar.google.com/calendar/render?action=TEMPLATE&text=" +
        encodeURIComponent("Reunião com Felipe Branding") +
        "&dates=" +
        calendarStamp(start) +
        "/" +
        calendarStamp(end) +
        "&details=" +
        encodeURIComponent("Conversa sobre projeto de branding");
      overlay.classList.add("is-open");
      overlay.removeAttribute("aria-hidden");
      overlay.removeAttribute("inert");
      lockScroll("modal");
      var first = focusables()[0];
      if (first) first.focus({ preventScroll: true });
    }
    function close() {
      if (!isOpen()) return;
      overlay.classList.remove("is-open");
      overlay.setAttribute("aria-hidden", "true");
      overlay.setAttribute("inert", "");
      unlockScroll("modal");
      if (lastFocus && lastFocus.focus)
        lastFocus.focus({ preventScroll: true });
    }

    overlay.setAttribute("inert", "");
    opener.addEventListener("click", open);
    byId("closeModal").addEventListener("click", close);
    overlay.addEventListener("click", function (event) {
      if (event.target === overlay) close();
    });
    // Escolher uma opção abre o WhatsApp/e-mail/agenda: o modal fecha junto.
    box.querySelectorAll(".modal-option").forEach(function (link) {
      link.addEventListener("click", close);
    });
    document.addEventListener("keydown", function (event) {
      if (!isOpen()) return;
      if (event.key === "Escape") {
        close();
        return;
      }
      if (event.key === "Tab") {
        var items = focusables();
        if (!items.length) return;
        var first = items[0];
        var last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Animações de entrada e contadores
  // ---------------------------------------------------------------------------
  var revealObserver =
    "IntersectionObserver" in window && !reduceMotion
      ? new IntersectionObserver(
          function (entries) {
            entries.forEach(function (entry) {
              if (entry.isIntersecting) {
                entry.target.classList.add("is-visible");
                revealObserver.unobserve(entry.target);
              }
            });
          },
          { threshold: 0.12, rootMargin: "0px 0px -60px 0px" },
        )
      : null;

  function observeReveals(scope) {
    scope
      .querySelectorAll("[data-reveal]:not(.is-visible)")
      .forEach(function (el) {
        if (revealObserver) revealObserver.observe(el);
        else el.classList.add("is-visible");
      });
  }

  var countedStats = new WeakSet();
  function animateCounter(el) {
    var target = parseInt(el.getAttribute("data-counter"), 10) || 0;
    if (reduceMotion) {
      el.textContent = target;
      return;
    }
    var start = null;
    function step(now) {
      if (start === null) start = now;
      var progress = Math.min((now - start) / 1200, 1);
      el.textContent = Math.floor(progress * target);
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = target;
    }
    requestAnimationFrame(step);
  }
  var counterObserver =
    "IntersectionObserver" in window
      ? new IntersectionObserver(
          function (entries) {
            entries.forEach(function (entry) {
              if (entry.isIntersecting && !countedStats.has(entry.target)) {
                countedStats.add(entry.target);
                counterObserver.unobserve(entry.target);
                animateCounter(entry.target);
              }
            });
          },
          { threshold: 0.6 },
        )
      : null;

  function initCounters() {
    document.querySelectorAll("[data-counter]").forEach(function (el) {
      if (counterObserver) counterObserver.observe(el);
      else el.textContent = el.getAttribute("data-counter");
    });
  }

  // ---------------------------------------------------------------------------
  // Estrela que segue o cursor no hero — só anima enquanto o mouse está no hero
  // ---------------------------------------------------------------------------
  function initCursorStar() {
    if (reduceMotion || coarsePointer) return;
    var star = byId("cursorStar");
    var hero = document.querySelector(".hero");
    var targetX = 0,
      targetY = 0,
      x = 0,
      y = 0,
      running = false;

    function frame() {
      x += 0.18 * (targetX - x);
      y += 0.18 * (targetY - y);
      star.style.transform =
        "translate(" +
        (x - 7) +
        "px," +
        (y - 7) +
        "px) rotate(" +
        0.4 * x +
        "deg)";
      if (running) requestAnimationFrame(frame);
    }
    hero.addEventListener("mouseenter", function (event) {
      targetX = x = event.clientX;
      targetY = y = event.clientY;
      star.style.opacity = "0.9";
      if (!running) {
        running = true;
        requestAnimationFrame(frame);
      }
    });
    hero.addEventListener("mousemove", function (event) {
      targetX = event.clientX;
      targetY = event.clientY;
    });
    hero.addEventListener("mouseleave", function () {
      star.style.opacity = "0";
      running = false;
    });
  }

  var heroStarsAdded = false;
  function addHeroStars() {
    var visual = byId("heroVisual");
    if (heroStarsAdded || !visual || reduceMotion || !visual.animate) return;
    heroStarsAdded = true;
    [
      { t: "10%", l: "12%", s: 18, d: 0 },
      { t: "70%", l: "8%", s: 12, d: 0.3 },
      { t: "18%", l: "78%", s: 14, d: 0.6 },
      { t: "75%", l: "82%", s: 20, d: 0.9 },
      { t: "45%", l: "92%", s: 10, d: 1.2 },
    ].forEach(function (spec) {
      var star = document.createElement("div");
      star.className = "hero-star";
      star.setAttribute("aria-hidden", "true");
      star.style.top = spec.t;
      star.style.left = spec.l;
      star.style.width = spec.s + "px";
      star.style.height = spec.s + "px";
      star.innerHTML =
        '<svg viewBox="0 0 100 100"><use href="#ic-star4"/></svg>';
      visual.appendChild(star);
      star.animate(
        [
          { opacity: 0, transform: "scale(0) rotate(0deg)" },
          { opacity: 1, transform: "scale(1) rotate(180deg)", offset: 0.5 },
          { opacity: 0.5, transform: "scale(.8) rotate(360deg)" },
        ],
        {
          duration: 3200,
          delay: 400 * spec.d + 300,
          iterations: Infinity,
          direction: "alternate",
          easing: "ease-in-out",
        },
      );
    });
  }

  // ---------------------------------------------------------------------------
  // Portfólio: filtros + busca (sem diferenciar acentos: "video" acha "Vídeo")
  // ---------------------------------------------------------------------------
  var portfolioFilter = "todos";

  function normalizeText(value) {
    return String(value || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "");
  }

  function applyPortfolioFilters() {
    var term = normalizeText(byId("portfolioSearch").value.trim());
    var visible = 0;
    byId("portfolioGrid")
      .querySelectorAll(".case-card")
      .forEach(function (card) {
        var matchesCategory =
          portfolioFilter === "todos" ||
          card.getAttribute("data-cat") === portfolioFilter;
        var matchesTerm =
          !term || card.getAttribute("data-search").indexOf(term) !== -1;
        var show = matchesCategory && matchesTerm;
        card.classList.toggle("is-hidden", !show);
        if (show) visible++;
      });
    byId("portfolioEmpty").classList.toggle("is-visible", visible === 0);
  }

  function initPortfolioFilters() {
    var buttons = document.querySelectorAll(".filter-btn");
    buttons.forEach(function (button) {
      button.addEventListener("click", function () {
        buttons.forEach(function (other) {
          other.classList.toggle("is-active", other === button);
          other.setAttribute(
            "aria-pressed",
            other === button ? "true" : "false",
          );
        });
        portfolioFilter = button.getAttribute("data-filter");
        applyPortfolioFilters();
      });
    });
    byId("portfolioSearch").addEventListener("input", applyPortfolioFilters);
  }

  // ---------------------------------------------------------------------------
  // Comparador antes/depois — mouse, toque e teclado (input range)
  // ---------------------------------------------------------------------------


  // ---------------------------------------------------------------------------
  // Depoimentos
  // ---------------------------------------------------------------------------
  var testimonials = { index: 0, timer: null, count: 0, paused: false };

  function showTestimonial(index) {
    if (!testimonials.count) return;
    testimonials.index = (index + testimonials.count) % testimonials.count;
    var slides = byId("testiSlides");
    slides.style.transform = "translateX(-" + 100 * testimonials.index + "%)";
    Array.prototype.forEach.call(slides.children, function (slide, i) {
      slide.setAttribute(
        "aria-hidden",
        i === testimonials.index ? "false" : "true",
      );
    });
    Array.prototype.forEach.call(byId("testiDots").children, function (dot, i) {
      dot.classList.toggle("is-active", i === testimonials.index);
      if (i === testimonials.index) dot.setAttribute("aria-current", "true");
      else dot.removeAttribute("aria-current");
    });
  }
  function stopAutoplay() {
    if (testimonials.timer) {
      clearInterval(testimonials.timer);
      testimonials.timer = null;
    }
  }
  function startAutoplay() {
    stopAutoplay();
    if (
      reduceMotion ||
      testimonials.count < 2 ||
      testimonials.paused ||
      document.hidden
    )
      return;
    testimonials.timer = setInterval(function () {
      showTestimonial(testimonials.index + 1);
    }, 6000);
  }

  function initTestimonialControls() {
    var wrap = document.querySelector(".testi-wrap");
    byId("testiPrev").addEventListener("click", function () {
      showTestimonial(testimonials.index - 1);
    });
    byId("testiNext").addEventListener("click", function () {
      showTestimonial(testimonials.index + 1);
    });
    byId("testiDots").addEventListener("click", function (event) {
      var dot = event.target.closest("button[data-index]");
      if (dot) showTestimonial(parseInt(dot.getAttribute("data-index"), 10));
    });
    // Pausa com mouse em cima, com foco do teclado dentro e com a aba em segundo plano.
    function pause() {
      testimonials.paused = true;
      stopAutoplay();
    }
    function resume() {
      testimonials.paused = false;
      startAutoplay();
    }
    wrap.addEventListener("mouseenter", pause);
    wrap.addEventListener("mouseleave", resume);
    wrap.addEventListener("focusin", pause);
    wrap.addEventListener("focusout", function (event) {
      if (!wrap.contains(event.relatedTarget)) resume();
    });
    document.addEventListener("visibilitychange", function () {
      if (document.hidden) stopAutoplay();
      else startAutoplay();
    });
  }

  function renderTestimonials(list) {
    var slides = byId("testiSlides");
    var dots = byId("testiDots");
    slides.innerHTML = list
      .map(function (item) {
        var initials = String(item.name || "")
          .split(" ")
          .map(function (part) {
            return part[0] || "";
          })
          .slice(0, 2)
          .join("")
          .toUpperCase();
        return (
          '<div class="testi-slide" role="group" aria-roledescription="depoimento"><blockquote>' +
          esc(item.quote) +
          '</blockquote><div class="testi-author"><div class="testi-avatar" aria-hidden="true">' +
          esc(initials) +
          '</div><div><div class="name">' +
          esc(item.name) +
          '</div><div class="role">' +
          esc(item.role) +
          "</div></div></div></div>"
        );
      })
      .join("");
    dots.innerHTML = list
      .map(function (_, i) {
        return (
          '<button type="button" data-index="' +
          i +
          '" aria-label="Ir para o depoimento ' +
          (i + 1) +
          '"></button>'
        );
      })
      .join("");
    testimonials.count = list.length;
    document.querySelector(".testi-controls").hidden = list.length < 2;
    showTestimonial(Math.min(testimonials.index, Math.max(list.length - 1, 0)));
    startAutoplay();
  }

  // ---------------------------------------------------------------------------
  // FAQ (acordeão)
  // ---------------------------------------------------------------------------
  function setFaqOpen(item, open) {
    var question = item.querySelector(".faq-q");
    var answer = item.querySelector(".faq-a");
    item.classList.toggle("is-open", open);
    question.setAttribute("aria-expanded", open ? "true" : "false");
    answer.style.maxHeight = open ? answer.scrollHeight + "px" : "";
  }

  function initFaq() {
    var list = byId("faqList");
    list.addEventListener("click", function (event) {
      var question = event.target.closest(".faq-q");
      if (!question) return;
      var item = question.closest(".faq-item");
      var willOpen = !item.classList.contains("is-open");
      list.querySelectorAll(".faq-item.is-open").forEach(function (other) {
        setFaqOpen(other, false);
      });
      if (willOpen) setFaqOpen(item, true);
    });
    // Girou a tela / mudou a largura: a resposta aberta recalcula a altura (antes cortava o texto).
    window.addEventListener(
      "resize",
      function () {
        var open = list.querySelector(".faq-item.is-open");
        if (open) setFaqOpen(open, true);
      },
      { passive: true },
    );
  }

  function renderFaq(items) {
    byId("faqList").innerHTML = items
      .map(function (item, i) {
        var id = "faq-a-" + i;
        return (
          '<div class="faq-item"><h3 class="faq-h"><button type="button" class="faq-q" aria-expanded="false" aria-controls="' +
          id +
          '">' +
          '<span class="faq-q-text">' +
          esc(item.q) +
          '</span><span class="plus" aria-hidden="true"></span></button></h3>' +
          '<div class="faq-a" id="' +
          id +
          '"><p>' +
          esc(item.a) +
          "</p></div></div>"
        );
      })
      .join("");
  }

  // ---------------------------------------------------------------------------
  // Formulário de contato → grava no painel (Function contato-criar, que também
  // avisa por e-mail) e oferece o WhatsApp; se o envio falhar, o WhatsApp vira
  // o caminho principal para a mensagem nunca se perder.
  // ---------------------------------------------------------------------------
  var BUDGET_LABELS = {
    "ate-3k": "Até R$3 mil",
    "3-8k": "R$3 a 8 mil",
    "8k+": "Acima de R$8 mil",
  };

  function initContactForm() {
    var form = byId("contactForm");
    var success = byId("formSuccess");
    var successLink = byId("successWhatsapp");
    var successTitle = byId("formSuccessTitle");
    var successText = byId("formSuccessText");
    var editButton = byId("editContactForm");
    var submitButton = byId("contactSubmit");
    var submitted = false;
    var sending = false;
    var lastOutcome = "ok";
    // Nome dos campos na Function contato-criar → campo do formulário
    var SERVER_FIELDS = {
      nome: "name",
      email: "email",
      whatsapp: "whatsapp",
      servico: "service",
      mensagem: "message",
    };

    function showOutcome(outcome) {
      lastOutcome = outcome;
      if (outcome === "ok") {
        successTitle.textContent = "Recebemos sua mensagem.";
        successText.textContent =
          "Ela já chegou para a equipe. Respondemos por e-mail ou WhatsApp — se quiser adiantar, fale agora com a gente.";
        successLink.textContent = "Falar agora pelo WhatsApp";
        editButton.textContent = "Enviar outra mensagem";
      } else {
        successTitle.textContent = "Não conseguimos registrar pelo site agora.";
        successText.textContent =
          "Sua mensagem já está pronta no WhatsApp — é só tocar em enviar para ela chegar até nós.";
        successLink.textContent = "Enviar pelo WhatsApp";
        editButton.textContent = "Editar mensagem";
      }
      form.hidden = true;
      success.hidden = false;
      success.classList.add("is-visible");
      successTitle.focus();
    }

    function setSending(on) {
      sending = on;
      submitButton.disabled = on;
      submitButton.setAttribute("aria-busy", on ? "true" : "false");
      submitButton.textContent = on ? "Enviando…" : "Enviar mensagem";
    }

    function postContact(payload) {
      var controller =
        "AbortController" in window ? new AbortController() : null;
      var timer = setTimeout(function () {
        if (controller) controller.abort();
      }, 12000);
      return fetch("/.netlify/functions/contato-criar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller ? controller.signal : undefined,
      })
        .then(function (res) {
          return res
            .json()
            .catch(function () {
              return {};
            })
            .then(function (data) {
              return { status: res.status, data: data };
            });
        })
        .finally(function () {
          clearTimeout(timer);
        });
    }

    var fields = {
      name: {
        wrap: byId("field-name"),
        input: byId("name"),
        valid: function (v) {
          return v.trim().length >= 2 && v.trim().length <= 120;
        },
      },
      email: {
        wrap: byId("field-email"),
        input: byId("email"),
        valid: function (v) {
          return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
        },
      },
      whatsapp: {
        wrap: byId("field-whatsapp"),
        input: byId("whatsapp"),
        valid: function (v) {
          var digits = v.replace(/\D/g, "").length;
          return digits >= 10 && digits <= 13;
        },
      },
      service: {
        wrap: byId("field-service"),
        input: byId("service"),
        valid: function (v) {
          return Boolean(v);
        },
      },
      message: {
        wrap: byId("field-message"),
        input: byId("message"),
        valid: function (v) {
          return v.trim().length >= 8 && v.trim().length <= 2000;
        },
      },
    };

    function check(field) {
      var ok = field.valid(field.input.value);
      field.wrap.classList.toggle("has-error", !ok);
      if (ok) field.input.removeAttribute("aria-invalid");
      else field.input.setAttribute("aria-invalid", "true");
      return ok;
    }

    // Depois da primeira tentativa, o erro some assim que o campo fica certo.
    Object.keys(fields).forEach(function (key) {
      var field = fields[key];
      var evt = field.input.tagName === "SELECT" ? "change" : "input";
      field.input.addEventListener(evt, function () {
        if (submitted) check(field);
      });
      field.input.addEventListener("blur", function () {
        if (submitted) check(field);
      });
    });

    form.querySelectorAll(".budget-pill input").forEach(function (radio) {
      radio.addEventListener("change", function () {
        form.querySelectorAll(".budget-pill").forEach(function (pill) {
          pill.classList.toggle(
            "is-checked",
            pill.contains(radio) && radio.checked,
          );
        });
      });
    });

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      if (sending) return;
      submitted = true;
      // Armadilha para robôs: pessoas não veem este campo.
      if (byId("hpWebsite").value) return;

      var firstInvalid = null;
      Object.keys(fields).forEach(function (key) {
        if (!check(fields[key]) && !firstInvalid)
          firstInvalid = fields[key].input;
      });
      if (firstInvalid) {
        firstInvalid.focus();
        return;
      }

      var budget = form.querySelector('input[name="budget"]:checked');
      var lines = [
        "Olá! Meu nome é " + fields.name.input.value.trim() + ".",
        "Tenho interesse em: " + fields.service.input.value + ".",
        budget
          ? "Faixa de investimento: " +
            (BUDGET_LABELS[budget.value] || budget.value) +
            "."
          : "",
        "E-mail: " + fields.email.input.value.trim(),
        "",
        fields.message.input.value.trim(),
      ].filter(function (line, i, all) {
        return line !== "" || (i > 0 && all[i - 1] !== "");
      });
      successLink.href = whatsappUrl(lines.join("\n"));

      setSending(true);
      postContact({
        nome: fields.name.input.value.trim(),
        email: fields.email.input.value.trim(),
        whatsapp: fields.whatsapp.input.value.trim(),
        servico: fields.service.input.value,
        orcamento: budget ? budget.value : null,
        mensagem: fields.message.input.value.trim(),
        fb_hp_campo_vazio: byId("hpWebsite").value,
      })
        .then(function (r) {
          setSending(false);
          if (r.status === 201) return showOutcome("ok");
          // O servidor recusou algum campo: mostra no próprio campo.
          if (r.status === 400 && r.data && r.data.campos) {
            var first = null;
            Object.keys(r.data.campos).forEach(function (serverKey) {
              var field = fields[SERVER_FIELDS[serverKey]];
              if (!field) return;
              field.wrap.classList.add("has-error");
              field.input.setAttribute("aria-invalid", "true");
              if (!first) first = field.input;
            });
            if (first) return first.focus();
          }
          showOutcome("fallback");
        })
        .catch(function () {
          setSending(false);
          showOutcome("fallback");
        });
    });

    editButton.addEventListener("click", function () {
      success.hidden = true;
      success.classList.remove("is-visible");
      form.hidden = false;
      if (lastOutcome === "ok") {
        // Mensagem já registrada: limpa só o texto para uma nova, mantendo os dados de contato.
        fields.message.input.value = "";
        submitted = false;
      }
      fields.message.input.focus();
    });
  }

  // ---------------------------------------------------------------------------
  // Renderização do conteúdo (chamada com o padrão e de novo quando o do painel chega)
  // ---------------------------------------------------------------------------
  var PORTFOLIO_GRADIENTS = [
    ["#1D2A44", "#161F30"],
    ["#212D49", "#1D2A44"],
    ["#243252", "#161F30"],
    ["#1D2A44", "#212D49"],
    ["#161F30", "#243252"],
    ["#212D49", "#1D2A44"],
  ];
  var VALUE_ICONS = ["ic-target", "ic-spark", "ic-layers", "ic-star4"];
  var SERVICE_ICONS = {
    target: 1,
    spark: 1,
    layers: 1,
    "arrows-h": 1,
    star4: 1,
    compass: 1,
    trend: 1,
  };
  var TRUST_ITEMS = [
    "Branding",
    "Identidade Visual",
    "Posicionamento",
    "Estratégia de Marca",
    "Conteúdo",
    "Marketing",
  ];

  function videoEmbed(rawUrl) {
    var url = safeUrl(rawUrl, { allowRelative: true });
    if (!url) return null;
    var yt = url.match(
      /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{6,})/,
    );
    if (yt)
      return {
        type: "iframe",
        src: "https://www.youtube-nocookie.com/embed/" + yt[1] + "?rel=0",
      };
    var vimeo = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    if (vimeo)
      return {
        type: "iframe",
        src: "https://player.vimeo.com/video/" + vimeo[1],
      };
    if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(url))
      return { type: "video", src: url };
    return null; // qualquer outro endereço não vira iframe na home
  }

  function renderHeroMedia(videoUrl) {
    var visual = byId("heroVisual");
    var current = visual.querySelector(".hero-video");
    var embed = videoEmbed(videoUrl);
    if (!embed) {
      if (current) current.remove();
      byId("heroMark").hidden = false;
      addHeroStars();
      return;
    }
    if (current && current.getAttribute("data-src") === embed.src) return;
    if (current) current.remove();
    var wrap = document.createElement("div");
    wrap.className = "hero-video";
    wrap.setAttribute("data-src", embed.src);
    wrap.innerHTML =
      embed.type === "video"
        ? '<video src="' +
          esc(embed.src) +
          '" autoplay muted loop playsinline></video>'
        : '<iframe src="' +
          esc(embed.src) +
          '" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen loading="lazy" title="Vídeo institucional Felipe Branding"></iframe>';
    byId("heroMark").hidden = true;
    visual.querySelectorAll(".hero-star").forEach(function (s) {
      s.remove();
    });
    heroStarsAdded = false;
    visual.appendChild(wrap);
  }

  function setLinkOrHide(id, url) {
    var link = byId(id);
    var safe = safeUrl(url);
    link.hidden = !safe;
    if (safe) link.href = safe;
  }

  function renderContent(data) {
    content = data;

    document.querySelectorAll("[data-key]").forEach(function (el) {
      var value = FB.get(data, el.getAttribute("data-key"));
      if (value != null && typeof value !== "object") el.textContent = value;
    });

    ["stat1", "stat2", "stat3"].forEach(function (id) {
      var el = byId(id);
      var n = parseInt(data.hero[id + "Num"], 10);
      if (isNaN(n)) n = 0;
      el.setAttribute("data-counter", n);
      if (countedStats.has(el)) el.textContent = n; // contador já rodou: só atualiza o número
    });
    byId("year").textContent = new Date().getFullYear();

    var contact = data.contact || {};
    var email = String(contact.email || "").trim();
    byId("waFloat").href = whatsappUrl(
      "Olá, vim pelo site e quero saber mais sobre a Felipe Branding.",
    );
    byId("footerWa").href = whatsappUrl("");
    byId("modalWa").href = whatsappUrl(
      "Olá, quero agendar uma conversa sobre meu projeto.",
    );
    byId("footerEmail").href = "mailto:" + email;
    byId("modalEmail").href =
      "mailto:" +
      email +
      "?subject=" +
      encodeURIComponent("Quero agendar uma reunião");
    setLinkOrHide("socialInstagram", contact.instagram);
    setLinkOrHide("socialLinkedin", contact.linkedin);
    setLinkOrHide("socialBehance", contact.behance);
    var socialRow = document.querySelector(".social-row");
    socialRow.hidden = !socialRow.querySelector("a:not([hidden])");

    var trust = "";
    for (var copy = 0; copy < 2; copy++) {
      TRUST_ITEMS.forEach(function (label) {
        trust +=
          '<span><svg viewBox="0 0 100 100"><use href="#ic-star4"/></svg>' +
          esc(label) +
          "</span>";
      });
    }
    byId("trustTrack").innerHTML = trust;

    renderHeroMedia(data.hero.videoUrl);

    var photoWrap = byId("founderPhotoWrap");
    var photo = safeUrl(data.founder.photo, {
      allowRelative: true,
      allowDataImage: true,
    });
    photoWrap.innerHTML = photo
      ? '<img src="' +
        esc(photo) +
        '" alt="' +
        esc(data.founder.name) +
        ", " +
        esc(data.founder.role) +
        '" loading="lazy">'
      : '<div class="founder-photo-fallback"><span class="brand-icon" aria-hidden="true"></span></div>';

    var valuesGrid = byId("valuesGrid");
    valuesGrid.innerHTML = (data.about.values || [])
      .map(function (value, i) {
        return (
          '<div class="value-card" data-reveal><svg aria-hidden="true"><use href="#' +
          VALUE_ICONS[i % VALUE_ICONS.length] +
          '"/></svg><h3 class="value-title">' +
          esc(value.title) +
          "</h3><p>" +
          esc(value.desc) +
          "</p></div>"
        );
      })
      .join("");
    observeReveals(valuesGrid);

    var servicesGrid = byId("servicesGrid");
    // 30/09: em produção "services" estava salvo como [] e a seção Serviços
    // aparecia só com o título. Lista vazia = usa o padrão.
    var services =
      data.services && data.services.length
        ? data.services
        : FB.DEFAULT_CONTENT.services;
    servicesGrid.innerHTML = services
      .map(function (service, i) {
        var tags = String(service.tags || "")
          .split(",")
          .map(function (tag) {
            return tag.trim();
          })
          .filter(Boolean);
        var icon = SERVICE_ICONS[service.icon] ? service.icon : "spark";
        return (
          '<article class="service-card" data-reveal><span class="num" aria-hidden="true">' +
          String(i + 1).padStart(2, "0") +
          '</span><div class="service-icon" aria-hidden="true"><svg><use href="#ic-' +
          icon +
          '"/></svg></div><h3>' +
          esc(service.title) +
          "</h3><p>" +
          esc(service.desc) +
          '</p><div class="service-tags">' +
          tags
            .map(function (tag) {
              return "<span>" + esc(tag) + "</span>";
            })
            .join("") +
          "</div></article>"
        );
      })
      .join("");
    observeReveals(servicesGrid);

    var processList = byId("processList");
    var steps =
      data.process && data.process.length
        ? data.process
        : FB.DEFAULT_CONTENT.process;
    processList.innerHTML = steps
      .map(function (step, i) {
        return (
          '<li class="process-item" data-reveal><div class="step-num" aria-hidden="true">' +
          String(i + 1).padStart(2, "0") +
          "</div><div><h3>" +
          esc(step.title) +
          '</h3><p class="step-desc">' +
          esc(step.desc) +
          '</p></div><div class="step-deliver"><b>Entrega</b>' +
          esc(step.deliver) +
          "</div></li>"
        );
      })
      .join("");
    observeReveals(processList);

    var portfolioGrid = byId("portfolioGrid");
    portfolioGrid.innerHTML = (data.portfolio || [])
      .map(function (item, i) {
        var colors = PORTFOLIO_GRADIENTS[i % PORTFOLIO_GRADIENTS.length];
        var image = safeUrl(item.image, {
          allowRelative: true,
          allowDataImage: true,
        });
        var thumb = image
          ? '<img src="' +
            esc(image) +
            '" alt="' +
            esc(item.title) +
            '" loading="lazy">'
          : '<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="pg' +
            i +
            '" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="' +
            colors[0] +
            '"/><stop offset="100%" stop-color="' +
            colors[1] +
            '"/></linearGradient></defs><rect width="400" height="300" fill="url(#pg' +
            i +
            ')"/><path d="M200 90 L214 140 L264 150 L214 160 L200 210 L186 160 L136 150 L186 140 Z" fill="#C9A667" opacity="0.85"/></svg>';
        return (
          '<article class="case-card" data-reveal data-cat="' +
          esc(item.category) +
          '" data-search="' +
          esc(
            normalizeText(
              [item.title, item.categoryLabel, item.desc].join(" "),
            ),
          ) +
          '"><div class="case-thumb">' +
          thumb +
          '<span class="case-badge" aria-hidden="true">' +
          esc(item.categoryLabel) +
          '</span></div><div class="case-body"><span class="case-cat">' +
          esc(item.categoryLabel) +
          "</span><h3>" +
          esc(item.title) +
          "</h3><p>" +
          esc(item.desc) +
          "</p></div></article>"
        );
      })
      .join("");
    observeReveals(portfolioGrid);
    applyPortfolioFilters();

    renderTestimonials(data.testimonials || []);
    renderFaq(data.faq || []);
  }

  // ---------------------------------------------------------------------------
  // Início: a interface funciona na hora; o conteúdo do painel entra quando chegar.
  // Antes, TUDO (menu, tema, modal, formulário) só era ligado depois da resposta
  // do Supabase: com rede lenta o menu não abria e o formulário recarregava a
  // página com nome, e-mail e WhatsApp no endereço.
  // ---------------------------------------------------------------------------
  initThemeToggle();
  initScrollChrome();
  initMobileMenu();
  initScheduleModal();
  initPortfolioFilters();
  initTestimonialControls();
  initFaq();
  initContactForm();
  initCursorStar();
  initCounters();
  observeReveals(document);

  var rendered = null;
  function renderOnce(data) {
    var key = JSON.stringify(data);
    if (key === rendered) return;
    rendered = key;
    renderContent(data);
  }

  // Espera o conteúdo do painel por até 1,2 s para evitar a troca de textos na
  // frente do visitante; se demorar mais, mostra o padrão e troca quando chegar.
  var fallbackTimer = setTimeout(function () {
    renderOnce(FB.deepClone(FB.DEFAULT_CONTENT));
  }, 1200);
  FB.loadContentResult().then(function (result) {
    clearTimeout(fallbackTimer);
    renderOnce(result.content);
  });
})();
