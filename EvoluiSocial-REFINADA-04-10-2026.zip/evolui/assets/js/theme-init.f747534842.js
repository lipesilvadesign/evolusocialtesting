/* Aplica o tema salvo ANTES de a página desenhar (evita piscar no tema errado).
   Carregado no <head>, sem defer. Só aceita "light" ou "dark". */
(function () {
  try {
    var theme = localStorage.getItem("fb_theme");
    if (theme === "light" || theme === "dark") document.documentElement.setAttribute("data-theme", theme);
  } catch (err) {
    /* storage bloqueado: segue no tema padrão */
  }
})();
