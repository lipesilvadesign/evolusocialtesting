/**
 * Motor de PDF da apresentação pública (ENABLE_NEW_PDF_ENGINE / ENABLE_PDF_V2).
 * 30/09/2026 · reestruturado em 01/10/2026 sobre o MODELO EDITORIAL.
 *
 *   SNAPSHOT → montarModelo() (apresentacao-modelo.js) → ┬ WEB
 *                                                       └ PDF (este arquivo)
 * O PDF não tem "segunda versão" do conteúdo: percorre as mesmas seções, na
 * mesma ordem, com os mesmos textos. Só a composição muda (página A4).
 *
 * Mecanismo: pdf-lib 1.17.1 hospedada no próprio site (/assets/vendor/),
 * carregada só no clique. Sistema de layout:
 *   - renderPdfCover · renderPdfSection · renderPdfStrategy · renderPdfMetric ·
 *     renderPdfInsight · renderPdfOpportunity · renderPdfVisual · renderPdfFooter
 *   - margens fixas; cabeçalho e rodapé "Página X de Y" nas páginas internas;
 *   - keepWithNext: título de seção só é desenhado se couber junto com o
 *     começo do conteúdo (cálculo explícito de altura);
 *   - parágrafos sem órfã/viúva (mín. 2 linhas em cada lado da quebra);
 *   - blocos indivisíveis (métrica, item de lista curto, linha de interpretação
 *     curta) nunca partidos; blocos maiores que uma página são quebrados por linha;
 *   - quebra de palavra gigante (URL);
 *   - saída DETERMINÍSTICA (datas do documento = data de publicação).
 * Tipografia (decisão consciente — a fonte web NÃO está disponível dentro do PDF):
 *   títulos em Times-Bold (serifada, papel da Fraunces na web) e texto em
 *   Helvetica (sem serifa, papel da Manrope). São fontes PADRÃO do PDF: zero
 *   download, zero embutimento, saída menor. Embutir Fraunces/Manrope exigiria
 *   o fontkit e os arquivos TTF (~600 KB) — não justificado agora.
 *   Caracteres fora da codificação WinAnsi (emoji, setas) são trocados ou removidos.
 *
 * Uso: window.ApresentacaoPdf.gerar({ PDFLib, modelo | conteudo, tema, publicadoEm, onEtapa })
 *      → { bytes, paginas, nomeArquivo, textos }
 */
(function (raiz, fabrica) {
  const api = fabrica(typeof module === 'object' && module.exports ? require('./apresentacao-modelo.js') : null);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else raiz.ApresentacaoPdf = api;
}(typeof self !== 'undefined' ? self : this, function (ModeloNode) {
  'use strict';

  const A4 = [595.28, 841.89];
  const M = { esq: 56, dir: 56, topo: 80, base: 72 };
  const PADRAO = { primary: '#161F30', secondary: '#3D3D3D', accent: '#C9A667', texto: '#1D2330', suave: '#5B6070' };
  const TROCAS = { '→': '->', '←': '<-', '✓': '', '✔': '', ' ': ' ', ' ': ' ', ' ': ' ', '​': '' };
  const NATUREZA = { dado: 'DADO', contexto: 'CONTEXTO INFORMADO', interpretacao: 'INTERPRETAÇÃO', recomendacao: 'RECOMENDAÇÃO', plano: 'PLANO' };
  const T = { titulo: 19, rotulo: 8, corpo: 10.5, entrelinha: 15.5 };
  // estrela de 5 pontas em coordenadas SVG (0–24), usada no lugar do caractere ★
  const CAMINHO_ESTRELA = 'M12 1.5l3.1 6.6 7.2.9-5.3 5 1.4 7.1L12 17.6 5.6 21.1 7 14 1.7 9l7.2-.9z';

  function luminancia(r, g, b) {
    const f = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  }
  function cor(PDFLib, hex, reserva) {
    const h = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(String(hex || '')) ? String(hex) : reserva;
    let v = h.slice(1);
    if (v.length === 3) v = v.split('').map((c) => c + c).join('');
    const n = parseInt(v, 16);
    const rgb = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    return { cor: PDFLib.rgb(rgb[0] / 255, rgb[1] / 255, rgb[2] / 255), lum: luminancia(...rgb), rgb };
  }
  /** escurece até contraste ≥ 4,5:1 com branco (texto pequeno legível) */
  function legivelSobreBranco(PDFLib, c) {
    let rgb = c.rgb.slice();
    for (let i = 0; i < 30 && 1.05 / (luminancia(...rgb) + 0.05) < 4.5; i += 1) rgb = rgb.map((x) => Math.round(x * 0.9));
    return { cor: PDFLib.rgb(rgb[0] / 255, rgb[1] / 255, rgb[2] / 255), lum: luminancia(...rgb), rgb };
  }
  const contraste = (a, b) => (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);

  function nomeArquivo(nome) {
    const base = String(nome || 'cliente').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
      .replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'cliente';
    return `diagnostico-${base}.pdf`;
  }

  /** Texto seguro para a fonte padrão: troca o que dá, remove o que a fonte não codifica. */
  function limpo(texto, fonte) {
    let s = String(texto == null ? '' : texto).replace(/\r/g, '');
    s = s.replace(/[→←✓✔   ​]/g, (ch) => (ch in TROCAS ? TROCAS[ch] : ch));
    let out = '';
    for (const ch of s) {
      if (ch === '\n' || ch === '\t') { out += ' '; continue; }
      try { fonte.encodeText(ch); out += ch; } catch { /* fora da WinAnsi: descarta */ }
    }
    return out.replace(/ {2,}/g, ' ').trim();
  }

  /** Quebra por largura real da fonte; palavra maior que a linha é partida. */
  function quebrar(texto, fonte, tam, largura) {
    const palavras = String(texto || '').split(/\s+/).filter(Boolean);
    const linhas = [];
    let atual = '';
    const cabeLinha = (s) => fonte.widthOfTextAtSize(s, tam) <= largura;
    for (let p of palavras) {
      while (!cabeLinha(p)) {
        let corte = p.length - 1;
        while (corte > 1 && !cabeLinha(p.slice(0, corte))) corte -= 1;
        if (atual) { linhas.push(atual); atual = ''; }
        linhas.push(p.slice(0, corte));
        p = p.slice(corte);
      }
      const tentativa = atual ? `${atual} ${p}` : p;
      if (cabeLinha(tentativa)) atual = tentativa;
      else { linhas.push(atual); atual = p; }
    }
    if (atual) linhas.push(atual);
    return linhas;
  }

  async function embutirLogo(PDFLib, doc, logo) {
    const m = /^data:image\/(png|jpe?g);base64,([A-Za-z0-9+/=]+)$/i.exec(String(logo || ''));
    if (!m) return null; // SVG/WebP/URL externa: capa sem logo (nunca busca rede na geração)
    try {
      const bin = typeof atob === 'function' ? Uint8Array.from(atob(m[2]), (x) => x.charCodeAt(0)) : Uint8Array.from(Buffer.from(m[2], 'base64'));
      return /png/i.test(m[1]) ? await doc.embedPng(bin) : await doc.embedJpg(bin);
    } catch { return null; }
  }

  async function gerar({ PDFLib, modelo, conteudo, tema, publicadoEm, onEtapa }) {
    const Modelo = ModeloNode || (typeof self !== 'undefined' ? self.ApresentacaoModelo : null);
    const mod = modelo || (Modelo ? Modelo.montarModelo(conteudo) : null);
    if (!mod) throw new Error('Modelo editorial indisponível.');
    const t = tema || {};
    const etapa = (e) => { if (typeof onEtapa === 'function') onEtapa(e); };
    etapa('gerando');

    const doc = await PDFLib.PDFDocument.create();
    const F = {
      texto: await doc.embedFont(PDFLib.StandardFonts.Helvetica),
      forte: await doc.embedFont(PDFLib.StandardFonts.HelveticaBold),
      titulo: await doc.embedFont(PDFLib.StandardFonts.TimesRomanBold),
    };
    const empresa = mod.capa.empresa || 'Cliente';
    const dataBase = String(publicadoEm || '').slice(0, 10);
    const dataDoc = /^\d{4}-\d{2}-\d{2}$/.test(dataBase) ? new Date(`${dataBase}T12:00:00Z`) : new Date('2026-01-01T12:00:00Z');
    doc.setTitle(`${mod.capa.eyebrow} — ${limpo(empresa, F.texto)}`);
    doc.setAuthor('Felipe Branding');
    doc.setCreator('Felipe Branding');
    doc.setProducer('Felipe Branding (pdf-lib)');
    doc.setLanguage('pt-BR');
    doc.setCreationDate(dataDoc);
    doc.setModificationDate(dataDoc);

    const C = {
      primary: cor(PDFLib, t.primaryColor, PADRAO.primary),
      accent: cor(PDFLib, t.accentColor, PADRAO.accent),
      texto: cor(PDFLib, PADRAO.texto, PADRAO.texto),
      suave: cor(PDFLib, PADRAO.suave, PADRAO.suave),
      linha: cor(PDFLib, '#E3E1DA', '#E3E1DA'),
      trilho: cor(PDFLib, '#ECEAE4', '#ECEAE4'),
      claro: cor(PDFLib, '#F7F5F0', '#F7F5F0'),
    };
    const destaqueTexto = legivelSobreBranco(PDFLib, C.accent); // rótulos pequenos
    const destaqueForma = C.accent.lum > 0.75 ? C.primary : C.accent; // barras, filetes
    const corTitulo = C.primary.lum > 0.5 ? C.texto : C.primary;
    const [W, H] = A4;
    const largura = W - M.esq - M.dir;
    const textos = []; // trilha do conteúdo desenhado (para conferir web = PDF)

    // ------------------------------------------------------------ CAPA
    async function renderPdfCover() {
      const p = doc.addPage(A4);
      p.drawRectangle({ x: 0, y: 0, width: W, height: H, color: C.primary.cor });
      const escuro = C.primary.lum <= 0.45;
      const corTexto = escuro ? C.claro.cor : C.texto.cor;
      const corSuave = escuro ? cor(PDFLib, '#C9CCD6', '#C9CCD6').cor : C.suave.cor;
      let y = H - 150;
      const logo = await embutirLogo(PDFLib, doc, t.logo);
      if (logo) {
        const e = Math.min(180 / logo.width, 60 / logo.height, 1);
        p.drawImage(logo, { x: M.esq, y, width: logo.width * e, height: logo.height * e });
        y -= 40;
      } else if (t.logo) {
        // logo enviada mas não utilizável no PDF (SVG/WebP/corrompida): monograma discreto, nunca erro
        const iniciais = limpo(empresa, F.titulo).split(/\s+/).filter((w) => w.length > 2 || /^[A-Z]/.test(w)).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || 'FB';
        p.drawCircle({ x: M.esq + 26, y: y + 26, size: 26, borderColor: escuro ? C.claro.cor : C.texto.cor, borderWidth: 1.2 });
        const w = F.titulo.widthOfTextAtSize(iniciais, 18);
        p.drawText(iniciais, { x: M.esq + 26 - w / 2, y: y + 20, size: 18, font: F.titulo, color: corTexto });
        y -= 40;
      }
      p.drawText(limpo(mod.capa.eyebrow.toUpperCase(), F.forte), { x: M.esq, y, size: 10.5, font: F.forte,
        color: contraste(C.accent.lum, C.primary.lum) >= 3 ? C.accent.cor : corTexto });
      y -= 50;
      for (const l of quebrar(limpo(empresa, F.titulo), F.titulo, 34, largura).slice(0, 4)) {
        p.drawText(l, { x: M.esq, y, size: 34, font: F.titulo, color: corTexto }); y -= 40;
      }
      textos.push(empresa);
      const meta = [mod.capa.segmento, mod.capa.localizacao].filter(Boolean).join('  ·  ');
      if (meta) {
        p.drawText(limpo(meta, F.forte).slice(0, 90), { x: M.esq, y: y + 4, size: 12, font: F.forte, color: corTexto });
        y -= 26;
      }
      if (mod.capa.titulo) {
        for (const l of quebrar(limpo(mod.capa.titulo, F.texto), F.texto, 14, largura).slice(0, 3)) {
          p.drawText(l, { x: M.esq, y: y - 4, size: 14, font: F.texto, color: corSuave }); y -= 20;
        }
        textos.push(mod.capa.titulo);
      }
      if (mod.capa.data) p.drawText(limpo(mod.capa.data, F.texto), { x: M.esq, y: M.base, size: 10, font: F.texto, color: corSuave });
      const marca = 'Felipe Branding';
      p.drawText(marca, { x: W - M.dir - F.forte.widthOfTextAtSize(marca, 10), y: M.base, size: 10, font: F.forte, color: corSuave });
    }

    // ------------------------------------------------------------ MOTOR DE FLUXO
    const internas = [];
    let pag = null;
    let y = 0;
    const novaPagina = () => { pag = doc.addPage(A4); internas.push(pag); y = H - M.topo; };
    const espaco = () => (pag ? y - M.base : -1);
    const garantir = (h) => { if (espaco() < h) novaPagina(); };
    const alturaPagina = H - M.topo - M.base;

    /** Linhas de texto com controle de órfã/viúva. */
    function linhasComFluxo(linhas, { x = M.esq, fonte = F.texto, tam = T.corpo, corTxt = C.texto.cor, entre = T.entrelinha } = {}) {
      let i = 0;
      while (i < linhas.length) {
        const cabem = Math.floor(espaco() / entre);
        let n = Math.min(cabem, linhas.length - i);
        const resto = linhas.length - i - n;
        if (resto === 1 && n > 2) n -= 1; // viúva
        if (n <= 0 || (n === 1 && linhas.length - i > 1)) { novaPagina(); continue; } // órfã
        for (let k = 0; k < n; k += 1) { pag.drawText(linhas[i + k], { x, y: y - tam, size: tam, font: fonte, color: corTxt }); y -= entre; }
        i += n;
        if (i < linhas.length) novaPagina();
      }
    }
    const linhasDe = (texto, fonte = F.texto, tam = T.corpo, larg = largura) => quebrar(limpo(texto, fonte), fonte, tam, larg);

    function rotulo(texto, x = M.esq) {
      pag.drawText(limpo(texto.toUpperCase(), F.forte), { x, y: y - T.rotulo, size: T.rotulo, font: F.forte, color: destaqueTexto.cor });
      y -= 15;
    }

    /** Cabeçalho de seção com keepWithNext: só desenha se couber com `alturaInicio` do conteúdo. */
    function renderPdfSection(s, alturaInicio) {
      const alturaTitulo = 14 + T.titulo + 12 + 18;
      if (espaco() < alturaTitulo + alturaInicio) novaPagina();
      else if (y < H - M.topo - 1) y -= 16; // respiro entre seções na mesma página
      const nat = NATUREZA[s.natureza] || '';
      pag.drawText(limpo(s.eyebrow.toUpperCase(), F.forte), { x: M.esq, y: y - T.rotulo, size: T.rotulo, font: F.forte, color: destaqueTexto.cor });
      if (nat) {
        const w = F.texto.widthOfTextAtSize(nat, 7);
        pag.drawText(nat, { x: W - M.dir - w, y: y - T.rotulo, size: 7, font: F.texto, color: C.suave.cor });
      }
      y -= 14;
      pag.drawText(limpo(s.tituloPdf || s.titulo, F.titulo), { x: M.esq, y: y - T.titulo, size: T.titulo, font: F.titulo, color: corTitulo.cor });
      y -= T.titulo + 9;
      pag.drawRectangle({ x: M.esq, y: y - 2, width: 36, height: 2, color: destaqueForma.cor });
      y -= 18;
    }

    /** Pares rótulo → texto (contexto, presença, estratégia). */
    function renderPdfStrategy(s) {
      const primeiro = s.itens[0] ? 15 + Math.min(2, linhasDe(s.itens[0][1]).length) * T.entrelinha : 0;
      renderPdfSection(s, primeiro);
      for (const [r, v] of s.itens) {
        const ls = linhasDe(v);
        garantir(15 + Math.min(ls.length, 2) * T.entrelinha);
        rotulo(r);
        linhasComFluxo(ls);
        y -= 9;
        textos.push(v);
      }
    }

    function renderPdfMetric(m) {
      const ALT = 64;
      garantir(ALT);
      const valor = m.numerico ? `${m.valor.toLocaleString('pt-BR')}${m.unidade ? ` ${m.unidade}` : ''}` : m.valorTexto;
      // ★/☆ não existem na fonte padrão do PDF: viram estrela VETORIAL (opção B), nunca "�" nem sumiço
      const estrelas = (String(valor).match(/[\u2605\u2606]/g) || []).length;
      const valorTxt = limpo(String(valor).replace(/[\u2605\u2606]/g, ''), F.titulo).slice(0, 36);
      pag.drawText(valorTxt, { x: M.esq, y: y - 20, size: 20, font: F.titulo, color: corTitulo.cor });
      for (let k = 0; k < Math.min(estrelas, 5); k += 1) {
        const x0 = M.esq + F.titulo.widthOfTextAtSize(valorTxt, 20) + 8 + k * 16;
        pag.drawSvgPath(CAMINHO_ESTRELA, { x: x0, y: y - 6, scale: 0.6, color: destaqueForma.cor });
      }
      linhasDe(m.nome, F.texto, 10, largura - 190).slice(0, 2).forEach((l, k) => pag.drawText(l, { x: M.esq + 190, y: y - 13 - k * 13, size: 10, font: F.texto, color: C.texto.cor }));
      if (m.numerico) {
        pag.drawRectangle({ x: M.esq, y: y - 36, width: largura, height: 6, color: C.trilho.cor });
        pag.drawRectangle({ x: M.esq, y: y - 36, width: largura * m.proporcao, height: 6, color: destaqueForma.cor });
      }
      const meta = [m.periodo, m.origem ? `fonte: ${m.origem}` : ''].filter(Boolean).join(' · ');
      if (meta) pag.drawText(limpo(meta, F.texto).slice(0, 110), { x: M.esq, y: y - 52, size: 8.5, font: F.texto, color: C.suave.cor });
      y -= ALT;
      textos.push(m.nome); if (!m.numerico) textos.push(m.valorTexto);
    }

    function renderPdfInsight(s) {
      renderPdfSection(s, 15 + 2 * T.entrelinha);
      s.itens.forEach((r, i) => {
        const partes = [['Observação', r.dado], ['Interpretação', r.significado], ['Implicação', r.impacto]].filter(([, v]) => v);
        const total = partes.reduce((a, [, v]) => a + 15 + linhasDe(v).length * T.entrelinha + 6, 0);
        // linha de interpretação curta (cabe numa página) nunca é partida
        if (total <= alturaPagina * 0.6) garantir(total);
        for (const [r2, v] of partes) {
          const ls = linhasDe(v);
          garantir(15 + Math.min(ls.length, 2) * T.entrelinha);
          rotulo(r2);
          linhasComFluxo(ls);
          y -= 6;
          textos.push(v);
        }
        if (i < s.itens.length - 1 && espaco() > 14) { pag.drawRectangle({ x: M.esq, y: y + 2, width: largura, height: 0.6, color: C.linha.cor }); y -= 12; }
      });
    }

    /** Lista numerada (oportunidades e próximos passos). */
    function renderPdfOpportunity(s) {
      const recuo = 30;
      const ls0 = s.itens[0] ? linhasDe(s.itens[0], F.texto, T.corpo, largura - recuo) : [];
      renderPdfSection(s, Math.min(ls0.length, 3) * T.entrelinha);
      s.itens.forEach((texto, idx) => {
        const ls = linhasDe(texto, F.texto, T.corpo, largura - recuo);
        garantir(Math.min(ls.length, 3) * T.entrelinha);
        pag.drawText(String(idx + 1).padStart(2, '0'), { x: M.esq, y: y - T.corpo, size: T.corpo + 1, font: F.forte, color: destaqueTexto.cor });
        linhasComFluxo(ls, { x: M.esq + recuo });
        y -= 7;
        textos.push(texto);
      });
    }

    /** Plano de ação: prioridade (ordem), ação, objetivo e indicador quando informados. */
    function renderPdfPlan(s) {
      const recuo = 30;
      const altura = (t) => linhasDe(t.acao, F.forte, T.corpo, largura - recuo).length * T.entrelinha + (t.objetivo ? 15 : 0) + (t.indicador ? 15 : 0);
      renderPdfSection(s, s.itens[0] ? Math.min(altura(s.itens[0]), 4 * T.entrelinha) : 0);
      s.itens.forEach((t) => {
        const ls = linhasDe(t.acao, F.forte, T.corpo, largura - recuo);
        const h = altura(t);
        garantir(h <= alturaPagina * 0.5 ? h : Math.min(ls.length, 3) * T.entrelinha); // item curto é indivisível
        pag.drawText(String(t.prioridade).padStart(2, '0'), { x: M.esq, y: y - T.corpo, size: T.corpo + 1, font: F.forte, color: destaqueTexto.cor });
        linhasComFluxo(ls, { x: M.esq + recuo, fonte: F.forte });
        for (const [r, v] of [['Objetivo', t.objetivo], ['Indicador', t.indicador]]) {
          if (!v) continue;
          const lv = linhasDe(`${r}: ${v}`, F.texto, 9.5, largura - recuo);
          linhasComFluxo(lv, { x: M.esq + recuo, tam: 9.5, corTxt: C.suave.cor, entre: 14 });
        }
        y -= 8;
        textos.push(t.acao); if (t.objetivo) textos.push(t.objetivo); if (t.indicador) textos.push(t.indicador);
      });
    }

    function renderPdfVisual(s) {
      const v = s.itens;
      const hexes = v.cores.filter((c) => c.hex).slice(0, 8);
      renderPdfSection(s, hexes.length ? 70 : 15 + 2 * T.entrelinha);
      if (v.cores.length) {
        garantir(hexes.length ? 70 : 15 + T.entrelinha);
        rotulo('Cores');
        if (hexes.length) {
          hexes.forEach((c, i) => {
            const x = M.esq + i * 62;
            pag.drawRectangle({ x, y: y - 28, width: 28, height: 28, color: cor(PDFLib, c.hex, '#000000').cor, borderColor: C.linha.cor, borderWidth: 0.8 });
            pag.drawText(c.hex.toUpperCase(), { x, y: y - 40, size: 7.5, font: F.texto, color: C.suave.cor });
          });
          y -= 52;
        }
        linhasComFluxo(linhasDe(v.cores.map((c) => c.texto).join(' · ')));
        v.cores.forEach((c) => textos.push(c.texto));
        y -= 9;
      }
      for (const [r, val] of [['Tipografia', v.tipografia], ['Referências', v.referencias]]) {
        if (!val) continue;
        const ls = linhasDe(val);
        garantir(15 + Math.min(ls.length, 2) * T.entrelinha);
        rotulo(r); linhasComFluxo(ls); y -= 9;
        textos.push(val);
      }
    }

    function renderPdfFooter() {
      const total = internas.length + 1;
      const cab = limpo(empresa, F.forte).slice(0, 70);
      internas.forEach((p, i) => {
        p.drawText(cab, { x: M.esq, y: H - 46, size: 8.5, font: F.forte, color: C.suave.cor });
        const dir = mod.capa.eyebrow;
        p.drawText(dir, { x: W - M.dir - F.texto.widthOfTextAtSize(dir, 8.5), y: H - 46, size: 8.5, font: F.texto, color: C.suave.cor });
        p.drawRectangle({ x: M.esq, y: H - 54, width: largura, height: 0.6, color: C.linha.cor });
        p.drawRectangle({ x: M.esq, y: 50, width: largura, height: 0.6, color: C.linha.cor });
        p.drawText('Felipe Branding', { x: M.esq, y: 36, size: 8.5, font: F.forte, color: C.suave.cor });
        const num = `Página ${i + 2} de ${total}`;
        p.drawText(num, { x: W - M.dir - F.texto.widthOfTextAtSize(num, 8.5), y: 36, size: 8.5, font: F.texto, color: C.suave.cor });
      });
    }

    // ------------------------------------------------------------ COMPOSIÇÃO
    await renderPdfCover();
    novaPagina();
    for (const s of mod.secoes) {
      if (s.tipo === 'pares') renderPdfStrategy(s);
      else if (s.tipo === 'metricas') {
        renderPdfSection(s, 64);
        s.itens.forEach(renderPdfMetric);
        if (s.nota) { garantir(14); pag.drawText(limpo(s.nota, F.texto), { x: M.esq, y: y - 8, size: 8, font: F.texto, color: C.suave.cor }); y -= 18; }
      } else if (s.tipo === 'interpretacao') renderPdfInsight(s);
      else if (s.tipo === 'lista') renderPdfOpportunity(s);
      else if (s.tipo === 'passos') renderPdfPlan(s);
      else if (s.tipo === 'visual') renderPdfVisual(s);
    }
    if (!mod.secoes.length) linhasComFluxo(linhasDe('Esta apresentação ainda não tem conteúdo além da capa.'));
    // última página quase vazia só com o fim de uma seção é aceitável; página TOTALMENTE vazia, não
    if (internas.length > 1 && y >= H - M.topo - 0.5) { doc.removePage(doc.getPageCount() - 1); internas.pop(); }

    etapa('finalizando');
    renderPdfFooter();
    const bytes = await doc.save({ useObjectStreams: false });
    return { bytes, paginas: internas.length + 1, nomeArquivo: nomeArquivo(empresa), textos };
  }

  return { gerar, nomeArquivo, _internos: { quebrar, limpo, luminancia } };
}));
