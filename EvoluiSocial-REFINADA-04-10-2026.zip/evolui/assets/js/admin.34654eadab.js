!(function () {
  "use strict";
  var e = window.supabase.createClient(
      "https://aligftypgtzlymmditeo.supabase.co",
      "sb_publishable_lLKYguXwi6isaw1C4X5uiA_25-MT7ym",
    ),
    a = {
      hero: {
        eyebrow: "Branding e marketing — Petrolina, PE · Vale do São Francisco",
        title: "Marcas que são percebidas antes de serem escolhidas.",
        lead: "A Felipe Branding cuida de posicionamento, identidade visual e comunicação de empresas de Petrolina, Juazeiro e do Vale do São Francisco. Marketing e conteúdo entram como ferramentas para gerar percepção e decisão.",
        ctaPrimary: "Conhecer a consultoria gratuita",
        ctaSecondary: "Conhecer a Felipe Branding",
        stat1Num: 10,
        stat1Label: "Anos no digital",
        stat2Num: 6,
        stat2Label: "Frentes de atuação",
        stat3Num: 100,
        stat3Label: "% direção estratégica",
        videoUrl: "",
      },
      about: {
        eyebrow: "Sobre a Felipe Branding",
        title: "Uma marca nasceu para guiar, não para decorar.",
        p1: 'Desde 2015 transformando ideias em materialização visual e audiovisual, venho construindo uma forma própria de olhar para marcas: menos sobre "ficar bonito", mais sobre comunicar com clareza quem você é e para onde vai.',
        p2: "Passando por diferentes plataformas e formatos, desenvolvi domínio real em design gráfico, produção audiovisual e gestão de redes sociais — e uni tudo isso sob um mesmo teto: a Felipe Branding.",
        p3: 'O símbolo da marca — um "b" com uma estrela de quatro pontas vazada no centro — representa exatamente essa proposta: iluminação, direção e diferenciação. Cada projeto carrega esse compromisso.',
        founderLabel: "Felipe Souto — Fundador",
        values: [
          {
            title: "Simplicidade Estratégica",
            desc: "Decisões visuais que servem a um objetivo claro, sem ruído.",
          },
          {
            title: "Identidade Autêntica",
            desc: "Marca como extensão real de quem você é — nunca um molde genérico.",
          },
          {
            title: "Sofisticação Funcional",
            desc: "Estética refinada que também funciona no dia a dia do negócio.",
          },
          {
            title: "Inovação com Propósito",
            desc: "Criatividade a serviço de um resultado, não de uma tendência.",
          },
        ],
      },
      services: [
        {
          title: "Branding",
          desc: "Construção ou revisão da marca como um todo: o que ela promete, como fala e como quer ser lembrada.",
          tags: "Plataforma de marca, Naming, Arquitetura de marca",
          icon: "star4",
        },
        {
          title: "Identidade Visual",
          desc: "Logotipo, paleta, tipografia e manual de aplicação: o sistema visual que faz a marca ser reconhecida em qualquer ponto de contato.",
          tags: "Logotipo, Paleta, Manual de marca",
          icon: "layers",
        },
        {
          title: "Posicionamento",
          desc: "Para quem a marca é, com quem ela compete e por que deveria ser escolhida — definido antes de qualquer peça ser criada.",
          tags: "Público, Diferenciação, Proposta de valor",
          icon: "target",
        },
        {
          title: "Estratégia de Marca",
          desc: "Tom de voz, mensagens-chave e direção criativa que orientam todas as decisões de comunicação.",
          tags: "Tom de voz, Mensagens, Direção criativa",
          icon: "compass",
        },
        {
          title: "Conteúdo",
          desc: "Design gráfico, vídeo e peças para redes sociais que traduzem a estratégia no que as pessoas veem todos os dias.",
          tags: "Redes sociais, Vídeo, Design gráfico",
          icon: "spark",
        },
        {
          title: "Marketing",
          desc: "Presença digital, calendário editorial e ações que levam a percepção construída até o contato e a venda.",
          tags: "Presença digital, Calendário, Conversão",
          icon: "trend",
        },
      ],
      process: [
        {
          title: "Posicionamento",
          desc: "Entendemos o negócio, o público e a concorrência para definir o lugar que a marca deve ocupar.",
          deliver: "Diagnóstico e posicionamento definido",
        },
        {
          title: "Identidade",
          desc: "Traduzimos o posicionamento em um sistema visual e verbal coerente.",
          deliver: "Identidade visual e tom de voz",
        },
        {
          title: "Conteúdo",
          desc: "Planejamos e produzimos o que a marca vai dizer e mostrar, com um objetivo claro em cada peça.",
          deliver: "Linha editorial e peças produzidas",
        },
        {
          title: "Experiência",
          desc: "Cuidamos para que cada ponto de contato — perfil, site, atendimento, material impresso — conte a mesma história.",
          deliver: "Pontos de contato alinhados",
        },
        {
          title: "Prova",
          desc: "Organizamos evidências reais — trabalhos, resultados e relatos de clientes — que sustentam o que a marca promete.",
          deliver: "Portfólio e provas organizados",
        },
        {
          title: "Decisão",
          desc: "Com percepção construída e prova visível, o caminho até o contato e a compra fica mais curto.",
          deliver: "Caminho claro até o contato",
        },
      ],
      portfolioIntro: {
        eyebrow: "Trabalhos",
        title: "Estudos de caso, não apenas imagens bonitas.",
        desc: "Filtre por tipo de projeto ou pesquise por palavra-chave.",
      },
      portfolio: [
        {
          category: "identidade",
          categoryLabel: "Identidade Visual",
          title: "Sistema de marca — clínica de estética",
          desc: "Naming, logotipo e paleta para reposicionamento premium.",
          image: "",
        },
        {
          category: "social",
          categoryLabel: "Social Media",
          title: "Calendário editorial — moda autoral",
          desc: "Estratégia de conteúdo e identidade de feed.",
          image: "",
        },
        {
          category: "video",
          categoryLabel: "Vídeo",
          title: "Institucional — negócio local",
          desc: "Roteiro, captação e motion para vídeo de apresentação.",
          image: "",
        },
        {
          category: "identidade",
          categoryLabel: "Identidade Visual",
          title: "Rebranding — food service",
          desc: "Reconstrução completa de marca e aplicação em embalagens.",
          image: "",
        },
        {
          category: "social",
          categoryLabel: "Social Media",
          title: "Gestão de presença — consultoria",
          desc: "Direção de conteúdo e crescimento de engajamento.",
          image: "",
        },
        {
          category: "video",
          categoryLabel: "Vídeo",
          title: "Reels de lançamento — produto digital",
          desc: "Série de vídeos curtos para campanha de lançamento.",
          image: "",
        },
      ],
      diff: {
        eyebrow: "Diferenciais",
        title: "O que muda quando existe direção estratégica.",
      },
      testimonialsIntro: {
        eyebrow: "Depoimentos",
        title: "Palavra de quem já passou pelo processo.",
      },
      testimonials: [
        {
          quote:
            "Antes eu tinha uma logo. Depois do trabalho com a Felipe Branding, passei a ter uma marca que meus clientes reconhecem antes mesmo de eu falar o nome do negócio.",
          name: "Mariana R.",
          role: "Empreendedora, setor de estética",
        },
        {
          quote:
            "O processo de imersão foi o que mais me surpreendeu. Senti que a estratégia veio antes do design — e isso mudou completamente o resultado final.",
          name: "Lucas C.",
          role: "Fundador, marca de indumentária",
        },
        {
          quote:
            "Os vídeos de reposicionamento aumentaram nosso engajamento de forma visível já nas primeiras semanas. Direção clara, entrega no prazo.",
          name: "Paula A.",
          role: "Gestora de marketing",
        },
      ],
      faqIntro: {
        eyebrow: "Dúvidas frequentes",
        title: "Perguntas que ajudam antes de fechar.",
      },
      faq: [
        {
          q: "Quanto tempo leva um projeto de identidade visual?",
          a: "Em média de 3 a 5 semanas, dependendo da complexidade e da agilidade nas rodadas de feedback. Projetos que envolvem apenas peças gráficas avulsas costumam ser mais rápidos.",
        },
        {
          q: "Preciso já ter logotipo pronto para contratar?",
          a: "Não. Muitos projetos começam do zero, ainda na fase de imersão e estratégia, antes de qualquer elemento visual existir.",
        },
        {
          q: "Como funciona o orçamento?",
          a: "Cada projeto é orçado conforme escopo e prazo. Preencha o formulário de contato com a faixa de investimento estimada e você recebe uma proposta personalizada.",
        },
        {
          q: "Vocês atendem clientes fora de Petrolina?",
          a: "Sim, o atendimento é 100% remoto e cobre todo o Brasil, com reuniões por vídeo-chamada nas etapas-chave do processo.",
        },
        {
          q: "Existe suporte depois da entrega final?",
          a: "Sim. Todo projeto inclui um período de acompanhamento pós-entrega para ajustes de aplicação e dúvidas de uso do material.",
        },
      ],
      cta: {
        eyebrow: "Consultoria gratuita",
        title: "Comece pelo diagnóstico da sua marca.",
        desc: "Receba uma leitura estratégica do seu perfil no Instagram, sem custo. Se fizer sentido, a gente conversa sobre o próximo passo.",
        note: "Leva menos de 2 minutos. Sem compromisso.",
      },
      contactIntro: {
        eyebrow: "Contato",
        title: "Conte um pouco sobre o seu projeto.",
        desc: "Responda o formulário e retornamos em até 1 dia útil — ou fale agora mesmo pelo WhatsApp.",
      },
      contact: {
        whatsapp: "5587981798483",
        whatsappDisplay: "(87) 98179-8483",
        email: "contato@felipebranding.com.br",
        address: "Petrolina, PE — Vale do São Francisco, com atendimento remoto para todo o Brasil",
        hours: "Segunda a sexta, 9h às 18h",
        instagram: "",
        linkedin: "",
        behance: "",
      },
      footer: {
        desc: "Branding, posicionamento, identidade visual e marketing. Petrolina (PE), Vale do São Francisco — atendimento remoto para todo o Brasil.",
      },
    };
  // 29/09 — AUDITORIA: se o conteúdo do banco não carregar (rede, bloqueador,
  // sessão), o editor antes abria com o conteúdo PADRÃO e o primeiro
  // "Salvar" sobrescrevia o site publicado inteiro com ele. Agora o editor
  // fica travado (somente leitura) até carregar de verdade.
  var podeSalvar = !1,
    sujo = !1,
    seqCampo = 0;
  function marcarSujo() {
    sujo = !0;
  }
  window.addEventListener("beforeunload", function (ev) {
    if (sujo) {
      ev.preventDefault();
      ev.returnValue = "";
    }
  });
  // Só aceita imagem de http(s), caminho do próprio site ou data:image.
  function urlImagemValida(u) {
    return !u || /^https?:\/\//i.test(u) || /^\/(?!\/)/.test(u) || /^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,/i.test(u);
  }
  function t(e) {
    return JSON.parse(JSON.stringify(e));
  }
  function o(e) {
    return e && "object" == typeof e && !Array.isArray(e);
  }
  function n(e, a) {
    return a
      ? (Object.keys(a).forEach(function (t) {
          Array.isArray(a[t])
            ? (e[t] = a[t])
            : o(a[t]) && o(e[t])
              ? n(e[t], a[t])
              : (e[t] = a[t]);
        }),
        e)
      : e;
  }
  function i(a) {
    if (!podeSalvar)
      return Promise.reject(
        new Error(
          "o conteúdo atual do site ainda não foi carregado — salvar agora apagaria o que está publicado. Recarregue a página.",
        ),
      );
    return e
      .from("site_content")
      .update({ content: a })
      .eq("id", 1)
      .select()
      .then(function (e) {
        if (e.error) throw e.error;
        if (!e.data || 0 === e.data.length)
          throw new Error(
            "Nenhuma linha foi alterada — rode o SQL de configuração no Supabase (se ainda não rodou) e confirme que seu usuário está cadastrado na tabela admins.",
          );
        return ((sujo = !1), !0);
      });
  }
  var r = t(a);
  function d(e) {
    var a = document.getElementById("toast");
    ((a.textContent = e),
      a.classList.add("is-visible"),
      clearTimeout(a._timer),
      (a._timer = setTimeout(function () {
        a.classList.remove("is-visible");
      }, 2600)));
  }
  var s = document.getElementById("gate"),
    c = document.getElementById("shell"),
    l = document.getElementById("gateEmail"),
    u = document.getElementById("gatePassword"),
    m =
      (document.getElementById("gateTitle"),
      document.getElementById("gateSubtitle"),
      document.getElementById("gateError")),
    p = document.getElementById("gateSubmit");
  function v(e) {
    ((m.textContent = e), (m.style.display = "block"));
  }
  function f() {
    ((m.style.display = "none"),
      l.value && u.value
        ? ((p.disabled = !0),
          (p.textContent = "Entrando…"),
          e.auth
            .signInWithPassword({ email: l.value, password: u.value })
            .then(function (e) {
              if (e.error) throw e.error;
              g();
            })
            .catch(function (e) {
              v(
                e && "Invalid login credentials" === e.message
                  ? "E-mail ou senha incorretos."
                  : "Não foi possível entrar: " +
                      (e && e.message ? e.message : "tente novamente."),
              );
            })
            .then(function () {
              ((p.disabled = !1), (p.textContent = "Entrar"));
            }))
        : v("Preencha e-mail e senha."));
  }
  function erroCarga() {
    var area = document.getElementById("mainArea");
    ((document.getElementById("sideNav").innerHTML = ""),
      (area.innerHTML =
        '<section class="panel is-active"><div class="load-error" role="alert"><h2>Não foi possível carregar o conteúdo do site</h2><p>Para não apagar nada do que está publicado, a edição fica bloqueada até o conteúdo carregar. Verifique a internet (ou desative bloqueadores de anúncio para este site) e tente de novo.</p><button type="button" class="btn btn-primary" id="retryLoadBtn">Tentar novamente</button></div></section>'),
      document.getElementById("retryLoadBtn").addEventListener("click", g));
  }
  function g() {
    var o;
    ((s.style.display = "none"),
      c.classList.add("is-active"),
      ((o = t(a)),
      e
        .from("site_content")
        .select("content")
        .eq("id", 1)
        .single()
        .then(function (e) {
          if (e.error) throw e.error;
          return ((podeSalvar = !0), e.data && e.data.content ? n(o, e.data.content) : o);
        })
        .catch(function (e) {
          return (
            console.warn(
              "Não foi possível carregar o conteúdo do Supabase.",
              e,
            ),
            (podeSalvar = !1),
            null
          );
        })).then(function (e) {
        if (!e) return erroCarga();
        ((r = e), (sujo = !1), h());
      }));
  }
  (document.getElementById("gateForm").addEventListener("submit", function (ev) {
    (ev.preventDefault(), p.disabled || f());
  }),
    document.getElementById("lockBtn").addEventListener("click", function () {
      if (
        sujo &&
        !confirm("Há alterações que ainda não foram salvas. Sair mesmo assim?")
      )
        return;
      ((sujo = !1), (podeSalvar = !1));
      e.auth.signOut().then(function () {
        (c.classList.remove("is-active"),
          (s.style.display = "flex"),
          (l.value = ""),
          (u.value = ""));
      });
    }),
    e.auth.getSession().then(function (e) {
      e.data && e.data.session && g();
    }));
  var b = [
    { id: "hero", label: "Hero (abertura)" },
    { id: "about", label: "Sobre" },
    { id: "services", label: "Serviços" },
    { id: "process", label: "Processo" },
    { id: "portfolio", label: "Portfólio" },
    { id: "testimonials", label: "Depoimentos" },
    { id: "faq", label: "FAQ" },
    { id: "cta", label: "Chamada final (CTA)" },
    { id: "contact", label: "Contato" },
    { id: "footer", label: "Rodapé" },
  ];
  function h() {
    var e,
      a = document.getElementById("sideNav");
    ((a.innerHTML = b
      .map(function (e, a) {
        return (
          '<button type="button" data-panel="' +
          e.id +
          '" aria-controls="panel-' +
          e.id +
          '"' +
          (0 === a ? ' aria-current="true"' : "") +
          ' class="' +
          (0 === a ? "is-active" : "") +
          '">' +
          e.label +
          "</button>"
        );
      })
      .join("")),
      (document.getElementById("mainArea").innerHTML = b
        .map(function (e, a) {
          return (
            '<section class="panel' +
            (0 === a ? " is-active" : "") +
            '" id="panel-' +
            e.id +
            '" aria-label="' +
            e.label +
            '"></section>'
          );
        })
        .join("")),
      a.querySelectorAll("button").forEach(function (e) {
        e.addEventListener("click", function () {
          (a.querySelectorAll("button").forEach(function (e) {
            (e.classList.remove("is-active"), e.removeAttribute("aria-current"));
          }),
            e.classList.add("is-active"),
            e.setAttribute("aria-current", "true"),
            window.matchMedia("(max-width: 860px)").matches &&
              document.getElementById("mainArea").scrollIntoView({ block: "start" }),
            document.querySelectorAll(".panel").forEach(function (e) {
              e.classList.remove("is-active");
            }),
            document
              .getElementById("panel-" + e.getAttribute("data-panel"))
              .classList.add("is-active"));
        });
      }),
      (function () {
        var e = document.getElementById("panel-hero");
        ((e.innerHTML = ""),
          E(
            e,
            "Hero (abertura)",
            "O primeiro bloco que o visitante vê ao abrir o site.",
            function () {},
          ));
        var a = r.hero;
        (y(
          e,
          "Texto pequeno acima do título (eyebrow)",
          a.eyebrow,
          function (e) {
            a.eyebrow = e;
          },
        ),
          y(
            e,
            "Título principal",
            a.title,
            function (e) {
              a.title = e;
            },
            { textarea: !0 },
          ),
          y(
            e,
            "Texto de apoio (parágrafo)",
            a.lead,
            function (e) {
              a.lead = e;
            },
            { textarea: !0 },
          ));
        var t = document.createElement("div");
        ((t.className = "grid2"),
          e.appendChild(t),
          y(t, "Texto do botão principal", a.ctaPrimary, function (e) {
            a.ctaPrimary = e;
          }),
          y(t, "Texto do botão secundário", a.ctaSecondary, function (e) {
            a.ctaSecondary = e;
          }));
        var o = document.createElement("div");
        ((o.className = "grid2"), e.appendChild(o));
        var n = document.createElement("div");
        (o.appendChild(n),
          y(
            n,
            "Estatística 1 — número",
            a.stat1Num,
            function (e) {
              a.stat1Num = e;
            },
            { number: !0 },
          ),
          y(n, "Estatística 1 — legenda", a.stat1Label, function (e) {
            a.stat1Label = e;
          }));
        var i = document.createElement("div");
        (o.appendChild(i),
          y(
            i,
            "Estatística 2 — número",
            a.stat2Num,
            function (e) {
              a.stat2Num = e;
            },
            { number: !0 },
          ),
          y(i, "Estatística 2 — legenda", a.stat2Label, function (e) {
            a.stat2Label = e;
          }));
        var d = document.createElement("div");
        (o.appendChild(d),
          y(
            d,
            "Estatística 3 — número",
            a.stat3Num,
            function (e) {
              a.stat3Num = e;
            },
            { number: !0 },
          ),
          y(d, "Estatística 3 — legenda", a.stat3Label, function (e) {
            a.stat3Label = e;
          }),
          y(
            e,
            "Vídeo de destaque (opcional)",
            a.videoUrl,
            function (e) {
              a.videoUrl = e;
            },
            {
              placeholder: "Link do YouTube, Vimeo ou um .mp4",
              hint: "Se preenchido, substitui a animação do símbolo no hero por este vídeo incorporado. Deixe em branco para manter a animação padrão.",
            },
          ));
      })(),
      (function () {
        var e = document.getElementById("panel-about");
        ((e.innerHTML = ""),
          E(
            e,
            "Sobre",
            "Texto institucional e os 4 valores da marca.",
            function () {},
          ));
        var a = r.about;
        (y(e, "Texto pequeno (eyebrow)", a.eyebrow, function (e) {
          a.eyebrow = e;
        }),
          y(
            e,
            "Título da seção",
            a.title,
            function (e) {
              a.title = e;
            },
            { textarea: !0 },
          ),
          y(
            e,
            "Parágrafo 1",
            a.p1,
            function (e) {
              a.p1 = e;
            },
            { textarea: !0 },
          ),
          y(
            e,
            "Parágrafo 2",
            a.p2,
            function (e) {
              a.p2 = e;
            },
            { textarea: !0 },
          ),
          y(
            e,
            "Parágrafo 3",
            a.p3,
            function (e) {
              a.p3 = e;
            },
            { textarea: !0 },
          ),
          y(e, "Legenda sob a imagem/símbolo", a.founderLabel, function (e) {
            a.founderLabel = e;
          }));
        var t = document.createElement("h3");
        ((t.style.margin = "22px 0 10px"),
          (t.style.fontSize = "1.05rem"),
          (t.textContent = "Valores da marca"),
          e.appendChild(t),
          a.values.forEach(function (a, t) {
            var o = document.createElement("div");
            ((o.className = "card"), e.appendChild(o));
            var n = document.createElement("div");
            ((n.className = "card-head"),
              (n.innerHTML = "<span>Valor " + (t + 1) + "</span>"),
              o.appendChild(n),
              y(o, "Título", a.title, function (e) {
                a.title = e;
              }),
              y(
                o,
                "Descrição",
                a.desc,
                function (e) {
                  a.desc = e;
                },
                { textarea: !0 },
              ));
          }));
      })(),
      (e = ["star4", "layers", "target", "compass", "spark", "trend", "arrows-h"]),
      L(
        "panel-services",
        "Serviços",
        "As frentes de serviço exibidas no site.",
        "services",
        function () {
          return { title: "Novo serviço", desc: "", tags: "", icon: "spark" };
        },
        function (a, t) {
          (y(a, "Título", t.title, function (e) {
            t.title = e;
          }),
            y(
              a,
              "Descrição",
              t.desc,
              function (e) {
                t.desc = e;
              },
              { textarea: !0 },
            ),
            y(a, "Tags (separadas por vírgula)", t.tags, function (e) {
              t.tags = e;
            }));
          var o = document.createElement("div");
          ((o.className = "field"), a.appendChild(o));
          var n = document.createElement("label");
          ((n.textContent = "Ícone"), o.appendChild(n));
          var i = document.createElement("select");
          ((i.id = "campo-" + ++seqCampo), (n.htmlFor = i.id));
          (e.forEach(function (e) {
            var a = document.createElement("option");
            ((a.value = e),
              (a.textContent = e),
              e === t.icon && (a.selected = !0),
              i.appendChild(a));
          }),
            i.addEventListener("change", function () {
              t.icon = i.value;
            }),
            o.appendChild(i));
        },
      ),
      L(
        "panel-process",
        "Processo",
        "As etapas do seu processo de trabalho, em ordem.",
        "process",
        function () {
          return { title: "Nova etapa", desc: "", deliver: "" };
        },
        function (e, a) {
          (y(e, "Título da etapa", a.title, function (e) {
            a.title = e;
          }),
            y(
              e,
              "Descrição",
              a.desc,
              function (e) {
                a.desc = e;
              },
              { textarea: !0 },
            ),
            y(e, "O que é entregue", a.deliver, function (e) {
              a.deliver = e;
            }));
        },
      ),
      (function () {
        var e = document.getElementById("panel-portfolio");
        ((e.innerHTML = ""),
          E(
            e,
            "Portfólio",
            "Introdução da seção e os cases exibidos.",
            function () {},
          ));
        var a = r.portfolioIntro;
        (y(e, "Texto pequeno (eyebrow)", a.eyebrow, function (e) {
          a.eyebrow = e;
        }),
          y(
            e,
            "Título da seção",
            a.title,
            function (e) {
              a.title = e;
            },
            { textarea: !0 },
          ),
          y(
            e,
            "Descrição",
            a.desc,
            function (e) {
              a.desc = e;
            },
            { textarea: !0 },
          ));
        var t = document.createElement("div");
        e.appendChild(t);
        var o = [
          ["identidade", "Identidade Visual"],
          ["social", "Social Media"],
          ["video", "Vídeo"],
        ];
        function n() {
          ((t.innerHTML = ""),
            r.portfolio.forEach(function (e, a) {
              var i = document.createElement("div");
              ((i.className = "card"), t.appendChild(i));
              var d = document.createElement("div");
              ((d.className = "card-head"),
                (d.innerHTML = "<span>Case " + (a + 1) + "</span>"));
              var s = document.createElement("button");
              ((s.className = "remove-btn"),
                (s.textContent = "Remover"),
                s.addEventListener("click", function () {
                  (r.portfolio.splice(a, 1), n());
                }),
                d.appendChild(s),
                i.appendChild(d));
              var c = document.createElement("div");
              ((c.className = "field"), i.appendChild(c));
              var l = document.createElement("label");
              ((l.textContent = "Categoria"), c.appendChild(l));
              var u = document.createElement("select");
              (o.forEach(function (a) {
                var t = document.createElement("option");
                ((t.value = a[0]),
                  (t.textContent = a[1]),
                  a[0] === e.category && (t.selected = !0),
                  u.appendChild(t));
              }),
                u.addEventListener("change", function () {
                  ((e.category = u.value),
                    (e.categoryLabel = o.find(function (e) {
                      return e[0] === u.value;
                    })[1]));
                }),
                c.appendChild(u),
                y(i, "Título do case", e.title, function (a) {
                  e.title = a;
                }),
                y(
                  i,
                  "Descrição",
                  e.desc,
                  function (a) {
                    e.desc = a;
                  },
                  { textarea: !0 },
                ),
                C(i, "Imagem do case", e.image, function (a) {
                  e.image = a;
                }));
            }));
          var e = document.createElement("button");
          ((e.className = "add-btn"),
            (e.textContent = "+ Adicionar case"),
            e.addEventListener("click", function () {
              (r.portfolio.push({
                category: "identidade",
                categoryLabel: "Identidade Visual",
                title: "Novo case",
                desc: "",
                image: "",
              }),
                n());
            }),
            t.appendChild(e));
        }
        n();
      })(),
      (function () {
        var e = document.getElementById("panel-testimonials");
        ((e.innerHTML = ""),
          E(
            e,
            "Depoimentos",
            "Introdução da seção e os depoimentos exibidos no carrossel.",
            function () {},
          ));
        var a = r.testimonialsIntro;
        (y(e, "Texto pequeno (eyebrow)", a.eyebrow, function (e) {
          a.eyebrow = e;
        }),
          y(e, "Título da seção", a.title, function (e) {
            a.title = e;
          }));
        var t = document.createElement("div");
        function o() {
          ((t.innerHTML = ""),
            r.testimonials.forEach(function (e, a) {
              var n = document.createElement("div");
              ((n.className = "card"), t.appendChild(n));
              var i = document.createElement("div");
              ((i.className = "card-head"),
                (i.innerHTML = "<span>Depoimento " + (a + 1) + "</span>"));
              var d = document.createElement("button");
              ((d.className = "remove-btn"),
                (d.textContent = "Remover"),
                d.addEventListener("click", function () {
                  (r.testimonials.splice(a, 1), o());
                }),
                i.appendChild(d),
                n.appendChild(i),
                y(
                  n,
                  "Depoimento",
                  e.quote,
                  function (a) {
                    e.quote = a;
                  },
                  { textarea: !0 },
                ));
              var s = document.createElement("div");
              ((s.className = "grid2"),
                n.appendChild(s),
                y(s, "Nome", e.name, function (a) {
                  e.name = a;
                }),
                y(s, "Cargo / negócio", e.role, function (a) {
                  e.role = a;
                }));
            }));
          var e = document.createElement("button");
          ((e.className = "add-btn"),
            (e.textContent = "+ Adicionar depoimento"),
            e.addEventListener("click", function () {
              (r.testimonials.push({ quote: "", name: "", role: "" }), o());
            }),
            t.appendChild(e));
        }
        (e.appendChild(t), o());
      })(),
      (function () {
        var e = document.getElementById("panel-faq");
        ((e.innerHTML = ""),
          E(
            e,
            "FAQ",
            "Perguntas frequentes exibidas em acordeão.",
            function () {},
          ));
        var a = r.faqIntro;
        (y(e, "Texto pequeno (eyebrow)", a.eyebrow, function (e) {
          a.eyebrow = e;
        }),
          y(e, "Título da seção", a.title, function (e) {
            a.title = e;
          }));
        var t = document.createElement("div");
        function o() {
          ((t.innerHTML = ""),
            r.faq.forEach(function (e, a) {
              var n = document.createElement("div");
              ((n.className = "card"), t.appendChild(n));
              var i = document.createElement("div");
              ((i.className = "card-head"),
                (i.innerHTML = "<span>Pergunta " + (a + 1) + "</span>"));
              var d = document.createElement("button");
              ((d.className = "remove-btn"),
                (d.textContent = "Remover"),
                d.addEventListener("click", function () {
                  (r.faq.splice(a, 1), o());
                }),
                i.appendChild(d),
                n.appendChild(i),
                y(n, "Pergunta", e.q, function (a) {
                  e.q = a;
                }),
                y(
                  n,
                  "Resposta",
                  e.a,
                  function (a) {
                    e.a = a;
                  },
                  { textarea: !0 },
                ));
            }));
          var e = document.createElement("button");
          ((e.className = "add-btn"),
            (e.textContent = "+ Adicionar pergunta"),
            e.addEventListener("click", function () {
              (r.faq.push({ q: "", a: "" }), o());
            }),
            t.appendChild(e));
        }
        (e.appendChild(t), o());
      })(),
      (function () {
        var e = document.getElementById("panel-cta");
        ((e.innerHTML = ""),
          E(
            e,
            "Chamada final (CTA)",
            "O bloco de destaque antes do formulário de contato.",
            function () {},
          ));
        var a = r.cta;
        (y(e, "Texto pequeno (eyebrow)", a.eyebrow, function (e) {
          a.eyebrow = e;
        }),
          y(
            e,
            "Título",
            a.title,
            function (e) {
              a.title = e;
            },
            { textarea: !0 },
          ),
          y(
            e,
            "Descrição",
            a.desc,
            function (e) {
              a.desc = e;
            },
            { textarea: !0 },
          ),
          y(e, "Nota abaixo dos botões", a.note, function (e) {
            a.note = e;
          }));
      })(),
      (function () {
        var e = document.getElementById("panel-contact");
        ((e.innerHTML = ""),
          E(
            e,
            "Contato",
            "Dados de contato, redes sociais e texto da seção.",
            function () {},
          ));
        var a = r.contactIntro;
        (y(e, "Texto pequeno (eyebrow)", a.eyebrow, function (e) {
          a.eyebrow = e;
        }),
          y(e, "Título da seção", a.title, function (e) {
            a.title = e;
          }),
          y(
            e,
            "Descrição",
            a.desc,
            function (e) {
              a.desc = e;
            },
            { textarea: !0 },
          ));
        var t = r.contact,
          o = document.createElement("div");
        ((o.className = "grid2"),
          e.appendChild(o),
          y(
            o,
            "WhatsApp (só números, com DDI+DDD)",
            t.whatsapp,
            function (e) {
              t.whatsapp = e;
            },
            { placeholder: "5587981798483" },
          ),
          y(
            o,
            "WhatsApp (formatado para exibir)",
            t.whatsappDisplay,
            function (e) {
              t.whatsappDisplay = e;
            },
            { placeholder: "(87) 98179-8483" },
          ),
          y(e, "E-mail", t.email, function (e) {
            t.email = e;
          }),
          y(e, "Endereço / região de atendimento", t.address, function (e) {
            t.address = e;
          }),
          y(e, "Horário de atendimento", t.hours, function (e) {
            t.hours = e;
          }));
        var n = document.createElement("div");
        ((n.className = "grid2"),
          e.appendChild(n),
          y(
            n,
            "Instagram (URL completa)",
            t.instagram,
            function (e) {
              t.instagram = e;
            },
            {
              placeholder: "https://instagram.com/seuusuario",
              hint: "Deixe em branco para ocultar o ícone no site.",
            },
          ),
          y(
            n,
            "LinkedIn (URL completa)",
            t.linkedin,
            function (e) {
              t.linkedin = e;
            },
            {
              placeholder: "https://linkedin.com/in/seuusuario",
              hint: "Deixe em branco para ocultar o ícone no site.",
            },
          ),
          y(
            e,
            "Behance (URL completa)",
            t.behance,
            function (e) {
              t.behance = e;
            },
            {
              placeholder: "https://behance.net/seuusuario",
              hint: "Deixe em branco para ocultar o ícone no site.",
            },
          ));
      })(),
      (function () {
        var e = document.getElementById("panel-footer");
        ((e.innerHTML = ""),
          E(
            e,
            "Rodapé",
            "Texto curto exibido junto à logo no rodapé.",
            function () {},
          ));
        var a = r.footer;
        y(
          e,
          "Descrição curta",
          a.desc,
          function (e) {
            a.desc = e;
          },
          { textarea: !0 },
        );
      })());
  }
  function E(e, a, t, o) {
    var n = document.createElement("div");
    ((n.className = "panel-head"),
      (n.innerHTML = "<div><h2>" + a + "</h2><p>" + t + "</p></div>"));
    var s = document.createElement("div"),
      c = document.createElement("button");
    ((c.className = "btn btn-primary"), (c.textContent = "Salvar seção"));
    var l = document.createElement("div");
    ((l.className = "save-status"),
      (l.textContent = "Salvo ✓"),
      c.addEventListener("click", function () {
        (o(), (c.disabled = !0));
        var e = c.textContent;
        ((c.textContent = "Salvando…"),
          i(r)
            .then(function () {
              (l.classList.add("is-visible"),
                setTimeout(function () {
                  l.classList.remove("is-visible");
                }, 1800),
                d("Alterações salvas e já publicadas no site."));
            })
            .catch(function (e) {
              d(
                "Não foi possível salvar: " +
                  (e && e.message
                    ? e.message
                    : "você pode não ter permissão para editar."),
              );
            })
            .then(function () {
              ((c.disabled = !1), (c.textContent = e));
            }));
      }),
      s.appendChild(c),
      s.appendChild(l),
      n.appendChild(s),
      e.appendChild(n));
  }
  function y(e, a, t, o, n) {
    n = n || {};
    var i = document.createElement("div");
    i.className = "field";
    var r = document.createElement("label");
    r.textContent = a;
    var d = document.createElement(n.textarea ? "textarea" : "input");
    ((d.id = "campo-" + ++seqCampo), (r.htmlFor = d.id));
    if (
      (n.textarea || (d.type = n.type || "text"),
      (d.value = t || ""),
      n.placeholder && (d.placeholder = n.placeholder),
      d.addEventListener("input", function () {
        (marcarSujo(), o(n.number ? parseFloat(d.value) || 0 : d.value));
      }),
      i.appendChild(r),
      i.appendChild(d),
      e.appendChild(i),
      n.hint)
    ) {
      var s = document.createElement("p");
      ((s.className = "hint"), (s.textContent = n.hint), i.appendChild(s));
    }
    return i;
  }
  function C(e, a, t, o, n) {
    var i = document.createElement("div");
    i.className = "field";
    var r = document.createElement("label");
    ((r.textContent = a), i.appendChild(r));
    var s = document.createElement("div");
    s.className = "img-field";
    var c = document.createElement("img");
    ((c.className = "img-preview"),
      (c.alt = "Pré-visualização: " + a),
      (c.src = t || ""),
      (c.style.display = t ? "block" : "none"));
    var l = document.createElement("div");
    l.className = "img-inputs";
    var u = document.createElement("input");
    ((u.type = "url"),
      (u.id = "campo-" + ++seqCampo),
      (r.htmlFor = u.id),
      (u.placeholder = "Cole a URL da imagem (https://…)"),
      (u.value = t && 0 === t.indexOf("data:") ? "" : t || ""));
    var erroUrl = document.createElement("p");
    ((erroUrl.className = "hint hint-erro"),
      (erroUrl.hidden = !0),
      (erroUrl.textContent = "Use um link que comece com https:// — esse endereço não será salvo."));
    var m = document.createElement("input");
    ((m.type = "file"), (m.accept = "image/*"), (m.style.display = "none"));
    var p = document.createElement("button");
    ((p.type = "button"),
      (p.className = "file-btn"),
      (p.textContent = "ou enviar arquivo do computador"),
      p.addEventListener("click", function () {
        m.click();
      }),
      u.addEventListener("input", function () {
        var ok = urlImagemValida(u.value.trim());
        ((erroUrl.hidden = ok), u.setAttribute("aria-invalid", ok ? "false" : "true"));
        if (!ok) return;
        ((c.src = u.value.trim()),
          (c.style.display = u.value ? "block" : "none"),
          marcarSujo(),
          o(u.value.trim()));
      }),
      m.addEventListener("change", function () {
        var e = m.files[0];
        if (e) {
          // A imagem enviada vira texto dentro do conteúdo do site, que TODO
          // visitante baixa ao abrir a página — arquivo grande deixa o site lento.
          if (e.size > 1048576)
            return (
              d("Imagem acima de 1 MB — comprima (ex.: squoosh.app) ou use um link hospedado."),
              void (m.value = "")
            );
          e.size > 358400 &&
            d("Imagem grande (acima de 350 KB) — o site pode ficar mais lento. Prefira comprimir.");
          var a = new FileReader();
          ((a.onload = function () {
            ((u.value = ""),
              (erroUrl.hidden = !0),
              (c.src = a.result),
              (c.style.display = "block"),
              marcarSujo(),
              o(a.result));
          }),
            a.readAsDataURL(e));
        }
      }),
      l.appendChild(u),
      l.appendChild(erroUrl),
      l.appendChild(p));
    var v = document.createElement("p");
    ((v.className = "hint"),
      (v.textContent =
        n ||
        "Aceita link de imagem já hospedada ou upload direto (arquivos pequenos)."),
      l.appendChild(v),
      s.appendChild(c),
      s.appendChild(l),
      i.appendChild(s),
      e.appendChild(i));
  }
  function L(e, a, t, o, n, i) {
    var d = document.getElementById(e);
    ((d.innerHTML = ""), E(d, a, t, function () {}));
    var s = document.createElement("div");
    (d.appendChild(s),
      (function e() {
        ((s.innerHTML = ""),
          r[o].forEach(function (a, t) {
            var n = document.createElement("div");
            ((n.className = "card"), s.appendChild(n));
            var d = document.createElement("div");
            ((d.className = "card-head"),
              (d.innerHTML = "<span>Item " + (t + 1) + "</span>"));
            var c = document.createElement("button");
            ((c.className = "remove-btn"),
              (c.textContent = "Remover"),
              c.addEventListener("click", function () {
                (marcarSujo(), r[o].splice(t, 1), e());
              }),
              d.appendChild(c),
              n.appendChild(d),
              i(n, a));
          }));
        var a = document.createElement("button");
        ((a.className = "add-btn"),
          (a.textContent = "+ Adicionar item"),
          a.addEventListener("click", function () {
            (marcarSujo(), r[o].push(n()), e());
          }),
          s.appendChild(a));
      })());
  }
  (document.getElementById("exportBtn").addEventListener("click", function () {
    var e = new Blob([JSON.stringify(r, null, 2)], {
        type: "application/json",
      }),
      a = URL.createObjectURL(e),
      t = document.createElement("a");
    ((t.href = a),
      (t.download = "felipe-branding-conteudo.json"),
      document.body.appendChild(t),
      t.click(),
      t.remove(),
      URL.revokeObjectURL(a),
      d("Backup exportado."));
  }),
    document.getElementById("importBtn").addEventListener("click", function () {
      document.getElementById("importFile").click();
    }),
    document
      .getElementById("importFile")
      .addEventListener("change", function (e) {
        var o = e.target.files[0];
        if (o) {
          var s = new FileReader();
          ((s.onload = function () {
            var o;
            try {
              o = JSON.parse(s.result);
            } catch (a) {
              return (
                d("Arquivo inválido — não foi possível importar."),
                void (e.target.value = "")
              );
            }
            if (!o || "object" != typeof o || Array.isArray(o) || !o.hero)
              return (
                d("Esse arquivo não é um backup deste painel — nada foi importado."),
                void (e.target.value = "")
              );
            if (
              !confirm(
                "Importar este backup substitui TODO o conteúdo publicado do site agora. Continuar?",
              )
            )
              return;
            var c = n(t(a), o);
            i(c)
              .then(function () {
                ((r = c), h(), d("Backup importado e publicado com sucesso."));
              })
              .catch(function (e) {
                d(
                  "Não foi possível salvar o backup importado: " +
                    (e && e.message ? e.message : "sem permissão."),
                );
              });
          }),
            s.readAsText(o),
            (e.target.value = ""));
        }
      }),
    document
      .getElementById("resetAllBtn")
      .addEventListener("click", function () {
        if (
          confirm(
            "Isso vai apagar todas as suas edições e voltar ao conteúdo padrão de fábrica. Deseja continuar?",
          )
        ) {
          var e = t(a);
          i(e)
            .then(function () {
              ((r = e), h(), d("Conteúdo restaurado ao padrão."));
            })
            .catch(function (e) {
              d(
                "Não foi possível restaurar: " +
                  (e && e.message ? e.message : "sem permissão."),
              );
            });
        }
      }));
  // Qualquer edição/remoção/adição dentro do editor conta como "não salvo".
  (function () {
    var area = document.getElementById("mainArea");
    (area.addEventListener("change", function (ev) {
      ev.target.matches("input, select, textarea") && marcarSujo();
    }),
      area.addEventListener("click", function (ev) {
        ev.target.closest(".remove-btn, .add-btn") && marcarSujo();
      }));
  })();
  "serviceWorker" in navigator &&
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("/sw.js").catch(function () {});
    });
})();
