(function () {
  "use strict";

  var MAX_TILT = 14; // graus
  var MAX_GLARE_SIZE = 100; // %

  function initTiltCard(card) {
    var inner = card.querySelector(".tilt-card-inner");
    if (!inner) return;

    var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var isCoarsePointer = window.matchMedia("(pointer: coarse)").matches;
    if (reduceMotion || isCoarsePointer) {
      card.classList.add("is-static");
      return;
    }

    var rect = null;

    function updateRect() {
      rect = card.getBoundingClientRect();
    }

    function handleMove(e) {
      if (!rect) updateRect();
      var x = (e.clientX - rect.left) / rect.width; // 0..1
      var y = (e.clientY - rect.top) / rect.height; // 0..1
      var rotY = (x - 0.5) * (MAX_TILT * 2);
      var rotX = (0.5 - y) * (MAX_TILT * 2);

      card.style.setProperty("--rx", rotX.toFixed(2) + "deg");
      card.style.setProperty("--ry", rotY.toFixed(2) + "deg");
      card.style.setProperty("--mx", (x * MAX_GLARE_SIZE).toFixed(1) + "%");
      card.style.setProperty("--my", (y * MAX_GLARE_SIZE).toFixed(1) + "%");
    }

    function reset() {
      card.style.setProperty("--rx", "0deg");
      card.style.setProperty("--ry", "0deg");
      card.classList.remove("is-active");
    }

    card.addEventListener("mouseenter", function () {
      updateRect();
      card.classList.add("is-active");
    });
    card.addEventListener("mousemove", handleMove);
    card.addEventListener("mouseleave", reset);
    window.addEventListener("resize", function () {
      rect = null;
    });
  }

  function init() {
    document.querySelectorAll(".tilt-card").forEach(initTiltCard);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
