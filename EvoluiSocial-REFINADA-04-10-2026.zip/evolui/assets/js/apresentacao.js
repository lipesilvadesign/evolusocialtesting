(function () {
  "use strict";

  function getSlug() {
    // /apresentacao/<slug> (via _redirects) — com fallback por querystring
    // pra facilitar teste local (/apresentacao.html?slug=empresa-x).
    const path = window.location.pathname.replace(/\/+$/, "");
    const parts = path.split("/apresentacao/");
    if (parts.length > 1 && parts[1]) return decodeURIComponent(parts[1]);
    const qs = new URLSearchParams(window.location.search);
    return qs.get("slug");
  }

  const HEX = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
  function luminancia(hex) {
    let v = hex.slice(1);
    if (v.length === 3) v = v.split("").map((c) => c + c).join("");
    const n = parseInt(v, 16);
    const f = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
    return 0.2126 * f((n >> 16) & 255) + 0.7152 * f((n >> 8) & 255) + 0.0722 * f(n & 255);
  }

  function corTextoLegivel(hex) {
    let v = hex.slice(1);
    if (v.length === 3) v = v.split("").map((c) => c + c).join("");
    let rgb = [0, 2, 4].map((i) => parseInt(v.slice(i, i + 2), 16));
    const contraste = () => 1.05 / (luminancia("#" + rgb.map((x) => x.toString(16).padStart(2, "0")).join("")) + 0.05);
    for (let i = 0; i < 30 && contraste() < 5; i += 1) rgb = rgb.map((x) => Math.round(x * 0.9));
    return "#" + rgb.map((x) => x.toString(16).padStart(2, "0")).join("");
  }

  function aplicarTema(tema) {
    const root = document.documentElement.style;
    const t = tema || {};
    if (HEX.test(t.primaryColor || "")) root.setProperty("--ap-primary", t.primaryColor);
    if (HEX.test(t.secondaryColor || "")) root.setProperty("--ap-secondary", t.secondaryColor);
    if (HEX.test(t.accentColor || "")) root.setProperty("--ap-accent", t.accentColor);
    if (HEX.test(t.backgroundColor || "")) root.setProperty("--ap-bg", t.backgroundColor);
    // 01/10: tom do destaque usado em TEXTO pequeno, escurecido até contraste ≥ 4,5:1 com branco
    root.setProperty("--ap-accent-texto", corTextoLegivel(HEX.test(t.accentColor || "") ? t.accentColor : "#C9A667"));
    // 30/09: texto da capa legível mesmo quando o cliente escolhe cor primária clara
    if (HEX.test(t.primaryColor || "") && luminancia(t.primaryColor) > 0.45) {
      root.setProperty("--ap-on-primary", "#1D2330");
      root.setProperty("--ap-on-primary-soft", "rgba(29,35,48,.75)");
    }
  }

  // (data e escape de texto agora ficam no modelo editorial — apresentacao-modelo.js)
  function escapeAttr(str) {
    return String(str || "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
  }
  // CORREÇÃO 29/09: só aceita imagem enviada pelo painel (data:image) ou https.
  function urlImagemSegura(u) {
    u = String(u || "").trim();
    return /^data:image\/(png|jpe?g|webp|gif|svg\+xml);base64,/i.test(u) || /^https:\/\//i.test(u) ? u : "";
  }

  // ---------------- Composição ----------------
  // 01/10: as seções vêm do MODELO EDITORIAL (assets/js/apresentacao-modelo.js),
  // o mesmo que o PDF usa — web e PDF mostram o mesmo conteúdo.

  function logoCapaHtml(capa, tema) {
    const logoSegura = urlImagemSegura(tema.logo);
    return logoSegura
      ? `<img class="ap-capa-logo" src="${escapeAttr(logoSegura)}" alt="Logo de ${escapeAttr(capa.empresa || 'cliente')}" decoding="async">`
      : `<img class="ap-capa-logo" src="/assets/img/logo-tilt-felipebranding.png" alt="Felipe Branding" style="filter:brightness(0) invert(1)" decoding="async">`;
  }

  /** Espera imagens da página (logo da capa) carregarem — ou falharem — com teto de tempo. */
  function aguardarImagens(raizEl, tetoMs) {
    const imgs = Array.from(raizEl.querySelectorAll("img"));
    return Promise.all(imgs.map((img) => {
      if (img.complete) return Promise.resolve();
      return new Promise((ok) => {
        const fim = () => ok();
        img.addEventListener("load", fim, { once: true });
        img.addEventListener("error", fim, { once: true });
        setTimeout(fim, tetoMs || 4000);
      });
    }));
  }

  // ---------------- Animações ----------------

  function setupReveal() {
    const els = document.querySelectorAll(".ap-reveal");
    if (!("IntersectionObserver" in window)) {
      els.forEach((e) => e.classList.add("is-visible"));
      return;
    }
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2, rootMargin: "0px 0px -8% 0px" });
    els.forEach((e) => obs.observe(e));
  }

  function setupContadores() {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function animarNumero(elNum) {
      const alvo = Number(elNum.dataset.countTo);
      // 01/10: mesmo formato do PDF (pt-BR: 1.840; 4,5)
      const fmt = (v) => Number(v).toLocaleString("pt-BR", { maximumFractionDigits: Number.isInteger(alvo) ? 0 : 1 });
      if (reduceMotion || !alvo) { elNum.textContent = fmt(alvo); return; }
      const duracao = 1200;
      const inicio = performance.now();
      function passo(agora) {
        const t = Math.min(1, (agora - inicio) / duracao);
        const ease = 1 - Math.pow(1 - t, 3);
        const valorAtual = alvo * ease;
        elNum.textContent = fmt(Number.isInteger(alvo) ? Math.round(valorAtual) : valorAtual);
        if (t < 1) requestAnimationFrame(passo);
      }
      requestAnimationFrame(passo);
    }

    if (!("IntersectionObserver" in window)) {
      document.querySelectorAll("[data-count-to]").forEach(animarNumero);
      document.querySelectorAll("[data-bar-to]").forEach((b) => { b.style.width = b.dataset.barTo + "%"; });
      return;
    }
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const card = entry.target;
        const num = card.querySelector("[data-count-to]");
        const bar = card.querySelector("[data-bar-to]");
        if (num) animarNumero(num);
        if (bar) bar.style.width = bar.dataset.barTo + "%";
        obs.unobserve(card);
      });
    }, { threshold: 0.4 });
    document.querySelectorAll(".ap-metric-card").forEach((c) => obs.observe(c));
  }

  // ---------------- PDF LEGADO (ENABLE_NEW_PDF_ENGINE=false) — jsPDF do cdnjs ----------------

  function carregarScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src;
      s.onload = resolve;
      s.onerror = () => reject(new Error("Falha ao carregar " + src));
      document.head.appendChild(s);
    });
  }

  async function gerarPdf(conteudo) {
    if (!window.jspdf) {
      await carregarScript("https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js");
    }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const pageW = doc.internal.pageSize.getWidth();
    const margin = 56;
    let y = 0;

    const NAVY = "#161F30";

    function novaPagina() {
      doc.addPage();
      y = margin;
    }
    function precisaQuebrar(altura) {
      if (y + altura > doc.internal.pageSize.getHeight() - margin) novaPagina();
    }
    function titulo(texto) {
      precisaQuebrar(40);
      doc.setFont("helvetica", "bold"); doc.setFontSize(15); doc.setTextColor(NAVY);
      doc.text(texto, margin, y);
      y += 10;
      doc.setDrawColor(NAVY); doc.setLineWidth(1.2);
      doc.line(margin, y, margin + 40, y);
      y += 22;
    }
    function paragrafo(label, texto) {
      if (!texto) return;
      precisaQuebrar(50);
      if (label) {
        doc.setFont("helvetica", "bold"); doc.setFontSize(9.5); doc.setTextColor(NAVY);
        doc.text(label.toUpperCase(), margin, y);
        y += 14;
      }
      doc.setFont("helvetica", "normal"); doc.setFontSize(10.5); doc.setTextColor("#222222");
      const linhas = doc.splitTextToSize(texto, pageW - margin * 2);
      linhas.forEach((linha) => {
        precisaQuebrar(16);
        doc.text(linha, margin, y);
        y += 15;
      });
      y += 8;
    }

    // Capa
    doc.setFillColor(NAVY);
    doc.rect(0, 0, pageW, doc.internal.pageSize.getHeight(), "F");
    doc.setTextColor("#C9A667"); doc.setFont("helvetica", "bold"); doc.setFontSize(11);
    doc.text("DIAGNÓSTICO ESTRATÉGICO DA MARCA", margin, 140);
    doc.setTextColor("#F7F5F0"); doc.setFont("helvetica", "bold"); doc.setFontSize(28);
    const nomeLinhas = doc.splitTextToSize((conteudo.capa && conteudo.capa.subtitulo) || "", pageW - margin * 2);
    doc.text(nomeLinhas, margin, 180);
    doc.setFont("helvetica", "normal"); doc.setFontSize(13); doc.setTextColor("#AEB4C4");
    doc.text((conteudo.capa && conteudo.capa.titulo) || "", margin, 180 + nomeLinhas.length * 30 + 10);
    doc.setFontSize(10); doc.setTextColor("#7C8296");
    doc.text((conteudo.capa && conteudo.capa.data) || "", margin, doc.internal.pageSize.getHeight() - margin);
    const marcaTexto = "Felipe Branding";
    doc.text(marcaTexto, pageW - margin - doc.getTextWidth(marcaTexto), doc.internal.pageSize.getHeight() - margin);

    novaPagina();

    if (conteudo.sobreEmpresa && conteudo.sobreEmpresa.incluir) {
      titulo("Sobre a empresa");
      paragrafo("Contexto", conteudo.sobreEmpresa.contexto);
      paragrafo("Segmento", conteudo.sobreEmpresa.segmento);
      paragrafo("Produtos e serviços", conteudo.sobreEmpresa.produtos);
      paragrafo("Diferenciais", conteudo.sobreEmpresa.diferenciais);
    }

    if (conteudo.presencaAtual && conteudo.presencaAtual.incluir) {
      titulo("Presença atual");
      paragrafo("Instagram", conteudo.presencaAtual.instagram);
      paragrafo("Site", conteudo.presencaAtual.site);
      paragrafo("Identidade", conteudo.presencaAtual.identidade);
      paragrafo("Comunicação", conteudo.presencaAtual.comunicacao);
      paragrafo("Posicionamento atual", conteudo.presencaAtual.posicionamento);
    }

    const metricasSel = (conteudo.metricasDisponiveis || []).filter((m) => (conteudo.metricasIds || []).indexOf(m.id) !== -1);
    if (metricasSel.length) {
      titulo("Dados e métricas");
      metricasSel.forEach((m) => {
        const valor = m.valor != null ? (m.valor + (m.unidade ? " " + m.unidade : "")) : (m.valor_texto || "—");
        paragrafo(m.nome, valor + (m.periodo ? " — " + m.periodo : "") + (m.origem ? " (fonte: " + m.origem + ")" : ""));
      });
    }

    const interp = (conteudo.interpretacao || []).filter((r) => r.dado || r.significado || r.impacto);
    if (interp.length) {
      titulo("Interpretação");
      interp.forEach((r) => {
        paragrafo("Dado", r.dado);
        paragrafo("Significado", r.significado);
        paragrafo("Impacto", r.impacto);
        y += 4;
      });
    }

    const oportunidades = (conteudo.oportunidades || "").split("\n").map((l) => l.trim()).filter(Boolean);
    if (oportunidades.length) {
      titulo("Oportunidades");
      oportunidades.forEach((o, i) => paragrafo(null, (i + 1) + ". " + o));
    }

    if (conteudo.direcaoEstrategica && conteudo.direcaoEstrategica.incluir) {
      titulo("Direção estratégica");
      paragrafo("Posicionamento", conteudo.direcaoEstrategica.posicionamento);
      paragrafo("Percepção desejada", conteudo.direcaoEstrategica.percepcaoDesejada);
      paragrafo("Diferenciação", conteudo.direcaoEstrategica.diferenciacao);
      paragrafo("Comunicação", conteudo.direcaoEstrategica.comunicacao);
    }

    if (conteudo.direcaoVisual && conteudo.direcaoVisual.incluir) {
      titulo("Direção visual");
      paragrafo("Cores", conteudo.direcaoVisual.cores);
      paragrafo("Tipografia", conteudo.direcaoVisual.tipografia);
      paragrafo("Referências", conteudo.direcaoVisual.referencias);
    }

    const passos = (conteudo.proximosPassos || "").split("\n").map((l) => l.trim()).filter(Boolean);
    if (passos.length) {
      titulo("Próximos passos");
      passos.forEach((p, i) => paragrafo(null, (i + 1) + ". " + p));
    }

    const nomeArquivo = "diagnostico-" + ((conteudo.capa && conteudo.capa.subtitulo) || "cliente").toLowerCase().replace(/[^a-z0-9]+/g, "-") + ".pdf";
    doc.save(nomeArquivo);
  }

  // ---------------- PDF — motor novo (ENABLE_NEW_PDF_ENGINE) ----------------
  // pdf-lib hospedada no próprio site (sem CDN), carregada só no clique.
  const PDF_LIB = "/assets/vendor/pdf-lib-1.17.1.min.0f9a5cad.js";
  const PDF_MOTOR = "/assets/js/apresentacao-pdf.js";
  let carregandoPdf = null;
  function carregarMotorPdf() {
    if (!carregandoPdf) {
      carregandoPdf = Promise.all([
        window.PDFLib ? null : carregarScript(PDF_LIB),
        window.ApresentacaoPdf ? null : carregarScript(PDF_MOTOR),
      ]).catch((err) => { carregandoPdf = null; throw err; });
    }
    return carregandoPdf;
  }

  function baixar(bytes, nome) {
    const blob = new Blob([bytes], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = nome; a.rel = "noopener";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  // ---------------- Estados ----------------

  function mostrarErro(tipo) {
    const loading = document.getElementById("apLoading");
    const erro = document.getElementById("apErro");
    const titulo = document.getElementById("apErroTitulo");
    const texto = document.getElementById("apErroTexto");
    const tentar = document.getElementById("apErroTentar");
    loading.hidden = true;
    erro.hidden = false;
    if (tipo === "rede") {
      titulo.textContent = "Não foi possível carregar a apresentação agora.";
      texto.textContent = "Pode ser a conexão ou uma instabilidade momentânea. Tente de novo em instantes.";
      tentar.hidden = false;
    } else {
      titulo.textContent = "Não encontramos essa apresentação.";
      texto.textContent = "O link pode estar incompleto ou a apresentação pode ainda não ter sido publicada. Fale com quem te enviou este link.";
      tentar.hidden = true;
    }
  }

  /** Antes de imprimir (Ctrl+P): tudo visível, contadores no valor final, barras cheias. */
  function prepararImpressao() {
    document.querySelectorAll(".ap-reveal").forEach((e) => e.classList.add("is-visible"));
    document.querySelectorAll("[data-count-to]").forEach((e) => { e.textContent = Number(e.dataset.countTo).toLocaleString("pt-BR"); });
    document.querySelectorAll("[data-bar-to]").forEach((b) => { b.style.width = b.dataset.barTo + "%"; });
  }

  // ---------------- Boot ----------------

  async function init() {
    const slug = getSlug();
    const loading = document.getElementById("apLoading");
    const erro = document.getElementById("apErro");
    const root = document.getElementById("apresentacaoRoot");
    const pdfBtn = document.getElementById("apPdfBtn");
    const pdfStatus = document.getElementById("apPdfStatus");

    if (!slug) { mostrarErro("nao_encontrada"); return; }
    loading.hidden = false;
    erro.hidden = true;

    let data;
    try {
      const res = await fetch("/.netlify/functions/apresentacao-publica?slug=" + encodeURIComponent(slug), { headers: { Accept: "application/json" } });
      if (res.status === 404 || res.status === 400) { mostrarErro("nao_encontrada"); return; }
      if (!res.ok) throw new Error("HTTP " + res.status);
      data = await res.json();
      if (!data || !data.apresentacao) { mostrarErro("nao_encontrada"); return; }
    } catch (err) {
      console.error("[apresentacao] falha ao carregar", err);
      mostrarErro("rede");
      return;
    }

    const apresentacao = data.apresentacao;
    const novoPdf = !data.recursos || data.recursos.novoPdf !== false;
    const conteudo = apresentacao.conteudo || {};
    const tema = apresentacao.tema || {};
    aplicarTema(tema);
    document.title = "Diagnóstico Estratégico — " + ((conteudo.capa && conteudo.capa.subtitulo) || "Felipe Branding");

    const M = window.ApresentacaoModelo;
    const modelo = M.montarModelo(conteudo);
    root.innerHTML = M.renderizarWeb(modelo, { logoHtml: logoCapaHtml(modelo.capa, tema) });
    const descricao = document.querySelector('meta[name="description"]');
    if (descricao && modelo.capa.empresa) descricao.setAttribute("content", "Diagnóstico estratégico da marca " + modelo.capa.empresa + ", preparado pela Felipe Branding.");

    loading.hidden = true;
    root.hidden = false;
    pdfBtn.hidden = false;

    setupReveal();
    setupContadores();
    window.addEventListener("beforeprint", prepararImpressao);

    const spanEl = pdfBtn.querySelector("span");
    const textoOriginal = spanEl.textContent;
    let limparStatus = 0;
    function status(msg, erroVisivel) {
      clearTimeout(limparStatus);
      pdfStatus.hidden = !msg;
      pdfStatus.textContent = msg || "";
      pdfStatus.classList.toggle("is-erro", Boolean(erroVisivel));
    }

    pdfBtn.addEventListener("click", async function () {
      if (pdfBtn.disabled) return; // clique duplo não gera 2 PDFs
      pdfBtn.disabled = true;
      pdfBtn.setAttribute("aria-busy", "true");
      spanEl.textContent = "Gerando…";
      const inicio = performance.now();
      try {
        if (novoPdf) {
          status("Preparando apresentação…");
          // dados prontos → imagens carregadas → fontes prontas → motor carregado → PDF
          await aguardarImagens(root, 4000);
          if (document.fonts && document.fonts.ready) await document.fonts.ready;
          await carregarMotorPdf();
          const r = await window.ApresentacaoPdf.gerar({
            PDFLib: window.PDFLib, modelo, tema, publicadoEm: apresentacao.publicadoEm,
            onEtapa: (e) => status(e === "gerando" ? "Gerando PDF…" : "Finalizando…"),
          });
          baixar(r.bytes, r.nomeArquivo);
          console.info("[apresentacao] pdf", { paginas: r.paginas, bytes: r.bytes.length, duracao_ms: Math.round(performance.now() - inicio) });
        } else {
          status("Gerando PDF…");
          await gerarPdf(conteudo);
        }
        status("PDF pronto.");
        limparStatus = setTimeout(() => status(""), 5000);
      } catch (err) {
        console.error("[apresentacao] falha ao gerar PDF", err); // detalhe técnico só no console
        status("Não foi possível gerar o PDF agora. Tente de novo em instantes — ou use Imprimir › Salvar como PDF no navegador.", true);
      } finally {
        pdfBtn.disabled = false;
        pdfBtn.removeAttribute("aria-busy");
        spanEl.textContent = textoOriginal;
      }
    });
  }

  document.addEventListener("click", (e) => {
    if (e.target && e.target.id === "apErroTentar") init();
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
