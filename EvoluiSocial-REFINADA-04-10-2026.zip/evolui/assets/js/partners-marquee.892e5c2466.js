/* ==========================================================================
   Esteira de marcas parceiras na home (site_content.partners).
   A seção começa escondida no HTML e só aparece se houver parceira
   publicada — antes o título "Parcerias" aparecia e sumia (salto na página).
   Usa a MESMA busca de conteúdo da home (FBContent), sem requisição extra.
   ========================================================================== */
(function () {
  "use strict";

  function safeUrl(value, allowRelative) {
    var url = String(value || "").trim();
    if (/^https?:\/\//i.test(url)) return url;
    if (allowRelative && /^\/(?!\/)/.test(url)) return url;
    if (/^data:image\/(png|jpe?g|webp|gif|avif|svg\+xml);base64,/i.test(url)) return url;
    return "";
  }

  function buildLogo(partner) {
    var img = document.createElement("img");
    img.src = safeUrl(partner.logoUrl, true);
    img.alt = partner.nome || "";
    img.loading = "lazy";
    img.decoding = "async";
    var link = safeUrl(partner.link, false);
    var wrap = document.createElement(link ? "a" : "span");
    wrap.className = "partner-logo";
    if (link) {
      wrap.href = link;
      wrap.target = "_blank";
      wrap.rel = "noopener noreferrer";
    }
    wrap.appendChild(img);
    return wrap;
  }

  function init() {
    var FBContent = window.FBContent;
    var section = document.getElementById("parceiros");
    var wrap = document.getElementById("partnersMarquee");
    var track = document.getElementById("partnersTrack");
    if (!FBContent || !section || !wrap || !track) {
      console.error("partners-marquee: elementos ou FBContent ausentes — confira a ordem dos scripts no index.html.");
      return;
    }

    FBContent.loadContent().then(function (content) {
      var partners = (content.partners || [])
        .filter(function (p) {
          return p && safeUrl(p.logoUrl, true) && p.status === "publicado";
        })
        .sort(function (a, b) {
          return (parseInt(a.ordem, 10) || 0) - (parseInt(b.ordem, 10) || 0);
        });
      if (!partners.length) return; // seção continua escondida

      track.textContent = "";
      var animate = partners.length >= 3 && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      // A esteira translada -50%: a segunda cópia só existe para o loop e fica fora do leitor de tela.
      partners.forEach(function (p) {
        track.appendChild(buildLogo(p));
      });
      if (animate) {
        partners.forEach(function (p) {
          var copy = buildLogo(p);
          copy.setAttribute("aria-hidden", "true");
          copy.setAttribute("tabindex", "-1");
          track.appendChild(copy);
        });
      } else {
        track.classList.add("is-static");
      }
      wrap.hidden = false;
      section.hidden = false;
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
