-- SQL_EVOLUI_ENTENDIMENTO_03_10.sql
-- Evolui: camada de entendimento de termos (taxonomia ampliada + funcao evolui_entender_termos).
-- Aditivo e idempotente. Aplicado em 03/10 (projeto aligftypgtzlymmditeo) em lotes pequenos.
-- Backup previo: bkp_evolui_20261003.evolui_tax_termos (34 linhas).
-- Chaves novas seguem o padrao existente (underscore): ex. eventos_sao_joao, passeios_rio.
set lock_timeout='5s'; set statement_timeout='25s';

-- 1) colunas, constraint de tipo ampliada, indices
alter table public.evolui_tax_termos
  add column if not exists locais text[] not null default '{}',
  add column if not exists peso_local jsonb not null default '{}';

do $$ begin
  if not exists (select 1 from pg_constraint where conrelid='public.evolui_tax_termos'::regclass and conname='evolui_tax_termos_tipo_check'
                 and pg_get_constraintdef(oid) like '%produto%') then
    alter table public.evolui_tax_termos drop constraint if exists evolui_tax_termos_tipo_check;
    alter table public.evolui_tax_termos drop constraint if exists evolui_tax_termos_tipo_check2;
    alter table public.evolui_tax_termos add constraint evolui_tax_termos_tipo_check
      check (tipo in ('area','subramo','tema','entidade','produto','servico','plataforma','formato','negocio')) not valid;
    alter table public.evolui_tax_termos validate constraint evolui_tax_termos_tipo_check;
  end if;
end $$;

create index if not exists evolui_tax_termos_sin_gin on public.evolui_tax_termos using gin (sinonimos);
create index if not exists evolui_tax_termos_rotulo_trgm on public.evolui_tax_termos using gin (rotulo gin_trgm_ops);

-- 2) relacoes (RLS ligado na criacao; leitura authenticated, escrita admin)
create table if not exists public.evolui_tax_relacoes (
  id uuid primary key default gen_random_uuid(),
  de_id uuid not null references public.evolui_tax_termos(id) on delete cascade,
  para_id uuid not null references public.evolui_tax_termos(id) on delete cascade,
  tipo text not null check (tipo in ('sinonimo_de','parte_de','tipo_de','produto_de','servico_de','relacionado_a','usado_em')),
  peso numeric not null default 1,
  fonte text not null default 'curadoria',
  criado_em timestamptz not null default now(),
  unique (de_id,para_id,tipo));
alter table public.evolui_tax_relacoes enable row level security;
revoke all on public.evolui_tax_relacoes from anon;
do $$ begin
  if not exists (select 1 from pg_policies where tablename='evolui_tax_relacoes' and policyname='rel_sel') then
    create policy rel_sel on public.evolui_tax_relacoes for select to authenticated using (true); end if;
  if not exists (select 1 from pg_policies where tablename='evolui_tax_relacoes' and policyname='rel_ins') then
    create policy rel_ins on public.evolui_tax_relacoes for insert to authenticated with check ((select public.evolui_eh_admin())); end if;
  if not exists (select 1 from pg_policies where tablename='evolui_tax_relacoes' and policyname='rel_upd') then
    create policy rel_upd on public.evolui_tax_relacoes for update to authenticated using ((select public.evolui_eh_admin())) with check ((select public.evolui_eh_admin())); end if;
  if not exists (select 1 from pg_policies where tablename='evolui_tax_relacoes' and policyname='rel_del') then
    create policy rel_del on public.evolui_tax_relacoes for delete to authenticated using ((select public.evolui_eh_admin())); end if;
end $$;
create index if not exists evolui_tax_rel_de on public.evolui_tax_relacoes(de_id);
create index if not exists evolui_tax_rel_para on public.evolui_tax_relacoes(para_id);

-- 3a) areas e subramos (sinonimos novos sao somados aos existentes, sem duplicar)
insert into public.evolui_tax_termos(tipo,chave,rotulo,sinonimos,pai_id)
select v.tipo,v.chave,v.rotulo,string_to_array(v.sin,'|'),(select p.id from public.evolui_tax_termos p where p.tipo=v.ptipo and p.chave=v.pchave)
from (values
('area','turismo','Turismo e eventos','turismo|turistico|turistica|turista|turistas',null,null),
('area','moda','Moda e acessórios','moda|boutique|vestuario|vestuário',null,null),
('area','alimentacao','Alimentação e restaurantes','alimentacao|alimentação|comida|gastronomia',null,null),
('area','saude','Saúde e bem-estar','saude|saúde|bem estar|bem-estar',null,null),
('area','fitness','Academia e fitness','fitness|academia|treino',null,null),
('area','pet','Pet','pet|pets|animais',null,null),
('area','casa','Casa e decoração','decoracao|decoração|casa e decoracao',null,null),
('area','educacao','Educação e cursos','educacao|educação|ensino|escola',null,null),
('area','servicos','Serviços profissionais','servicos profissionais|serviços profissionais|prestador de servicos',null,null),
('area','doces','Doces e confeitaria','doces|doce|confeitaria|docinhos',null,null),
('area','beleza','Beleza e estética','beleza|estetica|estética',null,null)
) v(tipo,chave,rotulo,sin,ptipo,pchave)
on conflict (tipo,chave) do update set sinonimos=(select coalesce(array_agg(x order by o),'{}') from (select x,min(o) o from unnest(public.evolui_tax_termos.sinonimos||excluded.sinonimos) with ordinality u(x,o) group by x) s);
-- 3b) subramos
insert into public.evolui_tax_termos(tipo,chave,rotulo,sinonimos,pai_id)
select v.tipo,v.chave,v.rotulo,string_to_array(v.sin,'|'),(select p.id from public.evolui_tax_termos p where p.tipo=v.ptipo and p.chave=v.pchave)
from (values
('subramo','cuidados_pele','Cuidados com a pele','cuidados com a pele|cuidados faciais|cuidados com o rosto|rotina de pele','area','beleza'),
('subramo','cabelo_barbearia','Cabelo e barbearia','salao|saloes|salão|salões|cabeleireiro|cabeleireira|barbearia|barbeiro|corte|cabelo','area','beleza'),
('subramo','estetica','Estética','estetica|estética|clinica de estetica|depilacao|depilação|sobrancelha|unhas|manicure|nail','area','beleza'),
('subramo','maquiagem','Maquiagem','maquiagem|make|makeup','area','beleza'),
('subramo','cosmeticos_perfumaria','Cosméticos e perfumaria','cosmeticos|cosméticos|cosmetico|perfume|perfumes|perfumaria|loja de cosmeticos|loja de cosméticos','area','beleza'),
('subramo','roupas','Roupas e vestuário','roupas|roupa|vestuario|vestuário|loja de roupas','area','moda'),
('subramo','calcados','Calçados','calcados|calçados|calcado|sapato|sapatos|tenis|sandalia','area','moda'),
('subramo','acessorios','Acessórios','acessorios|acessórios|bijuteria|bolsas','area','moda'),
('subramo','moda_praia','Moda praia','moda praia|biquini|biquíni|maiô|maio','area','moda'),
('subramo','moda_feminina','Moda feminina','moda feminina|roupa feminina','area','moda'),
('subramo','moda_masculina','Moda masculina','moda masculina|roupa masculina','area','moda'),
('subramo','moda_infantil','Moda infantil','moda infantil|roupa infantil|roupa de crianca','area','moda'),
('subramo','restaurantes_pizzarias','Restaurantes e pizzarias','restaurante|restaurantes|pizzaria|pizzarias','area','alimentacao'),
('subramo','lanchonete','Lanchonete','lanchonete|lanchonetes|lanche|lanches','area','alimentacao'),
('subramo','cafeteria','Cafeteria','cafeteria|cafeterias|cafe|café','area','alimentacao'),
('subramo','padaria','Padaria','padaria|padarias|panificadora','area','alimentacao'),
('subramo','mercado','Mercado e minimercado','minimercado|mercado|supermercado|mercadinho|mercearia','area','alimentacao'),
('subramo','hamburgueria','Hamburgueria','hamburgueria|hamburguerias|hamburguer|hambúrguer|burger','area','alimentacao'),
('subramo','clinicas','Clínicas','clinica|clínica|clinicas|clínicas','area','saude'),
('subramo','psicologia','Psicologia','psicologo|psicólogo|psicologa|psicóloga|psicologia|terapia','area','saude'),
('subramo','nutricao','Nutrição','nutricionista|nutricao|nutrição|nutri','area','saude'),
('subramo','fisioterapia','Fisioterapia','fisioterapia|fisioterapeuta|fisio','area','saude'),
('subramo','treino','Treino','treino|treinos|musculacao|musculação','area','fitness'),
('subramo','crossfit','Crossfit','crossfit|cross fit','area','fitness'),
('subramo','pilates','Pilates','pilates','area','fitness'),
('subramo','pet_shop','Pet shop','pet shop|petshop|pet shops|banho e tosa|veterinario|veterinário|clinica veterinaria','area','pet'),
('subramo','decoracao','Decoração','decoracao|decoração','area','casa'),
('subramo','moveis','Móveis','moveis|móveis|movel|móvel|marcenaria|planejados','area','casa'),
('subramo','construcao','Construção','construcao|construção|obra|obras|reforma|reformas|material de construcao|materiais de construcao|material de construção','area','casa'),
('subramo','cursos','Cursos','curso|cursos|aulas|escola|mentoria','area','educacao'),
('subramo','fotografia','Fotografia','fotografia|fotografo|fotógrafo|fotografa|fotógrafa|ensaio fotografico','area','servicos'),
('subramo','advocacia','Advocacia','advogado|advogada|advocacia|escritorio de advocacia','area','servicos'),
('subramo','contabilidade','Contabilidade','contador|contadora|contabilidade|escritorio contabil','area','servicos'),
('subramo','tecnologia','Tecnologia','tecnologia|software|sistemas|assistencia tecnica|desenvolvimento de software','area','servicos'),
('subramo','automotivo','Automotivo','automotivo|oficina|oficina mecanica|mecanica|mecânica|mecanico|mecânico|auto center|autopecas','area','servicos'),
('subramo','eventos_sao_joao','Eventos e São João','sao joao|são joão|festa junina|festas juninas|forro|forró|evento|eventos|festival|festivais','area','turismo'),
('subramo','gastronomia_regional','Gastronomia regional','gastronomia regional|comida regional|culinaria regional|culinária regional|comida nordestina|culinaria nordestina','area','turismo'),
('subramo','enoturismo','Enoturismo','enoturismo|vinho|vinhos|adega|adegas','area','turismo'),
('subramo','passeios_rio','Passeios no rio','passeio no rio|passeios no rio|rio sao francisco|rio são francisco|velho chico|passeio de barco|passeios de barco','area','turismo'),
('subramo','hospedagem','Hospedagem','hospedagem|hospedagens|hospedar|hospedes|hóspedes','area','turismo'),
('subramo','agro','Agronegócio e fruticultura','agro|agronegocio|agronegócio|agricultura|fruticultura|fazenda|produtor rural|produtores rurais','area','outro')
) v(tipo,chave,rotulo,sin,ptipo,pchave)
on conflict (tipo,chave) do update set sinonimos=(select coalesce(array_agg(x order by o),'{}') from (select x,min(o) o from unnest(public.evolui_tax_termos.sinonimos||excluded.sinonimos) with ordinality u(x,o) group by x) s);
-- 3c) temas
insert into public.evolui_tax_termos(tipo,chave,rotulo,sinonimos,pai_id)
select v.tipo,v.chave,v.rotulo,string_to_array(v.sin,'|'),(select p.id from public.evolui_tax_termos p where p.tipo=v.ptipo and p.chave=v.pchave)
from (values
('tema','skincare','Skincare','skincare|skin care|cuidados com a pele|rotina de pele|cuidados faciais|cuidados com o rosto|limpeza de pele|hidratacao facial|hidratação facial','subramo','cuidados_pele'),
('tema','barbearia','Barbearia','barbearias|barbeiros','subramo','cabelo_barbearia'),
('tema','odontologia','Odontologia','odonto|dentistas|consultorio odontologico','subramo','clinicas'),
('tema','restaurante','Restaurante','restaurantes','subramo','restaurantes_pizzarias'),
('tema','pizzaria','Pizzaria','pizzarias','subramo','restaurantes_pizzarias'),
('tema','bode_carneiro','Bode e carneiro (gastronomia regional)','bode|carneiro|carne de bode|carne de carneiro|bode assado|cabrito','subramo','restaurantes_pizzarias'),
('tema','festa_junina','Festa junina','festa junina|festas juninas|sao joao|são joão|arraial|quadrilha','subramo','eventos_sao_joao'),
('tema','forro','Forró','forro|forró|show de forro','subramo','eventos_sao_joao'),
('tema','comida_tipica','Comida típica','comida tipica|comida típica|prato tipico|pratos tipicos','subramo','gastronomia_regional'),
('tema','vinicolas','Vinícolas','vinicola|vinícola|vinicolas|vinícolas|vinhedo|vinhedos|espumante|espumantes','subramo','enoturismo'),
('tema','degustacao_vinhos','Degustação de vinhos','degustacao de vinho|degustação de vinho|degustacao de vinhos|degustação de vinhos|visita guiada','subramo','enoturismo'),
('tema','passeio_barco','Passeio de barco','barco|barcos|catamara|catamarã|navegacao','subramo','passeios_rio'),
('tema','pousadas','Pousadas','pousada|pousadas|hostel','subramo','hospedagem'),
('tema','hoteis','Hotéis','hotel|hoteis|hotéis','subramo','hospedagem'),
('tema','uva','Uva','uva|uvas|parreiral|parreirais','subramo','agro'),
('tema','manga','Manga','manga|mangas','subramo','agro'),
('tema','fruticultura_irrigada','Fruticultura irrigada','fruticultura irrigada|irrigacao|irrigação|agricultura irrigada','subramo','agro')
) v(tipo,chave,rotulo,sin,ptipo,pchave)
on conflict (tipo,chave) do update set sinonimos=(select coalesce(array_agg(x order by o),'{}') from (select x,min(o) o from unnest(public.evolui_tax_termos.sinonimos||excluded.sinonimos) with ordinality u(x,o) group by x) s);
-- 3d) produtos, servicos, plataformas, formatos, negocios (sem pai; ligados por evolui_tax_relacoes)
insert into public.evolui_tax_termos(tipo,chave,rotulo,sinonimos,pai_id)
select v.tipo,v.chave,v.rotulo,string_to_array(v.sin,'|'),null
from (values
('produto','protetor_solar','Protetor solar','protetor solar|filtro solar|fps|bloqueador|bloqueador solar|protetores solares'),
('produto','hidratante','Hidratante','hidratante|hidratantes|creme hidratante'),
('produto','sabonete_facial','Sabonete facial','sabonete facial|sabonetes faciais|gel de limpeza'),
('produto','serum','Sérum','serum|sérum|serums|séruns'),
('produto','tonico','Tônico','tonico|tônico|tonicos|tônicos|tonico facial'),
('servico','limpeza_de_pele','Limpeza de pele','limpeza de pele|limpeza facial'),
('servico','peeling','Peeling','peeling|peelings'),
('plataforma','instagram','Instagram','instagram|insta|ig'),
('plataforma','tiktok','TikTok','tiktok|tik tok'),
('plataforma','youtube','YouTube','youtube|you tube'),
('plataforma','facebook','Facebook','facebook'),
('plataforma','linkedin','LinkedIn','linkedin'),
('plataforma','whatsapp','WhatsApp','whatsapp|whats|zap|zapzap'),
('formato','reels','Reels','reels|reel'),
('formato','stories','Stories','stories|story|storie'),
('formato','carrossel','Carrossel','carrossel|carrosseis|carrosséis|carousel'),
('formato','video','Vídeo','video|vídeo|videos|vídeos'),
('formato','imagem','Imagem','imagem|imagens|foto|fotos'),
('formato','texto','Texto','texto|textos|legenda|legendas'),
('formato','post','Post','post|posts|publicacao|publicação|postagem|postagens'),
('formato','live','Live','live|lives|ao vivo'),
('negocio','loja','Loja','loja|lojas|lojinha|lojinhas'),
('negocio','salao','Salão','salao|salão|saloes|salões'),
('negocio','clinica','Clínica','clinica|clínica|clinicas|clínicas'),
('negocio','restaurante','Restaurante','restaurante|restaurantes'),
('negocio','autonomo','Autônomo','autonomo|autônomo|autonoma|autônoma|freelancer|profissional liberal|profissional autonomo'),
('negocio','consultorio','Consultório','consultorio|consultório|consultorios|consultórios'),
('negocio','estudio','Estúdio','estudio|estúdio|estudios|estúdios'),
('negocio','academia','Academia','academia|academias')
) v(tipo,chave,rotulo,sin)
on conflict (tipo,chave) do update set sinonimos=(select coalesce(array_agg(x order by o),'{}') from (select x,min(o) o from unnest(public.evolui_tax_termos.sinonimos||excluded.sinonimos) with ordinality u(x,o) group by x) s);

-- relacoes: produtos e servicos de skincare
insert into public.evolui_tax_relacoes(de_id,para_id,tipo)
select d.id,t.id,case d.tipo when 'produto' then 'produto_de' else 'servico_de' end
from public.evolui_tax_termos d join public.evolui_tax_termos t on t.tipo='tema' and t.chave='skincare'
where (d.tipo='produto' and d.chave in ('protetor_solar','hidratante','sabonete_facial','serum','tonico'))
   or (d.tipo='servico' and d.chave in ('limpeza_de_pele','peeling'))
on conflict (de_id,para_id,tipo) do nothing;
-- 4) funcao de entendimento
create or replace function public.evolui_entender_termos(p_texto text, p_cidade text default null)
returns jsonb
language plpgsql
stable
security definer
set search_path = public, pg_temp
as $fn$
declare
  v_orig text := coalesce(p_texto,'');
  v_txt text;
  v_dims jsonb := '[]'::jsonb;
  v_acc_a int4range[] := '{}';   -- faixas aceitas (termos taxonomicos/entidades)
  v_acc_n int4range[] := '{}';   -- faixas aceitas (negocio)
  v_rng int4range;
  r record;
  v_ok boolean;
  v_seeds jsonb := '[]'::jsonb;
  v_n_areas int;
  v_area record; v_sub record; v_tema record;
  v_cadeia jsonb;
  v_loc jsonb := null;
  v_cand text; v_w text; v_pref text;
  v_cn text;
begin
  v_txt := ' ' || btrim(regexp_replace(public.evolui_tax_norm(v_orig),'[^a-z0-9]+',' ','g')) || ' ';
  if length(btrim(v_txt)) = 0 then
    return jsonb_build_object('dimensoes','[]'::jsonb,'cadeia',jsonb_build_object('area',null,'subramo',null,'tema',null),'localizacao',null);
  end if;

  for r in
    with fr as (
      select t.id, t.tipo, t.chave, t.rotulo,
             btrim(regexp_replace(public.evolui_tax_norm(s.raw),'[^a-z0-9]+',' ','g')) as frase
      from public.evolui_tax_termos t
      cross join lateral unnest(array[t.rotulo, replace(t.chave,'_',' ')] || coalesce(t.sinonimos,'{}')) as s(raw)
      where t.ativo
    ), vari as (
      select distinct f.id, f.tipo, f.chave, f.rotulo, v.variante
      from fr f
      cross join lateral unnest(array[
        f.frase, f.frase||'s', f.frase||'es',
        case when length(f.frase) > 3 and f.frase like '%s' then left(f.frase,-1) end,
        case when length(f.frase) > 4 and f.frase like '%es' then left(f.frase,-2) end,
        case when f.frase like '%ao' then left(f.frase,-2)||'oes' end,
        case when f.frase like '%ao' then left(f.frase,-2)||'aes' end,
        case when f.frase like '%ao' then f.frase||'s' end,
        case when f.frase like '%oes' then left(f.frase,-3)||'ao' end
      ]) as v(variante)
      where f.frase <> '' and v.variante is not null and v.variante <> ''
    )
    select id, tipo, chave, rotulo, variante, strpos(v_txt, ' '||variante||' ') as pos,
           length(variante) as len,
           case tipo when 'produto' then 1 when 'servico' then 1 when 'tema' then 2
                     when 'plataforma' then 2 when 'formato' then 2 when 'subramo' then 3
                     when 'area' then 4 else 5 end as prio
    from vari
    where strpos(v_txt, ' '||variante||' ') > 0
    order by length(variante) desc, 8, 6, chave
  loop
    v_rng := int4range(r.pos+1, r.pos + r.len, '[]');   -- somente o conteudo das palavras
    if r.tipo = 'negocio' then
      v_ok := not exists (select 1 from unnest(v_acc_n) x where x && v_rng)
              and not exists (select 1 from jsonb_array_elements(v_dims) d where d->>'tipo'='negocio' and d->>'chave'=r.chave);
      if v_ok then v_acc_n := v_acc_n || v_rng; end if;
    else
      v_ok := not exists (select 1 from unnest(v_acc_a) x where x && v_rng)
              and not exists (select 1 from jsonb_array_elements(v_dims) d where d->>'tipo'=r.tipo and d->>'chave'=r.chave);
      if v_ok then v_acc_a := v_acc_a || v_rng; end if;
    end if;
    if v_ok then
      v_dims := v_dims || jsonb_build_object('tipo',r.tipo,'chave',r.chave,'rotulo',r.rotulo,
                 'trecho',r.variante,'origem','dita','_id',r.id,'_pos',r.pos);
    end if;
  end loop;

  -- sementes da cadeia: termos taxonomicos citados + alvos das relacoes de produtos/servicos
  with d as (
    select (e->>'_id')::uuid id, e->>'tipo' tipo, (e->>'_pos')::int pos
    from jsonb_array_elements(v_dims) e
  ), seeds as (
    select id seed, pos, true dita from d where tipo in ('area','subramo','tema')
    union all
    select (select rr.para_id from public.evolui_tax_relacoes rr
             where rr.de_id = d.id and rr.tipo in ('produto_de','servico_de','tipo_de','parte_de','usado_em')
             order by rr.peso desc limit 1), pos, false
    from d where tipo in ('produto','servico')
  ), ch as (
    select s.pos, s.dita, t.id tid, t.tipo,
           case t.tipo when 'tema' then t.id end tema_id,
           case t.tipo when 'subramo' then t.id when 'tema' then p1.id end sub_id,
           case t.tipo when 'area' then t.id when 'subramo' then p1.id when 'tema' then p2.id end area_id
    from seeds s
    join public.evolui_tax_termos t on t.id = s.seed
    left join public.evolui_tax_termos p1 on p1.id = t.pai_id
    left join public.evolui_tax_termos p2 on p2.id = p1.pai_id
  )
  select coalesce(jsonb_agg(to_jsonb(ch) order by (not dita), pos), '[]'::jsonb) into v_seeds from ch;

  select count(distinct (e->>'area_id')) into v_n_areas from jsonb_array_elements(v_seeds) e where e->>'area_id' is not null;

  if v_n_areas > 1 then
    v_cadeia := jsonb_build_object('area',null,'subramo',null,'tema',null,'ambigua',true);
  elsif v_n_areas = 0 then
    v_cadeia := jsonb_build_object('area',null,'subramo',null,'tema',null);
  else
    select t.id, t.chave, t.rotulo into v_area from public.evolui_tax_termos t
      where t.id = (select (e->>'area_id')::uuid from jsonb_array_elements(v_seeds) e where e->>'area_id' is not null limit 1);
    select t.id, t.chave, t.rotulo into v_tema from public.evolui_tax_termos t
      where t.id = (select (e->>'tema_id')::uuid from jsonb_array_elements(v_seeds) e where e->>'tema_id' is not null limit 1);
    if v_tema.id is not null then
      select t.id, t.chave, t.rotulo into v_sub from public.evolui_tax_termos t
        where t.id = (select (e->>'sub_id')::uuid from jsonb_array_elements(v_seeds) e
                       where e->>'tema_id' = v_tema.id::text and e->>'sub_id' is not null limit 1);
    else
      select t.id, t.chave, t.rotulo into v_sub from public.evolui_tax_termos t
        where t.id = (select (e->>'sub_id')::uuid from jsonb_array_elements(v_seeds) e where e->>'sub_id' is not null limit 1);
    end if;
    v_cadeia := jsonb_build_object(
      'area', jsonb_build_object('chave',v_area.chave,'rotulo',v_area.rotulo,
               'origem', case when exists (select 1 from jsonb_array_elements(v_dims) d where (d->>'_id')::uuid = v_area.id) then 'dita' else 'inferida' end),
      'subramo', case when v_sub.id is null then null else jsonb_build_object('chave',v_sub.chave,'rotulo',v_sub.rotulo,
               'origem', case when exists (select 1 from jsonb_array_elements(v_dims) d where (d->>'_id')::uuid = v_sub.id) then 'dita' else 'inferida' end) end,
      'tema', case when v_tema.id is null then null else jsonb_build_object('chave',v_tema.chave,'rotulo',v_tema.rotulo,
               'origem', case when exists (select 1 from jsonb_array_elements(v_dims) d where (d->>'_id')::uuid = v_tema.id) then 'dita' else 'inferida' end) end);
  end if;

  -- localizacao
  v_cand := null;
  if p_cidade is not null and btrim(p_cidade) <> '' then
    v_cn := btrim(regexp_replace(public.evolui_tax_norm(p_cidade),'[^a-z0-9]+',' ','g'));
    if v_cn <> '' and position(' '||v_cn||' ' in v_txt) > 0 then v_cand := btrim(p_cidade); end if;
  end if;
  if v_cand is null then
    v_cand := (regexp_match(v_orig, '\m[Ee]m\s+([A-ZÀ-Ý][[:alpha:]]+(?:\s+(?:(?:de|da|do|das|dos)\s+)?[A-ZÀ-Ý][[:alpha:]]+)*)'))[1];
  end if;
  if v_cand is not null then
    -- corta a partir da primeira palavra que seja termo da taxonomia (plataforma, formato etc.)
    v_pref := '';
    foreach v_w in array regexp_split_to_array(v_cand, '\s+') loop
      if exists (
        select 1 from public.evolui_tax_termos t
        cross join lateral unnest(array[t.rotulo, replace(t.chave,'_',' ')] || coalesce(t.sinonimos,'{}')) s(raw)
        where t.ativo and btrim(regexp_replace(public.evolui_tax_norm(s.raw),'[^a-z0-9]+',' ','g'))
              in (btrim(regexp_replace(public.evolui_tax_norm(v_w),'[^a-z0-9]+',' ','g')),
                  left(btrim(regexp_replace(public.evolui_tax_norm(v_w),'[^a-z0-9]+',' ','g')), -1))
      ) then exit; end if;
      v_pref := btrim(v_pref || ' ' || v_w);
    end loop;
    v_pref := regexp_replace(v_pref, '\s+(de|da|do|das|dos)$', '');
    if v_pref <> '' then v_loc := jsonb_build_object('nome', v_pref, 'origem', 'dita'); end if;
  end if;

  return jsonb_build_object(
    'dimensoes', coalesce((select jsonb_agg(d - '_id' - '_pos' order by (d->>'_pos')::int) from jsonb_array_elements(v_dims) d), '[]'::jsonb),
    'cadeia', v_cadeia,
    'localizacao', v_loc);
end
$fn$;

revoke all on function public.evolui_entender_termos(text,text) from public, anon, authenticated;
grant execute on function public.evolui_entender_termos(text,text) to authenticated, service_role;
