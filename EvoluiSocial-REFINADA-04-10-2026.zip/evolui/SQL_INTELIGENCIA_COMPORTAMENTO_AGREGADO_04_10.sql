-- EIE — Inteligência comportamental agregada v1
-- Aditivo. Não cria vínculo entre eventos e pessoas e não expõe user_id.
-- Aplicar no Supabase depois das migrações existentes.

create table if not exists public.evolui_comportamento_agregado (
  id bigint generated always as identity primary key,
  dia date not null default current_date,
  tema text not null,
  ramo text not null default '',
  origem text not null default 'pesquisa',
  volume integer not null default 0 check (volume >= 0),
  criado_em timestamptz not null default now(),
  unique (dia, tema, ramo, origem)
);

create index if not exists idx_evolui_comportamento_agregado_tema_dia
  on public.evolui_comportamento_agregado (tema, dia desc);

alter table public.evolui_comportamento_agregado enable row level security;

-- Nenhum acesso direto ao cliente. O motor usa as funções abaixo.
drop policy if exists evolui_comportamento_agregado_deny_all on public.evolui_comportamento_agregado;
create policy evolui_comportamento_agregado_deny_all
  on public.evolui_comportamento_agregado
  for all using (false) with check (false);

create or replace function public.evolui_registrar_sinal_agregado(
  p_tema text,
  p_ramo text default null,
  p_origem text default 'pesquisa'
) returns void
language sql
security definer
set search_path = public
as $$
  insert into public.evolui_comportamento_agregado (dia, tema, ramo, origem, volume)
  values (current_date, left(trim(p_tema), 160), left(trim(coalesce(p_ramo,'')), 120), left(trim(coalesce(p_origem,'pesquisa')), 40), 1)
  on conflict (dia, tema, ramo, origem)
  do update set volume = public.evolui_comportamento_agregado.volume + 1;
$$;

create or replace function public.evolui_obter_sinais_agregados(
  p_tema text,
  p_ramo text default null,
  p_dias integer default 30
) returns table (
  tema text,
  ramo text,
  periodo text,
  volume_atual integer,
  volume_anterior integer,
  crescimento numeric,
  confianca numeric
)
language sql
security definer
set search_path = public
as $$
  with atual as (
    select
      lower(trim(tema)) as tema,
      max(ramo) as ramo,
      coalesce(sum(volume) filter (where dia >= current_date - 6),0)::int as v_atual,
      coalesce(sum(volume) filter (where dia between current_date - 13 and current_date - 7),0)::int as v_ant
    from public.evolui_comportamento_agregado
    where lower(trim(tema)) = lower(trim(p_tema))
      and (p_ramo is null or lower(coalesce(ramo,'')) = lower(trim(p_ramo)))
      and dia >= current_date - greatest(7, least(coalesce(p_dias,30), 90))
    group by lower(trim(tema))
  )
  select
    tema,
    ramo,
    '7d_vs_7d'::text,
    v_atual,
    v_ant,
    case when v_ant > 0 then round(((v_atual - v_ant)::numeric / v_ant) * 100, 2) else null end,
    case when v_atual >= 10 then 0.9 when v_atual >= 5 then 0.8 else 0.7 end
  from atual
  where v_atual >= 3;
$$;

revoke all on function public.evolui_registrar_sinal_agregado(text,text,text) from public;
revoke all on function public.evolui_obter_sinais_agregados(text,text,integer) from public;
-- O runtime da Edge Function usa a service role e continua autorizado.

comment on table public.evolui_comportamento_agregado is
  'Volumes agregados de uso para inteligência do produto; não armazena user_id.';
