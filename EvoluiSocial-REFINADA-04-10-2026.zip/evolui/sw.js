/* Felipe Branding — Service Worker
   Estratégia:
   - HTML (navegação): network-first, com fallback pro cache se ficar offline.
     Garante que o visitante sempre veja a página mais nova quando há internet.
   - /assets/* (CSS/JS com hash no nome): cache-first, praticamente para sempre.
     Como o nome do arquivo muda a cada alteração de conteúdo, é seguro cachear
     "para sempre" — um arquivo com hash novo é, por definição, um arquivo novo.
   - Tudo que não é do mesmo site (Supabase, Google Fonts, YouTube etc.):
     não intercepta — deixa o navegador cuidar normalmente.
*/
// fb-v2 (29/09): apaga o cache antigo — ele guardava para sempre arquivos
// SEM hash no nome (ex.: apresentacao.js com correção de segurança).
var CACHE_VERSION = 'fb-v2';
var STATIC_CACHE = CACHE_VERSION + '-static';
var PAGES_CACHE = CACHE_VERSION + '-pages';

self.addEventListener('install', function(event){
  self.skipWaiting();
});

self.addEventListener('activate', function(event){
  event.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys
          .filter(function(k){ return k.indexOf('fb-') === 0 && k !== STATIC_CACHE && k !== PAGES_CACHE; })
          .map(function(k){ return caches.delete(k); })
      );
    }).then(function(){ return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function(event){
  var req = event.request;
  if(req.method !== 'GET') return;

  var url = new URL(req.url);
  if(url.origin !== self.location.origin) return; // não mexe em recursos de terceiros

  // Arquivos versionados por hash (nome.0123456789.js/css) e imagens —
  // cache-first. Arquivo SEM hash vai para a rede primeiro (senão uma
  // correção nunca chegaria a quem já visitou o site).
  var versionado = /\.[0-9a-f]{10}\.(js|css)$/.test(url.pathname) || /^\/assets\/img\//.test(url.pathname);
  if(url.pathname.indexOf('/assets/') === 0 && !versionado){
    event.respondWith(
      fetch(req).then(function(res){
        if(res && res.status === 200){ var c = res.clone(); caches.open(STATIC_CACHE).then(function(cache){ cache.put(req, c); }); }
        return res;
      }).catch(function(){ return caches.match(req); })
    );
    return;
  }
  if(versionado){
    event.respondWith(
      caches.open(STATIC_CACHE).then(function(cache){
        return cache.match(req).then(function(cached){
          if(cached) return cached;
          return fetch(req).then(function(res){
            if(res && res.status === 200) cache.put(req, res.clone());
            return res;
          });
        });
      })
    );
    return;
  }

  // Páginas HTML — network-first, cai pro cache só se estiver offline.
  // Painel e editor: sempre da rede, nunca guardados (área logada).
  if(url.pathname.indexOf('/painel') === 0 || url.pathname.indexOf('/admin') === 0) return;
  if(req.mode === 'navigate' || (req.headers.get('accept') || '').indexOf('text/html') !== -1){
    event.respondWith(
      fetch(req).then(function(res){
        var copy = res.clone();
        caches.open(PAGES_CACHE).then(function(cache){ cache.put(req, copy); });
        return res;
      }).catch(function(){
        return caches.match(req).then(function(cached){ return cached || caches.match('/'); });
      })
    );
  }
});
