# Relatório — Contatos do site, Painel e Admin (29/09/2026)

## 1. Verificação: os e-mails do formulário da home estavam chegando?

**Não, e nunca chegaram.** O formulário "Vamos conversar" da página inicial só montava uma mensagem e abria o WhatsApp. Nada era gravado no banco, nada aparecia no painel e nenhum e-mail era enviado. Se o visitante fechasse o WhatsApp sem tocar em "enviar", o contato se perdia sem deixar rastro.

- No Supabase de produção não existia nenhuma tabela para esses contatos.
- O único formulário que gravava alguma coisa era o do /consultas: são 6 registros, o último de 21/09. Eles aparecem em **Consultas** no painel, mas também não geram e-mail.

## 2. O que foi criado: o processo de receber e conferir os contatos

```
Visitante envia o formulário da home
  └─ Function contato-criar (pública, validação, anti-robô, 5 envios / 15 min por IP)
       ├─ 1. grava em site_contatos (banco)          → nunca se perde
       ├─ 2. trigger no banco → notificação no sino  → "Novo contato pelo site: Nome" (prioridade alta, botão "Abrir")
       ├─ 3. e-mail para contato@felipebranding.com.br (caixa Umbler; "Responder" já vai para o visitante)
       └─ 4. registra o resultado do e-mail: enviado / falhou / SMTP não configurado
Job de hora em hora (scheduled-sync-background)
  └─ confere os avisos pendentes ou que falharam, tenta de novo (até 5 vezes)
       ├─ se o SMTP não estiver configurado → avisa no sino (1× por dia)
       └─ se desistir → avisa no sino como erro, com o nome dos contatos
Painel → "Contatos do site" (admin e prospecção)
  ├─ cartão no topo: "Avisos por e-mail funcionando / desligados / N não confirmados" + botão "Testar envio de e-mail"
  ├─ lista com status (Novo, Em atendimento, Respondido, Virou cliente, Arquivado) e status do e-mail de cada contato
  ├─ detalhe: mensagem, responder no WhatsApp ou por e-mail, "Reenviar aviso por e-mail", observações internas
  └─ contador vermelho no menu com os contatos ainda "Novo"
```

Na home, o visitante agora vê **"Recebemos sua mensagem"** e pode falar pelo WhatsApp se quiser adiantar. Se o site falhar ao gravar, a mensagem já fica pronta no WhatsApp, com o texto "Não conseguimos registrar pelo site agora".

**Segurança (banco):** o visitante só consegue *inserir* os campos do formulário. Ele não lê nada, não marca o contato como "respondido" e não altera o controle de e-mail. Só admin e prospecção veem os contatos, e só admin exclui. O teste de ataque do robô passou de 22 para **35 testes, com 0 falhas**. Os testes novos são A05–A08, B06, B07, C07, C08 e F08–F12. **Esse SQL já está aplicado em produção**: a migração se chama `site_contatos_formulario_home`. Um teste real em produção foi feito dentro de uma transação desfeita, e nenhum dado ficou gravado.

### O que você precisa fazer (sem isso o e-mail não sai)

| # | Onde | O quê |
|---|---|---|
| 1 | Netlify → Deploys | Publicar esta versão do site. Os arquivos estão em `site-completo-corrigido.zip`. |
| 2 | Netlify → Site settings → Environment variables | Conferir se `UMBLER_SMTP_USER` e `UMBLER_SMTP_PASS` existem. São o e-mail e a senha da caixa contato@. |
| 3 | idem (opcional) | `SUPABASE_SERVICE_ROLE_KEY`: sem ela o reenvio automático de hora em hora não roda. O reenvio manual no painel funciona mesmo sem ela. |
| 4 | idem (opcional) | `CONTATO_EMAIL_DESTINO`: só se quiser receber os avisos em outro e-mail. O padrão é contato@felipebranding.com.br. |
| 5 | Painel → Contatos do site | Clicar em **"Testar envio de e-mail"** e conferir a caixa de entrada e o spam. |

## 3. Painel: refatoração por gravidade

A tela de cada painel foi testada logada, com dados simulados, em 5 larguras (360, 390, 768, 1024 e 1440 px), como admin e como prospecção. As Functions reais foram usadas nos testes.

| Grav. | Problema | Correção |
|---|---|---|
| P1 | Componentes `EmptyState`, `ErrorState`, `SuccessState`, `ConfirmDialog`, `AiAnalysisCard`, `InsightCard`, `IntelligenceBoard` e `HealthStatusCard` colocavam texto no HTML sem escape. As mensagens de erro do servidor também. | Os componentes passam a escapar sempre. `esc()` e `safeUrl()` ficam num só lugar (`utils/html.js`). Os 6 erros em Clientes e os 3 em Início foram escapados. |
| P1 | Clientes: o link público e a logo da apresentação, o id e o papel do funcionário no select, e o e-mail na tela de "acesso revogado" iam para o HTML sem proteção. | Escape, validação de protocolo (`safeUrl`) e `textContent`. |
| P1 | Confirmação de exclusão focava direto no botão **Excluir**: um Enter distraído apagava o registro. | O foco inicial vai para **Cancelar**. |
| P2 | Modais (Consultas, Prospecção, Financeiro, confirmações): o Tab escapava para a página de trás, o foco não voltava ao botão que abriu o modal, não havia nome acessível e o fundo rolava. | Novo modal compartilhado (`components/Modal.js`): foco preso, Esc fecha, foco devolvido, título associado, botão fechar, rolagem travada. No celular abre como gaveta de baixo para cima. |
| P2 | Início e Financeiro: rolagem lateral de 103 a 240 px no celular quando havia nome, e-mail ou texto longo. | Quebra de texto e `min-width: 0` nos blocos. A sonda confirma 0 px de rolagem lateral nas 5 larguras. |
| P2 | Linhas de Consultas, Clientes e Prospecção só abriam com o mouse. | Botão ou link de verdade: Tab + Enter funcionam. |
| P2 | Menu mostrava o grupo "Financeiro" vazio para quem não é admin, e a marca era um SVG cortado que aparecia como um pontinho. | Grupo escondido, logo real da marca. |
| P3 | 132 campos com rótulo solto, não associado ao campo (Clientes, Prospecção, Financeiro, Consultas, Equipe). | `for`/`id` ou `aria-label` em todos. |
| P3 | Botões com 21–30 px de altura no celular, e o "excluir mensagem" do mural invisível no toque (só aparecia no hover). | Mínimo de 40 px no celular. O excluir do mural fica visível em telas de toque. |
| P3 | Sem `[hidden]` global, sem foco visível padrão e sem respeito a "reduzir movimento". | Adicionados. |
| P3 | Links `target="_blank"` sem `rel`. | `noopener noreferrer`. |

**Resultado das sondas (resumo completo em `relatorios/`):**

- **Modo normal:** 0 XSS, 0 erro de JavaScript, 0 Function quebrando, 0 rolagem lateral, 0 campo sem rótulo. Sobrou 1 checkbox de tabela com 28×22 px (P4).
- **Modo erro** (todas as Functions falhando com uma mensagem maliciosa): nenhuma tela executou código, travou ou ficou carregando para sempre.
- **Modo interação:** os modais passaram nos testes de foco, Esc e altura.

## 4. Admin (`/admin`): refatoração por gravidade

| Grav. | Problema | Correção |
|---|---|---|
| **P0** | Se o conteúdo do banco não carregasse (rede, bloqueador de anúncio, sessão), o editor abria com o **conteúdo padrão**, e o primeiro "Salvar" **substituía o site publicado inteiro** por ele. | A edição fica travada, com a mensagem "Não foi possível carregar…" e um botão "Tentar novamente". Salvar é recusado enquanto o conteúdo real não carregar. |
| P1 | Importar backup publicava na hora, sem confirmação e sem checar se o arquivo era um backup do painel. | Confirmação ("substitui TODO o conteúdo publicado") e validação do arquivo. |
| P1 | O campo de imagem aceitava `javascript:` e qualquer endereço. Upload de até 700 KB, com aviso errado de "armazenamento local"; na prática a imagem vira texto que todo visitante baixa. | Aceita só `https://`, caminho do site ou imagem enviada. Bloqueia acima de 1 MB e alerta acima de 350 KB. |
| P2 | Fechar a aba ou clicar em "Bloquear" perdia as edições sem avisar. | Aviso de "alterações não salvas". |
| P2 | **No celular o editor tinha cerca de 140 px de largura** (a barra lateral de 250 px ficava ao lado). | Abaixo de 860 px, o menu vira uma faixa de abas roláveis em cima e o editor ocupa a tela toda (confirmado em 360, 390 e 768). |
| P2 | Os botões do menu tinham o fundo cinza padrão do navegador (quadros claros no tema escuro), e a logo era o mesmo SVG cortado. | Reset de botão e logo real. |
| P2 | Login sem `<form>` (gerenciador de senhas não reconhece), rótulos de campo não associados, erro de login não anunciado. | `<form>`, `for`/`id` em todos os campos, `role="alert"`. |
| P3 | Script inline de registro do service worker (bloqueado pela CSP quando ela for ativada). | Movido para o JS. |

**Sonda do admin:** 12 de 12 passaram (login, conteúdo publicado carregado, salvar, recusa de `javascript:`, trava quando a carga falha, recuperação, layout em 360, 390 e 768, sem erro de JavaScript).

## 5. Outras correções encontradas no caminho

- **Service worker** (`sw.js`): guardava "para sempre" arquivos **sem hash** no nome. O `apresentacao.js`, com a correção de segurança anterior, nunca chegaria a quem já tinha aberto o /admin. Agora esses arquivos vêm da rede primeiro, o cache antigo é apagado (`fb-v2`) e painel/admin nunca ficam guardados.
- `_headers`: `tilt-card.js/css` e `intro-gradient.css` saíram do cache "imutável" de 1 ano.
- `_redirects`: bloqueia o SQL novo e os relatórios novos (404).
- E-mails com acento no assunto agora chegam legíveis (RFC 2047), e o aviso tem **Responder direto ao visitante** (Reply-To).
- Botão "Gerar PDF" da apresentação ganhou nome acessível.

## 6. Testes

| Suíte | Resultado |
|---|---|
| Testes do projeto (`node tests/run-all.js`) | **208/208** (11 novos: contato-criar, job de verificação, montagem do e-mail, SMTP com acento e Reply-To) |
| Ataques ao banco (Postgres local, robô) | **35/35**, 0 vulnerável, 0 quebrado |
| Home: formulário (sucesso, erro 502, erro de campo, sem rede) × 390/1440 | 8/8 |
| Sonda do painel (normal, interação, erro, papel prospecção) | sem XSS, erro de JS, rolagem lateral ou Function quebrando |
| Sonda do admin | 12/12 |
| Robô completo | 0 crítico. Os "altos" restantes são decisões de negócio já listadas (aviso de privacidade/LGPD com página /privacidade, "guia gratuito", isca /consultas no hero, diagnóstico por sorteio, selo "verificado") |

## 7. Arquivos alterados ou criados nesta rodada

**Novos:**

- `SQL_PENDENTE_site_contatos.sql`
- `netlify/functions/contato-criar.js`
- `netlify/functions/contatos-site.js`
- `netlify/functions/_lib/services/siteContatosService.js`
- `tests/siteContatos.test.js`
- `painel/assets/js/views/contatosSite.js`
- `painel/assets/js/services/contatosSiteClient.js`
- `painel/assets/js/components/Modal.js`
- `painel/assets/js/utils/html.js`

**Alterados:**

- `index.html`
- `assets/js/site.6acb3cb59d.js` (no lugar de `site.097b651b6f.js`)
- `assets/css/main.137696d24c.css` (no lugar de `main.20503ed9c4.css`)
- `consultas.html` (novo nome do CSS)
- `admin.html`
- `assets/js/admin.69ddfd8809.js` (no lugar de `admin.1b9240a4b5.js`)
- `assets/css/admin.7bbe165e77.css` (no lugar de `admin.b72f9f459d.css`)
- `sw.js`
- `_headers`
- `_redirects`
- `apresentacao.html`
- `netlify/functions/scheduled-sync-background.js`
- `netlify/functions/_lib/integrations/rawSmtp.js`
- `netlify/functions/_lib/integrations/umblerSmtp.js`
- `tests/rawSmtp.test.js`
- Painel:
  - `index.html`
  - `app.js`
  - `admin-app.css`
  - `financeiro-view.css`
  - componentes `ConfirmDialog`, `EmptyState`, `ErrorState`, `SuccessState`, `AiAnalysisCard`, `InsightCard`, `IntelligenceBoard`, `HealthStatusCard` e `NotificationsList`
  - views `clientes`, `consultorias`, `prospeccao`, `financeiro`, `funcionarios`, `inicio`, `insights` e `conteudo`

## 8. Continua pendente (depende de você)

1. Publicar no Netlify e configurar as variáveis do item 2.
2. Supabase → Authentication: desligar "Allow new users to sign up" e ligar "Leaked password protection".
3. Decisões de negócio já listadas: página /privacidade (LGPD, agora ainda mais importante porque o formulário grava dados), textos de "guia gratuito" e "1 dia útil", portfólio e depoimentos reais, atribuir os 50 leads à Bianca e link da consultoria no topo da home.

## 9. Supabase — configuração aplicada (29/09, noite)

- Estrutura do banco de produção conferida contra tudo que o código usa: todas as tabelas e colunas existem (inclusive `site_contatos`).
- Migração `otimizacao_indices_fk_e_rls_initplan` (arquivo `SQL_OTIMIZACAO_29_09.sql`):
  - 6 índices novos nas chaves estrangeiras (mural, métricas, atividades e contatos por lead, leads por responsável);
  - 14 regras de acesso reescritas no formato recomendado pelo Supabase (`(select auth.uid())`), com o mesmo resultado e calculado uma vez por consulta em vez de uma vez por linha.
- Backup das regras antes da mudança: `backup_auditoria.policies_29_09_otimizacao` (114 regras).
- Conferido em produção, com a transação desfeita no fim:
  - o admin continua vendo os 50 leads, 6 consultas e a equipe;
  - a prospecção vê só o que é dela;
  - uma conta qualquer continua sem ver nada.
- Robô, com banco local e a mesma migração: 35/35.
- Só pelo painel do Supabase (a ferramenta de conexão não tem acesso a essas opções):
  - Authentication → Sign In / Providers → desligar **"Allow new users to sign up"**;
  - Authentication → Providers → Email → **"Prevent use of leaked passwords"** (só nos planos Pro ou acima).
