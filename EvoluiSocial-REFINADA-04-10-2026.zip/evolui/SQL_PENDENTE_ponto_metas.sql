-- ============================================================
-- Boas-vindas no Início: perfil (foto), ponto (dias/horas trabalhados) e
-- metas de prospecção (semanal/mensal) — pedido do Felipe, 13/09.
-- ============================================================
-- Aditivo e não-destrutivo: só cria tabelas novas e adiciona 1 coluna
-- nullable em admin_funcionarios. Nada existente é alterado ou apagado.
-- ============================================================

-- 1) Foto de perfil — opcional, só admin edita (mesma regra de
-- nome/role/ativo já existente pra admin_funcionarios).
alter table admin_funcionarios add column if not exists foto_url text;

-- ============================================================
-- 2) Ponto — "dias/horas trabalhados" tem que vir de um evento real que o
-- sistema consegue determinar (mesmo princípio de "não crie automação
-- falsa" já usado na Prospecção): cada linha é UM CLIQUE em Entrada/Saída,
-- não um número estimado. O funcionário só REGISTRA o evento — não edita
-- nem apaga depois (por isso não existe policy de update/delete pra ele,
-- só de insert/select da própria linha). Cálculo de horas/dias acontece no
-- painel a partir destes registros brutos, nunca editado direto.
-- ============================================================
create table if not exists admin_ponto_registros (
  id uuid primary key default gen_random_uuid(),
  funcionario_id uuid not null references admin_funcionarios(id) on delete cascade,
  tipo text not null check (tipo in ('entrada','saida')),
  registrado_em timestamptz not null default now(),
  created_at timestamptz not null default now()
);
alter table admin_ponto_registros enable row level security;

create index if not exists admin_ponto_registros_funcionario_idx
  on admin_ponto_registros (funcionario_id, registrado_em desc);

drop policy if exists "select_ponto_propria_ou_admin" on admin_ponto_registros;
drop policy if exists "insert_ponto_propria_linha" on admin_ponto_registros;

create policy "select_ponto_propria_ou_admin" on admin_ponto_registros for select
  using (admin_eh_admin() or funcionario_id = auth.uid());
create policy "insert_ponto_propria_linha" on admin_ponto_registros for insert
  with check (funcionario_id = auth.uid());
-- Sem policy de update/delete pra ninguém (nem admin) de propósito — é um
-- registro de ponto, precisa continuar confiável. Correção de um lançamento
-- errado é um caso raro o bastante pra ser feito direto no SQL Editor, não
-- pela interface.

comment on table admin_ponto_registros is 'Um evento por clique em Entrada/Saída no Início. Fonte real de "dias/horas trabalhados" — nunca um número declarado manualmente.';

-- ============================================================
-- 3) Metas de prospecção (semanal/mensal) — Felipe define, aparece pro
-- funcionário de prospecção no Início. O PROGRESSO é calculado a partir de
-- admin_prospeccao_atividades (tipo='whatsapp_enviado') no período — a
-- pessoa nunca precisa "enviar os dados pra ele", o sistema já sabe.
-- ============================================================
create table if not exists admin_metas_prospeccao (
  id uuid primary key default gen_random_uuid(),
  funcionario_id uuid not null references admin_funcionarios(id) on delete cascade,
  periodo text not null check (periodo in ('semanal','mensal')),
  referencia date not null, -- semanal: segunda-feira da semana; mensal: dia 1 do mês
  meta int not null check (meta > 0),
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz,
  unique (funcionario_id, periodo, referencia)
);
alter table admin_metas_prospeccao enable row level security;

drop policy if exists "select_metas_propria_ou_admin" on admin_metas_prospeccao;
drop policy if exists "somente_admin_insert_metas" on admin_metas_prospeccao;
drop policy if exists "somente_admin_update_metas" on admin_metas_prospeccao;
drop policy if exists "somente_admin_delete_metas" on admin_metas_prospeccao;

create policy "select_metas_propria_ou_admin" on admin_metas_prospeccao for select
  using (admin_eh_admin() or funcionario_id = auth.uid());
create policy "somente_admin_insert_metas" on admin_metas_prospeccao for insert
  with check (admin_eh_admin());
create policy "somente_admin_update_metas" on admin_metas_prospeccao for update
  using (admin_eh_admin());
create policy "somente_admin_delete_metas" on admin_metas_prospeccao for delete
  using (admin_eh_admin());

comment on table admin_metas_prospeccao is 'Meta de prospecções (mensagens enviadas) que o Felipe define por pessoa/período. Progresso = contagem real de admin_prospeccao_atividades tipo=whatsapp_enviado no período — nunca um número declarado manualmente.';
