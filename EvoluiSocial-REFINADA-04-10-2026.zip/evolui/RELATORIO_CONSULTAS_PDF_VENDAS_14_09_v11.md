# Consultas — o botão de PDF agora ajuda a vender — 14/09 (11ª rodada)

## O que você perguntou

"É possível gerar vendas com essa consulta no botão de PDF?"

## O que eu encontrei

Sim, é bem possível, só que o botão "Salvar resultado em PDF" (que abre a caixa de impressão do navegador) estava fazendo o contrário: ele apagava de propósito os botões de contato (Falar com Felipe, Agendar, Instagram) na hora de imprimir, porque botão que não clica não faz sentido no papel. O problema é que, junto com os botões, sumia qualquer jeito de a pessoa voltar a falar com você a partir do PDF salvo.

Investigando mais a fundo achei um segundo problema, mais escondido: o quadro final de CTA e o card "Você viu todas as dicas" são escuros de propósito na tela (texto claro em fundo azul-escuro). Só que a maioria dos navegadores, por padrão, **não imprime cor de fundo** a não ser que a pessoa marque manualmente uma caixinha escondida ("gráficos de fundo") na tela de impressão — quase ninguém marca. Sem o fundo escuro, o texto claro original ficava quase invisível numa página em branco. Ou seja: mesmo sem meu problema do contato sumido, o título de fechamento do CTA (que já é a parte mais importante da página inteira pra puxar conversa) já ia sair ilegível na maioria dos PDFs salvos.

## O que eu mudei

**1. Contato em texto, no lugar dos botões**

Onde os botões somem na impressão, agora aparece um bloco de texto simples:

```
Fale com a Felipe Branding
WhatsApp: (87) 98179-8483
Instagram: @seu_usuario   (só aparece se tiver Instagram cadastrado)
E-mail: contato@felipebranding.com.br
felipebranding.com.br
```

O número e o e-mail vêm dos mesmos dados de contato que a página já carrega (o painel administrativo, se você mudar o WhatsApp por lá, atualiza aqui também, sem precisar mexer em código).

**2. Texto sempre legível, não importa a configuração de impressão de quem salva**

Forcei o quadro final de CTA e o card "Você viu todas as dicas" a imprimir sempre em fundo branco com letra escura, testei os dois cenários possíveis (com e sem "gráficos de fundo" marcado) e os dois ficaram idênticos e legíveis.

**3. O quadro final não quebra mais no meio**

Antes, se a página de impressão terminasse bem no meio do CTA final, ele quebrava em duas páginas (a frase cortava no meio de uma palavra). Agora ele sempre fica inteiro numa página só, mesmo que precise "empurrar" o resto pra página seguinte.

## Como eu testei

Não dava pra confiar só no preview em tela: o Chrome mostra sempre com fundo colorido na pré-visualização de impressão, mas o PDF de verdade depende de uma opção que a maioria das pessoas nunca vê. Então gerei o PDF de verdade dos dois jeitos (com e sem a tal opção marcada) e conferi cada página, imagem por imagem:

- Sem "gráficos de fundo" (o caso mais comum): tudo legível, contato aparece certinho, nada cortado.
- Com "gráficos de fundo": mesmo resultado, sem conflito de cor.
- `node --check` e suíte de testes: **174 testes, todos passando**.
- Também já atualizei a prévia ao vivo (mesmo link, agora Versão 5) — repare que a prévia não tem o botão de PDF de verdade (ela roda isolada, sem o motor de diagnóstico "de verdade" plugado no backend), mas o texto de contato e as cores corrigidas já estão lá, então dá pra abrir a tela de impressão do navegador (Ctrl+P / Cmd+P) na prévia pra conferir o resultado.

## O que eu não mexi (e por quê)

Não toquei em nada do conteúdo do diagnóstico nem da parte de tela normal (o botão continua sendo `window.print()`, não virou um gerador de PDF separado) — a mudança foi só garantir que o PDF, quando alguém salva, carrega um jeito de voltar a falar com você. Também não coloquei nenhum dado que não existisse já no site (nada de número ou depoimento inventado, mesma linha da rodada anterior).

## O que fazer agora

Nada manual, sem mudança de banco. Só instalar o zip anexo por cima do anterior.
