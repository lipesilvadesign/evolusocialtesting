# Consultas — animações modernas e profissionais — 14/09 (9ª rodada)

## O que foi pedido

"Procure animações estilizáveis modernas e profissionais para adicionar na página."

## O que eu pesquisei

Antes de sair adicionando qualquer coisa, pesquisei o que sites premium (tipo os que ganham prêmio no Awwwards) e artigos de tendência de design 2026 estão usando como microinteração hoje: glassmorphism em cabeçalho, botão "magnético" (o botão puxa levemente na direção do cursor), brilho que segue o cursor dentro de um card, efeito de "decodificação"/scramble em texto curto, zoom em imagem no hover, feedback de formulário animado, entre outros.

Descartei o que a página já tinha (fade-in ao rolar, transições suaves, respeito a "reduzir movimento") e o que não fazia sentido aqui (zoom de imagem — a página não tem fotos de produto; feedback de formulário — os campos já têm validação visual). Fiquei com 4 que se encaixam bem no que a página já é, sem precisar redesenhar nada:

1. **Cabeçalho com vidro fosco ao rolar** — o cabeçalho fica translúcido e com um leve desfoque atrás assim que você rola a página. O CSS pra isso já existia no site (é o mesmo efeito da home), só que na página de consultas ninguém tinha ligado o gatilho de rolagem ainda. Liguei.
2. **Botões "magnéticos"** — nos botões principais (Enviar, Avançar, Falar com Felipe etc.), o botão se desloca um pouquinho na direção de onde o mouse está por cima dele, como se fosse atraído. É um dos efeitos mais usados em sites de agência premium hoje. Só acontece com mouse (não em celular/toque) e desloca no máximo 10px pra cada lado, então não atrapalha o clique.
3. **Brilho que segue o cursor** — nos cards de categoria do diagnóstico e nos cards de dica, passar o mouse por cima acende um brilho sutil bem no ponto onde o cursor está, dando profundidade sem mudar a cor da marca (usa a própria cor do texto, bem clara). Também só em mouse.
4. **Selo "decodificando"** — os selinhos de avaliação (tipo "Ponto de atenção", "Oportunidade clara") aparecem com um efeito de letras embaralhando por um instante antes de assentar no texto final, tipo terminal decifrando um código. Como esses selos já são maiúsculos e em fonte monoespaçada, o efeito combina com o visual que já existia, sem precisar mudar nada no design. Cada selo começa um pouquinho depois do anterior, criando uma sequência.

Todos os quatro respeitam "reduzir movimento" (quem ativa essa opção no aparelho não vê nenhum deles: o cabeçalho ainda funciona, mas sem o efeito visual de transição, os selos aparecem direto com o texto final, e os efeitos de cursor ficam desligados).

## O que eu não mexi

Não toquei no efeito já existente de revelar o @ do perfil letra por letra (isso já tinha sido aprovado numa rodada anterior). Também não usei nenhuma biblioteca externa nem script de fora — é tudo CSS e JavaScript puro, do jeito que a página já era, porque a política de segurança do site não permite carregar script de outro domínio.

## Verificação

- `node --check` no arquivo tocado: sem erro.
- Suíte de testes: **174 testes, todos passando**.
- Testei de ponta a ponta simulando um diagnóstico completo (celular 390px e computador 1440px):
  - Cabeçalho: confirmei que a classe de "rolado" liga e desliga certinho ao rolar a página.
  - Botão magnético: confirmei que ele se desloca com o mouse e volta ao normal quando o mouse sai.
  - Brilho no cursor: confirmei que ele acende só no hover, na posição certa, e some se "reduzir movimento" está ativo.
  - Selo decodificando: confirmei que o texto final sempre bate certo com a avaliação real (nunca fica com letra errada) e que, com "reduzir movimento" ativo, aparece direto sem embaralhar.
  - Celular: nada vazando da tela (testei antes e depois, sem novo estouro de layout).
- Também já atualizei a prévia ao vivo que te mandei antes — o mesmo link já está com essas quatro novidades, é só abrir de novo.

## O que fazer agora

Nada manual, sem mudança de banco. Só instalar o zip anexo por cima do anterior.
