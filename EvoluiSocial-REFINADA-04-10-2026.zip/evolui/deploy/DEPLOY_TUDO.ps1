param(
  [string]$SupabaseProjectRef = "",
  [switch]$DeployNetlify,
  [switch]$BuildEviImage,
  [string]$EviImageTag = "evolui-evi-video:v1"
)
$ErrorActionPreference = "Stop"

Write-Host "=== Evolui Social — deploy consolidado ===" -ForegroundColor Cyan
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if ($SupabaseProjectRef) {
  Write-Host "[1/3] Deploy da Edge Function evolui-api..." -ForegroundColor Yellow
  supabase functions deploy evolui-api --project-ref $SupabaseProjectRef
} else {
  Write-Host "[1/3] Supabase: SUPABASE_PROJECT_REF não foi informado. Execute o deploy manual da evolui-api nesta rodada." -ForegroundColor Yellow
}

if ($DeployNetlify) {
  Write-Host "[2/3] Deploy do frontend no Netlify..." -ForegroundColor Yellow
  npx netlify deploy --prod --dir .
} else {
  Write-Host "[2/3] Netlify: use seu site conectado normalmente ou rode com -DeployNetlify." -ForegroundColor Yellow
}

if ($BuildEviImage) {
  Write-Host "[3/3] Build do EVI Video Worker..." -ForegroundColor Yellow
  docker build -t $EviImageTag ./evi-video-worker
  Write-Host "Imagem criada: $EviImageTag" -ForegroundColor Green
  Write-Host "Publique esta imagem no seu registry/host de containers uma única vez e configure EVI_VIDEO_WORKER_URL no Supabase." -ForegroundColor Yellow
} else {
  Write-Host "[3/3] EVI Worker: build não executado. Rode com -BuildEviImage quando for publicar o worker." -ForegroundColor Yellow
}

Write-Host "=== Fim da rodada de deploy ===" -ForegroundColor Green
Write-Host "Depois desta rodada, o benchmark KeyAPI pode ser executado sem novo deploy." -ForegroundColor Green
