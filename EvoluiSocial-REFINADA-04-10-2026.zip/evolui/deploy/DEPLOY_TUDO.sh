#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

SUPABASE_PROJECT_REF="${SUPABASE_PROJECT_REF:-}"
DEPLOY_NETLIFY="${DEPLOY_NETLIFY:-0}"
BUILD_EVI_IMAGE="${BUILD_EVI_IMAGE:-0}"
EVI_IMAGE_TAG="${EVI_IMAGE_TAG:-evolui-evi-video:v1}"

if [[ -n "$SUPABASE_PROJECT_REF" ]]; then
  supabase functions deploy evolui-api --project-ref "$SUPABASE_PROJECT_REF"
else
  echo "SUPABASE_PROJECT_REF não definido; faça o deploy da evolui-api conforme seu projeto Supabase."
fi

if [[ "$DEPLOY_NETLIFY" == "1" ]]; then
  npx netlify deploy --prod --dir .
fi

if [[ "$BUILD_EVI_IMAGE" == "1" ]]; then
  docker build -t "$EVI_IMAGE_TAG" ./evi-video-worker
fi

echo "Rodada consolidada concluída."
