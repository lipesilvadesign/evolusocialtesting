# Consultor de Marketing por IA — Felipe Branding Admin

## 1. Provedor de IA utilizado

**Anthropic (API Claude)**, chamada direto via `fetch` (sem SDK — mesmo padrão zero-dependências do resto do projeto), em `netlify/functions/_lib/integrations/aiProvider.js`.

- Endpoint: `https://api.anthropic.com/v1/messages`
- Modelo padrão: `claude-haiku-4-5-20251001` (mais barato — a tarefa é extração/análise estruturada, não exige o modelo mais caro)
- Saída forçada em JSON via **tool use** (function calling): em vez de pedir "responda em JSON" em texto livre (frágil, pode vir com texto extra ou markdown), a chamada obriga o modelo a preencher os parâmetros de uma ferramenta (`submit_marketing_analysis`) com um schema fixo — a resposta já chega como objeto estruturado, não como string pra fazer `JSON.parse`.

## 2. Variáveis de ambiente

| Variável | Obrigatória? | O que é |
|---|---|---|
| `AI_API_KEY` | Sim | Chave da API da Anthropic. Só server-side (Netlify Function), nunca vai ao frontend. |
| `AI_MODEL` | Não | Sobrescreve o modelo padrão. Ex: `claude-sonnet-5` pra análises mais elaboradas (custo maior). |

Configurar em **Project configuration → Environment variables** do site (não em "Team settings" — essa parte é paga; a variável do site é grátis).

## 3. Estrutura do prompt

- **System prompt** (fixo, em `aiProvider.js`, `SYSTEM_PROMPT`): define o papel (consultor de marketing), as regras de não-invenção, a proibição de linguagem causal, a escala de `evidence_strength`, a exigência de recomendações específicas (não genéricas) e a obrigação de responder só pela ferramenta.
- **Mensagem do usuário**: o `AiContext` inteiro, serializado em JSON — montado pelo **AI Context Builder** (`netlify/functions/_lib/aiContextBuilder.js`), que seleciona só o necessário do snapshot normalizado + dos insights determinísticos já calculados (até 5 páginas, 5 eventos, 5 fontes de tráfego, 10 insights — nunca o payload bruto do Google).
- **Versão do prompt**: constante `PROMPT_VERSION = 'v1'` em `aiInsightsService.js`. Entra na chave de cache e no registro de histórico — se o texto do `SYSTEM_PROMPT` ou o schema da ferramenta mudar, subir essa versão evita misturar análises de prompts diferentes.

## 4. Schema da resposta

A IA só pode responder preenchendo esta estrutura (imposta via tool use, e **revalidada de novo** no backend em `aiResponseSchema.js` — nunca confia cegamente no que veio da API):

```json
{
  "summary": "string",
  "insufficient_data": true,
  "positive_points": [{ "text": "string", "evidence_strength": "forte|moderada|limitada", "related_metric": "string" }],
  "attention_points": [{ "...": "mesma forma de positive_points" }],
  "opportunities": [{ "...": "mesma forma de positive_points" }],
  "recommendations": [
    { "title": "string", "explanation": "string", "evidence": "string", "suggested_action": "string", "priority": "baixa|media|alta" }
  ],
  "questions_to_investigate": ["string"]
}
```

Qualquer campo ausente, de tipo errado, ou fora do enum (`evidence_strength`/`priority`) faz `aiResponseSchema.js` lançar `AiError('AI_INVALID_RESPONSE')` — a resposta nunca chega na UI malformada.

## 5. Estratégia de cache

- Chave: `ai-analysis:{promptVersion}:{rangeKey}:{hashDasMetricas}` — o hash (SHA-256, primeiros 12 caracteres) é calculado em cima dos valores/variações das métricas principais, então mesmo dentro do mesmo período, se os números mudarem de forma relevante (nova sincronização do GA4), o cache não serve um resultado desatualizado.
- TTL: **1 hora** (mais longo que o cache de analytics puro, porque cada chamada à IA tem custo real).
- **Atualização manual**: botão "Gerar nova análise" na UI → `?refresh=true` na Function → `invalidate()` remove a chave antes de rechamar a IA, e o resultado novo já fica salvo no cache pra próxima leitura normal.
- Mesma limitação já documentada no cache de analytics: é em memória do processo, não sobrevive a cold start do Netlify — não é um cache distribuído.

## 6. Tratamento de erros

Erros tipados em `_lib/errors/aiErrors.js`, nunca vazam stack trace nem a chave de API:

| Código | Quando acontece | HTTP |
|---|---|---|
| `AI_CREDENTIALS_MISSING` | `AI_API_KEY` não configurada | 400 |
| `AI_AUTH_ERROR` | Chave inválida/revogada | 401 |
| `AI_RATE_LIMIT` | HTTP 429 da Anthropic | 429 |
| `AI_TIMEOUT` | Sem resposta em 20s | 504 |
| `AI_PROVIDER_UNAVAILABLE` | Erro genérico da API | 502 |
| `AI_INVALID_RESPONSE` | Resposta não bate com o schema | 502 |

Além disso: se o volume de dados do período for muito baixo (usuários ativos < 5), a IA **nem é chamada** — retorna direto "Não há dados suficientes para concluir." (economiza custo e cumpre o item 5 da etapa).

## 7. Custos potenciais

- Cada análise nova (cache miss) = 1 chamada à API da Anthropic. Com Haiku (modelo padrão), o custo por chamada é baixo (a entrada é um contexto compacto — poucos KB de JSON — e a saída é limitada a 1600 tokens).
- O cache de 1 hora + a exigência de clique manual pra forçar atualização limitam drasticamente quantas chamadas acontecem por dia, mesmo com vários acessos ao painel.
- Trocar `AI_MODEL` para um modelo maior (ex: Sonnet) aumenta o custo por chamada — não muda a lógica de cache/quantidade de chamadas, só o preço unitário.
- Nenhum custo é gerado enquanto `AI_API_KEY` não estiver configurada (a Function falha rápido com `AI_CREDENTIALS_MISSING`, sem tentar chamar a API).

## 8. Limitações conhecidas

- **Histórico não persiste ainda** — `aiHistoryService.js` só loga no console da Function (mesmo padrão do `auditLogService.js` da etapa CMS). A estrutura está pronta (ver `AiHistoryRecord` em `types.js`); a tabela sugerida pra quando isso for implementado de verdade:

```sql
create table if not exists admin_ai_analises (
  id uuid primary key default gen_random_uuid(),
  range_label text not null,
  prompt_version text not null,
  model text not null,
  metrics_used jsonb not null default '[]'::jsonb,
  recommendation_count int not null default 0,
  analysis jsonb not null,
  created_at timestamptz not null default now()
);
```

- **Ações das recomendações são só visuais** ("Analisar página" / "Ver métrica" / "Adicionar tarefa" aparecem como chips desabilitados) — nenhuma delas executa nada nesta etapa, por pedido explícito.
- A IA **nunca acessa** o Google Analytics nem o Supabase diretamente — só recebe o `AiContext` já filtrado. Se o Context Builder não incluir um dado, a IA simplesmente não tem acesso a ele (proteção estrutural contra invenção, não só uma instrução no prompt).
- O `evidence_strength` e o `priority` são linguagem qualitativa da própria IA, orientada pelo prompt — não é um cálculo estatístico determinístico (diferente da `confidence` do motor de insights, que é calculada por regra). O prompt instrui a IA a ser conservadora, mas a garantia de qualidade aqui é mais fraca do que a do motor determinístico da etapa anterior.
