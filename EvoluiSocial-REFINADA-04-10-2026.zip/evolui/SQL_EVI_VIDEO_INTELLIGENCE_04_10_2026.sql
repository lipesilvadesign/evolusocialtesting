-- EVI Video Intelligence v1
-- Memória por usuário das análises estruturadas. Não armazena o arquivo do vídeo.

create extension if not exists pgcrypto;

create table if not exists public.evolui_video_analises (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  url text not null,
  plataforma text not null default 'video',
  algoritmo text not null default 'evi-video-v1',
  titulo text,
  tema text,
  formato text,
  transcricao text,
  transcricao_meta jsonb not null default '{}'::jsonb,
  estrutura jsonb not null default '[]'::jsonb,
  retorica jsonb not null default '{}'::jsonb,
  ritmo jsonb not null default '{}'::jsonb,
  cenas jsonb not null default '[]'::jsonb,
  sinais_visuais jsonb not null default '{}'::jsonb,
  dna jsonb not null default '{}'::jsonb,
  lacunas jsonb not null default '[]'::jsonb,
  oportunidades jsonb not null default '[]'::jsonb,
  evi_score jsonb not null default '{}'::jsonb,
  impressao_digital text,
  ajuste_contextual_observavel jsonb not null default '{}'::jsonb,
  proveniencia jsonb not null default '{}'::jsonb,
  criado_em timestamptz not null default now()
);

create index if not exists idx_evi_video_analises_user_data
  on public.evolui_video_analises(user_id, criado_em desc);
create index if not exists idx_evi_video_analises_tema
  on public.evolui_video_analises(tema);
create index if not exists idx_evi_video_analises_algoritmo
  on public.evolui_video_analises(algoritmo, criado_em desc);

-- Migração aditiva para instalações que já possuem a tabela da v1 anterior.
alter table public.evolui_video_analises
  add column if not exists impressao_digital text,
  add column if not exists ajuste_contextual_observavel jsonb not null default '{}'::jsonb;

alter table public.evolui_video_analises enable row level security;

drop policy if exists "evi_video_select_own" on public.evolui_video_analises;
create policy "evi_video_select_own" on public.evolui_video_analises
  for select to authenticated using (auth.uid() = user_id);

drop policy if exists "evi_video_delete_own" on public.evolui_video_analises;
create policy "evi_video_delete_own" on public.evolui_video_analises
  for delete to authenticated using (auth.uid() = user_id);

revoke all on public.evolui_video_analises from anon;
revoke insert, update, delete on public.evolui_video_analises from authenticated;
grant select, delete on public.evolui_video_analises to authenticated;
grant all on public.evolui_video_analises to service_role;

comment on table public.evolui_video_analises is
  'EVI: memória estruturada de análises de vídeo por usuário. Não é base agregada de comportamento.';
