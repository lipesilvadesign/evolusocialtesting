# Evolui Social — Refatoração: Inteligência de Dados v1

## Objetivo

Adicionar uma camada de inteligência de dados ao motor existente sem substituir fontes, EIE, Claudia, Supabase, repertório ou a pesquisa avançada.

A ideia aproveitada da referência estudada é separar claramente:

`fonte → dado observado → sinal derivado → agregado`

A referência também descreve inferências, dados provenientes de outras fontes, integrações e análise de uso. Nesta refatoração, esses conceitos foram adaptados para o contexto da Evolui, sem copiar implementação ou texto da referência.

## O que entrou

### 1. Proveniência
Cada sinal agora carrega:
- origem;
- tipo de sinal;
- confiança;
- explicação;
- data de atualização.

### 2. Tipos de informação
- `explicito`: veio do contexto declarado/permitido da pesquisa;
- `observado`: veio de uma fonte consultada;
- `derivado`: calculado pela Evolui a partir de sinais existentes;
- `agregado`: reservado para futuras métricas agregadas sem identificação pessoal.

### 3. Fontes preservadas
A camada usa somente dados que a pesquisa já recuperou. Ela não cria uma nova coleta paralela.

Continuam preservados:
- Wikipédia;
- GDELT;
- Google Trends;
- YouTube quando habilitado;
- biblioteca/repertório;
- pesquisa web avançada SearXNG/Firecrawl;
- taxonomia e EIE.

### 4. Convergência
Quando duas ou mais fontes apresentam sinais compatíveis, a Evolui registra `convergencia_de_fontes` como sinal derivado.

Isso não significa viralização, causalidade ou garantia de resultado.

### 5. Minimização
A camada não recebe IP, e-mail, nome ou identificador do usuário. Ela recebe apenas o contexto necessário para interpretar a pesquisa e os resultados agregados das fontes.

## Arquivo principal

`supabase/functions/evolui-api/eie/inteligencia-dados.ts`

## Integração

`supabase/functions/evolui-api/index.ts`

O resultado passa a expor:

`inteligencia_dados`

sem remover os campos antigos.

## Próxima evolução possível

1. registrar métricas agregadas de pesquisas por tema/ramo;
2. criar janelas temporais de crescimento;
3. detectar mudanças de interesse sem identificar usuários;
4. criar conectores opcionais com consentimento explícito;
5. separar dados pessoais, dados operacionais e sinais de mercado no banco;
6. criar controles de retenção e desconexão por integração.

## Regra arquitetural

Nenhuma nova fonte deve entrar diretamente no ranking final.

Toda nova fonte deve passar por:

`conector → normalização → proveniência → sinal → fusão/ranking → EvoluiScore`

Assim a Evolui pode crescer em quantidade de dados sem transformar o motor em uma coleção desorganizada de APIs.
