# Pesquisa v2 — integração da busca avançada + experiência Pro

## Objetivo

Fazer o motor de pesquisa atual e a camada de descoberta web avançada trabalharem juntos sem substituir o EIE, a Claudia, o cálculo de tendência ou o banco.

## Implementado

- SearXNG continua como metabusca server-side.
- Firecrawl foi adicionado como segundo adaptador HTTP opcional, com leitura Markdown opcional.
- SearXNG e Firecrawl são iniciados em paralelo e seus URLs são fundidos/deduplicados.
- Resultados da busca avançada alimentam os assuntos relacionados por RRF, portanto a nova camada deixa de ser apenas observabilidade.
- A busca avançada continua separada da evidência de tendência: resultados web não contam sozinhos como fontes independentes de crescimento.
- Nenhuma migração SQL foi criada.
- Nenhuma tabela Supabase foi alterada.
- A Claudia/Anthropic não foi alterada.
- A tela de pesquisa garante pelo menos 5 segundos de carregamento.
- Usuários Free veem um slider promocional dentro do próprio card de pesquisa; usuários Pro/Master não veem a propaganda.
- O slider usa uma área de proporção fixa e troca de conteúdo por transição, sem alterar o tamanho entre slides.

## Variáveis de ambiente

```text
PESQUISA_AVANCADA_MODO=integrada
SEARXNG_URL=https://...
FIRECRAWL_API_KEY=fc-...
FIRECRAWL_BASE_URL=https://api.firecrawl.dev/v2
FIRECRAWL_SCRAPE_PESQUISA=true
FIRECRAWL_LIMIT=5
PESQUISA_AVANCADA_MAX_QUERIES=6
```

Chaves permanecem somente no Supabase Edge Function e nunca são enviadas ao navegador.

## Plano Free x Pro usado na propaganda

Os textos exibidos no slider correspondem às regras já presentes no motor: Free = 1 ideia, 2 notícias, 3 relacionados, 14 dias; Pro = 3 ideias, 6 notícias, 6 relacionados, 28 dias e análise local.
