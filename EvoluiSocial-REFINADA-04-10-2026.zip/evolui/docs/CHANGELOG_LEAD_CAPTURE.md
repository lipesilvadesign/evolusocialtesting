# Changelog — Lead Capture Engine (30/09/2026)

## Banco de produção (Supabase `aligftypgtzlymmditeo`) — APLICADO

Aplicado nesta ordem:

1. `lce_001_arquivamento_trava_delete`
   - Backup `backup_auditoria.prospeccao_leads_30_09` (50 linhas).
   - Colunas de arquivamento.
   - Trava: DELETE de lead pela service role é recusado.
   - **Testado em produção** (transação desfeita): a exclusão foi bloqueada e os 50 leads continuam lá.
2. `lce_002_taxonomia`: fonte, método e campanha separados; backfill dos 50 leads (manual / prospeccao_manual; setor Coworking + subsetor).
3. `lce_003_normalizacao`: colunas `*_norm` por trigger.
4. `lce_004_indices`: pg_trgm 1.6 + índices; opt-out com telefone normalizado.
5. `lce_005_capture_jobs`: buscas → capture job; RLS por dono; backup de políticas em `backup_auditoria.policies_30_09_lce`.
6. `lce_006_capture_raw`: tabelas captura e oportunidades; espelho dos `sinal_*`.
7. `lce_008_score_temperatura`: score e temperatura no banco; os 50 leads foram recalculados (score 40, "frio").
8. `lce_009a/b/c`:
   - dedup, aprovação, conversão, arquivar, restaurar, mesclar;
   - exclusão definitiva só de arquivado;
   - opt-outs só para admin e prospecção;
   - limite de e-mail global;
   - grants endurecidos.

Nenhum DROP de tabela ou coluna. Nenhum DELETE de dados. Migration 010 não criada.

## Código — PRONTO, AGUARDANDO DEPLOY (zip)

### Fase 0

- `scheduled-sync-background.js`: a limpeza arquiva em vez de apagar; prazo de 30 dias; follow-up ignora arquivados; recálculo diário.
- `prospeccaoService.js` reescrito:
  - `create` grava todos os campos válidos (lista branca);
  - score e campos protegidos são ignorados;
  - `update` vazio vira 404;
  - `listar` com filtros e paginação;
  - RPCs de arquivar, restaurar, mesclar e converter;
  - limite de e-mail por RPC global no fuso do Recife.
- `prospeccao.js` (Function): papel checado, novas ações, auditoria antes da exclusão, aviso de duplicado no cadastro manual.
- `prospeccao-enviar-email-background.js`:
  - atividade `email_enviado`;
  - falha de envio separada de falha de registro;
  - rodapé de descadastro + `List-Unsubscribe`.
- `rawSmtp.js` / `umblerSmtp.js`: `Message-ID`, `List-Unsubscribe`.
- `prospeccao-sync-osm.js`: cria job de captação (não insere mais no CRM); respeita opt-out pelo pipeline.
- `prospeccao-buscar-empresas-background.js`: virou rota de compatibilidade para o pipeline novo.
- `scoreEngine` (servidor e painel): `interessado` conta como resposta; rótulos das faixas alinhados.
- `clientes.js`: WhatsApp sem 55 duplicado.
- `financeiro.js`: `lead.fonte`.
- `prospeccao.js` (painel):
  - data da próxima ação no fuso local;
  - botão de abrir mantido após ação rápida;
  - trava de clique duplo;
  - lista paginada no servidor;
  - filtros de temperatura, faixa e arquivados;
  - arquivar/restaurar;
  - score do banco.
- `SQL_PENDENTE_clientes.sql`: trecho conflitante de `status_lead` desativado.
- `relatorioService.js`: funil sem arquivados.

### Fases 1–9

- **Novos módulos em `_lib/captacao/`:** taxonomia, normalizar, tipos, deduplicar, enriquecer, pipeline, deps, acesso e providers (geoapify, overpass, csv, inbound, consultoria, siteContato, manual).
- **Cliente REST:** `_lib/supabaseRest.js`.
- **Novas Functions:** `captacao.js`, `captacao-worker-background.js`, `prospeccao-taxonomia.js`.
- **Painel:**
  - nova tela `views/captacao.js` e `services/captacaoClient.js`;
  - rotas `#/prospeccao/captacao` e `/<jobId>`;
  - botão "Converter em lead" em Consultas e Contatos do site;
  - CSS da captação.
- **`_redirects`:** `/migrations/*` e `/docs/*` devolvem 404.

## Testes

- **JS:** 255/255 (`node tests/run-all.js`). Novos arquivos:
  - `captacaoNormalizar`;
  - `captacaoProviders`, incluindo a regressão Construção/Petrolina: estratégia antiga = 0, nova > 0, com resposta **mockada** no formato documentado;
  - `captacaoPipeline`;
  - `captacaoTaxonomia`, incluindo a paridade JS × SQL no Postgres local;
  - `prospeccaoFase0`.
- **Robô de RLS:** 69/69, sendo 34 novos (`robo/db/ataques_lce.sql`).
  - Encontrou e corrigiu um bug real: dentro de função SECURITY DEFINER, `current_user` vira o dono, e todo mundo parecia "serviço".
- **Sonda do painel:** Prospecção, Captação, Contatos e Consultas em 390 e 1280 px, como admin e como prospecção.
  - 0 erro de JS, 0 XSS, 0 rolagem lateral.
  - Modo "erro" sem XSS.
- **Robô geral:** 0 crítico. Os 3 altos restantes são anteriores a esta execução:
  - aviso LGPD nos formulários (2);
  - diagnóstico por hash (1).

---

# Refinamento (30/09/2026, 2ª etapa) — ver docs/RELATORIO_REFINAMENTO_30_09.md

- **Banco (APLICADO):** `lce_011_refinamento`.
  - Corrige a aprovação: a CHECK do audit_log, que só existe em produção, recusava as ações da captação.
  - Acrescenta telemetria, cache por provider, enriquecimento assíncrono, os sinais SITE_SEM_CONTATO e SITE_SEM_FORMULARIO e a RPC pública da apresentação filtrada.
- **Captação:** coleta paralela com prazo e cache; Overpass com orçamento, teto de `Retry-After` e detecção de `remark`; resultados antes do enriquecimento; resumo da busca; minimapa; mensagens e progresso da aprovação.
- **Enriquecimento:** título, descrição, formulário, WhatsApp, e-mail e telefone lidos da página inicial; merge só em campo vazio, feito no banco; CNPJ pela BrasilAPI atrás de flag (desligada).
- **Apresentação:** lista branca de campos públicos; estados de erro distintos; contraste da capa; PDF novo (pdf-lib hospedada, determinístico, paginação sem órfãos, cabeçalho e rodapé); `@media print`.
- **Flags:** ENABLE_NEW_CAPTURE_FLOW, ENABLE_MAP_SELECTION, ENABLE_NEW_PDF_ENGINE (ligadas); ENABLE_CNPJ_LOOKUP (desligada).
- **Testes:**
  - JS 283/283;
  - RLS 77/77 (com paridade de produção);
  - sondas: captação 60/60, apresentação 75/75.

---

# Fase 2 (01/10/2026) — ver docs/RELATORIO_FASE2_01_10.md

- **Banco:** `lce_012_aprovacao_parcial_enriquecidos` (APLICADA): aprovação parcial segura, um subbloco por registro; `qtd_enriquecidos`.
- **Overpass:** User-Agent identificado (o 406 em produção); espelho principal primeiro; 429 pula de espelho sem esperar.
- **Minimapa:** área personalizada (polígono), validada e filtrada no servidor; estado único `captureState.area`.
- **Apresentação:** modelo editorial único para web e PDF; componentes; natureza de cada seção (dado, interpretação, recomendação); contraste dos rótulos; metadados de prévia (noindex mantido).
- **PDF:** renderiza o mesmo modelo; funções `renderPdf*`; Times-Bold nos títulos e Helvetica no texto; espera imagens e fontes antes de gerar.
- **Testes:**
  - JS 299/299;
  - RLS 78/78;
  - sondas: captação 81/81, apresentação 85/85 (web = PDF).

---

# Fase 3 (01/10/2026) — ver docs/RELATORIO_FASE3_01_10.md

- **Banco:** `lce_013_fase3_operacao` (APLICADA). Inclui saúde dos providers + circuito, 4 sinais medidos, contatabilidade, histórico de score, tarefas/próxima ação e cache de site.
- **Captação progressiva:**
  - TTFR e TTLC;
  - status por fonte;
  - timeout só no provider que estourou;
  - dedup entre lotes;
  - painel técnico (admin);
  - mensagens sem jargão.
- **Minimapa:** área pesquisada e aproximada, aviso de área extensa, "dentro / fora da área".
- **Enriquecimento:**
  - crawl controlado (contato/sobre, robots.txt, limites);
  - sinais de meta description, favicon, WhatsApp e Instagram;
  - cache de site de 7 dias.
- **CRM:**
  - composição do score;
  - histórico;
  - potencial × engajamento;
  - contatabilidade;
  - próxima ação (tarefas).
- **Apresentação/PDF:** hero com segmento e local; Observação → Interpretação → Implicação; plano Ação | Objetivo | Indicador; ★ vetorial; monograma; paginação testada.
- **LGPD:** `/privacidade` + aviso nos formulários.
- **Testes:**
  - JS 318;
  - RLS 86;
  - sondas: captação 99, apresentação 93.
