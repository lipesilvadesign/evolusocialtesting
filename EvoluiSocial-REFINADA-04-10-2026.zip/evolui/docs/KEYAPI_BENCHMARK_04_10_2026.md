# KeyAPI Benchmark — Evolui Social

## Objetivo

Medir se dados sociais da KeyAPI adicionam evidência útil ao motor da Evolui sem substituir as fontes atuais.

## Hipótese

```text
web + trends + repertório
           ↓
      sinais atuais

web + trends + repertório + social
           ↓
      sinais mais ricos
           ↓
     melhor contextualização
```

A KeyAPI é tratada como provider de aquisição. O ranking continua no EIE.

## Plano de teste

56 créditos teóricos, com 26 chamadas:

- TikTok: hashtags de tendência e captions;
- Instagram: busca de Reels, comentários e resolução de shortcode;
- YouTube: busca e informações de vídeo;
- Pinterest: busca de usuários e informações de perfil.

O script nunca executa chamadas no modo padrão.

## Segurança de crédito

- `DRY-RUN` por padrão;
- `--live` obrigatório;
- teto absoluto de 98;
- cada custo é reservado antes da chamada;
- estado salvo em `scripts/.keyapi-benchmark-state.json`;
- a chave nunca é impressa.

## Como medir o resultado

Após a execução, comparar:

```text
cobertura
qualidade do dado
recência
latência
densidade de texto
riqueza de metadados
sinais de comentários
capacidade de detectar gaps
```

O objetivo não é maximizar número de resultados. É descobrir quais fontes melhoram a decisão contextual.
