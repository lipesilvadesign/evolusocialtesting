# Evolui Social — configuração final para uma rodada de deploy

## Objetivo

Este pacote consolida EKE, inteligência comportamental agregada, EVI Video Intelligence e o provider/benchmark KeyAPI para que a implantação seja feita em uma única rodada, evitando ciclos de correção/deploy.

## O que entra no deploy

### Supabase Edge Function

Publicar novamente **somente**:

```text
supabase/functions/evolui-api
```

A versão publicada passa a reconhecer, entre outras ações existentes:

```text
buscar
buscar_referencias_pinterest
analisar_video_pro
analisar_link
```

A persistência de análises EVI usa a chave de serviço do próprio backend e respeita a RLS da tabela.

### Banco

Executar uma única vez:

```text
SQL_EVOLUI_INTELIGENCIA_CONSOLIDADO_04_10_2026.sql
```

Ele é aditivo e não contém segredos.

### Frontend

Publicar a raiz do projeto no Netlify normalmente. O site continua estático; não é necessário um build especial.

### EVI Video Worker

O worker é separado porque `faster-whisper` + FFmpeg não devem rodar dentro da Edge Function.

Construção:

```bash
cd evi-video-worker
docker build -t evolui-evi-video:v1 .
```

A imagem já leva:

- faster-whisper 1.2.1;
- yt-dlp 2026.08.19;
- yt-dlp-ejs 0.8.0;
- Deno 2.9.6;
- FFmpeg;
- PySceneDetect 0.7.1;
- OpenCV.

O EJS do yt-dlp atualmente exige um runtime JavaScript compatível; Deno 2.9.6 atende ao mínimo publicado e é o runtime recomendado. Veja a auditoria em `EVI_VIDEO_OPEN_SOURCE_AUDIT_04_10_2026.md`.

## Secrets

No Supabase Edge Function:

```text
EVI_VIDEO_WORKER_URL=https://SEU-WORKER/analyze
EVI_VIDEO_WORKER_TOKEN=<segredo interno>
```

Opcional/legado:

```text
EVOLUI_VIDEO_ANALYZER_URL
EVOLUI_VIDEO_ANALYZER_TOKEN
```

KeyAPI, quando for utilizar o benchmark ou ativar o provider:

```text
KEYAPI_API_KEY=<sua chave>
```

Nunca coloque uma chave dentro de código, ZIP, frontend ou commit.

## KeyAPI — segurança de créditos

A implementação continua desligada do fluxo automático de pesquisa por padrão.

O benchmark local:

- começa em DRY-RUN;
- exige `--live` para consumir créditos;
- possui teto absoluto de 98 créditos;
- plano inicial de 56 créditos;
- reserva 8 créditos de segurança;
- persiste o estado localmente.

Depois de uma execução bem-sucedida, restam 42 créditos dentro do teto absoluto.

Execução:

```bash
KEYAPI_API_KEY="..." node scripts/keyapi-benchmark.mjs --live
```

No PowerShell:

```powershell
$env:KEYAPI_API_KEY = "..."
node scripts/keyapi-benchmark.mjs --live
```

## Ordem única de implantação

1. Executar `SQL_EVOLUI_INTELIGENCIA_CONSOLIDADO_04_10_2026.sql`.
2. Configurar `EVI_VIDEO_WORKER_URL` e `EVI_VIDEO_WORKER_TOKEN` no Supabase.
3. Publicar `supabase/functions/evolui-api`.
4. Publicar o frontend no Netlify.
5. Publicar o container `evi-video-worker` uma vez e usar sua URL no secret.

Depois disso, o funcionamento normal não exige novo deploy para o benchmark KeyAPI: basta executar o script com a chave localmente. Para ativar KeyAPI no fluxo automático no futuro, a intenção é fazer isso por configuração, sem alterar o núcleo do EIE.

## Smoke test pós-deploy

### A) API

Usuário logado → chamada `buscar`.

### B) Pinterest

Ação `buscar_referencias_pinterest`.

### C) Vídeo

Ação `analisar_video_pro` com YouTube/TikTok/Instagram público.

O erro antigo `Ação desconhecida` deve desaparecer quando a Edge Function publicada for a versão deste pacote.

### D) KeyAPI

Rodar primeiro:

```bash
node scripts/keyapi-benchmark.mjs
```

Depois, caso queira consumir a cota de teste:

```bash
node scripts/keyapi-benchmark.mjs --live
```

## Limitações que continuam explícitas

IMPLEMENTADO:
- EVI v1 determinístico;
- transcrição local;
- timestamps;
- cenas/sinais visuais básicos;
- DNA/fingerprint;
- lacunas/oportunidades;
- persistência;
- EKE;
- Pinterest oficial;
- KeyAPI provider + benchmark controlado.

PREPARADO:
- OCR;
- diarização/WhisperX;
- corpus comparativo;
- Opportunity Gap em escala;
- aprendizado por métricas reais.

AINDA NÃO IMPLEMENTADO:
- treinamento de um modelo próprio de áudio/visão;
- previsão de viralização;
- aprendizagem automática dos pesos por métricas de rede;
- fila distribuída de vídeos longos.
