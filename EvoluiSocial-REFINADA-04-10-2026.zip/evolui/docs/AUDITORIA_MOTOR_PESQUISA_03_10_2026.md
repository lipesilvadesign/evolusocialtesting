# Evolui Social — Auditoria e intervenção conservadora no motor de pesquisa

Data: 03/10/2026
Versão de trabalho: pesquisa-avancada-v1 (shadow)

## Regra de segurança

Esta etapa foi desenhada para **não substituir** o motor existente. Nenhum SQL do Supabase foi alterado e nenhuma tabela, RPC, RLS, índice ou função de banco foi criada/removida/modificada nesta etapa.

A integração com Claude/Anthropic (`netlify/functions/_lib/integrations/aiProvider.js`) também não foi modificada.

## O que já existia

O motor existente já possui uma cadeia relevante de entendimento, fontes, repertório, EIE, RRF/MMR, EvoluiScore, histórico, novidade, recência, contexto do negócio, oportunidades e fallbacks.

A principal lacuna identificada não é ausência de ranking: é **cobertura e profundidade da descoberta antes do ranking**.

## Falhas concretas encontradas na interpretação

### 1. Categoria de negócio confundida com intenção de mercado

Caso de teste anterior:

`quero ideias de reels para barbearia em Caruaru`

A interpretação podia transformar `barbearia` em sinal de `mercado`, mesmo quando a pessoa só queria ideias de conteúdo.

Correção: intenção de mercado local agora exige marcador explícito (quais/onde/lista/encontre/existem etc.) ou marcador de mercado; a categoria do negócio permanece como assunto.

### 2. Cidade composta era fragmentada

Caso:

`lojas de maquiagem em juazeiro do norte`

O parser podia identificar apenas `Juazeiro` e deixar `norte` no assunto.

Correção: quando o primeiro componente é uma cidade conhecida, conectores como `do/da/de/dos/das` podem compor a localização mesmo com capitalização inconsistente.

### 3. Ano estava vazando para o assunto/termos de busca

Caso:

`tendências de skincare em 2026`

Correção: o ano explícito passou a ser armazenado separadamente (`Consulta.ano`) e não é utilizado como termo lexical do assunto/biblioteca.

## Nova camada adicionada — modo shadow

Criada a pasta:

`supabase/functions/evolui-api/eie/pesquisa/`

Arquivos:

- `tipos.ts` — contratos de pesquisa avançada.
- `plano.ts` — planejamento determinístico de consultas.
- `searxng.ts` — adaptador nativo para SearXNG via HTTP.
- `fusao.ts` — normalização, deduplicação e evidência.
- `orquestrador.ts` — execução em modo shadow.
- `README.md` — ativação e limites da etapa.

Também foi criado:

`tests/pesquisaAvancada.test.js`

## Como o modo shadow funciona

Por padrão:

`PESQUISA_AVANCADA_MODO=off`

Quando desligado, o motor novo não consulta nada.

Quando configurado como:

`PESQUISA_AVANCADA_MODO=shadow`

com `SEARXNG_URL` válido, ele:

1. recebe a interpretação existente;
2. cria consultas complementares;
3. consulta SearXNG;
4. normaliza resultados;
5. deduplica URLs;
6. mede cobertura de consultas/engines, recência, autoridade e diversidade;
7. retorna os resultados em `pesquisa_avancada`.

**Ele não altera o ranking EIE na v1.**

## Estratégia de consultas

O planner gera consultas com razões explícitas, como:

- assunto direto;
- assunto × ramo;
- assunto × localização;
- sinais de momento/tendência;
- comportamento/demanda;
- dores e lacunas;
- concorrência/benchmark;
- aplicabilidade em conteúdo;
- formatos e ganchos;
- expansão taxonômica;
- validação editorial.

Foi incluída uma proteção contra consultas circulares de baixo valor: expansões que apenas repetem o próprio assunto não são tratadas como descoberta nova.

## O que NÃO foi feito

Ainda não foi feito:

- substituição das fontes Wikipédia/GDELT/Trends/YouTube;
- alteração dos pesos do EvoluiScore;
- entrada dos resultados SearXNG no ranking EIE;
- Firecrawl em runtime;
- qsearch embutido na Edge Function;
- alteração do schema do Supabase;
- alteração da integração Claude/Anthropic.

A razão é metodológica: primeiro medir ganho real de cobertura, novidade e qualidade; depois decidir o que merece entrar no ranking.

## Critério de evolução da próxima etapa

A camada só deve sair de shadow quando conseguirmos medir, por ramo e tipo de consulta:

- resultados novos que o motor atual não encontra;
- porcentagem de URLs realmente relevantes;
- diversidade de domínios/fontes;
- recência dos sinais;
- taxa de duplicação;
- latência adicional;
- taxa de falha por fonte;
- melhora na explicação/oportunidade final;
- melhora em casos que hoje retornam pouco ou nenhum sinal.

## Testes

Suíte específica da pesquisa avançada: **8/8 aprovados**.

Suíte geral do projeto após a intervenção: **322 aprovados, 1 falha, 1 ignorado, de 324 testes**.

A falha existente permanece localizada em `tests/rawSmtp.test.js`, no cenário de conexão SMTP recusada, e não envolve o motor de pesquisa nem foi alterada nesta etapa.

## Próximo passo recomendado

Medir o modo shadow com consultas reais de diversos ramos antes de permitir que os sinais novos alterem o ranking.

A decisão de incorporar novos provedores/crawlers deve ser baseada em ganho mensurável, não em quantidade de componentes adicionados.
