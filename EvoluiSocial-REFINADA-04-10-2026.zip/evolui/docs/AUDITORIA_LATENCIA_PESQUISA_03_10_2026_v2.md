# Auditoria e otimização de latência — Pesquisa Evolui v2 — 03/10/2026

## Objetivo
Reduzir a latência percebida e real da pesquisa, preservando as fontes, EIE, EvoluiScore, RRF/MMR, biblioteca e IA. Meta operacional: ~15s em condições normais, sem espera artificial.

## Alterações
- SearXNG: timeout padrão 5,5s → 3,5s.
- Firecrawl: timeout padrão 3,5s → 2,5s.
- Firecrawl: fan-out máximo 3 → 2 consultas no caminho crítico.
- Pesquisa avançada: deadline de 4s; se excedido, não bloqueia o restante do motor.
- Máximo de consultas avançadas padrão: 6 → 5.
- Removida espera artificial de 5s no frontend.
- Removida espera artificial de 5,2s antes da segunda consulta GDELT.
- Loading trocado de nomes técnicos de provedores por dicas didáticas da Evolui.
- Pro/Master recebem slider de Evolui Business durante a pesquisa.
- Telemetria existente de fontes/pesquisa avançada/EIE preservada.

## Preservado
Google Trends, GDELT, Wikipédia, YouTube, Biblioteca, Repertório, SearXNG, Firecrawl, RRF, MMR, EIE, EvoluiScore e provedor de geração.

## Regra de qualidade
Nenhuma fonte foi removida como mecanismo de evidência. A otimização reduz o tempo máximo de bloqueio de fontes opcionais e torna a descoberta web uma camada complementar.
