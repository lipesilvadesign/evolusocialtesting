# Auditoria — Refinamento do Lead Capture Engine + Apresentação por Cliente (30/09/2026)

Tudo abaixo foi lido no código ou consultado no banco de produção (`aligftypgtzlymmditeo`) antes de qualquer alteração.
Nada foi inferido sem evidência. Quando não deu para confirmar, está escrito **NÃO FOI POSSÍVEL CONFIRMAR**.

## 1. Mapa de dependências (resumo)

```
painel/views/captacao.js ──► services/captacaoClient.js ──► /.netlify/functions/captacao (validação, papel)
                                                             ├─► RPC aprovar_captura ─► prospeccao_aprovar_um ─► admin_audit_log (INSERT)
                                                             └─► captacao-worker-background ─► _lib/captacao/pipeline.js
pipeline.executarPesquisa ─► deps.geocodificar (Nominatim → Photon)
                           ─► deps.coletar.geoapify / .overpass (integrations/openStreetMap.postOverpassQuery, 6 espelhos)
                           ─► processarRegistros ─► dedup ─► opt-out ─► RPC prospeccao_dedup_candidatos
                                                 ─► enriquecer.verificarSite (até 50 sites, 5 em paralelo)  ◄─ ANTES de gravar
                                                 ─► gravarCaptura (admin_prospeccao_captura)
apresentacao.html ─► assets/js/apresentacao.js ─► /.netlify/functions/apresentacao-publica ─► RPC apresentacao_publica (anon)
                                               └─► jsPDF 2.5.1 (cdnjs, carregado ao clicar)
painel/views/clientes.js (aba Apresentação) ─► /.netlify/functions/apresentacoes ─► apresentacoesService (admin_apresentacoes)
```

## 2. Itens da auditoria

### A1 — Aprovação falha sempre em produção (CRÍTICO)
- **ARQUIVO:** banco de produção (`admin_audit_log`); `migrations/009a_dedup_aprovacao.sql`, `009b_inbound_arquivo_mescla.sql`.
- **FUNÇÃO:** `aprovar_captura` → `prospeccao_aprovar_um` → `INSERT INTO admin_audit_log (action = 'aprovar_captura', …)`.
- **DEPENDÊNCIAS:** Function `captacao.js?acao=aprovar`, tela `views/captacao.js`.
- **PROBLEMA:** toda aprovação volta erro e nenhum lead é criado.
- **CAUSA (confirmada):** a constraint `admin_audit_log_action_check` existe só em produção e aceita apenas `create, update, delete, publish, unpublish, settings_change, permission_change, status_change`.
  - O INSERT de auditoria falha com 23514, e a transação inteira da RPC é desfeita.
  - Reproduzido em produção com transação desfeita (ROLLBACK), como admin.
  - A réplica local não tinha essa constraint, por isso os testes passavam.
  - Mesmo defeito em `converter_inbound`, `arquivar`, `restaurar`, `mesclar` e `mesclar_captura`.
  - As chamadas JS de `auditLog.record` (`captacao_iniciar`, `importar_csv`, `enviar_email_prospeccao`, `optout_prospeccao`…) falham **em silêncio**, e a trilha de auditoria fica sem esses eventos.
- **RISCO:** alto. O fluxo principal do CRM está parado.
- **SOLUÇÃO:** migration 011 recria a CHECK com os valores antigos mais os novos. Isso é aditivo: nenhum valor existente passa a ser recusado. Além disso:
  - replicar na réplica do robô as constraints que só existem em produção (arquivo de paridade), para o teste pegar isso da próxima vez;
  - traduzir o erro 23514 numa mensagem legível.

### A2 — Idempotência / atomicidade da aprovação
- **ARQUIVO:** `009a_dedup_aprovacao.sql`, `captacao.js`, `views/captacao.js`.
- **SITUAÇÃO:** `prospeccao_aprovar_um` trava a linha (`FOR UPDATE`) e confere `lead_id is null` / `status`. Um segundo clique devolve `ja_aprovado`, e a RPC roda numa única transação.
  - A tela desabilita o botão.
  - A mensagem de erro repassa o texto técnico do banco.
  - A tela não mostra "Aprovando N empresas…".
- **RISCO:** baixo depois de A1. A mensagem ao usuário ainda não atende ao pedido.
- **SOLUÇÃO:** progresso no modal, resumo "X aprovados / Y duplicados / Z bloqueados" e mensagem "A aprovação não foi concluída. Motivo: …". Adicionar um teste de duplo clique ao robô de RLS.

### A3 — Busca lenta (≈2 min 16 s para uma cidade)
- **ARQUIVO:** `_lib/captacao/pipeline.js`, `_lib/integrations/openStreetMap.js`, `providers/overpass.js`, `deps.js`.
- **EVIDÊNCIA REAL:** job `91c3931d…` (Construção, Petrolina, 15 km).
  - O worker reivindicou o job às 20:53:27 e só gravou a coleta às 20:55:43.
  - Geoapify trouxe 16 resultados; Overpass trouxe 0, sem erro registrado.
  - O resto (dedup, 2 sites, gravação) levou cerca de 3 s.
- **CAUSAS (lidas no código):**
  1. Providers e setores rodam em **série** (`for prov … for setor …`).
  2. Pior caso do `postOverpassQuery`: 6 espelhos × timeout de 8 s, mais a espera de `Retry-After` **sem teto** e uma 2ª tentativa no mesmo espelho. Isso passa de 1 minuto facilmente.
  3. A consulta `nwr["name"~…]["building"!~"."]` (regex só por nome, raio de 15 km, sem filtro de tag) é a mais cara para o Overpass. `[timeout:25]` no servidor.
  4. O Overpass pode devolver 200 com `elements: []` e um `remark` de timeout ou memória. Hoje isso conta como "0 resultados, sucesso", o que explica "0 sem erro".
  5. A geocodificação (Nominatim, depois Photon, 8 s cada) acontece até para as 10 cidades fixas da região.
  6. A checagem de sites (até 50 sites × até 4 tentativas × 5 s) roda **antes** de gravar. O usuário não vê nada até o fim.
  7. Não há cache: repetir a mesma busca refaz tudo.
  8. Não há telemetria por provider (`duration_ms`). Só existe o `progresso` por cidade.
- **RISCO:** médio (lentidão, espera no painel, custo).
- **SOLUÇÃO (menor mudança):**
  - providers e setores em paralelo com `Promise.allSettled`;
  - orçamento total de tempo para o Overpass (padrão 20 s), teto de 5 s no `Retry-After` e detecção de `remark` (vira erro explícito);
  - coordenadas fixas para as cidades da região;
  - cache de resultado por provider (24 h) no banco;
  - gravar os resultados primeiro (`em_revisao`) e enriquecer depois, em segundo plano;
  - telemetria em `buscas.metricas`.
  - Tudo atrás de `ENABLE_NEW_CAPTURE_FLOW`: desligar volta ao fluxo sequencial.

### A4 — Área da busca só por cidade + raio fixo (5/15/30)
- **ARQUIVO:** `views/captacao.js`, `captacao.js` (iniciar), `pipeline.js`.
- **PROBLEMA:** não dá para escolher um bairro, um ponto ou um raio livre.
- **SOLUÇÃO:** minimapa com Leaflet + OpenStreetMap, carregado sob demanda.
  - Resultado gravado em `parametros.area = {latitude, longitude, raio_metros}`.
  - O servidor valida lat/lon dentro do Brasil e raio entre 500 m e 30 km.
  - Nenhuma biblioteca de mapa existe no projeto (grep: nenhuma ocorrência de leaflet ou L.map).
  - A CSP está em modo **Report-Only** e o painel não tem CSP própria. Leaflet (~42 KB gzip) só é baixado quando o usuário abre o mapa.
  - Atrás de `ENABLE_MAP_SELECTION`.
  - Polígono personalizado: **não implementado** nesta fase, porque exigiria outra dependência (leaflet-draw) e filtragem por polígono em cada provider. Fica em próximas melhorias.

### A5 — Enriquecimento
- **ARQUIVO:** `enriquecer.js`, `pipeline.js`.
- **SITUAÇÃO:** checa status, HTTPS, redirect e o link de Instagram na página. Gera SITE_FORA_DO_AR, SITE_SEM_HTTPS e SEM_SITE. Não lê título, meta description, formulário, WhatsApp, e-mail ou telefone na página. Não há CNPJ.
- **SOLUÇÃO:**
  - Extrair do HTML já baixado (200 KB, sem requisição extra): `<title>`, `meta description`, `<form>`, links `wa.me` / `api.whatsapp.com`, `mailto:`, `tel:`.
  - Novos sinais só com evidência medida: SITE_SEM_CONTATO e SITE_SEM_FORMULARIO.
  - SITE_DESATUALIZADO **não** será gerado automaticamente. Não há critério objetivo confiável: o ano no rodapé não prova nada. Continua como sinal manual, que já existe na taxonomia.
  - CNPJ via BrasilAPI atrás de flag (`ENABLE_CNPJ_LOOKUP`, desligada), gravando fonte e data, sem sobrescrever campo preenchido.
  - Instagram: só o link publicado no próprio site da empresa ou o dado da fonte. Sem scraping do Instagram.

### A6 — Apresentação pública vaza métricas não selecionadas e dados internos (ALTO)
- **ARQUIVO:** `painel/assets/js/views/clientes.js` (≈ linha 1011), `apresentacoesService.obterPublicaPorSlug`, RPC `apresentacao_publica`.
- **PROBLEMA:** o snapshot guarda `metricasDisponiveis`, que são **todas** as linhas de `admin_metricas` do lead, com `lead_id`, `id` e autor.
  - A RPC pública devolve o `conteudo` inteiro.
  - Qualquer pessoa com o link (ou a anon key chamando `rpc/apresentacao_publica` diretamente) recebe métricas que o consultor **desmarcou** e identificadores internos.
- **EVIDÊNCIA:** leitura do código. Produção tem 0 apresentações hoje, então não houve vazamento efetivo confirmado.
- **SOLUÇÃO:** sanitizar no próprio banco. A RPC devolve só as métricas selecionadas, com campos públicos (nome, valor, unidade, período, origem). A Function faz a mesma lista branca (defesa em profundidade). Nenhum dado é apagado.

### A7 — PDF da apresentação (ALTO)
- **ARQUIVO:** `assets/js/apresentacao.js` (`gerarPdf`), `assets/css/apresentacao.css`.
- **MECANISMO ATUAL:** jsPDF 2.5.1 baixado do cdnjs **no clique**. Texto redesenhado à mão, com Helvetica e cores fixas.
- **CAUSAS DOS DEFEITOS:**
  1. **Dependência externa na hora do clique:** se o CDN falhar, ou quando a CSP (`script-src 'self'`, hoje Report-Only) for ativada, o PDF quebra.
  2. **Título órfão:** `titulo()` reserva 40 pt, mas título + rótulo + 1ª linha ocupam cerca de 80 pt, então o título fica sozinho no pé da página.
  3. **Sem cabeçalho, rodapé nem número de página.**
  4. **Tema do cliente ignorado** (NAVY fixo) e data crua (`2026-09-30`), diferente da página.
  5. Cores da direção visual e métricas **sem gráfico**.
  6. Nome do arquivo perde letras acentuadas (`café` → `caf`).
  7. Erro por `alert()` e o único feedback é "Gerando…".
- **IMPRESSÃO PELO NAVEGADOR (Ctrl+P):** não existe `@media print`. Consequências:
  - `.ap-reveal` fora da tela fica com `opacity:0`, e as **seções saem em branco**;
  - contadores imprimem 0 e barras largura 0;
  - o botão fixo sai impresso;
  - a capa com `100svh` gera páginas quase vazias.
- **SOLUÇÃO:**
  - Motor novo atrás de `ENABLE_NEW_PDF_ENGINE`, ainda com jsPDF (já é o mecanismo do projeto; trocar de stack não se justifica), mas **hospedado no próprio site** (`/assets/vendor/jspdf.umd.min.js`, mesmo arquivo 2.5.1 do cdnjs).
  - Paginação com "manter com o próximo", cabeçalho e rodapé com página X/Y, cores do tema, barras das métricas, amostras de cor, data formatada e nome de arquivo sem perder letras.
  - Etapas de progresso e erro amigável na página.
  - `@media print` completo para quem usa Ctrl+P.

### A8 — Página pública: estados, acessibilidade, responsividade
- **ARQUIVO:** `apresentacao.html`, `apresentacao.js`, `apresentacao.css`.
- **PROBLEMAS:**
  - O erro mostra a mesma mensagem para "não existe" e "falha de rede", sem botão "tentar de novo".
  - O loading não tem texto nem `aria-live`.
  - `formatarData` quebra com timestamp completo (`T00:00:00` concatenado a um ISO que já tem hora dá "Invalid Date").
  - Seção de interpretação com setas "→" sem alternativa textual.
  - Cores do tema sem checagem de contraste: texto branco sobre um `primaryColor` claro fica ilegível.
  - O botão PDF no celular só tem ícone. Precisa de `aria-label`: **NÃO FOI POSSÍVEL CONFIRMAR** no HTML, a conferir.
- **SOLUÇÃO:**
  - distinguir 404 de falha, com botão "Tentar de novo";
  - `role=status` no loading;
  - data robusta;
  - contraste automático do texto da capa (claro/escuro conforme a luminância);
  - `aria-label` no botão;
  - testes em 360, 390, 430, 768, 1024, 1280, 1440 e 1920 px.

### A9 — Cache da página pública
- `apresentacao-publica` envia `Cache-Control: public, max-age=30` também no **404**. Um slug publicado logo depois de alguém visitar o link continua "não encontrado" por até 30 s. Isso é aceitável, mas o 404 passa a ir com `no-store`.

### A10 — Réplica local divergente de produção
- Constraints que só existem em produção: `admin_audit_log_action_check`, `admin_pages_status_check`, `admin_posts_status_check`, `admin_relatorios_tipo_check`.
- **SOLUÇÃO:** `robo/db/paridade_producao.sql` aplicado pelo robô antes dos ataques.

## 3. Plano (ordem de execução)

1. **Migration 011** (aditiva e idempotente):
   - CHECK de auditoria;
   - `buscas.metricas`;
   - tabela `admin_prospeccao_cache_provider`;
   - `captura.enriquecimento` e `captura.enriquecimento_status`;
   - `leads.enriquecimento`;
   - novos tipos de oportunidade no score;
   - RPC pública sanitizada.
2. **Backend:**
   - pipeline paralelo;
   - orçamento do Overpass;
   - coordenadas fixas;
   - cache;
   - enriquecimento assíncrono;
   - telemetria;
   - área do mapa;
   - mensagens de erro.
3. **Frontend:** resumo da busca, progresso da aprovação, minimapa.
4. **Apresentação:** estados, segurança e PDF.
5. **Testes:** JS, robô de RLS com paridade, sonda do painel e da apresentação nas 8 larguras, PDF gerado e conferido.
