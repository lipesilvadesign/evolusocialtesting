# Relatório — Mega Brain Fase 2 (estabilização da captura, minimapa, aprovação, apresentação, PDF) · 01/10/2026

## 0. Auditoria do código real (o que a Fase 2 pedia × o que já existia)

A Fase 2 descreve problemas do código **antes** de 30/09. Conferi tudo no código atual e no banco de produção. O deploy publicado em 01/10 às 01:51 UTC já contém o refinamento de 30/09.

| Item da Fase 2 | Situação real encontrada | Ação nesta fase |
|---|---|---|
| 1. Bug do responsável (`bulkInsertManual` sem 4º argumento) | **Já corrigido.** `prospeccao-buscar-empresas-background.js` virou rota de compatibilidade: cria um job e usa o pipeline. Não existe mais nenhuma chamada a `bulkInsertManual` (grep). O responsável é decidido **no banco** (`prospeccao_aprovar_um`): prospecção só atribui a si mesma, e o admin escolhe entre funcionários ativos admin/prospecção. | Nenhuma |
| 2. Busca inserindo direto no CRM | **Já corrigido.** Provider → job → captura → normalização → dedup → revisão → `aprovar_captura` → CRM. O job semanal (`prospeccao-sync-osm`) também cria job. | Nenhuma |
| 3. Migração sem quebrar | `prospeccao-buscar-empresas-background`, `prospeccao-busca-status` e `admin_prospeccao_buscas` foram mantidos e reaproveitados (adaptador). | Nenhuma |
| 4. Capture job | `admin_prospeccao_buscas` estendida (005/011). Faltava `qtd_enriquecidos`. | **Migration 012** |
| 5. Staging | `admin_prospeccao_captura` com `UNIQUE(job_id, provider, external_id)` e `payload` original (006). | Nenhuma |
| 6. Normalização | `_lib/captacao/` (normalizar, taxonomia, tipos, pipeline, providers) + `*_norm` por trigger no banco (003). | Nenhuma |
| 7. Dedup em camadas | Já implementado (CNPJ/origem/domínio+nome automático; telefone/Instagram/nome+cidade para revisão). Nunca sobrescreve: merge só em campo vazio, regra no banco. | Nenhuma |
| 8–9. Minimapa | Existia círculo (centro + raio). **Faltava área personalizada** e a nomenclatura `captureState.area`. | **Polígono + estado único** |
| 10–12. Busca rápida e telemetria | Já paralela, com prazo, cache e telemetria (011). **Medição real em produção mostrou o gargalo seguinte: Overpass.** | **Correção do Overpass** |
| 13–15. Aprovação atômica, idempotente, parcial | Atômica e idempotente. **Parcial ainda não:** um erro inesperado num registro desfazia o lote inteiro. | **Migration 012** |
| 16–17. Enriquecimento | Assíncrono; sinais medidos (011). | Nenhuma |
| 18. Score | No PostgreSQL (trigger), reproduzível, com motivos e temperatura. Conferido em produção nos 2 leads aprovados (score 45, frio, motivos gravados). | Nenhuma |
| 19. Exclusão automática | **Já corrigido.** `scheduled-sync-background` arquiva (30 dias, `inatividade_automatica`); o banco recusa DELETE vindo de rotina (001). | Nenhuma |
| 20–28. Apresentação | Funcional, mas com seções montadas como HTML gigante, sem separar dado e análise, rótulos dourados com contraste insuficiente e sem metadados de prévia. | **Modelo editorial + componentes** |
| 29–37. PDF | Motor pdf-lib (30/09), mas com montagem **paralela** à da web. | **PDF sobre o mesmo modelo** |

## 1. Evidência real de produção (depois do deploy de 01/10, 01:51 UTC)

Job `ceb4fe77` (Imobiliário, Petrolina) — números lidos de `admin_prospeccao_buscas.metricas`:

| Medida | Valor medido |
|---|---|
| Resultado na tela (`total_ms`) | **21,8 s** (o job `91c3931d`, de 30/09 com o código antigo, levou **2 min 16 s**) |
| Geocodificação | 0,59 s |
| Geoapify | **1,43 s**, 2 resultados, 0 erro |
| Overpass | **20 s gastos, 0 resultado**: kumi → 429, overpass-api.de → **406**, openstreetmap.ru → timeout, private.coffee → 429 |
| Dedup / gravação | 368 ms / 206 ms |
| Aprovação | **2 aprovados → 2 leads no CRM** com responsável, score 45, temperatura "frio", 1 atividade cada. Auditoria `aprovar_captura` registrada. A correção da constraint funciona em produção. |

**Conclusão:** quase todo o tempo restante (20 s de 21,8 s) era o Overpass falhando.
- **406** é a recusa do overpass-api.de para requisição sem User-Agent identificado.
- **429** é o limite de uso de cada espelho.
- Esperar o `Retry-After` dentro do orçamento consumia o tempo dos outros espelhos.

## 2. O que mudou nesta fase

### Captura
- **Overpass** (`_lib/integrations/openStreetMap.js`):
  - User-Agent do app em todas as chamadas;
  - overpass-api.de (instância principal) em primeiro;
  - 429 com espelhos sobrando pula na hora para o próximo; só o último espelho espera o `Retry-After` (até 5 s).
  - O ganho de tempo **NÃO FOI MEDIDO**: depende do próximo deploy. Ver em `metricas.providers.overpass`.
- **Área personalizada no minimapa** (`components/MiniMapa.js`, `views/captacao.js`):
  - "Área personalizada (clique os cantos no mapa)", de 3 a 12 cantos, com "Desfazer ponto" e "Limpar";
  - o raio é calculado para cobrir a área;
  - envia `area.geometry` (GeoJSON Polygon).
- **Servidor** (`pipeline.areaValida` / `poligonoValido`):
  - valida a área: anel fechado, de 3 a 20 cantos, no Brasil, coberto pelo raio;
  - **geometria inválida é recusada, não ignorada**;
  - o pipeline descarta o que caiu **fora** do polígono e conta em `metricas.fora_da_area`; registro sem coordenada fica fora, porque não dá para afirmar que está dentro.
- **Estado único** `captureState.area = { latitude, longitude, raioMetros, geometry, rotulo }`: o mapa só lê e escreve por callback, sem cópia própria.
  - Ciclo testado: abrir captura, abrir o mapa, fechar, reabrir (mesmo mapa), trocar cidade, trocar raio, desenhar área, desfazer ponto, iniciar busca, mapa destruído ao sair.
- **Aprovação parcial** (migration 012):
  - cada registro roda num subbloco do banco; um erro inesperado desfaz **só aquele registro** (lead + atividade + auditoria + status juntos) e devolve `{resultado:'erro', mensagem}`;
  - erros de regra do pedido (permissão, responsável) continuam abortando tudo, porque valem para todos;
  - a tela mostra "10 aprovado(s) · 1 com erro" e a lista do que falhou, sem esconder o que deu certo.
- **`qtd_enriquecidos`** no job (migration 012).
- **Flags:** aceitam também `ENABLE_CAPTURE_ENGINE_V2` e `ENABLE_PDF_V2` (sinônimos; o nome novo tem precedência).
  - `ENABLE_NEW_APPROVAL` e `ENABLE_PRESENTATION_V2` **não foram criadas de propósito**: não existe versão anterior funcional para onde voltar, e uma flag assim enganaria.

### Apresentação (antes → problema · depois → solução)

| Antes | Problema | Depois |
|---|---|---|
| 9 funções montando HTML direto do snapshot | Web e PDF com lógica de conteúdo separada (risco de divergir) | **Modelo editorial único** (`assets/js/apresentacao-modelo.js`): snapshot → `montarModelo()` → web **e** PDF |
| HTML gigante em strings | Difícil reaproveitar | Componentes: `Hero`, `SectionHeader`, `MetricCard`, `MetricGrid`, `InsightBlock`, `OpportunityList`, `StrategyBlock`, `VisualDirection`, `NextSteps`, `Footer` |
| Dado e opinião com a mesma cara | Interpretação parecia dado | Cada seção declara a **natureza**: *Contexto informado*, *Dado*, *Interpretação*, *Recomendação*, *Plano*. A proporção das barras é cálculo e está explicada na nota. Nenhum número é criado. |
| Rótulos em dourado #C9A667 sobre branco (~2:1) | Falha WCAG AA | Tom de texto calculado até ≥ 5:1 com branco (`--ap-accent-texto`), inclusive para a cor de cada cliente |
| `<main>` com conteúdo solto | Estrutura semântica fraca | `header` (capa) → `main` → `section[aria-labelledby]` → `footer`; listas como `<ol>`; 1 `h1` visível |
| Número "1840" na web e "1.840" no PDF | Mesmo dado com formato diferente | pt-BR nos dois |
| Sem prévia de link | Link no WhatsApp sem título | Open Graph / Twitter **genéricos** (sem dado do cliente) |

**SEO (decisão):** a apresentação continua com **noindex**, porque é proposta privada com a estratégia do cliente. Não criei canonical nem metadados com o nome do cliente para robôs.

### PDF
- **Arquitetura:** `apresentacao-pdf.js` percorre o **mesmo modelo** da web.
  - Funções: `renderPdfCover`, `renderPdfSection` (keepWithNext por cálculo de altura), `renderPdfStrategy`, `renderPdfMetric` (bloco indivisível), `renderPdfInsight` (linha curta nunca partida), `renderPdfOpportunity`, `renderPdfVisual`, `renderPdfFooter` ("Página X de Y");
  - parágrafos sem órfã nem viúva; página final vazia é removida.
- **Ordem antes de gerar:** dados prontos → `aguardarImagens()` (logo, com teto de 4 s) → `document.fonts.ready` → motor carregado → PDF.
- **Tipografia (decisão consciente):**
  - Times-Bold nos títulos (papel da Fraunces) e Helvetica no texto (papel da Manrope), fontes padrão do PDF;
  - a fonte da web **não** está disponível dentro do PDF; embutir Fraunces/Manrope exigiria fontkit + arquivos TTF (~600 KB) e os arquivos não estão no projeto.
- **Limitações:**
  - símbolos fora da fonte do PDF (★, emoji) são removidos: "4,6 ★" vira "4,6";
  - logo só PNG/JPG;
  - Safari/iOS não testado.

## 3. Banco (migration → mudança → impacto)

| Migration | Mudança | Impacto |
|---|---|---|
| `lce_012_aprovacao_parcial_enriquecidos` (aplicada) | `aprovar_captura` com subbloco por registro; `qtd_enriquecidos` + recontagem | Erro inesperado num registro não derruba o lote. Backup das definições anteriores: `backup_auditoria.objetos_01_10_012`. Validada em produção numa transação desfeita depois (2 aprovados; contagem de leads voltou a 52). Compatível com o código já publicado (a tela já mostrava "com erro"). |

## 4. Testes

| Suíte | Resultado |
|---|---|
| JS (`node tests/run-all.js`) | **PASS 299/299** (+16: polígono, Overpass com User-Agent/429/último espelho, flags-sinônimo, web = PDF, natureza das seções, null-safe, XSS do modelo, PDF com 1 / ~5 / ~10 / 20+ páginas, logo, tipografia) |
| Robô de RLS (réplica + paridade de produção) | **PASS 78/78** (novo FR04: aprovação parcial, 1 aprovado + 1 erro, sem captura "aprovada" sem lead) |
| Sonda da captação (admin 1280/390, prospecção 390) | **PASS 81/81**: ciclo do mapa, polígono (4 cantos, desfazer, envio do GeoJSON), aprovação (erro, sucesso, duplo clique), sem erro JS, sem XSS, sem rolagem lateral |
| Sonda da apresentação (8 larguras) | **PASS 85/85**, incluindo **web = PDF**: 13 itens da página conferidos no texto extraído do PDF baixado (pdftotext) em 390 e 1280 px, e estrutura (1 `main`, 1 `h1` visível, natureza em todas as seções) |
| Sonda geral do painel (12 rotas × 2 larguras × 2 papéis) | **PASS**: 0 erro JS (2 avisos antigos de alvo de toque pequeno) |
| Robô geral | 0 crítico; 3 altos **anteriores** (aviso LGPD em 2 formulários; diagnóstico por hash) |
| Fluxo real em produção (busca → aprovação → CRM → score) | **PASS** (job `ceb4fe77`) |
| Overpass depois da correção | **BLOCKED**: depende do deploy deste zip |
| Safari/iOS; leitor de tela real | **BLOCKED**: não disponíveis no ambiente |

## 5. Performance (só medido)

| Medida | Antes | Depois | Fonte |
|---|---|---|---|
| Busca de 1 cidade, até o resultado aparecer | 2 min 16 s (job `91c3931d`, código antigo) | **21,8 s** (job `ceb4fe77`, código de 30/09) | Produção, `metricas`/timestamps |
| Geoapify | — | 1,43 s | Produção |
| Overpass | — | 20 s sem resultado (406/429/timeout) | Produção. **Depois da correção de hoje: NÃO MEDIDO.** |
| Página da apresentação (localhost, sem fontes externas) | — | DCL 26–46 ms · LCP 28–156 ms · CLS ≤ 0,011 | Playwright local; **não representa a rede real**; INP e TTFB reais não medidos |
| PDF (exemplo, 4 páginas) | — | 11–92 ms | Node |

## 6. Riscos residuais

- Os espelhos públicos do Overpass continuam instáveis (429). O User-Agent resolve só o 406.
  - Se o Overpass seguir lento, o tempo total continua limitado pelo orçamento de 20 s.
  - Próxima melhoria possível: mostrar os resultados do Geoapify antes, sem esperar o Overpass.
- Polígono: as fontes buscam o círculo que cobre a área. Áreas muito alongadas gastam consulta com o que depois é descartado (contado em `fora_da_area`).
- Os riscos do relatório de 30/09 continuam valendo (cache de 24 h, sinais só da página inicial, CNPJ desligado).

## 7. Rollback

- **Código:** republicar o zip de 30/09 (`site-completo-refinamento-30-09.zip`) ou usar as flags (`ENABLE_CAPTURE_ENGINE_V2=false`, `ENABLE_MAP_SELECTION=false`, `ENABLE_PDF_V2=false`).
- **Banco 012:** executar as definições salvas em `backup_auditoria.objetos_01_10_012` (`select definicao from backup_auditoria.objetos_01_10_012`). A coluna `qtd_enriquecidos` pode ficar. **Nada foi apagado.**
