# Relatório final — Refinamento do Lead Capture Engine + Apresentação por Cliente (30/09/2026)

A auditoria completa (ARQUIVO / FUNÇÃO / DEPENDÊNCIAS / PROBLEMA / CAUSA / RISCO / SOLUÇÃO) está em `docs/AUDITORIA_REFINAMENTO_30_09.md`.

## Situação

- **Banco de produção:** a migration 011 foi **aplicada e validada**. A aprovação de leads, que falhava 100% das vezes, voltou a funcionar.
- **Código:** **pronto e testado, aguardando deploy (zip).** Sem o deploy, o site publicado continua com o código anterior. Ele segue compatível com o banco: a 011 só acrescenta.

## 1. Bugs corrigidos

| # | Bug | Causa raiz (confirmada) | Correção |
|---|-----|-------------------------|----------|
| 1 | **Nenhuma aprovação funcionava** (nem converter, arquivar, restaurar ou mesclar) | A constraint `admin_audit_log_action_check`, que só existe em produção, aceitava 8 ações. As RPCs gravam `aprovar_captura` etc., o banco devolve erro 23514 e a transação inteira é desfeita. | 011 recria a CHECK com os 8 valores antigos mais os usados pelo código. Testado em produção numa transação desfeita depois: `aprovado`, 2ª chamada `ja_aprovado`, 1 lead só. |
| 2 | Auditoria das Functions perdida em silêncio (`captacao_iniciar`, `importar_csv`, `enviar_email_prospeccao`, `optout_prospeccao`…) | Mesma constraint. | Mesma correção. |
| 3 | Testes passavam e produção falhava | A réplica local não tinha as constraints que só existem em produção. | `robo/db/paridade_producao.sql`. Sem a 011, o robô agora acusa FL01/FL06/FL07/FL12 como QUEBRADO, igual a produção. |
| 4 | Busca lenta (2 min 16 s para 1 cidade, job `91c3931d`) | Providers em série; Overpass até 6 espelhos × 8 s com `Retry-After` sem teto; consulta só por nome incluindo relações; resposta "200 vazio + remark" contada como sucesso; checagem de sites antes de gravar; sem cache. | Ver seção 4. |
| 5 | Overpass com "0 resultados, sem erro" | Resposta 200 com `remark` de timeout tratada como sucesso. | Passa a ser falha daquele espelho e o próximo é tentado. Se todos falharem, aparece como erro. |
| 6 | Apresentação pública entregava **métricas desmarcadas** e ids internos | O snapshot guarda todas as métricas do lead, e a RPC pública devolvia o `conteudo` inteiro (dava para chamar direto com a chave pública). | A RPC filtra no banco; a Function aplica lista branca de campos (2ª camada). O robô R03 confirma. Produção tem 0 apresentações, então **não houve vazamento efetivo**. |
| 7 | PDF quebrava fácil | Ver seção 6. | Motor novo. |
| 8 | Ctrl+P imprimia seções em branco | Faltava `@media print`: elementos animados ficavam com `opacity:0`, contadores em 0, barras vazias e o botão saía no papel. | `@media print` completo + `beforeprint`. |
| 9 | Mensagem de erro técnica na aprovação | O texto do banco ia direto para a tela. | "A aprovação não foi concluída. Motivo: … Nenhum lead foi criado." O detalhe técnico vai só para o log. |
| 10 | Cabeçalho do job saía da tela a 390 px | Nome de campanha longo sem quebra. | `overflow-wrap: anywhere`. |
| 11 | 404 da apresentação ficava em cache 30 s | O 404 saía com `max-age=30`. | 404/502 com `no-store`. Slug com formato inválido devolve 404 direto. |

## 2. Banco (migration → alteração → impacto)

`migrations/011_refinamento.sql` (aplicada como `lce_011_refinamento`). É aditiva e idempotente: rodada 2 vezes na réplica sem erro. Backup antes de aplicar: `backup_auditoria.objetos_30_09_011`, com as definições anteriores de `prospeccao_aprovar_um`, `apresentacao_publica` e das 2 constraints.

| Alteração | Impacto |
|-----------|---------|
| `admin_audit_log_action_check` virou superconjunto | Destrava aprovação e auditoria. Nenhum valor antigo é recusado. |
| `admin_prospeccao_buscas.metricas jsonb` | Telemetria da busca. |
| Tabela `admin_prospeccao_cache_provider` (RLS: só admin/prospecção; anônimo sem acesso) | Cache de 24 h por provider e de 30 dias da geocodificação. |
| `captura.enriquecimento`, `captura.enriquecimento_status`, `leads.enriquecimento` | Enriquecimento assíncrono com origem dos dados. |
| Tipos `SITE_SEM_CONTATO` e `SITE_SEM_FORMULARIO` (CHECK superconjunto; `aprovar_um` copia os dois) | Novos sinais medidos. **O score não muda**: não inventei peso; a decisão fica com o dono. |
| RPC `prospeccao_gravar_enriquecimento` (SECURITY DEFINER, confere o dono do job) | Única porta de escrita do enriquecimento. Só preenche campo vazio; sinal de julgamento (ex.: SITE_DESATUALIZADO) é recusado. |
| Trigger `prospeccao_captura_enriquecimento_para_lead` | Enriquecimento que chega depois da aprovação leva ao lead só o que estiver vazio. Edição manual nunca é sobrescrita (teste FR01). |
| `apresentacao_publica` filtrada | Só as métricas selecionadas e só campos públicos. |

Advisors de segurança do Supabase depois da 011: nenhuma tabela sem RLS. Os avisos de "SECURITY DEFINER executável" são de RPCs que conferem papel por dentro (intencional, já existiam). Também continua o aviso de proteção contra senha vazada desligada (configuração do Auth, decisão do dono).

## 3. APIs / providers

| Provider | Antes | Agora |
|----------|-------|-------|
| Geoapify | Série; sem prazo total | Paralelo (até 4); prazo de 12 s por consulta (`CAPTACAO_PRAZO_GEOAPIFY_MS`); cache 24 h |
| Overpass | Série; 6 espelhos × 8 s + `Retry-After` sem teto; `remark` ignorado | Paralelo (até 2, respeita o limite do servidor); orçamento total de 20 s (`CAPTACAO_PRAZO_OVERPASS_MS`); `Retry-After` ≤ 5 s; `remark` = falha; consulta por nome sem relações; `[timeout]` acompanha o prazo; cache 24 h |
| Geocodificação (Nominatim → Photon) | A cada busca, com pausa de 1,2 s entre cidades | Cache de 30 dias; pausa só entre chamadas reais à rede; área do mapa não geocodifica |
| Site da empresa | Antes de gravar, travando o resultado | Depois de gravar, 5 em paralelo. Também lê título, descrição, `<form>`, WhatsApp, e-mail e telefone da mesma página (sem requisição extra). |
| CNPJ (BrasilAPI) | Não existia | **Desligado** (`ENABLE_CNPJ_LOOKUP`): 6 s, sem retry, só CNPJ válido, grava fonte e data; quadro de sócios não é guardado. Fornecedor: **decisão do dono** · LGPD: **VALIDAÇÃO JURÍDICA NECESSÁRIA** antes de ampliar campos. |
| Instagram | Link no site / dado da fonte | Igual (fontes legítimas). **Nenhum scraping do Instagram.** |

Feature flags (variáveis do Netlify; "false" desliga):
- `ENABLE_NEW_CAPTURE_FLOW` (ligada): desligar volta ao fluxo antigo, que continua no código.
- `ENABLE_MAP_SELECTION` (ligada).
- `ENABLE_NEW_PDF_ENGINE` (ligada): desligar volta ao jsPDF antigo.
- `ENABLE_CNPJ_LOOKUP` (desligada).

## 4. Captação — o que mudou para quem usa

- **Resultados aparecem antes:** a lista é liberada assim que os registros estão gravados. Os sites são verificados em segundo plano ("Verificando sites em segundo plano — você já pode revisar e aprovar"). Quando terminam, a lista recarrega com os novos sinais e contatos.
- **Resumo real da busca**, só com telemetria medida: "Busca concluída em 2,8 s · 37 encontradas · 8 duplicadas · 29 disponíveis".
- **Minimapa:** "Ponto no mapa (bairro, rua, raio livre)".
  - Como funciona: centraliza numa cidade da lista; clique ou arraste o marcador; raio de 0,5 a 30 km; zoom pelos botões, pela roda e pelo teclado.
  - Comportamento: carrega só quando escolhido; nunca há dois mapas ao mesmo tempo; é destruído ao sair da tela.
  - Estado e validação: o mapa não guarda cópia própria da seleção; quem guarda é o formulário. O job recebe `parametros.area = {latitude, longitude, raio_metros}`, e o servidor valida a área (dentro do Brasil, raio de 0,5 a 30 km).
  - Implementação: componente próprio (~250 linhas, sem dependência), com ladrilhos do OpenStreetMap e a atribuição exigida.
  - **Por que não Leaflet:** não dá para hospedar o arquivo aqui (CDN bloqueado no ambiente), e um script de CDN dentro do painel autenticado é risco de cadeia de suprimentos.
  - **Polígono personalizado: não implementado** (próximas melhorias).
- **Aprovação:**
  - mostra "Aprovando N empresa(s)…" e depois o resumo ("10 aprovado(s) · 1 duplicado(s) · 1 bloqueado(s) por opt-out");
  - o duplo clique envia 1 requisição só, e a RPC também é idempotente;
  - em caso de erro, a mensagem fica no próprio modal e o botão volta a funcionar.

## 5. Performance — antes/depois (somente medições reais)

| Medida | Antes | Depois | Como foi medido |
|--------|-------|--------|-----------------|
| Coleta de 1 cidade (Construção, Petrolina, 15 km, 2 fontes) | **2 min 16 s** (job real `91c3931d`) | **NÃO MEDIDO em produção.** O código ainda não está publicado, e o ambiente de trabalho não alcança Geoapify, Overpass nem Nominatim. Teto por construção: ~20 s (orçamento do Overpass), com os 2 providers em paralelo. | Timestamps do job em produção. O "depois" deve ser lido em `buscas.metricas` após o deploy. |
| Paralelismo | — | 2 providers × 150 ms simulados = coleta < 270 ms (seria 300 ms em série) | Teste automatizado (atraso **simulado**) |
| Provider travado | Segurava a busca | Encerrado no prazo; o outro provider mantém os resultados | Teste automatizado (simulado) |
| Aprovação em produção | 100% de falha (23514) | Funciona (aprovado / ja_aprovado / 1 lead) | Transação real em produção, desfeita depois |
| Página da apresentação (local, sem fontes externas) | Não medido antes | DCL 21–59 ms · LCP 32–176 ms · CLS ≤ 0,011 nas 8 larguras | Playwright em localhost. **Não representa a rede real.** INP não medido. |
| Geração do PDF | Não medido antes | 11–92 ms (5 execuções; a 1ª inclui aquecimento), 4 páginas, ~10 KB | Node, mesma biblioteca do navegador |
| Peso do PDF no clique | jsPDF do cdnjs | pdf-lib 513 KB (207 KB gzip), só no clique, depois em cache (nome com hash) | Arquivo |

## 6. PDF — causa raiz, correção, mecanismo, limitações

**Causa raiz (código lido):**
1. jsPDF baixado do cdnjs no clique: se o CDN falhar, o PDF quebra, e ele seria bloqueado pela CSP `script-src 'self'` quando ela sair do modo Report-Only.
2. O título reservava 40 pt, mas título + rótulo + 1ª linha ocupam cerca de 80 pt: título órfão no pé da página.
3. Sem cabeçalho, rodapé e numeração.
4. Tema do cliente ignorado e data crua.
5. Métricas sem gráfico.
6. O nome do arquivo perdia letras acentuadas.
7. Erro mostrado por `alert`.

**Correção / mecanismo novo** (`assets/js/apresentacao-pdf.js` + `assets/vendor/pdf-lib-1.17.1.min.0f9a5cad.js`, licença MIT ao lado):
- pdf-lib hospedada no próprio site, carregada no clique;
- capa com o tema e contraste calculado;
- cabeçalho e rodapé "Página X de Y";
- título mantido com o conteúdo seguinte; parágrafos sem órfã ou viúva; cartão de métrica nunca partido, com barra proporcional;
- amostras das cores #hex;
- palavra gigante (URL) partida;
- caracteres fora da fonte (emoji, setas) trocados ou removidos, sem quebrar a geração;
- **determinístico**: mesmas entradas geram o mesmo SHA-256 (teste);
- progresso "Preparando apresentação… → Gerando PDF… → Finalizando… → PDF pronto.";
- erro amigável, com o técnico só no console;
- duplo clique gera 1 download.

A impressão do navegador (Ctrl+P) também foi corrigida:
- `@page` A4;
- capa em página própria;
- rótulos de seção nunca sozinhos no pé da página;
- cartões sem quebra no meio;
- rodapé junto do conteúdo.

Resultado: 6 páginas, sem página em branco.

**Limitações:**
- Fonte Helvetica do PDF, não Fraunces/Manrope (embutir as fontes exigiria fontkit e mais ~600 KB).
- Logo no PDF só se for PNG/JPG enviado pelo painel (SVG, WebP e URL externa ficam fora).
- Impressão pelo navegador depende do navegador (Chrome testado).
- Safari/iOS não testado neste ambiente: **NÃO FOI POSSÍVEL CONFIRMAR**.

## 7. Apresentação pública — outras correções

- **Estados distintos:**
  - "Não encontramos" (slug inexistente, sem slug ou com formato inválido);
  - "Não foi possível carregar agora" + botão "Tentar de novo" (falha de rede ou servidor);
  - carregando com `role=status`.
- **Contraste e conteúdo:**
  - texto da capa escuro automaticamente quando o cliente escolhe uma cor primária clara;
  - cores do tema só aceitas no formato `#hex`;
  - data robusta;
  - setas decorativas com `aria-hidden`.
- **Botão de PDF:** "Baixar PDF" com 44 px e `aria-label`.
- **Dados null-safe:** conteúdo nulo mostra capa + rodapé e o PDF ainda é gerado.
- **Segurança:** só a apresentação do slug pedido, só publicada, só campos públicos; slug malicioso devolve 404.
- **Estrutura** (capa → sobre → presença → métricas → interpretação → oportunidades → direção → visual → próximos passos): analisada e **mantida**. Ela já segue a narrativa diagnóstico → proposta, e mudá-la mexeria no editor do painel e nas versões já criadas.

## 8. Testes

| Suíte | Resultado |
|-------|-----------|
| JS (`node tests/run-all.js`) | **PASS 283/283** (eram 255; +28 novos: pipeline v2, Overpass, enriquecimento, CNPJ, flags, cache, área do mapa, mensagens da aprovação, PDF) |
| Robô de RLS (réplica com paridade de produção) | **PASS 77/77**. Sem a 011, falha 4 (reproduz o bug de produção). Novos: R01–R05, FR01–FR03 |
| Sonda da captação (admin 1280/390, prospecção 390) | **PASS 60/60**: resumo, enriquecimento, erro e sucesso da aprovação, duplo clique, mapa (lazy, clique, raio, instância única, limpeza, envio da área), sem erro JS, sem XSS, sem rolagem lateral |
| Sonda da apresentação (360, 390, 430, 768, 1024, 1280, 1440, 1920) | **PASS 75/75**: layout, métricas desmarcadas ausentes do DOM e do JSON, PDF (download único, válido, nome), nenhum script de CDN, impressão, estados (inexistente, sem slug, malicioso, falha + tentar de novo, conteúdo nulo, biblioteca indisponível) |
| Sonda geral do painel (12 rotas × 2 larguras × 2 papéis) | **PASS**: 0 erro JS; 2 avisos de alvo de toque pequeno (anteriores) |
| Robô geral | 0 crítico. 3 altos **anteriores** a esta execução: aviso LGPD em 2 formulários; diagnóstico por hash |
| Aprovação real em produção (transação desfeita) | **PASS** |
| Busca real em produção (velocidade) | **BLOCKED**: depende do deploy e de rede externa |
| Safari/iOS, leitor de tela real | **BLOCKED**: não disponíveis no ambiente |

## 9. Riscos residuais

- A velocidade real só será conhecida depois do deploy. Conferir `metricas` dos primeiros jobs.
- Cache de 24 h: uma empresa nova pode demorar até 24 h para aparecer numa busca idêntica. Para ajustar, use `CAPTACAO_CACHE_HORAS` (0 desliga). Termos de uso do Geoapify sobre cache: **NÃO FOI POSSÍVEL CONFIRMAR**; conferir no plano contratado.
- SITE_SEM_FORMULARIO e SITE_SEM_CONTATO olham só a página inicial: confiança "média" e a evidência diz isso.
- Os ladrilhos do mapa vêm de `tile.openstreetmap.org`. A política de uso pede volume baixo, o que é compatível com uso interno.
- Constraints de produção `admin_pages_status_check`, `admin_posts_status_check` e `admin_relatorios_tipo_check` ainda não estão na paridade do robô (fora do escopo; definições não lidas).

## 10. Rollback

1. **Código:** republicar o zip anterior (`site-completo-lead-capture-30-09.zip`), ou desligar só a parte nova pelas flags (`ENABLE_NEW_CAPTURE_FLOW=false`, `ENABLE_MAP_SELECTION=false`, `ENABLE_NEW_PDF_ENGINE=false`).
2. **Banco** (não recomendado: desfazer a CHECK quebra a aprovação de novo):
   - funções: `select definicao from backup_auditoria.objetos_30_09_011` e executar o `CREATE OR REPLACE` guardado;
   - trigger: `drop trigger prospeccao_captura_enriquecimento_para_lead on admin_prospeccao_captura`;
   - colunas e tabela novas podem ficar, porque o código antigo as ignora. **Não apagar dados.**

## 11. Próximas melhorias

1. Polígono personalizado no mapa (filtrar resultados por polígono no servidor).
2. Decidir peso no score para SITE_SEM_CONTATO e SITE_SEM_FORMULARIO (decisão do dono).
3. Escolher o fornecedor de CNPJ e ligar a flag, depois de validação jurídica.
4. Embutir Fraunces/Manrope no PDF.
5. Medir INP e LCP reais com o site publicado.
6. Completar a paridade de constraints de produção no robô.
7. Aviso LGPD nos formulários do site (pendência anterior, alta).
