# Evolui Social — Auditoria e otimização de latência da pesquisa

Data: 03/10/2026

## Objetivo
Reduzir a latência percebida e real da pesquisa, mirando ~15s sem remover fontes, EIE, RRF/MMR, biblioteca ou integração de IA.

## Intervenções desta versão

1. **Firecrawl deixou de raspar Markdown por padrão.**
   - `FIRECRAWL_SCRAPE_PESQUISA` agora precisa ser explicitamente `true`.
   - A descoberta web não deve bloquear a pesquisa com leitura profunda de páginas.
2. **Timeout do Firecrawl reduzido de 6500ms para 3500ms.**
   - Se o provedor estiver lento, ele falha de forma barata e as fontes restantes continuam.
3. **Fan-out do Firecrawl reduzido de 4 para 3 consultas.**
   - SearXNG permanece com o conjunto completo de consultas planejadas.
4. **Telemetria granular adicionada.**
   - A resposta passa a carregar `telemetria.fontes_ms`, `pesquisa_avancada_ms`, `pesquisa_avancada_etapas` e `eie_ms`.
   - A pesquisa avançada mede planejamento, SearXNG, Firecrawl e descoberta total.

## O que não foi removido

- Wikipédia
- GDELT
- Google Trends
- YouTube
- Biblioteca/Taxonomia
- Repertório
- EIE / EvoluiScore
- RRF/MMR
- Firecrawl
- SearXNG
- integração Claude/Anthropic
- Supabase / RPCs existentes

## Resultado esperado

O maior ganho esperado vem de impedir que a raspagem Markdown do Firecrawl aconteça em todas as consultas. O Firecrawl continua disponível como camada de descoberta. A leitura profunda pode ser reativada de forma explícita quando houver um fluxo que realmente precise dela.

## Validação

A suíte específica existente depende de execução TypeScript/Edge e não pode ser validada com o Node puro usado neste container: o Node retorna `ERR_UNKNOWN_FILE_EXTENSION` para os `.ts`. A sintaxe JavaScript existente foi verificada com `node --check`.

A validação final deve ser feita no runtime Supabase/Edge antes do deploy.
