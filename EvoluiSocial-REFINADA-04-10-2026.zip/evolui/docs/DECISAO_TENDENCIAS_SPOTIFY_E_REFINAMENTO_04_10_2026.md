# Evolui — decisão de arquitetura de tendências e refinamento da pesquisa
Data: 04/10/2026

## Decisão sobre áudio
A Evolui não terá player de áudio na primeira implementação desta frente. O produto precisa responder "o que está acontecendo e o que fazer", não virar um catálogo de músicas.

Quando uma fonte audiovisual existir, o resultado pode receber **preview visual** (miniatura) e link contextual. A inteligência de tendência continua independente da reprodução do áudio.

## O que foi aproveitado do estudo open source da Spotify
A referência não é o código proprietário de recomendação da Spotify. É o padrão arquitetural observado em projetos open source:

- representação de itens em vetores;
- busca por itens semelhantes;
- pipelines de dados;
- recência + velocidade;
- ranking contextual.

Projetos estudados: Annoy, Voyager, Luigi e Pedalboard.

## Aplicação na Evolui
O motor deve evoluir para:

`volume atual → velocidade → recência → contexto → similaridade → saturação → score contextual`

O objetivo é diferenciar:
- tendência grande e já saturada;
- tendência crescendo;
- sinal inicial;
- assunto relevante para um ramo específico.

O campo `semanticoExterno` já existente no EIE fica como ponto de extensão para embeddings/similaridade. Não foi criado um segundo motor semântico na interface.

## Refinamento de UX desta versão

### Carregamento
- menos etapas técnicas visíveis;
- linguagem para leigo;
- mínimo de tempo de leitura de aproximadamente 5,2 s;
- promoções durante a pesquisa ficam mais tempo na tela;
- o usuário não precisa acompanhar quais APIs estão sendo executadas.

### Resultado
Ordem principal:
1. veredito;
2. repertório;
3. oportunidade;
4. ideias/ações;
5. evidências e fontes sob demanda.

### Oportunidade
- texto principal mais curto;
- ação destacada;
- "como chegamos aqui" em segundo plano;
- fontes/data em detalhe;
- vídeos apresentados como miniaturas, quando disponíveis;
- sem lista textual de URLs poluindo o card.

### Repertório
- sobe para antes da oportunidade;
- máximo de três referências principais;
- padrões e ganchos visualmente separados;
- explicações longas saem da leitura principal;
- origem fica contextual, acionável pelo ícone de informação.

### Evidência
"Evidência insuficiente" deixa de ser linguagem de fracasso.
Agora:
**"Ainda não há sinal claro"**
com orientação para ampliar o termo ou testar variações.

### A/B
Os dois caminhos passam a ter papéis diferentes:
- Caminho A — primeira abordagem;
- Caminho B — outra hipótese.

Isso ajuda a pessoa a entender que A/B é um experimento, não simplesmente dois cards iguais.

## Regra de produto
A Evolui não deve mostrar a complexidade do motor só porque o motor é complexo.

`complexidade no backend → simplicidade na tela`

A interface deve mostrar primeiro a decisão; a prova fica disponível quando a pessoa quiser investigar.
