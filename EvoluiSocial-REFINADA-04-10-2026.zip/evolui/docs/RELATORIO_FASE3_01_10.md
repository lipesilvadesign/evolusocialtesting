# Relatório — Mega Brain Fase 3 (performance real, enriquecimento, apresentação, produção) · 01/10/2026

## 0. Ponto de partida medido (antes de mexer)

- **Deploy publicado:** `6abdbc83` (01/10, 01:51 UTC), com o código de 30/09. **O zip da Fase 2 ainda não foi publicado**, então a correção do Overpass da Fase 2 **não pôde ser medida em produção**.
- **Única busca real desde então:** job `ceb4fe77`.
  - Total de 21,8 s; Geoapify 1,43 s com 2 resultados.
  - Overpass gastou 20 s sem resultado (429, 406 e timeout).
  - Nenhuma busca nova até o fim desta fase.
- **Decisão guiada pelo dado:** o gargalo é o provider lento **bloqueando a tela**. Prioridade 1: resultados progressivos (TTFR). Prioridade 2: saúde dos espelhos, para o Overpass falhar menos e mais rápido.

## 1. O que foi feito

### Captação
| Item | Implementação |
|---|---|
| **Resultados progressivos** | `pipeline.executarPesquisaV2`, que agora é progressiva. Cada consulta que termina vira um lote (área → validação → dedup contra o que **já foi gravado** e dentro do lote → opt-out → CRM → grava). O job fica `em_revisao` com `etapa: coleta` desde o 1º lote. Lotes são processados um por vez, então a dedup é determinística. |
| **Sem duplicar** | Registro do 2º provider que é a mesma empresa **completa** o já exibido (só campos vazios), por PATCH filtrado a registros não decididos. Se ele traz o site, o sinal SEM_SITE é retirado (deixou de ser verdade) e o site entra na fila de verificação. |
| **Orçamento por provider** | Geoapify 12 s e Overpass 20 s (variáveis de ambiente); enriquecimento é assíncrono. Estouro vira `status: timeout` **só naquele provider**; a captura nunca falha por causa de um provider secundário. |
| **TTFR / TTLC** | `metricas.ttfr_ms` (início → 1º resultado gravado) e `metricas.ttlc_ms` (→ último provider gravado). Estado por provider: `aguardando`, `em_andamento`, `concluido`, `parcial`, `timeout` ou `erro`, com `duration_ms`, `resultados` e `novos`. |
| **Saúde dos espelhos + circuito** | Tabela `admin_prospeccao_provider_saude` (migration 013). Cada tentativa registra host, status (ok/429/406/5xx/timeout/erro) e duração. **3 falhas seguidas abrem pausa** de 5 a 60 min (crescente); 1 sucesso fecha. A ordem dos espelhos segue a taxa de sucesso suavizada e a latência; espelho em pausa vai para o fim (não some). Sem dependência externa. |
| **Tela** | "Encontrando empresas…" → "Primeiros resultados prontos — mais resultados chegando…". Uma linha por fonte: "Geoapify ✓ 25 resultado(s)", "OpenStreetMap ↻ pesquisando…" ou "OpenStreetMap: não respondeu a tempo. Os resultados das outras fontes já foram mantidos.". A lista recarrega sozinha; se houver itens selecionados, aparece "Mais resultados chegaram — Atualizar lista" (não troca a lista por baixo da pessoa). |
| **Erros para o usuário** | Sem "HTTP 429" nem URL na tela; frases como "a fonte de dados atingiu o limite temporário de consultas". O detalhe técnico fica no **painel técnico** (só admin). |
| **Minimapa** | "Área pesquisada · círculo de 5 km de raio · cerca de 79 km²" ou "Área personalizada · 4 pontos · cerca de X km² · as fontes consultam um raio de Y". Acima de ~300 km² aparece o aviso "Sua área cobre uma região extensa…" (não bloqueia). |
| **Fora da área** | "37 encontradas · 32 dentro da área · 5 descartadas por localização". |
| **Painel técnico** | `#/prospeccao/captacao/diagnostico`, só admin. Mostra medianas de TTFR, TTLC, dedup e gravação; por fonte, sucesso %, timeouts, erros e latência mediana; saúde por servidor (em pausa ou ativo); últimas 30 buscas com tempos e erros técnicos. **Este é o instrumento do benchmark** (seção 5). |
| **Cache por tipo** | Listagens 24 h; geocodificação 30 dias; **checagem de site 7 dias por domínio** (nova); CNPJ 30 dias (consulta desligada). Cada TTL tem justificativa no código (`cache.js`) e pode ser ajustado por variável. |

### Enriquecimento
- **Camadas independentes:**
  1. provider;
  2. site: inicial + **crawl controlado**;
  3. redes: link no site / fonte;
  4. CNPJ: desligado;
  5. contato;
  6. oportunidades.
  - A falha de uma camada não derruba as outras.
- **Crawl controlado:**
  - só quando a página inicial **não** mostra contato;
  - no máximo 2 páginas **claramente** de contato/sobre, do mesmo domínio (nunca links externos ou de blog);
  - respeita `robots.txt` (bloco `*` ou nosso User-Agent);
  - limite de 200 KB e 5 s por página; `/favicon.ico` só se o HTML não declarar ícone.
- **Oportunidades novas, só com evidência medida:**
  - `SITE_SEM_META_DESCRIPTION`, `SITE_SEM_FAVICON`, `SITE_SEM_WHATSAPP` e `SITE_SEM_INSTAGRAM`, todas com confiança "média";
  - a evidência diz **quais páginas** foram vistas e que outras não foram;
  - `SITE_SEM_INSTAGRAM` não sai se a fonte já informou perfil;
  - `SITE_DESATUALIZADO` continua **manual**: não há critério objetivo;
  - score inalterado (pesos são decisão do dono).
- **Instagram:** só de evidência (link no site, fonte, campo). A forma canônica `@handle` já existia (`normalizar.instagram`). Nenhuma adivinhação.
- **CNPJ: continua NÃO VERIFICADO.** Análise do provider:
  - BrasilAPI é gratuita, mas sem SLA e com limite não documentado: **NÃO FOI POSSÍVEL CONFIRMAR**;
  - custo zero;
  - LGPD: só dado de PJ, sem quadro de sócios. **VALIDAÇÃO JURÍDICA NECESSÁRIA** antes de ligar.
  - A integração existe, testada, atrás de `ENABLE_CNPJ_LOOKUP=false`.
- **Evidência visual (screenshot):** **não implementada**. As Netlify Functions não têm navegador; incluir Chromium passa do limite de tamanho da Function e seria uma dependência pesada. O que existe: URL, status, horário e páginas verificadas, gravados em `enriquecimento.site`.
- **Contatabilidade:** coluna **gerada no banco** (leads e captura).
  - `CONTATO_FORTE` = e-mail ou WhatsApp + pelo menos 2 canais; `CONTATO_PARCIAL` = algum canal (telefone sozinho cai aqui); `SEM_CONTATO`.
  - **Dado real de produção:** 50 leads parciais, 2 sem contato e 0 fortes.

### Score / temperatura / CRM
- **Explicabilidade:** o editor do lead mostra a composição **exatamente como o SQL gravou** (`score_motivos`), agrupada por componente, com subtotal ("+15 Encaixe: Setor estratégico (+15)…") e nota sobre os tetos. A tela não recalcula nada.
- **Histórico do score:** `admin_prospeccao_score_historico`, alimentado por trigger: antes → depois, motivos que entraram e saíram, origem. Linha de base gravada para os 52 leads.
- **Potencial × engajamento:** "Potencial: Prospectar · Engajamento: sem interação recente". Faixa vem do banco; temperatura vem das interações.
- **Próxima ação / tarefas:** `admin_prospeccao_tarefas` (lead, responsável, tipo, descrição, data, status, criada/concluída).
  - A tarefa aberta mais próxima vira `proxima_acao` + `proxima_atividade_em` do lead, por trigger; os lembretes existentes já usam esse campo.
  - Prospecção só cria tarefa **para si**, e só em lead que vê (RLS + trigger). Sem DELETE: tarefa é cancelada, e o histórico fica.
  - Na tela: "Próxima ação" no editor (agendar, concluir, cancelar, marcação de atrasada) e linha "Próxima ação: …" na lista.
  - Filtros novos na lista: contatabilidade e "com próxima ação".

### Apresentação e PDF
- **Hero:** nome + **segmento · localização** (localização vem do CRM, gravada no snapshot a partir de agora) + tipo de análise + data.
- **Insights:** **Observação → Interpretação → Implicação** (web e PDF).
- **Plano de ação:** linha opcional `Ação | Objetivo | Indicador`; a ordem é a prioridade (sem ranking melhor/pior). Web usa `<dl>`; o PDF mostra objetivo e indicador abaixo da ação.
- **Web = modelo = PDF:** teste automático com todos os textos do modelo (HTML e PDF) e conferência no navegador (pdftotext do PDF baixado × DOM), em 390 e 1280 px.
- **Símbolos:**
  - ★ vira **estrela vetorial** (opção B, medido: sem efeito em páginas nem tempo perceptível);
  - emoji e caracteres fora da fonte são removidos;
  - teste garante **nenhum "�"** no texto do PDF;
  - ✓ não vira mais "v".
- **Logo inválida** (SVG, WebP ou corrompida): monograma com as iniciais na capa; o documento nunca quebra.
- **Fontes:** mantidas Times-Bold e Helvetica. Fontkit e os TTF de Fraunces/Manrope **não estão disponíveis** neste ambiente (sem acesso a CDN ou npm), então não deu para medir peso, tempo e qualidade; **sem medição, não houve troca**.
- **Paginação testada:** 1, 2, 20 e 100 linhas (sem linha solta, sem página vazia) e 1 / ~5 / ~10 / 20+ páginas.
- **Compartilhamento:** `noindex` mantido; prévia genérica (Open Graph) sem dado do cliente.

### LGPD (auditoria)
| Ponto | Situação | Ação |
|---|---|---|
| Formulários (home, consultoria) | Coletam nome, e-mail e WhatsApp sem link para política | **Aviso no momento da coleta** + link; **página `/privacidade`** (finalidade, dados, operadores, retenção, direitos, contato) |
| Base legal | Resposta a pedido do titular (art. 7º, V) | **Sem checkbox de consentimento** (não é a base legal adequada aqui; um checkbox artificial daria falsa impressão de consentimento) |
| Prospecção B2B | Dados públicos de **empresas** | Política explica e indica o canal de opt-out (lista de bloqueio já existente) |
| Google Analytics (consultoria) | Ativo sem aviso de cookies | **VALIDAÇÃO JURÍDICA NECESSÁRIA** (guia de cookies da ANPD); listado na política |
| Retenção | Leads parados são arquivados (30 dias), nunca apagados por rotina | Política não promete prazo que o sistema não cumpre |
| Logs | Logger mascara chaves com token/senha/segredo | Mantido |
| Exports (CSV de leads) | Só admin/prospecção (Function com papel) | Mantido |

O robô de bugs foi de **3 achados altos para 1**. Os 2 de LGPD estão resolvidos. Resta o "diagnóstico por hash" da consultoria, uma decisão de produto anterior.

### Segurança
- **RLS:** 86/86 no robô (+8 novos).
  - Prospecção: não cria tarefa para outra pessoa nem em lead alheio.
  - Designer: não lê tarefas nem histórico, e não envenena a saúde dos espelhos.
  - Anônimo: não chama a RPC de saúde.
  - Circuito, contatabilidade e histórico funcionam.
- **XSS:** os textos novos passam por `esc()`; as sondas usam fixtures com `<img onerror>` em tarefa, título de site e campanha: **0 execuções**.
- **CSRF:** não se aplica. As Functions autenticam por `Authorization: Bearer`, não por cookie.
- **IDOR / escalada:** `aprovar_captura`, tarefas e enriquecimento conferem papel e dono **no banco**. O painel técnico recusa quem não é admin (Function) e a rota é `somenteAdmin`.
- **Injeção:**
  - slug malicioso devolve 404 (sonda);
  - filtros PostgREST montados com `encodeURIComponent` e listas brancas (contatabilidade só aceita 3 valores);
  - URLs de site só `https?` no crawl, mesmo host.
- **Service role:** não aparece no navegador (robô de publicação: 0 segredos).

## 2. Banco
| Migration | Mudança | Impacto |
|---|---|---|
| `lce_013_fase3_operacao` (**aplicada**) | Saúde dos providers + RPC; 4 oportunidades novas (CHECK superconjunto, listas das RPCs); `contatabilidade` gerada; histórico de score + trigger + linha de base; tarefas + guarda + "próxima ação"; cache aceita `site` | Aditiva. Backup em `backup_auditoria.objetos_01_10_013`. **DOWN documentado** no fim do arquivo. Compatível com o código já publicado: inserts usam listas de colunas, e a coluna gerada não é enviada. |

## 3. Testes
| Suíte | Antes (Fase 2) | Depois | Status |
|---|---|---|---|
| JS (`node tests/run-all.js`) | 299 | **318** | PASS |
| RLS (réplica + paridade de produção) | 78 | **86** | PASS |
| Sonda da captação | 81 | **99** | PASS |
| Sonda da apresentação (8 larguras) | 85 | **93** | PASS |
| Sonda geral do painel (13 rotas) | 0 erro JS | 0 erro JS | PASS |
| Robô geral | 3 altos | **1 alto** (anterior) | PASS |
| Benchmark em produção | — | — | **BLOCKED** (seção 5) |

Testes novos cobrem: TTFR antes do provider lento, segundo provider sem duplicar, timeout só no provider, evidência de SEM_SITE verdadeira no momento, ordem por saúde, registro por host, crawl (só link relacionado, robots.txt, favicon/meta), plano estruturado, hero, rótulos de insight, ★ vetorial e nenhum "�", logo inválida, paginação 1/2/20/100 linhas, tarefas e circuito (SQL).

## 4. Performance (só medido)
| Medida | Valor | Fonte |
|---|---|---|
| Busca antes da Fase 2 | 2 min 16 s | produção, job `91c3931d` |
| Busca com o código de 30/09 | **21,8 s** (Geoapify 1,43 s; Overpass 20 s sem resultado) | produção, job `ceb4fe77` |
| TTFR / TTLC com o código desta fase | **NÃO MEDIDO em produção** (não publicado) | — |
| TTFR em teste (provider lento simulado de 300 ms) | 1º resultado < 200 ms; TTLC ≥ 300 ms | teste automatizado, **simulado** |
| Apresentação (localhost, sem fontes externas) | DCL 38–68 ms · LCP 52–236 ms · CLS ≤ 0,012 | Playwright local (não é rede real; INP não medido) |
| PDF (4 páginas) | 11–92 ms | Node (medição de 30/09; o motor não mudou de custo) |

**Hipótese a confirmar após o deploy:** TTFR ≈ geocodificação (~0,6 s ou cache) + Geoapify (~1,4 s) ≈ **2 s**, independente do Overpass. O TTLC continua limitado ao orçamento do Overpass (≤ 20 s), com mais chance de sucesso (User-Agent + espelho saudável primeiro).

## 5. Benchmark — protocolo (executar depois do deploy)
Faça as 7 buscas abaixo no painel e abra **Prospecção → Captação → Diagnóstico técnico** (só admin). Os números do painel vêm direto de `metricas`; nada é estimado.

| # | Cenário | Como |
|---|---|---|
| 1 | Cidade pequena | Orocó, PE · raio 5 km |
| 2 | Cidade média | Juazeiro, BA · raio 15 km |
| 3 | Cidade grande | Petrolina, PE · raio 15 km |
| 4 | Raio pequeno | ponto no mapa · 1 km |
| 5 | Raio médio | ponto no mapa · 10 km |
| 6 | Polígono pequeno | 4 cantos num bairro |
| 7 | Polígono grande | área de ~300 km² (aparece o aviso) |

Repetir a #3 em seguida mede o **cache** (as fontes respondem do banco).

## 6. Produção
- **Banco:** 013 aplicada e validada (RLS ligada nas 4 tabelas novas; contatabilidade calculada nos 52 leads; 52 linhas de base no histórico).
- **Código:** `site-completo-fase3-01-10.zip`, **aguardando publicação**. Inclui a Fase 2, também ainda não publicada.
- **Flags:** `ENABLE_CAPTURE_ENGINE_V2` (desligar volta ao fluxo antigo, sequencial), `ENABLE_MAP_SELECTION`, `ENABLE_PDF_V2`, `ENABLE_CNPJ_LOOKUP` (desligada).
  - Novas variáveis opcionais: `CAPTACAO_PRAZO_OVERPASS_MS`, `CAPTACAO_PRAZO_GEOAPIFY_MS`, `CAPTACAO_CACHE_SITE_HORAS`.
- **Rollback:**
  - código: republicar o zip anterior ou desligar as flags;
  - banco: DOWN no fim de `013_fase3_operacao.sql` + funções em `backup_auditoria.objetos_01_10_013`. Nada foi apagado.

## 7. Riscos residuais
- **Benchmark real pendente:** sem o deploy, TTFR e TTLC de produção não foram medidos.
- **Espelhos públicos do Overpass:** podem continuar limitando (429). O circuito evita insistir no espelho ruim, mas não cria capacidade.
- **Sinais de site:** olham no máximo 3 páginas; contato em outra página gera falso "sem formulário/WhatsApp". A evidência registra isso e a confiança é "média".
- **Cookies do Google Analytics** e base legal: **VALIDAÇÃO JURÍDICA NECESSÁRIA**.
- **CNPJ:** desligado, aguardando decisão do dono e validação jurídica.
- **Fontes do PDF:** sem Fraunces/Manrope (decisão adiada até ser possível medir).
