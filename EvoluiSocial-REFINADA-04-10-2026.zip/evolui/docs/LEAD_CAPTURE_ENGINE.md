# Lead Capture Engine — documentação técnica

**Felipe Branding · 30/09/2026.** Este documento descreve o módulo como ele está no código e no banco. A especificação de origem é `ESPECIFICACAO_LEAD_CAPTURE_ENGINE_30_09.md`.

## 1. Regras que não podem ser quebradas

1. **Nenhum dado automático entra no CRM (`admin_prospeccao_leads`) sem passar por:**
   - captura;
   - normalização;
   - deduplicação;
   - decisão humana (RPC `aprovar_captura`).
2. **Nenhuma rotina automática destrói um lead.**
   - A limpeza agora **arquiva**.
   - O banco recusa `DELETE` feito pela service role (trigger `prospeccao_leads_bloquear_delete_automatico`).
   - Exclusão definitiva só por admin, e só de lead já arquivado (política `delete_leads`).
3. **O score e a temperatura são do banco.** O navegador só exibe. Qualquer `score` enviado é sobrescrito pelo trigger.

## 2. Arquitetura

```
PAINEL (#/prospeccao/captacao)
   │  POST captacao?acao=iniciar      ← valida TUDO e cria o job 'na_fila' (erro real, nunca 202 cego)
   ▼
admin_prospeccao_buscas  (= capture job)
   │  POST captacao-worker-background {jobId}   ← reivindica o job (na_fila → em_andamento) de forma atômica
   ▼
PROVIDERS (_lib/captacao/providers)
   geoapify · overpass · csv · consultoria · siteContato · manual
   │  todos devolvem o RegistroIntermediario (_lib/captacao/tipos.js)
   ▼
normalizar.js → deduplicar.js (job + RPC prospeccao_dedup_candidatos) → opt-out → enriquecer.js
   ▼
admin_prospeccao_captura  (capture raw; upsert idempotente em job_id+provider+external_id)
   │  trigger: normalização + score previsto; trigger de instrução: contadores do job
   ▼
REVISÃO HUMANA (aprovar · descartar · marcar duplicado · comparar · mesclar)
   │  RPC aprovar_captura (SECURITY DEFINER, 10 passos, idempotente)
   ▼
admin_prospeccao_leads (CRM) + oportunidades + atividade + auditoria
```

## 3. Arquivos

| Onde | O quê |
|---|---|
| `netlify/functions/_lib/captacao/taxonomia.js` | **Fonte única:** setores (e categorias Geoapify / tags OSM), fontes, métodos, status, oportunidades, cidades da região, temperatura, limites |
| `.../captacao/normalizar.js` | Telefone, Instagram, domínio, CNPJ (dígitos verificadores), cidade/UF, empresa, setor, similaridade (trigramas), distância |
| `.../captacao/tipos.js` | Contrato `RegistroIntermediario` + validador |
| `.../captacao/providers/*.js` | Geoapify, Overpass, CSV (servidor), inbound (consultoria/site), manual |
| `.../captacao/deduplicar.js` | Fusão dentro do job, classificação contra o CRM, opt-out |
| `.../captacao/enriquecer.js` | Checagem de site (HTTPS, status, Instagram na home), sinais com evidência |
| `.../captacao/pipeline.js` | Orquestra coleta → gravação na captura; cancelamento entre etapas |
| `.../captacao/deps.js` | Dependências reais (REST/RPC/providers), injetáveis nos testes |
| `.../captacao/acesso.js` | Autenticação + papel (admin/prospecção) + rate limit por usuário |
| `.../_lib/supabaseRest.js` | Cliente REST: timeout de 10 s, 1 retry só em GET, erros sem segredo |
| `netlify/functions/captacao.js` | API síncrona: iniciar, importar (prévia/criar/atualizar/mesclar), aprovar, descartar, marcar duplicado, mesclar, cancelar, inbound em lote |
| `netlify/functions/captacao-worker-background.js` | Worker da pesquisa |
| `netlify/functions/prospeccao-taxonomia.js` | Taxonomia para o painel |
| `netlify/functions/prospeccao.js` | CRM: filtros e paginação no servidor, arquivar, restaurar, mesclar, converter, recalcular, excluir definitivo |
| `netlify/functions/prospeccao-sync-osm.js` | Semanal: cria job (não insere no CRM) |
| `netlify/functions/prospeccao-buscar-empresas-background.js` | Rota antiga mantida só por compatibilidade → pipeline novo |
| `netlify/functions/scheduled-sync-background.js` | Arquiva parados (30 dias) + recálculo diário de score/temperatura |
| `painel/assets/js/views/captacao.js` + `services/captacaoClient.js` | Tela de captação |
| `painel/assets/js/views/prospeccao.js` | Lista paginada no servidor, filtros novos, arquivar/restaurar, score do banco |
| `migrations/001…009_*.sql` | Migrations (ver §6) |

## 4. Endpoints

| Endpoint | Autorização | Observação |
|---|---|---|
| `GET /prospeccao` | admin/prospecção + RLS | Filtros:<br>• `q`, `setor`, `subsetor`, `cidade`, `uf`, `fonte`, `metodo`, `campanha`<br>• `score_min`, `score_max`, `faixa`, `temperatura`, `prioridade`, `status`, `responsavel` (`me`/`sem`/uuid)<br>• `criado_de`, `criado_ate`, `atividade_de`, `atividade_ate`<br>• `oportunidade`, `tem_site`, `tem_instagram`, `tem_telefone`, `tem_email`, `arquivados` (`0`/`1`/`so`)<br>• `ordem`, `pagina`, `por_pagina` (50 padrão, 100 máx.) |
| `POST /prospeccao` | idem | 409 com `duplicados` se achar lead parecido (reenviar com `confirmarDuplicado: true`) |
| `POST /prospeccao?acao=arquivar\|restaurar\|mesclar\|converter\|recalcular` | arquivar: dono/admin. Restaurar, mesclar e recalcular: admin. Converter consulta: admin; contato do site: admin/prospecção | Tudo por RPC |
| `DELETE /prospeccao?id=` | admin, lead arquivado | Auditoria gravada **antes** |
| `/captacao` | admin/prospecção | Ver cabeçalho do arquivo |
| `/captacao-worker-background` | token do dono do job (ou job da rotina agendada) | |
| `/prospeccao-taxonomia` | qualquer sessão válida | Cache de 1 h |

## 5. Providers

- **Geoapify:** categorias específicas do setor (todos os resultados) + categorias genéricas filtradas pelo termo no nome.
  - Categorias conferidas na documentação oficial da Places API (30/09).
  - 1 retry com backoff em 429/5xx; timeout de 20 s.
- **Overpass:** as mesmas tags OSM + reforço por nome.
  - Reaproveita os espelhos e o Retry-After de `integrations/openStreetMap.js`; 8 s por espelho.
  - NÃO FOI POSSÍVEL CONFIRMAR no wiki do OSM a lista completa de valores de `office=*` (o acesso não foi liberado nesta execução). Por isso só entram tags equivalentes a categorias Geoapify documentadas, mais `craft=builder`, `office=company` e `man_made=works`, que são de uso comum.
- **CSV:**
  - BOM; UTF-8 com fallback para Windows-1252.
  - Separadores `;`, `,` e TAB; aspas; quebra de linha dentro do campo.
  - Mapeamento automático por sinônimos, prévia de 5 linhas; 4 MB / 1.500 linhas.
- **XLSX: não suportado (decisão).** O projeto não tem nenhuma dependência de produção (`package.json`). Adicionar um leitor de Excel exige avaliar versão, licença, tamanho e vulnerabilidades. Orientação na tela: “Salvar como CSV UTF-8”.
- **Inbound (consultoria e contato do site):**
  - Botão “Converter em lead” nas telas Consultas e Contatos do site, ou revisão em lote pela captação.
  - Conversão idempotente (`convertido_lead_id`).
  - Se já existe lead com o mesmo telefone, e-mail ou Instagram, **vincula** e registra atividade `resposta_recebida`.
- **Manual:** o formulário “Novo lead” passa pela deduplicação antes de criar.

## 6. Migrations (aplicadas em produção em 30/09/2026)

| # | Nome no Supabase | O quê | Rollback |
|---|---|---|---|
| 001 | `lce_001_arquivamento_trava_delete` | Colunas de arquivamento, índice parcial, trava anti-DELETE da service role. Backup `backup_auditoria.prospeccao_leads_30_09` (50 linhas) | No cabeçalho do arquivo |
| 002 | `lce_002_taxonomia` | `metodo_captacao`, `campanha`, `subsetor`, `uf`, `temperatura`, `convertido_de_*`, `score_calculado_em`, `origem_ids`. Constraints aceitam as fontes antigas. Backfill: 50 leads em `manual`/`prospeccao_manual`; "Coworking (…)" vira setor Coworking + subsetor | idem |
| 003 | `lce_003_normalizacao` | Funções SQL de normalização + colunas `*_norm` por trigger | idem |
| 004 | `lce_004_indices` | pg_trgm (schema `extensions`, v1.6) + índices; único só em CNPJ válido | idem |
| 005 | `lce_005_capture_jobs` | `admin_prospeccao_buscas` vira capture job; novos estados; RLS por dono. Backup `backup_auditoria.policies_30_09_lce` | idem |
| 006 | `lce_006_capture_raw` (inclui 007) | `admin_prospeccao_captura` + `admin_prospeccao_oportunidades` + espelho dos `sinal_*` | idem |
| 008 | `lce_008_score_temperatura` | Score e temperatura no banco (triggers), recálculo | idem |
| 009 | `lce_009a_dedup_aprovacao`, `lce_009b_inbound_arquivo_mescla`, `lce_009c_endurecimento_grants` | Dedup, aprovação, conversão, arquivar/restaurar/mesclar, guardas, política de delete, opt-outs só comercial, limite de e-mail global, grants | idem |
| 010 | **não criada** | Remoção dos `sinal_*` / `responsavel_interno`: só depois de um ciclo estável | — |

Todas são idempotentes. Foram testadas antes no Postgres local (reaplicadas por cima de si mesmas).

## 7. Score (0–100, um só; componentes em `score_motivos`)

| Componente | Teto | Regras |
|---|---|---|
| Encaixe | 35 | Setor estratégico ou sinal de segmento +15; cidade do Vale +10; porte +10 |
| Oportunidade | 40 | Sem site +20 (ou fora do ar +15); max(sem HTTPS +8, desatualizado +10); Instagram +10; Google +10; nova/expansão +10 |
| Contato | 15 | Telefone válido +5; e-mail +5; contato principal +5 |
| Intenção | 30 | Formulário +20; respondeu/interessado +10; reunião/proposta/cliente +20 |
| Bloqueio | — | Opt-out, "não contatar" ou arquivado dão 0 |

- **Oportunidades que contam:** não descartadas e (confirmadas ou com confiança alta).
- **Faixas:** >90 Prioritário · 61–90 Prospectar · 31–60 Nutrir · ≤30 Aguardar.
- **Setores estratégicos** (decisão de negócio, em `taxonomia.js` e na migration 008): Arquitetura, Construção, Imobiliário, Saúde, Beleza e estética, Agronegócio, Coworking.

## 8. Temperatura (só eventos e datas)

Só contam atividades **vindas do lead**: `resposta_recebida`, `reuniao_marcada`, `reuniao_realizada`, `proposta_enviada` e `negociacao`. `whatsapp_enviado` e `email_enviado` são ações da equipe e **não aquecem**.

- **Quente:** interação do lead há até 14 dias; ou status interessado/reunião/proposta com atividade há até 14 dias; ou formulário há até 7 dias.
- **Morno:** interação entre 15 e 45 dias; ou formulário há até 30 dias; ou "respondeu" com atividade há até 30 dias.
- **Frio:** o resto.
- **Nulo:** cliente, perdido ou arquivado.

Recalculada em toda escrita e diariamente, às 6h do Recife (`scheduled-sync-background`).

## 9. Deduplicação

Ordem: CNPJ (100, automático) > mesma origem/`external_id` (100, automático) > domínio com nome ≥ 0,5 (95, automático) > domínio (80) > telefone (85) > Instagram (85) > e-mail (85) > nome ≥ 0,80 na mesma cidade (70–90) > nome ≥ 0,60 com endereço ≥ 0,70 (60–75).

- Os itens sem "automático" viram **possível duplicado** e vão para revisão humana.
- Leads **arquivados contam**.
- Dentro do mesmo job, a mesma empresa vinda de duas fontes é **fundida** num registro.
- A aprovação refaz as chaves exatas dentro da transação.

## 10. Segurança

| Chave | Onde é usada |
|---|---|
| Publishable (anon) | Só formulários públicos |
| Token do usuário | Todas as Functions do CRM e da captação (RLS vale) |
| Service role | Só nas rotinas agendadas (arquivamento, recálculo, job semanal, worker de job agendado). Motivo: não existe usuário num cron. Mesmo assim, as rotinas só **arquivam** e só gravam na **captura** |

- **Permissões no banco:** as RPCs são SECURITY DEFINER e checam papel e dono lá dentro.
  - Prospecção não atribui a outro, não restaura, não exclui, não mescla e não recalcula tudo.
  - Admin faz tudo isso.
- **Robô de RLS** (`robo/db/ataques_lce.sql`): 34 testes do Capture Engine, com 69/69 OK junto aos 35 anteriores. Para rodar: `LCE=1 robo/db/testar_rls.sh <projeto> migrations/00*.sql`.
- **Descadastro:** todo e-mail de prospecção leva rodapé "responda SAIR", `List-Unsubscribe` e `Message-ID`.

## 11. Limites

- Por usuário: 1 job ativo (job parado há mais de 20 min é marcado como erro) e 10 jobs por dia (dia de Recife).
- Por job: 6 cidades, raio de 5/15/30 km, 500 resultados por provider e cidade, 1.500 registros por job, 50 checagens de site.
- Checagem de site: 5 s, 1 retry, 3 redirecionamentos, 200 KB.
- Supabase: 10 s por chamada.

## 12. Pendências e decisões (NÃO FOI POSSÍVEL CONFIRMAR / decisão de negócio)

- **Deploy:** o código novo só vale depois de publicar o zip no Netlify. O banco já está migrado e compatível com o código antigo.
- **Prazo de arquivamento automático:** 30 dias (env `PROSPECCAO_ARQUIVAR_DIAS`, mínimo 7). Antes eram 7.
- **Responsável dos 50 leads atuais:** não atribuído. Há 1 admin e 1 usuário de prospecção, e os leads foram criados por "Claude — pesquisa de prospecção", sem regra existente que defina o dono.
- **Setores estratégicos:** lista inicial, a confirmar.
- **Enriquecimento por CNPJ** (e, com ele, `EMPRESA_NOVA`): fornecedor não escolhido, não implementado.
- **XLSX:** dependência não aprovada.
- **Limite de tempo das functions síncronas** no plano Netlify: NÃO FOI POSSÍVEL CONFIRMAR. A importação CSV roda de forma síncrona; se passar do limite com 1.500 linhas, dividir o arquivo.
- **`process.env.URL` no runtime das scheduled functions:** NÃO FOI POSSÍVEL CONFIRMAR. Se não existir, o job semanal fica "na fila" e o admin clica em "Processar".
- **Plano e capacidade do Supabase:** NÃO FOI POSSÍVEL CONFIRMAR.
- **LGPD** (VALIDAÇÃO JURÍDICA NECESSÁRIA): base legal da prospecção B2B, finalidade para converter formulários em prospecção, página `/privacidade`, prazos de retenção.
- **Dashboard (Início):** ainda lê todos os leads (só as colunas de funil). Agregar no banco quando passar de alguns milhares.
