-- ============================================================
-- CORREÇÃO DE SEGURANÇA — 29/09/2026 (auditoria + robô caçador de bugs)
-- ============================================================
-- Rodar UMA vez no SQL Editor do Supabase, DEPOIS de todos os outros
-- SQL_PENDENTE_*/SQL_FIX_*. Idempotente: pode rodar de novo sem efeito
-- colateral. Testado em Postgres 16 com os 13 scripts do projeto aplicados
-- antes (robo/db/aplicar.sh + robo/db/ataques.sql): 9 ataques passavam
-- antes, 0 depois.
--
-- IMPORTANTE: este script vem junto com 3 ajustes de código que usam as
-- funções novas (consultas-evento.js, apresentacoesService.js e a checagem
-- de admin das Functions). Publique o código e rode este SQL no mesmo dia.
--
-- Antes de rodar, veja o que está valendo HOJE em produção:
--   select tablename, policyname, roles, cmd, qual, with_check
--   from pg_policies where schemaname = 'public' order by 1, 2;
-- ============================================================

-- ------------------------------------------------------------
-- 0) Funções auxiliares: search_path fixo (recomendação oficial Supabase
--    para SECURITY DEFINER) + uma nova: "é funcionário ativo?"
-- ------------------------------------------------------------
create or replace function admin_funcionario_role()
returns text language sql security definer stable set search_path = public as $$
  select role from admin_funcionarios where id = auth.uid() and ativo = true limit 1;
$$;

create or replace function admin_eh_admin()
returns boolean language sql security definer stable set search_path = public as $$
  select coalesce(admin_funcionario_role() = 'admin', false);
$$;

create or replace function admin_eh_funcionario_ativo()
returns boolean language sql security definer stable set search_path = public as $$
  select admin_funcionario_role() is not null;
$$;

create or replace function admin_pode_ver_lead(p_lead_id uuid)
returns boolean language sql security definer stable set search_path = public as $$
  select admin_eh_admin() or exists (
    select 1 from admin_prospeccao_leads where id = p_lead_id and responsavel_id = auth.uid()
  );
$$;

-- ------------------------------------------------------------
-- 1) Consultoria pública (/consultas) — ataques A01, A02, A03
--    SQL_FIX_completo_13_09.sql recriou as políticas "anon" como
--    "with check (true)" e SEM "to anon" (valiam para todo mundo).
-- ------------------------------------------------------------
drop policy if exists "anon_insert_consultas_leads" on consultas_leads;
drop policy if exists "anon_update_evento_consultas_leads" on consultas_leads;
drop policy if exists "anon_insert_consultas_atividades" on consultas_atividades;

-- No Supabase, anon recebe ALL em toda tabela nova. Tira tudo e devolve só
-- o INSERT das colunas que o formulário realmente preenche.
revoke all on consultas_leads from anon;
revoke all on consultas_atividades from anon;
grant insert (id, nome, instagram, whatsapp, email, segmento, objetivo, origem,
              resultado_analise, resultado_gerado_em, consultoria_concluida_em)
  on consultas_leads to anon;
-- id e criado_por: consultasAtividadesService.criar envia os dois (criado_por = null; a política barra outro valor)
grant insert (id, lead_id, tipo, descricao, data, criado_por) on consultas_atividades to anon;

create policy "anon_insert_consultas_leads" on consultas_leads
  for insert to anon
  with check (
    status = 'novo' and contato_realizado = false and ultimo_contato_em is null
    and observacoes_internas is null and atualizado_por is null
    and tentativa_agendamento = false and tentativa_agendamento_em is null
    and cta_clicado is null and cta_clicado_em is null
  );

create policy "anon_insert_consultas_atividades" on consultas_atividades
  for insert to anon
  with check (
    tipo in ('analise_concluida','cta_whatsapp','cta_agendamento','cta_instagram')
    and criado_por is null
  );

-- Clique em CTA: em vez de UPDATE aberto para anon (que, além de inseguro,
-- NÃO FUNCIONAVA — o filtro ?id=eq. exige política de SELECT que anon não
-- tem, então o PATCH atualizava 0 linhas em silêncio), uma função que só
-- mexe na linha informada e só nas colunas de CTA.
create or replace function consulta_registrar_cta(p_lead_id uuid, p_evento text)
returns boolean language plpgsql security definer set search_path = public as $$
declare
  v_cta text := case p_evento when 'cta_whatsapp' then 'whatsapp'
                              when 'cta_agendamento' then 'agendamento'
                              when 'cta_instagram' then 'instagram' end;
  n int;
begin
  if v_cta is null then return false; end if;
  update consultas_leads
     set cta_clicado = v_cta,
         cta_clicado_em = now(),
         tentativa_agendamento = tentativa_agendamento or (p_evento = 'cta_agendamento'),
         tentativa_agendamento_em = case when p_evento = 'cta_agendamento' then now() else tentativa_agendamento_em end,
         updated_at = now()
   where id = p_lead_id
     and created_at > now() - interval '30 days';   -- só leads recentes: limita abuso
  get diagnostics n = row_count;
  return n > 0;
end $$;
revoke all on function consulta_registrar_cta(uuid, text) from public;
grant execute on function consulta_registrar_cta(uuid, text) to anon, authenticated;

-- ------------------------------------------------------------
-- 2) Prospecção — ataques B01, B02, B03, B04
--    SQL_PENDENTE_equipe_permissoes.sql tentou apagar as políticas antigas
--    com os nomes ERRADOS ("authenticated_select_contatos" em vez de
--    "authenticated_select_prospeccao_contatos"). As antigas continuaram
--    valendo e, somadas (OR) às novas, anularam o controle por papel.
-- ------------------------------------------------------------
drop policy if exists "authenticated_select_prospeccao_contatos" on admin_prospeccao_contatos;
drop policy if exists "authenticated_insert_prospeccao_contatos" on admin_prospeccao_contatos;
drop policy if exists "authenticated_update_prospeccao_contatos" on admin_prospeccao_contatos;
drop policy if exists "authenticated_delete_prospeccao_contatos" on admin_prospeccao_contatos;
drop policy if exists "select_contatos" on admin_prospeccao_contatos;
drop policy if exists "insert_contatos" on admin_prospeccao_contatos;
drop policy if exists "update_contatos" on admin_prospeccao_contatos;
drop policy if exists "delete_contatos" on admin_prospeccao_contatos;
create policy "select_contatos" on admin_prospeccao_contatos for select using (admin_pode_ver_lead(lead_id));
create policy "insert_contatos" on admin_prospeccao_contatos for insert
  with check (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and admin_pode_ver_lead(lead_id)));
create policy "update_contatos" on admin_prospeccao_contatos for update
  using (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and admin_pode_ver_lead(lead_id)));
create policy "delete_contatos" on admin_prospeccao_contatos for delete
  using (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and admin_pode_ver_lead(lead_id)));

drop policy if exists "authenticated_select_prospeccao_atividades" on admin_prospeccao_atividades;
drop policy if exists "authenticated_insert_prospeccao_atividades" on admin_prospeccao_atividades;
drop policy if exists "authenticated_delete_prospeccao_atividades" on admin_prospeccao_atividades;
drop policy if exists "select_atividades" on admin_prospeccao_atividades;
drop policy if exists "insert_atividades" on admin_prospeccao_atividades;
drop policy if exists "delete_atividades" on admin_prospeccao_atividades;
create policy "select_atividades" on admin_prospeccao_atividades for select using (admin_pode_ver_lead(lead_id));
create policy "insert_atividades" on admin_prospeccao_atividades for insert with check (admin_pode_ver_lead(lead_id));
create policy "delete_atividades" on admin_prospeccao_atividades for delete using (admin_eh_admin());

-- Opt-outs, buscas e envios: qualquer FUNCIONÁRIO ATIVO (não "qualquer conta logada").
drop policy if exists "authenticated_select_prospeccao_optouts" on admin_prospeccao_optouts;
drop policy if exists "authenticated_insert_prospeccao_optouts" on admin_prospeccao_optouts;
drop policy if exists "funcionario_select_optouts" on admin_prospeccao_optouts;
drop policy if exists "funcionario_insert_optouts" on admin_prospeccao_optouts;
create policy "funcionario_select_optouts" on admin_prospeccao_optouts for select using (admin_eh_funcionario_ativo());
create policy "funcionario_insert_optouts" on admin_prospeccao_optouts for insert with check (admin_eh_funcionario_ativo());

drop policy if exists "authenticated_select_prospeccao_buscas" on admin_prospeccao_buscas;
drop policy if exists "authenticated_insert_prospeccao_buscas" on admin_prospeccao_buscas;
drop policy if exists "authenticated_update_prospeccao_buscas" on admin_prospeccao_buscas;
drop policy if exists "funcionario_select" on admin_prospeccao_buscas;
drop policy if exists "funcionario_insert" on admin_prospeccao_buscas;
drop policy if exists "funcionario_update" on admin_prospeccao_buscas;
create policy "funcionario_select" on admin_prospeccao_buscas for select using (admin_eh_funcionario_ativo());
create policy "funcionario_insert" on admin_prospeccao_buscas for insert with check (admin_eh_funcionario_ativo());
create policy "funcionario_update" on admin_prospeccao_buscas for update using (admin_eh_funcionario_ativo());

drop policy if exists "authenticated_select_prospeccao_envios" on admin_prospeccao_envios;
drop policy if exists "authenticated_insert_prospeccao_envios" on admin_prospeccao_envios;
drop policy if exists "authenticated_update_prospeccao_envios" on admin_prospeccao_envios;
drop policy if exists "funcionario_select" on admin_prospeccao_envios;
drop policy if exists "funcionario_insert" on admin_prospeccao_envios;
drop policy if exists "funcionario_update" on admin_prospeccao_envios;
create policy "funcionario_select" on admin_prospeccao_envios for select using (admin_eh_funcionario_ativo());
create policy "funcionario_insert" on admin_prospeccao_envios for insert with check (admin_eh_funcionario_ativo());
create policy "funcionario_update" on admin_prospeccao_envios for update using (admin_eh_funcionario_ativo());

-- ------------------------------------------------------------
-- 3) Apresentações públicas — ataque A04
--    A política "anon_select_apresentacoes_publicadas" (sem "to anon")
--    deixava qualquer um LISTAR todas as apresentações publicadas de todos
--    os clientes com a chave pública. Troca por uma função que só devolve
--    UMA apresentação, pelo slug exato, e só as colunas públicas.
-- ------------------------------------------------------------
drop policy if exists "anon_select_apresentacoes_publicadas" on admin_apresentacoes;
revoke all on admin_apresentacoes from anon;

create or replace function apresentacao_publica(p_slug text)
returns table (slug text, versao int, tema jsonb, conteudo jsonb, publicado_em timestamptz)
language sql security definer stable set search_path = public as $$
  select a.slug, a.versao::int, a.tema::jsonb, a.conteudo::jsonb, a.publicado_em
    from admin_apresentacoes a
   where a.slug = p_slug and a.status = 'publicado'
   order by a.versao desc
   limit 1;
$$;
revoke all on function apresentacao_publica(text) from public;
grant execute on function apresentacao_publica(text) to anon, authenticated;

-- Garante que funcionários continuam enxergando/editando (em alguns bancos
-- essas políticas nunca foram criadas porque o SQL de equipe falhou no meio).
drop policy if exists "select_apresentacoes" on admin_apresentacoes;
drop policy if exists "insert_apresentacoes" on admin_apresentacoes;
drop policy if exists "update_apresentacoes" on admin_apresentacoes;
create policy "select_apresentacoes" on admin_apresentacoes for select
  using (admin_eh_admin() or admin_pode_ver_lead(lead_id));
create policy "insert_apresentacoes" on admin_apresentacoes for insert
  with check (admin_eh_admin() or (admin_funcionario_role() = 'design' and admin_pode_ver_lead(lead_id)));
create policy "update_apresentacoes" on admin_apresentacoes for update
  using (admin_eh_admin() or (admin_funcionario_role() = 'design' and admin_pode_ver_lead(lead_id) and status = 'rascunho'));

-- ------------------------------------------------------------
-- 5) Encontrado em produção (29/09): regras antigas "qualquer conta logada =
--    acesso total" que anulavam as regras "somente_admin" das mesmas tabelas.
-- ------------------------------------------------------------
do $$ declare r record; begin
  for r in select * from (values
    ('admin_ai_usage','admin_ai_usage acesso autenticado'),('admin_insights_historico','admin_insights_historico acesso autenticado'),
    ('admin_relatorios','admin_relatorios acesso autenticado'),('admin_settings','admin_settings acesso autenticado'),
    ('admin_tarefas','admin_tarefas acesso autenticado'),('admin_notificacoes','admin_notificacoes acesso autenticado'),
    ('admin_audit_log','admin_audit_log escrita autenticada'),('admin_audit_log','admin_audit_log leitura autenticada'),
    ('admin_pages','admin_pages acesso total autenticado'),('admin_posts','admin_posts acesso total autenticado'),
    ('site_content','site_content escrita autenticada')) v(tabela, politica)
  loop
    if to_regclass('public.' || r.tabela) is not null then execute format('drop policy if exists %I on public.%I', r.politica, r.tabela); end if;
  end loop;
end $$;
do $$ begin
  if to_regprocedure('public.admin_funcionarios_protege_colunas_sensiveis()') is not null then
    alter function public.admin_funcionarios_protege_colunas_sensiveis() set search_path = public;
  end if;
end $$;

-- ------------------------------------------------------------
-- 4) Conferência final — deve voltar ZERO linhas.
-- ------------------------------------------------------------
select tablename, policyname, cmd, qual, with_check
  from pg_policies
 where schemaname = 'public'
   and (qual = 'true' or with_check = 'true' or qual like '%''authenticated''%' or with_check like '%''authenticated''%')
   and tablename not in ('admin_settings','admin_posts','admin_pages','site_content');
