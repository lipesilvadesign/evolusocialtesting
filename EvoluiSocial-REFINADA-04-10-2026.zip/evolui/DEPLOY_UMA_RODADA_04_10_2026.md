# EVOLUI — DEPLOY EM UMA RODADA

Este pacote foi fechado para evitar ciclos repetidos de deploy.

## 1. Banco — uma execução

No Supabase SQL Editor, execute:

```text
SQL_EVOLUI_INTELIGENCIA_CONSOLIDADO_04_10_2026.sql
```

Não execute também os SQLs individuais EVI/EKE/agregado para não repetir o mesmo trabalho. Os SQLs individuais permanecem apenas como histórico/documentação.

## 2. Supabase — uma publicação

Publique a Edge Function:

```text
supabase/functions/evolui-api
```

Depois configure apenas estes secrets para o EVI:

```text
EVI_VIDEO_WORKER_URL
EVI_VIDEO_WORKER_TOKEN
```

Os secrets legados de vídeo só são necessários se você decidir manter o analisador legado como fallback.

## 3. Worker EVI — uma publicação

Build:

```bash
cd evi-video-worker
docker build -t evolui-evi-video:v1 .
```

Publique essa imagem no seu host de containers uma única vez e use a URL `/analyze` como `EVI_VIDEO_WORKER_URL`.

O container já inclui FFmpeg + faster-whisper + PySceneDetect + OpenCV + yt-dlp-ejs + Deno.

## 4. Netlify — uma publicação

Publique a raiz deste pacote no mesmo site Netlify já utilizado pela Evolui.

## 5. KeyAPI — não precisa de deploy

A chave fica apenas no ambiente local que executará o benchmark:

PowerShell:

```powershell
$env:KEYAPI_API_KEY = "SUA_CHAVE"
node scripts/keyapi-benchmark.mjs --live
```

Linux/macOS:

```bash
KEYAPI_API_KEY="SUA_CHAVE" node scripts/keyapi-benchmark.mjs --live
```

O benchmark usa 56 créditos no plano inicial e nunca ultrapassa 98.

## 6. Teste final

Depois da rodada:

```text
buscar → pesquisa normal
buscar_referencias_pinterest → Pinterest
analisar_video_pro → EVI
```

O erro `Ação desconhecida` deixa de ocorrer quando a Edge Function publicada é esta versão.

## IMPORTANTE

A chave KeyAPI não deve ser colocada no frontend, no ZIP, em `.env` versionado ou em commits.

O único passo que não pode ser executado automaticamente neste ambiente é o consumo dos créditos KeyAPI, porque a chave privada do usuário não está disponível aqui.
