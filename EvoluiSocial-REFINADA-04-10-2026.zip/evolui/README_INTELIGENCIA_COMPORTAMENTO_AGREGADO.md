# Evolui — Inteligência Comportamental Agregada v1

## Objetivo

Adicionar uma camada de aprendizado do próprio produto sem armazenar `user_id` na tabela de sinais agregados.

O motor registra apenas volume diário por `tema + ramo + origem` e, na leitura, compara os últimos 7 dias com os 7 anteriores.

## Proteções

- Não grava nome, e-mail, IP ou `user_id`.
- RLS bloqueia acesso direto à tabela.
- A leitura exige limiar mínimo de 3 eventos.
- A API expõe apenas volume agregado e crescimento.
- Sinais agregados são marcados como `tipo: agregado`.
- A camada é de enriquecimento: se o RPC falhar, a pesquisa continua normalmente.

## Aplicação

Executar `SQL_INTELIGENCIA_COMPORTAMENTO_AGREGADO_04_10.sql` no Supabase.

Depois disso, cada pesquisa registra um evento agregado e pode receber um sinal histórico do próprio uso da Evolui.

## Exemplo

Se um tema teve:

- 18 pesquisas nos últimos 7 dias;
- 9 nos 7 dias anteriores;

A Evolui pode receber `crescimento = 100%` como sinal agregado.

Isso não significa que o tema vai viralizar e não identifica quem pesquisou. É apenas uma evidência adicional para o motor contextual.
