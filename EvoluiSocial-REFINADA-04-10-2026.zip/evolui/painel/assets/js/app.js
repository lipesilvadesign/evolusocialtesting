import { getCurrentUser, signIn, signOut, onAuthChange } from './services/auth.js';
import { createDrawer } from './components/Drawer.js';
import { renderInicio } from './views/inicio.js';
import { renderDesempenho } from './views/desempenho.js';
import { renderSistema } from './views/sistema.js';
import { renderProspeccao } from './views/prospeccao.js';
import { renderCaptacao, renderCaptacaoDiagnostico } from './views/captacao.js';
import { renderConsultorias } from './views/consultorias.js';
import { renderContatosSite } from './views/contatosSite.js';
import { contarContatosNovos } from './services/contatosSiteClient.js';
import { renderClientes } from './views/clientes.js';
import { renderFinanceiro } from './views/financeiro.js';
import { renderFuncionarios } from './views/funcionarios.js';
import { renderComunicacao } from './views/comunicacao.js';
import { renderPerfil } from './views/perfil.js';
import { renderEvoluiSocial } from './views/evoluisocial.js';
import { alertasEvolui } from './services/evoluiAdminClient.js';
import { atualizarBadgeMural } from './services/muralStatus.js';
import { ehAdmin, temAcesso } from './services/rbac.js';
import { applyHeadingFx, initTiltCard } from './utils/textFx.js';

// Nova arquitetura (reformulação "dashboard operacional"): "Início"
// substitui a antiga "Visão Geral" como tela padrão. "#/visao-geral" é
// mantido como alias (redireciona pro mesmo render) só pra não quebrar um
// favorito/link antigo de alguém que já usava o painel.
// "Inteligência"/Insights e "Site (GA4)" saíram (dependiam de GA4, que o
// Felipe decidiu abandonar aqui — configura manualmente fora do painel).
// Os arquivos views/insights.js e a Function analytics-insights.js
// continuam no projeto, só sem rota: uma versão futura focada em
// desempenho de equipe/prospecção pode reaproveitar os componentes
// (InsightCard/IntelligenceBoard) em vez de partir do zero.
// "Conteúdo do site" e "Geral" saíram pro admin.html (gestão já existe lá
// — ver link no rodapé do menu); views/conteudo.js e configuracoes.js
// continuam intactos, só sem rota aqui.
// "Financeiro" é novo — módulo não existia antes desta rodada (ver
// cabeçalho de views/financeiro.js e SQL_PENDENTE_financeiro.sql).
// somenteAdmin: true pelo mesmo motivo de Funcionários/Sistema — dado
// financeiro da agência não é visível pra quem não é admin.
const ROUTES = {
  '#/inicio': { render: renderInicio, navId: 'nav-inicio' },
  '#/visao-geral': { render: renderInicio, navId: 'nav-inicio' },
  // 30/09: prospecção só para a equipe comercial (a Function também recusa os outros papéis)
  '#/prospeccao': { render: renderProspeccao, navId: 'nav-prospeccao', papeis: ['admin', 'prospeccao'] },
  '#/prospeccao/captacao': { render: (el) => renderCaptacao(el), navId: 'nav-prospeccao', papeis: ['admin', 'prospeccao'] },
  '#/prospeccao/captacao/diagnostico': { render: (el) => renderCaptacaoDiagnostico(el), navId: 'nav-prospeccao', somenteAdmin: true },
  '#/clientes': { render: renderClientes, navId: 'nav-clientes' },
  '#/consultorias': { render: renderConsultorias, navId: 'nav-consultorias' },
  // 29/09: formulário "Vamos conversar" da home — comercial (admin + prospecção).
  '#/contatos-site': { render: renderContatosSite, navId: 'nav-contatos-site', papeis: ['admin', 'prospeccao'] },
  '#/financeiro': { render: renderFinanceiro, navId: 'nav-financeiro', somenteAdmin: true },
  '#/desempenho': { render: renderDesempenho, navId: 'nav-desempenho' },
  '#/comunicacao': { render: renderComunicacao, navId: 'nav-comunicacao' },
  '#/perfil': { render: renderPerfil, navId: 'nav-perfil' },
  '#/funcionarios': { render: renderFuncionarios, navId: 'nav-funcionarios', somenteAdmin: true },
  '#/sistema': { render: renderSistema, navId: 'nav-sistema', somenteAdmin: true },
  // 01/10: EvoluiSocial (produto) — usuários, uso, agentes, segurança e arrecadação. Só admin.
  '#/evoluisocial': { render: renderEvoluiSocial, navId: 'nav-evoluisocial', somenteAdmin: true },
};
const DEFAULT_ROUTE = '#/inicio';

const $ = (id) => document.getElementById(id);
let usuarioAtual = null;

function setActiveNav(navId) {
  document.querySelectorAll('.app-nav-item[data-route]').forEach((el) => {
    el.classList.toggle('is-active', el.id === navId);
  });
}

// Única rota com parâmetro hoje: #/clientes/<id> (página individual do
// cliente). Resolvida à parte, sem reescrever o roteador — as demais rotas
// continuam vindo direto de ROUTES, sem mudança de comportamento.
function matchClienteDetalhe(hash) {
  const m = hash.match(/^#\/clientes\/([^/]+)$/);
  return m ? m[1] : null;
}

// 30/09: #/prospeccao/captacao/<jobId> (resultado de uma captação)
function matchCaptacaoJob(hash) {
  const m = hash.match(/^#\/prospeccao\/captacao\/([0-9a-f-]{36})/i);
  return m ? m[1] : null;
}

function renderRoute() {
  const jobId = matchCaptacaoJob(window.location.hash);
  if (jobId) {
    const mainContent = $('main-content');
    if (!usuarioAtual || !['admin', 'prospeccao'].includes(usuarioAtual.role)) {
      mainContent.innerHTML = '<div class="app-view-head"><h2>Acesso restrito</h2><p>Esta área é da equipe comercial (administração e prospecção).</p></div>';
      setActiveNav(null);
      return;
    }
    renderCaptacao(mainContent, jobId);
    setActiveNav('nav-prospeccao');
    mainContent.scrollTop = 0;
    return;
  }
  const clienteId = matchClienteDetalhe(window.location.hash);
  if (clienteId) {
    const mainContent = $('main-content');
    renderClientes(mainContent, clienteId);
    setActiveNav('nav-clientes');
    mainContent.scrollTop = 0;
    return;
  }

  // Parâmetros depois de "?" (ex.: #/prospeccao?arquivados=so) não mudam a rota
  const semQuery = window.location.hash.split('?')[0];
  const hash = ROUTES[semQuery] ? semQuery : DEFAULT_ROUTE;
  const route = ROUTES[hash];
  const mainContent = $('main-content');

  // Proteção de rota — não é só esconder o link do menu (isso também é
  // feito, ver showShell). Mesmo navegando direto pra #/funcionarios pela
  // URL, quem não é admin recebe uma tela de acesso negado, nunca o
  // conteúdo. A barreira real continua sendo a RLS (a Function/consulta por
  // trás disso recusaria de qualquer jeito) — isto aqui é só não fingir
  // que carregou algo que na prática voltaria vazio/erro.
  const semPapel = route.papeis && !route.papeis.includes(usuarioAtual && usuarioAtual.role);
  if ((route.somenteAdmin && !ehAdmin(usuarioAtual)) || semPapel) {
    mainContent.innerHTML = `
      <div class="app-view-head"><h2>Acesso restrito</h2><p>${semPapel ? 'Esta área é da equipe comercial (administração e prospecção).' : 'Esta área é exclusiva de administradores.'}</p></div>
    `;
    setActiveNav(null);
    return;
  }

  route.render(mainContent);
  setActiveNav(route.navId);
  mainContent.scrollTop = 0;
  // Título da página "entra" palavra por palavra — só cosmético, nunca
  // bloqueia nada se o head ainda não estiver no DOM (a maioria das views é
  // assíncrona; roda de novo a cada troca de rota, então pega o head novo).
  requestAnimationFrame(() => applyHeadingFx(mainContent));
  // Bolinha de mensagem não lida (13/09, 2ª rodada) — checagem leve, a cada
  // navegação; nunca trava a troca de rota (fire-and-forget).
  atualizarBadgeMural(usuarioAtual);
  atualizarBadgeContatos();
  atualizarBadgeEvolui();
}

// Alertas abertos do agente de segurança da EvoluiSocial (só admin; nunca trava a navegação)
async function atualizarBadgeEvolui() {
  const badge = $('evoluiBadge');
  if (!badge || !ehAdmin(usuarioAtual)) return;
  try {
    const n = ((await alertasEvolui(true)) || []).length;
    badge.hidden = n === 0;
    badge.textContent = n > 99 ? '99+' : String(n);
    badge.setAttribute('aria-label', `${n} alerta(s) de segurança`);
  } catch (e) { badge.hidden = true; }
}

// Contador de contatos do site ainda "novos" no menu (29/09) — mesma ideia
// da bolinha do mural: leve, nunca trava a navegação.
async function atualizarBadgeContatos() {
  const badge = $('contatosSiteBadge');
  if (!badge || !usuarioAtual || !['admin', 'prospeccao'].includes(usuarioAtual.role)) return;
  const n = await contarContatosNovos();
  badge.hidden = n === 0;
  badge.textContent = n > 99 ? '99+' : String(n);
  badge.setAttribute('aria-label', `${n} contato(s) novo(s)`);
}

function showShell(user) {
  usuarioAtual = user;
  $('gate').style.display = 'none';
  $('app-shell').style.display = 'flex';
  $('sidebar-user-email').textContent = user.email;
  document.querySelectorAll('[data-somente-admin]').forEach((el) => {
    el.style.display = ehAdmin(user) ? '' : 'none';
  });
  document.querySelectorAll('[data-papeis]').forEach((el) => {
    el.style.display = el.dataset.papeis.split(',').includes(user.role) ? '' : 'none';
  });
  window.addEventListener('hashchange', renderRoute);
  window.addEventListener('contatos-site:mudou', atualizarBadgeContatos);
  renderRoute();
}

function showAcessoRevogado(user) {
  $('gate').style.display = 'none';
  $('app-shell').style.display = 'none';
  let tela = $('acesso-revogado');
  if (!tela) {
    tela = document.createElement('div');
    tela.id = 'acesso-revogado';
    tela.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;text-align:center;padding:24px;font-family:var(--font-body,sans-serif)';
    tela.innerHTML = `
      <h1 style="margin-bottom:8px">Acesso não configurado</h1>
      <p style="color:var(--text-muted,#666);max-width:420px">
        Sua conta (<span id="acessoRevogadoEmail"></span>) está autenticada, mas ainda não tem um papel liberado
        na equipe da Felipe Branding, ou seu acesso foi revogado. Fale com um administrador.
      </p>
      <button id="logoutRevogadoBtn" class="btn btn-ghost btn-sm" style="margin-top:16px">Sair</button>
    `;
    tela.querySelector('#acessoRevogadoEmail').textContent = user.email;
    document.body.appendChild(tela);
    tela.querySelector('#logoutRevogadoBtn').addEventListener('click', async () => {
      await signOut();
      tela.remove();
      showGate();
    });
  }
  tela.style.display = 'flex';
}

function showGate() {
  const tela = $('acesso-revogado');
  if (tela) tela.style.display = 'none';
  $('app-shell').style.display = 'none';
  $('gate').style.display = 'flex';
}

async function boot() {
  const gateBox = document.querySelector('.gate-box');
  if (gateBox) initTiltCard(gateBox);

  const user = await getCurrentUser();
  if (user) {
    if (temAcesso(user)) showShell(user); else showAcessoRevogado(user);
  } else {
    showGate();
  }

  // Login
  const form = $('gateForm');
  const errorEl = $('gateError');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.style.display = 'none';
    const email = $('gateEmail').value.trim();
    const password = $('gatePassword').value;
    const submitBtn = $('gateSubmit');
    submitBtn.disabled = true;
    submitBtn.innerHTML = 'Entrando <span class="fx-bars-spinner"><span></span><span></span><span></span></span>';
    const { error } = await signIn(email, password);
    submitBtn.disabled = false;
    submitBtn.textContent = 'Entrar';
    if (error) {
      errorEl.textContent = 'E-mail ou senha inválidos.';
      errorEl.style.display = 'block';
      return;
    }
    const loggedUser = await getCurrentUser();
    if (loggedUser) {
      if (temAcesso(loggedUser)) showShell(loggedUser); else showAcessoRevogado(loggedUser);
    }
  });

  // Logout
  $('logoutBtn').addEventListener('click', async () => {
    await signOut();
    window.removeEventListener('hashchange', renderRoute);
    showGate();
  });

  // Drawer mobile
  createDrawer({
    sidebarEl: $('sidebar'),
    overlayEl: $('drawerOverlay'),
    triggerEl: $('menuToggle'),
  });
}

boot();
