import { authedFetch } from './apiClient.js';

/**
 * @param {{range?:string, start?:string, end?:string}} rangeQuery
 * @param {{ refresh?: boolean }} [opts]
 */
export async function fetchAiAnalysis(rangeQuery = { range: '30d' }, opts = {}) {
  const params = new URLSearchParams(rangeQuery);
  if (opts.refresh) params.set('refresh', 'true');
  const { analysis } = await authedFetch(`/.netlify/functions/ai-insights?${params.toString()}`);
  return analysis;
}
