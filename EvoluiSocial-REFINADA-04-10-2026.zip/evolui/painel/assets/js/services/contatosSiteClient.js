import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/contatos-site';

/** @returns {Promise<{ contatos: object[], email: { configurado: boolean, destino: string } }>} */
export function fetchContatosSite() {
  return authedFetch(ENDPOINT);
}

/** @param {string} id @param {{ status?: string, observacoesInternas?: string|null }} payload */
export async function updateContatoSite(id, payload) {
  const { contato } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
  return contato;
}

export async function deleteContatoSite(id) {
  await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}

/** @returns {Promise<{ resultado: { status: string, erro?: string }, contato: object }>} */
export function reenviarAvisoContato(id) {
  return authedFetch(`${ENDPOINT}?acao=reenviar&id=${encodeURIComponent(id)}`, { method: 'POST' });
}

/** @returns {Promise<{ resultado: { status: string, erro?: string, destino?: string } }>} */
export function testarEmailContatos() {
  return authedFetch(`${ENDPOINT}?acao=testar-email`, { method: 'POST' });
}

/** Quantos contatos ainda estão como "novo" — usado na bolinha do menu. Nunca lança. */
export async function contarContatosNovos() {
  try {
    const { contatos } = await fetchContatosSite();
    return contatos.filter((c) => c.status === 'novo').length;
  } catch {
    return 0;
  }
}
