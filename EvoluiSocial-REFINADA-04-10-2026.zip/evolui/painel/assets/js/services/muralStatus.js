/**
 * "Bolinha vermelha de mensagem não lida" (pedido 13/09, 2ª rodada) — sem
 * infraestrutura nova: reaproveita listarMensagens()/listarFuncionarios()
 * que já existem. mural_ultima_leitura (coluna nova em admin_funcionarios,
 * ver SQL_FIX_completo_13_09.sql §4d) guarda quando a PRÓPRIA pessoa abriu
 * o mural pela última vez.
 */
import { listarMensagens } from './equipeMensagensClient.js';
import { listarFuncionarios, atualizarFuncionario } from './funcionariosClient.js';

/**
 * @param {{id:string}} usuario
 * @returns {Promise<boolean>} true = existe mensagem de outra pessoa mais nova que a última leitura
 */
export async function temMensagemNaoLida(usuario) {
  if (!usuario) return false;
  try {
    const mensagens = await listarMensagens();
    if (!mensagens.length) return false;
    const ultima = mensagens[mensagens.length - 1]; // listarMensagens() já devolve em ordem cronológica (mais nova por último)
    if (ultima.autor_id === usuario.id) return false; // mensagem da própria pessoa não conta como "não lida"
    const funcionarios = await listarFuncionarios();
    const propria = funcionarios.find((f) => f.id === usuario.id);
    const ultimaLeitura = propria && propria.mural_ultima_leitura;
    if (!ultimaLeitura) return true;
    return new Date(ultima.created_at) > new Date(ultimaLeitura);
  } catch {
    // Nunca deixa essa checagem cosmética quebrar navegação nenhuma —
    // se falhar (rede, coluna ainda não migrada), simplesmente não mostra
    // a bolinha desta vez.
    return false;
  }
}

/** Marca "vi o mural agora" — chamado uma vez ao abrir a tela de Comunicação. */
export async function marcarMuralVisto(usuario) {
  if (!usuario) return;
  try {
    await atualizarFuncionario(usuario.id, { muralUltimaLeitura: new Date().toISOString() });
  } catch {
    // Cosmético — se falhar, a bolinha só continua aparecendo até a
    // próxima vez que der certo. Não interrompe o uso do mural.
  }
}

/**
 * Mostra/esconde a bolinha vermelha no item de menu "Comunicação". Chamada
 * pelo app.js (no boot e a cada navegação) e pela própria tela de
 * Comunicação (assim que marca como visto, some na hora — sem esperar a
 * próxima checagem).
 */
export async function atualizarBadgeMural(usuario) {
  const dot = document.getElementById('comunicacaoBadgeDot');
  if (!dot) return;
  const temNaoLida = await temMensagemNaoLida(usuario);
  dot.hidden = !temNaoLida;
}
