/**
 * RBAC (admin/prospeccao/design) — PROMPT 4.
 *
 * IMPORTANTE: isto é só UX (esconder/desabilitar botão, evitar navegar pra
 * uma tela que vai dar erro). A autorização de VERDADE está nas policies de
 * RLS no Postgres (ver SQL_PENDENTE_equipe_permissoes.sql) — mesmo que
 * alguém contorne esta camada (chamando a Function ou o Supabase REST
 * direto), o banco recusa. Nunca confiar só nisto.
 *
 * Matriz de permissões (documentada por completo em
 * PROMPT_4_EQUIPE_PERMISSOES.md):
 *
 *                                admin   prospeccao      design
 * Visualizar cliente              sim    atribuído     atribuído
 * Criar cliente                   sim     próprio¹        não
 * Editar cliente                  sim    atribuído         não
 * Excluir cliente                 sim       não            não
 * Ver métricas                    sim    atribuído          não
 * Gerar diagnóstico                sim      não        não (só lê publicado)
 * Editar apresentação (rascunho)    sim      não          atribuído
 * Publicar apresentação              sim      não             não
 * Gerar PDF                           sim    atribuído       atribuído
 * Gerenciar usuários                   sim      não             não
 * Gerenciar configurações               sim      não             não
 *
 * ¹ prospeccao só cria lead já atribuído a si mesmo (a RLS de INSERT exige
 * responsavel_id = auth.uid() pra esse papel).
 *
 * @param {import('../../../../netlify/functions/_lib/types').AdminUser|null} user
 */

function role(user) {
  return user ? user.role : null;
}

export function temAcesso(user) {
  return Boolean(user) && role(user) !== 'sem_acesso';
}

export function ehAdmin(user) {
  return role(user) === 'admin';
}

/** @param {object} lead objeto do lead/cliente (precisa de responsavel_id) */
function ehResponsavel(user, lead) {
  return Boolean(lead) && Boolean(user) && lead.responsavel_id === user.id;
}

export function podeVerCliente(user, lead) {
  return ehAdmin(user) || ehResponsavel(user, lead);
}
export function podeCriarCliente(user) {
  return ehAdmin(user) || role(user) === 'prospeccao';
}
export function podeEditarCliente(user, lead) {
  return ehAdmin(user) || (role(user) === 'prospeccao' && ehResponsavel(user, lead));
}
export function podeExcluirCliente(user) {
  return ehAdmin(user);
}
export function podeVerMetricas(user, lead) {
  return podeVerCliente(user, lead);
}
export function podeRegistrarMetrica(user, lead) {
  return ehAdmin(user) || (role(user) === 'prospeccao' && ehResponsavel(user, lead));
}
export function podeGerenciarDiagnostico(user) {
  return ehAdmin(user);
}
export function podeEditarApresentacao(user, lead) {
  return ehAdmin(user) || (role(user) === 'design' && ehResponsavel(user, lead));
}
export function podePublicarApresentacao(user) {
  return ehAdmin(user);
}
export function podeGerarPdf(user, lead) {
  return podeVerCliente(user, lead);
}
export function podeGerenciarUsuarios(user) {
  return ehAdmin(user);
}

/** Usado por views/configuracoes.js — nome mantido por compatibilidade. */
export function canManageSettings(user) {
  return ehAdmin(user);
}
/** Usado por views/conteudo.js — nome mantido por compatibilidade. */
export function canManageContent(user) {
  return ehAdmin(user);
}
