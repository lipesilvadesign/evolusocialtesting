import { authedFetch } from './apiClient.js';

const CONTRATOS = '/.netlify/functions/financeiro-contratos';
const PARCELAS = '/.netlify/functions/financeiro-parcelas';
const DESPESAS = '/.netlify/functions/financeiro-despesas';

export async function listarContratos() {
  const { contratos } = await authedFetch(CONTRATOS);
  return contratos;
}

/** @param {{ leadId: string, servico: string, valorTotal: number, dataInicio?: string, numeroParcelas?: number, recorrente?: boolean, observacoes?: string }} payload */
export async function criarContrato(payload) {
  return authedFetch(CONTRATOS, { method: 'POST', body: JSON.stringify(payload) });
}

/** @param {string} id @param {object} payload */
export async function atualizarContrato(id, payload) {
  const { contrato } = await authedFetch(`${CONTRATOS}?id=${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
  return contrato;
}

export async function excluirContrato(id) {
  await authedFetch(`${CONTRATOS}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}

/** @param {string} [contratoId] */
export async function listarParcelas(contratoId) {
  const qs = contratoId ? `?contratoId=${encodeURIComponent(contratoId)}` : '';
  const { parcelas } = await authedFetch(`${PARCELAS}${qs}`);
  return parcelas;
}

/** @param {string} id @param {{ status: string, pagoEm?: string, valorPago?: number, formaPagamento?: string }} payload */
export async function atualizarStatusParcela(id, payload) {
  const { parcela } = await authedFetch(`${PARCELAS}?id=${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
  return parcela;
}

export async function listarDespesas() {
  const { despesas } = await authedFetch(DESPESAS);
  return despesas;
}

/** @param {{ categoria: string, descricao: string, fornecedor?: string, valor: number, vencimento: string, recorrente?: boolean, comprovanteUrl?: string, observacoes?: string }} payload */
export async function criarDespesa(payload) {
  const { despesa } = await authedFetch(DESPESAS, { method: 'POST', body: JSON.stringify(payload) });
  return despesa;
}

/** @param {string} id @param {object} payload */
export async function atualizarDespesa(id, payload) {
  const { despesa } = await authedFetch(`${DESPESAS}?id=${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(payload) });
  return despesa;
}

export async function excluirDespesa(id) {
  await authedFetch(`${DESPESAS}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}
