import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/metricas';

/** @param {string} leadId @returns {Promise<object[]>} */
export async function listarMetricas(leadId) {
  const { metricas } = await authedFetch(`${ENDPOINT}?leadId=${encodeURIComponent(leadId)}`);
  return metricas;
}

/** @param {{ leadId: string, nome: string, valor?: number, valorTexto?: string, unidade?: string, origem?: string, periodo?: string, dataColeta?: string, definicao?: string }} dados */
export async function criarMetrica(dados) {
  const { metrica } = await authedFetch(ENDPOINT, { method: 'POST', body: JSON.stringify(dados) });
  return metrica;
}

/** @param {string} id */
export async function removerMetrica(id) {
  await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}
