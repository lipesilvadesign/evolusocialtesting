/**
 * Cliente de Analytics usado pelo painel.
 * Etapa GA4: os relatórios agora são REAIS e exigem sessão autenticada
 * (mesmo authedFetch usado por conteúdo/configurações) — antes, com dados
 * mockados, este endpoint não exigia login.
 */
import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/analytics-ga';

function qs(params) {
  const usp = new URLSearchParams(params);
  return usp.toString();
}

/** @param {{range?:string, start?:string, end?:string}} rangeQuery */
export function fetchAnalyticsOverview(rangeQuery = { range: '7d' }) {
  return authedFetch(`${ENDPOINT}?report=overview&${qs(rangeQuery)}`);
}

export function fetchTrafficSources(rangeQuery = { range: '7d' }) {
  return authedFetch(`${ENDPOINT}?report=traffic-sources&${qs(rangeQuery)}`);
}

export function fetchTopPages(rangeQuery = { range: '7d' }) {
  return authedFetch(`${ENDPOINT}?report=top-pages&${qs(rangeQuery)}`);
}

export function fetchEvents(rangeQuery = { range: '7d' }) {
  return authedFetch(`${ENDPOINT}?report=events&${qs(rangeQuery)}`);
}

export function fetchDevices(rangeQuery = { range: '7d' }) {
  return authedFetch(`${ENDPOINT}?report=devices&${qs(rangeQuery)}`);
}

export function fetchLocations(rangeQuery = { range: '7d' }) {
  return authedFetch(`${ENDPOINT}?report=locations&${qs(rangeQuery)}`);
}

export function fetchRealtime() {
  return authedFetch(`${ENDPOINT}?report=realtime`);
}

export function testGaConnection() {
  return authedFetch(`${ENDPOINT}?report=test-connection`);
}

/**
 * Etapa "Motor de Insights": endpoint real (motor determinístico, sem IA),
 * substitui o mock anterior. Exige a mesma sessão autenticada.
 * @param {{range?:string, start?:string, end?:string}} rangeQuery
 */
export function fetchInsightsEngine(rangeQuery = { range: '30d' }) {
  return authedFetch(`/.netlify/functions/analytics-insights?${qs(rangeQuery)}`);
}
