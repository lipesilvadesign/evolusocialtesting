import { authedFetch } from './apiClient.js';

export function fetchHealth() {
  return authedFetch('/.netlify/functions/health');
}

export async function fetchAuditLog() {
  const { entries } = await authedFetch('/.netlify/functions/system?resource=audit');
  return entries;
}
