import { getAccessToken } from './auth.js';

/**
 * @param {string} path
 * @param {RequestInit} [opts]
 */
export async function authedFetch(path, opts = {}) {
  const token = await getAccessToken();
  if (!token) throw new Error('Sessão expirada. Faça login novamente.');

  const res = await fetch(path, {
    ...opts,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(opts.headers || {}),
    },
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Falha na requisição (${res.status}).`);
  return data;
}
