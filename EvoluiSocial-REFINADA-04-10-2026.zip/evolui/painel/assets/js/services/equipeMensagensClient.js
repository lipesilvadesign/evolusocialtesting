import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/equipe-mensagens';

export async function listarMensagens() {
  const { mensagens } = await authedFetch(ENDPOINT);
  return mensagens;
}

/**
 * @param {string} texto
 * @param {string|null} [leadId] Compartilha a mensagem ligada a um cliente
 *   (mostra um link "Ver cliente" no mural) — opcional.
 */
export async function enviarMensagem(texto, leadId = null) {
  const { mensagem } = await authedFetch(ENDPOINT, { method: 'POST', body: JSON.stringify({ mensagem: texto, leadId }) });
  return mensagem;
}

/** Admin only (RLS garante) — moderação. */
export async function excluirMensagem(id) {
  await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}
