/**
 * Cliente de Conteúdo usado pelo painel — chama a Function content-overview,
 * que lê a tabela site_content real (mesma fonte do admin.html atual).
 */
export async function fetchContentOverview() {
  const res = await fetch('/.netlify/functions/content-overview', {
    headers: { Accept: 'application/json' },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Falha ao carregar o resumo de conteúdo.');
  return data;
}
