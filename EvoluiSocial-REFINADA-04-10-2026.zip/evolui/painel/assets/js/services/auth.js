/**
 * Autenticação do painel.
 * Reaproveita o MESMO Supabase Auth já usado em admin.html — mesmo projeto
 * Supabase, mesma chave pública, mesmas contas cadastradas por você. Não é
 * um sistema de login novo/paralelo: uma conta que já entra no admin.html
 * também entra aqui.
 *
 * RBAC (admin/prospeccao/design) — IMPLEMENTADO (PROMPT 4). `role` vem de
 * admin_funcionarios (ver SQL_PENDENTE_equipe_permissoes.sql), buscado
 * abaixo com o token normal da sessão — a mesma RLS que protege o resto do
 * banco também decide o que esta consulta pode ver. Uma conta autenticada
 * sem linha em admin_funcionarios (ou com `ativo=false`) recebe
 * role='sem_acesso': consegue logar, mas rbac.js barra o resto.
 */

const SUPABASE_URL = 'https://aligftypgtzlymmditeo.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_lLKYguXwi6isaw1C4X5uiA_25-MT7ym';

let client = null;

function getClient() {
  if (!client) {
    if (!window.supabase || typeof window.supabase.createClient !== 'function') {
      throw new Error('SDK do Supabase não carregado (assets/js/supabase.efef2daf49.js).');
    }
    client = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  }
  return client;
}

/**
 * Exposto pra quem precisa do MESMO client (mesma sessão) além de
 * autenticação — hoje só o indicador "digitando…" do mural (Realtime
 * Broadcast, sem tabela nova, ver comunicacao.js). Nunca cria um client
 * paralelo — Realtime Broadcast autenticado depende de ser a mesma sessão.
 */
export function getSupabaseClient() {
  return getClient();
}

/** @returns {Promise<import('../../../../netlify/functions/_lib/types').AdminUser|null>} */
export async function getCurrentUser() {
  const { data, error } = await getClient().auth.getSession();
  if (error || !data.session) return null;
  const { user } = data.session;
  const linha = await buscarPropriaLinha(data.session.access_token);
  return {
    id: user.id,
    email: user.email,
    nome: (linha && linha.nome) || (user.user_metadata && user.user_metadata.nome) || null,
    fotoUrl: (linha && linha.foto_url) || null,
    role: (linha && linha.role) || 'sem_acesso', // conta autenticada mas sem linha em admin_funcionarios (ou desativada) — ver rbac.js
  };
}

/**
 * Busca a PRÓPRIA linha em admin_funcionarios (role, nome, foto). Usa a
 * mesma RLS de sempre (não uma chave privilegiada) — a policy
 * "select_propria_linha_ou_admin" é o que garante que isto só devolve a
 * linha da própria pessoa (a menos que ela seja admin, aí a policy libera
 * qualquer linha, mas aqui só pedimos a própria mesmo assim).
 * @param {string} accessToken
 * @returns {Promise<{role:string, nome:string, foto_url:string|null}|null>} null = sem linha cadastrada, ou desativado
 */
async function buscarPropriaLinha(accessToken) {
  const userId = await obterUserId();
  if (!userId) return null;
  // Tenta com foto_url (coluna nova, ver SQL_PENDENTE_ponto_metas.sql).
  // Se a migração ainda não tiver sido aplicada em produção, essa coluna
  // não existe e o PostgREST recusa a consulta INTEIRA (400) — sem o
  // fallback abaixo, isso derrubaria login de TODO MUNDO (mesmo problema
  // de "Acesso não configurado" já visto neste projeto), só por causa de
  // uma coluna cosmética. Por isso: se a consulta com foto_url falhar,
  // tenta de novo sem ela antes de desistir.
  const comFoto = await consultarLinha(accessToken, userId, 'role,ativo,nome,foto_url');
  if (comFoto !== undefined) return comFoto;
  const semFoto = await consultarLinha(accessToken, userId, 'role,ativo,nome');
  return semFoto === undefined ? null : semFoto;
}

async function obterUserId() {
  const { data: sessionData } = await getClient().auth.getSession();
  return sessionData.session ? sessionData.session.user.id : null;
}

/** @returns {Promise<object|null|undefined>} undefined = a consulta em si falhou (tentar outro select); null = sem acesso de verdade */
async function consultarLinha(accessToken, userId, select) {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/admin_funcionarios?id=eq.${userId}&select=${select}`, {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${accessToken}` },
    });
    if (!res.ok) return undefined;
    const rows = await res.json();
    if (!rows[0] || !rows[0].ativo) return null;
    return rows[0];
  } catch (err) {
    return undefined;
  }
}

/** @returns {Promise<{ error: string|null }>} */
export async function signIn(email, password) {
  const { error } = await getClient().auth.signInWithPassword({ email, password });
  return { error: error ? error.message : null };
}

export async function signOut() {
  await getClient().auth.signOut();
}

export function onAuthChange(callback) {
  const { data } = getClient().auth.onAuthStateChange(() => callback());
  return data.subscription;
}

/**
 * Token de acesso da sessão atual — usado pelo apiClient pra autenticar
 * chamadas às Netlify Functions de conteúdo/configurações (etapa CMS).
 * As Functions validam esse mesmo token direto contra o Supabase Auth
 * (ver netlify/functions/_lib/config/authGuard.js) — a interface nunca é
 * a única barreira de autorização.
 * @returns {Promise<string|null>}
 */
export async function getAccessToken() {
  const { data } = await getClient().auth.getSession();
  return data.session ? data.session.access_token : null;
}
