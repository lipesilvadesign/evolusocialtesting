/** Próxima ação / tarefas do lead e histórico de score (Function prospeccao-tarefas). */
import { authedFetch } from './apiClient.js';

const API = '/.netlify/functions/prospeccao-tarefas';
export const carregarOperacao = (leadId) => authedFetch(`${API}?leadId=${encodeURIComponent(leadId)}`);
export const criarTarefa = (dados) => authedFetch(API, { method: 'POST', body: JSON.stringify(dados) }).then((r) => r.tarefa);
export const mudarTarefa = (id, status) => authedFetch(`${API}?id=${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ status }) }).then((r) => r.tarefa);
