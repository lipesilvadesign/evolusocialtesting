import { authedFetch } from './apiClient.js';

/**
 * @param {{ empresa: string, setor?: string, briefing?: object, metricas?: object[] }} contexto
 * @returns {Promise<object>} rascunho — nunca salvo sozinho, quem chama decide se aceita
 */
export async function gerarRascunhoDiagnosticoIA(contexto) {
  const { rascunho } = await authedFetch('/.netlify/functions/diagnostico-ia', {
    method: 'POST',
    body: JSON.stringify(contexto),
  });
  return rascunho;
}
