/**
 * Cliente do Lead Capture Engine (Functions captacao, captacao-worker-background,
 * prospeccao-taxonomia). Toda regra (validação, limites, permissão) é do
 * servidor/banco — aqui só chamadas.
 */
import { authedFetch } from './apiClient.js';

const API = '/.netlify/functions/captacao';
let taxonomiaCache = null;

export async function carregarTaxonomia() {
  if (!taxonomiaCache) taxonomiaCache = authedFetch('/.netlify/functions/prospeccao-taxonomia').catch((err) => { taxonomiaCache = null; throw err; });
  return taxonomiaCache;
}

export const listarJobs = () => authedFetch(API).then((r) => r.jobs);
/** Painel técnico (só admin). */
export const diagnosticoTecnico = () => authedFetch(`${API}?diagnostico=1`);
/** Centro de uma cidade (servidor: Nominatim/Photon com cache de 30 dias). */
export const geocodificarCidade = (cidade) => authedFetch(`${API}?geocodificar=${encodeURIComponent(cidade)}`).then((r) => r.coords);
export const buscarJob = (id) => authedFetch(`${API}?id=${encodeURIComponent(id)}`).then((r) => r.job);
export function listarItens(id, { status, pagina = 1, porPagina = 50 } = {}) {
  const p = new URLSearchParams({ id, itens: '1', pagina: String(pagina), por_pagina: String(porPagina) });
  if (status) p.set('status', status);
  return authedFetch(`${API}?${p}`);
}

const acao = (nome, corpo) => authedFetch(`${API}?acao=${nome}`, { method: 'POST', body: JSON.stringify(corpo || {}) });

/** Cria o job (validado no servidor) e dispara o worker em segundo plano. */
export async function iniciarCaptacao(dados) {
  const { job } = await acao('iniciar', dados);
  await dispararWorker(job.id);
  return job;
}
export async function dispararWorker(jobId) {
  // Background Function: responde 202 na hora. A validação já foi feita em "iniciar".
  await authedFetch('/.netlify/functions/captacao-worker-background', { method: 'POST', body: JSON.stringify({ jobId }) }).catch(() => {});
}
export const importarPrevia = (arquivoBase64, delimitador) => acao('importar-previa', { arquivoBase64, delimitador });
export const importar = (dados) => acao('importar', dados);
export const aprovar = (dados) => acao('aprovar', dados);
export const descartar = (ids, motivo) => acao('descartar', { ids, motivo });
export const marcarDuplicado = (id, leadId) => acao('marcar-duplicado', { id, leadId });
export const mesclar = (id, leadId) => acao('mesclar', { id, leadId });
export const cancelar = (id) => acao('cancelar', { id });
export const revisarInbound = () => acao('inbound', {});

/** Arquivo → base64 (sem o prefixo data:). */
export function arquivoParaBase64(arquivo) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(',')[1] || '');
    r.onerror = () => reject(new Error('Não consegui ler o arquivo.'));
    r.readAsDataURL(arquivo);
  });
}
