import { authedFetch } from './apiClient.js';

// Posts/Páginas usam a Function content-collection (tabelas próprias).
// Projetos/Serviços usam a Function content-array (dentro de site_content).
const COLLECTION_TYPES = new Set(['posts', 'paginas']);
const ARRAY_TYPES = new Set(['projetos', 'servicos', 'parceiros']);

function endpointFor(type) {
  if (COLLECTION_TYPES.has(type)) return '/.netlify/functions/content-collection';
  if (ARRAY_TYPES.has(type)) return '/.netlify/functions/content-array';
  throw new Error(`Tipo de conteúdo desconhecido: ${type}`);
}

/** @returns {Promise<object[]>} */
export async function listContent(type) {
  const { items } = await authedFetch(`${endpointFor(type)}?type=${type}`);
  return items;
}

/** @returns {Promise<object>} */
export async function createContent(type, payload) {
  const { item } = await authedFetch(`${endpointFor(type)}?type=${type}`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  return item;
}

/** @returns {Promise<object>} */
export async function updateContent(type, id, payload) {
  const { item } = await authedFetch(`${endpointFor(type)}?type=${type}&id=${encodeURIComponent(id)}`, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
  return item;
}

export async function deleteContent(type, id) {
  await authedFetch(`${endpointFor(type)}?type=${type}&id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}
