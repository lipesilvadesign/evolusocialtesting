import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/prospeccao';

/**
 * Lista paginada com filtros NO SERVIDOR (30/09). Nunca carrega a tabela inteira.
 * @param {Record<string,string|number>} [filtros] q, setor, cidade, status, prioridade, temperatura, faixa,
 *   fonte, metodo, campanha, oportunidade, responsavel, criado_de, arquivados, ordem, pagina, por_pagina...
 * @param {{ signal?: AbortSignal }} [opts]
 * @returns {Promise<{ leads: object[], total: number|null, pagina: number, porPagina: number }>}
 */
export async function fetchLeads(filtros = {}, opts = {}) {
  const p = new URLSearchParams();
  Object.entries(filtros).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '' && v !== 'todos') p.set(k, String(v)); });
  return authedFetch(`${ENDPOINT}${p.toString() ? `?${p}` : ''}`, { signal: opts.signal });
}

/**
 * Todas as páginas (até `max`) — só para telas que ainda precisam da lista
 * completa (Clientes, Financeiro). Páginas de 100, uma de cada vez.
 * @returns {Promise<object[]>}
 */
export async function fetchTodosLeads(filtros = {}, max = 2000) {
  const todos = [];
  for (let pagina = 1; todos.length < max; pagina++) {
    const r = await fetchLeads({ ordem: 'recentes', ...filtros, pagina, por_pagina: 100 });
    todos.push(...r.leads);
    if (r.leads.length < 100 || (r.total !== null && todos.length >= r.total)) break;
  }
  return todos.slice(0, max);
}

export async function fetchLead(id) {
  const { lead } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`);
  return lead;
}

const acaoLead = (acao, corpo) => authedFetch(`${ENDPOINT}?acao=${acao}`, { method: 'POST', body: JSON.stringify(corpo) });
export const arquivarLeads = (ids, motivo, obs) => acaoLead('arquivar', { ids, motivo, obs });
export const restaurarLeads = (ids) => acaoLead('restaurar', { ids });
export const mesclarLeads = (manterId, absorverId) => acaoLead('mesclar', { manterId, absorverId });
export const converterInbound = (tipo, id) => acaoLead('converter', { tipo, id }).then((r) => r.resultado);
export const recalcularScores = () => acaoLead('recalcular', {});

/** @param {{ empresa: string, setor?: string, telefone?: string, email?: string, endereco?: string, avaliacaoGoogle?: string, motivo?: string, canalSugerido?: string, observacoes?: string }} payload */
export async function createLead(payload) {
  const { lead } = await authedFetch(ENDPOINT, { method: 'POST', body: JSON.stringify(payload) });
  return lead;
}

/** Como createLead, mas devolve { duplicados } quando o servidor encontra lead parecido (HTTP 409). */
export async function createLeadComChecagem(payload) {
  const { getAccessToken } = await import('./auth.js');
  const token = await getAccessToken();
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 409 && Array.isArray(data.duplicados)) return { duplicados: data.duplicados };
  if (!res.ok) throw new Error(data.error || `Falha na requisição (${res.status}).`);
  return { lead: data.lead };
}

/** @param {string} id @param {object} payload campos a atualizar */
export async function updateLead(id, payload) {
  const { lead } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify(payload),
  });
  return lead;
}

export async function deleteLead(id) {
  await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}

/**
 * Botão "Atualizar" — busca empresas novas via OpenStreetMap (gratuito, sem
 * chave de API) nas cidades e ramo escolhidos no popup. Background Function:
 * o jobId é gerado AQUI (no navegador) e enviado no corpo, pra já poder
 * consultar o progresso (consultarStatusBusca) antes mesmo da function
 * terminar de criar a linha de status.
 * @param {string[]} cidades
 * @param {string} ramo
 * @returns {Promise<string>} o jobId gerado, pra usar no polling
 */
export async function buscarNovasEmpresas(cidades, ramo) {
  const jobId = crypto.randomUUID();
  await authedFetch('/.netlify/functions/prospeccao-buscar-empresas-background', {
    method: 'POST',
    body: JSON.stringify({ jobId, cidades, ramo }),
  });
  return jobId;
}

/**
 * Consulta o progresso de uma busca em andamento (polling). `busca` vem
 * `null` se a Background Function ainda não criou a linha (normal nos
 * primeiros 1-2 segundos) — a interface deve só tentar de novo.
 * @param {string} jobId
 * @returns {Promise<object|null>}
 */
export async function consultarStatusBusca(jobId) {
  const { busca } = await authedFetch(`/.netlify/functions/prospeccao-busca-status?id=${encodeURIComponent(jobId)}`);
  return busca;
}

/**
 * Dispara o envio de e-mail em segundo plano (Background Function). O jobId
 * é gerado AQUI (no navegador) — o painel usa ele pra consultar o progresso
 * (consultarStatusEnvio) lead por lead, sem depender de notificação.
 * @param {string[]} leadIds
 * @param {string} assunto modelo com {{empresa}}, {{setor}}, {{cidade}}
 * @param {string} corpo modelo com {{empresa}}, {{setor}}, {{cidade}}
 * @returns {Promise<string>} o jobId gerado, pra usar no polling
 */
export async function enviarEmails(leadIds, assunto, corpo) {
  const jobId = crypto.randomUUID();
  await authedFetch('/.netlify/functions/prospeccao-enviar-email-background', {
    method: 'POST',
    body: JSON.stringify({ jobId, leadIds, assunto, corpo }),
  });
  return jobId;
}

/**
 * Consulta o progresso de um envio em andamento (polling). `envio` vem
 * `null` se a Background Function ainda não criou a linha (normal nos
 * primeiros 1-2 segundos).
 * @param {string} jobId
 * @returns {Promise<object|null>}
 */
export async function consultarStatusEnvio(jobId) {
  const { envio } = await authedFetch(`/.netlify/functions/prospeccao-envio-status?id=${encodeURIComponent(jobId)}`);
  return envio;
}

/**
 * Consulta o relatório da Prospecção — buscas, envios e leads no período.
 * @param {string} periodo 'hoje' | 'semana' | 'mes' | 'tudo'
 */
export async function buscarRelatorio(periodo) {
  return authedFetch(`/.netlify/functions/prospeccao-relatorio?periodo=${encodeURIComponent(periodo)}`);
}

/** @param {string} leadId */
export async function listarContatos(leadId) {
  const { contatos } = await authedFetch(`/.netlify/functions/prospeccao-contatos?leadId=${encodeURIComponent(leadId)}`);
  return contatos;
}

/** @param {{ leadId: string, nome: string, cargo?: string, email?: string, whatsapp?: string, linkedin?: string, principal?: boolean }} dados */
export async function criarContato(dados) {
  const { contato } = await authedFetch('/.netlify/functions/prospeccao-contatos', { method: 'POST', body: JSON.stringify(dados) });
  return contato;
}

/** @param {string} id */
export async function removerContato(id) {
  await authedFetch(`/.netlify/functions/prospeccao-contatos?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}

/** @param {string} leadId */
export async function listarAtividades(leadId) {
  const { atividades } = await authedFetch(`/.netlify/functions/prospeccao-atividades?leadId=${encodeURIComponent(leadId)}`);
  return atividades;
}

/** @param {{ leadId: string, tipo: string, descricao?: string, data?: string, proximaEm?: string }} dados */
export async function criarAtividade(dados) {
  const { atividade } = await authedFetch('/.netlify/functions/prospeccao-atividades', { method: 'POST', body: JSON.stringify(dados) });
  return atividade;
}

/** @param {{ email?: string, telefone?: string, origemId?: string, motivo?: string }} dados */
export async function registrarOptout(dados) {
  const { registro } = await authedFetch('/.netlify/functions/prospeccao-optout', { method: 'POST', body: JSON.stringify(dados) });
  return registro;
}
