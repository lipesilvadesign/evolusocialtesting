/**
 * Banco de imagens do EvoluiSocial no painel (03/10/2026) — admin-only.
 * Tabelas: evolui_tax_termos, evolui_imagens, evolui_imagem_usos; RPC evolui_imagens_lacunas;
 * bucket público "evolui-imagens". A autorização é toda no banco (RLS): leitura authenticated, escrita só admin.
 */
import { getSupabaseClient } from './auth.js';

export const BUCKET = 'evolui-imagens';
export const MAX_BYTES = 3 * 1024 * 1024;
export const MAX_ENTRADA_BYTES = 30 * 1024 * 1024; // limite do arquivo ORIGINAL, só para não travar o navegador
export const MAX_LADO = 1600;
export const TIPOS_ACEITOS = ['image/jpeg', 'image/png', 'image/webp'];
export const STATUS = ['rascunho', 'ativa', 'revisao', 'arquivada'];
export const ORIGENS = ['propria', 'licenciada', 'banco_gratuito', 'cliente_autorizado', 'outra'];

const db = () => getSupabaseClient();
const msgErro = (error, padrao) => {
  if (!error) return padrao;
  if (error.code === '23505') return 'Já existe um registro com esse valor. Escolha outro.';
  if (error.code === '42501' || /row-level security|permission denied/i.test(error.message || '')) return 'Sem permissão: só administradores podem fazer isso.';
  if (/licen/i.test(error.message || '') && /ativa/i.test(error.message || '')) return 'Para ativar a imagem, preencha a licença.';
  return error.message || padrao;
};
const falha = (error, padrao) => { throw new Error(msgErro(error, padrao)); };

// ------------------------------------------------------------------ utilidades
export function semAcento(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, ''); }
export function slug(s) { return semAcento(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''); }
/** Chave de termo: minúscula, sem acento, com sublinhado (ex.: "Saúde e Bem-estar" → saude_e_bem_estar). */
export function chaveDe(rotulo) { return semAcento(rotulo).toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, ''); }
function sufixo() { return Math.random().toString(36).slice(2, 8).padEnd(6, '0'); }

export function urlImagem(arquivo) {
  if (!arquivo) return '';
  return db().storage.from(BUCKET).getPublicUrl(arquivo).data?.publicUrl || '';
}

// ------------------------------------------------------------------ processamento no navegador
function carregarBitmap(file) {
  if (typeof createImageBitmap === 'function') {
    return createImageBitmap(file).catch(() => carregarImg(file));
  }
  return carregarImg(file);
}
function carregarImg(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('imagem ilegível')); };
    img.src = url;
  });
}
function paraBlob(canvas, tipo, q) { return new Promise((res) => canvas.toBlob(res, tipo, q)); }

/** Valida, reduz para no máximo 1600 px no maior lado e converte para WebP (fallback JPEG), qualidade ~0.82. */
export async function prepararImagem(file) {
  if (!file) throw new Error('Nenhum arquivo selecionado.');
  const nome = file.name || 'imagem';
  if (!TIPOS_ACEITOS.includes(file.type)) throw new Error(`"${nome}": formato não aceito. Use JPG, PNG ou WebP.`);
  if (file.size > MAX_ENTRADA_BYTES) throw new Error(`"${nome}": arquivo grande demais (${(file.size / 1048576).toFixed(1)} MB). Reduza antes de enviar.`);
  let bmp;
  try { bmp = await carregarBitmap(file); } catch { throw new Error(`"${nome}": não foi possível ler a imagem. O arquivo pode estar corrompido.`); }
  const w0 = bmp.width, h0 = bmp.height;
  if (!w0 || !h0) throw new Error(`"${nome}": imagem sem dimensões válidas.`);
  const escala = Math.min(1, MAX_LADO / Math.max(w0, h0));
  const largura = Math.max(1, Math.round(w0 * escala)), altura = Math.max(1, Math.round(h0 * escala));
  const canvas = document.createElement('canvas');
  canvas.width = largura; canvas.height = altura;
  const ctx = canvas.getContext('2d');
  let blob = await paraBlob(canvas, 'image/webp', 0.82); // teste de suporte: navegador sem WebP devolve PNG
  const webp = blob && blob.type === 'image/webp';
  if (!webp) { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, largura, altura); } // JPEG não tem transparência
  ctx.drawImage(bmp, 0, 0, largura, altura);
  if (bmp.close) bmp.close();
  blob = await paraBlob(canvas, webp ? 'image/webp' : 'image/jpeg', 0.82);
  if (!blob) throw new Error(`"${nome}": falha ao converter a imagem.`);
  if (blob.size > MAX_BYTES) throw new Error(`"${nome}": mesmo reduzida, a imagem passa de 3 MB (${(blob.size / 1048576).toFixed(1)} MB). Use uma imagem mais simples ou menor.`);
  return { blob, largura, altura, peso: blob.size, ext: webp ? 'webp' : 'jpg', tipo: blob.type };
}

export function nomeSeguro(nomeOriginal, ext) {
  const base = slug(String(nomeOriginal || 'imagem').replace(/\.[^.]+$/, '')).slice(0, 60) || 'imagem';
  const d = new Date();
  const pasta = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  return `${pasta}/${base}-${sufixo()}.${ext}`;
}

// ------------------------------------------------------------------ imagens
const COLS = 'id,arquivo,titulo,texto_alternativo,largura,altura,peso,area_id,subramo_id,tema_id,tags,plataformas,formatos,tipos_card,origem,licenca,autor,url_fonte,status,usos,criado_em,criado_por,atualizado_em';

/** @param {{status?:string, areaId?:string, temaId?:string, busca?:string, limite?:number}} f */
export async function listarImagens({ status, areaId, temaId, busca, limite = 300 } = {}) {
  let q = db().from('evolui_imagens').select(COLS).order('criado_em', { ascending: false }).limit(limite);
  if (status) q = q.eq('status', status);
  if (areaId) q = q.eq('area_id', areaId);
  if (temaId) q = q.eq('tema_id', temaId);
  const t = String(busca || '').trim().replace(/[,()%*\\"]/g, ' ').replace(/\s+/g, ' ').trim();
  if (t) q = q.or(`titulo.ilike.%${t}%,arquivo.ilike.%${t}%,autor.ilike.%${t}%,tags.cs.{${slug(t)}}`);
  const { data, error } = await q;
  if (error) falha(error, 'Não foi possível listar as imagens.');
  return data || [];
}

export async function contarPorStatus() {
  const { data, error } = await db().from('evolui_imagens').select('status,area_id,subramo_id,tema_id').limit(20000);
  if (error) falha(error, 'Não foi possível contar as imagens.');
  const porStatus = { rascunho: 0, ativa: 0, revisao: 0, arquivada: 0 };
  const ativasPorNo = {}, totalPorNo = {};
  for (const r of data || []) {
    if (r.status in porStatus) porStatus[r.status]++;
    for (const id of new Set([r.area_id, r.subramo_id, r.tema_id].filter(Boolean))) {
      totalPorNo[id] = (totalPorNo[id] || 0) + 1;
      if (r.status === 'ativa') ativasPorNo[id] = (ativasPorNo[id] || 0) + 1;
    }
  }
  return { total: (data || []).length, porStatus, ativasPorNo, totalPorNo };
}

/** Faz upload (já reduzido/convertido) e cria a linha. Se o insert falhar, remove o arquivo enviado. */
export async function criarImagem(file, campos = {}) {
  const p = await prepararImagem(file);
  const arquivo = nomeSeguro(file.name, p.ext);
  const up = await db().storage.from(BUCKET).upload(arquivo, p.blob, { contentType: p.tipo, cacheControl: '31536000', upsert: false });
  if (up.error) falha(up.error, `Falha ao enviar "${file.name}".`);
  const linha = {
    arquivo, largura: p.largura, altura: p.altura, peso: p.peso, status: 'rascunho', origem: 'propria',
    tags: [], plataformas: [], formatos: [], tipos_card: [], ...campos,
  };
  const { data: u } = await db().auth.getUser().catch(() => ({ data: null }));
  if (u?.user?.id && !linha.criado_por) linha.criado_por = u.user.id;
  const { data, error } = await db().from('evolui_imagens').insert(linha).select(COLS).single();
  if (error) {
    await db().storage.from(BUCKET).remove([arquivo]).catch(() => {});
    falha(error, `Falha ao registrar "${file.name}".`);
  }
  return data;
}

export async function atualizarImagem(id, campos) {
  const { data, error } = await db().from('evolui_imagens').update({ ...campos, atualizado_em: new Date().toISOString() }).eq('id', id).select(COLS).single();
  if (error) falha(error, 'Não foi possível salvar a imagem.');
  return data;
}
export const mudarStatusImagem = (id, status) => atualizarImagem(id, { status });
export const arquivarImagem = (id) => mudarStatusImagem(id, 'arquivada');

/** Apaga a linha e depois o arquivo (se a linha não puder ser apagada, o arquivo fica intacto). */
export async function apagarImagem(img) {
  const { error } = await db().from('evolui_imagens').delete().eq('id', img.id);
  if (error) falha(error, 'Não foi possível apagar a imagem.');
  const r = await db().storage.from(BUCKET).remove([img.arquivo]);
  if (r.error) return { arquivoRemovido: false };
  return { arquivoRemovido: true };
}

export async function usosDaImagem(imagemId, limite = 20) {
  const { data, error } = await db().from('evolui_imagem_usos').select('tipo_card,tema,criado_em').eq('imagem_id', imagemId).order('criado_em', { ascending: false }).limit(limite);
  if (error) falha(error, 'Não foi possível carregar os usos.');
  return data || [];
}

export async function lacunas(dias = 30) {
  const { data, error } = await db().rpc('evolui_imagens_lacunas', { dias });
  if (error) falha(error, 'Não foi possível carregar as lacunas.');
  return data || [];
}

// ------------------------------------------------------------------ taxonomia
export async function listarTermos({ incluirInativos = true } = {}) {
  let q = db().from('evolui_tax_termos').select('id,tipo,pai_id,chave,rotulo,sinonimos,ativo,criado_em').order('rotulo', { ascending: true }).limit(5000);
  if (!incluirInativos) q = q.eq('ativo', true);
  const { data, error } = await q;
  if (error) falha(error, 'Não foi possível carregar a taxonomia.');
  return data || [];
}
export async function criarTermo({ tipo, paiId = null, rotulo, chave, sinonimos = [] }) {
  const { data, error } = await db().from('evolui_tax_termos').insert({ tipo, pai_id: paiId, rotulo, chave: chave || chaveDe(rotulo), sinonimos, ativo: true }).select().single();
  if (error) falha(error, 'Não foi possível criar o termo.');
  return data;
}
export async function atualizarTermo(id, campos) {
  const { data, error } = await db().from('evolui_tax_termos').update(campos).eq('id', id).select().single();
  if (error) falha(error, 'Não foi possível salvar o termo.');
  return data;
}
export const definirTermoAtivo = (id, ativo) => atualizarTermo(id, { ativo });
