import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/funcionarios';

/** @returns {Promise<object[]>} admin vê todos; os demais, só a própria linha (decidido pela RLS, não aqui) */
export async function listarFuncionarios() {
  const { funcionarios } = await authedFetch(ENDPOINT);
  return funcionarios;
}

/**
 * @param {string} id @param {{ nome?: string, role?: string, ativo?: boolean, fotoUrl?: string, tempoExperiencia?: string, funcoes?: string, genero?: string, biografia?: string }} payload
 * Quem pode alterar o quê é decidido no banco: dono da linha edita
 * nome/biografia/fotoUrl/tempoExperiencia/funcoes/genero (própria linha);
 * role/ativo continuam só-admin mesmo se enviados aqui (o banco ignora).
 */
export async function atualizarFuncionario(id, payload) {
  const { funcionario } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify(payload),
  });
  return funcionario;
}

/** Gera uma nova senha temporária pra uma conta já existente — devolvida uma única vez. Admin only (RLS/Function garantem). */
export async function resetarSenhaFuncionario(funcionarioId) {
  const { senhaGerada } = await authedFetch('/.netlify/functions/funcionarios-conta', {
    method: 'POST',
    body: JSON.stringify({ acao: 'resetar_senha', funcionarioId }),
  });
  return senhaGerada;
}

/** Exclui a conta de verdade (Supabase Auth) — cascade apaga admin_funcionarios e tudo ligado a ela. Irreversível. Admin only. */
export async function excluirFuncionario(funcionarioId) {
  await authedFetch('/.netlify/functions/funcionarios-conta', {
    method: 'POST',
    body: JSON.stringify({ acao: 'excluir', funcionarioId }),
  });
}

/**
 * @param {{ email: string, nome: string, role: string, modo?: 'convite_email'|'gerar_senha' }} dados
 * @returns {Promise<{ funcionario: object, senhaGerada: string|null }>}
 */
export async function convidarFuncionario(dados) {
  return authedFetch('/.netlify/functions/funcionarios-convidar', {
    method: 'POST',
    body: JSON.stringify(dados),
  });
}
