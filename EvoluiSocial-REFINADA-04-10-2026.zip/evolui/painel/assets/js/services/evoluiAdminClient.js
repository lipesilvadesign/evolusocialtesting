/**
 * EvoluiSocial no painel (01/10/2026) — admin-only.
 * Tudo vem de funções do banco (evolui_admin_*) que conferem admin_eh_admin()
 * lá dentro: mesmo chamando direto pela API, quem não é admin recebe erro.
 * Nenhum dado de cartão passa por aqui (fica no Mercado Pago).
 */
import { getSupabaseClient } from './auth.js';

async function rpc(nome, args) {
  const { data, error } = await getSupabaseClient().rpc(nome, args || {});
  if (error) throw new Error(error.message || 'Falha ao consultar o banco.');
  return data;
}

export const resumoEvolui = (dias) => rpc('evolui_admin_resumo', { p_dias: dias });
export const usuariosEvolui = (busca) => rpc('evolui_admin_usuarios', { p_busca: busca || null, p_limite: 200 });
export const alertasEvolui = (abertos = true) => rpc('evolui_admin_alertas', { p_abertos: abertos });
export const resolverAlertaEvolui = (id, nota) => rpc('evolui_admin_resolver_alerta', { p_id: id, p_nota: nota || null });
export const definirUsuarioEvolui = (id, { plano = null, dias = null, bloqueado = null } = {}) =>
  rpc('evolui_admin_definir', { p_user: id, p_plano: plano, p_dias: dias, p_bloqueado: bloqueado });
export const rodarAgentesEvolui = () => rpc('evolui_admin_rodar_agentes');
export const financeiroEvolui = (meses = 12) => rpc('evolui_admin_financeiro', { p_meses: meses });
export const configEvolui = (chave, valor) => rpc('evolui_admin_config', { p_chave: chave, p_valor: valor });

// v5 · papéis (user/admin/owner), redefinição segura de senha e saúde da plataforma
export const plataformaEvolui = () => rpc('evolui_admin_plataforma');
export const definirPapelEvolui = (id, papel) => rpc('evolui_owner_definir_papel', { p_user: id, p_papel: papel });
/** Registra o pedido no log e, só se a conta tiver senha, dispara o e-mail oficial de redefinição do Supabase Auth.
 *  O admin nunca vê nem define a senha de ninguém. */
export async function iniciarResetEvolui(id) {
  const info = await rpc('evolui_admin_iniciar_reset', { p_user: id });
  if (!info?.tem_senha) return { enviado: false, ...info };
  const { error } = await getSupabaseClient().auth.resetPasswordForEmail(info.email, { redirectTo: `${location.origin}/evoluisocial/app/` });
  if (error) throw new Error(error.message || 'Não foi possível enviar o e-mail.');
  return { enviado: true, ...info };
}

// v6 · chaves de API (Supabase Vault). Só o proprietário. O valor nunca volta do banco: só "configurada" e os 4 últimos caracteres.
export const integracoesEvolui = () => rpc('evolui_integracoes_listar');
export const salvarIntegracaoEvolui = (chave, valor, rotulo = null, descricao = null) => rpc('evolui_integracao_salvar', { p_chave: chave, p_valor: valor, p_rotulo: rotulo, p_descricao: descricao });
export const removerIntegracaoEvolui = (chave) => rpc('evolui_integracao_remover', { p_chave: chave });
export async function testarIntegracaoEvolui(chave) {
  const { data, error } = await getSupabaseClient().functions.invoke('evolui-integracoes', { body: { acao: 'testar', chave } });
  if (error) {
    let msg = 'Não foi possível testar agora.';
    try { const j = await error.context?.json?.(); if (j?.erro) msg = j.erro; } catch { /* mantém a mensagem padrão */ }
    throw new Error(msg);
  }
  return data;
}

// v10 · Central de Repertório (só admin). Análise e gravação passam pela função evolui-repertorio;
// leitura/estatísticas pelas funções do banco (evolui_rep_*), que conferem admin lá dentro.
async function repFn(body) {
  const { data, error } = await getSupabaseClient().functions.invoke('evolui-repertorio', { body });
  if (error) {
    let msg = 'Não foi possível concluir agora.';
    try { const j = await error.context?.json?.(); if (j?.erro) msg = j.erro; } catch { /* mantém a mensagem padrão */ }
    throw new Error(msg);
  }
  return data;
}
export const adicionarRepertorio = (d) => repFn({ acao: 'adicionar', ...d });
export const excluirRepertorio = (id) => repFn({ acao: 'excluir', id });
export const ajustarRepertorio = (id, d) => repFn({ acao: 'ajustar', id, ...d });
export const statsRepertorio = () => rpc('evolui_rep_stats');
export const verRepertorio = (id) => rpc('evolui_rep_ver', { p_id: id });
export const resolverRepertorio = (tipo, id, status) => rpc('evolui_rep_resolver', { p_tipo: tipo, p_id: id, p_status: status });
export async function listarRepertorio(busca) {
  let q = getSupabaseClient().from('evolui_rep_conhecimentos')
    .select('id,titulo,fonte,assunto,tags,usos,ultimo_uso,criado_em,status').order('criado_em', { ascending: false }).limit(200);
  const t = String(busca || '').trim().replace(/[%,()]/g, ' ');
  if (t) q = q.or(`titulo.ilike.%${t}%,assunto.ilike.%${t}%,fonte.ilike.%${t}%,tags.cs.{${t.toLowerCase().replace(/\s+/g, '-')}}`);
  const { data, error } = await q;
  if (error) throw new Error(error.message || 'Falha ao consultar o repertório.');
  return data || [];
}
export async function insightsRepertorio() {
  const { data, error } = await getSupabaseClient().from('evolui_rep_insights')
    .select('id,titulo,texto,status,criado_em').order('criado_em', { ascending: false }).limit(30);
  if (error) throw new Error(error.message || 'Falha ao consultar os insights.');
  return data || [];
}
export async function conflitosRepertorio() {
  const { data, error } = await getSupabaseClient().from('evolui_rep_conflitos')
    .select('id,descricao,status').eq('status', 'aberto').limit(30);
  if (error) throw new Error(error.message || 'Falha ao consultar os conflitos.');
  return data || [];
}

// Solicitações de acesso (Social Media etc.): usuário pede, admin aprova, vira permissão.
export const solicitacoesEvolui = (status = 'pendente') => rpc('evolui_admin_solicitacoes', { p_status: status });
export const decidirSolicitacaoEvolui = (id, aprovar, resposta) => rpc('evolui_admin_decidir_solicitacao', { p_id: id, p_aprovar: aprovar, p_resposta: resposta || null });
export const revogarPermissaoEvolui = (user, recurso) => rpc('evolui_admin_revogar_permissao', { p_user: user, p_recurso: recurso });
