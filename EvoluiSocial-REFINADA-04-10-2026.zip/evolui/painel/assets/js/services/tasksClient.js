import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/tasks';

export async function fetchTasks() {
  const { tasks } = await authedFetch(ENDPOINT);
  return tasks;
}

/** @param {{ titulo: string, descricao?: string, origemTipo?: string, origemReferencia?: object, prioridade?: string }} payload */
export async function createTask(payload) {
  const { task } = await authedFetch(ENDPOINT, { method: 'POST', body: JSON.stringify(payload) });
  return task;
}

/** @param {'TODO'|'IN_PROGRESS'|'DONE'} status */
export async function updateTaskStatus(id, status) {
  const { task } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
  return task;
}

export async function deleteTask(id) {
  await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}
