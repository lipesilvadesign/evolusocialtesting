/**
 * Exportar/importar leads em CSV — fluxo manual de enriquecimento (ex:
 * preencher CNPJ/porte pesquisando no CNPJ.ws fora do sistema), sem
 * integração automática com API externa nenhuma. Módulo puro, sem DOM,
 * pra poder testar isoladamente (ver tests/csv.test.js, carregado via
 * dynamic import a partir de um teste Node).
 */

// Ordem fixa das colunas — export e import usam exatamente a mesma lista,
// nessa mesma ordem, pra o round-trip (exportar → editar → importar) nunca
// desalinhar coluna com campo por engano.
export const COLUNAS_CSV = [
  'id', 'empresa', 'cnpj', 'setor', 'cidade', 'telefone', 'email', 'site',
  'anos_mercado', 'porte_medio_grande', 'score', 'prioridade', 'status', 'status_lead', 'status_contato',
];

function escaparCampoCSV(valor) {
  const str = valor === null || valor === undefined ? '' : String(valor);
  // Precisa de aspas se tiver vírgula, aspas ou quebra de linha — regra padrão de CSV.
  if (/[",\n\r]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * @param {object[]} leads
 * @returns {string} conteúdo CSV completo, pronto pra virar arquivo
 */
export function leadsParaCSV(leads) {
  const linhas = [COLUNAS_CSV.join(',')];
  leads.forEach((lead) => {
    const linha = COLUNAS_CSV.map((col) => {
      if (col === 'porte_medio_grande') return lead.sinal_porte_medio_grande ? 'Sim' : 'Não';
      return escaparCampoCSV(lead[col]);
    });
    linhas.push(linha.join(','));
  });
  // \r\n — Excel (muito usado pra editar essas planilhas no Brasil) espera isso; \n sozinho
  // às vezes quebra a visualização de linha em algumas versões do Excel no Windows.
  return linhas.join('\r\n');
}

/**
 * Parser de CSV simples (sem biblioteca) — cobre o caso que geramos
 * (aspas duplicadas escapando aspas, vírgula/quebra de linha dentro de
 * campo com aspas). Não cobre encoding exótico nem delimitador diferente
 * de vírgula — suficiente pro round-trip export→import deste fluxo.
 * @param {string} texto
 * @returns {string[][]} linhas, cada uma um array de campos (inclui o cabeçalho como primeira linha)
 */
export function parseCSV(texto) {
  const linhas = [];
  let campoAtual = '';
  let linhaAtual = [];
  let dentroDeAspas = false;
  const normalizado = texto.replace(/\r\n/g, '\n');

  for (let i = 0; i < normalizado.length; i++) {
    const char = normalizado[i];
    if (dentroDeAspas) {
      if (char === '"') {
        if (normalizado[i + 1] === '"') { campoAtual += '"'; i++; }
        else dentroDeAspas = false;
      } else {
        campoAtual += char;
      }
    } else if (char === '"') {
      dentroDeAspas = true;
    } else if (char === ',') {
      linhaAtual.push(campoAtual);
      campoAtual = '';
    } else if (char === '\n') {
      linhaAtual.push(campoAtual);
      linhas.push(linhaAtual);
      linhaAtual = [];
      campoAtual = '';
    } else {
      campoAtual += char;
    }
  }
  if (campoAtual !== '' || linhaAtual.length > 0) {
    linhaAtual.push(campoAtual);
    linhas.push(linhaAtual);
  }
  return linhas.filter((l) => !(l.length === 1 && l[0] === ''));
}

/**
 * Converte as linhas parseadas de volta em objetos de atualização parcial
 * de lead, pra mandar pra updateLead(id, payload) um por um. Só inclui no
 * payload os campos que realmente mudaram — CSV reexportado sem edição
 * nenhuma não deveria gerar nenhuma escrita.
 * @param {string[][]} linhas resultado de parseCSV (COM o cabeçalho na primeira linha)
 * @param {object[]} leadsAtuais pra comparar "mudou ou não" antes de mandar update
 * @returns {Array<{ id: string, empresa: string, payload: object }>}
 */
export function csvParaAtualizacoes(linhas, leadsAtuais) {
  if (!linhas.length) return [];
  const cabecalho = linhas[0];
  const idxOf = (col) => cabecalho.indexOf(col);
  const idxId = idxOf('id');
  if (idxId === -1) throw new Error('CSV inválido: coluna "id" não encontrada — não dá pra saber qual lead cada linha atualiza.');

  const porId = new Map(leadsAtuais.map((l) => [l.id, l]));
  const atualizacoes = [];

  for (let i = 1; i < linhas.length; i++) {
    const linha = linhas[i];
    const id = linha[idxId];
    const atual = porId.get(id);
    if (!atual) continue; // lead foi excluído ou o id não bate com nenhum conhecido — ignora silenciosamente essa linha

    const payload = {};
    const cnpj = idxOf('cnpj') !== -1 ? linha[idxOf('cnpj')] : undefined;
    if (cnpj !== undefined && cnpj !== (atual.cnpj || '')) payload.cnpj = cnpj;

    const anosMercado = idxOf('anos_mercado') !== -1 ? linha[idxOf('anos_mercado')] : undefined;
    if (anosMercado !== undefined && anosMercado !== (atual.anos_mercado || '')) payload.anosMercado = anosMercado;

    const setor = idxOf('setor') !== -1 ? linha[idxOf('setor')] : undefined;
    if (setor !== undefined && setor !== (atual.setor || '')) payload.setor = setor;

    const porteIdx = idxOf('porte_medio_grande');
    if (porteIdx !== -1) {
      const porteTexto = (linha[porteIdx] || '').trim().toLowerCase();
      const porteBool = porteTexto === 'sim' || porteTexto === 'true' || porteTexto === '1';
      if (porteBool !== Boolean(atual.sinal_porte_medio_grande)) payload.sinalPorteMedioGrande = porteBool;
    }

    if (Object.keys(payload).length > 0) {
      atualizacoes.push({ id, empresa: atual.empresa, payload });
    }
  }
  return atualizacoes;
}
