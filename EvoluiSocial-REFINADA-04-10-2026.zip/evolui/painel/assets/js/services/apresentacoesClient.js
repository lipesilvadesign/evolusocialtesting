import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/apresentacoes';

/** @param {string} leadId @returns {Promise<object[]>} */
export async function listarApresentacoes(leadId) {
  const { apresentacoes } = await authedFetch(`${ENDPOINT}?leadId=${encodeURIComponent(leadId)}`);
  return apresentacoes;
}

/** @param {string} leadId @param {string} nomeEmpresa @param {{ tema?: object, conteudo?: object }} dados */
export async function criarNovaVersaoApresentacao(leadId, nomeEmpresa, dados) {
  const { apresentacao } = await authedFetch(
    `${ENDPOINT}?leadId=${encodeURIComponent(leadId)}&nome=${encodeURIComponent(nomeEmpresa)}`,
    { method: 'POST', body: JSON.stringify(dados || {}) }
  );
  return apresentacao;
}

/** @param {string} id @param {{ tema?: object, conteudo?: object }} dados */
export async function salvarApresentacao(id, dados) {
  const { apresentacao } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify(dados),
  });
  return apresentacao;
}

/** @param {string} id */
export async function publicarApresentacao(id) {
  const { apresentacao } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}&acao=publicar`, { method: 'PATCH' });
  return apresentacao;
}
