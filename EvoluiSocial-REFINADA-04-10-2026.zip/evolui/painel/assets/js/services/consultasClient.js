import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/consultas';
const ATIVIDADES_ENDPOINT = '/.netlify/functions/consultas-atividades';

/** @param {{ status?: string }} [filtros] */
export async function fetchConsultas(filtros = {}) {
  const params = new URLSearchParams();
  if (filtros.status) params.set('status', filtros.status);
  const qs = params.toString();
  const { leads } = await authedFetch(qs ? `${ENDPOINT}?${qs}` : ENDPOINT);
  return leads;
}

/** @param {string} id @param {object} payload campos a atualizar (status, observacoesInternas, contatoRealizado, ultimoContatoEm) */
export async function updateConsulta(id, payload) {
  const { lead } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify(payload),
  });
  return lead;
}

export async function deleteConsulta(id) {
  await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
}

/** @param {string} leadId */
export async function listarAtividadesConsulta(leadId) {
  const { atividades } = await authedFetch(`${ATIVIDADES_ENDPOINT}?leadId=${encodeURIComponent(leadId)}`);
  return atividades;
}

/** @param {{ leadId: string, tipo: 'contato_realizado'|'mudanca_status'|'observacao', descricao?: string }} dados */
export async function criarAtividadeConsulta(dados) {
  const { atividade } = await authedFetch(ATIVIDADES_ENDPOINT, { method: 'POST', body: JSON.stringify(dados) });
  return atividade;
}
