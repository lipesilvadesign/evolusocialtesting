/**
 * Gerador de mensagens. Revisado com base no playbook de abordagem
 * comercial fornecido pelo usuário (playbook_abordagem_felipe_branding.md).
 *
 * REGRA INQUEBRÁVEL: nenhuma mensagem gerada aqui usa travessão (—) em
 * lugar nenhum. Se um dia for editar este arquivo, mantenha essa regra
 * (inclusive ao colar texto de fora, como o playbook original, que tinha
 * travessão em alguns pontos — removidos na hora de trazer pra cá).
 *
 * O tom muda de verdade conforme o que já está cadastrado no lead: ramo
 * (setor), tempo de mercado (anos_mercado), quantidade de avaliações no
 * Google e, quando existir, o Instagram real da empresa. Nada aqui é
 * inventado: cada variação só aparece na mensagem se o dado correspondente
 * estiver preenchido no lead, sem isso, a frase cai pra uma versão
 * genérica, nunca inventa um número, horário ou fato que não foi passado.
 */

export const ESTAGIOS_MENSAGEM = [
  { key: 'primeiro_contato', label: 'Primeiro contato' },
  { key: 'segundo_contato', label: 'Segundo contato (sem resposta)' },
  { key: 'follow_up', label: 'Follow-up' },
  { key: 'retomada', label: 'Retomada (contato antigo, esfriou)' },
  { key: 'apresentacao', label: 'Envio da apresentação' },
  { key: 'pos_reuniao', label: 'Pós-reunião' },
];

// ---------------------------------------------------------------------
// Tom por ramo: cada grupo de setores fala de um jeito um pouco diferente.
// São só as PALAVRAS DE ABERTURA do gancho, não um fato novo, então não
// corre o risco de inventar nada sobre a empresa.
// ---------------------------------------------------------------------
function grupoDeTom(segmento) {
  const s = (segmento || '').toLowerCase();
  if (/advocacia|contabilidade|consultoria|marca pessoal/.test(s)) return 'consultivo';
  if (/estética|saúde|pilates|clínica|beleza/.test(s)) return 'caloroso';
  if (/indústria|engenharia|construção|logística|transporte|b2b/.test(s)) return 'direto';
  if (/moda|joia|decoração|comércio premium|imobiliário|arquitetura/.test(s)) return 'inspirado';
  return 'neutro';
}

function saudacaoAbertura(remetente, tom) {
  const nome = remetente || 'Felipe';
  const POR_TOM = {
    consultivo: `Tudo bem? Meu nome é ${nome}, da Felipe Branding.`,
    caloroso: `Oi, tudo bem? Aqui é ${nome}, da Felipe Branding!`,
    direto: `Oi, tudo bem? Meu nome é ${nome}, da Felipe Branding.`,
    inspirado: `Oi! Tudo bem? Aqui é ${nome}, da Felipe Branding.`,
    neutro: `Oi, tudo bem? Meu nome é ${nome}, da Felipe Branding.`,
  };
  return POR_TOM[tom] || POR_TOM.neutro;
}

/**
 * Monta a "observação" de abertura combinando só o que existe de verdade
 * no cadastro (Instagram, avaliações, tempo de mercado). Segue o
 * diagnóstico do playbook: em vez de "fiquei curioso" (que enfraquece o
 * motivo do contato), conecta a observação a algo concreto (descoberta,
 * confiança, pedido, visita). Nunca combina mais de dois sinais na mesma
 * frase pra não ficar forçado.
 */
function montarObservacao({ empresa, instagram, avaliacaoGoogle, anosMercado }) {
  const nomeEmpresa = empresa || 'vocês';
  const match = String(avaliacaoGoogle || '').match(/([\d.,]+)\s*\((\d+)\s*avaliaç/i);
  const temAvaliacao = Boolean(match);
  const qtdAvaliacoes = temAvaliacao ? match[2] : null;

  if (instagram) {
    return `Conheci a ${nomeEmpresa} pelo Instagram de vocês (${instagram}) e quis entender uma coisa: quando alguém encontra a marca pela primeira vez por ali, fica claro o que torna vocês diferentes e como fazer um pedido ou agendar uma visita?`;
  }
  if (temAvaliacao && Number(qtdAvaliacoes) >= 50) {
    return `Vi que a ${nomeEmpresa} já tem ${qtdAvaliacoes} avaliações no Google, o que mostra que vocês já construíram confiança por aí. Fiquei pensando: essa mesma confiança aparece clara pra quem descobre a empresa agora, antes de falar com alguém do time?`;
  }
  if (temAvaliacao) {
    return `Conheci a ${nomeEmpresa} pelo Google e quis entender uma coisa: quando alguém encontra a marca pela primeira vez por ali, fica claro o que torna vocês diferentes e como pedir ou visitar?`;
  }
  if (anosMercado) {
    return `Vi que a ${nomeEmpresa} já tem ${anosMercado} de estrada. Fiquei pensando: isso fica claro pra quem está conhecendo a empresa agora, antes mesmo de falar com alguém do time?`;
  }
  return `Conheci a ${nomeEmpresa} e quis entender uma coisa: quando alguém encontra a marca pela primeira vez, fica claro o que torna vocês diferentes e qual é o próximo passo pra comprar ou visitar?`;
}

/** Se vierem 2 horários reais, usa os dois; sem isso, pergunta aberta (nunca inventa horário). */
function fraseDeHorarios(horarios) {
  if (Array.isArray(horarios) && horarios.length >= 2) {
    return `${horarios[0]} ou ${horarios[1]} funcionam pra você?`;
  }
  if (Array.isArray(horarios) && horarios.length === 1) {
    return `${horarios[0]} funciona pra você?`;
  }
  return 'Faz sentido pra você essa semana?';
}

const TEMPLATES = {
  primeiro_contato: ({ saudacao, observacao, responsavelNome, fraseHorarios }) =>
    `${saudacao}\n\n` +
    `${observacao}\n\n` +
    `Tenho algumas observações rápidas sobre isso. Posso te mostrar em uma conversa de 10 minutos, sem compromisso${responsavelNome}? ${fraseHorarios}`,

  segundo_contato: ({ empresa, responsavelNome, fraseHorarios }) =>
    `Oi${responsavelNome}! Passando de novo por aqui, sei que a rotina não dá trégua.\n\n` +
    `Fica o convite em aberto: se quiser, te mostro em 10 minutos algumas ideias pra ${empresa || 'vocês'}, sem compromisso. ${fraseHorarios}`,

  follow_up: ({ empresa, problemaFrase, responsavelNome }) =>
    `Oi${responsavelNome}, tudo bem?\n\n` +
    `Só retomando nosso papo sobre a ${empresa || 'sua empresa'}. ${problemaFrase}Se ainda fizer sentido pra vocês, posso te mostrar como a gente pensa em resolver isso, com calma e sem pressa.`,

  retomada: ({ empresa, responsavelNome }) =>
    `Oi${responsavelNome}! Faz um tempinho que a gente conversou sobre a ${empresa || 'sua empresa'}, como estão as coisas por aí?\n\n` +
    `Se o momento mudou e voltou a fazer sentido falar sobre a marca de vocês, fico à disposição pra retomar de onde paramos, sem pressa nenhuma.`,

  apresentacao: ({ empresa, linkApresentacao, responsavelNome }) =>
    `Oi${responsavelNome}! Preparei com carinho uma apresentação com o diagnóstico da ${empresa || 'sua empresa'}. Dá uma olhada quando puder, com calma:\n\n${linkApresentacao}\n\nQualquer dúvida, é só me chamar por aqui mesmo, tô à disposição.`,

  pos_reuniao: ({ empresa, objetivoFrase, responsavelNome }) =>
    `Oi${responsavelNome}! Foi muito bom conversar hoje sobre a ${empresa || 'sua empresa'}.\n\n` +
    `Como combinamos, ${objetivoFrase} Qualquer coisa que ficou faltando ou alguma dúvida que surgir, me chama sem cerimônia.`,
};

/**
 * @param {string} estagioKey
 * @param {{ empresa?: string, responsavel?: string, remetente?: string, segmento?: string, observacao?: string,
 *   problemaIdentificado?: string, objetivo?: string, instagram?: string, avaliacaoGoogle?: string,
 *   anosMercado?: string, linkApresentacao?: string, horarios?: string[] }} dados
 * @returns {string}
 */
export function gerarMensagem(estagioKey, dados = {}) {
  const template = TEMPLATES[estagioKey];
  if (!template) throw new Error(`Estágio de mensagem desconhecido: ${estagioKey}`);

  const tom = grupoDeTom(dados.segmento);
  const saudacao = saudacaoAbertura(dados.remetente, tom);
  const responsavelNome = dados.responsavel ? `, ${dados.responsavel}` : '';
  const observacao = dados.observacao
    ? `Conheci a ${dados.empresa || 'sua empresa'} e quis entender uma coisa: ${dados.observacao}.`
    : montarObservacao(dados);
  const problemaFrase = dados.problemaIdentificado ? `${dados.problemaIdentificado}. ` : '';
  const objetivoFrase = dados.objetivo || 'seguimos com os próximos passos que combinamos';
  const linkApresentacao = dados.linkApresentacao || '[link da apresentação]';
  const fraseHorarios = fraseDeHorarios(dados.horarios);

  return template({
    saudacao,
    observacao,
    empresa: dados.empresa,
    responsavelNome,
    problemaFrase,
    objetivoFrase,
    linkApresentacao,
    fraseHorarios,
  });
}

// ---------------------------------------------------------------------
// Respostas a objeções e dúvidas frequentes (do playbook). Não estão
// ligadas a um estágio do funil, então ficam como textos prontos à parte,
// pra copiar quando a situação aparecer numa conversa. {nome} é a única
// variável, o resto do texto é fixo (não depende de dado do lead).
// ---------------------------------------------------------------------
export const RESPOSTAS_OBJECAO = {
  ja_tem_agencia: (nome) =>
    `Faz sentido, ${nome || '[Nome]'}, e é positivo que vocês já invistam nisso.\n\n` +
    `Minha intenção não é substituir ninguém sem entender o cenário. A conversa pode servir como uma segunda visão sobre posicionamento e apresentação da marca.\n\n` +
    `Se eu te mostrar 2 observações em 10 minutos e não fizer sentido, encerramos por ali. Topa?`,
  sem_orcamento: (nome) =>
    `Entendo perfeitamente, ${nome || '[Nome]'}. Não estou te propondo investimento agora, o convite é só pra compartilhar uma análise curta.\n\n` +
    `Se houver uma oportunidade que faça sentido, vocês avaliam no momento certo. Posso te mostrar os pontos primeiro?`,
  manda_por_whatsapp: () =>
    `Claro. Pra não te mandar algo genérico, qual ponto é mais importante pra vocês hoje: atrair clientes novos, aumentar pedidos ou melhorar a percepção da marca?\n\n` +
    `Com sua resposta, te envio uma observação objetiva por aqui.`,
  sem_tempo: (nome) =>
    `Entendo, ${nome || '[Nome]'}. Posso resumir a principal observação num áudio de até 1 minuto por aqui.\n\n` +
    `Se fizer sentido pra você, depois marcamos os 10 minutos com calma. Posso enviar?`,
  sem_interesse: (nome) =>
    `Tranquilo, ${nome || '[Nome]'}, obrigado pela sinceridade.\n\n` +
    `Antes de encerrar, posso te deixar uma observação rápida sobre como um cliente novo percebe a marca online? Não precisa responder nem marcar nada.`,
  falar_com_socio: (nome) =>
    `Perfeito, ${nome || '[Nome]'}. Pra facilitar a conversa interna, posso te enviar um resumo curto com o objetivo da reunião e os pontos que vou abordar.\n\n` +
    `Quem mais costuma participar dessa decisão? Se fizer sentido, podemos incluir essa pessoa na conversa de 10 minutos.`,
  quanto_custa: (nome) =>
    `Depende do objetivo e do escopo, ${nome || '[Nome]'}. Antes de falar em valor, prefiro entender o que faria diferença pra vocês, pra não sugerir algo inadequado.\n\n` +
    `A conversa inicial é sem custo. Se houver aderência, apresentamos uma proposta clara e você decide com tranquilidade. Faz sentido?`,
};

export const DUVIDAS_FREQUENTES = {
  o_que_a_felipe_branding_faz: () =>
    `A Felipe Branding ajuda empresas a melhorar como são percebidas e escolhidas pelos clientes.\n\n` +
    `Dependendo da necessidade, isso pode envolver estratégia de marca, identidade visual, comunicação, conteúdo, presença digital e campanhas. Primeiro entendemos o cenário, depois indicamos o que realmente faz sentido.`,
  como_funciona_a_conversa: () =>
    `É uma conversa objetiva de 10 minutos. Mostro o que observei na presença atual da marca, faço algumas perguntas sobre o momento da empresa e, se houver aderência, explico possíveis próximos passos.\n\n` +
    `Não há compromisso de contratação nem proposta obrigatória na primeira conversa.`,
  atendem_nosso_segmento: () =>
    `Trabalhamos a partir do contexto de cada negócio. O mais importante é entender o cliente, a diferenciação, os canais de descoberta e o objetivo comercial da empresa.\n\n` +
    `Na conversa, posso mostrar como adaptar a estratégia à realidade de vocês.`,
  quanto_tempo_pra_resultado: () =>
    `Depende do projeto. Ajustes de clareza, apresentação e campanha podem gerar sinais mais rápidos, construção de marca e crescimento orgânico exigem consistência.\n\n` +
    `Na análise inicial, alinhamos expectativas, indicadores e prazo realista antes de iniciar qualquer trabalho.`,
};

/**
 * Três perguntas de qualificação pra usar depois de uma resposta positiva
 * (do playbook). Texto fixo, sem variável de lead nenhuma.
 */
export function perguntasQualificacao(nome) {
  return (
    `Perfeito, ${nome || '[Nome]'}. Pra eu preparar algo realmente útil, posso te fazer três perguntas rápidas?\n\n` +
    `1. Hoje, de onde vêm a maioria dos novos clientes: indicação, Instagram, Google, delivery ou passagem na loja?\n` +
    `2. Qual é o objetivo mais importante agora: atrair mais clientes, aumentar pedidos, fortalecer a marca ou divulgar produtos específicos?\n` +
    `3. Além de você, alguém participa dessa decisão?`
  );
}
