import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/briefings';

/** @param {string} leadId @returns {Promise<object|null>} */
export async function obterBriefing(leadId) {
  const { briefing } = await authedFetch(`${ENDPOINT}?leadId=${encodeURIComponent(leadId)}`);
  return briefing;
}

/** @param {string} leadId @param {object} conteudo */
export async function salvarBriefing(leadId, conteudo) {
  const { briefing } = await authedFetch(`${ENDPOINT}?leadId=${encodeURIComponent(leadId)}`, {
    method: 'PUT',
    body: JSON.stringify({ conteudo }),
  });
  return briefing;
}
