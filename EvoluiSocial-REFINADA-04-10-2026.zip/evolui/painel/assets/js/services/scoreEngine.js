/**
 * Espelho no navegador de netlify/functions/_lib/scoreEngine.js — mesma
 * lógica exata (testada lá, ver tests/scoreEngine.test.js), duplicada aqui
 * porque o painel roda como módulo ES no navegador e não pode importar um
 * arquivo CommonJS de dentro de netlify/functions. Qualquer mudança na
 * pontuação precisa ser feita NOS DOIS arquivos.
 */

const PONTOS = {
  semSite: 30,
  siteDesatualizado: 20,
  instagramDesorganizado: 15,
  gbpFraco: 15,
  porteMedioGrande: 15,
  segmentoAltoPotencial: 15,
  decisorIdentificado: 20,
  emailValidado: 10,
  respondeu: 40,
  pediuPropostaOuReuniao: 70,
};

// 30/09: 'interessado' também conta como resposta (antes valia menos que 'respondeu'). A partir da migration 008 o score oficial é o do banco.
const ESTAGIOS_RESPONDEU = ['respondeu', 'interessado', 'reuniao_marcada', 'proposta_enviada', 'cliente'];
const ESTAGIOS_PEDIU_PROPOSTA_OU_REUNIAO = ['reuniao_marcada', 'proposta_enviada', 'cliente'];

export function calcularScore(lead) {
  const motivos = [];

  if (!lead.site) motivos.push({ label: 'Sem site encontrado', pontos: PONTOS.semSite });
  if (lead.sinalSiteDesatualizado) motivos.push({ label: 'Site desatualizado/com problema técnico', pontos: PONTOS.siteDesatualizado });
  if (lead.sinalInstagramDesorganizado) motivos.push({ label: 'Instagram ativo, mas desorganizado', pontos: PONTOS.instagramDesorganizado });
  if (lead.sinalGbpFraco) motivos.push({ label: 'Google Business Profile fraco', pontos: PONTOS.gbpFraco });
  if (lead.sinalPorteMedioGrande) motivos.push({ label: 'Empresa de médio/grande porte', pontos: PONTOS.porteMedioGrande });
  if (lead.sinalSegmentoAltoPotencial) motivos.push({ label: 'Segmento de alto potencial', pontos: PONTOS.segmentoAltoPotencial });
  if (lead.temContatoDecisor) motivos.push({ label: 'Contato decisor identificado', pontos: PONTOS.decisorIdentificado });
  if (lead.sinalEmailValidado) motivos.push({ label: 'E-mail validado', pontos: PONTOS.emailValidado });

  const estagio = lead.status || 'novo_lead';
  if (ESTAGIOS_PEDIU_PROPOSTA_OU_REUNIAO.includes(estagio)) {
    motivos.push({ label: 'Pediu proposta ou reunião', pontos: PONTOS.pediuPropostaOuReuniao });
  } else if (ESTAGIOS_RESPONDEU.includes(estagio)) {
    motivos.push({ label: 'Respondeu ao contato', pontos: PONTOS.respondeu });
  }

  const score = motivos.reduce((acc, m) => acc + m.pontos, 0);
  return { score, motivos };
}

export function faixaScore(score) {
  if (score > 90) return { chave: 'prioritario', label: 'Prioritário' };
  if (score >= 61) return { chave: 'prospectar', label: 'Prospectar' };
  if (score >= 31) return { chave: 'nutrir', label: 'Nutrir' };
  return { chave: 'aguardar', label: 'Aguardar' };
}
