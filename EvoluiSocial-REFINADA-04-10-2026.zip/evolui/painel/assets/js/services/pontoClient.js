import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/ponto';

/** @param {{ inicio: string, fim: string, funcionarioId?: string }} periodo */
export function fetchPonto({ inicio, fim, funcionarioId }) {
  const qs = new URLSearchParams({ inicio, fim, ...(funcionarioId ? { funcionarioId } : {}) });
  return authedFetch(`${ENDPOINT}?${qs.toString()}`);
}

/** @param {'entrada'|'saida'} tipo */
export function registrarPonto(tipo) {
  return authedFetch(ENDPOINT, { method: 'POST', body: JSON.stringify({ tipo }) });
}
