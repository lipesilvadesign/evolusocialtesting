import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/metas';

export async function listarMetas() {
  const { metas } = await authedFetch(ENDPOINT);
  return metas;
}

/** @param {{ funcionarioId: string, periodo: 'semanal'|'mensal', referencia: string, meta: number }} dados */
export async function definirMeta(dados) {
  const { meta } = await authedFetch(ENDPOINT, { method: 'POST', body: JSON.stringify(dados) });
  return meta;
}
