import { authedFetch } from './apiClient.js';

/** @returns {Promise<import('../../../../netlify/functions/_lib/types').SiteSettings>} */
export async function getSettings() {
  const { settings } = await authedFetch('/.netlify/functions/settings');
  return settings;
}

/**
 * Envia só as seções que mudaram — a Function faz merge parcial, o resto
 * do JSON salvo continua intacto.
 * @returns {Promise<import('../../../../netlify/functions/_lib/types').SiteSettings>}
 */
export async function saveSettings(partial) {
  const { settings } = await authedFetch('/.netlify/functions/settings', {
    method: 'PUT',
    body: JSON.stringify(partial),
  });
  return settings;
}
