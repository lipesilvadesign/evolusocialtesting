import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/diagnosticos';

/** @param {string} leadId @returns {Promise<object[]>} versões, mais recente primeiro */
export async function listarDiagnosticos(leadId) {
  const { diagnosticos } = await authedFetch(`${ENDPOINT}?leadId=${encodeURIComponent(leadId)}`);
  return diagnosticos;
}

/** @param {string} leadId @returns {Promise<object>} nova versão vazia */
export async function criarNovaVersaoDiagnostico(leadId) {
  const { diagnostico } = await authedFetch(`${ENDPOINT}?leadId=${encodeURIComponent(leadId)}`, { method: 'POST' });
  return diagnostico;
}

/** @param {string} id @param {object} conteudo */
export async function salvarDiagnostico(id, conteudo) {
  const { diagnostico } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify({ conteudo }),
  });
  return diagnostico;
}

/** @param {string} id */
export async function publicarDiagnostico(id) {
  const { diagnostico } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}&acao=publicar`, { method: 'PATCH' });
  return diagnostico;
}
