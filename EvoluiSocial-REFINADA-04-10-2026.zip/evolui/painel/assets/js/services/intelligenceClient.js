import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/intelligence';

/** @param {{range?:string, start?:string, end?:string}} rangeQuery */
export async function fetchIntelligence(rangeQuery = { range: '30d' }) {
  const params = new URLSearchParams(rangeQuery);
  const { intelligence } = await authedFetch(`${ENDPOINT}?${params.toString()}`);
  return intelligence;
}

/**
 * Ação real do usuário — persiste no histórico (admin_insights_historico).
 * @param {string} id
 * @param {'novo'|'em_andamento'|'concluido'|'descartado'} status
 */
export async function updateOpportunityStatus(id, status) {
  const { item } = await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
  return item;
}
