import { authedFetch } from './apiClient.js';

const ENDPOINT = '/.netlify/functions/notifications';

export async function fetchNotifications({ onlyUnread = false } = {}) {
  const { notifications } = await authedFetch(`${ENDPOINT}?unread=${onlyUnread}`);
  return notifications;
}

export async function markNotificationRead(id) {
  await authedFetch(`${ENDPOINT}?id=${encodeURIComponent(id)}`, { method: 'PATCH' });
}
