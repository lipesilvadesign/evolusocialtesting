/**
 * Módulo "Clientes" — PROMPT 2.
 *
 * DECISÃO DE ARQUITETURA (ver PROMPT_1_AUDITORIA_E_ARQUITETURA.md e o
 * cabeçalho de SQL_PENDENTE_clientes.sql): "cliente" não é uma tabela nova —
 * é o MESMO registro de admin_prospeccao_leads, só que no estágio `status`
 * (estágio da oportunidade) igual a 'cliente'. Por isso esta view reaproveita
 * fetchLeads/updateLead/listarContatos/criarContato/listarAtividades/
 * criarAtividade, todos já existentes em prospeccaoClient.js — nada disso é
 * duplicado aqui. STATUS_MAP/STATUS_ORDER vêm de prospeccao.js (fonte única).
 *
 * Rotas: '#/clientes' (lista) e '#/clientes/<id>' (página individual com
 * abas), ambas resolvidas por esta mesma função (ver app.js). Lista ordena
 * clientes (status='cliente') primeiro.
 */

import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import {
  fetchTodosLeads,
  fetchLead,
  updateLead,
  listarContatos,
  criarContato,
  removerContato,
  listarAtividades,
  criarAtividade,
} from '../services/prospeccaoClient.js';
import { obterBriefing, salvarBriefing } from '../services/briefingsClient.js';
import { listarMetricas, criarMetrica, removerMetrica } from '../services/metricasClient.js';
import {
  listarDiagnosticos,
  criarNovaVersaoDiagnostico,
  salvarDiagnostico,
  publicarDiagnostico,
} from '../services/diagnosticosClient.js';
import {
  listarApresentacoes,
  criarNovaVersaoApresentacao,
  salvarApresentacao,
  publicarApresentacao,
} from '../services/apresentacoesClient.js';
import { gerarRascunhoDiagnosticoIA } from '../services/diagnosticoIaClient.js';
import { listarFuncionarios } from '../services/funcionariosClient.js';
import { getCurrentUser } from '../services/auth.js';
import { ehAdmin } from '../services/rbac.js';
import { ESTAGIOS_MENSAGEM, gerarMensagem } from '../services/mensagensTemplates.js';
import { enviarMensagem } from '../services/equipeMensagensClient.js';
// STATUS_MAP/STATUS_ORDER vêm de prospeccao.js — fonte única (antes esta
// view tinha seu próprio mapa, com chaves (lead/contato_feito/diagnostico/
// proposta...) que nunca bateram com a coluna real do banco. O formulário
// "Status" desta página escrevia em status_lead (que só aceita
// novo/pesquisando/qualificado/nao_qualificado/duplicado/bloqueado) com
// valores fora dessa lista — todo "Salvar alterações" que mexesse no status
// falhava contra a constraint do Postgres. Corrigido: agora lê/escreve o
// mesmo campo `status` (estágio da oportunidade) que a Prospecção usa.
import { STATUS_MAP, STATUS_ORDER } from './prospeccao.js';
import { esc, safeUrl } from '../utils/html.js';

function statusBadgeHtml(status) {
  const info = STATUS_MAP[status] || STATUS_MAP.novo_lead;
  return `<span class="badge ${info.cls}">${info.label}</span>`;
}

// Nomes de empresa/contato/métrica e todo texto de briefing/apresentação são
// digitados por qualquer funcionário — nunca inserir em innerHTML (nem
// dentro de <textarea>, onde um "</textarea>" no texto quebraria a tag) sem
// escapar antes (achado numa auditoria de segurança, 13/09).

function formatarData(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('pt-BR');
}

// ---------------------------------------------------------------------
// Entrada — decide lista ou detalhe
// ---------------------------------------------------------------------
export async function renderClientes(container, clienteId) {
  container.innerHTML = '';
  if (clienteId) {
    await renderDetalhe(container, clienteId);
  } else {
    await renderLista(container);
  }
}

// ---------------------------------------------------------------------
// LISTA
// ---------------------------------------------------------------------
async function renderLista(container) {
  let leads = [];
  // Padrão: esconde o estágio "Novo lead" (prospecção crua, ainda sem
  // contato feito) — isso fica só na tela Prospecção. Aqui em Clientes
  // começa a partir de "Contatado". "Todos" continua disponível como opção
  // explícita pra quem quiser ver tudo mesmo assim.
  let filtroStatus = 'sem_leads_brutos';
  let termoBusca = '';

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Clientes</h2>
      <p>Do primeiro contato ao cliente ativo — tudo num só lugar. (Mesma base de dados da Prospecção; leads ainda sem contato ficam só na tela Prospecção.)</p>
    </div>
  `;
  container.appendChild(head);

  const toolbar = document.createElement('div');
  toolbar.className = 'content-toolbar';
  toolbar.innerHTML = `
    <div class="search-box-small">
      <input type="search" id="clienteSearch" placeholder="Buscar por empresa, responsável, segmento, Instagram, telefone…" aria-label="Buscar cliente" style="min-width:280px">
    </div>
  `;
  container.appendChild(toolbar);

  const filtrosBar = document.createElement('div');
  filtrosBar.className = 'content-tabs';
  container.appendChild(filtrosBar);

  function renderFiltros() {
    filtrosBar.innerHTML = '';
    const emAndamento = document.createElement('button');
    emAndamento.className = 'tab-btn' + (filtroStatus === 'sem_leads_brutos' ? ' is-active' : '');
    emAndamento.textContent = 'Em relacionamento';
    emAndamento.title = 'Esconde o estágio "Novo lead" (prospecção crua) — esse fica só na tela Prospecção';
    emAndamento.addEventListener('click', () => { filtroStatus = 'sem_leads_brutos'; renderFiltros(); renderTabela(); });
    filtrosBar.appendChild(emAndamento);

    const todos = document.createElement('button');
    todos.className = 'tab-btn' + (filtroStatus === 'todos' ? ' is-active' : '');
    todos.textContent = 'Todos (incluindo leads novos)';
    todos.addEventListener('click', () => { filtroStatus = 'todos'; renderFiltros(); renderTabela(); });
    filtrosBar.appendChild(todos);

    STATUS_ORDER.forEach((s) => {
      const btn = document.createElement('button');
      btn.className = 'tab-btn' + (filtroStatus === s ? ' is-active' : '');
      btn.textContent = STATUS_MAP[s].label;
      btn.addEventListener('click', () => { filtroStatus = s; renderFiltros(); renderTabela(); });
      filtrosBar.appendChild(btn);
    });
  }

  const listCard = document.createElement('section');
  listCard.className = 'card';
  container.appendChild(listCard);

  function filtrados() {
    const termo = termoBusca.trim().toLowerCase();
    const linhas = leads.filter((l) => {
      const statusAtual = l.status || 'novo_lead';
      const passaStatus =
        filtroStatus === 'todos' ||
        (filtroStatus === 'sem_leads_brutos' ? statusAtual !== 'novo_lead' : statusAtual === filtroStatus);
      if (!passaStatus) return false;
      if (!termo) return true;
      const campos = [l.empresa, l.responsavel_interno, l.setor, l.instagram, l.telefone, STATUS_MAP[statusAtual]?.label];
      return campos.some((c) => String(c || '').toLowerCase().includes(termo));
    });
    // Clientes (status já convertido) sempre primeiro — pedido do Felipe:
    // quem já é cliente é quem mais importa ver de cara nesta lista.
    return linhas.sort((a, b) => {
      const aCliente = a.status === 'cliente' ? 0 : 1;
      const bCliente = b.status === 'cliente' ? 0 : 1;
      if (aCliente !== bCliente) return aCliente - bCliente;
      return new Date(b.ultima_atividade_em || b.created_at) - new Date(a.ultima_atividade_em || a.created_at);
    });
  }

  function renderTabela() {
    listCard.innerHTML = '';
    const rows = filtrados();
    if (rows.length === 0) {
      listCard.appendChild(EmptyState({
        title: 'Nada por aqui',
        description: leads.length === 0 ? 'Nenhum cliente/lead cadastrado ainda.' : 'Nada encontrado com esses filtros.',
      }));
      return;
    }
    const wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    const table = document.createElement('table');
    table.className = 'app-table';
    table.innerHTML = `
      <thead><tr><th>Empresa</th><th>Segmento</th><th>Cidade</th><th>Responsável (interno)</th><th>Status</th><th>Último contato</th></tr></thead>
      <tbody></tbody>
    `;
    const tbody = table.querySelector('tbody');
    rows.forEach((l) => {
      const tr = document.createElement('tr');
      tr.style.cursor = 'pointer';
      tr.innerHTML = `
        <td><a class="app-table-link" href="#/clientes/${encodeURIComponent(l.id)}">${esc(l.empresa)}</a></td>
        <td>${esc(l.setor || '—')}</td>
        <td>${esc(l.cidade || '—')}</td>
        <td>${esc(l.responsavel_interno || '—')}</td>
        <td>${statusBadgeHtml(l.status || 'novo_lead')}</td>
        <td>${formatarData(l.ultima_atividade_em)}</td>
      `;
      tr.addEventListener('click', () => { window.location.hash = `#/clientes/${l.id}`; });
      tbody.appendChild(tr);
    });
    wrap.appendChild(table);
    listCard.appendChild(wrap);
  }

  function carregar() {
    listCard.innerHTML = '';
    listCard.appendChild(LoadingState({ rows: 6 }));
    fetchTodosLeads()
      .then((data) => { leads = data; renderFiltros(); renderTabela(); })
      .catch((err) => {
        listCard.innerHTML = '';
        listCard.appendChild(ErrorState({ description: err.message, onRetry: carregar }));
      });
  }

  toolbar.querySelector('#clienteSearch').addEventListener('input', (e) => {
    termoBusca = e.target.value;
    renderTabela();
  });

  renderFiltros();
  carregar();
}

// ---------------------------------------------------------------------
// DETALHE — página individual com abas
// ---------------------------------------------------------------------
const TABS = ['empresa', 'prospeccao', 'briefing', 'metricas', 'diagnostico', 'apresentacao', 'historico'];
const TAB_LABELS = {
  empresa: 'Empresa', prospeccao: 'Prospecção', briefing: 'Briefing', metricas: 'Métricas',
  diagnostico: 'Diagnóstico', apresentacao: 'Apresentação', historico: 'Histórico',
};

async function renderDetalhe(container, clienteId) {
  const backLink = document.createElement('a');
  backLink.href = '#/clientes';
  backLink.className = 'btn btn-ghost btn-sm';
  backLink.textContent = '← Voltar para Clientes';
  backLink.style.marginBottom = 'var(--space-4)';
  container.appendChild(backLink);

  const head = document.createElement('div');
  head.className = 'app-view-head';
  container.appendChild(head);

  const tabsBar = document.createElement('div');
  tabsBar.className = 'content-tabs';
  container.appendChild(tabsBar);

  const tabHost = document.createElement('div');
  container.appendChild(tabHost);

  let lead = null;
  let activeTab = 'empresa';

  function renderTabsBar() {
    tabsBar.innerHTML = '';
    TABS.forEach((t) => {
      const btn = document.createElement('button');
      btn.className = 'tab-btn' + (t === activeTab ? ' is-active' : '');
      btn.textContent = TAB_LABELS[t];
      btn.addEventListener('click', () => { activeTab = t; renderTabsBar(); renderTabContent(); });
      tabsBar.appendChild(btn);
    });
  }

  function renderTabContent() {
    tabHost.innerHTML = '';
    const card = document.createElement('section');
    card.className = 'card';
    tabHost.appendChild(card);

    if (activeTab === 'empresa') return renderAbaEmpresa(card, lead, atualizarLeadLocal);
    if (activeTab === 'prospeccao') return renderAbaProspeccao(card, lead);
    if (activeTab === 'briefing') return renderAbaBriefing(card, lead);
    if (activeTab === 'metricas') return renderAbaMetricas(card, lead);
    if (activeTab === 'diagnostico') return renderAbaDiagnostico(card, lead);
    if (activeTab === 'apresentacao') return renderAbaApresentacao(card, lead);
    if (activeTab === 'historico') return renderAbaHistorico(card, lead);
  }

  function atualizarLeadLocal(novoLead) {
    lead = novoLead;
    head.innerHTML = `
      <div>
        <p class="eyebrow">Cliente</p>
        <h2>${esc(lead.empresa)}</h2>
        <p>${statusBadgeHtml(lead.status || 'novo_lead')} &nbsp; ${esc(lead.setor || '')} ${lead.cidade ? '· ' + esc(lead.cidade) : ''}</p>
      </div>
      <button class="btn btn-ghost btn-sm" id="btnCompartilharMural" type="button" title="Manda uma dúvida ou aviso sobre este cliente pro mural da equipe, com link de volta pra cá">
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a3 3 0 1 0-2.83-4H15a3 3 0 0 0 .05 3.9L8.9 11.6a3 3 0 1 0 0 2.8l6.15 3.7a3 3 0 1 0 .87-1.7L9.77 12.7a3 3 0 0 0 0-1.4l6.15-3.7c.31.25.67.44 1.05.55Q17.5 8 18 8Z"/></svg>
        Compartilhar no mural
      </button>
    `;
    head.querySelector('#btnCompartilharMural').addEventListener('click', () => abrirCompartilharMural(lead));
  }

  async function abrirCompartilharMural(leadAtual) {
    const texto = window.prompt(`Mensagem pra equipe sobre "${leadAtual.empresa}" (vai aparecer no mural com um link de volta pra este cliente):`, '');
    if (texto === null) return;
    if (!texto.trim()) { showToast('Escreva alguma coisa antes de compartilhar.', { tone: 'danger' }); return; }
    try {
      await enviarMensagem(texto.trim(), leadAtual.id);
      showToast('Compartilhado no mural.', { tone: 'ok' });
    } catch (err) {
      showToast(err.message || 'Falha ao compartilhar no mural.', { tone: 'danger' });
    }
  }

  tabHost.innerHTML = '';
  tabHost.appendChild(LoadingState({ rows: 4 }));

  try {
    lead = await fetchLead(clienteId).catch(() => null);
    if (!lead) {
      tabHost.innerHTML = '';
      tabHost.appendChild(ErrorState({ description: 'Cliente não encontrado.' }));
      return;
    }
    atualizarLeadLocal(lead);
    renderTabsBar();
    renderTabContent();
  } catch (err) {
    tabHost.innerHTML = '';
    tabHost.appendChild(ErrorState({ description: err.message }));
  }
}

// ---------- ABA: EMPRESA ----------
async function renderAbaEmpresa(card, lead, onSaved) {
  card.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Carregando…</p>';
  const usuario = await getCurrentUser();
  const souAdmin = ehAdmin(usuario);
  let funcionarios = [];
  if (souAdmin) {
    try { funcionarios = await listarFuncionarios(); } catch (e) { /* segue sem a lista — campo cai pro modo somente-leitura */ }
  }

  const responsavelFieldHtml = souAdmin && funcionarios.length
    ? `
      <div class="field">
        <label for="f_responsavelId">Responsável (interno — quem na Felipe Branding cuida deste cliente)</label>
        <select id="f_responsavelId">
          <option value="">— Ninguém atribuído —</option>
          ${funcionarios.map((f) => `<option value="${esc(f.id)}" ${f.id === lead.responsavel_id ? 'selected' : ''}>${esc(f.nome)} (${esc(f.role)})</option>`).join('')}
        </select>
      </div>
    `
    : `
      <div class="field">
        <label for="f_responsavelInterno">Responsável (interno)</label>
        <input id="f_responsavelInterno" value="${esc(lead.responsavel_interno || '')}" ${souAdmin ? '' : 'disabled title="Só administradores reatribuem clientes"'}>
      </div>
    `;

  card.innerHTML = `
    <div class="content-editor-form">
      <div class="field"><label for="f_empresa">Empresa</label><input id="f_empresa" value="${esc(lead.empresa || '')}"></div>
      <div class="field"><label for="f_setor">Segmento</label><input id="f_setor" value="${esc(lead.setor || '')}"></div>
      ${responsavelFieldHtml}
      <div class="field"><label for="f_telefone">Telefone / WhatsApp</label><input id="f_telefone" value="${esc(lead.telefone || '')}"></div>
      <div class="field"><label for="f_email">E-mail</label><input id="f_email" value="${esc(lead.email || '')}"></div>
      <div class="field"><label for="f_instagram">Instagram</label><input id="f_instagram" placeholder="@usuario" value="${esc(lead.instagram || '')}"></div>
      <div class="field"><label for="f_site">Site</label><input id="f_site" value="${esc(lead.site || '')}"></div>
      <div class="field"><label for="f_cidade">Cidade</label><input id="f_cidade" value="${esc(lead.cidade || '')}"></div>
      <div class="field">
        <label for="f_status">Status</label>
        <select id="f_status">${STATUS_ORDER.map((s) => `<option value="${s}" ${s === (lead.status || 'novo_lead') ? 'selected' : ''}>${STATUS_MAP[s].label}</option>`).join('')}</select>
      </div>
      <div class="field"><label for="f_obs">Observações</label><textarea id="f_obs" rows="4">${esc(lead.observacoes || '')}</textarea></div>
    </div>
    <button class="btn btn-primary btn-sm" id="salvarEmpresaBtn">Salvar alterações</button>
  `;
  card.querySelector('#salvarEmpresaBtn').addEventListener('click', async () => {
    const payload = {
      empresa: card.querySelector('#f_empresa').value.trim(),
      setor: card.querySelector('#f_setor').value.trim(),
      telefone: card.querySelector('#f_telefone').value.trim(),
      email: card.querySelector('#f_email').value.trim(),
      instagram: card.querySelector('#f_instagram').value.trim(),
      site: card.querySelector('#f_site').value.trim(),
      cidade: card.querySelector('#f_cidade').value.trim(),
      status: card.querySelector('#f_status').value,
      observacoes: card.querySelector('#f_obs').value.trim(),
    };
    const responsavelIdEl = card.querySelector('#f_responsavelId');
    const responsavelInternoEl = card.querySelector('#f_responsavelInterno');
    if (responsavelIdEl) {
      payload.responsavelId = responsavelIdEl.value || null;
      const nomeEscolhido = responsavelIdEl.selectedOptions[0]?.textContent || '';
      payload.responsavelInterno = nomeEscolhido.replace(/\s*\([^)]*\)$/, '');
    } else if (responsavelInternoEl) {
      payload.responsavelInterno = responsavelInternoEl.value.trim();
    }
    if (!payload.empresa) { showToast('Informe o nome da empresa.', { tone: 'danger' }); return; }
    try {
      const atualizado = await updateLead(lead.id, payload);
      showToast('Dados salvos.', { tone: 'ok' });
      onSaved(atualizado);
    } catch (err) {
      showToast(err.message || 'Falha ao salvar.', { tone: 'danger' });
    }
  });
}

// ---------- ABA: PROSPECÇÃO (contatos + resumo) ----------
function renderAbaProspeccao(card, lead) {
  card.innerHTML = `
    <h3>Contatos (pessoas na empresa do cliente)</h3>
    <div id="contatosHost"><p style="color:var(--text-muted);font-size:.85rem">Carregando…</p></div>
    <div class="content-editor-form" style="margin-top:var(--space-4)">
      <div class="field"><label for="c_nome">Nome</label><input id="c_nome"></div>
      <div class="field"><label for="c_cargo">Cargo</label><input id="c_cargo"></div>
      <div class="field"><label for="c_email">E-mail</label><input id="c_email"></div>
      <div class="field"><label for="c_whatsapp">WhatsApp</label><input id="c_whatsapp"></div>
      <div class="field"><label for="c_linkedin">LinkedIn</label><input id="c_linkedin"></div>
      <div class="field"><label><input type="checkbox" id="c_principal"> Contato principal</label></div>
    </div>
    <button class="btn btn-primary btn-sm" id="addContatoBtn">+ Adicionar contato</button>

    <h3 style="margin-top:var(--space-5)">Gerador de mensagens</h3>
    <div class="content-editor-form">
      <div class="field">
        <label for="msg_estagio">Estágio do contato</label>
        <select id="msg_estagio">${ESTAGIOS_MENSAGEM.map((e) => `<option value="${e.key}">${e.label}</option>`).join('')}</select>
      </div>
      <div class="field"><label for="msg_responsavel">Nome do responsável na empresa (opcional)</label><input id="msg_responsavel"></div>
      <div class="field"><label for="msg_observacao">Observação (o que você reparou — opcional)</label><input id="msg_observacao"></div>
      <div class="field"><label for="msg_objetivo">Objetivo desta conversa (opcional)</label><input id="msg_objetivo"></div>
    </div>
    <button class="btn btn-ghost btn-sm" id="msg_gerarBtn">Gerar mensagem</button>
    <div id="msg_resultadoHost" style="margin-top:var(--space-3)"></div>
  `;
  const host = card.querySelector('#contatosHost');

  function renderMensagem() {
    const estagio = card.querySelector('#msg_estagio').value;
    const texto = gerarMensagem(estagio, {
      empresa: lead.empresa,
      responsavel: card.querySelector('#msg_responsavel').value.trim(),
      segmento: lead.setor,
      observacao: card.querySelector('#msg_observacao').value.trim(),
      problemaIdentificado: lead.problema_identificado || '',
      objetivo: card.querySelector('#msg_objetivo').value.trim(),
      instagram: lead.instagram || undefined,
      avaliacaoGoogle: lead.avaliacao_google || undefined,
      anosMercado: lead.anos_mercado || undefined,
    });
    const resultHost = card.querySelector('#msg_resultadoHost');
    resultHost.innerHTML = `
      <div class="field"><textarea id="msg_texto" rows="6" style="width:100%">${esc(texto)}</textarea></div>
      <button class="btn btn-primary btn-sm" id="msg_copiarBtn">Copiar mensagem</button>
    `;
    resultHost.querySelector('#msg_copiarBtn').addEventListener('click', async () => {
      await navigator.clipboard.writeText(resultHost.querySelector('#msg_texto').value);
      showToast('Mensagem copiada.', { tone: 'ok' });
    });
  }
  card.querySelector('#msg_gerarBtn').addEventListener('click', renderMensagem);


  function renderContatos(lista) {
    if (lista.length === 0) {
      host.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Nenhum contato cadastrado ainda.</p>';
      return;
    }
    host.innerHTML = `<div class="table-wrap"><table class="app-table"><thead><tr><th>Pessoa</th><th>Cargo</th><th>Falar com</th><th></th></tr></thead><tbody>
      ${lista.map((c) => {
        const iniciais = esc(c.nome.trim().split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]).join('').toUpperCase());
        // 30/09: número já com DDI 55 (12–13 dígitos) não ganha outro 55 (antes virava wa.me/5555...)
        const digitosWa = (c.whatsapp || '').replace(/\D/g, '').replace(/^0+/, '');
        const soDigitos = digitosWa && /^55\d{10,11}$/.test(digitosWa) ? digitosWa.slice(2) : digitosWa;
        return `
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:8px">
              <div class="welcome-avatar welcome-avatar-initials" style="width:28px;height:28px;font-size:.7rem">${iniciais || '?'}</div>
              <span>${esc(c.nome)}${c.principal ? ' <span class="badge badge-ok">Principal</span>' : ''}</span>
            </div>
          </td>
          <td>${esc(c.cargo || '—')}</td>
          <td>
            <div style="display:flex;gap:8px;align-items:center">
              ${soDigitos ? `<a class="btn btn-ghost btn-xs btn-icon-label" href="https://wa.me/55${soDigitos}" target="_blank" rel="noopener" title="Abrir WhatsApp"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg><span>WhatsApp</span></a>` : ''}
              ${c.email ? `<a class="btn btn-ghost btn-xs btn-icon-label" href="mailto:${encodeURIComponent(c.email)}" title="Enviar e-mail"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg><span>E-mail</span></a>` : ''}
              ${!soDigitos && !c.email ? '—' : ''}
            </div>
          </td>
          <td><button class="btn btn-ghost btn-sm" data-del="${c.id}">Excluir</button></td>
        </tr>
      `;
      }).join('')}
    </tbody></table></div>`;
    host.querySelectorAll('[data-del]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await removerContato(btn.dataset.del);
          carregarContatos();
        } catch (err) {
          showToast(err.message || 'Falha ao excluir contato.', { tone: 'danger' });
        }
      });
    });
  }

  function carregarContatos() {
    listarContatos(lead.id).then(renderContatos).catch((err) => {
      host.innerHTML = `<p style="color:var(--danger);font-size:.85rem">${esc(err.message)}</p>`;
    });
  }

  card.querySelector('#addContatoBtn').addEventListener('click', async () => {
    const nome = card.querySelector('#c_nome').value.trim();
    if (!nome) { showToast('Informe o nome do contato.', { tone: 'danger' }); return; }
    try {
      await criarContato({
        leadId: lead.id,
        nome,
        cargo: card.querySelector('#c_cargo').value.trim(),
        email: card.querySelector('#c_email').value.trim(),
        whatsapp: card.querySelector('#c_whatsapp').value.trim(),
        linkedin: card.querySelector('#c_linkedin').value.trim(),
        principal: card.querySelector('#c_principal').checked,
      });
      showToast('Contato adicionado.', { tone: 'ok' });
      carregarContatos();
    } catch (err) {
      showToast(err.message || 'Falha ao adicionar contato.', { tone: 'danger' });
    }
  });

  carregarContatos();
}

// ---------- ABA: BRIEFING ----------
function renderAbaBriefing(card, lead) {
  card.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Carregando…</p>';

  obterBriefing(lead.id).then((briefing) => {
    const c = (briefing && briefing.conteudo) || {};
    const empresa = c.empresa || {};
    const publico = c.publico || {};
    const posicionamento = c.posicionamento || {};
    const personalidade = c.personalidade || {};
    const preferenciasVisuais = c.preferenciasVisuais || {};
    const objetivos = c.objetivos || {};

    const escalas = [
      ['tradicionalContemporanea', 'Tradicional', 'Contemporânea'],
      ['discretaExpressiva', 'Discreta', 'Expressiva'],
      ['popularSofisticada', 'Popular', 'Sofisticada'],
      ['formalDescontraida', 'Formal', 'Descontraída'],
    ];
    const objetivosLista = [
      ['reconhecimento', 'Reconhecimento de marca'],
      ['autoridade', 'Autoridade no mercado'],
      ['geracaoLeads', 'Geração de leads'],
      ['vendas', 'Vendas diretas'],
      ['reposicionamento', 'Reposicionamento'],
      ['diferenciacao', 'Diferenciação da concorrência'],
    ];

    card.innerHTML = `
      <h3>Empresa</h3>
      <div class="content-editor-form">
        <div class="field"><label for="b_historia">História</label><textarea id="b_historia" rows="2">${esc(empresa.historia || '')}</textarea></div>
        <div class="field"><label for="b_produtos">Produtos</label><textarea id="b_produtos" rows="2">${esc(empresa.produtos || '')}</textarea></div>
        <div class="field"><label for="b_servicos">Serviços</label><textarea id="b_servicos" rows="2">${esc(empresa.servicos || '')}</textarea></div>
        <div class="field"><label for="b_empresaDiferenciais">Diferenciais</label><textarea id="b_empresaDiferenciais" rows="2">${esc(empresa.diferenciais || '')}</textarea></div>
        <div class="field"><label for="b_localizacao">Localização</label><input id="b_localizacao" value="${esc(empresa.localizacao || '')}"></div>
      </div>

      <h3>Público</h3>
      <div class="content-editor-form">
        <div class="field"><label for="b_perfil">Perfil</label><textarea id="b_perfil" rows="2">${esc(publico.perfil || '')}</textarea></div>
        <div class="field"><label for="b_necessidades">Necessidades</label><textarea id="b_necessidades" rows="2">${esc(publico.necessidades || '')}</textarea></div>
        <div class="field"><label for="b_comportamento">Comportamento</label><textarea id="b_comportamento" rows="2">${esc(publico.comportamento || '')}</textarea></div>
        <div class="field"><label for="b_desejos">Desejos</label><textarea id="b_desejos" rows="2">${esc(publico.desejos || '')}</textarea></div>
        <div class="field"><label for="b_objecoes">Objeções</label><textarea id="b_objecoes" rows="2">${esc(publico.objecoes || '')}</textarea></div>
        <div class="field"><label for="b_motivadores">Motivadores</label><textarea id="b_motivadores" rows="2">${esc(publico.motivadores || '')}</textarea></div>
      </div>

      <h3>Posicionamento</h3>
      <div class="content-editor-form">
        <div class="field"><label for="b_percepcaoAtual">Percepção atual</label><textarea id="b_percepcaoAtual" rows="2">${esc(posicionamento.percepcaoAtual || '')}</textarea></div>
        <div class="field"><label for="b_percepcaoDesejada">Percepção desejada</label><textarea id="b_percepcaoDesejada" rows="2">${esc(posicionamento.percepcaoDesejada || '')}</textarea></div>
        <div class="field"><label for="b_concorrentes">Concorrentes</label><textarea id="b_concorrentes" rows="2">${esc(posicionamento.concorrentes || '')}</textarea></div>
        <div class="field"><label for="b_posDiferenciais">Diferenciais</label><textarea id="b_posDiferenciais" rows="2">${esc(posicionamento.diferenciais || '')}</textarea></div>
        <div class="field"><label for="b_promessa">Promessa</label><textarea id="b_promessa" rows="2">${esc(posicionamento.promessa || '')}</textarea></div>
        <div class="field"><label for="b_propostaValor">Proposta de valor</label><textarea id="b_propostaValor" rows="2">${esc(posicionamento.propostaValor || '')}</textarea></div>
      </div>

      <h3>Personalidade da marca</h3>
      <div class="content-editor-form">
        ${escalas.map(([key, esq, dir]) => `
          <div class="field">
            <label style="display:flex;justify-content:space-between"><span>${esq}</span><span>${dir}</span></label>
            <input type="range" min="0" max="100" id="b_escala_${key}" value="${personalidade[key] != null ? personalidade[key] : 50}" style="width:100%">
          </div>
        `).join('')}
      </div>

      <h3>Preferências visuais</h3>
      <div class="content-editor-form">
        <div class="field"><label for="b_coresPreferidas">Cores preferidas</label><input id="b_coresPreferidas" value="${esc(preferenciasVisuais.coresPreferidas || '')}"></div>
        <div class="field"><label for="b_coresEvitar">Cores a evitar</label><input id="b_coresEvitar" value="${esc(preferenciasVisuais.coresEvitar || '')}"></div>
        <div class="field"><label for="b_tipografias">Tipografias</label><input id="b_tipografias" value="${esc(preferenciasVisuais.tipografias || '')}"></div>
        <div class="field"><label for="b_referencias">Referências</label><textarea id="b_referencias" rows="2">${esc(preferenciasVisuais.referencias || '')}</textarea></div>
        <div class="field"><label for="b_estilosDesejados">Estilos desejados</label><textarea id="b_estilosDesejados" rows="2">${esc(preferenciasVisuais.estilosDesejados || '')}</textarea></div>
        <div class="field"><label for="b_estilosRejeitados">Estilos rejeitados</label><textarea id="b_estilosRejeitados" rows="2">${esc(preferenciasVisuais.estilosRejeitados || '')}</textarea></div>
      </div>

      <h3>Objetivos</h3>
      <div class="content-editor-form">
        ${objetivosLista.map(([key, label]) => `
          <label style="display:block;margin-bottom:8px">
            <input type="checkbox" id="b_obj_${key}" ${objetivos[key] ? 'checked' : ''}> ${label}
          </label>
        `).join('')}
      </div>

      <button class="btn btn-primary btn-sm" id="salvarBriefingBtn" style="margin-top:var(--space-4)">Salvar briefing</button>
    `;

    card.querySelector('#salvarBriefingBtn').addEventListener('click', async () => {
      const g = (id) => card.querySelector(id).value.trim();
      const conteudo = {
        empresa: {
          historia: g('#b_historia'), produtos: g('#b_produtos'), servicos: g('#b_servicos'),
          diferenciais: g('#b_empresaDiferenciais'), localizacao: g('#b_localizacao'),
        },
        publico: {
          perfil: g('#b_perfil'), necessidades: g('#b_necessidades'), comportamento: g('#b_comportamento'),
          desejos: g('#b_desejos'), objecoes: g('#b_objecoes'), motivadores: g('#b_motivadores'),
        },
        posicionamento: {
          percepcaoAtual: g('#b_percepcaoAtual'), percepcaoDesejada: g('#b_percepcaoDesejada'),
          concorrentes: g('#b_concorrentes'), diferenciais: g('#b_posDiferenciais'),
          promessa: g('#b_promessa'), propostaValor: g('#b_propostaValor'),
        },
        personalidade: Object.fromEntries(escalas.map(([key]) => [key, Number(card.querySelector(`#b_escala_${key}`).value)])),
        preferenciasVisuais: {
          coresPreferidas: g('#b_coresPreferidas'), coresEvitar: g('#b_coresEvitar'), tipografias: g('#b_tipografias'),
          referencias: g('#b_referencias'), estilosDesejados: g('#b_estilosDesejados'), estilosRejeitados: g('#b_estilosRejeitados'),
        },
        objetivos: Object.fromEntries(objetivosLista.map(([key]) => [key, card.querySelector(`#b_obj_${key}`).checked])),
      };
      try {
        await salvarBriefing(lead.id, conteudo);
        try { await criarAtividade({ leadId: lead.id, tipo: 'briefing_atualizado', descricao: 'Briefing atualizado.' }); } catch (e) { /* não bloqueia o salvamento do briefing */ }
        showToast('Briefing salvo.', { tone: 'ok' });
      } catch (err) {
        showToast(err.message || 'Falha ao salvar briefing.', { tone: 'danger' });
      }
    });
  }).catch((err) => {
    card.innerHTML = `<p style="color:var(--danger)">${esc(err.message)}</p>`;
  });
}

// ---------- ABA: MÉTRICAS ----------
function renderAbaMetricas(card, lead) {
  card.innerHTML = `
    <h3>Métricas registradas</h3>
    <div id="metricasHost"><p style="color:var(--text-muted);font-size:.85rem">Carregando…</p></div>

    <h3 style="margin-top:var(--space-5)">Análise e comparação de períodos</h3>
    <div id="metricasAnaliseHost"></div>

    <h3 style="margin-top:var(--space-5)">Adicionar métrica</h3>
    <div class="content-editor-form">
      <div class="field"><label for="m_nome">Nome</label><input id="m_nome" placeholder="Ex.: Seguidores no Instagram"></div>
      <div class="field"><label for="m_valor">Valor (numérico)</label><input id="m_valor" type="number" step="any"></div>
      <div class="field"><label for="m_valorTexto">Valor (texto, se não for número)</label><input id="m_valorTexto"></div>
      <div class="field"><label for="m_unidade">Unidade</label><input id="m_unidade" placeholder="Ex.: seguidores, R$, %"></div>
      <div class="field"><label for="m_origem">Origem</label><input id="m_origem" placeholder="Ex.: Instagram Insights, informado pelo cliente"></div>
      <div class="field"><label for="m_periodo">Período</label><input id="m_periodo" placeholder="Ex.: Ago/2026"></div>
      <div class="field"><label for="m_dataColeta">Data de coleta</label><input id="m_dataColeta" type="date"></div>
      <div class="field"><label for="m_definicao">Definição/fórmula</label><textarea id="m_definicao" rows="2"></textarea></div>
    </div>
    <button class="btn btn-primary btn-sm" id="addMetricaBtn">+ Adicionar métrica</button>
  `;
  const host = card.querySelector('#metricasHost');
  const analiseHost = card.querySelector('#metricasAnaliseHost');

  function renderAnalise(lista) {
    // Agrupa por nome; só compara quando existem 2+ valores NUMÉRICOS pra
    // aquele nome (não dá pra calcular variação de um valor_texto).
    const grupos = {};
    lista.forEach((m) => {
      if (m.valor == null) return;
      (grupos[m.nome] = grupos[m.nome] || []).push(m);
    });
    const comparaveis = Object.entries(grupos).filter(([, itens]) => itens.length >= 2);
    if (comparaveis.length === 0) {
      analiseHost.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Registre a mesma métrica em pelo menos 2 períodos diferentes pra ver comparação automática aqui.</p>';
      return;
    }

    const linhas = comparaveis.map(([nome, itens]) => {
      // mais antigo → mais recente, por data_coleta quando existir, senão pela ordem de criação já vinda do backend (created_at desc) invertida.
      const ordenados = [...itens].sort((a, b) => {
        const da = a.data_coleta || a.created_at, db = b.data_coleta || b.created_at;
        return new Date(da) - new Date(db);
      });
      const antigo = ordenados[0];
      const novo = ordenados[ordenados.length - 1];
      const variacaoAbsoluta = novo.valor - antigo.valor;
      const variacaoPercentual = antigo.valor !== 0 ? (variacaoAbsoluta / Math.abs(antigo.valor)) * 100 : null;
      return { nome, antigo, novo, variacaoAbsoluta, variacaoPercentual, unidade: novo.unidade || antigo.unidade || '' };
    });

    const melhor = linhas.reduce((a, b) => (b.variacaoPercentual != null && (a.variacaoPercentual == null || b.variacaoPercentual > a.variacaoPercentual) ? b : a), linhas[0]);
    const atencao = linhas.reduce((a, b) => (b.variacaoPercentual != null && (a.variacaoPercentual == null || b.variacaoPercentual < a.variacaoPercentual) ? b : a), linhas[0]);

    analiseHost.innerHTML = `
      <div class="table-wrap"><table class="app-table">
        <thead><tr><th>Métrica</th><th>Mais antigo</th><th>Mais recente</th><th>Variação</th></tr></thead>
        <tbody>
          ${linhas.map((l) => `
            <tr>
              <td>${esc(l.nome)}${l.nome === melhor.nome && melhor.variacaoPercentual > 0 ? ' <span class="badge badge-ok">Melhor desempenho</span>' : ''}${l.nome === atencao.nome && atencao.variacaoPercentual < 0 ? ' <span class="badge badge-danger">Ponto de atenção</span>' : ''}</td>
              <td>${l.antigo.valor}${l.unidade ? ' ' + esc(l.unidade) : ''} <span style="color:var(--text-muted);font-size:.75rem">(${esc(l.antigo.periodo) || formatarData(l.antigo.data_coleta)})</span></td>
              <td>${l.novo.valor}${l.unidade ? ' ' + esc(l.unidade) : ''} <span style="color:var(--text-muted);font-size:.75rem">(${esc(l.novo.periodo) || formatarData(l.novo.data_coleta)})</span></td>
              <td>${l.variacaoAbsoluta > 0 ? '+' : ''}${l.variacaoAbsoluta}${l.unidade ? ' ' + esc(l.unidade) : ''} ${l.variacaoPercentual != null ? `(${l.variacaoPercentual > 0 ? '+' : ''}${l.variacaoPercentual.toFixed(1)}%)` : ''}</td>
            </tr>
          `).join('')}
        </tbody>
      </table></div>
      <p style="color:var(--text-muted);font-size:.74rem;margin-top:8px">Fórmula: variação percentual = (mais recente − mais antigo) ÷ |mais antigo| × 100. Compara sempre o primeiro e o último registro de cada métrica, por data de coleta.</p>
    `;
  }

  function renderLista(lista) {
    renderAnalise(lista);
    if (lista.length === 0) {
      host.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Nenhuma métrica registrada ainda.</p>';
      return;
    }
    host.innerHTML = `<div class="table-wrap"><table class="app-table"><thead><tr><th>Nome</th><th>Valor</th><th>Origem</th><th>Período</th><th>Coletado em</th><th></th></tr></thead><tbody>
      ${lista.map((m) => `
        <tr>
          <td>${esc(m.nome)}</td>
          <td>${m.valor != null ? m.valor : esc(m.valor_texto || '—')}${m.unidade ? ' ' + esc(m.unidade) : ''}</td>
          <td>${esc(m.origem || '—')}</td>
          <td>${esc(m.periodo || '—')}</td>
          <td>${m.data_coleta ? formatarData(m.data_coleta) : '—'}</td>
          <td><button class="btn btn-ghost btn-sm" data-del="${m.id}">Excluir</button></td>
        </tr>
      `).join('')}
    </tbody></table></div>`;
    host.querySelectorAll('[data-del]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try { await removerMetrica(btn.dataset.del); carregar(); } catch (err) { showToast(err.message, { tone: 'danger' }); }
      });
    });
  }

  function carregar() {
    listarMetricas(lead.id).then(renderLista).catch((err) => {
      host.innerHTML = `<p style="color:var(--danger);font-size:.85rem">${esc(err.message)}</p>`;
    });
  }

  card.querySelector('#addMetricaBtn').addEventListener('click', async () => {
    const nome = card.querySelector('#m_nome').value.trim();
    if (!nome) { showToast('Informe o nome da métrica.', { tone: 'danger' }); return; }
    const valorRaw = card.querySelector('#m_valor').value;
    try {
      await criarMetrica({
        leadId: lead.id,
        nome,
        valor: valorRaw !== '' ? Number(valorRaw) : undefined,
        valorTexto: card.querySelector('#m_valorTexto').value.trim(),
        unidade: card.querySelector('#m_unidade').value.trim(),
        origem: card.querySelector('#m_origem').value.trim(),
        periodo: card.querySelector('#m_periodo').value.trim(),
        dataColeta: card.querySelector('#m_dataColeta').value || undefined,
        definicao: card.querySelector('#m_definicao').value.trim(),
      });
      showToast('Métrica registrada.', { tone: 'ok' });
      carregar();
    } catch (err) {
      showToast(err.message || 'Falha ao registrar métrica.', { tone: 'danger' });
    }
  });

  carregar();
}

// ---------- ABA: DIAGNÓSTICO ----------
const SECOES_DIAGNOSTICO = [
  ['dado_fornecido', 'Dado fornecido', 'Só o que foi informado pelo cliente ou coletado como métrica — nunca invente um número aqui.'],
  ['calculo', 'Cálculo', 'Contas feitas em cima dos dados acima (fórmula visível, sem opinião).'],
  ['analise_ia', 'Análise da IA', 'Interpretação gerada por IA a partir do que já está em "Dado fornecido"/"Cálculo" — nunca deve introduzir números novos.'],
  ['analise_especialista', 'Análise do especialista', 'Sua leitura humana do caso.'],
  ['recomendacao', 'Recomendação', 'O que propor ao cliente a partir de tudo acima.'],
];

function renderAbaDiagnostico(card, lead) {
  card.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Carregando…</p>';

  let versoes = [];
  let versaoAtual = null;

  function renderSeletor() {
    const seletorHtml = `
      <div style="display:flex;gap:var(--space-2);align-items:center;margin-bottom:var(--space-4);flex-wrap:wrap">
        <select id="d_versaoSelect">
          ${versoes.map((v) => `<option value="${v.id}" ${v.id === versaoAtual.id ? 'selected' : ''}>v${v.versao} — ${v.status === 'publicado' ? 'Publicado' : 'Rascunho'}</option>`).join('')}
        </select>
        <button class="btn btn-ghost btn-sm" id="d_novaVersaoBtn">+ Nova versão</button>
        ${versaoAtual.status === 'rascunho' ? '<button class="btn btn-primary btn-sm" id="d_publicarBtn">Publicar esta versão</button>' : '<span class="badge badge-ok">Publicado — congelado</span>'}
      </div>
    `;
    return seletorHtml;
  }

  function renderConteudoVersao() {
    const c = versaoAtual.conteudo || {};
    const bloqueado = versaoAtual.status === 'publicado';
    card.innerHTML = renderSeletor()
      + (bloqueado ? '' : `
        <p style="font-size:.82rem;color:var(--text-muted);margin-bottom:var(--space-3)">
          <button class="btn btn-ghost btn-sm" id="d_gerarIaBtn">✦ Gerar rascunho com IA</button>
          — usa só o que já está no Briefing e nas Métricas deste cliente; nunca inventa número. Revise sempre antes de salvar.
        </p>
      `)
      + SECOES_DIAGNOSTICO.map(([key, label, ajuda]) => {
      const secao = c[key] || { texto: '', visibilidade: 'interna' };
      return `
        <div class="card" style="margin-bottom:var(--space-3);background:var(--bg-soft)">
          <div class="card-head" style="display:flex;justify-content:space-between;align-items:center">
            <h4 style="margin:0">${label}</h4>
            <select id="d_vis_${key}" ${bloqueado ? 'disabled' : ''}>
              <option value="interna" ${secao.visibilidade === 'interna' ? 'selected' : ''}>Interna</option>
              <option value="visivel_cliente" ${secao.visibilidade === 'visivel_cliente' ? 'selected' : ''}>Visível ao cliente</option>
            </select>
          </div>
          <p style="color:var(--text-muted);font-size:.78rem;margin:4px 0 8px">${ajuda}</p>
          <textarea id="d_texto_${key}" rows="3" style="width:100%" ${bloqueado ? 'disabled' : ''}>${esc(secao.texto || '')}</textarea>
        </div>
      `;
    }).join('') + (bloqueado ? '' : '<button class="btn btn-primary btn-sm" id="d_salvarBtn">Salvar versão</button>');

    card.querySelector('#d_versaoSelect').addEventListener('change', (e) => {
      versaoAtual = versoes.find((v) => v.id === e.target.value);
      renderConteudoVersao();
    });
    card.querySelector('#d_novaVersaoBtn').addEventListener('click', criarVersao);
    const publicarBtn = card.querySelector('#d_publicarBtn');
    if (publicarBtn) publicarBtn.addEventListener('click', publicar);
    const salvarBtn = card.querySelector('#d_salvarBtn');
    if (salvarBtn) salvarBtn.addEventListener('click', salvar);
    const gerarIaBtn = card.querySelector('#d_gerarIaBtn');
    if (gerarIaBtn) gerarIaBtn.addEventListener('click', gerarComIA);
  }

  async function gerarComIA() {
    const btn = card.querySelector('#d_gerarIaBtn');
    if (btn) { btn.disabled = true; btn.textContent = 'Gerando…'; }
    try {
      const [briefing, metricas] = await Promise.all([
        obterBriefing(lead.id).catch(() => null),
        listarMetricas(lead.id).catch(() => []),
      ]);
      const rascunho = await gerarRascunhoDiagnosticoIA({
        empresa: lead.empresa,
        setor: lead.setor,
        briefing: briefing ? briefing.conteudo : null,
        metricas,
      });
      if (rascunho.dadosInsuficientes) {
        showToast('Dados insuficientes: ' + (rascunho.motivoDadosInsuficientes || 'preencha o briefing ou registre métricas antes.'), { tone: 'danger' });
      }
      const setTexto = (id, valor) => { const el = card.querySelector(id); if (el && valor) el.value = valor; };
      setTexto('#d_texto_dado_fornecido', rascunho.dadoFornecido.join('\n'));
      setTexto('#d_texto_calculo', rascunho.calculo.map((c) => `${c.formula} = ${c.resultado}`).join('\n'));
      setTexto('#d_texto_analise_ia', rascunho.interpretacao);
      setTexto('#d_texto_recomendacao', rascunho.recomendacao);
      showToast('Rascunho gerado — revise antes de salvar.', { tone: 'ok' });
    } catch (err) {
      showToast(err.message || 'Falha ao gerar com IA.', { tone: 'danger' });
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = '✦ Gerar rascunho com IA'; }
    }
  }

  async function salvar() {
    const conteudo = {};
    SECOES_DIAGNOSTICO.forEach(([key]) => {
      conteudo[key] = {
        texto: card.querySelector(`#d_texto_${key}`).value,
        visibilidade: card.querySelector(`#d_vis_${key}`).value,
      };
    });
    try {
      versaoAtual = await salvarDiagnostico(versaoAtual.id, conteudo);
      versoes = versoes.map((v) => (v.id === versaoAtual.id ? versaoAtual : v));
      showToast('Diagnóstico salvo.', { tone: 'ok' });
    } catch (err) {
      showToast(err.message || 'Falha ao salvar diagnóstico.', { tone: 'danger' });
    }
  }

  async function publicar() {
    try {
      versaoAtual = await publicarDiagnostico(versaoAtual.id);
      versoes = versoes.map((v) => (v.id === versaoAtual.id ? versaoAtual : v));
      try { await criarAtividade({ leadId: lead.id, tipo: 'diagnostico_publicado', descricao: `Diagnóstico v${versaoAtual.versao} publicado.` }); } catch (e) { /* não bloqueia */ }
      showToast('Diagnóstico publicado — esta versão está congelada.', { tone: 'ok' });
      renderConteudoVersao();
    } catch (err) {
      showToast(err.message || 'Falha ao publicar.', { tone: 'danger' });
    }
  }

  async function criarVersao() {
    try {
      const nova = await criarNovaVersaoDiagnostico(lead.id);
      versoes = [nova, ...versoes];
      versaoAtual = nova;
      try { await criarAtividade({ leadId: lead.id, tipo: 'diagnostico_criado', descricao: `Diagnóstico v${nova.versao} criado.` }); } catch (e) { /* não bloqueia */ }
      renderConteudoVersao();
    } catch (err) {
      showToast(err.message || 'Falha ao criar nova versão.', { tone: 'danger' });
    }
  }

  listarDiagnosticos(lead.id).then(async (lista) => {
    versoes = lista;
    if (versoes.length === 0) {
      card.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Nenhum diagnóstico ainda.</p><button class="btn btn-primary btn-sm" id="d_criarPrimeiraBtn">Criar primeira versão</button>';
      card.querySelector('#d_criarPrimeiraBtn').addEventListener('click', criarVersao);
      return;
    }
    versaoAtual = versoes[0];
    renderConteudoVersao();
  }).catch((err) => {
    card.innerHTML = `<p style="color:var(--danger)">${esc(err.message)}</p>`;
  });
}

// ---------- ABA: APRESENTAÇÃO ----------
function linhasParaLista(texto) {
  return String(texto || '')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
}

function fileParaDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function renderAbaApresentacao(card, lead) {
  card.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Carregando…</p>';

  let versoes = [];
  let versaoAtual = null;
  let logoDataUrl = '';

  async function montarSugestao() {
    const [briefing, diagnosticos, metricas] = await Promise.all([
      obterBriefing(lead.id).catch(() => null),
      listarDiagnosticos(lead.id).catch(() => []),
      listarMetricas(lead.id).catch(() => []),
    ]);
    const b = (briefing && briefing.conteudo) || {};
    const diagPublicado = diagnosticos.find((d) => d.status === 'publicado');
    const secoesVisiveis = {};
    if (diagPublicado) {
      Object.entries(diagPublicado.conteudo || {}).forEach(([k, v]) => {
        if (v && v.visibilidade === 'visivel_cliente' && v.texto) secoesVisiveis[k] = v.texto;
      });
    }

    return {
      capa: {
        titulo: 'Diagnóstico Estratégico da Marca',
        subtitulo: lead.empresa,
        data: new Date().toISOString().slice(0, 10),
        // Fase 3: o hero diz QUEM, ONDE e O QUÊ (dado do CRM, não inventado)
        localizacao: [lead.cidade, lead.uf].filter(Boolean).join(' · ') || '',
      },
      sobreEmpresa: {
        incluir: Boolean(b.empresa),
        contexto: (b.empresa && b.empresa.historia) || '',
        segmento: lead.setor || '',
        produtos: (b.empresa && b.empresa.produtos) || '',
        diferenciais: (b.empresa && b.empresa.diferenciais) || '',
      },
      presencaAtual: {
        incluir: true,
        instagram: lead.instagram || '',
        site: lead.site || '',
        identidade: '',
        comunicacao: '',
        posicionamento: (b.posicionamento && b.posicionamento.percepcaoAtual) || '',
      },
      metricasIds: metricas.map((m) => m.id),
      metricasDisponiveis: metricas,
      interpretacao: secoesVisiveis.dado_fornecido
        ? [{ dado: secoesVisiveis.dado_fornecido, significado: secoesVisiveis.analise_especialista || secoesVisiveis.analise_ia || '', impacto: secoesVisiveis.recomendacao || '' }]
        : [],
      oportunidades: secoesVisiveis.recomendacao || '',
      direcaoEstrategica: {
        incluir: Boolean(b.posicionamento),
        posicionamento: (b.posicionamento && b.posicionamento.percepcaoDesejada) || '',
        percepcaoDesejada: (b.posicionamento && b.posicionamento.promessa) || '',
        diferenciacao: (b.posicionamento && b.posicionamento.diferenciais) || '',
        comunicacao: (b.posicionamento && b.posicionamento.propostaValor) || '',
      },
      direcaoVisual: {
        incluir: Boolean(b.preferenciasVisuais),
        cores: (b.preferenciasVisuais && b.preferenciasVisuais.coresPreferidas) || '',
        tipografia: (b.preferenciasVisuais && b.preferenciasVisuais.tipografias) || '',
        referencias: (b.preferenciasVisuais && b.preferenciasVisuais.referencias) || '',
      },
      proximosPassos: '',
    };
  }

  function temaAtual() {
    return (versaoAtual && versaoAtual.tema) || {
      primaryColor: '#161F30', secondaryColor: '#3D3D3D', accentColor: '#C9A667', backgroundColor: '#F7F5F0', fonte: 'Manrope', logo: '',
    };
  }

  function renderEditor() {
    const c = versaoAtual.conteudo || {};
    const tema = temaAtual();
    const bloqueado = versaoAtual.status === 'publicado';
    const metricasDisponiveis = c.metricasDisponiveis || [];
    const metricasSelecionadas = new Set(c.metricasIds || []);
    logoDataUrl = tema.logo || '';

    const linkPublico = `${window.location.origin}/apresentacao/${versaoAtual.slug}`;

    card.innerHTML = `
      <div style="display:flex;gap:var(--space-2);align-items:center;margin-bottom:var(--space-4);flex-wrap:wrap">
        <select id="ap_versaoSelect">
          ${versoes.map((v) => `<option value="${v.id}" ${v.id === versaoAtual.id ? 'selected' : ''}>v${v.versao} — ${v.status === 'publicado' ? 'Publicado' : 'Rascunho'}</option>`).join('')}
        </select>
        <button class="btn btn-ghost btn-sm" id="ap_novaVersaoBtn">+ Nova versão (a partir do briefing/diagnóstico atual)</button>
        ${versaoAtual.status === 'rascunho' ? '<button class="btn btn-primary btn-sm" id="ap_publicarBtn">Publicar</button>' : '<span class="badge badge-ok">Publicado</span>'}
      </div>
      ${versaoAtual.status === 'publicado' || versaoAtual.publicado_em || versaoAtual.slug
        ? `<p style="font-size:.85rem">Link público: <a href="${esc(safeUrl(linkPublico))}" target="_blank" rel="noopener noreferrer">${esc(linkPublico)}</a></p>`
        : ''}
      <p style="color:var(--text-muted);font-size:.8rem">Nada aqui vai pro cliente até você clicar em "Publicar". Rascunhos são só seus.</p>

      <h3 style="margin-top:var(--space-4)">Capa</h3>
      <div class="content-editor-form">
        <div class="field"><label for="ap_capaTitulo">Título</label><input id="ap_capaTitulo" value="${esc(c.capa?.titulo || '')}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_logoFile">Logo do cliente (opcional — se vazio, usa a marca Felipe Branding)</label>
          <input type="file" id="ap_logoFile" accept="image/*" ${bloqueado ? 'disabled' : ''}>
          ${safeUrl(logoDataUrl) ? `<img src="${esc(safeUrl(logoDataUrl))}" alt="Logo atual" style="height:40px;margin-top:6px">` : ''}
        </div>
      </div>

      <h3>Sobre a empresa <label style="font-size:.78rem;color:var(--text-muted)"><input type="checkbox" id="ap_sobreIncluir" ${c.sobreEmpresa?.incluir ? 'checked' : ''} ${bloqueado ? 'disabled' : ''}> incluir esta seção</label></h3>
      <div class="content-editor-form">
        <div class="field"><label for="ap_contexto">Contexto</label><textarea id="ap_contexto" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.sobreEmpresa?.contexto || '')}</textarea></div>
        <div class="field"><label for="ap_segmento">Segmento</label><input id="ap_segmento" value="${esc(c.sobreEmpresa?.segmento || '')}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_produtos">Produtos</label><textarea id="ap_produtos" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.sobreEmpresa?.produtos || '')}</textarea></div>
        <div class="field"><label for="ap_sobreDiferenciais">Diferenciais</label><textarea id="ap_sobreDiferenciais" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.sobreEmpresa?.diferenciais || '')}</textarea></div>
      </div>

      <h3>Presença atual <label style="font-size:.78rem;color:var(--text-muted)"><input type="checkbox" id="ap_presencaIncluir" ${c.presencaAtual?.incluir ? 'checked' : ''} ${bloqueado ? 'disabled' : ''}> incluir esta seção</label></h3>
      <div class="content-editor-form">
        <div class="field"><label for="ap_instagram">Instagram</label><input id="ap_instagram" value="${esc(c.presencaAtual?.instagram || '')}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_site">Site</label><input id="ap_site" value="${esc(c.presencaAtual?.site || '')}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_identidade">Identidade</label><textarea id="ap_identidade" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.presencaAtual?.identidade || '')}</textarea></div>
        <div class="field"><label for="ap_comunicacao">Comunicação</label><textarea id="ap_comunicacao" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.presencaAtual?.comunicacao || '')}</textarea></div>
        <div class="field"><label for="ap_posicionamentoAtual">Posicionamento</label><textarea id="ap_posicionamentoAtual" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.presencaAtual?.posicionamento || '')}</textarea></div>
      </div>

      <h3>Dados e métricas <span style="font-size:.78rem;color:var(--text-muted)">(marque quais entram na apresentação)</span></h3>
      <div>
        ${metricasDisponiveis.length === 0
          ? '<p style="color:var(--text-muted);font-size:.85rem">Nenhuma métrica registrada na aba Métricas ainda.</p>'
          : metricasDisponiveis.map((m) => `
            <label style="display:block;margin-bottom:6px;font-size:.85rem">
              <input type="checkbox" class="ap_metrica_chk" data-id="${m.id}" ${metricasSelecionadas.has(m.id) ? 'checked' : ''} ${bloqueado ? 'disabled' : ''}>
              ${esc(m.nome)}: <strong>${m.valor != null ? esc(m.valor) : esc(m.valor_texto || '—')}${m.unidade ? ' ' + esc(m.unidade) : ''}</strong> ${m.periodo ? '(' + esc(m.periodo) + ')' : ''}
            </label>
          `).join('')}
      </div>

      <h3 style="margin-top:var(--space-4)">Interpretação (dado → significado → impacto)</h3>
      <div id="ap_interpretacaoHost"></div>
      <button class="btn btn-ghost btn-sm" id="ap_addInterpretacaoBtn" ${bloqueado ? 'disabled' : ''}>+ Adicionar linha</button>

      <h3 style="margin-top:var(--space-4)">Oportunidades <span style="font-size:.78rem;color:var(--text-muted)">(uma por linha)</span></h3>
      <div class="field"><textarea id="ap_oportunidades" rows="4" ${bloqueado ? 'disabled' : ''}>${esc(c.oportunidades || '')}</textarea></div>

      <h3>Direção estratégica <label style="font-size:.78rem;color:var(--text-muted)"><input type="checkbox" id="ap_direcaoEstIncluir" ${c.direcaoEstrategica?.incluir ? 'checked' : ''} ${bloqueado ? 'disabled' : ''}> incluir esta seção</label></h3>
      <div class="content-editor-form">
        <div class="field"><label for="ap_deposicionamento">Posicionamento</label><textarea id="ap_deposicionamento" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.direcaoEstrategica?.posicionamento || '')}</textarea></div>
        <div class="field"><label for="ap_depercepcao">Percepção desejada</label><textarea id="ap_depercepcao" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.direcaoEstrategica?.percepcaoDesejada || '')}</textarea></div>
        <div class="field"><label for="ap_dediferenciacao">Diferenciação</label><textarea id="ap_dediferenciacao" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.direcaoEstrategica?.diferenciacao || '')}</textarea></div>
        <div class="field"><label for="ap_decomunicacao">Comunicação</label><textarea id="ap_decomunicacao" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.direcaoEstrategica?.comunicacao || '')}</textarea></div>
      </div>

      <h3>Direção visual <label style="font-size:.78rem;color:var(--text-muted)"><input type="checkbox" id="ap_direcaoVisIncluir" ${c.direcaoVisual?.incluir ? 'checked' : ''} ${bloqueado ? 'disabled' : ''}> incluir esta seção</label></h3>
      <div class="content-editor-form">
        <div class="field"><label for="ap_dvcores">Cores</label><input id="ap_dvcores" value="${c.direcaoVisual?.cores || ''}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_dvtipografia">Tipografia</label><input id="ap_dvtipografia" value="${c.direcaoVisual?.tipografia || ''}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_dvreferencias">Referências</label><textarea id="ap_dvreferencias" rows="2" ${bloqueado ? 'disabled' : ''}>${esc(c.direcaoVisual?.referencias || '')}</textarea></div>
      </div>

      <h3>Próximos passos <span style="font-size:.78rem;color:var(--text-muted)">(um por linha, na ordem de prioridade · opcional: <code>Ação | Objetivo | Indicador</code>)</span></h3>
      <div class="field"><textarea id="ap_proximosPassos" rows="4" ${bloqueado ? 'disabled' : ''}>${esc(c.proximosPassos || '')}</textarea></div>

      <h3 style="margin-top:var(--space-4)">Cores da apresentação (identidade adaptada — a marca Felipe Branding continua presente no rodapé)</h3>
      <div class="content-editor-form">
        <div class="field"><label for="ap_corPrimaria">Cor primária</label><input type="color" id="ap_corPrimaria" value="${esc(tema.primaryColor || '#161F30')}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_corSecundaria">Cor secundária</label><input type="color" id="ap_corSecundaria" value="${esc(tema.secondaryColor || '#3D3D3D')}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_corDestaque">Cor de destaque</label><input type="color" id="ap_corDestaque" value="${esc(tema.accentColor || '#C9A667')}" ${bloqueado ? 'disabled' : ''}></div>
        <div class="field"><label for="ap_corFundo">Cor de fundo</label><input type="color" id="ap_corFundo" value="${esc(tema.backgroundColor || '#F7F5F0')}" ${bloqueado ? 'disabled' : ''}></div>
      </div>

      ${bloqueado ? '' : '<button class="btn btn-primary btn-sm" id="ap_salvarBtn" style="margin-top:var(--space-4)">Salvar rascunho</button>'}
    `;

    const interpHost = card.querySelector('#ap_interpretacaoHost');
    let interpretacaoRows = (c.interpretacao || []).slice();
    function renderInterp() {
      interpHost.innerHTML = interpretacaoRows.map((row, i) => `
        <div class="content-editor-form" style="border:1px solid var(--border);border-radius:var(--radius-md);padding:var(--space-3);margin-bottom:var(--space-2)">
          <div class="field"><label>Dado</label><textarea aria-label="Dado" rows="2" class="ap_interp_dado" data-i="${i}" ${bloqueado ? 'disabled' : ''}>${esc(row.dado || '')}</textarea></div>
          <div class="field"><label>Significado</label><textarea aria-label="Significado" rows="2" class="ap_interp_significado" data-i="${i}" ${bloqueado ? 'disabled' : ''}>${esc(row.significado || '')}</textarea></div>
          <div class="field"><label>Impacto</label><textarea aria-label="Impacto" rows="2" class="ap_interp_impacto" data-i="${i}" ${bloqueado ? 'disabled' : ''}>${esc(row.impacto || '')}</textarea></div>
          ${bloqueado ? '' : `<button class="btn btn-ghost btn-sm" data-remove-interp="${i}">Remover linha</button>`}
        </div>
      `).join('') || '<p style="color:var(--text-muted);font-size:.85rem">Nenhuma linha ainda.</p>';
      interpHost.querySelectorAll('[data-remove-interp]').forEach((btn) => {
        btn.addEventListener('click', () => {
          interpretacaoRows.splice(Number(btn.dataset.removeInterp), 1);
          renderInterp();
        });
      });
    }
    renderInterp();
    const addInterpBtn = card.querySelector('#ap_addInterpretacaoBtn');
    if (addInterpBtn) addInterpBtn.addEventListener('click', () => {
      interpretacaoRows.push({ dado: '', significado: '', impacto: '' });
      renderInterp();
    });

    card.querySelector('#ap_versaoSelect').addEventListener('change', (e) => {
      versaoAtual = versoes.find((v) => v.id === e.target.value);
      renderEditor();
    });
    card.querySelector('#ap_novaVersaoBtn').addEventListener('click', criarVersao);
    const logoInput = card.querySelector('#ap_logoFile');
    if (logoInput) logoInput.addEventListener('change', async () => {
      const file = logoInput.files[0];
      if (file) logoDataUrl = await fileParaDataUrl(file);
    });
    const publicarBtn = card.querySelector('#ap_publicarBtn');
    if (publicarBtn) publicarBtn.addEventListener('click', publicar);
    const salvarBtn = card.querySelector('#ap_salvarBtn');
    if (salvarBtn) salvarBtn.addEventListener('click', () => salvar(interpretacaoRows, metricasDisponiveis));
  }

  async function salvar(interpretacaoRows, metricasDisponiveis) {
    const g = (id) => card.querySelector(id).value.trim();
    const metricasIds = Array.from(card.querySelectorAll('.ap_metrica_chk:checked')).map((el) => el.dataset.id);
    const conteudo = {
      capa: { titulo: g('#ap_capaTitulo'), subtitulo: lead.empresa, data: new Date().toISOString().slice(0, 10), localizacao: [lead.cidade, lead.uf].filter(Boolean).join(' · ') || '' },
      sobreEmpresa: {
        incluir: card.querySelector('#ap_sobreIncluir').checked,
        contexto: g('#ap_contexto'), segmento: g('#ap_segmento'), produtos: g('#ap_produtos'), diferenciais: g('#ap_sobreDiferenciais'),
      },
      presencaAtual: {
        incluir: card.querySelector('#ap_presencaIncluir').checked,
        instagram: g('#ap_instagram'), site: g('#ap_site'), identidade: g('#ap_identidade'),
        comunicacao: g('#ap_comunicacao'), posicionamento: g('#ap_posicionamentoAtual'),
      },
      metricasIds,
      metricasDisponiveis,
      interpretacao: interpretacaoRows.map((_, i) => ({
        dado: card.querySelector(`.ap_interp_dado[data-i="${i}"]`)?.value.trim() || '',
        significado: card.querySelector(`.ap_interp_significado[data-i="${i}"]`)?.value.trim() || '',
        impacto: card.querySelector(`.ap_interp_impacto[data-i="${i}"]`)?.value.trim() || '',
      })).filter((r) => r.dado || r.significado || r.impacto),
      oportunidades: g('#ap_oportunidades'),
      direcaoEstrategica: {
        incluir: card.querySelector('#ap_direcaoEstIncluir').checked,
        posicionamento: g('#ap_deposicionamento'), percepcaoDesejada: g('#ap_depercepcao'),
        diferenciacao: g('#ap_dediferenciacao'), comunicacao: g('#ap_decomunicacao'),
      },
      direcaoVisual: {
        incluir: card.querySelector('#ap_direcaoVisIncluir').checked,
        cores: g('#ap_dvcores'), tipografia: g('#ap_dvtipografia'), referencias: g('#ap_dvreferencias'),
      },
      proximosPassos: g('#ap_proximosPassos'),
    };
    const tema = {
      primaryColor: card.querySelector('#ap_corPrimaria').value,
      secondaryColor: card.querySelector('#ap_corSecundaria').value,
      accentColor: card.querySelector('#ap_corDestaque').value,
      backgroundColor: card.querySelector('#ap_corFundo').value,
      fonte: 'Manrope',
      logo: logoDataUrl,
    };
    try {
      versaoAtual = await salvarApresentacao(versaoAtual.id, { conteudo, tema });
      versoes = versoes.map((v) => (v.id === versaoAtual.id ? versaoAtual : v));
      showToast('Rascunho salvo.', { tone: 'ok' });
      renderEditor();
    } catch (err) {
      showToast(err.message || 'Falha ao salvar.', { tone: 'danger' });
    }
  }

  async function publicar() {
    try {
      versaoAtual = await publicarApresentacao(versaoAtual.id);
      versoes = versoes.map((v) => (v.id === versaoAtual.id ? versaoAtual : v));
      try { await criarAtividade({ leadId: lead.id, tipo: 'apresentacao_enviada', descricao: `Apresentação v${versaoAtual.versao} publicada.` }); } catch (e) { /* não bloqueia */ }
      showToast('Apresentação publicada — o link já está no ar.', { tone: 'ok' });
      renderEditor();
    } catch (err) {
      showToast(err.message || 'Falha ao publicar.', { tone: 'danger' });
    }
  }

  async function criarVersao() {
    try {
      const sugestao = await montarSugestao();
      const nova = await criarNovaVersaoApresentacao(lead.id, lead.empresa, { conteudo: sugestao, tema: temaAtual() });
      versoes = [nova, ...versoes];
      versaoAtual = nova;
      renderEditor();
    } catch (err) {
      showToast(err.message || 'Falha ao criar nova versão.', { tone: 'danger' });
    }
  }

  try {
    versoes = await listarApresentacoes(lead.id);
    if (versoes.length === 0) {
      card.innerHTML = `
        <h3>Apresentação para o cliente</h3>
        <p style="color:var(--text-muted)">Nenhuma apresentação criada ainda. Ao criar, eu já sugiro o conteúdo a partir do briefing e do diagnóstico publicado — nada vai pro cliente até você publicar.</p>
        <button class="btn btn-primary btn-sm" id="ap_criarPrimeiraBtn">Criar primeira versão</button>
      `;
      card.querySelector('#ap_criarPrimeiraBtn').addEventListener('click', criarVersao);
      return;
    }
    versaoAtual = versoes[0];
    renderEditor();
  } catch (err) {
    card.innerHTML = `<p style="color:var(--danger)">${esc(err.message)}</p>`;
  }
}

// ---------- ABA: HISTÓRICO (linha do tempo) ----------
const TIPO_ATIVIDADE_LABEL = {
  email_enviado: 'E-mail enviado', whatsapp_enviado: 'WhatsApp enviado', ligacao: 'Ligação',
  follow_up: 'Follow-up', resposta_recebida: 'Resposta recebida', reuniao_marcada: 'Reunião marcada',
  reuniao_realizada: 'Reunião realizada', proposta_enviada: 'Proposta enviada', negociacao: 'Negociação',
  nota: 'Nota', briefing_atualizado: 'Briefing atualizado', diagnostico_criado: 'Diagnóstico criado',
  diagnostico_publicado: 'Diagnóstico publicado', apresentacao_enviada: 'Apresentação enviada',
  mudanca_status: 'Status atualizado',
};

function renderAbaHistorico(card, lead) {
  card.innerHTML = `
    <h3>Linha do tempo</h3>
    <div id="historicoHost"><p style="color:var(--text-muted);font-size:.85rem">Carregando…</p></div>
    <h3 style="margin-top:var(--space-5)">Registrar novo evento</h3>
    <div class="content-editor-form">
      <div class="field">
        <label for="h_tipo">Tipo</label>
        <select id="h_tipo">${Object.entries(TIPO_ATIVIDADE_LABEL).map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select>
      </div>
      <div class="field"><label for="h_descricao">Descrição</label><textarea id="h_descricao" rows="2"></textarea></div>
      <div class="field"><label for="h_objecao">Objeção levantada pelo cliente (opcional)</label><input id="h_objecao" placeholder="Ex.: achou o prazo longo, preço acima do esperado…"></div>
      <div class="field"><label for="h_proximaEm">Próximo contato (opcional)</label><input id="h_proximaEm" type="date"></div>
    </div>
    <button class="btn btn-primary btn-sm" id="h_addBtn">+ Registrar</button>
  `;
  const host = card.querySelector('#historicoHost');

  function renderLinha(lista) {
    if (lista.length === 0) {
      host.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Nenhum evento registrado ainda.</p>';
      return;
    }
    host.innerHTML = `<ol style="list-style:none;padding:0;margin:0;border-left:2px solid var(--border);padding-left:var(--space-4)">
      ${lista.map((a) => `
        <li style="margin-bottom:var(--space-3)">
          <div style="font-size:.78rem;color:var(--text-muted)">${formatarData(a.data)}</div>
          <div><strong>${esc(TIPO_ATIVIDADE_LABEL[a.tipo] || a.tipo)}</strong>${a.descricao ? ' — ' + esc(a.descricao) : ''}</div>
          ${a.objecao ? `<div style="font-size:.82rem;color:var(--danger);margin-top:2px">Objeção: ${esc(a.objecao)}</div>` : ''}
        </li>
      `).join('')}
    </ol>`;
  }

  function carregar() {
    listarAtividades(lead.id).then(renderLinha).catch((err) => {
      host.innerHTML = `<p style="color:var(--danger);font-size:.85rem">${esc(err.message)}</p>`;
    });
  }

  card.querySelector('#h_addBtn').addEventListener('click', async () => {
    try {
      await criarAtividade({
        leadId: lead.id,
        tipo: card.querySelector('#h_tipo').value,
        descricao: card.querySelector('#h_descricao').value.trim(),
        objecao: card.querySelector('#h_objecao').value.trim() || undefined,
        proximaEm: card.querySelector('#h_proximaEm').value || undefined,
      });
      showToast('Evento registrado.', { tone: 'ok' });
      carregar();
    } catch (err) {
      showToast(err.message || 'Falha ao registrar evento.', { tone: 'danger' });
    }
  });

  carregar();
}
