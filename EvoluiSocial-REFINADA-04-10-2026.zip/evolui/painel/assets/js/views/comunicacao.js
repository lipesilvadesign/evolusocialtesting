/**
 * Comunicação da equipe (pedido do Felipe, 13/09) — "criar uma aba de
 * comentários... onde a gente entra em comunicação pra equipe que está
 * cadastrado no painel". Um canal único, visível pra qualquer funcionário
 * ativo (não é admin-only) — diferente da maioria das outras telas deste
 * painel. Mensagem enviada é definitiva; só admin apaga (moderação).
 *
 * Lista de mensagens atualiza por polling (mesmo espírito de outras telas
 * com progresso "ao vivo" no projeto). O indicador "Fulano está
 * digitando…" (pedido 13/09, 2ª rodada) é a ÚNICA parte deste projeto que
 * usa Supabase Realtime (Broadcast efêmero — sem tabela nova, sem RLS: a
 * mensagem "digitando" nunca é gravada em lugar nenhum, só passa pelos
 * clientes conectados no momento). AVISO HONESTO: eu não tenho como testar
 * isto de ponta a ponta contra o projeto de produção (sem acesso ao
 * Supabase real) — a lista de mensagens em si (polling) funciona
 * independentemente disso; se o indicador de digitação não aparecer depois
 * do deploy, o mural continua 100% funcional do mesmo jeito.
 */
import { LoadingState } from '../components/LoadingState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { getCurrentUser, getSupabaseClient } from '../services/auth.js';
import { ehAdmin } from '../services/rbac.js';
import { listarFuncionarios } from '../services/funcionariosClient.js';
import { listarMensagens, enviarMensagem, excluirMensagem } from '../services/equipeMensagensClient.js';
import { marcarMuralVisto, atualizarBadgeMural } from '../services/muralStatus.js';

const INTERVALO_ATUALIZACAO_MS = 20000;
const CANAL_DIGITANDO = 'mural-digitando';
const THROTTLE_ENVIO_DIGITANDO_MS = 2000;
const TEMPO_LIMITE_DIGITANDO_MS = 4000;
let intervaloAtivo = null;

function iniciaisDe(nome) {
  const partes = (nome || '?').trim().split(/\s+/).filter(Boolean);
  if (partes.length >= 2) return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase();
  return (nome || '?').slice(0, 2).toUpperCase();
}

// O nome do autor agora é autoeditável por qualquer funcionário (Meu
// Perfil) — nunca inserir em innerHTML sem escapar, senão um funcionário
// poderia injetar HTML/JS que executaria no navegador de QUALQUER pessoa
// que abrisse o mural (achado numa auditoria de segurança, 13/09).
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function horaCurta(iso) {
  const d = new Date(iso);
  const hoje = new Date();
  const mesmodia = d.toDateString() === hoje.toDateString();
  return mesmodia
    ? d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

export async function renderComunicacao(container) {
  if (intervaloAtivo) { clearInterval(intervaloAtivo); intervaloAtivo = null; }
  container.innerHTML = '';

  const usuario = await getCurrentUser();

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Comunicação</h2>
      <p>Mural da equipe — tire dúvidas e avise a todo mundo que tem acesso ao painel, num lugar só.</p>
    </div>
  `;
  container.appendChild(head);

  const card = document.createElement('section');
  card.className = 'card';
  card.innerHTML = `
    <div id="comunicacaoLista" class="chat-list"></div>
    <p id="comunicacaoDigitando" class="chat-digitando" hidden></p>
    <form id="comunicacaoForm" class="chat-form">
      <textarea id="comunicacaoTexto" rows="2" maxlength="2000" placeholder="Escreva uma mensagem para a equipe…" aria-label="Nova mensagem"></textarea>
      <button class="btn btn-primary btn-sm" type="submit" id="comunicacaoEnviarBtn">Enviar</button>
    </form>
  `;
  container.appendChild(card);

  const lista = card.querySelector('#comunicacaoLista');
  const form = card.querySelector('#comunicacaoForm');
  const textarea = card.querySelector('#comunicacaoTexto');
  const statusDigitando = card.querySelector('#comunicacaoDigitando');

  let funcionariosPorId = new Map();
  let carregandoPrimeiraVez = true;

  // ---------- "Fulano está digitando…" (Realtime Broadcast) ----------
  let canalDigitando = null;
  const digitandoPorPessoa = new Map(); // funcionarioId -> { timeoutId, nome }
  let ultimoEnvioDigitando = 0;

  function atualizarTextoDigitando() {
    const nomes = [...digitandoPorPessoa.values()].map((v) => v.nome).filter(Boolean);
    if (nomes.length === 0) { statusDigitando.hidden = true; return; }
    statusDigitando.hidden = false;
    statusDigitando.textContent = nomes.length === 1
      ? `${nomes[0]} está digitando…`
      : `${nomes.slice(0, 2).join(', ')}${nomes.length > 2 ? ' e outros' : ''} estão digitando…`;
  }

  function registrarDigitando(funcionarioId, nome) {
    const existente = digitandoPorPessoa.get(funcionarioId);
    if (existente) clearTimeout(existente.timeoutId);
    const timeoutId = setTimeout(() => {
      digitandoPorPessoa.delete(funcionarioId);
      atualizarTextoDigitando();
    }, TEMPO_LIMITE_DIGITANDO_MS);
    digitandoPorPessoa.set(funcionarioId, { timeoutId, nome });
    atualizarTextoDigitando();
  }

  async function iniciarCanalDigitando() {
    try {
      const client = getSupabaseClient();
      canalDigitando = client.channel(CANAL_DIGITANDO, { config: { broadcast: { self: false } } });
      canalDigitando.on('broadcast', { event: 'digitando' }, ({ payload }) => {
        if (!payload || !usuario || payload.funcionarioId === usuario.id) return;
        registrarDigitando(payload.funcionarioId, payload.nome);
      });
      await canalDigitando.subscribe();
    } catch (err) {
      // Não é crítico — o mural continua funcionando por polling mesmo sem
      // o indicador de digitação (rede sem Realtime, projeto sem Realtime
      // habilitado etc.).
      canalDigitando = null;
    }
  }

  function pararCanalDigitando() {
    if (canalDigitando) { canalDigitando.unsubscribe(); canalDigitando = null; }
    digitandoPorPessoa.forEach((v) => clearTimeout(v.timeoutId));
    digitandoPorPessoa.clear();
  }

  textarea.addEventListener('input', () => {
    if (!canalDigitando || !usuario) return;
    const agora = Date.now();
    if (agora - ultimoEnvioDigitando < THROTTLE_ENVIO_DIGITANDO_MS) return;
    ultimoEnvioDigitando = agora;
    canalDigitando.send({ type: 'broadcast', event: 'digitando', payload: { funcionarioId: usuario.id, nome: usuario.nome } });
  });

  async function carregar() {
    // Se a pessoa já navegou pra outra tela, este nó não está mais no DOM
    // — para o polling em vez de continuar batendo na API em segundo
    // plano pra sempre (não há um hook genérico de "saiu da tela" no
    // roteador deste projeto, então a checagem fica aqui mesmo).
    if (!lista.isConnected) {
      if (intervaloAtivo) { clearInterval(intervaloAtivo); intervaloAtivo = null; }
      pararCanalDigitando();
      return;
    }
    if (carregandoPrimeiraVez) {
      lista.innerHTML = '';
      lista.appendChild(LoadingState({ rows: 3 }));
    }
    try {
      const [mensagens, funcionarios] = await Promise.all([
        listarMensagens(),
        carregandoPrimeiraVez ? listarFuncionarios() : Promise.resolve(null),
      ]);
      if (funcionarios) funcionariosPorId = new Map(funcionarios.map((f) => [f.id, f]));
      renderLista(mensagens);
      if (carregandoPrimeiraVez) {
        // Abriu o mural agora — marca como visto e some com a bolinha do
        // menu na hora, sem esperar a próxima checagem de rota.
        marcarMuralVisto(usuario).then(() => atualizarBadgeMural(usuario));
      }
      carregandoPrimeiraVez = false;
    } catch (err) {
      if (carregandoPrimeiraVez) {
        lista.innerHTML = '';
        lista.appendChild(ErrorState({ description: err.message || 'Falha ao carregar as mensagens.', onRetry: carregar }));
      }
      // Numa atualização automática (não a primeira), falha silenciosa —
      // não vale a pena substituir a conversa já visível por um erro só
      // porque uma atualização em segundo plano não deu certo.
    }
  }

  function renderLista(mensagens) {
    if (mensagens.length === 0) {
      lista.innerHTML = '<p class="kpi-empty" style="padding:var(--space-4) 0">Nenhuma mensagem ainda — comece a conversa.</p>';
      return;
    }
    const estavaNoFim = lista.scrollTop + lista.clientHeight >= lista.scrollHeight - 24;
    lista.innerHTML = mensagens.map((m) => {
      const autor = funcionariosPorId.get(m.autor_id);
      const nome = autor ? autor.nome : 'Ex-funcionário';
      const propria = usuario && m.autor_id === usuario.id;
      return `
        <div class="chat-message${propria ? ' is-own' : ''}">
          <div class="chat-avatar">${esc(iniciaisDe(nome))}</div>
          <div class="chat-bubble">
            <div class="chat-meta"><strong>${esc(nome)}</strong><span>${horaCurta(m.created_at)}</span></div>
            <div class="chat-texto"></div>
            ${m.lead_id ? `<a class="chat-lead-link" href="#/clientes/${m.lead_id}">🔗 Ver cliente</a>` : ''}
            ${ehAdmin(usuario) ? `<button class="chat-excluir" data-excluir="${m.id}" title="Excluir (moderação)" aria-label="Excluir mensagem">✕</button>` : ''}
          </div>
        </div>
      `;
    }).join('');
    // Texto via textContent (nunca innerHTML) — evita que HTML colado numa
    // mensagem seja interpretado; é conteúdo escrito por qualquer
    // funcionário, nunca confiável como marcação.
    lista.querySelectorAll('.chat-texto').forEach((el, i) => { el.textContent = mensagens[i].mensagem; });
    lista.querySelectorAll('[data-excluir]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (!window.confirm('Excluir esta mensagem?')) return;
        try {
          await excluirMensagem(btn.dataset.excluir);
          carregar();
        } catch (err) {
          showToast(err.message || 'Falha ao excluir.', { tone: 'danger' });
        }
      });
    });
    if (estavaNoFim) lista.scrollTop = lista.scrollHeight;
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const texto = textarea.value.trim();
    if (!texto) return;
    const btn = card.querySelector('#comunicacaoEnviarBtn');
    btn.disabled = true;
    try {
      await enviarMensagem(texto);
      textarea.value = '';
      await carregar();
      lista.scrollTop = lista.scrollHeight;
    } catch (err) {
      showToast(err.message || 'Falha ao enviar mensagem.', { tone: 'danger' });
    } finally {
      btn.disabled = false;
    }
  });

  await carregar();
  lista.scrollTop = lista.scrollHeight;
  intervaloAtivo = setInterval(carregar, INTERVALO_ATUALIZACAO_MS);
  iniciarCanalDigitando();
}
