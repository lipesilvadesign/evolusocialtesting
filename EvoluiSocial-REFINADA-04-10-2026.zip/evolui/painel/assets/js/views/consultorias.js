/**
 * Área "Consultorias" do painel — ETAPA 2/3/4: cada solicitação feita em
 * /consultas vira um lead aqui, com o diagnóstico já anexado, pipeline de
 * status, observações internas, atividades e atalhos de contato/agendamento.
 *
 * Segue o MESMO padrão visual e de código já usado em views/prospeccao.js
 * (root com classe própria, app-view-head, content-toolbar, .card + .app-table,
 * modal via abrirModal(), EmptyState/LoadingState/ErrorState/Toast/ConfirmDialog).
 */

import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { confirmDialog } from '../components/ConfirmDialog.js';
import { showToast } from '../components/Toast.js';
import { abrirModal as abrirModalBase } from '../components/Modal.js';
import { converterInbound } from '../services/prospeccaoClient.js';
import {
  fetchConsultas,
  updateConsulta,
  deleteConsulta,
  listarAtividadesConsulta,
  criarAtividadeConsulta,
} from '../services/consultasClient.js';

const STATUS_MAP = {
  novo: { label: 'Novo', cls: 'badge-demo' },
  analisando: { label: 'Analisando', cls: 'badge-info' },
  analise_enviada: { label: 'Análise enviada', cls: 'badge-warning' },
  contatado: { label: 'Contatado', cls: 'badge-info' },
  reuniao_agendada: { label: 'Reunião agendada', cls: 'badge-warning' },
  convertido: { label: 'Convertido', cls: 'badge-ok' },
  arquivado: { label: 'Arquivado', cls: 'badge-danger' },
};
const STATUS_ORDER = Object.keys(STATUS_MAP);

const SEGMENTOS = {
  moda_vestuario: 'Moda e vestuário', beleza_estetica: 'Beleza e estética', saude_bem_estar: 'Saúde e bem-estar',
  fitness: 'Fitness e esporte', alimentacao: 'Alimentação e gastronomia', imoveis: 'Imóveis',
  educacao_cursos: 'Educação e cursos', servicos_profissionais: 'Serviços profissionais e consultoria',
  direito_contabilidade: 'Direito, contabilidade e finanças', construcao_arquitetura: 'Construção, arquitetura e engenharia',
  varejo_ecommerce: 'Varejo e e-commerce', pet: 'Pet', tecnologia: 'Tecnologia e software',
  artesanato_criativo: 'Artesanato e criativo', eventos: 'Eventos e festas', outro: 'Outro',
};
const OBJETIVOS = {
  crescer_seguidores: 'Crescer o número de seguidores', gerar_vendas: 'Gerar vendas diretas pelo Instagram',
  atrair_clientes_locais: 'Atrair clientes da minha região', fortalecer_autoridade: 'Fortalecer autoridade e profissionalismo',
  organizar_identidade: 'Organizar a identidade visual do perfil', converter_contatos: 'Converter seguidores em contatos (WhatsApp/e-mail)',
  outro: 'Outro objetivo',
};
const CTA_LABEL = { whatsapp: 'Falar com Felipe', agendamento: 'Agendar conversa', instagram: 'Ver Instagram da Felipe Branding' };
const TIPO_ATIVIDADE_MAP = {
  analise_concluida: 'Análise concluída (automático)',
  cta_whatsapp: 'Clicou em "Falar com Felipe" (automático)',
  cta_agendamento: 'Clicou em "Agendar conversa" (automático)',
  cta_instagram: 'Clicou em "Ver Instagram" (automático)',
  contato_realizado: 'Contato realizado',
  mudanca_status: 'Mudança de status',
  observacao: 'Observação',
};

function statusBadgeHtml(status) {
  const info = STATUS_MAP[status] || STATUS_MAP.novo;
  return `<span class="badge ${info.cls}">${info.label}</span>`;
}
function onlyDigits(str) { return (str || '').replace(/\D/g, ''); }
function waLink(whatsapp, message) {
  const digits = onlyDigits(whatsapp);
  if (!digits) return null;
  const withCountry = digits.length <= 11 ? `55${digits}` : digits;
  return `https://wa.me/${withCountry}${message ? `?text=${encodeURIComponent(message)}` : ''}`;
}
function formatarDataHora(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export async function renderConsultorias(container) {
  container.innerHTML = '';
  const root = document.createElement('div');
  root.className = 'consultorias-view';
  container.appendChild(root);

  let leads = [];
  let filterStatus = 'todos';
  let searchTerm = '';

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Consultorias</h2>
      <p>Solicitações da Consultoria Gratuita de Perfil para Instagram (/consultoria) — cada uma já chega com o diagnóstico anexado.</p>
    </div>
  `;
  root.appendChild(head);

  const toolbar = document.createElement('div');
  toolbar.className = 'content-toolbar';
  toolbar.innerHTML = `
    <div class="search-box-small">
      <input type="search" id="consultaSearch" placeholder="Buscar por nome ou @Instagram…" aria-label="Buscar consultoria">
    </div>
    <select id="statusFilterConsulta" aria-label="Filtrar por status">
      <option value="todos">Todos os status</option>
      ${STATUS_ORDER.map((s) => `<option value="${s}">${STATUS_MAP[s].label}</option>`).join('')}
    </select>
    <button class="btn btn-ghost btn-sm" id="atualizarConsultasBtn">Atualizar</button>
  `;
  root.appendChild(toolbar);

  const listCard = document.createElement('section');
  listCard.className = 'card';
  root.appendChild(listCard);

  function filteredLeads() {
    return leads
      .filter((l) => {
        const matchesStatus = filterStatus === 'todos' || (l.status || 'novo') === filterStatus;
        const term = searchTerm.toLowerCase();
        const matchesSearch = !term || `${l.nome || ''} ${l.instagram || ''}`.toLowerCase().includes(term);
        return matchesStatus && matchesSearch;
      })
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  }

  function renderList() {
    listCard.innerHTML = '';
    const rows = filteredLeads();

    if (rows.length === 0) {
      listCard.appendChild(
        EmptyState({
          title: 'Nada por aqui ainda',
          description: leads.length === 0
            ? 'Nenhuma solicitação de consultoria recebida ainda. Assim que alguém preencher em /consultoria, o lead aparece aqui automaticamente.'
            : 'Nada encontrado com esses filtros.',
        })
      );
      return;
    }

    const wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    const table = document.createElement('table');
    table.className = 'app-table';
    table.innerHTML = `
      <thead><tr><th>Nome</th><th>Instagram</th><th>Segmento</th><th>Recebido em</th><th>CTA</th><th>Status</th><th></th></tr></thead>
      <tbody></tbody>
    `;
    const tbody = table.querySelector('tbody');

    rows.forEach((lead) => {
      const tr = document.createElement('tr');
      const ctaTag = lead.cta_clicado
        ? `<span class="badge badge-info" title="${esc(formatarDataHora(lead.cta_clicado_em))}">${esc(CTA_LABEL[lead.cta_clicado] || lead.cta_clicado)}</span>`
        : '<span class="text-muted" style="font-size:.82rem">—</span>';
      tr.innerHTML = `
        <td>${esc(lead.nome)}${lead.contato_realizado ? ' <span class="badge badge-ok" title="Contato já realizado">Contatado</span>' : ''}</td>
        <td>@${esc(lead.instagram)}</td>
        <td>${esc(SEGMENTOS[lead.segmento] || lead.segmento || '—')}</td>
        <td>${formatarDataHora(lead.created_at)}</td>
        <td>${ctaTag}</td>
        <td>${statusBadgeHtml(lead.status || 'novo')}</td>
        <td style="text-align:right"><button type="button" class="btn btn-ghost btn-sm" aria-label="Abrir ${esc(lead.nome)}">Abrir</button></td>
      `;
      tr.style.cursor = 'pointer';
      tr.addEventListener('click', () => abrirDetalhe(lead));
      tbody.appendChild(tr);
    });

    wrap.appendChild(table);
    listCard.appendChild(wrap);
  }

  // 29/09: usa o modal compartilhado (foco preso, Esc, foco devolvido, nome acessível).
  function abrirModal(innerHtml) {
    return abrirModalBase({ html: innerHtml, host: root, maxWidth: '640px' });
  }

  function renderDiagnostico(resultado) {
    if (!resultado) return '<p class="text-muted" style="font-size:.85rem">Nenhum diagnóstico disponível.</p>';
    const categorias = (resultado.categorias || [])
      .map(
        (cat) => `
        <div class="card" style="padding:var(--space-3);margin:0">
          <div style="display:flex;justify-content:space-between;gap:8px;margin-bottom:4px">
            <strong style="font-size:.86rem">${esc(cat.titulo)}</strong>
            <span class="badge ${cat.avaliacao === 'atencao' ? 'badge-danger' : cat.avaliacao === 'oportunidade' ? 'badge-ok' : 'badge-demo'}">${esc(cat.avaliacaoLabel)}</span>
          </div>
          <p style="font-size:.82rem;color:var(--text-muted)">${esc(cat.texto)}</p>
          ${
            cat.dicasPraticas && cat.dicasPraticas.length
              ? `<ul style="margin-top:8px;padding-left:16px;font-size:.8rem;color:var(--text-muted)">${cat.dicasPraticas.map((d) => `<li>${esc(d)}</li>`).join('')}</ul>`
              : ''
          }
        </div>`
      )
      .join('');
    const lista = (titulo, itens) =>
      itens && itens.length
        ? `<div style="margin-top:var(--space-3)"><strong style="font-size:.82rem">${titulo}</strong><ul style="margin-top:6px;padding-left:18px;font-size:.82rem;color:var(--text-muted)">${itens.map((i) => `<li>${esc(i)}</li>`).join('')}</ul></div>`
        : '';
    return `
      <p style="font-size:.88rem;color:var(--text-muted);margin-bottom:var(--space-3)">${esc(resultado.resumo)}</p>
      <div class="card-grid" style="margin-bottom:var(--space-2)">${categorias}</div>
      ${lista('Pontos fortes', resultado.pontosFortes)}
      ${lista('Pontos de atenção', resultado.pontosDeAtencao)}
      ${lista('Oportunidades', resultado.oportunidades)}
      ${lista('Próximas ações', resultado.proximasAcoes)}
    `;
  }

  async function abrirDetalhe(lead) {
    const wa = waLink(lead.whatsapp, `Olá, ${lead.nome}! Aqui é o Felipe, da Felipe Branding. Vi que você fez a consultoria gratuita de perfil (@${lead.instagram}) — vamos conversar sobre o diagnóstico?`);
    const igLink = lead.instagram ? `https://instagram.com/${encodeURIComponent(lead.instagram)}` : null;

    const { box, close } = abrirModal(`
      <h3 style="font-size:1.1rem;margin-bottom:2px">${esc(lead.nome)}</h3>
      <p class="text-muted" style="font-size:.85rem;margin-bottom:var(--space-4)">@${esc(lead.instagram)} · ${esc(SEGMENTOS[lead.segmento] || lead.segmento)} · recebido em ${formatarDataHora(lead.created_at)} · origem: ${esc(lead.origem || '—')}</p>

      <div class="content-editor-form" style="margin-bottom:var(--space-4)">
        <div class="field"><label>WhatsApp</label><input aria-label="WhatsApp" value="${esc(lead.whatsapp)}" readonly></div>
        <div class="field"><label>E-mail</label><input aria-label="E-mail" value="${esc(lead.email || '—')}" readonly></div>
        <div class="field field-full"><label>Objetivo principal</label><input aria-label="Objetivo principal" value="${esc(OBJETIVOS[lead.objetivo] || lead.objetivo)}" readonly></div>
      </div>

      <div style="display:flex;gap:var(--space-2);flex-wrap:wrap;margin-bottom:var(--space-5)">
        ${wa ? `<a class="btn btn-primary btn-sm" href="${wa}" target="_blank" rel="noopener">Abrir WhatsApp</a>` : ''}
        ${igLink ? `<a class="btn btn-ghost btn-sm" href="${igLink}" target="_blank" rel="noopener">Abrir Instagram</a>` : ''}
        <button class="btn btn-ghost btn-sm" id="btnAgendar">Iniciar agendamento</button>
        ${lead.convertido_lead_id
          ? `<a class="btn btn-ghost btn-sm" href="#/clientes/${esc(lead.convertido_lead_id)}" title="Esta consulta já virou lead no CRM">Ver lead no CRM</a>`
          : '<button class="btn btn-ghost btn-sm" id="btnConverter" title="Cria (ou vincula a) um lead na Prospecção — sem duplicar">Converter em lead</button>'}
      </div>

      <h4 style="font-size:.9rem;margin-bottom:var(--space-2)">Diagnóstico gerado</h4>
      <div style="margin-bottom:var(--space-5)">${renderDiagnostico(lead.resultado_analise)}</div>

      <div class="content-editor-form" style="margin-bottom:var(--space-4)">
        <div class="field">
          <label for="statusSelect">Status</label>
          <select id="statusSelect">${STATUS_ORDER.map((s) => `<option value="${s}" ${s === (lead.status || 'novo') ? 'selected' : ''}>${STATUS_MAP[s].label}</option>`).join('')}</select>
        </div>
        <div class="field">
          <label for="contatoSelect">Contato realizado</label>
          <select id="contatoSelect">
            <option value="false" ${!lead.contato_realizado ? 'selected' : ''}>Ainda não</option>
            <option value="true" ${lead.contato_realizado ? 'selected' : ''}>Sim${lead.ultimo_contato_em ? ` (${formatarDataHora(lead.ultimo_contato_em)})` : ''}</option>
          </select>
        </div>
        <div class="field field-full">
          <label for="observacoesInput">Observações internas</label>
          <textarea id="observacoesInput" rows="3" placeholder="Anotações só visíveis para o time">${esc(lead.observacoes_internas || '')}</textarea>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;margin-bottom:var(--space-5)">
        <button class="btn btn-danger btn-sm" id="btnExcluir">Excluir</button>
        <button class="btn btn-primary btn-sm" id="btnSalvar">Salvar alterações</button>
      </div>

      <h4 style="font-size:.9rem;margin-bottom:var(--space-2)">Linha do tempo</h4>
      <div id="atividadesHost" style="margin-bottom:var(--space-4)"><p class="text-muted" style="font-size:.82rem">Carregando…</p></div>
      <div class="content-editor-form">
        <div class="field"><label for="novaAtividadeTipo">Tipo</label><select id="novaAtividadeTipo"><option value="observacao">Observação</option><option value="contato_realizado">Contato realizado</option><option value="mudanca_status">Mudança de status</option></select></div>
        <div class="field field-full"><label for="novaAtividadeDescricao">Descrição</label><textarea id="novaAtividadeDescricao" rows="2" placeholder="O que aconteceu?"></textarea></div>
      </div>
      <button class="btn btn-ghost btn-sm" id="btnAdicionarAtividade">+ Adicionar ao histórico</button>
    `);

    const btnConverter = box.querySelector('#btnConverter');
    if (btnConverter) btnConverter.addEventListener('click', async () => {
      btnConverter.disabled = true; // a conversão também é idempotente no banco
      try {
        const r = await converterInbound('consulta', lead.id);
        lead.convertido_lead_id = r.lead_id || r.match_lead_id || lead.convertido_lead_id;
        const msg = { aprovado: 'Lead criado na Prospecção.', vinculado: 'Já existia um lead com este contato: a consulta foi vinculada a ele.', ja_convertido: 'Esta consulta já tinha sido convertida.' }[r.resultado] || `Resultado: ${r.resultado}`;
        showToast(msg, { tone: 'ok' });
        btnConverter.outerHTML = lead.convertido_lead_id ? `<a class="btn btn-ghost btn-sm" href="#/clientes/${esc(lead.convertido_lead_id)}">Ver lead no CRM</a>` : '';
      } catch (err) {
        showToast(err.message || 'Falha ao converter.', { tone: 'danger' });
        btnConverter.disabled = false;
      }
    });

    box.querySelector('#btnAgendar').addEventListener('click', () => {
      const d1 = new Date(); d1.setDate(d1.getDate() + 7);
      const d2 = new Date(d1.getTime() + 30 * 60 * 1000);
      const fmt = (d) => d.toISOString().replace(/[-:]|\.\d{3}/g, '').slice(0, 15) + 'Z';
      const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent('Conversa — ' + lead.nome + ' (consultoria Instagram)')}&dates=${fmt(d1)}/${fmt(d2)}&details=${encodeURIComponent('Continuação da consultoria gratuita de perfil no Instagram @' + lead.instagram)}`;
      window.open(url, '_blank', 'noopener');
    });

    box.querySelector('#btnSalvar').addEventListener('click', async () => {
      const payload = {
        status: box.querySelector('#statusSelect').value,
        contatoRealizado: box.querySelector('#contatoSelect').value === 'true',
        observacoesInternas: box.querySelector('#observacoesInput').value.trim() || null,
      };
      if (payload.contatoRealizado && !lead.contato_realizado) payload.ultimoContatoEm = new Date().toISOString();
      try {
        const atualizado = await updateConsulta(lead.id, payload);
        const idx = leads.findIndex((l) => l.id === lead.id);
        if (idx !== -1) leads[idx] = atualizado;
        renderList();
        showToast('Consultoria atualizada.', { tone: 'ok' });
        close();
      } catch (err) {
        showToast(err.message || 'Falha ao salvar.', { tone: 'danger' });
      }
    });

    box.querySelector('#btnExcluir').addEventListener('click', async () => {
      const ok = await confirmDialog({ title: 'Excluir esta consultoria?', description: `${lead.nome} (@${lead.instagram}) será removido permanentemente.`, confirmLabel: 'Excluir' });
      if (!ok) return;
      try {
        await deleteConsulta(lead.id);
        leads = leads.filter((l) => l.id !== lead.id);
        renderList();
        showToast('Consultoria excluída.', { tone: 'ok' });
        close();
      } catch (err) {
        showToast(err.message || 'Falha ao excluir.', { tone: 'danger' });
      }
    });

    box.querySelector('#btnAdicionarAtividade').addEventListener('click', async () => {
      const tipo = box.querySelector('#novaAtividadeTipo').value;
      const descricao = box.querySelector('#novaAtividadeDescricao').value.trim();
      if (!descricao) { showToast('Descreva a atividade antes de salvar.', { tone: 'danger' }); return; }
      try {
        await criarAtividadeConsulta({ leadId: lead.id, tipo, descricao });
        box.querySelector('#novaAtividadeDescricao').value = '';
        carregarAtividades(box, lead.id);
        showToast('Atividade registrada.', { tone: 'ok' });
      } catch (err) {
        showToast(err.message || 'Falha ao registrar atividade.', { tone: 'danger' });
      }
    });

    carregarAtividades(box, lead.id);
  }

  async function carregarAtividades(box, leadId) {
    const host = box.querySelector('#atividadesHost');
    if (!host) return;
    try {
      const atividades = await listarAtividadesConsulta(leadId);
      if (!box.isConnected) return;
      host.innerHTML = atividades.length
        ? `<ul style="display:grid;gap:8px">${atividades
            .map(
              (a) => `<li style="font-size:.82rem;border-bottom:1px solid var(--border);padding-bottom:8px">
                <strong>${esc(TIPO_ATIVIDADE_MAP[a.tipo] || a.tipo)}</strong>
                <span class="text-muted"> — ${formatarDataHora(a.data)}</span>
                ${a.descricao ? `<br>${esc(a.descricao)}` : ''}
              </li>`
            )
            .join('')}</ul>`
        : '<p class="text-muted" style="font-size:.82rem">Nenhuma atividade registrada ainda.</p>';
    } catch (err) {
      if (box.isConnected) host.innerHTML = `<p style="color:var(--danger);font-size:.82rem">${esc(err.message || 'Falha ao carregar atividades.')}</p>`;
    }
  }

  toolbar.querySelector('#consultaSearch').addEventListener('input', (e) => { searchTerm = e.target.value; renderList(); });
  toolbar.querySelector('#statusFilterConsulta').addEventListener('change', (e) => { filterStatus = e.target.value; renderList(); });
  toolbar.querySelector('#atualizarConsultasBtn').addEventListener('click', () => carregar());

  async function carregar() {
    listCard.innerHTML = '';
    listCard.appendChild(LoadingState({ rows: 4 }));
    try {
      leads = await fetchConsultas();
      renderList();
    } catch (err) {
      listCard.innerHTML = '';
      listCard.appendChild(ErrorState({ description: err.message || 'Falha ao carregar consultorias.', onRetry: carregar }));
    }
  }

  carregar();
}
