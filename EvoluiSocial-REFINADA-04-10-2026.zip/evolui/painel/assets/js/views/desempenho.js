/**
 * Desempenho (Métricas) — versão nova de "Inteligência", focada em
 * equipe/prospecção (a anterior dependia 100% de GA4, que saiu do painel).
 * Só dados reais: mensagens enviadas, respostas e conversões por pessoa,
 * calculados a partir de admin_prospeccao_atividades/leads — os mesmos
 * dados que já alimentam o Início, aqui agrupados por responsável.
 *
 * Pedido 13/09 (3ª rodada — "hoje são ~11 blocos dentro do Início, precisa
 * de página própria"): esta página passou a acumular também os KPIs
 * completos, o funil de prospecção, o gráfico "por dia" e as atividades
 * recentes que antes viviam no Início — que agora só mostra um resumo de
 * hoje com um link pra cá. Ordem revista por pedido explícito: "atividades
 * recentes" (o que aconteceu de concreto) vem ANTES do gráfico por dia (uma
 * visão mais abstrata) — antes era o contrário.
 */
import { LoadingState } from '../components/LoadingState.js';
import { ErrorState } from '../components/ErrorState.js';
import { renderTimeline } from '../components/Timeline.js';
import { funilProspeccaoHtml } from '../components/FunilProspeccao.js';
import { chartAreaHtml } from '../components/ChartArea.js';
import { buscarRelatorio } from '../services/prospeccaoClient.js';
import { listarFuncionarios } from '../services/funcionariosClient.js';
import { STATUS_MAP, STATUS_ORDER, NAO_TERMINAIS } from './prospeccao.js';

const PERIODOS = [
  ['hoje', 'Hoje'],
  ['semana', 'Últimos 7 dias'],
  ['mes', 'Últimos 30 dias'],
  ['tudo', 'Todo o período'],
];
// Abaixo deste número de eventos, uma taxa (%) fica mais enganosa do que
// útil — mostramos "poucos dados" em vez de uma porcentagem que parece
// precisa mas não é representativa (mesmo princípio já usado em Analytics).
const MINIMO_PARA_TAXA = 5;

// nome de funcionário é autoeditável (Meu Perfil) — nunca inserir em
// innerHTML sem escapar (achado numa auditoria de segurança, 13/09).
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function dentroDoPeriodo(dataIso, inicioIso, fimIso) {
  if (!dataIso) return false;
  const t = new Date(dataIso).getTime();
  if (inicioIso && t < new Date(inicioIso).getTime()) return false;
  if (fimIso && t > new Date(fimIso).getTime()) return false;
  return true;
}

function fmtPct(n) {
  return `${Math.round(n)}%`;
}

function kpiCardHtml({ label, value, sublabel, delta }) {
  return `
    <div class="card kpi-card">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value">${value}</div>
      ${sublabel ? `<div class="kpi-empty">${sublabel}</div>` : ''}
      ${delta != null ? `<div class="kpi-delta ${delta >= 0 ? 'up' : 'down'}">${delta >= 0 ? '▲' : '▼'} ${Math.abs(delta)}% vs. período anterior</div>` : ''}
    </div>
  `;
}

function diaCurto(iso) {
  return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

/** Agrupa uma lista de datas ISO em contagem por dia, últimos `dias` dias (inclui dias com 0). */
function agruparPorDia(datasIso, dias) {
  const baldes = new Map();
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  for (let i = dias - 1; i >= 0; i--) {
    const d = new Date(hoje.getTime() - i * 86400000);
    baldes.set(d.toISOString().slice(0, 10), 0);
  }
  datasIso.forEach((iso) => {
    const chave = new Date(iso).toISOString().slice(0, 10);
    if (baldes.has(chave)) baldes.set(chave, baldes.get(chave) + 1);
  });
  return baldes;
}

export async function renderDesempenho(container) {
  container.innerHTML = '';

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Desempenho</h2>
      <p>KPIs, funil, atividades recentes e prospecção por pessoa — só com dados reais já registrados.</p>
    </div>
  `;
  container.appendChild(head);

  const periodoBar = document.createElement('div');
  periodoBar.className = 'date-range-selector';
  periodoBar.style.marginBottom = 'var(--space-5)';
  periodoBar.innerHTML = `<select id="desempenhoPeriodo" aria-label="Selecionar período">${PERIODOS.map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select>`;
  periodoBar.querySelector('#desempenhoPeriodo').value = 'semana';
  container.appendChild(periodoBar);

  const body = document.createElement('div');
  container.appendChild(body);
  periodoBar.querySelector('#desempenhoPeriodo').addEventListener('change', (e) => carregar(e.target.value));

  carregar('semana');

  async function carregar(periodo) {
    body.innerHTML = '';
    body.appendChild(LoadingState({ variant: 'cards', rows: 4 }));
    try {
      const [dados, funcionarios] = await Promise.all([buscarRelatorio(periodo), listarFuncionarios()]);
      body.innerHTML = '';
      montarDesempenho(body, dados, funcionarios);
    } catch (err) {
      body.innerHTML = '';
      body.appendChild(ErrorState({ description: err.message || 'Falha ao carregar desempenho.', onRetry: () => carregar(periodo) }));
    }
  }
}

/** Puro — fácil de testar. Agrupa atividades/leads por responsável, calculando só o que dá pra determinar de verdade. */
export function calcularDesempenhoPorPessoa(statusAtual, atividades, funcionarios) {
  const responsavelPorLead = new Map(statusAtual.map((l) => [l.id, l.responsavel_id]));
  const porPessoa = new Map();
  const nomeDe = (id) => (funcionarios.find((f) => f.id === id) || {}).nome || 'Sem responsável';

  function linha(id) {
    if (!porPessoa.has(id)) {
      porPessoa.set(id, { funcionarioId: id, nome: nomeDe(id), mensagensEnviadas: 0, respostas: 0, conversoes: 0, perdidos: 0 });
    }
    return porPessoa.get(id);
  }

  atividades.forEach((a) => {
    const respId = responsavelPorLead.get(a.lead_id) || null;
    if (a.tipo === 'whatsapp_enviado') linha(respId).mensagensEnviadas += 1;
    if (a.tipo === 'resposta_recebida') linha(respId).respostas += 1;
  });
  statusAtual.forEach((l) => {
    if (l.status === 'cliente') linha(l.responsavel_id || null).conversoes += 1;
    if (l.status === 'nao_convertido') linha(l.responsavel_id || null).perdidos += 1;
  });

  return Array.from(porPessoa.values())
    .map((p) => ({
      ...p,
      taxaResposta: p.mensagensEnviadas >= MINIMO_PARA_TAXA ? Math.round((p.respostas / p.mensagensEnviadas) * 100) : null,
    }))
    .sort((a, b) => b.mensagensEnviadas - a.mensagensEnviadas);
}

function montarDesempenho(body, dados, funcionarios) {
  const resumo = dados.resumo || {};
  const atividades = dados.atividades || [];
  const statusAtual = dados.statusAtual || [];
  const { inicio, fim } = dados.periodo || {};
  const empresaPorLeadId = new Map(statusAtual.map((l) => [l.id, l.empresa]));

  // ---- Cálculos, todos a partir de dados já existentes (movidos do Início) ----
  const prospeccoesRealizadas = resumo.leadsNoPeriodo || 0;
  const whatsappNoPeriodo = atividades.filter((a) => a.tipo === 'whatsapp_enviado').length;
  const emailsNoPeriodo = resumo.emailsEnviados || 0;
  const mensagensEnviadas = whatsappNoPeriodo + emailsNoPeriodo;
  const respostasRecebidas = atividades.filter((a) => a.tipo === 'resposta_recebida').length;
  const leadsEmAndamento = statusAtual.filter((l) => NAO_TERMINAIS.includes(l.status)).length;
  const leadsInteressados = statusAtual.filter((l) => l.status === 'interessado').length;
  const reunioesOrcamentos = statusAtual.filter((l) => l.status === 'reuniao_marcada' || l.status === 'proposta_enviada').length;
  const conversoes = statusAtual.filter((l) => l.status === 'cliente' && dentroDoPeriodo(l.updated_at, inicio, fim)).length;
  const perdidosNoPeriodo = statusAtual.filter((l) => l.status === 'nao_convertido' && dentroDoPeriodo(l.updated_at, inicio, fim)).length;
  const contatosIniciados = statusAtual.filter((l) => l.status !== 'novo_lead' && dentroDoPeriodo(l.updated_at, inicio, fim)).length;

  const taxaResposta = mensagensEnviadas >= MINIMO_PARA_TAXA ? fmtPct((respostasRecebidas / mensagensEnviadas) * 100) : null;
  const taxaConversao = contatosIniciados >= MINIMO_PARA_TAXA ? fmtPct((conversoes / contatosIniciados) * 100) : null;

  // ---- KPIs ----
  const kpiGrid = document.createElement('div');
  kpiGrid.className = 'kpi-grid';
  kpiGrid.innerHTML = [
    kpiCardHtml({ label: 'Prospecções realizadas', value: prospeccoesRealizadas }),
    kpiCardHtml({ label: 'Contatos iniciados', value: contatosIniciados }),
    kpiCardHtml({ label: 'Mensagens enviadas', value: mensagensEnviadas, sublabel: `${whatsappNoPeriodo} WhatsApp · ${emailsNoPeriodo} e-mail` }),
    kpiCardHtml({ label: 'Respostas recebidas', value: respostasRecebidas }),
    kpiCardHtml({
      label: 'Taxa de resposta',
      value: taxaResposta ?? '—',
      sublabel: taxaResposta ? null : 'Poucos dados neste período',
    }),
    kpiCardHtml({ label: 'Leads em andamento', value: leadsEmAndamento, sublabel: 'agora, todos os períodos' }),
    kpiCardHtml({ label: 'Interessados', value: leadsInteressados, sublabel: 'agora' }),
    kpiCardHtml({ label: 'Reunião/Orçamento', value: reunioesOrcamentos, sublabel: 'agora' }),
    kpiCardHtml({ label: 'Conversões', value: conversoes, sublabel: 'no período' }),
    kpiCardHtml({
      label: 'Taxa de conversão',
      value: taxaConversao ?? '—',
      sublabel: taxaConversao ? 'sobre contatos iniciados' : 'Poucos dados neste período',
    }),
    kpiCardHtml({ label: 'Perdidos', value: perdidosNoPeriodo, sublabel: 'no período' }),
  ].join('');
  body.appendChild(kpiGrid);

  // ---- Atividades recentes (pedido explícito: mais acima que o gráfico
  // "por dia" — é a informação mais concreta e acionável das duas) ----
  const atividadesCard = document.createElement('section');
  atividadesCard.className = 'card';
  atividadesCard.innerHTML = `<div class="card-head"><h3>Atividades recentes</h3></div>`;
  const comEmpresa = atividades
    .map((a) => ({ ...a, empresa: empresaPorLeadId.get(a.lead_id) }))
    .sort((a, b) => new Date(b.data) - new Date(a.data));
  atividadesCard.appendChild(renderTimeline(comEmpresa, {
    vazio: 'Nenhuma atividade registrada neste período.',
    mostrarEmpresa: true,
    limite: 15,
  }));
  atividadesCard.querySelectorAll('.timeline-lead-link').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (btn.dataset.leadId) window.location.hash = `#/clientes/${btn.dataset.leadId}`;
    });
  });
  body.appendChild(atividadesCard);

  // ---- Funil (distribuição atual por estágio) ----
  const funilCard = document.createElement('section');
  funilCard.className = 'card';
  const contagemPorStatus = {};
  STATUS_ORDER.forEach((s) => { contagemPorStatus[s] = 0; });
  statusAtual.forEach((l) => { if (contagemPorStatus[l.status] != null) contagemPorStatus[l.status] += 1; });
  funilCard.innerHTML = `<div class="card-head"><h3>Funil de prospecção — agora</h3></div>${funilProspeccaoHtml(contagemPorStatus, STATUS_ORDER, STATUS_MAP)}`;
  body.appendChild(funilCard);

  // ---- Gráfico por dia — linha suave com área em gradiente (estilo
  // "estatísticas"/BTC-USD que você mandou; ver ChartArea.js) ----
  const dias = dados.periodo?.chave === 'mes' ? 30 : dados.periodo?.chave === 'hoje' ? 1 : 7;
  if (dias > 1) {
    const chartCard = document.createElement('section');
    chartCard.className = 'card';
    chartCard.innerHTML = `<div class="card-head"><h3>Desempenho por dia</h3></div>`;
    const leadsPorDia = agruparPorDia(statusAtual.filter((l) => dentroDoPeriodo(l.created_at, inicio, fim)).map((l) => l.created_at), dias);
    const respostasPorDia = agruparPorDia(atividades.filter((a) => a.tipo === 'resposta_recebida').map((a) => a.data), dias);
    const chaves = Array.from(leadsPorDia.keys());

    chartCard.innerHTML += chartAreaHtml({
      categorias: chaves.map((k) => diaCurto(k + 'T12:00:00')),
      series: [
        { nome: 'Leads captados', cor: 'var(--star)', valores: chaves.map((k) => leadsPorDia.get(k)) },
        { nome: 'Respostas', cor: 'var(--info)', valores: chaves.map((k) => respostasPorDia.get(k) || 0) },
      ],
    });
    body.appendChild(chartCard);
  }

  // ---- Por pessoa (já existia nesta página) ----
  const linhas = calcularDesempenhoPorPessoa(statusAtual, atividades, funcionarios);
  const pessoaCard = document.createElement('section');
  pessoaCard.className = 'card';
  pessoaCard.innerHTML = `<div class="card-head"><h3>Por pessoa</h3></div>`;

  if (linhas.length === 0) {
    pessoaCard.innerHTML += '<p class="kpi-empty">Nenhuma atividade registrada neste período.</p>';
    body.appendChild(pessoaCard);
    return;
  }

  const wrap = document.createElement('div');
  wrap.className = 'table-wrap';
  wrap.innerHTML = `
    <table class="app-table">
      <thead><tr><th>Pessoa</th><th>Mensagens enviadas</th><th>Respostas</th><th>Taxa de resposta</th><th>Conversões</th><th>Perdidos</th></tr></thead>
      <tbody>
        ${linhas.map((l) => `
          <tr>
            <td>${esc(l.nome)}</td>
            <td>${l.mensagensEnviadas}</td>
            <td>${l.respostas}</td>
            <td>${l.taxaResposta != null ? l.taxaResposta + '%' : '—'}</td>
            <td>${l.conversoes}</td>
            <td>${l.perdidos}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
  pessoaCard.appendChild(wrap);
  body.appendChild(pessoaCard);
}
