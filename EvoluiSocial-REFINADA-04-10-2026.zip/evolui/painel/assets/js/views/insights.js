import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { renderDateRangeSelector } from '../components/DateRangeSelector.js';
import { renderInsightCard } from '../components/InsightCard.js';
import { renderAiAnalysisSection } from '../components/AiAnalysisCard.js';
import { renderIntelligenceBoard } from '../components/IntelligenceBoard.js';
import { fetchInsightsEngine } from '../services/analyticsClient.js';
import { fetchAiAnalysis } from '../services/aiClient.js';
import { fetchIntelligence } from '../services/intelligenceClient.js';
import { createTask } from '../services/tasksClient.js';
import { showToast } from '../components/Toast.js';
import { esc } from '../utils/html.js';

// Ordem de exibição pedida: Resumo → O que está indo bem → Atenção →
// Oportunidades → Recomendações. "Alertas" e "Tendências" também existem
// como categorias tipadas (ver insightsEngine) — entram entre Atenção e
// Oportunidades, já que são igualmente categorias de 1º nível do motor.
const SECTIONS = [
  { key: 'positive', title: 'O que está indo bem' },
  { key: 'attention', title: 'Atenção' },
  { key: 'alert', title: 'Alertas' },
  { key: 'trend', title: 'Tendências' },
  { key: 'opportunity', title: 'Oportunidades' },
  { key: 'recommendation', title: 'Recomendações' },
];

export function renderInsights(container) {
  container.innerHTML = '';
  let currentRange = { range: '30d' }; // 30 dias dá mais base pros motores compararem do que 7

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Insights</h2>
      <p>Health Score, anomalias, correlações e oportunidades priorizadas — com leituras determinísticas e uma análise executiva por IA logo abaixo.</p>
    </div>
  `;
  container.appendChild(head);

  const rangeBar = document.createElement('div');
  rangeBar.style.cssText = 'margin-bottom:var(--space-5)';
  container.appendChild(rangeBar);
  rangeBar.appendChild(
    renderDateRangeSelector({
      initial: currentRange,
      onChange: (value) => {
        currentRange = value;
        loadIntelligence();
        load();
        loadAi({ refresh: false });
      },
    })
  );

  // ---- Inteligência Avançada (Health Score / Anomalias / Correlações / Oportunidades) ----
  const intelHead = document.createElement('h3');
  intelHead.style.cssText = 'font-size:1.1rem;margin-bottom:var(--space-3)';
  intelHead.textContent = 'Inteligência avançada';
  container.appendChild(intelHead);

  const intelBody = document.createElement('div');
  container.appendChild(intelBody);

  const engineDivider = document.createElement('hr');
  engineDivider.style.cssText = 'border:none;border-top:1px solid var(--border);margin:var(--space-8) 0';
  container.appendChild(engineDivider);

  // ---- Motor determinístico (etapa anterior, reaproveitado sem mudança) ----
  const body = document.createElement('div');
  container.appendChild(body);

  const aiDivider = document.createElement('hr');
  aiDivider.style.cssText = 'border:none;border-top:1px solid var(--border);margin:var(--space-8) 0';
  container.appendChild(aiDivider);

  // ---- Análise por IA (etapa anterior, reaproveitada — agora recebe também a inteligência avançada) ----
  const aiToolbar = document.createElement('div');
  aiToolbar.style.cssText = 'display:flex;justify-content:flex-end;margin-bottom:var(--space-3)';
  aiToolbar.innerHTML = `<button class="btn btn-ghost btn-sm" id="aiRefreshBtn">Gerar nova análise</button>`;
  container.appendChild(aiToolbar);

  const aiBody = document.createElement('div');
  container.appendChild(aiBody);

  aiToolbar.querySelector('#aiRefreshBtn').addEventListener('click', () => loadAi({ refresh: true }));

  loadIntelligence();
  load();
  loadAi({ refresh: false });

  function loadIntelligence() {
    intelBody.innerHTML = '';
    intelBody.appendChild(LoadingState({ variant: 'cards', rows: 4 }));
    fetchIntelligence(currentRange)
      .then((intelligence) => {
        intelBody.innerHTML = '';
        intelBody.appendChild(renderIntelligenceBoard(intelligence, { onStatusChange: () => {} }));
      })
      .catch((err) => {
        intelBody.innerHTML = '';
        intelBody.appendChild(ErrorState({ description: err.message, onRetry: loadIntelligence }));
      });
  }

  function load() {
    body.innerHTML = '';
    body.appendChild(LoadingState({ rows: 5 }));

    fetchInsightsEngine(currentRange)
      .then((data) => {
        body.innerHTML = '';

        if (data.isEmpty) {
          body.appendChild(
            EmptyState({
              title: 'Dados insuficientes para gerar leituras',
              description:
                'O motor de insights precisa de um volume mínimo de tráfego (e, para a maioria das regras, um período anterior comparável) para produzir leituras confiáveis. Tente um período mais longo ou volte quando houver mais dados.',
            })
          );
          return;
        }

        body.appendChild(buildSummary(data));

        SECTIONS.forEach((section) => {
          const items = data.byCategory[section.key] || [];
          if (items.length === 0) return;
          body.appendChild(buildSection(section.title, items));
        });
      })
      .catch((err) => {
        body.innerHTML = '';
        body.appendChild(ErrorState({ description: err.message, onRetry: load }));
      });
  }

  function loadAi({ refresh }) {
    const btn = aiToolbar.querySelector('#aiRefreshBtn');
    btn.disabled = true;
    btn.textContent = refresh ? 'Gerando…' : 'Gerar nova análise';
    aiBody.innerHTML = '';
    aiBody.appendChild(LoadingState({ rows: 4 }));

    fetchAiAnalysis(currentRange, { refresh })
      .then((analysis) => {
        aiBody.innerHTML = '';
        aiBody.appendChild(renderAiAnalysisSection(analysis, { createTask, showToast }));
      })
      .catch((err) => {
        aiBody.innerHTML = '';
        aiBody.appendChild(ErrorState({ description: err.message, onRetry: () => loadAi({ refresh: false }) }));
      })
      .finally(() => {
        btn.disabled = false;
        btn.textContent = 'Gerar nova análise';
      });
  }

  function buildSummary(data) {
    const card = document.createElement('section');
    card.className = 'card';
    const countsHtml = SECTIONS.map((s) => {
      const n = (data.byCategory[s.key] || []).length;
      return n > 0 ? `<span class="badge badge-demo">${esc(s.title)}: ${n}</span>` : '';
    })
      .filter(Boolean)
      .join(' ');
    card.innerHTML = `
      <div class="card-head"><h3>Resumo — motor determinístico</h3></div>
      <p style="color:var(--text-muted);font-size:.86rem;margin-bottom:var(--space-3)">
        ${data.total} leitura${data.total === 1 ? '' : 's'} geradas para ${data.rangeLabel}${
      data.hasComparison ? ', comparado ao período imediatamente anterior.' : '. Sem período anterior comparável — algumas regras não puderam ser aplicadas.'
    }
      </p>
      <div style="display:flex;gap:var(--space-2);flex-wrap:wrap">${countsHtml}</div>
    `;
    return card;
  }

  function buildSection(title, items) {
    const wrap = document.createElement('section');
    wrap.style.marginBottom = 'var(--space-6)';
    const h = document.createElement('h3');
    h.style.cssText = 'font-size:1.05rem;margin-bottom:var(--space-3)';
    h.textContent = title;
    wrap.appendChild(h);
    const grid = document.createElement('div');
    grid.className = 'card-grid';
    items.forEach((insight) => grid.appendChild(renderInsightCard(insight)));
    wrap.appendChild(grid);
    return wrap;
  }
}
