/**
 * Financeiro — módulo novo (não existia no projeto; ver cabeçalho de
 * SQL_PENDENTE_financeiro.sql para o porquê). Admin-only, mesmo padrão de
 * Equipe/Sistema (ver app.js e painel/index.html).
 *
 * PRINCÍPIO SEGUIDO (pedido explícito): "cliente" aqui é sempre um id de
 * admin_prospeccao_leads já existente — nunca um nome digitado à mão. O
 * seletor de cliente do formulário "Novo contrato" vem de fetchLeads(),
 * a MESMA função que Clientes/Prospecção já usam — zero base paralela.
 *
 * PRINCÍPIO SEGUIDO (pedido explícito): nenhum número mostrado aqui é
 * inventado. Todo KPI é somado a partir de admin_financeiro_contratos/
 * parcelas/despesas de verdade; quando não há dado suficiente pra uma
 * métrica fazer sentido (ex.: receita por origem sem nenhum lead com
 * `origem` preenchido), a tela mostra "Dados insuficientes" em vez de um
 * número ou um "—" sem explicação.
 */
import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { confirmDialog } from '../components/ConfirmDialog.js';
import { chartAreaHtml } from '../components/ChartArea.js';
import { renderDateRangeSelector } from '../components/DateRangeSelector.js';
import { fetchTodosLeads } from '../services/prospeccaoClient.js';
import {
  listarContratos, criarContrato,
  listarParcelas, atualizarStatusParcela,
  listarDespesas, criarDespesa, atualizarDespesa, excluirDespesa,
} from '../services/financeiroClient.js';
import { getCurrentUser } from '../services/auth.js';
import { ehAdmin } from '../services/rbac.js';
import { abrirModal as abrirModalBase } from '../components/Modal.js';
import { cartaoEvoluiFinanceiro } from './evoluisocial.js';

const SERVICO_LABEL = {
  branding: 'Branding', identidade_visual: 'Identidade visual', estrategia: 'Estratégia',
  conteudo: 'Conteúdo', gestao: 'Gestão', diagnostico: 'Diagnóstico',
  projeto_especial: 'Projeto especial', outros: 'Outros',
};
const CATEGORIA_DESPESA_LABEL = {
  google_ads: 'Google Ads', meta_ads: 'Meta Ads', ferramentas: 'Ferramentas', ia: 'IA',
  adobe: 'Adobe', hospedagem: 'Hospedagem', dominio: 'Domínio', supabase: 'Supabase',
  netlify: 'Netlify', freelancers: 'Freelancers', equipe: 'Equipe', estagio: 'Estágio',
  equipamentos: 'Equipamentos', transporte: 'Transporte', telefonia_internet: 'Telefonia/Internet',
  impostos: 'Impostos', servicos_terceirizados: 'Serviços terceirizados', marketing: 'Marketing',
  capacitacao: 'Capacitação', administrativo: 'Administrativo', outros: 'Outros',
};
const STATUS_PARCELA_LABEL = {
  previsto: { label: 'Previsto', cls: 'badge-demo' },
  aguardando: { label: 'Aguardando', cls: 'badge-info' },
  pago: { label: 'Pago', cls: 'badge-ok' },
  atrasado: { label: 'Atrasado', cls: 'badge-danger' },
  cancelado: { label: 'Cancelado', cls: 'badge-demo' },
};
const STATUS_DESPESA_LABEL = {
  previsto: { label: 'Previsto', cls: 'badge-demo' },
  pago: { label: 'Pago', cls: 'badge-ok' },
  atrasado: { label: 'Atrasado', cls: 'badge-danger' },
  cancelado: { label: 'Cancelado', cls: 'badge-demo' },
};
const ORIGEM_LABEL = {
  google: 'Google', instagram: 'Instagram', linkedin: 'LinkedIn', whatsapp: 'WhatsApp',
  prospeccao: 'Prospecção', indicacao: 'Indicação', site: 'Site', outros: 'Outros',
};
// Abaixo deste número de itens, agrupar "por origem" mostraria 1-2 barras
// isoladas — não é uma distribuição, é ruído (mesmo princípio já usado em
// Desempenho: MINIMO_PARA_TAXA).
const MINIMO_PARA_AQUISICAO = 3;

// Nome de cliente/observações são digitados por gente — nunca inserir em
// innerHTML sem escapar (mesmo achado de segurança já corrigido no resto do
// painel, 13-14/09).
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** @param {number} valor em reais (não centavos) */
export function formatBRL(valor) {
  if (valor == null || Number.isNaN(valor)) return 'R$ 0,00';
  return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function formatDataBR(iso) {
  if (!iso) return '—';
  // Data pura (YYYY-MM-DD, sem horário) — construir com T12:00:00 evita o
  // bug clássico de fuso horário (new Date('2026-01-31') pode virar 30/01
  // dependendo do fuso do navegador, porque é interpretada como UTC 00:00).
  const s = String(iso);
  const isoComHora = s.length === 10 ? `${s}T12:00:00` : s;
  return new Date(isoComHora).toLocaleDateString('pt-BR');
}

/**
 * Status "efetivo" pra exibição: vencida e ainda não paga/cancelada vira
 * "atrasado" na tela mesmo se ninguém marcou manualmente — sem precisar de
 * job agendado nem gatilho no banco (ver comentário no SQL).
 * @param {{ status: string, vencimento: string }} item
 * @param {string} [hojeIso] injetável pra teste; default = hoje real
 */
export function statusEfetivo(item, hojeIso = new Date().toISOString().slice(0, 10)) {
  if (item.status === 'pago' || item.status === 'cancelado') return item.status;
  return item.vencimento < hojeIso ? 'atrasado' : item.status;
}

const PERIODO_ROTULO = {
  hoje: 'hoje', ontem: 'ontem', '7d': 'últimos 7 dias', '28d': 'últimos 28 dias',
  '30d': 'últimos 30 dias', '90d': 'últimos 90 dias',
};

/**
 * Traduz o valor do seletor de período (DateRangeSelector) em limites de
 * data concretos — puro, testável. É o que faz o seletor do header
 * realmente FILTRAR alguma coisa (achado nesta auditoria: antes ele só
 * existia visualmente, sem afetar nenhum número da tela).
 * @param {{ range: string, start?: string, end?: string }} value
 * @param {string} [hojeIso] injetável pra teste
 * @returns {{ inicioIso: string, fimIso: string, label: string }}
 */
export function resolverPeriodo(value, hojeIso = new Date().toISOString().slice(0, 10)) {
  const hoje = new Date(`${hojeIso}T12:00:00`);
  const diasAtras = (n) => new Date(hoje.getTime() - n * 86400000).toISOString().slice(0, 10);

  if (value.range === 'personalizado' && value.start && value.end) {
    return { inicioIso: value.start, fimIso: value.end, label: `${formatDataBR(value.start)} a ${formatDataBR(value.end)}` };
  }
  if (value.range === 'hoje') return { inicioIso: hojeIso, fimIso: hojeIso, label: PERIODO_ROTULO.hoje };
  if (value.range === 'ontem') { const d = diasAtras(1); return { inicioIso: d, fimIso: d, label: PERIODO_ROTULO.ontem }; }
  const dias = { '7d': 7, '28d': 28, '30d': 30, '90d': 90 }[value.range] || 30;
  return { inicioIso: diasAtras(dias - 1), fimIso: hojeIso, label: PERIODO_ROTULO[value.range] || `últimos ${dias} dias` };
}

/**
 * Agregação central — pura, testável sem DOM/rede. Recebe os dados já
 * carregados e devolve tudo que as seções da tela precisam.
 * @param {{ contratos: object[], parcelas: object[], despesas: object[], leads: object[], hojeIso?: string }} dados
 */
export function calcularResumoFinanceiro({ contratos, parcelas, despesas, leads, hojeIso = new Date().toISOString().slice(0, 10), periodo }) {
  const leadPorId = new Map(leads.map((l) => [l.id, l]));
  const contratoPorId = new Map(contratos.map((c) => [c.id, c]));
  // Sem período explícito (ex.: os testes existentes), cai no mês corrente —
  // mesmo padrão de antes. Com período (vem do seletor do header), o
  // "resultado" passa a refletir o que a pessoa selecionou, não sempre "mês
  // atual" — o seletor de período no header precisa realmente filtrar algo,
  // não só existir visualmente (achado nesta auditoria: um período que não
  // filtra nada é, na prática, um controle sem função).
  const { inicioIso, fimIso } = periodo || { inicioIso: `${hojeIso.slice(0, 7)}-01`, fimIso: hojeIso };

  const parcelasComEfetivo = parcelas.map((p) => ({ ...p, statusEfetivo: statusEfetivo(p, hojeIso) }));
  const despesasComEfetivo = despesas.map((d) => ({ ...d, statusEfetivo: statusEfetivo(d, hojeIso) }));

  const totalRecebido = parcelasComEfetivo.filter((p) => p.status === 'pago').reduce((s, p) => s + Number(p.valor_pago ?? p.valor), 0);
  const totalPagoDespesas = despesasComEfetivo.filter((d) => d.status === 'pago').reduce((s, d) => s + Number(d.valor), 0);
  const saldoDisponivel = totalRecebido - totalPagoDespesas;

  const aReceber = parcelasComEfetivo.filter((p) => p.statusEfetivo !== 'pago' && p.statusEfetivo !== 'cancelado').reduce((s, p) => s + Number(p.valor), 0);
  const aPagar = despesasComEfetivo.filter((d) => d.statusEfetivo !== 'pago' && d.statusEfetivo !== 'cancelado').reduce((s, d) => s + Number(d.valor), 0);

  const receitaContratada = contratos.filter((c) => c.status === 'ativo').reduce((s, c) => s + Number(c.valor_total), 0);
  const receitaRecorrente = contratos.filter((c) => c.status === 'ativo' && c.recorrente).reduce((s, c) => s + Number(c.valor_total), 0);

  const dentroDoPeriodo = (dataIso) => dataIso && dataIso >= inicioIso && dataIso <= fimIso;
  const recebidoNoPeriodo = parcelasComEfetivo.filter((p) => p.status === 'pago' && dentroDoPeriodo(p.pago_em)).reduce((s, p) => s + Number(p.valor_pago ?? p.valor), 0);
  const pagoNoPeriodo = despesasComEfetivo.filter((d) => d.status === 'pago' && dentroDoPeriodo(d.pago_em)).reduce((s, d) => s + Number(d.valor), 0);
  const resultadoPeriodo = recebidoNoPeriodo - pagoNoPeriodo;

  const compromissosProximos30d = parcelasComEfetivo.filter((p) => {
    if (p.statusEfetivo === 'pago' || p.statusEfetivo === 'cancelado') return false;
    const dias = (new Date(`${p.vencimento}T12:00:00`) - new Date(`${hojeIso}T12:00:00`)) / 86400000;
    return dias >= 0 && dias <= 30;
  }).length;
  const pagamentosPendentes = parcelasComEfetivo.filter((p) => p.statusEfetivo === 'atrasado').length;
  const despesasPendentes = despesasComEfetivo.filter((d) => d.statusEfetivo === 'atrasado').length;

  // ---- Receita por cliente ----
  const porCliente = new Map();
  parcelasComEfetivo.forEach((p) => {
    const contrato = contratoPorId.get(p.contrato_id);
    if (!contrato) return;
    const lead = leadPorId.get(contrato.lead_id);
    const chave = contrato.lead_id;
    if (!porCliente.has(chave)) {
      porCliente.set(chave, {
        leadId: chave,
        nome: lead ? lead.empresa : 'Cliente removido do CRM',
        servico: contrato.servico,
        contratado: 0,
        recebido: 0,
      });
    }
    const linha = porCliente.get(chave);
    linha.contratado += Number(p.valor);
    if (p.status === 'pago') linha.recebido += Number(p.valor_pago ?? p.valor);
  });
  const receitaPorCliente = Array.from(porCliente.values())
    .map((l) => ({ ...l, emAberto: Math.max(0, l.contratado - l.recebido), status: l.recebido >= l.contratado ? 'quitado' : (l.recebido > 0 ? 'parcial' : 'em_aberto') }))
    .sort((a, b) => b.contratado - a.contratado);

  // ---- Receita por serviço ----
  const porServico = new Map();
  contratos.forEach((c) => {
    if (!porServico.has(c.servico)) porServico.set(c.servico, 0);
    porServico.set(c.servico, porServico.get(c.servico) + Number(c.valor_total));
  });
  const receitaPorServico = Array.from(porServico.entries())
    .map(([servico, valor]) => ({ servico, valor }))
    .sort((a, b) => b.valor - a.valor);

  // ---- Próximos vencimentos (contas a receber, não pagas/canceladas) ----
  const proximosVencimentos = parcelasComEfetivo
    .filter((p) => p.statusEfetivo !== 'pago' && p.statusEfetivo !== 'cancelado')
    .map((p) => {
      const contrato = contratoPorId.get(p.contrato_id);
      const lead = contrato ? leadPorId.get(contrato.lead_id) : null;
      return { ...p, nomeCliente: lead ? lead.empresa : 'Cliente removido do CRM' };
    })
    .sort((a, b) => (a.vencimento < b.vencimento ? -1 : 1));

  // ---- Despesas por categoria ----
  const porCategoria = new Map();
  despesas.forEach((d) => {
    if (!porCategoria.has(d.categoria)) porCategoria.set(d.categoria, 0);
    porCategoria.set(d.categoria, porCategoria.get(d.categoria) + Number(d.valor));
  });
  const despesasPorCategoria = Array.from(porCategoria.entries())
    .map(([categoria, valor]) => ({ categoria, valor }))
    .sort((a, b) => b.valor - a.valor);

  // ---- Aquisição (receita por origem do lead) — só se houver dado real
  // suficiente; nunca calcula CAC (pedido explícito: "não inventar CAC" —
  // exigiria custo de aquisição por canal, que este módulo não coleta). ----
  const porOrigem = new Map();
  let clientesComOrigem = 0;
  receitaPorCliente.forEach((l) => {
    const lead = leadPorId.get(l.leadId);
    // 30/09: a coluna real é `fonte` (admin_prospeccao_leads não tem `origem`); `origem` fica como fallback
    const origem = lead && (lead.fonte || lead.origem);
    if (!origem) return;
    clientesComOrigem += 1;
    porOrigem.set(origem, (porOrigem.get(origem) || 0) + l.recebido);
  });
  const receitaPorOrigem = clientesComOrigem >= MINIMO_PARA_AQUISICAO
    ? Array.from(porOrigem.entries()).map(([origem, valor]) => ({ origem, valor })).sort((a, b) => b.valor - a.valor)
    : null; // null = "Dados insuficientes", tratado na view

  return {
    saldoDisponivel, aReceber, aPagar, receitaContratada, receitaRecorrente, resultadoPeriodo,
    recebidoNoPeriodo, pagoNoPeriodo, compromissosProximos30d, pagamentosPendentes, despesasPendentes,
    receitaPorCliente, receitaPorServico, proximosVencimentos, despesasPorCategoria, receitaPorOrigem,
    parcelasComEfetivo, despesasComEfetivo,
  };
}

/** Série mensal (receitas pagas vs. despesas pagas) pros últimos `meses` meses — puro, testável. */
export function calcularSerieFluxo(parcelas, despesas, meses = 6, hojeIso = new Date().toISOString().slice(0, 10)) {
  const chaves = [];
  const base = new Date(`${hojeIso.slice(0, 7)}-01T12:00:00`);
  for (let i = meses - 1; i >= 0; i--) {
    const d = new Date(base);
    d.setMonth(d.getMonth() - i);
    chaves.push(d.toISOString().slice(0, 7));
  }
  const receitasPorMes = new Map(chaves.map((k) => [k, 0]));
  const despesasPorMes = new Map(chaves.map((k) => [k, 0]));
  parcelas.forEach((p) => {
    if (p.status !== 'pago' || !p.pago_em) return;
    const chave = p.pago_em.slice(0, 7);
    if (receitasPorMes.has(chave)) receitasPorMes.set(chave, receitasPorMes.get(chave) + Number(p.valor_pago ?? p.valor));
  });
  despesas.forEach((d) => {
    if (d.status !== 'pago' || !d.pago_em) return;
    const chave = d.pago_em.slice(0, 7);
    if (despesasPorMes.has(chave)) despesasPorMes.set(chave, despesasPorMes.get(chave) + Number(d.valor));
  });
  const rotuloMes = (chave) => new Date(`${chave}-01T12:00:00`).toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '');
  return {
    categorias: chaves.map(rotuloMes),
    receitas: chaves.map((k) => receitasPorMes.get(k)),
    despesas: chaves.map((k) => despesasPorMes.get(k)),
  };
}

function kpi({ label, value, sublabel, destaque }) {
  return `
    <div class="card kpi-card fin-kpi ${destaque ? 'fin-kpi-destaque' : ''}">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value fin-kpi-value">${value}</div>
      ${sublabel ? `<div class="kpi-empty">${sublabel}</div>` : ''}
    </div>
  `;
}

function badgeStatus(status, mapa) {
  const info = mapa[status] || mapa.previsto;
  return `<span class="badge ${info.cls}">${info.label}</span>`;
}

export async function renderFinanceiro(container) {
  container.innerHTML = '';

  const user = await getCurrentUser();
  if (!ehAdmin(user)) {
    container.innerHTML = '<div class="app-view-head"><h2>Acesso restrito</h2><p>O Financeiro é uma área exclusiva de administradores.</p></div>';
    return;
  }

  const root = document.createElement('div');
  root.className = 'financeiro-view';
  container.appendChild(root);

  const head = document.createElement('div');
  head.className = 'app-view-head fin-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Financeiro</h2>
      <p>Visão financeira da Felipe Branding.</p>
    </div>
    <div class="fin-head-actions">
      <div id="finPeriodoHost"></div>
      <button class="btn btn-primary btn-sm" id="finNovaMovBtn">Nova movimentação</button>
      <button class="btn btn-ghost btn-sm" id="finExportarBtn">Exportar</button>
    </div>
  `;
  root.appendChild(head);
  // 01/10: arrecadação da EvoluiSocial no mês (separada dos clientes da agência)
  root.appendChild(cartaoEvoluiFinanceiro());

  let cache = null; // { contratos, parcelas, despesas, leads } — reaproveitado pelos modais e ao trocar de período, sem recarregar tudo de novo
  let periodo = resolverPeriodo({ range: '30d' });

  head.querySelector('#finPeriodoHost').appendChild(renderDateRangeSelector({
    initial: { range: '30d' },
    // Só recalcula/redesenha com o que já está em cache — trocar o período
    // não precisa buscar nada de novo na rede (os dados completos já foram
    // carregados; o período só decide o que entra na soma).
    onChange: (value) => { periodo = resolverPeriodo(value); if (cache) montar(body, cache, carregar, periodo); },
  }));

  const body = document.createElement('div');
  root.appendChild(body);

  async function carregar() {
    body.innerHTML = '';
    body.appendChild(LoadingState({ variant: 'cards', rows: 4 }));
    try {
      const [contratos, parcelas, despesas, leads] = await Promise.all([
        listarContratos(), listarParcelas(), listarDespesas(), fetchTodosLeads(),
      ]);
      cache = { contratos, parcelas, despesas, leads };
      body.innerHTML = '';
      montar(body, cache, carregar, periodo);
    } catch (err) {
      body.innerHTML = '';
      body.appendChild(ErrorState({ description: err.message || 'Falha ao carregar o Financeiro.', onRetry: carregar }));
    }
  }

  head.querySelector('#finNovaMovBtn').addEventListener('click', () => abrirModalNovaMovimentacao(root, cache, carregar));
  head.querySelector('#finExportarBtn').addEventListener('click', () => {
    if (!cache) return;
    exportarCSV(cache, periodo);
  });

  await carregar();
}

function montar(body, { contratos, parcelas, despesas, leads }, onRecarregar, periodo) {
  // Limpa sempre aqui dentro (não em quem chama) — achado nesta auditoria:
  // trocar o período chamava montar() de novo sem limpar `body` antes,
  // duplicando todos os cards na tela em vez de substituí-los.
  body.innerHTML = '';
  if (contratos.length === 0 && despesas.length === 0) {
    body.appendChild(EmptyState({
      title: 'Nenhuma movimentação financeira registrada ainda',
      description: 'Comece criando o primeiro contrato (ligado a um cliente já existente no CRM) ou registrando uma despesa. Os indicadores abaixo aparecem assim que houver dados.',
    }));
    return;
  }

  const r = calcularResumoFinanceiro({ contratos, parcelas, despesas, leads, periodo });
  const periodoLabel = periodo?.label || 'período selecionado';

  // ---- Bloco 1: KPI hero — saldo disponível domina, o resto é secundário ----
  const kpiWrap = document.createElement('div');
  kpiWrap.className = 'fin-kpi-grid';
  kpiWrap.innerHTML = `
    <div class="card fin-kpi-hero">
      <div class="kpi-label">Saldo disponível</div>
      <div class="fin-kpi-hero-value">${formatBRL(r.saldoDisponivel)}</div>
      <div class="kpi-empty">Recebido − pago, com base no que está registrado no sistema</div>
    </div>
    <div class="fin-kpi-secondary">
      ${kpi({ label: 'A receber', value: formatBRL(r.aReceber), sublabel: r.pagamentosPendentes > 0 ? `${r.pagamentosPendentes} parcela(s) atrasada(s)` : null })}
      ${kpi({ label: 'A pagar', value: formatBRL(r.aPagar), sublabel: r.despesasPendentes > 0 ? `${r.despesasPendentes} despesa(s) atrasada(s)` : null })}
      ${kpi({ label: 'Receita contratada', value: formatBRL(r.receitaContratada), sublabel: 'contratos ativos' })}
      ${kpi({ label: 'Receita recorrente', value: formatBRL(r.receitaRecorrente), sublabel: r.receitaRecorrente > 0 ? 'valor mensal, contratos recorrentes ativos' : 'Nenhum contrato recorrente ativo' })}
      ${kpi({ label: 'Resultado do período', value: formatBRL(r.resultadoPeriodo), sublabel: `recebido − pago, ${periodoLabel}` })}
    </div>
  `;
  body.appendChild(kpiWrap);

  // ---- Bloco 2: Fluxo financeiro ----
  const serie = calcularSerieFluxo(parcelas, despesas, 6);
  const temFluxo = serie.receitas.some((v) => v > 0) || serie.despesas.some((v) => v > 0);
  const fluxoCard = document.createElement('section');
  fluxoCard.className = 'card';
  fluxoCard.innerHTML = `<div class="card-head"><h3>Fluxo financeiro</h3><span class="field-hint-inline">Últimos 6 meses</span></div>`;
  if (temFluxo) {
    fluxoCard.innerHTML += chartAreaHtml({
      categorias: serie.categorias,
      series: [
        { nome: 'Receitas', cor: 'var(--ok)', valores: serie.receitas },
        { nome: 'Despesas', cor: 'var(--danger)', valores: serie.despesas },
      ],
    });
  } else {
    fluxoCard.appendChild(EmptyState({ title: 'Sem pagamentos registrados ainda', description: 'O gráfico aparece assim que houver pelo menos uma parcela ou despesa marcada como paga.' }));
  }
  body.appendChild(fluxoCard);

  // ---- Bloco 3: Resumo do período (interpretação objetiva, sem inventar nada) ----
  const resumoCard = document.createElement('section');
  resumoCard.className = 'card';
  resumoCard.innerHTML = `
    <div class="card-head"><h3>Resumo do período</h3><span class="field-hint-inline">${periodoLabel}</span></div>
    <ul class="fin-resumo-lista">
      <li><strong>${formatBRL(r.recebidoNoPeriodo)}</strong> recebidos no período selecionado.</li>
      <li><strong>${r.compromissosProximos30d}</strong> compromisso(s) a receber nos próximos 30 dias (a partir de hoje, independente do período selecionado).</li>
      <li>${r.pagamentosPendentes > 0
        ? `<strong>${r.pagamentosPendentes}</strong> pagamento(s) de cliente em atraso.`
        : 'Nenhum pagamento de cliente em atraso.'}</li>
      <li>${r.despesasPendentes > 0
        ? `<strong>${r.despesasPendentes}</strong> despesa(s) em atraso.`
        : 'Nenhuma despesa em atraso.'}</li>
      <li>Resultado do período: <strong class="${r.resultadoPeriodo >= 0 ? 'fin-positivo' : 'fin-negativo'}">${formatBRL(r.resultadoPeriodo)}</strong>.</li>
    </ul>
  `;
  body.appendChild(resumoCard);

  // ---- Bloco 4: Receita por cliente ----
  const clienteCard = document.createElement('section');
  clienteCard.className = 'card';
  clienteCard.innerHTML = `<div class="card-head"><h3>Receita por cliente</h3></div>`;
  if (r.receitaPorCliente.length === 0) {
    clienteCard.appendChild(EmptyState({ title: 'Nenhum contrato registrado', description: 'Crie o primeiro contrato em "Nova movimentação" para ver a receita por cliente aqui.' }));
  } else {
    const wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    wrap.innerHTML = `
      <table class="app-table">
        <thead><tr><th>Cliente</th><th>Serviço</th><th>Valor</th><th>Recebido</th><th>Em aberto</th><th>Status</th></tr></thead>
        <tbody>
          ${r.receitaPorCliente.map((l) => `
            <tr>
              <td><button class="fin-link-cliente" data-lead-id="${l.leadId}">${esc(l.nome)}</button></td>
              <td>${SERVICO_LABEL[l.servico] || esc(l.servico)}</td>
              <td>${formatBRL(l.contratado)}</td>
              <td>${formatBRL(l.recebido)}</td>
              <td>${formatBRL(l.emAberto)}</td>
              <td>${l.status === 'quitado' ? '<span class="badge badge-ok">Quitado</span>' : l.status === 'parcial' ? '<span class="badge badge-warning">Parcial</span>' : '<span class="badge badge-demo">Em aberto</span>'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
    clienteCard.appendChild(wrap);
    clienteCard.querySelectorAll('.fin-link-cliente').forEach((btn) => {
      btn.addEventListener('click', () => { window.location.hash = `#/clientes/${btn.dataset.leadId}`; });
    });
  }
  body.appendChild(clienteCard);

  // ---- Bloco 5: Próximos vencimentos ----
  const vencCard = document.createElement('section');
  vencCard.className = 'card';
  vencCard.innerHTML = `<div class="card-head"><h3>Próximos vencimentos</h3></div>`;
  if (r.proximosVencimentos.length === 0) {
    vencCard.appendChild(EmptyState({ title: 'Nada a receber pendente', description: 'Todas as parcelas registradas já estão pagas ou canceladas.' }));
  } else {
    const lista = document.createElement('div');
    lista.className = 'fin-venc-lista';
    lista.innerHTML = r.proximosVencimentos.slice(0, 10).map((p) => `
      <div class="fin-venc-item">
        <div>
          <div class="fin-venc-cliente">${esc(p.nomeCliente)}</div>
          <div class="fin-venc-data">${formatDataBR(p.vencimento)} · parcela ${p.numero}</div>
        </div>
        <div class="fin-venc-valor">${formatBRL(p.valor)}</div>
        ${badgeStatus(p.statusEfetivo, STATUS_PARCELA_LABEL)}
        <button class="btn btn-ghost btn-xs" data-marcar-pago="${p.id}">Marcar como pago</button>
      </div>
    `).join('');
    vencCard.appendChild(lista);
    vencCard.querySelectorAll('[data-marcar-pago]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await atualizarStatusParcela(btn.dataset.marcarPago, { status: 'pago' });
          showToast('Parcela marcada como paga.', { tone: 'ok' });
          onRecarregar();
        } catch (err) {
          showToast(err.message || 'Falha ao atualizar parcela.', { tone: 'danger' });
        }
      });
    });
  }
  body.appendChild(vencCard);

  // ---- Bloco 6: Despesas ----
  const despCard = document.createElement('section');
  despCard.className = 'card';
  despCard.innerHTML = `<div class="card-head"><h3>Despesas</h3></div>`;
  if (r.despesasPorCategoria.length === 0) {
    despCard.appendChild(EmptyState({ title: 'Nenhuma despesa registrada', description: 'Registre uma despesa em "Nova movimentação" para ver as categorias aqui.' }));
  } else {
    const pendentes = r.despesasComEfetivo
      .filter((d) => d.statusEfetivo !== 'pago' && d.statusEfetivo !== 'cancelado')
      .sort((a, b) => (a.vencimento < b.vencimento ? -1 : 1));
    if (pendentes.length > 0) {
      const subPendentes = document.createElement('div');
      subPendentes.className = 'fin-venc-lista';
      subPendentes.style.marginBottom = 'var(--space-5)';
      subPendentes.innerHTML = pendentes.slice(0, 8).map((d) => `
        <div class="fin-venc-item">
          <div>
            <div class="fin-venc-cliente">${esc(d.descricao)}${d.fornecedor ? ` — ${esc(d.fornecedor)}` : ''}</div>
            <div class="fin-venc-data">${formatDataBR(d.vencimento)} · ${CATEGORIA_DESPESA_LABEL[d.categoria] || esc(d.categoria)}</div>
          </div>
          <div class="fin-venc-valor">${formatBRL(d.valor)}</div>
          ${badgeStatus(d.statusEfetivo, STATUS_DESPESA_LABEL)}
          <button class="btn btn-ghost btn-xs" data-pagar-despesa="${d.id}">Marcar como pago</button>
          <button class="btn btn-ghost btn-xs" data-excluir-despesa="${d.id}" data-desc="${esc(d.descricao)}" style="color:var(--danger)">Excluir</button>
        </div>
      `).join('');
      despCard.appendChild(subPendentes);
      subPendentes.querySelectorAll('[data-pagar-despesa]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          try {
            await atualizarDespesa(btn.dataset.pagarDespesa, { status: 'pago' });
            showToast('Despesa marcada como paga.', { tone: 'ok' });
            onRecarregar();
          } catch (err) {
            showToast(err.message || 'Falha ao atualizar despesa.', { tone: 'danger' });
          }
        });
      });
      subPendentes.querySelectorAll('[data-excluir-despesa]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const ok = await confirmDialog({
            title: 'Excluir despesa?',
            description: `"${btn.dataset.desc}" será excluída permanentemente.`, // confirmDialog escapa (29/09)
            confirmLabel: 'Excluir',
          });
          if (!ok) return;
          try {
            await excluirDespesa(btn.dataset.excluirDespesa);
            showToast('Despesa excluída.', { tone: 'ok' });
            onRecarregar();
          } catch (err) {
            showToast(err.message || 'Falha ao excluir despesa.', { tone: 'danger' });
          }
        });
      });
    }

    const maxValor = Math.max(...r.despesasPorCategoria.map((c) => c.valor));
    const lista = document.createElement('div');
    lista.className = 'fin-categoria-lista';
    lista.innerHTML = r.despesasPorCategoria.map((c) => `
      <div class="fin-categoria-item">
        <div class="fin-categoria-nome">${CATEGORIA_DESPESA_LABEL[c.categoria] || esc(c.categoria)}</div>
        <div class="fin-categoria-barra"><div class="fin-categoria-barra-fill" style="width:${Math.max(4, (c.valor / maxValor) * 100)}%"></div></div>
        <div class="fin-categoria-valor">${formatBRL(c.valor)}</div>
      </div>
    `).join('');
    despCard.appendChild(lista);
  }
  body.appendChild(despCard);

  // ---- Aquisição (só se houver dado suficiente) ----
  if (r.receitaPorOrigem) {
    const origemCard = document.createElement('section');
    origemCard.className = 'card';
    origemCard.innerHTML = `<div class="card-head"><h3>Receita por origem de aquisição</h3></div>`;
    const lista = document.createElement('div');
    lista.className = 'fin-categoria-lista';
    const maxValor = Math.max(...r.receitaPorOrigem.map((o) => o.valor));
    lista.innerHTML = r.receitaPorOrigem.map((o) => `
      <div class="fin-categoria-item">
        <div class="fin-categoria-nome">${ORIGEM_LABEL[o.origem] || esc(o.origem)}</div>
        <div class="fin-categoria-barra"><div class="fin-categoria-barra-fill" style="width:${Math.max(4, (o.valor / maxValor) * 100)}%"></div></div>
        <div class="fin-categoria-valor">${formatBRL(o.valor)}</div>
      </div>
    `).join('');
    origemCard.appendChild(lista);
    body.appendChild(origemCard);
  }
}

// Anexado dentro de `root` (.financeiro-view) pro tema escopado valer no
// modal. 29/09: modal compartilhado (foco preso, Esc, foco devolvido).
function abrirModal(root, innerHtml, maxWidth = '520px') {
  return abrirModalBase({ html: innerHtml, host: root, maxWidth });
}

function abrirModalNovaMovimentacao(root, cache, onSalvo) {
  if (!cache) return;
  const { close, box } = abrirModal(root, `
    <h3 style="margin-bottom:var(--space-4)">Nova movimentação</h3>
    <div class="fin-tab-switch">
      <button type="button" class="fin-tab is-active" data-tab="contrato">Novo contrato (receita)</button>
      <button type="button" class="fin-tab" data-tab="despesa">Nova despesa</button>
    </div>
    <div id="finTabHost"></div>
  `, '600px');

  const tabHost = box.querySelector('#finTabHost');
  function selecionarTab(tab) {
    box.querySelectorAll('.fin-tab').forEach((b) => b.classList.toggle('is-active', b.dataset.tab === tab));
    tabHost.innerHTML = '';
    tabHost.appendChild(tab === 'contrato' ? formContrato() : formDespesa());
  }
  box.querySelectorAll('.fin-tab').forEach((b) => b.addEventListener('click', () => selecionarTab(b.dataset.tab)));

  function formContrato() {
    const wrap = document.createElement('div');
    // Clientes já existentes no CRM (admin_prospeccao_leads) — 'cliente'
    // primeiro (mais provável), depois os demais estágios em negociação.
    const leadsOrdenados = [...cache.leads].sort((a, b) => (a.status === 'cliente' ? -1 : 1) - (b.status === 'cliente' ? -1 : 1));
    wrap.innerHTML = `
      <div class="content-editor-form">
        <div class="field field-full">
          <label for="fc_leadId">Cliente (já existente no CRM)</label>
          <select id="fc_leadId">
            <option value="">Selecione...</option>
            ${leadsOrdenados.map((l) => `<option value="${l.id}">${esc(l.empresa)}${l.status !== 'cliente' ? ` — ${esc(l.status)}` : ''}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label for="fc_servico">Serviço</label>
          <select id="fc_servico">${Object.entries(SERVICO_LABEL).map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select>
        </div>
        <div class="field"><label for="fc_valor">Valor total (R$)</label><input id="fc_valor" type="number" min="0.01" step="0.01" inputmode="decimal"></div>
        <div class="field"><label for="fc_dataInicio">Data de início</label><input id="fc_dataInicio" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
        <div class="field"><label for="fc_parcelas">Número de parcelas</label><input id="fc_parcelas" type="number" min="1" step="1" value="1"></div>
        <div class="field field-full">
          <label><input type="checkbox" id="fc_recorrente" style="width:auto;margin-right:6px"> Contrato recorrente (gestão mensal)</label>
          <p class="field-hint">Pra gestão mensal contínua: deixe 1 parcela e informe o valor mensal em "Valor total" — cada novo ciclo vira um contrato novo. "Receita recorrente" soma só contratos ativos marcados aqui.</p>
        </div>
        <div class="field field-full"><label for="fc_obs">Observações</label><textarea id="fc_obs" rows="2"></textarea></div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:var(--space-3)">
        <button class="btn btn-ghost btn-sm" id="fc_cancelar">Cancelar</button>
        <button class="btn btn-primary btn-sm" id="fc_salvar">Criar contrato</button>
      </div>
    `;
    wrap.querySelector('#fc_cancelar').addEventListener('click', close);
    wrap.querySelector('#fc_salvar').addEventListener('click', async () => {
      const leadId = wrap.querySelector('#fc_leadId').value;
      const valorTotal = Number(wrap.querySelector('#fc_valor').value);
      if (!leadId) { showToast('Selecione o cliente.', { tone: 'danger' }); return; }
      if (!valorTotal || valorTotal <= 0) { showToast('Informe um valor total válido.', { tone: 'danger' }); return; }
      try {
        await criarContrato({
          leadId,
          servico: wrap.querySelector('#fc_servico').value,
          valorTotal,
          dataInicio: wrap.querySelector('#fc_dataInicio').value,
          numeroParcelas: Number(wrap.querySelector('#fc_parcelas').value) || 1,
          recorrente: wrap.querySelector('#fc_recorrente').checked,
          observacoes: wrap.querySelector('#fc_obs').value.trim(),
        });
        showToast('Contrato criado.', { tone: 'ok' });
        close();
        onSalvo();
      } catch (err) {
        showToast(err.message || 'Falha ao criar contrato.', { tone: 'danger' });
      }
    });
    return wrap;
  }

  function formDespesa() {
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <div class="content-editor-form">
        <div class="field">
          <label for="fd_categoria">Categoria</label>
          <select id="fd_categoria">${Object.entries(CATEGORIA_DESPESA_LABEL).map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select>
        </div>
        <div class="field"><label for="fd_fornecedor">Fornecedor</label><input id="fd_fornecedor"></div>
        <div class="field field-full"><label for="fd_descricao">Descrição</label><input id="fd_descricao"></div>
        <div class="field"><label for="fd_valor">Valor (R$)</label><input id="fd_valor" type="number" min="0.01" step="0.01" inputmode="decimal"></div>
        <div class="field"><label for="fd_vencimento">Vencimento</label><input id="fd_vencimento" type="date" value="${new Date().toISOString().slice(0, 10)}"></div>
        <div class="field field-full">
          <label><input type="checkbox" id="fd_recorrente" style="width:auto;margin-right:6px"> Despesa recorrente</label>
        </div>
        <div class="field field-full"><label for="fd_comprovante">Link do comprovante (opcional)</label><input id="fd_comprovante" type="url" placeholder="https://..."></div>
        <div class="field field-full"><label for="fd_obs">Observações</label><textarea id="fd_obs" rows="2"></textarea></div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:var(--space-3)">
        <button class="btn btn-ghost btn-sm" id="fd_cancelar">Cancelar</button>
        <button class="btn btn-primary btn-sm" id="fd_salvar">Registrar despesa</button>
      </div>
    `;
    wrap.querySelector('#fd_cancelar').addEventListener('click', close);
    wrap.querySelector('#fd_salvar').addEventListener('click', async () => {
      const descricao = wrap.querySelector('#fd_descricao').value.trim();
      const valor = Number(wrap.querySelector('#fd_valor').value);
      const vencimento = wrap.querySelector('#fd_vencimento').value;
      if (!descricao) { showToast('Informe a descrição.', { tone: 'danger' }); return; }
      if (!valor || valor <= 0) { showToast('Informe um valor válido.', { tone: 'danger' }); return; }
      if (!vencimento) { showToast('Informe o vencimento.', { tone: 'danger' }); return; }
      try {
        await criarDespesa({
          categoria: wrap.querySelector('#fd_categoria').value,
          descricao,
          fornecedor: wrap.querySelector('#fd_fornecedor').value.trim(),
          valor,
          vencimento,
          recorrente: wrap.querySelector('#fd_recorrente').checked,
          comprovanteUrl: wrap.querySelector('#fd_comprovante').value.trim(),
          observacoes: wrap.querySelector('#fd_obs').value.trim(),
        });
        showToast('Despesa registrada.', { tone: 'ok' });
        close();
        onSalvo();
      } catch (err) {
        showToast(err.message || 'Falha ao registrar despesa.', { tone: 'danger' });
      }
    });
    return wrap;
  }

  selecionarTab('contrato');
}

/** Exporta parcelas + despesas em aberto/pagas (tudo que está carregado) como CSV — mesmo padrão (BOM UTF-8) já usado em csvLeads.js. */
/**
 * Exporta o que caiu (venceu ou foi pago) dentro do período selecionado no
 * header — mesmo período usado nos KPIs, pra exportar bater com o que a
 * pessoa está vendo na tela na hora de clicar "Exportar".
 */
function exportarCSV({ contratos, parcelas, despesas, leads }, periodo) {
  const leadPorId = new Map(leads.map((l) => [l.id, l]));
  const contratoPorId = new Map(contratos.map((c) => [c.id, c]));
  const dentroDoPeriodo = (item) => {
    const dataRelevante = item.pago_em || item.vencimento;
    return dataRelevante >= periodo.inicioIso && dataRelevante <= periodo.fimIso;
  };
  const linhas = [['tipo', 'cliente_ou_fornecedor', 'descricao', 'valor', 'vencimento', 'status', 'pago_em']];
  parcelas.filter(dentroDoPeriodo).forEach((p) => {
    const contrato = contratoPorId.get(p.contrato_id);
    const lead = contrato ? leadPorId.get(contrato.lead_id) : null;
    linhas.push(['receita', lead ? lead.empresa : '', `Parcela ${p.numero}${contrato ? ' — ' + (SERVICO_LABEL[contrato.servico] || contrato.servico) : ''}`, p.valor, p.vencimento, statusEfetivo(p), p.pago_em || '']);
  });
  despesas.filter(dentroDoPeriodo).forEach((d) => {
    linhas.push(['despesa', d.fornecedor || '', d.descricao, d.valor, d.vencimento, statusEfetivo(d), d.pago_em || '']);
  });
  if (linhas.length === 1) {
    showToast(`Nada para exportar em ${periodo.label}.`, { tone: 'danger' });
    return;
  }
  const csv = linhas.map((l) => l.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(';')).join('\n');
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `financeiro-felipe-branding-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
