/**
 * EvoluiSocial — módulo do painel (01/10/2026). Admin-only.
 *
 * Abas:
 *  - Visão geral: usuários, uso, funil, o que as pessoas pesquisam e respondem, agentes.
 *  - Usuários: lista com plano, segmento, engajamento; mudar plano/bloquear (fica registrado).
 *  - Segurança: alertas do agente de segurança (rajadas, várias contas, tentativa de burlar plano...).
 *  - Financeiro: arrecadado por mês (Mercado Pago), pagamentos, preços e conta de recebimento.
 *  - Repertório: Central de Repertório (conhecimento que o Evolui organiza e usa nas pesquisas).
 *  - Taxonomia / Imagens: banco de imagens (Área > Subramo > Tema) usado nos cards.
 *  - Plataforma: papéis (user/admin/owner), saúde das fontes de dados, agentes, rotinas e conteúdos.
 *
 * Papéis: a autorização é toda no banco (evolui_eh_admin / evolui_eh_owner). Esconder botão aqui é só conforto.
 * Senhas: o painel nunca vê nem define senha; só dispara o e-mail oficial de redefinição.
 *
 * Regra: nenhum número inventado. Tudo vem de evolui_admin_* (banco).
 */
import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { chartAreaHtml } from '../components/ChartArea.js';
import { getCurrentUser } from '../services/auth.js';
import { ehAdmin } from '../services/rbac.js';
import { esc } from '../utils/html.js';
import { abrirModal } from '../components/Modal.js';
import { abaRepertorio } from './evoluiRepertorio.js';
import { abaTaxonomia } from './evoluiTaxonomia.js';
import { abaImagens } from './evoluiImagens.js';
import {
  resumoEvolui, usuariosEvolui, alertasEvolui, resolverAlertaEvolui, definirUsuarioEvolui,
  rodarAgentesEvolui, financeiroEvolui, configEvolui, plataformaEvolui, definirPapelEvolui, iniciarResetEvolui,
  integracoesEvolui, salvarIntegracaoEvolui, removerIntegracaoEvolui, testarIntegracaoEvolui,
  solicitacoesEvolui, decidirSolicitacaoEvolui,
} from '../services/evoluiAdminClient.js';

const brl = (c) => (Number(c || 0) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const num = (n) => Number(n || 0).toLocaleString('pt-BR');
const dataBR = (d) => (d ? new Date(d).toLocaleDateString('pt-BR') : '—');
const dataHoraBR = (d) => (d ? new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');
const PLANO = { free: 'Free', pro: 'Pro', master: 'Master' };
const PAPEL = { user: 'Usuário', admin: 'Administrador', owner: 'Proprietário' };
const FONTE = { wikipedia: 'Wikipédia', gdelt: 'Notícias (GDELT, pelo servidor)', gdelt_navegador: 'Notícias (GDELT, pelo navegador)', google_trends: 'Google Trends', ibge: 'IBGE (cidades)', openstreetmap: 'OpenStreetMap', oembed_youtube: 'YouTube (oEmbed)', oembed_tiktok: 'TikTok (oEmbed)', youtube: 'YouTube (busca de vídeos)', geoapify: 'Geoapify (mapa, opcional)' };
const SEGMENTO = { novo: 'Novo', ativo: 'Ativo', morno: 'Morno', inativo: 'Inativo', sem_calculo: 'Ainda sem cálculo' };
const RAMO = {
  doces: 'Doces e confeitaria', alimentacao: 'Alimentação', beleza: 'Beleza e estética', moda: 'Moda', saude: 'Saúde',
  fitness: 'Fitness', pet: 'Pet', casa: 'Casa e decoração', educacao: 'Educação', servicos: 'Serviços', criador: 'Criador', outro: 'Outro', sem: 'Não informado',
};
const ALERTA = {
  rajada: 'Rajada de buscas', multi_conta: 'Várias contas no mesmo acesso', forcando_limite: 'Forçando o limite do plano',
  plano_adulterado: 'Tentativa de mudar o plano sem pagar', eventos_excesso: 'Excesso de registros de uso',
  pagamento_divergente: 'Pagamento divergente', conta_bloqueada: 'Conta bloqueada', outro: 'Outro',
};
const ESTADO = { em_alta: 'Em alta', crescendo: 'Crescendo', comecando: 'Começando', estavel: 'Estável', caindo: 'Caindo', pico: 'Pico', insuficiente: 'Sem dados' };
const GRAV = { alta: 'badge-danger', media: 'badge-warning', baixa: 'badge-info' };
const STATUS_PAG = { aprovado: 'badge-ok', pendente: 'badge-demo', em_analise: 'badge-info', recusado: 'badge-danger', reembolsado: 'badge-warning', cancelado: 'badge-demo', estornado: 'badge-danger' };

function barras(itens, { rotulo = (x) => x.k, valor = (x) => x.v, formato = num } = {}) {
  const max = Math.max(1, ...itens.map(valor));
  return `<div class="ev-barras">${itens.map((x) => `
    <div class="ev-barra"><span class="ev-barra-rot">${esc(rotulo(x))}</span>
    <span class="ev-barra-trilho"><i style="width:${Math.round((valor(x) / max) * 100)}%"></i></span>
    <b>${esc(formato(valor(x)))}</b></div>`).join('')}</div>`;
}
function kpi(label, valor, sub, destaque) {
  return `<div class="card kpi-card${destaque ? ' ev-kpi-destaque' : ''}"><div class="kpi-label">${esc(label)}</div><div class="kpi-value">${valor}</div>${sub ? `<div class="kpi-empty">${sub}</div>` : ''}</div>`;
}

export async function renderEvoluiSocial(container) {
  container.innerHTML = '';
  const user = await getCurrentUser();
  if (!ehAdmin(user)) {
    container.innerHTML = '<div class="app-view-head"><h2>Acesso restrito</h2><p>A área da EvoluiSocial é exclusiva de administradores.</p></div>';
    return;
  }
  const root = document.createElement('div');
  root.className = 'evolui-view';
  container.appendChild(root);
  const aba0 = (location.hash.split('?')[1] || '').replace('aba=', '') || 'geral';
  root.innerHTML = `
    <div class="app-view-head ev-head">
      <div><p class="eyebrow">Produto da Felipe Branding</p><h2>EvoluiSocial</h2><p>Quem usa, o que pesquisa, quanto arrecada e o que os agentes encontraram.</p></div>
      <div class="ev-head-acoes">
        <select id="evDias" class="ev-select" aria-label="Período"><option value="7">7 dias</option><option value="30" selected>30 dias</option><option value="90">90 dias</option></select>
        <button class="btn btn-ghost btn-sm" id="evAgentes">Rodar agentes agora</button>
        <a class="btn btn-ghost btn-sm" href="/evoluisocial/" target="_blank" rel="noopener">Abrir o site ↗</a>
      </div>
    </div>
    <div class="ev-abas" role="tablist">
      ${[['geral', 'Visão geral'], ['usuarios', 'Usuários'], ['seguranca', 'Segurança'], ['financeiro', 'Financeiro'], ['plataforma', 'Plataforma'], ['repertorio', 'Repertório'], ['taxonomia', 'Taxonomia'], ['imagens', 'Imagens'], ['integracoes', 'Integrações'], ['solicitacoes', 'Solicitações']].map(([k, t]) => `<button class="tab-btn${k === aba0 ? ' is-active' : ''}" role="tab" aria-selected="${k === aba0}" data-aba="${k}">${t}<span class="ev-aba-badge" id="evBadge-${k}" hidden></span></button>`).join('')}
    </div>
    <div id="evCorpo"></div>`;
  const corpo = root.querySelector('#evCorpo');
  let aba = aba0;
  const abrir = (k) => {
    aba = k;
    root.querySelectorAll('[data-aba]').forEach((b) => { const on = b.dataset.aba === k; b.classList.toggle('is-active', on); b.setAttribute('aria-selected', String(on)); });
    (({ geral: abaGeral, usuarios: abaUsuarios, seguranca: abaSeguranca, financeiro: abaFinanceiro, plataforma: abaPlataforma, repertorio: abaRepertorio, taxonomia: abaTaxonomia, imagens: abaImagens, integracoes: abaIntegracoes, solicitacoes: abaSolicitacoes })[k] || abaGeral)(corpo, root);
  };
  root.querySelectorAll('[data-aba]').forEach((b) => b.addEventListener('click', () => abrir(b.dataset.aba)));
  root.querySelector('#evDias').addEventListener('change', () => { if (aba === 'geral') abrir('geral'); });
  root.querySelector('#evAgentes').addEventListener('click', async (e) => {
    const b = e.currentTarget; b.disabled = true; b.textContent = 'Rodando…';
    try {
      const r = await rodarAgentesEvolui();
      showToast(`Agentes rodaram: ${r.seguranca?.rajadas || 0} rajada(s), ${r.seguranca?.multi_conta || 0} multi-conta, ${r.planos_expirados || 0} plano(s) vencido(s).`, { tone: 'ok' });
      abrir(aba);
    } catch (err) { showToast(err.message, { tone: 'danger' }); }
    b.disabled = false; b.textContent = 'Rodar agentes agora';
  });
  alertasEvolui(true).then((a) => { const n = (a || []).length; const el = root.querySelector('#evBadge-seguranca'); if (el) { el.hidden = !n; el.textContent = n; } }).catch(() => {});
  solicitacoesEvolui('pendente').then((a) => { const n = (a || []).length; const el = root.querySelector('#evBadge-solicitacoes'); if (el) { el.hidden = !n; el.textContent = n; } }).catch(() => {});
  abrir(aba);
}

// ------------------------------------------------------------------ visão geral
async function abaGeral(corpo, root) {
  corpo.innerHTML = '';
  corpo.appendChild(LoadingState({ variant: 'cards', rows: 4 }));
  const dias = Number(root.querySelector('#evDias').value) || 30;
  let r;
  try { r = await resumoEvolui(dias); } catch (err) { corpo.innerHTML = ''; corpo.appendChild(ErrorState({ description: err.message, onRetry: () => abaGeral(corpo, root) })); return; }
  const rec = r.receita || {};
  const delta = rec.mes_anterior_centavos ? Math.round(((rec.mes_centavos - rec.mes_anterior_centavos) / rec.mes_anterior_centavos) * 100) : null;
  const serie = r.serie || [];
  const funil = r.funil || {};
  const etapas = [['Cadastrados', funil.cadastrados], ['Perfil completo', funil.perfil_completo], ['Fizeram busca', funil.fez_busca], ['Salvaram ideia', funil.salvou_ideia], ['Usaram o laboratório', funil.usou_lab], ['Pagaram', funil.pagou]];
  corpo.innerHTML = `
    <div class="kpi-grid ev-kpis">
      ${kpi('Usuários', num(r.usuarios), `+${num(r.novos_periodo)} nos últimos ${r.periodo_dias} dias`)}
      ${kpi('Ativos em 7 dias', num(r.ativos_7d), `${num(r.ativos_30d)} em 30 dias`)}
      ${kpi('Pesquisas hoje', num(r.buscas_hoje), `${num(r.buscas_periodo)} no período`)}
      ${kpi('Assinantes', num(rec.assinantes_ativos), `${num(r.interesse_planos)} pessoa(s) olharam os planos`)}
      ${kpi('Arrecadado no mês', brl(rec.mes_centavos), delta == null ? 'Sem base do mês anterior' : `${delta >= 0 ? '+' : ''}${delta}% vs. mês anterior`, true)}
      ${kpi('Alertas abertos', num(r.alertas_abertos), r.alertas_altos ? `<span class="ev-alto">${num(r.alertas_altos)} de gravidade alta</span>` : 'Nada grave')}
    </div>
    <section class="card"><div class="card-head"><h3>Uso por dia</h3><span class="field-hint-inline">Pesquisas e novos cadastros · ${r.periodo_dias} dias</span></div>
      ${serie.some((d) => d.buscas || d.novos) ? chartAreaHtml({
        categorias: serie.map((d) => d.dia.slice(8, 10) + '/' + d.dia.slice(5, 7)),
        series: [{ nome: 'Pesquisas', cor: 'var(--star)', valores: serie.map((d) => d.buscas) }, { nome: 'Novos usuários', cor: 'var(--info)', valores: serie.map((d) => d.novos) }],
      }) : '<p class="kpi-empty">Ainda sem uso no período.</p>'}
    </section>
    <div class="ev-grade">
      <section class="card"><div class="card-head"><h3>Funil</h3><span class="field-hint-inline">Do cadastro ao pagamento</span></div>
        ${barras(etapas.map(([k, v]) => ({ k, v: v || 0 })))}
      </section>
      <section class="card"><div class="card-head"><h3>Planos e engajamento</h3><span class="field-hint-inline">Engajamento médio: ${r.engajamento_medio ?? '—'}/100</span></div>
        ${barras(Object.entries(r.por_plano || {}).map(([k, v]) => ({ k: PLANO[k] || k, v })))}
        <h4 class="ev-sub">Segmentos (agente de perfil)</h4>
        ${barras(Object.entries(r.por_segmento || {}).map(([k, v]) => ({ k: SEGMENTO[k] || k, v })))}
      </section>
    </div>
    <div class="ev-grade">
      <section class="card"><div class="card-head"><h3>O que estão pesquisando</h3><span class="field-hint-inline">${r.periodo_dias} dias</span></div>
        ${(r.top_termos || []).length ? `<div class="table-wrap"><table class="app-table"><thead><tr><th>Termo</th><th>Pesquisas</th><th>Pessoas</th></tr></thead><tbody>
          ${r.top_termos.map((t) => `<tr><td>${esc(t.termo)}</td><td>${num(t.n)}</td><td>${num(t.pessoas)}</td></tr>`).join('')}</tbody></table></div>` : '<p class="kpi-empty">Nenhuma pesquisa no período.</p>'}
        <h4 class="ev-sub">Resultado das pesquisas</h4>
        ${barras(Object.entries(r.estados || {}).map(([k, v]) => ({ k: ESTADO[k] || k, v })))}
      </section>
      <section class="card"><div class="card-head"><h3>Quem são</h3><span class="field-hint-inline">Ramo e cidade</span></div>
        ${barras((r.top_ramos || []).map((x) => ({ k: RAMO[x.ramo] || x.ramo, v: x.n })))}
        <h4 class="ev-sub">Cidades</h4>
        ${barras((r.top_cidades || []).map((x) => ({ k: `${x.cidade}/${x.uf}`, v: x.n })))}
      </section>
    </div>
    <section class="card"><div class="card-head"><h3>O que eles respondem na pergunta do dia</h3><span class="field-hint-inline">${num(r.respostas_hoje)} resposta(s) hoje · ${r.periodo_dias} dias</span></div>
      ${(r.respostas || []).length ? `<div class="ev-grade ev-grade-3">${r.respostas.map((q) => `<div class="ev-pergunta"><b>${esc(q.texto)}</b>${barras(Object.entries(q.opcoes || {}).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ k, v })))}</div>`).join('')}</div>`
        : '<p class="kpi-empty">Ainda ninguém respondeu. A pergunta aparece uma vez por dia para quem entra no app.</p>'}
    </section>
    <section class="card"><div class="card-head"><h3>Agentes</h3><span class="field-hint-inline">Robôs que rodam sozinhos no banco</span></div>
      <div class="ev-grade">${(r.agentes || []).map((a) => `<div class="ev-agente"><div class="ev-agente-topo"><b>${a.nome === 'seguranca' ? 'Agente de segurança' : a.nome === 'perfil' ? 'Agente de perfil' : esc(a.nome)}</b><span class="badge ${a.ultima_execucao ? 'badge-ok' : 'badge-demo'}">${a.ultima_execucao ? 'Rodou ' + dataHoraBR(a.ultima_execucao) : 'Ainda não rodou'}</span></div><p>${esc(a.descricao || '')}</p><code>${esc(JSON.stringify(a.resultado || {}))}</code></div>`).join('')}</div>
    </section>`;
}

// ------------------------------------------------------------------ usuários
let meuPapel = null;
async function abaUsuarios(corpo) {
  corpo.innerHTML = `<section class="card"><div class="card-head"><h3>Usuários</h3><input id="evBusca" class="ev-input" type="search" placeholder="Buscar por nome, e-mail ou cidade" aria-label="Buscar usuário"></div><div id="evLista"></div></section>`;
  const lista = corpo.querySelector('#evLista');
  let t;
  const carregar = async () => {
    lista.innerHTML = ''; lista.appendChild(LoadingState({ rows: 5 }));
    let us;
    try { us = await usuariosEvolui(corpo.querySelector('#evBusca').value.trim()); } catch (err) { lista.innerHTML = ''; lista.appendChild(ErrorState({ description: err.message, onRetry: carregar })); return; }
    lista.innerHTML = '';
    if (!us.length) { lista.appendChild(EmptyState({ title: 'Nenhum usuário encontrado', description: 'Quando alguém entrar com Google na EvoluiSocial, aparece aqui.' })); return; }
    lista.innerHTML = `<div class="table-wrap"><table class="app-table ev-tabela"><thead><tr><th>Pessoa</th><th>Negócio</th><th>Plano</th><th>Uso</th><th>Segmento</th><th>Último acesso</th><th></th></tr></thead><tbody>
      ${us.map((u) => `<tr>
        <td><b>${esc(u.nome || '—')}</b>${u.papel && u.papel !== 'user' ? ` <span class="badge badge-info">${esc(PAPEL[u.papel] || u.papel)}</span>` : ''}<br><span class="ev-muted">${esc(u.email || '')}</span>${u.bloqueado ? '<br><span class="badge badge-danger">Bloqueado</span>' : ''}${u.banido ? '<br><span class="badge badge-danger">Acesso suspenso</span>' : ''}${u.email_confirmado === false ? '<br><span class="badge badge-warning">E-mail não confirmado</span>' : ''}${u.alertas ? `<br><span class="badge badge-warning">${u.alertas} alerta(s)</span>` : ''}</td>
        <td>${esc(RAMO[u.ramo] || u.ramo || '—')}<br><span class="ev-muted">${esc(u.cidade ? `${u.cidade}/${u.uf}` : '')}</span>${(u.redes || []).map((r) => `<br><span class="ev-muted">${esc(r.rede)} @${esc(r.usuario)}</span>`).join('')}</td>
        <td><span class="badge ${u.plano === 'free' ? 'badge-demo' : 'badge-ok'}">${PLANO[u.plano] || esc(u.plano)}</span>${u.plano_ate ? `<br><span class="ev-muted">até ${dataBR(u.plano_ate)}</span>` : ''}</td>
        <td>${num(u.buscas_mes)} no mês<br><span class="ev-muted">${num(u.buscas_total)} no total · ${num(u.salvos)} salvos · ${num(u.testes)} testes</span></td>
        <td>${esc(SEGMENTO[u.segmento] || '—')}<br><span class="ev-muted">engajamento ${u.engajamento ?? '—'}/100${u.personalizar === false ? ' · personalização desligada' : ''}</span></td>
        <td>${dataHoraBR(u.ultimo_acesso || u.ultimo)}<br><span class="ev-muted">login ${dataHoraBR(u.ultimo_login)} · desde ${dataBR(u.criado_em)}</span>${(u.provedores || []).length ? `<br><span class="ev-muted">entra com ${esc((u.provedores || []).map((p) => (p === 'google' ? 'Google' : p === 'email' ? 'e-mail e senha' : p)).join(' + '))}</span>` : ''}${u.conteudos ? `<br><span class="ev-muted">${num(u.conteudos)} conteúdo(s)</span>` : ''}</td>
        <td><button class="btn btn-ghost btn-xs" data-gerir="${esc(u.id)}">Gerenciar</button></td></tr>`).join('')}
      </tbody></table></div><p class="kpi-empty">Mudanças de plano e bloqueios ficam registrados (quem fez e quando).</p>`;
    lista.querySelectorAll('[data-gerir]').forEach((b) => b.addEventListener('click', () => gerir(us.find((x) => x.id === b.dataset.gerir), carregar, b)));
    meuPapel = meuPapel || await plataformaEvolui().then((p) => p?.meu_papel || 'admin').catch(() => 'admin');
  };
  corpo.querySelector('#evBusca').addEventListener('input', () => { clearTimeout(t); t = setTimeout(carregar, 350); });
  carregar();
}
function gerir(u, depois, origem) {
  const { box, close } = abrirModal({
    titulo: u.nome || u.email,
    origem,
    maxWidth: '480px',
    html: `<p class="ev-muted" style="margin-top:-8px">${esc(u.email || '')}</p>
      <div class="field"><label for="evGP">Plano</label><select id="evGP">${['free', 'pro', 'master'].map((p) => `<option value="${p}"${p === u.plano ? ' selected' : ''}>${PLANO[p]}</option>`).join('')}</select></div>
      <div class="field"><label for="evGD">Por quantos dias? (vazio = sem data de fim)</label><input id="evGD" type="number" min="1" max="400" placeholder="ex.: 30"></div>
      <p class="field-hint">Use para cortesia, teste ou correção. Pagamentos pelo Mercado Pago liberam o plano sozinhos.</p>
      ${meuPapel === 'owner' ? `<div class="field"><label for="evGR">Papel na plataforma</label><div style="display:flex;gap:8px"><select id="evGR" style="flex:1">${['user', 'admin', 'owner'].map((p) => `<option value="${p}"${p === (u.papel || 'user') ? ' selected' : ''}>${PAPEL[p]}</option>`).join('')}</select><button class="btn btn-ghost btn-sm" id="evGRS" type="button">Salvar papel</button></div><p class="field-hint">Só o proprietário muda papéis. Fica registrado no log.</p></div>` : ''}
      <div class="field"><label>Acesso à conta</label><div><button class="btn btn-ghost btn-sm" id="evGPW" type="button">Enviar redefinição de senha</button></div><p class="field-hint">A pessoa recebe o e-mail oficial para criar uma senha nova. Ninguém do painel vê ou define senhas.</p></div>
      <div class="modal-rodape">
        <button class="btn btn-ghost btn-sm" id="evGX" type="button">Cancelar</button>
        <button class="btn ${u.bloqueado ? 'btn-ok' : 'btn-danger'} btn-sm" id="evGB" type="button">${u.bloqueado ? 'Desbloquear' : 'Bloquear conta'}</button>
        <button class="btn btn-primary btn-sm" id="evGS" type="button">Salvar plano</button>
      </div>`,
  });
  box.querySelector('#evGX').addEventListener('click', close);
  box.querySelector('#evGS').addEventListener('click', async () => {
    try {
      const dias = box.querySelector('#evGD').value ? Number(box.querySelector('#evGD').value) : null;
      await definirUsuarioEvolui(u.id, { plano: box.querySelector('#evGP').value, dias });
      showToast('Plano atualizado.', { tone: 'ok' }); close(); depois();
    } catch (err) { showToast(err.message, { tone: 'danger' }); }
  });
  const gr = box.querySelector('#evGRS');
  if (gr) gr.addEventListener('click', async () => {
    const papel = box.querySelector('#evGR').value;
    if (papel === (u.papel || 'user')) { showToast('Esse já é o papel atual.'); return; }
    if (!window.confirm(`Mudar ${u.email || 'esta pessoa'} para "${PAPEL[papel]}"?`)) return;
    try { await definirPapelEvolui(u.id, papel); showToast('Papel atualizado.', { tone: 'ok' }); close(); depois(); }
    catch (err) { showToast(err.message, { tone: 'danger' }); }
  });
  box.querySelector('#evGPW').addEventListener('click', async (e) => {
    const b = e.currentTarget; b.disabled = true;
    try {
      const r = await iniciarResetEvolui(u.id);
      showToast(r.enviado ? `E-mail de redefinição enviado para ${r.email}.` : 'Esta conta entra com Google, não tem senha na EvoluiSocial. Oriente a pessoa a usar "Entrar com Google" (a senha é gerenciada pelo Google).', { tone: r.enviado ? 'ok' : 'info' });
    } catch (err) { showToast(err.message, { tone: 'danger' }); }
    b.disabled = false;
  });
  box.querySelector('#evGB').addEventListener('click', async () => {
    if (!u.bloqueado && !window.confirm('Bloquear esta conta? A pessoa não conseguirá pesquisar até ser desbloqueada.')) return;
    try { await definirUsuarioEvolui(u.id, { bloqueado: !u.bloqueado }); showToast(u.bloqueado ? 'Conta desbloqueada.' : 'Conta bloqueada.', { tone: 'ok' }); close(); depois(); }
    catch (err) { showToast(err.message, { tone: 'danger' }); }
  });
}

// ------------------------------------------------------------------ segurança
async function abaSeguranca(corpo) {
  corpo.innerHTML = `<section class="card"><div class="card-head"><h3>Alertas do agente de segurança</h3><label class="ev-check"><input type="checkbox" id="evTodos"> Mostrar resolvidos</label></div>
    <p class="kpi-empty">O agente roda a cada hora. Ele procura: rajadas de pesquisa, várias contas usando o mesmo acesso à internet (o endereço é guardado só como código irreversível), quem força o limite do plano, tentativas de mudar o plano sem pagar e pagamentos com valor diferente do preço.</p>
    <div id="evAlertas"></div></section>`;
  const box = corpo.querySelector('#evAlertas');
  const carregar = async () => {
    box.innerHTML = ''; box.appendChild(LoadingState({ rows: 4 }));
    let al;
    try { al = await alertasEvolui(!corpo.querySelector('#evTodos').checked); } catch (err) { box.innerHTML = ''; box.appendChild(ErrorState({ description: err.message, onRetry: carregar })); return; }
    box.innerHTML = '';
    if (!al.length) { box.appendChild(EmptyState({ title: 'Nenhum alerta aberto', description: 'Tudo tranquilo. Quando o agente encontrar algo estranho, aparece aqui.' })); return; }
    box.innerHTML = `<div class="ev-alertas">${al.map((a) => `
      <div class="ev-alerta${a.resolvido ? ' resolvido' : ''}">
        <div class="ev-alerta-topo"><span class="badge ${GRAV[a.gravidade] || 'badge-info'}">${esc(a.gravidade)}</span><b>${esc(ALERTA[a.tipo] || a.tipo)}</b><span class="ev-muted">${dataHoraBR(a.criado_em)}</span></div>
        <div class="ev-muted">${a.email ? esc(`${a.nome || ''} · ${a.email}`) : 'Sem conta específica'}</div>
        <code>${esc(JSON.stringify(a.detalhe || {}))}</code>
        ${a.resolvido ? `<div class="ev-muted">Resolvido ${dataHoraBR(a.resolvido_em)}${a.nota ? ' · ' + esc(a.nota) : ''}</div>` : `<button class="btn btn-ghost btn-xs" data-resolver="${esc(a.id)}">Marcar como resolvido</button>`}
      </div>`).join('')}</div>`;
    box.querySelectorAll('[data-resolver]').forEach((b) => b.addEventListener('click', async () => {
      const nota = window.prompt('Nota (opcional): o que foi feito?') ?? null;
      try { await resolverAlertaEvolui(b.dataset.resolver, nota); showToast('Alerta resolvido.', { tone: 'ok' }); carregar(); } catch (err) { showToast(err.message, { tone: 'danger' }); }
    }));
  };
  corpo.querySelector('#evTodos').addEventListener('change', carregar);
  carregar();
}

// ------------------------------------------------------------------ solicitações de acesso
async function abaSolicitacoes(corpo) {
  corpo.innerHTML = `<section class="card"><div class="card-head"><h3>Solicitações de acesso</h3><label class="ev-check"><input type="checkbox" id="evSolTodas"> Mostrar já decididas</label></div>
    <p class="kpi-empty">Quem pede o acesso de Social Media aparece aqui. Ao aprovar, a pessoa recebe a permissão e passa a ser Social Media; ao recusar, ela pode pedir de novo.</p><div id="evSol"></div></section>`;
  const box = corpo.querySelector('#evSol');
  const carregar = async () => {
    box.innerHTML = ''; box.appendChild(LoadingState({ rows: 3 }));
    let lista;
    try { lista = await solicitacoesEvolui(corpo.querySelector('#evSolTodas').checked ? null : 'pendente'); } catch (err) { box.innerHTML = ''; box.appendChild(ErrorState({ description: err.message, onRetry: carregar })); return; }
    box.innerHTML = '';
    if (!lista.length) { box.appendChild(EmptyState({ title: 'Nenhuma solicitação pendente', description: 'Quando alguém pedir acesso de Social Media, o pedido aparece aqui.' })); return; }
    box.innerHTML = `<div class="ev-alertas">${lista.map((s) => `
      <div class="ev-alerta${s.status !== 'pendente' ? ' resolvido' : ''}">
        <div class="ev-alerta-topo"><span class="badge badge-info">${esc(s.status)}</span><b>${esc(s.recurso === 'social_media' ? 'Social Media' : s.recurso)}</b><span class="ev-muted">${dataHoraBR(s.criado_em)}</span></div>
        <div class="ev-muted">${esc(`${s.nome || 'Sem nome'} · ${s.email || ''}`)} · ${esc([s.ramo, s.ramo_detalhe, s.cidade && s.uf ? `${s.cidade}/${s.uf}` : ''].filter(Boolean).join(' · ') || 'ramo não informado')} · plano ${esc(s.plano || 'free')}</div>
        ${s.mensagem ? `<div>"${esc(s.mensagem)}"</div>` : ''}
        ${s.status === 'pendente' ? `<div class="ev-linha"><button class="btn btn-primary btn-xs" data-ok="${esc(s.id)}">Aprovar</button> <button class="btn btn-ghost btn-xs" data-no="${esc(s.id)}">Recusar</button></div>` : `<div class="ev-muted">Decidida ${dataHoraBR(s.decidido_em)}${s.resposta ? ' · ' + esc(s.resposta) : ''}</div>`}
      </div>`).join('')}</div>`;
    const decidir = (id, aprovar) => async () => {
      const resp = aprovar ? null : (window.prompt('Motivo para a pessoa (opcional):') ?? null);
      try { await decidirSolicitacaoEvolui(id, aprovar, resp); showToast(aprovar ? 'Acesso aprovado.' : 'Pedido recusado.', { tone: 'ok' }); carregar(); } catch (err) { showToast(err.message, { tone: 'danger' }); }
    };
    box.querySelectorAll('[data-ok]').forEach((b) => b.addEventListener('click', decidir(b.dataset.ok, true)));
    box.querySelectorAll('[data-no]').forEach((b) => b.addEventListener('click', decidir(b.dataset.no, false)));
  };
  corpo.querySelector('#evSolTodas').addEventListener('change', carregar);
  carregar();
}

// ------------------------------------------------------------------ plataforma
async function abaPlataforma(corpo) {
  corpo.innerHTML = '';
  corpo.appendChild(LoadingState({ variant: 'cards', rows: 3 }));
  let p;
  try { p = await plataformaEvolui(); } catch (err) { corpo.innerHTML = ''; corpo.appendChild(ErrorState({ description: err.message, onRetry: () => abaPlataforma(corpo) })); return; }
  meuPapel = p.meu_papel || meuPapel;
  const c = p.conteudos || {};
  const fontes = p.fontes || [];
  corpo.innerHTML = `
    <div class="kpi-grid ev-kpis">
      ${kpi('Seu papel', esc(PAPEL[p.meu_papel] || p.meu_papel || '—'), p.sou_owner ? 'Pode mudar papéis' : 'Papéis só o proprietário muda')}
      ${kpi('Biblioteca', num(c.biblioteca_ativos), 'Ideias, ganchos, CTAs e guias ativos na pesquisa')}
      ${kpi('Conteúdos dos usuários', num(c.conteudos_usuarios), `${num(c.publicacoes)} publicação(ões) · ${num(c.objetivos_ativos)} objetivo(s) ativo(s)`)}
      ${kpi('Fontes com falha', num(fontes.filter((f) => !f.ok).length), `${num(fontes.length)} fonte(s) monitorada(s)`)}
    </div>
    <div class="ev-grade">
      <section class="card"><div class="card-head"><h3>Fontes de dados</h3><span class="field-hint-inline">Atualiza a cada uso</span></div>
        ${fontes.length ? `<div class="table-wrap"><table class="app-table"><thead><tr><th>Fonte</th><th>Status</th><th>Último sucesso</th><th>Última falha</th></tr></thead><tbody>
          ${fontes.map((f) => `<tr><td>${esc(FONTE[f.fonte] || f.fonte)}</td><td><span class="badge ${f.ok ? 'badge-ok' : 'badge-warning'}">${f.ok ? 'Funcionando' : 'Com falha'}</span>${!f.ok && f.ultimo_erro ? `<br><span class="ev-muted">${esc(f.ultimo_erro)}</span>` : ''}</td><td>${dataHoraBR(f.ultima_ok)}</td><td>${dataHoraBR(f.ultima_falha)}</td></tr>`).join('')}
        </tbody></table></div>` : '<p class="kpi-empty">Nenhuma fonte usada ainda.</p>'}
        <p class="kpi-empty">Falha passageira é normal (GDELT e OpenStreetMap limitam consultas). O app segue funcionando com as outras fontes.</p>
      </section>
      <section class="card"><div class="card-head"><h3>Papéis</h3><span class="field-hint-inline">Usuário · Administrador · Proprietário</span></div>
        ${(p.papeis || []).length ? `<div class="table-wrap"><table class="app-table"><thead><tr><th>Conta</th><th>Papel</th><th>Desde</th></tr></thead><tbody>
          ${(p.papeis || []).map((x) => `<tr><td>${esc(x.email || x.user_id)}</td><td>${esc(PAPEL[x.papel] || x.papel)}</td><td>${dataBR(x.desde)}</td></tr>`).join('')}
        </tbody></table></div>` : '<p class="kpi-empty">Nenhum papel especial definido.</p>'}
        <p class="kpi-empty">Quem não aparece aqui é usuário comum. ${p.sou_owner ? 'Para mudar, abra a pessoa em Usuários › Gerenciar.' : ''} Funcionários do painel com perfil de administrador também enxergam esta área.</p>
      </section>
    </div>
    <div class="ev-grade">
      <section class="card"><div class="card-head"><h3>Rotinas automáticas</h3><span class="field-hint-inline">pg_cron no banco</span></div>
        ${(p.cron || []).map((j) => `<div class="ev-barra"><span class="ev-barra-rot">${esc(j.nome)}</span><code>${esc(j.agenda)}</code><span class="badge ${j.ativo ? 'badge-ok' : 'badge-demo'}">${j.ativo ? 'Ativa' : 'Parada'}</span></div>`).join('') || '<p class="kpi-empty">Nenhuma rotina.</p>'}
        <h4 class="ev-sub">Agentes</h4>
        ${(p.agentes || []).map((a) => `<div class="ev-barra"><span class="ev-barra-rot">${a.nome === 'seguranca' ? 'Segurança' : a.nome === 'perfil' ? 'Perfil' : esc(a.nome)}</span><span class="ev-muted">${a.ultima_execucao ? 'Rodou ' + dataHoraBR(a.ultima_execucao) : 'Ainda não rodou'}</span></div>`).join('')}
      </section>
      <section class="card"><div class="card-head"><h3>Conteúdos e conexões</h3><span class="field-hint-inline">Estrutura pronta para a próxima etapa</span></div>
        ${barras(Object.entries(c.biblioteca_por_tipo || {}).map(([k, v]) => ({ k: `Biblioteca · ${k}`, v })))}
        ${Object.keys(c.por_origem || {}).length ? barras(Object.entries(c.por_origem).map(([k, v]) => ({ k: k === 'link' ? 'Conteúdos por link' : 'Conteúdos por upload', v }))) : '<p class="kpi-empty">Nenhum usuário cadastrou conteúdo ainda (Adicionar conteúdo › Link ou Upload chega na próxima etapa).</p>'}
        ${Object.keys(p.conexoes || {}).length ? barras(Object.entries(p.conexoes).map(([k, v]) => ({ k, v }))) : '<p class="kpi-empty">Nenhuma rede conectada por API oficial ainda.</p>'}
      </section>
    </div>`;
}


// ------------------------------------------------------------------ integrações (chaves de API)
// As chaves ficam criptografadas no Supabase Vault. Esta tela nunca recebe o valor de volta: só "configurada" e os 4 últimos caracteres.
const CATEGORIA_INT = { ia: 'Inteligência artificial', redes: 'Redes sociais', busca: 'Busca', pagamento: 'Pagamentos', outra: 'Outras' };
async function abaIntegracoes(corpo) {
  corpo.innerHTML = '';
  corpo.appendChild(LoadingState({ variant: 'cards', rows: 3 }));
  let lista;
  try { lista = await integracoesEvolui(); } catch (err) {
    corpo.innerHTML = '';
    if (/propriet/i.test(err.message)) { corpo.innerHTML = '<section class="card"><div class="card-head"><h3>Integrações</h3></div><p class="kpi-empty">Só o proprietário da plataforma gerencia as chaves de API.</p></section>'; return; }
    corpo.appendChild(ErrorState({ description: err.message, onRetry: () => abaIntegracoes(corpo) })); return;
  }
  const ok = lista.filter((i) => i.configurada).length;
  const grupos = {};
  lista.forEach((i) => { (grupos[i.personalizada ? 'outra' : i.categoria] = grupos[i.personalizada ? 'outra' : i.categoria] || []).push(i); });
  const cartao = (i) => `
    <div class="ev-int" data-chave="${esc(i.chave)}">
      <div class="ev-int-topo">
        <div><b>${esc(i.rotulo)}</b> <span class="badge ${i.configurada ? 'badge-ok' : 'badge-demo'}">${i.configurada ? 'Configurada' + (i.final4 ? ' · …' + esc(i.final4) : '') : 'Não configurada'}</span>${i.teste_status ? ` <span class="badge ${i.teste_status === 'ok' ? 'badge-ok' : 'badge-warning'}" title="${esc(i.teste_msg || '')}">Teste: ${i.teste_status === 'ok' ? 'passou' : 'falhou'}</span>` : ''}</div>
        <span class="ev-muted">${i.atualizado_em ? 'Atualizada em ' + dataHoraBR(i.atualizado_em) + (i.atualizado_por ? ' por ' + esc(i.atualizado_por) : '') : ''}</span>
      </div>
      ${i.descricao ? `<p class="field-hint">${esc(i.descricao)}${i.ajuda_url ? ` <a href="${esc(i.ajuda_url)}" target="_blank" rel="noopener noreferrer">Onde pegar ↗</a>` : ''}</p>` : ''}
      <div class="ev-int-linha">
        <input type="password" class="ev-int-valor" autocomplete="new-password" spellcheck="false" placeholder="${i.configurada ? 'Cole uma nova chave para substituir' : 'Cole a chave aqui'}" aria-label="Chave de ${esc(i.rotulo)}">
        <button class="btn btn-primary btn-sm" data-int="salvar" type="button">${i.configurada ? 'Substituir' : 'Salvar'}</button>
        ${i.configurada && i.testavel ? '<button class="btn btn-ghost btn-sm" data-int="testar" type="button">Testar</button>' : ''}
        ${i.configurada ? '<button class="btn btn-ghost btn-sm" data-int="remover" type="button">Remover</button>' : ''}
      </div>
      ${i.teste_msg && i.teste_status ? `<p class="field-hint">${esc(i.teste_msg)}</p>` : ''}
    </div>`;
  corpo.innerHTML = `
    <div class="kpi-grid ev-kpis">
      ${kpi('Chaves configuradas', `${ok} de ${lista.length}`, 'Todas são opcionais: sem chave, o app segue funcionando')}
      ${kpi('Onde ficam guardadas', 'Vault', 'Criptografadas no Supabase. Nunca aparecem de volta nesta tela')}
    </div>
    <section class="card"><div class="card-head"><h3>Chaves de API</h3><span class="field-hint-inline">Só o proprietário vê e altera</span></div>
      <p class="field-hint">Cole a chave aqui, e só aqui. Nunca envie chaves em conversa, e-mail ou arquivo. Depois de salvar, ela não pode ser lida de novo; para trocar, é só colar outra. Cada troca fica registrada no log, sem o valor.</p>
      ${Object.entries(grupos).map(([g, itens]) => `<h4 class="ev-sub">${esc(CATEGORIA_INT[g] || g)}</h4>${itens.map(cartao).join('')}`).join('')}
    </section>
    <section class="card"><div class="card-head"><h3>Adicionar outra chave</h3><span class="field-hint-inline">Para integrações novas</span></div>
      <div class="ev-int-novo">
        <div class="field"><label for="evNomeInt">Nome</label><input id="evNomeInt" maxlength="80" placeholder="Ex.: Typesense"></div>
        <div class="field"><label for="evIdInt">Identificador</label><input id="evIdInt" maxlength="41" placeholder="ex.: typesense_key" autocapitalize="none"></div>
        <div class="field"><label for="evValInt">Chave</label><input id="evValInt" type="password" autocomplete="new-password" spellcheck="false" placeholder="Cole a chave aqui"></div>
        <button class="btn btn-primary btn-sm" id="evAddInt" type="button">Adicionar</button>
      </div>
      <p class="field-hint">O identificador é como o servidor encontra a chave (letras minúsculas, números e _). Chaves novas só passam a ser usadas quando o código correspondente for criado.</p>
    </section>`;
  const depois = () => abaIntegracoes(corpo);
  corpo.querySelectorAll('.ev-int').forEach((box) => {
    const chave = box.dataset.chave, campo = box.querySelector('.ev-int-valor');
    box.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-int]'); if (!b) return;
      const acao = b.dataset.int; b.disabled = true;
      try {
        if (acao === 'salvar') {
          if (!campo.value.trim()) { showToast('Cole a chave primeiro.', { tone: 'danger' }); b.disabled = false; return; }
          await salvarIntegracaoEvolui(chave, campo.value); campo.value = ''; showToast('Chave salva com segurança.', { tone: 'ok' }); depois();
        } else if (acao === 'testar') {
          b.textContent = 'Testando…';
          const r = await testarIntegracaoEvolui(chave); showToast(r.msg, { tone: r.ok ? 'ok' : 'danger' }); depois();
        } else if (acao === 'remover') {
          if (!window.confirm('Remover esta chave? Quem depende dela volta ao modo sem chave.')) { b.disabled = false; return; }
          await removerIntegracaoEvolui(chave); showToast('Chave removida.', { tone: 'ok' }); depois();
        }
      } catch (err) { showToast(err.message, { tone: 'danger' }); b.disabled = false; if (acao === 'testar') b.textContent = 'Testar'; }
    });
  });
  corpo.querySelector('#evAddInt').addEventListener('click', async (e) => {
    const b = e.currentTarget, nome = corpo.querySelector('#evNomeInt').value, id = corpo.querySelector('#evIdInt').value, val = corpo.querySelector('#evValInt');
    if (!nome.trim() || !id.trim() || !val.value.trim()) { showToast('Preencha nome, identificador e chave.', { tone: 'danger' }); return; }
    b.disabled = true;
    try { await salvarIntegracaoEvolui(id, val.value, nome); val.value = ''; showToast('Chave adicionada.', { tone: 'ok' }); depois(); }
    catch (err) { showToast(err.message, { tone: 'danger' }); b.disabled = false; }
  });
}

// ------------------------------------------------------------------ financeiro
async function abaFinanceiro(corpo) {
  corpo.innerHTML = ''; corpo.appendChild(LoadingState({ variant: 'cards', rows: 3 }));
  let f;
  try { f = await financeiroEvolui(12); } catch (err) { corpo.innerHTML = ''; corpo.appendChild(ErrorState({ description: err.message, onRetry: () => abaFinanceiro(corpo) })); return; }
  const meses = f.meses || [], atual = meses[meses.length - 1] || {}, ant = meses[meses.length - 2] || {};
  const cfg = f.config || {}, precos = cfg.precos || {}, rec = cfg.recebimento || {};
  const ano = meses.reduce((s, m) => s + (m.bruto || 0), 0);
  corpo.innerHTML = `
    <div class="kpi-grid ev-kpis">
      ${kpi('Arrecadado no mês', brl(atual.bruto), `${num(atual.pagamentos)} pagamento(s) aprovado(s)`, true)}
      ${kpi('Taxas do Mercado Pago', brl(atual.taxas), `Líquido: ${brl((atual.bruto || 0) - (atual.taxas || 0))}`)}
      ${kpi('Mês anterior', brl(ant.bruto), `${num(ant.pagamentos)} pagamento(s)`)}
      ${kpi('Últimos 12 meses', brl(ano), 'bruto aprovado')}
    </div>
    <section class="card"><div class="card-head"><h3>Arrecadação por mês</h3><span class="field-hint-inline">Só pagamentos aprovados</span></div>
      ${meses.some((m) => m.bruto) ? chartAreaHtml({ categorias: meses.map((m) => m.mes.slice(5, 7) + '/' + m.mes.slice(2, 4)), series: [{ nome: 'Bruto', cor: 'var(--star)', valores: meses.map((m) => (m.bruto || 0) / 100) }, { nome: 'Taxas', cor: 'var(--danger)', valores: meses.map((m) => (m.taxas || 0) / 100) }] })
        : '<p class="kpi-empty">Nenhum pagamento aprovado ainda. Os valores aparecem aqui sozinhos quando o Mercado Pago confirmar.</p>'}
    </section>
    <div class="ev-grade">
      <section class="card"><div class="card-head"><h3>Este mês por plano</h3></div>${Object.keys(f.por_plano_mes || {}).length ? barras(Object.entries(f.por_plano_mes).map(([k, v]) => ({ k: k.replace('_', ' '), v })), { formato: brl }) : '<p class="kpi-empty">Sem vendas neste mês.</p>'}</section>
      <section class="card"><div class="card-head"><h3>Este mês por forma de pagamento</h3></div>${Object.keys(f.por_metodo_mes || {}).length ? barras(Object.entries(f.por_metodo_mes).map(([k, v]) => ({ k: { pix: 'Pix', cartao: 'Cartão', boleto: 'Boleto' }[k] || k, v })), { formato: brl }) : '<p class="kpi-empty">Sem vendas neste mês.</p>'}</section>
    </div>
    <section class="card"><div class="card-head"><h3>Últimos pagamentos</h3></div>
      ${(f.ultimos || []).length ? `<div class="table-wrap"><table class="app-table"><thead><tr><th>Quando</th><th>Quem</th><th>Plano</th><th>Valor</th><th>Taxa</th><th>Forma</th><th>Status</th></tr></thead><tbody>
        ${f.ultimos.map((p) => `<tr><td>${dataHoraBR(p.pago_em || p.criado_em)}</td><td>${esc(p.nome || '')}<br><span class="ev-muted">${esc(p.email || '')}</span></td><td>${PLANO[p.plano]} ${esc(p.ciclo)}</td><td>${brl(p.valor_centavos)}</td><td>${brl(p.taxa_centavos)}</td><td>${esc(p.metodo || '—')}</td><td><span class="badge ${STATUS_PAG[p.status] || 'badge-demo'}">${esc(p.status)}</span></td></tr>`).join('')}
      </tbody></table></div>` : '<p class="kpi-empty">Nenhum pagamento registrado.</p>'}
    </section>
    <div class="ev-grade">
      <section class="card"><div class="card-head"><h3>Preços</h3><span class="badge ${precos.status === 'proposta' ? 'badge-warning' : 'badge-ok'}">${precos.status === 'proposta' ? 'Em proposta' : 'Aprovados'}</span></div>
        <form id="evPrecos" class="ev-form">
          ${['pro', 'master'].map((p) => ['mensal', 'anual'].map((c) => `<div class="field"><label>${PLANO[p]} ${c} (R$)</label><input name="${p}_${c}" type="number" min="1" step="0.01" value="${((precos[p] || {})[c] || 0) / 100}"></div>`).join('')).join('')}
          <label class="ev-check"><input type="checkbox" name="aprovado"${precos.status === 'proposta' ? '' : ' checked'}> Preços aprovados</label>
          <button class="btn btn-primary btn-sm" type="submit">Salvar preços</button>
        </form>
        <p class="kpi-empty">O valor cobrado é sempre o daqui (o navegador da pessoa nunca define o preço). Lembre de atualizar o texto da página de planos se mudar.</p>
      </section>
      <section class="card"><div class="card-head"><h3>Conta de recebimento</h3><span class="badge ${cfg.pagamento_ativo === true ? 'badge-ok' : 'badge-demo'}">${cfg.pagamento_ativo === true ? 'Pagamento ativo' : 'Pagamento desligado'}</span></div>
        <form id="evRec" class="ev-form">
          <div class="field"><label>Onde cai o dinheiro</label><input name="provedor" value="${esc(rec.provedor || 'Mercado Pago')}" maxlength="60"></div>
          <div class="field"><label>Conta (e-mail ou nome da conta no Mercado Pago)</label><input name="conta" value="${esc(rec.conta || '')}" maxlength="120"></div>
          <div class="field"><label>Titular</label><input name="titular" value="${esc(rec.titular || '')}" maxlength="120"></div>
          <div class="field"><label>CPF/CNPJ (só os 4 últimos dígitos)</label><input name="documento" value="${esc(rec.documento || '')}" maxlength="8" placeholder="ex.: ••••-12"></div>
          <label class="ev-check"><input type="checkbox" name="ativo"${cfg.pagamento_ativo === true ? ' checked' : ''}> Pagamento online ligado</label>
          <button class="btn btn-primary btn-sm" type="submit">Salvar</button>
        </form>
        <details class="ev-como"><summary>Como ligar o Mercado Pago (uma vez)</summary><ol>
          <li>No Mercado Pago da conta que vai receber: Seu negócio › Configurações › Credenciais. Copie o <b>Access Token de produção</b>.</li>
          <li>No Supabase: Edge Functions › Secrets › adicione <code>MP_ACCESS_TOKEN</code> com esse token.</li>
          <li>No Mercado Pago: Suas integrações › Webhooks › URL <code>https://aligftypgtzlymmditeo.supabase.co/functions/v1/evolui-pagamentos?origem=mp</code>, evento <b>Pagamentos</b>. Copie a assinatura secreta e salve no Supabase como <code>MP_WEBHOOK_SECRET</code>.</li>
          <li>Marque "Pagamento online ligado" aqui e salve. Faça um pagamento de teste.</li>
        </ol><p>Dados de cartão nunca passam pela Felipe Branding: ficam no Mercado Pago. Aqui guardamos só status, valor, taxa e forma de pagamento.</p></details>
      </section>
    </div>`;
  corpo.querySelector('#evPrecos').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const c = (k) => Math.round(Number(String(fd.get(k)).replace(',', '.')) * 100);
    const valor = { pro: { mensal: c('pro_mensal'), anual: c('pro_anual') }, master: { mensal: c('master_mensal'), anual: c('master_anual') }, status: fd.get('aprovado') ? 'aprovado' : 'proposta' };
    if ([valor.pro.mensal, valor.pro.anual, valor.master.mensal, valor.master.anual].some((v) => !Number.isFinite(v) || v < 100)) { showToast('Preço inválido (mínimo R$ 1,00).', { tone: 'danger' }); return; }
    try { await configEvolui('precos', valor); showToast('Preços salvos.', { tone: 'ok' }); abaFinanceiro(corpo); } catch (err) { showToast(err.message, { tone: 'danger' }); }
  });
  corpo.querySelector('#evRec').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const doc = String(fd.get('documento') || '').replace(/[^0-9•.\-/*]/g, '').slice(-8);
    try {
      await configEvolui('recebimento', { provedor: String(fd.get('provedor') || '').slice(0, 60), conta: String(fd.get('conta') || '').slice(0, 120), titular: String(fd.get('titular') || '').slice(0, 120), documento: doc, observacao: rec.observacao || '' });
      await configEvolui('pagamento_ativo', Boolean(fd.get('ativo')));
      showToast('Configuração salva.', { tone: 'ok' }); abaFinanceiro(corpo);
    } catch (err) { showToast(err.message, { tone: 'danger' }); }
  });
}

/** Cartão compacto para o Financeiro da agência: só o que a EvoluiSocial arrecadou no mês. */
export function cartaoEvoluiFinanceiro() {
  const card = document.createElement('section');
  card.className = 'card ev-fin-card';
  card.innerHTML = '<div class="card-head"><h3>EvoluiSocial · arrecadado no mês</h3><a class="btn btn-ghost btn-xs" href="#/evoluisocial?aba=financeiro">Ver detalhes</a></div><div class="ev-fin-corpo"><p class="kpi-empty">Carregando…</p></div>';
  financeiroEvolui(2).then((f) => {
    const m = f.meses || [], a = m[m.length - 1] || {}, b = m[m.length - 2] || {};
    card.querySelector('.ev-fin-corpo').innerHTML = `<div class="ev-fin-linha"><div><div class="kpi-label">Bruto</div><b>${brl(a.bruto)}</b></div><div><div class="kpi-label">Taxas</div><b>${brl(a.taxas)}</b></div><div><div class="kpi-label">Líquido</div><b>${brl((a.bruto || 0) - (a.taxas || 0))}</b></div><div><div class="kpi-label">Mês anterior</div><b>${brl(b.bruto)}</b></div><div><div class="kpi-label">Pagamentos</div><b>${num(a.pagamentos)}</b></div></div>
      <p class="kpi-empty">Assinaturas da EvoluiSocial pagas pelo Mercado Pago. Separado do faturamento de clientes da agência.</p>`;
  }).catch((err) => { card.querySelector('.ev-fin-corpo').innerHTML = `<p class="kpi-empty">Não foi possível carregar: ${esc(err.message)}</p>`; });
  return card;
}
