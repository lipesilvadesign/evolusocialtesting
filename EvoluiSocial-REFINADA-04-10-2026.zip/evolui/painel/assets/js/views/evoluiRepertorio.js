/**
 * Aba "Repertório" do EvoluiSocial (02/10/2026) — Central de Repertório. Admin-only.
 * Regra de produto: "Coloque o conhecimento. O Evolui organiza."
 * Procedência sempre visível: FONTE (literal) · INTERPRETAÇÃO DO SISTEMA · INSIGHT DERIVADO (hipótese do Evolui).
 */
import { LoadingState } from '../components/LoadingState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { esc } from '../utils/html.js';
import { abrirModal } from '../components/Modal.js';
import {
  adicionarRepertorio, excluirRepertorio, ajustarRepertorio, statsRepertorio, verRepertorio,
  resolverRepertorio, listarRepertorio, insightsRepertorio, conflitosRepertorio,
} from '../services/evoluiAdminClient.js';

const num = (n) => Number(n || 0).toLocaleString('pt-BR');
const dataBR = (d) => (d ? new Date(d).toLocaleDateString('pt-BR') : '—');
const kpi = (l, v, s) => `<div class="card kpi-card"><div class="kpi-label">${esc(l)}</div><div class="kpi-value">${v}</div>${s ? `<div class="kpi-empty">${s}</div>` : ''}</div>`;
const TIPO = { coocorre: 'aparece junto com', aplica_em: 'se aplica em', serve_para: 'serve para', util_para: 'é útil para', em_formato: 'funciona no formato' };
const TIPO_CONCEITO = { conceito: 'Conceito', assunto: 'Assunto', aplicacao: 'Aplicação', formato: 'Formato', segmento: 'Segmento', objetivo: 'Objetivo', termo: 'Termo', expressao: 'Expressão' };
const lista = (a) => (a && a.length ? a.map((x) => `<li>${esc(typeof x === 'string' ? x : x.texto || x.exemplo || '')}</li>`).join('') : '');
const chips = (a) => (a && a.length ? a.map((x) => `<span class="badge badge-demo">${esc(x)}</span>`).join(' ') : '<span class="ev-muted">—</span>');
const sel = (cond, html) => (cond ? html : '');

export async function abaRepertorio(corpo) {
  corpo.innerHTML = '';
  corpo.appendChild(LoadingState({ variant: 'cards', rows: 3 }));
  let s;
  try { s = await statsRepertorio(); } catch (err) {
    corpo.innerHTML = ''; corpo.appendChild(ErrorState({ description: err.message, onRetry: () => abaRepertorio(corpo) })); return;
  }
  corpo.innerHTML = `
    <section class="card"><div class="card-head"><h3>Central de Repertório</h3><span class="field-hint-inline">Coloque o conhecimento. O Evolui organiza.</span></div>
      <form id="repForm" class="ev-form">
        <div class="field"><label for="repTexto" class="sr-only">Conteúdo</label>
          <textarea id="repTexto" rows="9" maxlength="60000" placeholder="Adicione um artigo, texto ou conhecimento ao Evolui..." required></textarea></div>
        <details class="ev-como"><summary>Detalhes opcionais (título, fonte, assunto, tags, observação)</summary>
          <div class="field"><label for="repTitulo">Título / identificação</label><input id="repTitulo" maxlength="200"></div>
          <div class="field"><label for="repFonte">Fonte / origem</label><input id="repFonte" maxlength="300" placeholder="Link, livro, autor, estudo…"></div>
          <div class="field"><label for="repAutor">Autor</label><input id="repAutor" maxlength="150"></div>
          <div class="field"><label for="repAssunto">Assunto</label><input id="repAssunto" maxlength="120"></div>
          <div class="field"><label for="repTags">Tags (separe por vírgula)</label><input id="repTags" maxlength="400"></div>
          <div class="field"><label for="repObs">Observação do administrador</label><textarea id="repObs" rows="2" maxlength="1000"></textarea></div>
        </details>
        <div class="ev-int-linha"><button class="btn btn-primary" id="repEnviar" type="submit">Adicionar ao repertório</button><span id="repEstado" class="ev-muted" role="status" aria-live="polite"></span></div>
      </form>
      <p class="field-hint">O Evolui lê o texto, extrai conceitos, linguagem, aplicações e relações, liga ao que já conhece e guarda a origem. O texto original fica só aqui no painel: quem usa o app nunca vê o artigo, só ideias novas construídas a partir dele.</p>
    </section>
    <div class="kpi-grid ev-kpis">
      ${kpi('Conhecimentos', num(s.conhecimentos), `${num(s.novos7d)} novo(s) em 7 dias`)}
      ${kpi('Conceitos', num(s.conceitos))}
      ${kpi('Relações', num(s.relacoes))}
      ${kpi('Categorias', num(s.categorias))}
      ${kpi('Sem utilização', num(s.sem_uso), 'ainda não usados em pesquisas')}
      ${kpi('Insights derivados', num(s.insights), 'hipóteses do Evolui')}
      ${kpi('Conflitos abertos', num(s.conflitos))}
    </div>
    ${(s.mais_usados || []).length ? `<section class="card"><div class="card-head"><h3>Mais utilizados</h3></div><ul class="ev-lista">${s.mais_usados.map((m) => `<li>${esc(m.titulo)} · <b>${num(m.usos)}</b> uso(s)</li>`).join('')}</ul></section>` : ''}
    <section class="card"><div class="card-head"><h3>Conhecimentos</h3><input id="repBusca" type="search" class="ev-select" placeholder="Pesquisar por título, assunto, fonte ou tag" aria-label="Pesquisar no repertório"></div>
      <div id="repLista"></div></section>
    <div id="repExtras"></div>`;

  const estado = corpo.querySelector('#repEstado'), btn = corpo.querySelector('#repEnviar');
  corpo.querySelector('#repForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = (id) => corpo.querySelector(id).value;
    btn.disabled = true; estado.textContent = 'Analisando conteúdo...';
    try {
      const r = await adicionarRepertorio({
        conteudo: v('#repTexto'), titulo: v('#repTitulo'), fonte: v('#repFonte'), autor: v('#repAutor'), assunto: v('#repAssunto'),
        tags: v('#repTags').split(',').map((t) => t.trim()).filter(Boolean), observacao: v('#repObs'),
      });
      const x = r.resumo || {};
      estado.textContent = 'Conhecimento incorporado ao repertório.';
      showToast(`Incorporado: ${x.conceitos || 0} conceitos, ${x.relacoes || 0} relações${x.insights ? `, ${x.insights} insight(s) derivado(s)` : ''}${x.conflitos ? `, ${x.conflitos} conflito(s) registrado(s)` : ''}.`, { tone: 'ok' });
      setTimeout(() => abaRepertorio(corpo), 900);
    } catch (err) { estado.textContent = ''; showToast(err.message, { tone: 'danger' }); btn.disabled = false; }
  });

  const caixa = corpo.querySelector('#repLista');
  const carregar = async () => {
    caixa.innerHTML = '<p class="kpi-empty">Carregando…</p>';
    try {
      const itens = await listarRepertorio(corpo.querySelector('#repBusca').value);
      caixa.innerHTML = itens.length ? `<div class="table-wrap"><table class="app-table"><thead><tr><th>Conhecimento</th><th>Assunto</th><th>Tags</th><th>Usos</th><th>Em</th><th></th></tr></thead><tbody>
        ${itens.map((k) => `<tr><td><b>${esc(k.titulo)}</b>${k.status === 'arquivado' ? ' <span class="badge badge-warning">arquivado</span>' : ''}<br><span class="ev-muted">${esc(k.fonte || 'sem fonte informada')}</span></td>
        <td>${esc(k.assunto || '—')}</td><td>${(k.tags || []).map((t) => `<span class="badge badge-demo">${esc(t)}</span>`).join(' ') || '—'}</td>
        <td>${num(k.usos)}</td><td>${dataBR(k.criado_em)}</td>
        <td><button class="btn btn-ghost btn-xs" data-ver="${esc(k.id)}" type="button">Abrir</button></td></tr>`).join('')}
      </tbody></table></div>` : '<p class="kpi-empty">Nada por aqui ainda. Cole o primeiro texto acima.</p>';
    } catch (err) { caixa.innerHTML = ''; caixa.appendChild(ErrorState({ description: err.message, onRetry: carregar })); }
  };
  let t; corpo.querySelector('#repBusca').addEventListener('input', () => { clearTimeout(t); t = setTimeout(carregar, 350); });
  caixa.addEventListener('click', (e) => { const b = e.target.closest('[data-ver]'); if (b) abrirConhecimento(b.dataset.ver, () => abaRepertorio(corpo)); });
  carregar();

  // insights derivados e conflitos
  const extras = corpo.querySelector('#repExtras');
  try {
    const [ins, conf] = await Promise.all([insightsRepertorio(), conflitosRepertorio()]);
    extras.innerHTML = `
      <section class="card"><div class="card-head"><h3>Insights derivados</h3><span class="badge badge-info">Construídos pelo Evolui</span></div>
        <p class="field-hint">Combinações feitas pelo sistema a partir de conhecimentos diferentes. Não estão em nenhuma fonte: trate como hipótese e teste.</p>
        ${ins.length ? ins.map((i) => `<div class="ev-int"><div class="ev-int-topo"><b>${esc(i.titulo)}</b><span class="badge ${i.status === 'ativo' ? 'badge-ok' : 'badge-demo'}">${esc(i.status)}</span></div><p>${esc(i.texto)}</p>
          <button class="btn btn-ghost btn-xs" data-ins="${esc(i.id)}" data-st="${i.status === 'ativo' ? 'descartado' : 'ativo'}" type="button">${i.status === 'ativo' ? 'Descartar' : 'Reativar'}</button></div>`).join('') : '<p class="kpi-empty">Os insights aparecem quando o repertório tiver conhecimentos que se combinam.</p>'}
      </section>
      ${conf.length ? `<section class="card"><div class="card-head"><h3>Conflitos entre fontes</h3></div><p class="field-hint">Nada é apagado: as duas fontes continuam guardadas. Marque como resolvido quando você decidir.</p>
        ${conf.map((c) => `<div class="ev-int"><p>${esc(c.descricao)}</p><button class="btn btn-ghost btn-xs" data-conf="${esc(c.id)}" type="button">Marcar como resolvido</button></div>`).join('')}</section>` : ''}`;
    extras.addEventListener('click', async (e) => {
      const i = e.target.closest('[data-ins]'), c = e.target.closest('[data-conf]');
      try {
        if (i) { await resolverRepertorio('insight', i.dataset.ins, i.dataset.st); abaRepertorio(corpo); }
        if (c) { await resolverRepertorio('conflito', c.dataset.conf, 'resolvido'); abaRepertorio(corpo); }
      } catch (err) { showToast(err.message, { tone: 'danger' }); }
    });
  } catch { extras.innerHTML = ''; }
}

async function abrirConhecimento(id, depois) {
  let d;
  try { d = await verRepertorio(id); } catch (err) { showToast(err.message, { tone: 'danger' }); return; }
  if (!d) { showToast('Conhecimento não encontrado.', { tone: 'danger' }); return; }
  const k = d.conhecimento || {}, a = k.analise || {};
  const html = `
    <div class="ev-rep-ver">
      <p class="field-hint"><span class="badge badge-ok">Fonte original</span> ${esc(k.fonte || 'não informada')}${k.autor ? ' · ' + esc(k.autor) : ''} · inserido em ${dataBR(k.criado_em)} · ${num(k.usos)} uso(s)</p>
      <form id="repEd" class="ev-form">
        <div class="field"><label>Título</label><input name="titulo" value="${esc(k.titulo)}" maxlength="200"></div>
        <div class="field"><label>Assunto</label><input name="assunto" value="${esc(k.assunto || '')}" maxlength="120"></div>
        <div class="field"><label>Fonte</label><input name="fonte" value="${esc(k.fonte || '')}" maxlength="300"></div>
        <div class="field"><label>Tags (vírgula)</label><input name="tags" value="${esc((k.tags || []).join(', '))}"></div>
        <div class="field"><label>Categorias (corrigir classificação, vírgula)</label><input name="categorias" value="${esc((d.categorias || []).map((c) => c.rotulo).join(', '))}" placeholder="Ex.: Hooks, Redes sociais"></div>
        <div class="field"><label>Observação do administrador</label><textarea name="observacao" rows="2" maxlength="1000">${esc(k.observacao || '')}</textarea></div>
        <label class="ev-check"><input type="checkbox" name="arquivado"${k.status === 'arquivado' ? ' checked' : ''}> Arquivado (deixa de ser usado nas pesquisas)</label>
        <div class="ev-int-linha"><button class="btn btn-primary btn-sm" type="submit">Salvar</button><button class="btn btn-ghost btn-sm" id="repDel" type="button">Excluir</button></div>
      </form>
      <h4 class="ev-sub">Interpretação do sistema <span class="badge badge-info">não é a fonte</span></h4>
      <p>Assunto principal: <b>${esc(a.assunto_principal || '—')}</b></p>
      <p>Subassuntos: ${chips(a.subassuntos)}</p>
      <p>Aplicações: ${chips(a.aplicacoes)}</p>
      <p>Segmentos: ${chips(a.contexto?.segmentos)} · Objetivos: ${chips(a.contexto?.objetivos)}</p>
      <p>Vocabulário: ${chips(a.linguagem?.termos)} ${chips(a.linguagem?.expressoes)}</p>
      ${sel((a.linguagem?.padroes_titulo || []).length, `<p>Padrões de título: ${(a.linguagem.padroes_titulo).map((p) => `<span class="badge badge-demo" title="${esc(p.exemplo)}">${esc(p.estrutura)}</span>`).join(' ')}</p>`)}
      ${sel((a.linguagem?.aberturas || []).length, `<p>Formas de abertura: ${(a.linguagem.aberturas).map((p) => `<span class="badge badge-demo" title="${esc(p.exemplo)}">${esc(p.estrutura)}</span>`).join(' ')}</p>`)}
      ${sel((a.ideias_principais || []).length, `<h4 class="ev-sub">Trechos da fonte <span class="badge badge-ok">literal</span></h4><ul>${lista(a.ideias_principais)}${lista(a.argumentos)}${lista(a.exemplos)}</ul>`)}
      <h4 class="ev-sub">Relações encontradas</h4>
      ${(d.relacoes || []).length ? `<ul>${d.relacoes.slice(0, 20).map((r) => `<li>${esc(r.de)} <span class="ev-muted">${esc(TIPO[r.tipo] || r.tipo)}</span> ${esc(r.para)}</li>`).join('')}</ul>` : '<p class="kpi-empty">Nenhuma ainda.</p>'}
      <p>Categorias: ${(d.categorias || []).map((c) => `<span class="badge ${c.origem === 'admin' ? 'badge-ok' : 'badge-demo'}">${esc(c.rotulo)}</span>`).join(' ') || '—'}</p>
      <p>Conceitos: ${(d.conceitos || []).slice(0, 24).map((c) => `<span class="badge badge-demo" title="${esc(TIPO_CONCEITO[c.tipo] || c.tipo)}">${esc(c.rotulo)}</span>`).join(' ')}</p>
      ${sel((d.insights || []).length, `<h4 class="ev-sub">Insights derivados <span class="badge badge-info">hipótese do Evolui</span></h4>${d.insights.map((i) => `<p>${esc(i.texto)}</p>`).join('')}`)}
      ${sel((d.conflitos || []).length, `<h4 class="ev-sub">Conflitos</h4>${d.conflitos.map((c) => `<p>${esc(c.descricao)} <span class="ev-muted">(${esc(c.status)})</span></p>`).join('')}`)}
      <h4 class="ev-sub">Onde foi utilizado</h4>
      ${(d.usos || []).length ? `<ul>${d.usos.map((u) => `<li>${esc(u.termo || 'pesquisa')} <span class="ev-muted">${dataBR(u.em)}</span></li>`).join('')}</ul>` : '<p class="kpi-empty">Ainda não foi usado em nenhuma pesquisa.</p>'}
      <details class="ev-como"><summary>Texto original (só visível aqui)</summary><pre style="white-space:pre-wrap">${esc(k.conteudo || '')}</pre></details>
    </div>`;
  const modal = abrirModal({ titulo: k.titulo, html, maxWidth: '760px' });
  const raiz = modal.box;
  const form = raiz.querySelector('#repEd');
  if (!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = new FormData(form), lis = (n) => String(f.get(n) || '').split(',').map((x) => x.trim()).filter(Boolean);
    try {
      await ajustarRepertorio(id, { titulo: f.get('titulo'), assunto: f.get('assunto'), fonte: f.get('fonte'), observacao: f.get('observacao'), tags: lis('tags'), categorias: lis('categorias'), status: f.get('arquivado') ? 'arquivado' : 'ativo' });
      showToast('Salvo.', { tone: 'ok' }); modal.close(); depois();
    } catch (err) { showToast(err.message, { tone: 'danger' }); }
  });
  raiz.querySelector('#repDel').addEventListener('click', async () => {
    if (!window.confirm('Excluir este conhecimento, com suas relações e insights? Isso não pode ser desfeito.')) return;
    try { await excluirRepertorio(id); showToast('Conhecimento excluído.', { tone: 'ok' }); modal.close(); depois(); }
    catch (err) { showToast(err.message, { tone: 'danger' }); }
  });
}
