/**
 * Início (Dashboard) — substitui a antiga "Visão Geral". Responde, num
 * relance, "quem sou eu, o que preciso ver agora" (perfil, ponto,
 * notificações, metas e um resumo bem enxuto de hoje) e manda o resto —
 * KPIs completos, funil, gráfico por dia e atividades recentes — pra
 * página "Desempenho" (pedido 13/09, 3ª rodada: "hoje são ~11 blocos
 * dentro do Início", precisa de página própria). Nenhum número aqui é
 * inventado; quando não há dado suficiente, mostra "sem dados".
 */
import { LoadingState } from '../components/LoadingState.js';
import { ErrorState } from '../components/ErrorState.js';
import { renderNotifications } from '../components/NotificationsList.js';
import { showToast } from '../components/Toast.js';
import { buscarRelatorio } from '../services/prospeccaoClient.js';
import { getCurrentUser } from '../services/auth.js';
import { fetchPonto, registrarPonto } from '../services/pontoClient.js';
import { listarMetas, definirMeta } from '../services/metasClient.js';
import { listarFuncionarios } from '../services/funcionariosClient.js';
import { fetchNotifications } from '../services/notificationsClient.js';
import { ehAdmin } from '../services/rbac.js';
import { avatarIlustradoSvgPorId, avatarIlustradoSvgPorGenero } from '../components/avatarIlustrado.js';
import { cicloMensalHtml } from '../components/CicloMensal.js';

const ROLE_LABEL = { admin: 'Administrador', prospeccao: 'Prospecção', design: 'Design' };

// nome/tempo_experiencia/funcoes são autoeditáveis por qualquer funcionário
// (Meu Perfil) — nunca inserir em innerHTML sem escapar, senão a própria
// pessoa (ou alguém que definiu esses campos) poderia injetar HTML/JS que
// executaria no navegador de quem visse o Início (achado numa auditoria de
// segurança, 13/09; mesmo princípio já aplicado em NotificationsList.js).
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function iniciaisDe(nome, email) {
  const base = (nome || email || '?').trim();
  const partes = base.split(/\s+/).filter(Boolean);
  if (partes.length >= 2) return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase();
  return base.slice(0, 2).toUpperCase();
}

function primeiroDiaDoMesIso() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString();
}

function segundaFeiraDestaSemanaIso() {
  const d = new Date();
  const diaSemana = d.getDay(); // 0=domingo
  const diff = diaSemana === 0 ? -6 : 1 - diaSemana;
  const segunda = new Date(d.getFullYear(), d.getMonth(), d.getDate() + diff);
  return segunda.toISOString().slice(0, 10);
}

function primeiroDiaDoMesData() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
}

export async function renderInicio(container) {
  container.innerHTML = '';

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Início</h2>
      <p>Resumo operacional de prospecção — só com dados reais já registrados.</p>
    </div>
  `;
  container.appendChild(head);

  const usuario = await getCurrentUser();
  if (usuario) {
    await renderBoasVindas(container, usuario);
  }

  const body = document.createElement('div');
  container.appendChild(body);

  carregar();

  async function carregar() {
    body.innerHTML = '';
    body.appendChild(LoadingState({ variant: 'cards', rows: 1 }));
    try {
      const dados = await buscarRelatorio('hoje');
      body.innerHTML = '';
      montarResumoRapido(body, dados);
    } catch (err) {
      body.innerHTML = '';
      body.appendChild(ErrorState({ description: err.message || 'Falha ao carregar o resumo de hoje.', onRetry: () => carregar() }));
    }
  }
}

/**
 * Boas-vindas: quem é (foto/nome/papel), ponto (dias/horas trabalhados no
 * mês — calculado a partir de cliques reais de Entrada/Saída, nunca um
 * número declarado), notificações (movidas de Sistema pra cá) e metas de
 * prospecção. Cada bloco carrega e falha de forma independente — um erro
 * aqui nunca deve impedir o resto do Início (resumo de hoje) de aparecer.
 */
async function renderBoasVindas(container, usuario) {
  const card = document.createElement('section');
  card.className = 'card';
  card.style.marginBottom = 'var(--space-5)';
  card.innerHTML = `
    <div class="welcome-card">
      <div class="welcome-profile">
        <div class="welcome-avatar-host" id="welcomeAvatarHost">
          ${usuario.fotoUrl
            ? `<img class="welcome-avatar" src="${esc(usuario.fotoUrl)}" alt="">`
            : `<div class="welcome-avatar welcome-avatar-initials">${esc(iniciaisDe(usuario.nome, usuario.email))}</div>`}
        </div>
        <div>
          <h3 class="fx-blur-reveal" style="margin-bottom:2px">Olá, ${esc(usuario.nome || usuario.email)}</h3>
          <span class="badge badge-demo">${esc(ROLE_LABEL[usuario.role] || usuario.role)}</span>
          <div class="welcome-perfil-extra" id="welcomePerfilExtra"></div>
        </div>
      </div>
      <div class="welcome-ponto" id="welcomePontoHost"><p class="kpi-empty">Carregando ponto…</p></div>
    </div>
  `;
  container.appendChild(card);
  carregarPonto(card.querySelector('#welcomePontoHost'), usuario.id);
  carregarPerfilExtra(card, usuario);

  const grid = document.createElement('div');
  grid.className = 'card-grid';
  grid.style.marginBottom = 'var(--space-5)';
  container.appendChild(grid);

  const notifCard = document.createElement('section');
  notifCard.className = 'card';
  notifCard.innerHTML = `<div class="card-head"><h3>Notificações</h3></div><div id="welcomeNotifHost"><p class="kpi-empty">Carregando…</p></div>`;
  grid.appendChild(notifCard);
  carregarNotificacoes(notifCard.querySelector('#welcomeNotifHost'));

  const metasCard = document.createElement('section');
  metasCard.className = 'card';
  const metasHeadExtra = ehAdmin(usuario) ? '<button class="btn btn-ghost btn-sm" id="definirMetaBtn">+ Definir meta</button>' : '';
  metasCard.innerHTML = `<div class="card-head"><h3>Metas de prospecção</h3>${metasHeadExtra}</div><div id="welcomeMetasHost"><p class="kpi-empty">Carregando…</p></div>`;
  grid.appendChild(metasCard);
  carregarMetas(metasCard.querySelector('#welcomeMetasHost'), usuario);
  if (ehAdmin(usuario)) {
    metasCard.querySelector('#definirMetaBtn').addEventListener('click', () => abrirDefinirMeta(metasCard.querySelector('#welcomeMetasHost'), usuario));
  }
}

async function carregarPonto(host, funcionarioId) {
  try {
    const { registros, resumo } = await fetchPonto({ inicio: primeiroDiaDoMesIso(), fim: new Date().toISOString() });
    const ultimo = registros[registros.length - 1];
    const proximaAcao = !ultimo || ultimo.tipo === 'saida' ? 'entrada' : 'saida';
    host.innerHTML = `
      <div class="welcome-ponto-row">
        ${cicloMensalHtml(resumo)}
        <button class="btn ${proximaAcao === 'entrada' ? 'btn-primary' : 'btn-ok'} btn-sm" id="pontoBtn">
          ${proximaAcao === 'entrada' ? 'Bater entrada' : 'Bater saída'}
        </button>
      </div>
    `;
    host.querySelector('#pontoBtn').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      try {
        await registrarPonto(proximaAcao);
        showToast(proximaAcao === 'entrada' ? 'Entrada registrada.' : 'Saída registrada.', { tone: 'ok' });
        carregarPonto(host, funcionarioId);
      } catch (err) {
        showToast(err.message || 'Falha ao registrar ponto.', { tone: 'danger' });
        btn.disabled = false;
      }
    });
  } catch (err) {
    host.innerHTML = `<p class="kpi-empty">Não foi possível carregar o ponto (${esc(err.message || 'erro')}).</p>`;
  }
}

/**
 * Tempo de experiência / funções / avatar ilustrado — só o admin define
 * (ver Equipe); aqui é só leitura, o mesmo perfil que a pessoa vê de si
 * mesma. Sem esses dados (ainda não preenchidos, ou migração não
 * aplicada), o card de boas-vindas simplesmente não mostra nada extra —
 * nunca um campo vazio "quebrado". Troca o avatar de iniciais por um
 * personagem ilustrado SÓ quando não há foto_url e o gênero foi definido —
 * foto real sempre tem prioridade sobre a ilustração.
 */
async function carregarPerfilExtra(card, usuario) {
  try {
    const funcionarios = await listarFuncionarios();
    const propria = funcionarios.find((f) => f.id === usuario.id);
    if (!propria) return;

    const linhas = [propria.tempo_experiencia, propria.funcoes].filter(Boolean);
    const extraHost = card.querySelector('#welcomePerfilExtra');
    if (extraHost && linhas.length > 0) {
      extraHost.innerHTML = linhas.map((l) => `<div class="kpi-empty">${esc(l)}</div>`).join('');
    }

    // Prioridade: avatar escolhido na galeria nova > avatar pelo gênero
    // antigo (compatibilidade, pra quem ainda não passou pela migração de
    // backfill ou nunca abriu "Meu Perfil") > iniciais (já era o padrão,
    // não precisa de nada aqui).
    if (!usuario.fotoUrl && (propria.avatar_escolhido || propria.genero)) {
      const avatarHost = card.querySelector('#welcomeAvatarHost');
      const svg = propria.avatar_escolhido ? avatarIlustradoSvgPorId(propria.avatar_escolhido) : avatarIlustradoSvgPorGenero(propria.genero);
      if (avatarHost && svg) avatarHost.innerHTML = `<div class="welcome-avatar welcome-avatar-ilustrado">${svg}</div>`;
    }
  } catch {
    // Silencioso de propósito — é um detalhe do cabeçalho, não pode travar
    // nem "gritar" erro por cima do resto do Início se falhar.
  }
}

async function carregarNotificacoes(host) {
  try {
    const notifications = await fetchNotifications({ onlyUnread: false });
    host.innerHTML = '';
    host.appendChild(renderNotifications(notifications.slice(0, 6), { onChange: () => carregarNotificacoes(host) }));
  } catch (err) {
    host.innerHTML = `<p class="kpi-empty">Não foi possível carregar notificações (${esc(err.message || 'erro')}).</p>`;
  }
}

/**
 * Progresso = contagem REAL de mensagens enviadas (whatsapp_enviado) no
 * período — nunca um número que a pessoa "envia" manualmente pro Felipe. A
 * janela usada (rolante, via buscarRelatorio) é a mesma do resto do
 * Início: "semana" = últimos 7 dias, "mes" = últimos 30 dias — aproximado
 * à semana/mês corrido da meta, não alinhado ao calendário Seg-Dom.
 */
async function carregarMetas(host, usuario) {
  try {
    const [metas, dadosSemana, dadosMes] = await Promise.all([
      listarMetas(),
      buscarRelatorio('semana'),
      buscarRelatorio('mes'),
    ]);
    const minhas = metas.filter((m) => m.funcionario_id === usuario.id);
    const metaSemanal = minhas.find((m) => m.periodo === 'semanal');
    const metaMensal = minhas.find((m) => m.periodo === 'mensal');

    if (!metaSemanal && !metaMensal) {
      host.innerHTML = '<p class="kpi-empty">Nenhuma meta definida ainda.</p>';
      return;
    }

    const progressoSemana = (dadosSemana.atividades || []).filter((a) => a.tipo === 'whatsapp_enviado').length;
    const progressoMes = (dadosMes.atividades || []).filter((a) => a.tipo === 'whatsapp_enviado').length;

    host.innerHTML = [
      metaSemanal ? metaBarraHtml('Semanal', progressoSemana, metaSemanal.meta) : '',
      metaMensal ? metaBarraHtml('Mensal', progressoMes, metaMensal.meta) : '',
    ].join('');
  } catch (err) {
    host.innerHTML = `<p class="kpi-empty">Não foi possível carregar metas (${esc(err.message || 'erro')}).</p>`;
  }
}

function metaBarraHtml(label, progresso, meta) {
  const pct = Math.min(100, Math.round((progresso / meta) * 100));
  const bateu = progresso >= meta;
  return `
    <div class="funnel-row">
      <span class="funnel-label">${label}</span>
      <div class="funnel-bar-track"><div class="funnel-bar-fill${bateu ? ' is-complete' : ''}" style="width:${pct}%"></div></div>
      <span class="funnel-count">${progresso}/${meta}</span>
    </div>
    ${bateu ? '<div class="fx-gradient-text" style="font-size:.78rem;font-weight:700;margin-top:2px">Meta batida! 🎯</div>' : ''}
  `;
}

async function abrirDefinirMeta(host, usuarioAdmin) {
  try {
    const funcionarios = await listarFuncionarios();
    const prospectores = funcionarios.filter((f) => f.role === 'prospeccao' && f.ativo);
    if (prospectores.length === 0) {
      showToast('Nenhum funcionário com papel "prospecção" ativo cadastrado.', { tone: 'danger' });
      return;
    }
    const lista = prospectores.map((f, i) => `${i + 1}. ${f.nome}`).join('\n');
    const escolha = window.prompt(`Definir meta pra qual funcionário?\n${lista}\n\nDigite o número:`);
    const idx = Number(escolha) - 1;
    const funcionario = prospectores[idx];
    if (!funcionario) return;

    const periodo = window.prompt('Período — digite "semanal" ou "mensal":', 'semanal');
    if (!['semanal', 'mensal'].includes(periodo)) {
      showToast('Período inválido. Use "semanal" ou "mensal".', { tone: 'danger' });
      return;
    }
    const metaTxt = window.prompt(`Meta de mensagens enviadas (WhatsApp) por ${periodo === 'semanal' ? 'semana' : 'mês'}:`, '20');
    const meta = Number(metaTxt);
    if (!Number.isInteger(meta) || meta <= 0) {
      showToast('Informe um número inteiro maior que zero.', { tone: 'danger' });
      return;
    }

    await definirMeta({
      funcionarioId: funcionario.id,
      periodo,
      referencia: periodo === 'semanal' ? segundaFeiraDestaSemanaIso() : primeiroDiaDoMesData(),
      meta,
    });
    showToast(`Meta ${periodo} de ${funcionario.nome} definida: ${meta}.`, { tone: 'ok' });
    carregarMetas(host, usuarioAdmin);
  } catch (err) {
    showToast(err.message || 'Falha ao definir meta.', { tone: 'danger' });
  }
}

/**
 * Resumo bem enxuto de HOJE — só 3 números que já eram calculados aqui
 * mesmo, mais um link pra página completa. Os KPIs detalhados, o funil, o
 * gráfico por dia e as atividades recentes moraram aqui antes; agora moram
 * em Desempenho (ver desempenho.js), com "Atividades recentes" reordenada
 * pra mais acima do que o gráfico por dia, por pedido explícito.
 */
function montarResumoRapido(body, dados) {
  const resumo = dados.resumo || {};
  const atividades = dados.atividades || [];
  const leadsHoje = resumo.leadsNoPeriodo || 0;
  const mensagensHoje = atividades.filter((a) => a.tipo === 'whatsapp_enviado').length + (resumo.emailsEnviados || 0);
  const respostasHoje = atividades.filter((a) => a.tipo === 'resposta_recebida').length;

  const card = document.createElement('section');
  card.className = 'card';
  card.innerHTML = `
    <div class="card-head">
      <h3>Resumo de hoje</h3>
      <a class="btn btn-ghost btn-sm" href="#/desempenho">Ver desempenho completo →</a>
    </div>
    <div class="resumo-rapido-grid">
      <div class="resumo-rapido-item"><strong>${leadsHoje}</strong><span>Leads captados</span></div>
      <div class="resumo-rapido-item"><strong>${mensagensHoje}</strong><span>Mensagens enviadas</span></div>
      <div class="resumo-rapido-item"><strong>${respostasHoje}</strong><span>Respostas recebidas</span></div>
    </div>
  `;
  body.appendChild(card);
}
