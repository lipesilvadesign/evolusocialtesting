import { LoadingState } from '../components/LoadingState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { getSettings, saveSettings } from '../services/settingsApi.js';
import { testGaConnection } from '../services/analyticsClient.js';
import { getCurrentUser } from '../services/auth.js';
import { canManageSettings } from '../services/rbac.js';

const AUTOSAVE_DELAY = 900;

const DEFAULTS = {
  informacoesGerais: { nomeMarca: 'Felipe Branding', descricao: '', logo: '', favicon: '' },
  contato: {
    whatsapp: '',
    telefone: '',
    email: '',
    localizacao: '',
    redesSociais: { instagram: '', linkedin: '', behance: '' },
  },
  seo: { tituloPadrao: '', descricaoPadrao: '', ogImagemPadrao: '', indexavel: true },
  analytics: { ga4PropertyId: '', status: 'nao_conectado', ultimaSincronizacao: null },
  integracoes: { googleAnalytics: false, searchConsole: false, googleBusinessProfile: false, ia: false },
};

function deepMerge(base, patch) {
  const out = { ...base };
  Object.keys(patch || {}).forEach((k) => {
    if (patch[k] && typeof patch[k] === 'object' && !Array.isArray(patch[k]) && base[k]) {
      out[k] = deepMerge(base[k], patch[k]);
    } else {
      out[k] = patch[k];
    }
  });
  return out;
}

export async function renderConfiguracoes(container) {
  container.innerHTML = '';

  const user = await getCurrentUser();
  const canEdit = canManageSettings(user);

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Configurações</h2>
      <p>Dados gerais do site, organizados por seção. Cada seção salva de forma independente.</p>
    </div>
    <span class="autosave-indicator" id="settingsIndicator"></span>
  `;
  container.appendChild(head);

  const body = document.createElement('div');
  container.appendChild(body);
  body.appendChild(LoadingState({ rows: 6 }));

  load();

  function load() {
    body.innerHTML = '';
    body.appendChild(LoadingState({ rows: 6 }));
    getSettings()
      .then((remote) => {
        const settings = deepMerge(DEFAULTS, remote || {});
        body.innerHTML = '';
        body.appendChild(buildInformacoesGerais(settings));
        body.appendChild(buildContato(settings));
        body.appendChild(buildSeo(settings));
        body.appendChild(buildAnalytics(settings));
        // buildIntegracoes() (bloco "Integrações" com selos estáticos
        // "Estrutura preparada · não conectado") foi removido na limpeza
        // final — era só vitrine, sem nenhuma ação real por trás, e ainda
        // por cima descrevia Analytics/IA como "não conectado" quando as
        // duas já funcionam de verdade em Métricas/Insights. Quando uma
        // integração de verdade (Search Console, GBP) for implementada,
        // ela ganha sua própria tela funcional em vez de reaproveitar isto.
      })
      .catch((err) => {
        body.innerHTML = '';
        body.appendChild(ErrorState({ description: err.message, onRetry: load }));
      });
  }

  function autosaveSection(sectionKey, sectionValue) {
    const indicator = document.getElementById('settingsIndicator');
    if (indicator) indicator.textContent = 'Salvando…';
    return saveSettings({ [sectionKey]: sectionValue })
      .then(() => {
        if (indicator) indicator.textContent = 'Salvo';
      })
      .catch((err) => {
        if (indicator) indicator.textContent = '';
        showToast(err.message || 'Falha ao salvar configurações.', { tone: 'danger' });
      });
  }

  function fieldRow(label, value, onChange, opts = {}) {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    const l = document.createElement('label');
    l.textContent = label;
    wrap.appendChild(l);

    if (opts.type === 'image') {
      const row = document.createElement('div');
      row.className = 'img-field';
      const preview = document.createElement('img');
      preview.className = 'img-preview';
      preview.src = value || '';
      preview.style.display = value ? 'block' : 'none';
      const inputsWrap = document.createElement('div');
      inputsWrap.className = 'img-inputs';
      const fileInput = document.createElement('input');
      fileInput.type = 'file';
      fileInput.accept = 'image/*';
      fileInput.style.display = 'none';
      const fileBtn = document.createElement('span');
      fileBtn.className = 'file-btn';
      fileBtn.textContent = value ? 'Trocar' : 'Enviar';
      fileBtn.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', () => {
        const file = fileInput.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          preview.src = reader.result;
          preview.style.display = 'block';
          fileBtn.textContent = 'Trocar';
          onChange(reader.result);
        };
        reader.readAsDataURL(file);
      });
      inputsWrap.appendChild(fileBtn);
      inputsWrap.appendChild(fileInput);
      row.appendChild(preview);
      row.appendChild(inputsWrap);
      wrap.appendChild(row);
      return wrap;
    }

    if (opts.type === 'checkbox') {
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.style.width = 'auto';
      input.checked = Boolean(value);
      input.addEventListener('change', () => onChange(input.checked));
      wrap.style.display = 'flex';
      wrap.style.alignItems = 'center';
      wrap.style.gap = 'var(--space-2)';
      l.style.marginBottom = '0';
      wrap.appendChild(input);
      return wrap;
    }

    const input = opts.type === 'textarea' ? document.createElement('textarea') : document.createElement('input');
    if (opts.type !== 'textarea') input.type = opts.type || 'text';
    if (!canEdit) input.disabled = true;
    input.value = value || '';
    let timer = null;
    input.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => onChange(input.value), AUTOSAVE_DELAY);
    });
    wrap.appendChild(input);
    return wrap;
  }

  function buildInformacoesGerais(settings) {
    const s = settings.informacoesGerais;
    const card = document.createElement('section');
    card.className = 'card';
    card.innerHTML = `<div class="card-head"><h3>Informações gerais</h3></div>`;
    card.appendChild(fieldRow('Nome da marca', s.nomeMarca, (v) => autosaveSection('informacoesGerais', { ...s, nomeMarca: v })));
    card.appendChild(
      fieldRow('Descrição', s.descricao, (v) => autosaveSection('informacoesGerais', { ...s, descricao: v }), {
        type: 'textarea',
      })
    );
    card.appendChild(
      fieldRow('Logo', s.logo, (v) => autosaveSection('informacoesGerais', { ...s, logo: v }), { type: 'image' })
    );
    card.appendChild(
      fieldRow('Favicon', s.favicon, (v) => autosaveSection('informacoesGerais', { ...s, favicon: v }), {
        type: 'image',
      })
    );
    return card;
  }

  function buildContato(settings) {
    const s = settings.contato;
    const card = document.createElement('section');
    card.className = 'card';
    card.innerHTML = `<div class="card-head"><h3>Contato</h3></div>`;
    card.appendChild(fieldRow('WhatsApp', s.whatsapp, (v) => autosaveSection('contato', { ...s, whatsapp: v })));
    card.appendChild(fieldRow('Telefone', s.telefone, (v) => autosaveSection('contato', { ...s, telefone: v })));
    card.appendChild(fieldRow('E-mail', s.email, (v) => autosaveSection('contato', { ...s, email: v }), { type: 'email' }));
    card.appendChild(
      fieldRow('Localização', s.localizacao, (v) => autosaveSection('contato', { ...s, localizacao: v }))
    );
    card.appendChild(
      fieldRow('Instagram', s.redesSociais.instagram, (v) =>
        autosaveSection('contato', { ...s, redesSociais: { ...s.redesSociais, instagram: v } })
      )
    );
    card.appendChild(
      fieldRow('LinkedIn', s.redesSociais.linkedin, (v) =>
        autosaveSection('contato', { ...s, redesSociais: { ...s.redesSociais, linkedin: v } })
      )
    );
    card.appendChild(
      fieldRow('Behance', s.redesSociais.behance, (v) =>
        autosaveSection('contato', { ...s, redesSociais: { ...s.redesSociais, behance: v } })
      )
    );
    return card;
  }

  function buildSeo(settings) {
    const s = settings.seo;
    const card = document.createElement('section');
    card.className = 'card';
    card.innerHTML = `<div class="card-head"><h3>SEO</h3></div>`;
    card.appendChild(
      fieldRow('Título padrão', s.tituloPadrao, (v) => autosaveSection('seo', { ...s, tituloPadrao: v }))
    );
    card.appendChild(
      fieldRow('Descrição padrão', s.descricaoPadrao, (v) => autosaveSection('seo', { ...s, descricaoPadrao: v }), {
        type: 'textarea',
      })
    );
    card.appendChild(
      fieldRow('Imagem Open Graph padrão', s.ogImagemPadrao, (v) => autosaveSection('seo', { ...s, ogImagemPadrao: v }), {
        type: 'image',
      })
    );
    card.appendChild(
      fieldRow('Permitir indexação (robots)', s.indexavel, (v) => autosaveSection('seo', { ...s, indexavel: v }), {
        type: 'checkbox',
      })
    );
    return card;
  }

  function buildAnalytics(settings) {
    const s = settings.analytics;
    const card = document.createElement('section');
    card.className = 'card';
    const statusBadge = document.createElement('span');
    statusBadge.className = `badge ${s.status === 'conectado' ? 'badge-ok' : 'badge-demo'}`;
    statusBadge.textContent = s.status === 'conectado' ? 'Conectado' : 'Não conectado';

    const headEl = document.createElement('div');
    headEl.className = 'card-head';
    const h3 = document.createElement('h3');
    h3.textContent = 'Analytics';
    headEl.appendChild(h3);
    headEl.appendChild(statusBadge);
    card.appendChild(headEl);

    card.appendChild(
      fieldRow('GA4 Property ID', s.ga4PropertyId, (v) => autosaveSection('analytics', { ...s, ga4PropertyId: v }), {
        placeholder: '000000000',
      })
    );

    const note = document.createElement('p');
    note.id = 'gaLastSync';
    note.style.cssText = 'color:var(--text-muted);font-size:.82rem;margin:var(--space-2) 0 var(--space-3)';
    note.textContent = `Última sincronização: ${
      s.ultimaSincronizacao ? new Date(s.ultimaSincronizacao).toLocaleString('pt-BR') : 'nunca'
    }. O Property ID acima não é um segredo (é o mesmo tipo de identificador já público na tag do site) — a credencial da service account fica só em variável de ambiente do Netlify, nunca aqui.`;
    card.appendChild(note);

    const testBtn = document.createElement('button');
    testBtn.type = 'button';
    testBtn.className = 'btn btn-ghost btn-sm';
    testBtn.textContent = 'Testar conexão';
    testBtn.disabled = !canEdit;
    testBtn.addEventListener('click', async () => {
      testBtn.disabled = true;
      testBtn.textContent = 'Testando…';
      try {
        const result = await testGaConnection();
        statusBadge.className = 'badge badge-ok';
        statusBadge.textContent = 'Conectado';
        note.textContent = result.empty
          ? 'Conexão OK — o GA4 respondeu, mas sem dados no período testado (normal em propriedades novas).'
          : `Última sincronização: ${new Date().toLocaleString('pt-BR')}. Conexão confirmada agora.`;
        showToast('Conexão com o Google Analytics confirmada.', { tone: 'ok' });
      } catch (err) {
        statusBadge.className = 'badge badge-danger';
        statusBadge.textContent = 'Falha na conexão';
        showToast(err.message || 'Falha ao testar a conexão.', { tone: 'danger' });
      } finally {
        testBtn.disabled = !canEdit;
        testBtn.textContent = 'Testar conexão';
      }
    });
    card.appendChild(testBtn);

    return card;
  }

}
