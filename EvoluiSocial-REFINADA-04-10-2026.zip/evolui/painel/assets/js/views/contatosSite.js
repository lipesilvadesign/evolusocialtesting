/**
 * "Contatos do site" (29/09) — tudo que chega pelo formulário "Vamos
 * conversar" da home. Antes o formulário só abria o WhatsApp e nada ficava
 * registrado; agora cada envio é gravado (site_contatos), gera notificação
 * no sino e um aviso por e-mail para a caixa contato@.
 *
 * Esta tela também é o lugar de CONFERIR se os e-mails estão chegando:
 * cada contato mostra o status do aviso (enviado / pendente / falhou /
 * SMTP não configurado), com "Reenviar aviso", e o topo tem "Testar envio".
 *
 * Mesmo padrão de views/consultorias.js; todo texto vindo do visitante
 * passa por esc() antes de ir para o HTML.
 */

import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { confirmDialog } from '../components/ConfirmDialog.js';
import { showToast } from '../components/Toast.js';
import { abrirModal } from '../components/Modal.js';
import { converterInbound } from '../services/prospeccaoClient.js';
import {
  fetchContatosSite,
  updateContatoSite,
  deleteContatoSite,
  reenviarAvisoContato,
  testarEmailContatos,
} from '../services/contatosSiteClient.js';
import { esc, safeUrl } from '../utils/html.js';

const STATUS_MAP = {
  novo: { label: 'Novo', cls: 'badge-warning' },
  em_atendimento: { label: 'Em atendimento', cls: 'badge-info' },
  respondido: { label: 'Respondido', cls: 'badge-info' },
  convertido: { label: 'Virou cliente', cls: 'badge-ok' },
  arquivado: { label: 'Arquivado', cls: 'badge-demo' },
};
const STATUS_ORDER = Object.keys(STATUS_MAP);

const EMAIL_MAP = {
  enviado: { label: 'E-mail enviado', cls: 'badge-ok' },
  pendente: { label: 'E-mail pendente', cls: 'badge-warning' },
  falhou: { label: 'E-mail falhou', cls: 'badge-danger' },
  sem_smtp: { label: 'E-mail não configurado', cls: 'badge-danger' },
};

const ORCAMENTOS = { 'ate-3k': 'Até R$3 mil', '3-8k': 'R$3 a 8 mil', '8k+': 'Acima de R$8 mil' };

function badge(map, key, fallback) {
  const info = map[key] || map[fallback];
  return `<span class="badge ${info.cls}">${esc(info.label)}</span>`;
}
function waLink(whatsapp, mensagem) {
  const d = String(whatsapp || '').replace(/\D/g, '');
  if (d.length < 10) return null;
  const comPais = d.length <= 11 ? `55${d}` : d;
  return `https://wa.me/${comPais}${mensagem ? `?text=${encodeURIComponent(mensagem)}` : ''}`;
}
function formatarWhatsapp(whatsapp) {
  const d = String(whatsapp || '').replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return d;
}
function dataHora(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function tempoRelativo(iso) {
  const min = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (min < 1) return 'agora';
  if (min < 60) return `há ${min} min`;
  const h = Math.round(min / 60);
  if (h < 24) return `há ${h} h`;
  const d = Math.round(h / 24);
  return `há ${d} dia${d > 1 ? 's' : ''}`;
}
function semAcento(s) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

export async function renderContatosSite(container) {
  container.innerHTML = '';
  const root = document.createElement('div');
  root.className = 'contatos-site-view';
  container.appendChild(root);

  let contatos = [];
  let emailInfo = null;
  let filtroStatus = 'ativos';
  let busca = '';

  root.innerHTML = `
    <div class="app-view-head">
      <div>
        <p class="eyebrow">Central administrativa</p>
        <h2>Contatos do site</h2>
        <p>Tudo que chega pelo formulário "Vamos conversar" da página inicial. Cada contato também avisa no sino e por e-mail.</p>
      </div>
    </div>
    <section class="card contatos-email-card" id="emailStatusCard" aria-live="polite"></section>
    <div class="content-toolbar">
      <div class="search-box-small">
        <input type="search" id="contatoBusca" placeholder="Buscar por nome, e-mail ou serviço…" aria-label="Buscar contato">
      </div>
      <select id="contatoFiltro" aria-label="Filtrar por status">
        <option value="ativos">Em aberto (novo + em atendimento)</option>
        <option value="todos">Todos</option>
        ${STATUS_ORDER.map((s) => `<option value="${s}">${esc(STATUS_MAP[s].label)}</option>`).join('')}
      </select>
      <button class="btn btn-ghost btn-sm" type="button" id="contatosAtualizar">Atualizar</button>
    </div>
    <section class="card" id="contatosLista"></section>
  `;
  const emailCard = root.querySelector('#emailStatusCard');
  const listCard = root.querySelector('#contatosLista');

  function renderEmailCard() {
    if (!emailInfo) { emailCard.hidden = true; return; }
    emailCard.hidden = false;
    const problemas = contatos.filter((c) => c.email_status !== 'enviado');
    const ultimoEnviado = contatos.find((c) => c.email_status === 'enviado');
    let tom = 'ok';
    let titulo = 'Avisos por e-mail funcionando';
    let texto = `Cada novo contato é enviado para ${emailInfo.destino}.`;
    if (!emailInfo.configurado) {
      tom = 'danger';
      titulo = 'Avisos por e-mail desligados';
      texto = 'O servidor de e-mail (UMBLER_SMTP_USER/UMBLER_SMTP_PASS) não está configurado no Netlify. Os contatos continuam chegando aqui e no sino, mas nenhum e-mail sai.';
    } else if (problemas.length) {
      tom = 'warning';
      titulo = `${problemas.length} aviso(s) por e-mail não confirmado(s)`;
      texto = `Destino: ${emailInfo.destino}. O sistema tenta de novo a cada hora; você também pode reenviar em cada contato.`;
    }
    emailCard.className = `card contatos-email-card is-${tom}`;
    emailCard.innerHTML = `
      <div class="contatos-email-texto">
        <strong>${esc(titulo)}</strong>
        <p>${esc(texto + (ultimoEnviado ? ` Último aviso confirmado: ${dataHora(ultimoEnviado.email_enviado_em)}.` : ''))}</p>
      </div>
      <button class="btn btn-ghost btn-sm" type="button" id="testarEmailBtn">Testar envio de e-mail</button>
    `;
    emailCard.querySelector('#testarEmailBtn').addEventListener('click', testarEnvio);
  }

  async function testarEnvio(ev) {
    const btn = ev.currentTarget;
    btn.disabled = true;
    btn.textContent = 'Enviando teste…';
    try {
      const { resultado } = await testarEmailContatos();
      if (resultado.status === 'enviado') {
        showToast(`E-mail de teste enviado para ${resultado.destino}. Confira a caixa de entrada (e o spam).`, { tone: 'ok' });
      } else if (resultado.status === 'sem_smtp') {
        showToast('O e-mail não está configurado no Netlify (UMBLER_SMTP_USER/UMBLER_SMTP_PASS).', { tone: 'danger' });
      } else {
        showToast(`O servidor de e-mail recusou: ${resultado.erro || 'erro desconhecido'}`, { tone: 'danger' });
      }
    } catch (err) {
      showToast(err.message || 'Falha ao testar o envio.', { tone: 'danger' });
    } finally {
      if (btn.isConnected) { btn.disabled = false; btn.textContent = 'Testar envio de e-mail'; }
    }
  }

  function filtrados() {
    const termo = semAcento(busca.trim());
    return contatos.filter((c) => {
      const okStatus =
        filtroStatus === 'todos' ||
        (filtroStatus === 'ativos' ? c.status === 'novo' || c.status === 'em_atendimento' : c.status === filtroStatus);
      const okBusca = !termo || semAcento(`${c.nome} ${c.email} ${c.servico} ${c.mensagem}`).includes(termo);
      return okStatus && okBusca;
    });
  }

  function renderLista() {
    listCard.innerHTML = '';
    const linhas = filtrados();
    if (!linhas.length) {
      listCard.appendChild(
        EmptyState({
          title: contatos.length ? 'Nada com esses filtros' : 'Nenhum contato ainda',
          description: contatos.length
            ? 'Troque o filtro para "Todos" para ver os contatos já respondidos ou arquivados.'
            : 'Assim que alguém enviar o formulário "Vamos conversar" da página inicial, o contato aparece aqui.',
        })
      );
      return;
    }
    const ul = document.createElement('ul');
    ul.className = 'contatos-lista';
    ul.innerHTML = linhas
      .map(
        (c) => `
        <li>
          <button type="button" class="contato-item${c.status === 'novo' ? ' is-novo' : ''}" data-id="${esc(c.id)}">
            <span class="contato-topo">
              <strong>${esc(c.nome)}</strong>
              <span class="contato-quando" title="${esc(dataHora(c.created_at))}">${esc(tempoRelativo(c.created_at))}</span>
            </span>
            <span class="contato-meta">${esc(c.servico)}${c.orcamento ? ` · ${esc(ORCAMENTOS[c.orcamento] || c.orcamento)}` : ''}</span>
            <span class="contato-previa">${esc(c.mensagem)}</span>
            <span class="contato-badges">${badge(STATUS_MAP, c.status, 'novo')} ${badge(EMAIL_MAP, c.email_status, 'pendente')}</span>
          </button>
        </li>`
      )
      .join('');
    ul.querySelectorAll('.contato-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        const contato = contatos.find((c) => c.id === btn.dataset.id);
        if (contato) abrirDetalhe(contato, btn);
      });
    });
    listCard.appendChild(ul);
  }

  function substituir(atualizado) {
    const i = contatos.findIndex((c) => c.id === atualizado.id);
    if (i !== -1) contatos[i] = atualizado;
    renderEmailCard();
    renderLista();
    window.dispatchEvent(new CustomEvent('contatos-site:mudou'));
  }

  function abrirDetalhe(contato, origem) {
    const wa = waLink(contato.whatsapp, `Olá, ${contato.nome}! Aqui é o Felipe, da Felipe Branding. Recebi sua mensagem pelo site sobre ${contato.servico}.`);
    const mailto = `mailto:${encodeURIComponent(contato.email)}?subject=${encodeURIComponent(`Felipe Branding — ${contato.servico}`)}`;
    const email = EMAIL_MAP[contato.email_status] || EMAIL_MAP.pendente;
    const { box, close } = abrirModal({
      titulo: contato.nome,
      origem,
      host: root,
      html: `
        <p class="text-muted contato-sub">Recebido em ${esc(dataHora(contato.created_at))} · ${esc(contato.servico)}${contato.orcamento ? ` · ${esc(ORCAMENTOS[contato.orcamento] || contato.orcamento)}` : ''}</p>
        <blockquote class="contato-mensagem">${esc(contato.mensagem)}</blockquote>
        <dl class="contato-dados">
          <div><dt>E-mail</dt><dd><a href="${esc(safeUrl(mailto))}">${esc(contato.email)}</a></dd></div>
          <div><dt>WhatsApp</dt><dd>${esc(formatarWhatsapp(contato.whatsapp))}</dd></div>
          <div><dt>Aviso por e-mail</dt><dd><span class="badge ${email.cls}">${esc(email.label)}</span>${
            contato.email_status === 'enviado' && contato.email_enviado_em ? ` <span class="text-muted">em ${esc(dataHora(contato.email_enviado_em))}</span>` : ''
          }${contato.email_ultimo_erro ? `<br><span class="text-muted contato-erro">${esc(contato.email_ultimo_erro)}</span>` : ''}</dd></div>
        </dl>
        <div class="contato-acoes">
          ${wa ? `<a class="btn btn-primary btn-sm" href="${esc(safeUrl(wa))}" target="_blank" rel="noopener noreferrer">Responder no WhatsApp</a>` : ''}
          <a class="btn btn-ghost btn-sm" href="${esc(safeUrl(mailto))}">Responder por e-mail</a>
          ${contato.convertido_lead_id
            ? `<a class="btn btn-ghost btn-sm" href="#/clientes/${esc(contato.convertido_lead_id)}">Ver lead no CRM</a>`
            : '<button class="btn btn-ghost btn-sm" type="button" data-acao="converter" title="Cria (ou vincula a) um lead na Prospecção — sem duplicar">Converter em lead</button>'}
          <button class="btn btn-ghost btn-sm" type="button" data-acao="reenviar">${contato.email_status === 'enviado' ? 'Reenviar aviso por e-mail' : 'Tentar enviar o aviso agora'}</button>
        </div>
        <div class="content-editor-form">
          <div class="field">
            <label for="contatoStatus">Status</label>
            <select id="contatoStatus">${STATUS_ORDER.map((s) => `<option value="${s}"${s === contato.status ? ' selected' : ''}>${esc(STATUS_MAP[s].label)}</option>`).join('')}</select>
          </div>
          <div class="field field-full">
            <label for="contatoObs">Observações internas</label>
            <textarea id="contatoObs" rows="3" maxlength="4000" placeholder="Só a equipe vê">${esc(contato.observacoes_internas || '')}</textarea>
          </div>
        </div>
        ${contato.atualizado_por ? `<p class="text-muted contato-sub">Última alteração por ${esc(contato.atualizado_por)} em ${esc(dataHora(contato.updated_at))}</p>` : ''}
        <div class="modal-rodape">
          <button class="btn btn-danger btn-sm" type="button" data-acao="excluir">Excluir</button>
          <button class="btn btn-primary btn-sm" type="button" data-acao="salvar">Salvar</button>
        </div>
      `,
    });

    const btnConverter = box.querySelector('[data-acao="converter"]');
    if (btnConverter) btnConverter.addEventListener('click', async () => {
      btnConverter.disabled = true;
      try {
        const r = await converterInbound('site_contato', contato.id);
        const leadId = r.lead_id || r.match_lead_id;
        if (leadId) substituir({ ...contato, convertido_lead_id: leadId });
        const msg = { aprovado: 'Lead criado na Prospecção.', vinculado: 'Já existia um lead com este contato: vinculado a ele.', ja_convertido: 'Este contato já tinha sido convertido.' }[r.resultado] || `Resultado: ${r.resultado}`;
        showToast(msg, { tone: 'ok' });
        close();
      } catch (err) {
        showToast(err.message || 'Falha ao converter.', { tone: 'danger' });
        btnConverter.disabled = false;
      }
    });

    box.querySelector('[data-acao="reenviar"]').addEventListener('click', async (ev) => {
      const btn = ev.currentTarget;
      btn.disabled = true;
      btn.textContent = 'Enviando…';
      try {
        const { resultado, contato: atualizado } = await reenviarAvisoContato(contato.id);
        if (atualizado) substituir(atualizado);
        if (resultado.status === 'enviado') showToast('Aviso enviado por e-mail.', { tone: 'ok' });
        else if (resultado.status === 'sem_smtp') showToast('O e-mail não está configurado no Netlify.', { tone: 'danger' });
        else showToast(`Não enviou: ${resultado.erro || 'erro desconhecido'}`, { tone: 'danger' });
        close();
      } catch (err) {
        showToast(err.message || 'Falha ao reenviar.', { tone: 'danger' });
        if (btn.isConnected) { btn.disabled = false; btn.textContent = 'Tentar de novo'; }
      }
    });

    box.querySelector('[data-acao="salvar"]').addEventListener('click', async (ev) => {
      const btn = ev.currentTarget;
      btn.disabled = true;
      try {
        const atualizado = await updateContatoSite(contato.id, {
          status: box.querySelector('#contatoStatus').value,
          observacoesInternas: box.querySelector('#contatoObs').value.trim() || null,
        });
        substituir(atualizado);
        showToast('Contato atualizado.', { tone: 'ok' });
        close();
      } catch (err) {
        showToast(err.message || 'Falha ao salvar.', { tone: 'danger' });
        if (btn.isConnected) btn.disabled = false;
      }
    });

    box.querySelector('[data-acao="excluir"]').addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Excluir este contato?',
        description: `${contato.nome} (${contato.email}) será removido permanentemente.`,
        confirmLabel: 'Excluir',
      });
      if (!ok) return;
      try {
        await deleteContatoSite(contato.id);
        contatos = contatos.filter((c) => c.id !== contato.id);
        renderEmailCard();
        renderLista();
        showToast('Contato excluído.', { tone: 'ok' });
        close();
      } catch (err) {
        showToast(err.message || 'Falha ao excluir.', { tone: 'danger' });
      }
    });
  }

  root.querySelector('#contatoBusca').addEventListener('input', (e) => { busca = e.target.value; renderLista(); });
  root.querySelector('#contatoFiltro').addEventListener('change', (e) => { filtroStatus = e.target.value; renderLista(); });
  root.querySelector('#contatosAtualizar').addEventListener('click', () => carregar());

  async function carregar() {
    listCard.innerHTML = '';
    listCard.appendChild(LoadingState({ rows: 4 }));
    try {
      const dados = await fetchContatosSite();
      contatos = dados.contatos || [];
      emailInfo = dados.email || null;
      renderEmailCard();
      renderLista();
    } catch (err) {
      emailCard.hidden = true;
      listCard.innerHTML = '';
      listCard.appendChild(ErrorState({ description: err.message || 'Falha ao carregar os contatos.', onRetry: carregar }));
    }
  }

  carregar();
}
