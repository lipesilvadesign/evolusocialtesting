/**
 * "Meu Perfil" (pedido do Felipe, 13/09, 2ª rodada) — página onde qualquer
 * funcionário logado edita a PRÓPRIA linha: nome, biografia, foto, tempo
 * de experiência, funções e avatar ilustrado (pro card de boas-vindas
 * quando não tem foto). Quem decide o que pode ser gravado é o banco (RLS
 * + trigger, ver SQL_FIX_completo_13_09.sql §4c) — esta tela nunca manda
 * role/ativo, mas mesmo que mandasse, o banco ignora pra quem não é admin.
 *
 * ATUALIZAÇÃO (14/09, 3ª rodada): o avatar deixou de ser escolhido
 * indiretamente por um campo "gênero" (2 opções fixas) — agora é uma
 * galeria de 10 avatares e a pessoa escolhe o que quiser diretamente. Ver
 * SQL_PENDENTE_avatar_escolhido.sql (coluna nova + backfill a partir do
 * gênero antigo) e avatarIlustrado.js (a galeria em si).
 */
import { LoadingState } from '../components/LoadingState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { getCurrentUser } from '../services/auth.js';
import { listarFuncionarios, atualizarFuncionario } from '../services/funcionariosClient.js';
import { AVATARES_DISPONIVEIS, avatarIlustradoSvgPorId } from '../components/avatarIlustrado.js';

const LIMITE_BIOGRAFIA = 500;

function iniciaisDe(nome) {
  const partes = (nome || '?').trim().split(/\s+/).filter(Boolean);
  if (partes.length >= 2) return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase();
  return (nome || '?').slice(0, 2).toUpperCase();
}

export async function renderPerfil(container) {
  container.innerHTML = '';

  const usuario = await getCurrentUser();
  if (!usuario) return;

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Meu perfil</h2>
      <p>Seu nome, sua biografia e como você aparece pro resto da equipe.</p>
    </div>
  `;
  container.appendChild(head);

  const card = document.createElement('section');
  card.className = 'card';
  card.appendChild(LoadingState({ rows: 3 }));
  container.appendChild(card);

  let propria;
  try {
    const funcionarios = await listarFuncionarios();
    propria = funcionarios.find((f) => f.id === usuario.id);
    if (!propria) throw new Error('Não encontrei sua linha de cadastro.');
  } catch (err) {
    card.innerHTML = '';
    card.appendChild(ErrorState({ description: err.message || 'Falha ao carregar seu perfil.', onRetry: () => renderPerfil(container) }));
    return;
  }

  // Compatibilidade: quem ainda não escolheu um avatar na galeria nova
  // (avatar_escolhido nulo) mas tem gênero definido do esquema antigo cai
  // no "sucessor" correspondente, só pra não abrir a tela com nada
  // selecionado — a pessoa continua livre pra trocar por qualquer outro.
  const avatarInicial = propria.avatar_escolhido
    || (propria.genero === 'feminino' ? 'a6' : propria.genero === 'masculino' ? 'a1' : null);

  card.innerHTML = `
    <div class="perfil-secao-label">Foto e identidade</div>
    <div class="perfil-avatar-row">
      <div class="perfil-avatar-preview" id="perfilAvatarPreview"></div>
      <div class="field" style="flex:1">
        <label for="pf_foto">URL da foto</label>
        <input id="pf_foto" type="url" placeholder="https://…" value="${propria.foto_url ? escHtml(propria.foto_url) : ''}">
        <p class="field-hint">Tem uma foto sua? Cole o link aqui. Sem foto, vale a pena escolher um avatar ali embaixo — combina mais com você do que as iniciais.</p>
      </div>
    </div>
    <div class="perfil-secao-label">Escolha seu avatar</div>
    <p class="field-hint" style="margin-top:-6px;margin-bottom:var(--space-2)">Usado quando não há foto cadastrada. Clique pra escolher o seu.</p>
    <div class="avatar-galeria" id="perfilAvatarGaleria" role="radiogroup" aria-label="Escolha de avatar ilustrado">
      ${AVATARES_DISPONIVEIS.map((av, i) => `
        <button type="button" class="avatar-opcao${av.id === avatarInicial ? ' is-selecionado' : ''}" role="radio" aria-checked="${av.id === avatarInicial}" aria-label="${av.label}" data-avatar-id="${av.id}" style="animation-delay:${i * 30}ms">
          ${av.svg}
          <span class="avatar-opcao-check" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg></span>
        </button>
      `).join('')}
    </div>
    <div class="perfil-secao-label">Seus dados</div>
    <div class="perfil-form-grid">
      <div class="field"><label for="pf_nome">Nome</label><input id="pf_nome" value="${escHtml(propria.nome || '')}"></div>
      <div class="field"><label for="pf_tempo">Tempo de experiência</label><input id="pf_tempo" placeholder='ex.: "5 anos"' value="${escHtml(propria.tempo_experiencia || '')}"></div>
      <div class="field"><label for="pf_funcoes">Funções / responsabilidades</label><input id="pf_funcoes" placeholder="ex.: Design de identidade visual, redes sociais" value="${escHtml(propria.funcoes || '')}"></div>
      <div class="field perfil-campo-largo">
        <label for="pf_bio">Biografia <span class="field-hint-inline" id="pf_bioContador"></span></label>
        <textarea id="pf_bio" rows="3" maxlength="${LIMITE_BIOGRAFIA}" placeholder="Um pouco sobre você, pra equipe conhecer melhor.">${escHtml(propria.biografia || '')}</textarea>
      </div>
    </div>
    <div class="perfil-acoes">
      <button class="btn btn-ghost" id="pf_cancelar" type="button">Descartar alterações</button>
      <button class="btn btn-primary" id="pf_salvar" type="button">Salvar alterações</button>
    </div>
  `;

  const avatarPreview = card.querySelector('#perfilAvatarPreview');
  const fotoInput = card.querySelector('#pf_foto');
  const galeria = card.querySelector('#perfilAvatarGaleria');
  const bioTextarea = card.querySelector('#pf_bio');
  const bioContador = card.querySelector('#pf_bioContador');
  let avatarSelecionado = avatarInicial;

  function avatarIniciaisEl() {
    const div = document.createElement('div');
    div.className = 'welcome-avatar welcome-avatar-initials';
    div.textContent = iniciaisDe(card.querySelector('#pf_nome').value || propria.nome);
    return div;
  }
  function atualizarPreviewAvatar() {
    const url = fotoInput.value.trim();
    avatarPreview.innerHTML = '';
    if (url) {
      const img = document.createElement('img');
      img.className = 'welcome-avatar';
      img.src = url;
      img.alt = '';
      // Se a URL não carregar (link quebrado, digitado errado), cai pro
      // mesmo fallback de sempre em vez de mostrar um ícone de imagem
      // quebrada — nunca via innerHTML (a URL vem de input do usuário).
      img.addEventListener('error', () => { avatarPreview.replaceChildren(avatarIniciaisEl()); }, { once: true });
      avatarPreview.appendChild(img);
    } else if (avatarSelecionado) {
      const div = document.createElement('div');
      div.className = 'welcome-avatar welcome-avatar-ilustrado';
      div.innerHTML = avatarIlustradoSvgPorId(avatarSelecionado); // SVG fixo do projeto, não é conteúdo do usuário
      avatarPreview.appendChild(div);
    } else {
      avatarPreview.appendChild(avatarIniciaisEl());
    }
  }
  function atualizarContadorBio() {
    bioContador.textContent = `${bioTextarea.value.length}/${LIMITE_BIOGRAFIA}`;
  }
  function selecionarAvatar(id) {
    avatarSelecionado = id;
    galeria.querySelectorAll('.avatar-opcao').forEach((btn) => {
      const selecionado = btn.dataset.avatarId === id;
      btn.classList.toggle('is-selecionado', selecionado);
      btn.setAttribute('aria-checked', String(selecionado));
    });
    // Só troca a prévia pro avatar escolhido se não houver foto — a foto
    // sempre tem prioridade visual, mas a escolha fica salva do mesmo jeito.
    if (!fotoInput.value.trim()) atualizarPreviewAvatar();
  }

  galeria.addEventListener('click', (e) => {
    const btn = e.target.closest('.avatar-opcao');
    if (btn) selecionarAvatar(btn.dataset.avatarId);
  });
  fotoInput.addEventListener('input', atualizarPreviewAvatar);
  bioTextarea.addEventListener('input', atualizarContadorBio);
  atualizarPreviewAvatar();
  atualizarContadorBio();

  card.querySelector('#pf_cancelar').addEventListener('click', () => renderPerfil(container));

  card.querySelector('#pf_salvar').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const nome = card.querySelector('#pf_nome').value.trim();
    if (!nome) { showToast('O nome não pode ficar em branco.', { tone: 'danger' }); return; }
    btn.disabled = true;
    const textoOriginal = btn.textContent;
    btn.textContent = 'Salvando…';
    try {
      await atualizarFuncionario(usuario.id, {
        nome,
        fotoUrl: fotoInput.value.trim(),
        avatarEscolhido: avatarSelecionado || null,
        tempoExperiencia: card.querySelector('#pf_tempo').value.trim(),
        funcoes: card.querySelector('#pf_funcoes').value.trim(),
        biografia: bioTextarea.value.trim(),
      });
      showToast('Perfil atualizado.', { tone: 'ok' });
    } catch (err) {
      showToast(err.message || 'Falha ao salvar o perfil.', { tone: 'danger' });
    } finally {
      btn.disabled = false;
      btn.textContent = textoOriginal;
    }
  });
}

function escHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
