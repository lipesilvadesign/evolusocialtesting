/**
 * Lead Capture Engine — tela de CAPTAÇÃO (30/09).
 *
 *   #/prospeccao/captacao          nova pesquisa · importar planilha · formulários do site · histórico
 *   #/prospeccao/captacao/<jobId>  progresso → resultado → revisão → aprovação
 *
 * Esta tela só EXIBE e PEDE: validação, limites, deduplicação, score e
 * permissão (quem aprova para quem, quem mescla) são do servidor e do banco.
 * Nada vai para o CRM sem clicar em "Aprovar".
 */
import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { confirmDialog } from '../components/ConfirmDialog.js';
import { showToast } from '../components/Toast.js';
import { abrirModal } from '../components/Modal.js';
import { esc, safeUrl } from '../utils/html.js';
import { getCurrentUser } from '../services/auth.js';
import { ehAdmin } from '../services/rbac.js';
import { fetchLead } from '../services/prospeccaoClient.js';
import { listarFuncionarios } from '../services/funcionariosClient.js';
import { criarMiniMapa } from '../components/MiniMapa.js';
import {
  carregarTaxonomia, listarJobs, diagnosticoTecnico, buscarJob, listarItens, iniciarCaptacao, dispararWorker, importarPrevia, importar, geocodificarCidade,
  aprovar, descartar, marcarDuplicado, mesclar, cancelar, revisarInbound, arquivoParaBase64,
} from '../services/captacaoClient.js';

const STATUS_JOB = {
  na_fila: { label: 'Na fila', cls: 'badge-demo' },
  em_andamento: { label: 'Processando', cls: 'badge-info' },
  em_revisao: { label: 'Aguardando revisão', cls: 'badge-warning' },
  concluido: { label: 'Concluída', cls: 'badge-ok' },
  erro: { label: 'Erro', cls: 'badge-danger' },
  cancelado: { label: 'Cancelada', cls: 'badge-demo' },
};
const ETAPAS = { coleta: 'Coletando nas fontes', normalizacao: 'Normalizando', deduplicacao: 'Procurando duplicados', enriquecimento: 'Verificando sites', score: 'Calculando score' };
const ABAS = [
  { status: 'pendente', label: 'Novos', contador: (j) => Math.max(0, (j.qtd_normalizados || 0) - (j.qtd_duplicados || 0) - (j.qtd_possiveis_duplicados || 0) - (j.qtd_descartados || 0) - (j.qtd_bloqueados || 0) - (j.qtd_aprovados || 0)) },
  { status: 'possivel_duplicado', label: 'Possíveis duplicados', contador: (j) => j.qtd_possiveis_duplicados || 0 },
  { status: 'duplicado', label: 'Duplicados', contador: (j) => j.qtd_duplicados || 0 },
  { status: 'bloqueado_optout', label: 'Bloqueados (opt-out)', contador: (j) => j.qtd_bloqueados || 0 },
  { status: 'descartado', label: 'Descartados', contador: (j) => j.qtd_descartados || 0 },
  { status: 'aprovado', label: 'Aprovados', contador: (j) => j.qtd_aprovados || 0 },
];
// Resultado por registro devolvido pela RPC aprovar_captura → texto do resumo
const RESULTADO_APROVACAO = [
  ['aprovado', 'aprovado(s)'], ['ja_aprovado', 'já aprovado(s) antes'], ['duplicado', 'duplicado(s)'],
  ['requer_confirmacao', 'aguardando confirmação de duplicado'], ['bloqueado', 'bloqueado(s) por opt-out'],
  ['sem_permissao', 'sem permissão'], ['nao_encontrado', 'não encontrado(s)'], ['ignorado', 'ignorado(s)'], ['erro', 'com erro'],
];
function resumoAprovacao(r) {
  const partes = RESULTADO_APROVACAO.filter(([k]) => r[k]).map(([k, t]) => `${r[k]} ${t}`);
  return partes.length ? partes.join(' · ') : 'Nenhum registro processado.';
}
const segundos = (ms) => `${(ms / 1000).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} s`;
/** "Busca concluída em 2,8 s · 37 encontradas · 8 duplicadas · 29 disponíveis" (só com telemetria real). */
function resumoBusca(j) {
  const m = j.metricas || {};
  if (!Number.isFinite(m.total_ms)) return '';
  const tempo = Number.isFinite(m.ttfr_ms) && m.ttlc_ms - m.ttfr_ms > 1000
    ? [`Primeiros resultados em ${segundos(m.ttfr_ms)}`, `busca concluída em ${segundos(m.ttlc_ms)}`]
    : [`Busca concluída em ${segundos(m.total_ms)}`];
  const partes = [...tempo, `${m.encontrados ?? j.qtd_encontrados ?? 0} encontradas`];
  if (Number.isFinite(m.fora_da_area) && m.fora_da_area > 0) partes.push(`${m.dentro_da_area} dentro da área`, `${m.fora_da_area} descartadas por localização`);
  partes.push(`${m.duplicados ?? 0} duplicadas`, `${m.disponiveis ?? 0} disponíveis`);
  if (m.bloqueados) partes.push(`${m.bloqueados} bloqueadas (opt-out)`);
  const cache = Object.values(m.providers || {}).reduce((a, p) => a + (p.cache || 0), 0);
  return `${partes.join(' · ')}${cache ? ' · parte do resultado veio do cache (últimas 24 h)' : ''}`;
}

/** Linha por fonte: "Geoapify ✓ 2 resultados" / "OpenStreetMap ↻ pesquisando…" (sem jargão técnico). */
function statusFontes(j) {
  const m = (j.metricas && j.metricas.providers) || {};
  return Object.entries(m).map(([prov, x]) => {
    const nome = PROVIDER_LABEL[prov] || prov;
    if (x.status === 'aguardando' || x.status === 'em_andamento') return { cls: 'andando', txt: `${nome} ↻ pesquisando…` };
    if (x.status === 'timeout') return { cls: 'aviso', txt: `${nome}: não respondeu a tempo. Os resultados das outras fontes já foram mantidos.` };
    if (x.status === 'erro') return { cls: 'aviso', txt: `${nome}: ${mensagemFonte(x.ultimo_erro)} Os resultados das outras fontes já foram mantidos.` };
    const extra = prov !== Object.keys(m)[0] && x.novos !== undefined ? ` (+${x.novos} novos)` : '';
    return { cls: 'ok', txt: `${nome} ✓ ${x.resultados || 0} resultado(s)${extra}${x.status === 'parcial' ? ' — parte das consultas falhou' : ''}` };
  });
}

/** Erro técnico de fonte → frase para quem usa (o detalhe fica no painel técnico). */
function mensagemFonte(msg) {
  const m = String(msg || '');
  if (/429|limite/i.test(m)) return 'a fonte de dados atingiu o limite temporário de consultas.';
  if (/406|401|403|chave/i.test(m)) return 'a fonte de dados recusou a consulta.';
  if (/timeout|a tempo|sem resposta/i.test(m)) return 'a fonte de dados não respondeu a tempo.';
  if (/Geocodifica|não encontrada/i.test(m)) return 'não foi possível localizar a cidade no mapa.';
  return 'a fonte de dados está indisponível no momento.';
}

const ENRIQ_LABEL = { pendente: 'Site na fila de verificação', em_andamento: 'Verificando site…', parcial: 'Site: verificação parcial', erro: 'Site: não foi possível verificar' };

const PROVIDER_LABEL = { geoapify: 'Geoapify', overpass: 'OpenStreetMap', csv: 'Planilha', consultoria: 'Consultoria', site_contato: 'Contato do site', manual: 'Manual' };
const MATCH_LABEL = { cnpj: 'CNPJ igual', external_id: 'mesma origem', dominio_nome: 'mesmo site e nome', dominio: 'mesmo site', telefone: 'mesmo telefone', instagram: 'mesmo Instagram', email: 'mesmo e-mail', nome_cidade: 'nome parecido na mesma cidade', nome_endereco: 'nome e endereço parecidos', mesmo_job: 'marcado manualmente' };
const MOTIVOS_DESCARTE = { fora_do_perfil: 'Fora do perfil', dados_invalidos: 'Dados inválidos', duplicado: 'Duplicado', empresa_fechada: 'Empresa fechada', sem_interesse: 'Sem interesse', outro: 'Outro' };

function faixa(score, tax) {
  const f = (tax.faixasScore || []).find((x) => (score || 0) >= x.min) || { chave: 'aguardar', label: 'Aguardar' };
  const cls = { prioritario: 'badge-ok', prospectar: 'badge-info', nutrir: 'badge-warning', aguardar: 'badge-demo' }[f.chave] || 'badge-demo';
  return { ...f, cls };
}
const lista = (x) => (Array.isArray(x) ? x : []);
const dataHora = (iso) => (iso ? new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');

export async function renderCaptacao(container, jobId) {
  container.innerHTML = '';
  const root = document.createElement('div');
  root.className = 'prospeccao-view captacao-view';
  container.appendChild(root);
  root.appendChild(LoadingState({ rows: 4 }));
  let tax;
  let usuario;
  try {
    [tax, usuario] = await Promise.all([carregarTaxonomia(), getCurrentUser()]);
  } catch (err) {
    root.innerHTML = '';
    root.appendChild(ErrorState({ description: err.message, onRetry: () => renderCaptacao(container, jobId) }));
    return;
  }
  root.innerHTML = '';
  if (jobId) return renderJob(root, jobId, tax, usuario);
  return renderInicio(root, tax, usuario);
}

// ===========================================================================
// Início: nova pesquisa / importar / formulários / histórico
// ===========================================================================
function renderInicio(root, tax, usuario) {
  root.innerHTML = `
    <div class="app-view-head">
      <div>
        <p class="eyebrow"><a href="#/prospeccao">Prospecção</a> › Captação</p>
        <h2>Captação de leads</h2>
        <p>Busque empresas por setor e cidade, importe uma planilha ou revise os formulários do site. Tudo passa pela revisão antes de entrar no CRM.</p>
      </div>
    </div>
    <div class="captacao-abas" role="tablist">
      <button type="button" role="tab" class="btn btn-ghost btn-sm is-active" data-aba="pesquisa" aria-selected="true">Nova pesquisa</button>
      <button type="button" role="tab" class="btn btn-ghost btn-sm" data-aba="importar" aria-selected="false">Importar planilha</button>
      <button type="button" role="tab" class="btn btn-ghost btn-sm" data-aba="inbound" aria-selected="false">Formulários do site</button>
    </div>
    <section class="card" id="captacaoPainel"></section>
    <section class="card" id="captacaoHistorico" style="margin-top:var(--space-5)"></section>
  `;
  const painel = root.querySelector('#captacaoPainel');
  const abas = { pesquisa: () => formPesquisa(painel, tax), importar: () => formImportar(painel, tax), inbound: () => formInbound(painel, usuario) };
  root.querySelectorAll('[data-aba]').forEach((btn) => btn.addEventListener('click', () => {
    root.querySelectorAll('[data-aba]').forEach((b) => { b.classList.toggle('is-active', b === btn); b.setAttribute('aria-selected', String(b === btn)); });
    painel.dispatchEvent(new CustomEvent('captacao:sair')); // limpa o mapa da aba anterior
    abas[btn.dataset.aba]();
  }));
  const inicial = new URLSearchParams(window.location.hash.split('?')[1] || '').get('modo') === 'importar' ? 'importar' : 'pesquisa';
  root.querySelector(`[data-aba="${inicial}"]`).click();
  renderHistorico(root.querySelector('#captacaoHistorico'), tax);
}

function formPesquisa(host, tax) {
  const L = tax.limites;
  const comMapa = Boolean(tax.recursos && tax.recursos.selecaoNoMapa);
  // Estado ÚNICO do local (o mapa só lê/escreve aqui via callback — sem estado paralelo)
  // captureState: ÚNICA fonte de verdade do local da busca (formulário e mapa leem/escrevem aqui)
  const captureState = { modo: 'cidades', area: { latitude: null, longitude: null, raioMetros: 5000, geometry: null, rotulo: null } };
  let mapa = null;
  host.innerHTML = `
    <div class="card-head"><h3>1. O que buscar?</h3></div>
    <div class="content-editor-form">
      <div class="field"><label for="cpSetor">Setor *</label>
        <select id="cpSetor"><option value="">Escolha…</option>${tax.setores.map((s) => `<option value="${esc(s.id)}">${esc(s.id)}</option>`).join('')}</select></div>
      <div class="field"><label for="cpTermo">Termo extra (opcional)</label><input id="cpTermo" maxlength="60" placeholder="Ex.: construtora, clínica odontológica"></div>
      <div class="field"><label for="cpCampanha">Campanha (opcional)</label><input id="cpCampanha" maxlength="60" placeholder="ex.: arquitetos_petrolina_2026" pattern="[a-z0-9_]{1,60}"></div>
    </div>
    <div class="card-head" style="margin-top:var(--space-4)"><h3>2. Onde?</h3></div>
    ${comMapa ? `<div class="captacao-radios" role="radiogroup" aria-label="Como escolher o local">
      <label><input type="radio" name="cpModoLocal" value="cidades" checked> Cidades da região</label>
      <label><input type="radio" name="cpModoLocal" value="mapa"> Ponto no mapa (bairro, rua, raio livre)</label>
    </div>` : ''}
    <div id="cpModoCidades">
      <p class="captacao-dica">Até ${L.cidadesPorJob} cidades por captação.</p>
      <div id="cidadesChecklist" style="display:flex;flex-wrap:wrap">
        ${tax.cidadesRegiao.map((c, i) => `<label class="cidade-chip"><input type="checkbox" name="cpCidade" value="${esc(c)}" ${i === 0 ? 'checked' : ''}> ${esc(c)}</label>`).join('')}
      </div>
      <div class="content-editor-form" style="margin-top:var(--space-3)">
        <div class="field"><label for="cpCidadeOutra">Outra cidade (opcional)</label><input id="cpCidadeOutra" placeholder="Ex.: Remanso, BA"></div>
        <div class="field"><label>Raio</label><div class="captacao-radios">${L.raiosKm.map((r) => `<label><input type="radio" name="cpRaio" value="${r}" ${r === 15 ? 'checked' : ''}> ${r} km</label>`).join('')}</div></div>
      </div>
    </div>
    ${comMapa ? `<div id="cpModoMapa" hidden>
      <div class="captacao-area-linha">
        <div class="field"><label for="cpMapaCidade">Centralizar em</label>
          <select id="cpMapaCidade">${tax.cidadesRegiao.map((c) => `<option value="${esc(c)}">${esc(c)}</option>`).join('')}</select></div>
        <div class="field"><label for="cpMapaRaio">Raio: <strong id="cpMapaRaioTxt">5 km</strong></label>
          <input id="cpMapaRaio" type="range" min="500" max="30000" step="500" value="5000" aria-describedby="cpMapaRaioTxt"></div>
      </div>
      <div class="captacao-radios" role="radiogroup" aria-label="Formato da área">
        <label><input type="radio" name="cpFormaArea" value="circulo" checked> Círculo (centro + raio)</label>
        <label><input type="radio" name="cpFormaArea" value="poligono"> Área personalizada (clique os cantos no mapa)</label>
      </div>
      <div class="captacao-poligono-acoes" id="cpPoligonoAcoes" hidden>
        <span class="captacao-dica" id="cpPoligonoInfo" role="status">Clique no mapa para marcar de 3 a 12 cantos.</span>
        <button type="button" class="btn btn-ghost btn-xs" id="cpPoligonoDesfazer">Desfazer ponto</button>
        <button type="button" class="btn btn-ghost btn-xs" id="cpPoligonoLimpar">Limpar</button>
      </div>
      <div id="cpMapaHost"><p class="captacao-dica" id="cpMapaStatus" role="status">Carregando mapa…</p></div>
      <p class="captacao-aviso" id="cpAreaAviso" hidden role="status">Sua área cobre uma região extensa. A busca pode retornar muitos resultados e levar mais tempo.</p>
      <p class="captacao-dica"><span id="cpMapaDica">Clique no mapa ou arraste o marcador para definir o centro.</span> <span class="captacao-area-coord" id="cpMapaCoord"></span></p>
    </div>` : ''}
    <div class="card-head" style="margin-top:var(--space-4)"><h3>3. Fontes</h3></div>
    <div class="captacao-radios">
      <label><input type="checkbox" name="cpFonte" value="geoapify" checked> Geoapify <span class="captacao-dica">(usa créditos do plano gratuito: 1 crédito a cada 20 resultados)</span></label>
      <label><input type="checkbox" name="cpFonte" value="overpass" checked> OpenStreetMap <span class="captacao-dica">(gratuito)</span></label>
    </div>
    <div style="display:flex;justify-content:flex-end;margin-top:var(--space-4)"><button class="btn btn-primary btn-sm" id="cpIniciar">Iniciar captação</button></div>
  `;
  const chips = () => Array.from(host.querySelectorAll('input[name="cpCidade"]:checked'));
  host.querySelectorAll('input[name="cpCidade"]').forEach((el) => el.addEventListener('change', () => {
    if (chips().length > L.cidadesPorJob) { el.checked = false; showToast(`No máximo ${L.cidadesPorJob} cidades.`, { tone: 'danger' }); }
  }));
  if (comMapa) {
    const blocoCidades = host.querySelector('#cpModoCidades');
    const blocoMapa = host.querySelector('#cpModoMapa');
    const raio = host.querySelector('#cpMapaRaio');
    const raioTxt = host.querySelector('#cpMapaRaioTxt');
    const coordTxt = host.querySelector('#cpMapaCoord');
    const status = host.querySelector('#cpMapaStatus');
    const km = (m) => `${(m / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} km`;
    // Resumo da área para quem usa (sem coordenadas cruas): forma, cantos, raio efetivo, área aproximada.
    const AREA_GRANDE_KM2 = 300; // ~ raio de 10 km; acima disso a busca tende a demorar e trazer muita coisa
    const mostrarCoord = () => {
      if (!Number.isFinite(captureState.area.latitude)) { coordTxt.textContent = ''; return; }
      const a = mapa ? mapa.selecao() : null;
      const km2 = a ? a.area_km2 : (Math.PI * captureState.area.raioMetros ** 2) / 1e6;
      const fmtKm2 = (v) => `${v < 10 ? v.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) : Math.round(v).toLocaleString('pt-BR')} km²`;
      const pol = captureState.area.geometry && a;
      coordTxt.textContent = pol
        ? `Área personalizada · ${a.vertices} pontos · cerca de ${fmtKm2(km2)} · as fontes consultam um raio de ${km(captureState.area.raioMetros)}`
        : `Área pesquisada · círculo de ${km(captureState.area.raioMetros)} de raio · cerca de ${fmtKm2(km2)}`;
      const aviso = host.querySelector('#cpAreaAviso');
      if (aviso) aviso.hidden = !(km2 >= AREA_GRANDE_KM2);
    };
    let tRaio = 0;
    raio.addEventListener('input', () => {
      captureState.area.raioMetros = Number(raio.value);
      raioTxt.textContent = km(captureState.area.raioMetros);
      clearTimeout(tRaio); // debounce do redesenho
      tRaio = setTimeout(() => { if (mapa) mapa.definir({ raio_metros: captureState.area.raioMetros }); mostrarCoord(); }, 120);
    });
    const forma = Array.from(host.querySelectorAll('input[name="cpFormaArea"]'));
    const acoesPol = host.querySelector('#cpPoligonoAcoes');
    const infoPol = host.querySelector('#cpPoligonoInfo');
    function atualizarPoligonoInfo() {
      if (!mapa || captureState.modo !== 'mapa') return;
      const n = mapa.totalPontos();
      infoPol.textContent = n < 3 ? `Clique no mapa para marcar de 3 a 12 cantos (${n} marcado${n === 1 ? '' : 's'}).` : `${n} cantos · área pronta (o raio acompanha a área).`;
    }
    forma.forEach((r) => r.addEventListener('change', () => {
      if (!mapa) return;
      const pol = r.value === 'poligono';
      mapa.definirModo(pol ? 'poligono' : 'circulo');
      acoesPol.hidden = !pol;
      raio.disabled = pol; // no polígono o raio é calculado
      host.querySelector('#cpMapaDica').textContent = pol ? 'Clique no mapa para marcar os cantos da área; só entram empresas dentro dela.' : 'Clique no mapa ou arraste o marcador para definir o centro.';
      if (!pol) { captureState.area.geometry = null; mapa.definir({ raio_metros: Number(raio.value) }, { enquadrar: false }); captureState.area.raioMetros = Number(raio.value); }
      atualizarPoligonoInfo(); mostrarCoord();
    }));
    host.querySelector('#cpPoligonoDesfazer').addEventListener('click', () => { if (mapa) mapa.desfazerPonto(); });
    host.querySelector('#cpPoligonoLimpar').addEventListener('click', () => { if (mapa) mapa.limparPoligono(); });
    async function centralizarEm(cidade) {
      status.hidden = false;
      status.textContent = `Localizando ${cidade}…`;
      try {
        const c = await geocodificarCidade(cidade);
        captureState.area.latitude = Number(c.lat); captureState.area.longitude = Number(c.lon); captureState.area.rotulo = `Mapa: ${cidade}`;
        if (!mapa) {
          status.hidden = true;
          mapa = criarMiniMapa(host.querySelector('#cpMapaHost'), {
            latitude: captureState.area.latitude, longitude: captureState.area.longitude, raio_metros: captureState.area.raioMetros,
            rotulo: 'Mapa para escolher o centro da busca',
            onChange: (a) => {
              captureState.area.latitude = a.latitude; captureState.area.longitude = a.longitude;
              captureState.area.geometry = a.geometry || null;
              if (a.geometry) { captureState.area.raioMetros = a.raio_metros; raio.value = String(Math.min(30000, a.raio_metros)); raioTxt.textContent = km(a.raio_metros); }
              captureState.area.rotulo = a.geometry ? 'Área personalizada no mapa' : 'Área escolhida no mapa';
              atualizarPoligonoInfo(); mostrarCoord();
            },
          });
        } else {
          status.hidden = true;
          mapa.definirModo('circulo'); // nova cidade: recomeça a área
          forma.forEach((x) => { x.checked = x.value === 'circulo'; });
          captureState.area.geometry = null; raio.disabled = false; acoesPol.hidden = true;
          mapa.definir({ latitude: captureState.area.latitude, longitude: captureState.area.longitude, raio_metros: captureState.area.raioMetros });
        }
        mostrarCoord();
      } catch (err) {
        status.textContent = `Não foi possível abrir o mapa: ${err.message} Use "Cidades da região".`;
      }
    }
    host.querySelector('#cpMapaCidade').addEventListener('change', (e) => centralizarEm(e.target.value));
    host.querySelectorAll('input[name="cpModoLocal"]').forEach((r) => r.addEventListener('change', () => {
      captureState.modo = r.value;
      blocoCidades.hidden = captureState.modo !== 'cidades';
      blocoMapa.hidden = captureState.modo !== 'mapa';
      if (captureState.modo === 'mapa' && !mapa) centralizarEm(host.querySelector('#cpMapaCidade').value); // inicialização preguiçosa
    }));
    // limpeza: sair da tela ou trocar de aba destrói o mapa (nunca dois ao mesmo tempo)
    const limpar = () => { if (mapa) { mapa.destruir(); mapa = null; } };
    window.addEventListener('hashchange', limpar, { once: true });
    host.addEventListener('captacao:sair', limpar, { once: true });
  }
  const btn = host.querySelector('#cpIniciar');
  btn.addEventListener('click', async () => {
    const cidades = chips().map((el) => el.value);
    const outra = host.querySelector('#cpCidadeOutra').value.trim();
    if (outra) cidades.push(outra);
    const dados = {
      setor: host.querySelector('#cpSetor').value,
      termo: host.querySelector('#cpTermo').value.trim(),
      cidades,
      raioKm: Number((host.querySelector('input[name="cpRaio"]:checked') || {}).value),
      providers: Array.from(host.querySelectorAll('input[name="cpFonte"]:checked')).map((el) => el.value),
      campanha: host.querySelector('#cpCampanha').value.trim() || undefined,
    };
    if (captureState.modo === 'mapa') {
      if (!Number.isFinite(captureState.area.latitude)) return showToast('Escolha o centro no mapa.', { tone: 'danger' });
      const pol = host.querySelector('input[name="cpFormaArea"][value="poligono"]');
      if (pol && pol.checked && !captureState.area.geometry) return showToast('Marque pelo menos 3 cantos da área no mapa.', { tone: 'danger' });
      const a = captureState.area;
      dados.area = { latitude: a.latitude, longitude: a.longitude, raio_metros: a.raioMetros, rotulo: a.rotulo || undefined, ...(a.geometry ? { geometry: a.geometry } : {}) };
      delete dados.cidades; delete dados.raioKm;
    }
    if (!dados.setor) return showToast('Escolha o setor.', { tone: 'danger' });
    if (captureState.modo !== 'mapa' && !cidades.length) return showToast('Escolha ao menos uma cidade.', { tone: 'danger' });
    if (captureState.modo !== 'mapa' && cidades.length > L.cidadesPorJob) return showToast(`No máximo ${L.cidadesPorJob} cidades.`, { tone: 'danger' });
    if (!dados.providers.length) return showToast('Escolha ao menos uma fonte.', { tone: 'danger' });
    btn.disabled = true;
    btn.textContent = 'Iniciando…';
    try {
      const job = await iniciarCaptacao(dados);
      window.location.hash = `#/prospeccao/captacao/${job.id}`;
    } catch (err) {
      showToast(err.message, { tone: 'danger' });
      btn.disabled = false;
      btn.textContent = 'Iniciar captação';
    }
  });
}

function formImportar(host, tax) {
  host.innerHTML = `
    <div class="card-head"><h3>Importar planilha (CSV)</h3></div>
    <p class="captacao-dica">Aceita CSV separado por vírgula, ponto e vírgula ou tabulação (UTF-8 ou Excel). Até 4 MB / ${tax.limites.registrosPorJob} linhas.
      Arquivo .xlsx: abra no Excel e use <strong>Salvar como → CSV UTF-8</strong>.</p>
    <div class="field"><input type="file" id="impArquivo" accept=".csv,.txt,text/csv"></div>
    <div id="impPrevia"></div>
  `;
  host.querySelector('#impArquivo').addEventListener('change', async (e) => {
    const arquivo = e.target.files[0];
    if (!arquivo) return;
    const previa = host.querySelector('#impPrevia');
    previa.innerHTML = '<p class="captacao-dica">Lendo…</p>';
    try {
      const base64 = await arquivoParaBase64(arquivo);
      const r = await importarPrevia(base64);
      renderPreviaImportacao(previa, r, base64);
    } catch (err) {
      previa.innerHTML = `<p class="captacao-erro">${esc(err.message)}</p>`;
    }
  });
}

const CAMPOS_IMPORTACAO = { empresa: 'Empresa *', telefone: 'Telefone/WhatsApp', email: 'E-mail', site: 'Site', instagram: 'Instagram', cnpj: 'CNPJ', endereco: 'Endereço', cidade: 'Cidade', uf: 'UF', setor: 'Setor', observacoes: 'Observações', id: 'ID do lead (export do painel)' };

function renderPreviaImportacao(host, r, base64) {
  const opcoes = (sel) => `<option value="">— não importar —</option>${r.cabecalhos.map((c, i) => `<option value="${i}" ${sel === i ? 'selected' : ''}>${esc(c || `Coluna ${i + 1}`)}</option>`).join('')}`;
  host.innerHTML = `
    ${(r.avisos || []).map((a) => `<p class="captacao-aviso">${esc(a)}</p>`).join('')}
    <p class="captacao-dica">${r.totalLinhas} linha(s) · separador “${r.delimitador === '\t' ? 'TAB' : esc(r.delimitador)}” · ${esc(r.codificacao)}</p>
    <div class="table-wrap"><table class="app-table"><thead><tr>${r.cabecalhos.map((c) => `<th>${esc(c)}</th>`).join('')}</tr></thead>
      <tbody>${r.amostra.map((l) => `<tr>${r.cabecalhos.map((_, i) => `<td>${esc(l[i] || '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>
    <div class="card-head" style="margin-top:var(--space-4)"><h3>Qual coluna é o quê?</h3></div>
    <div class="content-editor-form">${Object.entries(CAMPOS_IMPORTACAO).map(([campo, label]) => `
      <div class="field"><label for="map_${campo}">${label}</label><select id="map_${campo}" data-map="${campo}">${opcoes(r.mapeamentoSugerido[campo])}</select></div>`).join('')}
    </div>
    <div class="content-editor-form">
      <div class="field"><label for="impModo">O que fazer</label>
        <select id="impModo">
          <option value="criar">Criar novos (vão para revisão antes do CRM)</option>
          <option value="mesclar">Completar leads existentes (só campos vazios)</option>
          <option value="atualizar">Atualizar leads existentes (substitui valores)</option>
        </select></div>
      <div class="field"><label for="impCampanha">Campanha (opcional)</label><input id="impCampanha" maxlength="60" placeholder="ex.: feira_agro_2026"></div>
    </div>
    <div id="impResultado"></div>
    <div style="display:flex;justify-content:flex-end;gap:var(--space-2);margin-top:var(--space-3)"><button class="btn btn-primary btn-sm" id="impEnviar">Continuar</button></div>
  `;
  const btn = host.querySelector('#impEnviar');
  btn.addEventListener('click', async () => {
    const mapeamento = {};
    host.querySelectorAll('[data-map]').forEach((s) => { if (s.value !== '') mapeamento[s.dataset.map] = Number(s.value); });
    const modo = host.querySelector('#impModo').value;
    const dados = { arquivoBase64: base64, delimitador: r.delimitador, mapeamento, modo, campanha: host.querySelector('#impCampanha').value.trim() || undefined };
    btn.disabled = true;
    try {
      const res = await importar(dados);
      if (modo === 'criar') {
        showToast(`${res.resumo.gravados} registro(s) prontos para revisão.`, { tone: 'ok' });
        window.location.hash = `#/prospeccao/captacao/${res.job.id}`;
        return;
      }
      const p = res.previa;
      const out = host.querySelector('#impResultado');
      out.innerHTML = `
        <p><strong>${p.totalAlteracoes}</strong> lead(s) seriam alterados · ${p.semAlteracao} sem mudança · ${p.semCorrespondencia} linha(s) sem lead correspondente${p.limitado ? ' · (limite de 300 por vez)' : ''}</p>
        <ul class="captacao-lista-mudancas">${p.alteracoes.map((a) => `<li><strong>${esc(a.empresa)}</strong>: ${Object.entries(a.campos).map(([c, [antes, depois]]) => `${esc(c)}: “${esc(antes || 'vazio')}” → “${esc(depois)}”`).join('; ')}</li>`).join('')}</ul>
        ${p.totalAlteracoes ? '<button class="btn btn-primary btn-sm" id="impAplicar">Aplicar alterações</button>' : ''}
      `;
      const aplicar = out.querySelector('#impAplicar');
      if (aplicar) aplicar.addEventListener('click', async () => {
        aplicar.disabled = true;
        try {
          const fim = await importar({ ...dados, aplicar: true });
          showToast(`${fim.atualizados} lead(s) atualizados${fim.falhas.length ? `, ${fim.falhas.length} falha(s)` : ''}.`, { tone: fim.falhas.length ? 'danger' : 'ok' });
          out.innerHTML = fim.falhas.length ? `<ul>${fim.falhas.map((f) => `<li>${esc(f.empresa)}: ${esc(f.erro)}</li>`).join('')}</ul>` : '<p>Pronto.</p>';
        } catch (err) { showToast(err.message, { tone: 'danger' }); aplicar.disabled = false; }
      });
    } catch (err) {
      showToast(err.message, { tone: 'danger' });
    } finally {
      btn.disabled = false;
    }
  });
}

function formInbound(host, usuario) {
  host.innerHTML = `
    <div class="card-head"><h3>Formulários do site</h3></div>
    <p class="captacao-dica">Traz para revisão os contatos do formulário “Vamos conversar”${ehAdmin(usuario) ? ' e da consultoria gratuita' : ''} que ainda não viraram lead.
      Também dá para converter um por um nas telas <a href="#/contatos-site">Contatos do site</a>${ehAdmin(usuario) ? ' e <a href="#/consultorias">Consultas</a>' : ''}.</p>
    <p class="captacao-aviso">VALIDAÇÃO JURÍDICA NECESSÁRIA: usar um contato do formulário para prospecção ativa precisa estar coberto pela política de privacidade (finalidade).</p>
    <button class="btn btn-primary btn-sm" id="inbRevisar">Revisar formulários pendentes</button>
  `;
  const btn = host.querySelector('#inbRevisar');
  btn.addEventListener('click', async () => {
    btn.disabled = true;
    try {
      const r = await revisarInbound();
      if (!r.job) { showToast(r.mensagem || 'Nada pendente.', { tone: 'ok' }); btn.disabled = false; return; }
      window.location.hash = `#/prospeccao/captacao/${r.job.id}`;
    } catch (err) { showToast(err.message, { tone: 'danger' }); btn.disabled = false; }
  });
}

async function renderHistorico(host, tax) {
  host.innerHTML = '<div class="card-head"><h3>Captações recentes</h3></div>';
  host.appendChild(LoadingState({ rows: 3 }));
  try {
    const jobs = await listarJobs();
    host.querySelector('.loading-state, [class*="loading"]')?.remove();
    host.innerHTML = '<div class="card-head"><h3>Captações recentes</h3></div>';
    if (!jobs.length) { host.appendChild(EmptyState({ title: 'Nenhuma captação ainda', description: 'Comece por uma nova pesquisa acima.' })); return; }
    const wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    wrap.innerHTML = `<table class="app-table"><thead><tr><th>Quando</th><th>O quê</th><th>Status</th><th>Encontrados</th><th>Aprovados</th></tr></thead><tbody>
      ${jobs.map((j) => {
        const st = STATUS_JOB[j.status] || STATUS_JOB.concluido;
        const oque = j.tipo === 'importacao' ? 'Planilha' : j.tipo === 'inbound' ? 'Formulários do site' : `${esc(j.ramo || '')}${(j.cidades || []).length ? ` · ${esc(j.cidades.join(', '))}` : ''}`;
        return `<tr><td>${dataHora(j.created_at)}</td><td><a class="app-table-link" href="#/prospeccao/captacao/${esc(j.id)}">${oque}</a></td>
          <td><span class="badge ${st.cls}">${st.label}</span></td><td>${j.qtd_encontrados ?? 0}</td><td>${j.qtd_aprovados ?? 0}</td></tr>`;
      }).join('')}</tbody></table>`;
    host.appendChild(wrap);
  } catch (err) {
    host.innerHTML = '<div class="card-head"><h3>Captações recentes</h3></div>';
    host.appendChild(ErrorState({ description: err.message, onRetry: () => renderHistorico(host, tax) }));
  }
}

// ===========================================================================
// Job: progresso → resultado → revisão
// ===========================================================================
async function renderJob(root, jobId, tax, usuario) {
  const souAdmin = ehAdmin(usuario);
  root.innerHTML = `
    <div class="app-view-head"><div>
      <p class="eyebrow"><a href="#/prospeccao">Prospecção</a> › <a href="#/prospeccao/captacao">Captação</a></p>
      <h2 id="jobTitulo">Captação</h2><p id="jobSub"></p></div></div>
    <section class="card" id="jobProgresso"></section>
    <section class="card" id="jobResultado" style="margin-top:var(--space-5)"></section>
  `;
  const estado = { job: null, aba: 'pendente', pagina: 1, selecionados: new Set(), itens: [], total: 0, inicioPolling: Date.now(), timer: null };

  function parar() { if (estado.timer) clearTimeout(estado.timer); estado.timer = null; }
  window.addEventListener('hashchange', parar, { once: true });

  /** Depois de uma decisão (aprovar/descartar/mesclar): relê o job e a lista. */
  function recarregar() { estado.faseListada = null; parar(); atualizarJob(); }

  async function atualizarJob() {
    try {
      estado.job = await buscarJob(jobId);
    } catch (err) {
      root.querySelector('#jobProgresso').innerHTML = '';
      root.querySelector('#jobProgresso').appendChild(ErrorState({ description: err.message, onRetry: atualizarJob }));
      return;
    }
    renderCabecalho();
    const ativo = ['na_fila', 'em_andamento'].includes(estado.job.status);
    const segundoPlano = ['coleta', 'deduplicacao', 'enriquecimento'].includes(estado.job.etapa);
    const decorrido = Date.now() - estado.inicioPolling;
    if (ativo || segundoPlano) {
      const rapido = (ativo || estado.job.etapa === 'coleta') && decorrido < 60000;
      if (decorrido < 15 * 60 * 1000) estado.timer = setTimeout(atualizarJob, rapido ? 2000 : 4000);
      else root.querySelector('#jobProgresso').insertAdjacentHTML('beforeend', '<p class="captacao-aviso">Sem conclusão após 15 minutos. O processamento continua em segundo plano; você pode sair desta tela e voltar depois.</p>');
    }
    // Resultados progressivos: a lista aparece com o 1º lote e é atualizada quando chegam mais
    // (se a pessoa estiver com itens selecionados, NÃO recarrega por baixo dela: mostra um aviso).
    const contagem = `${estado.job.qtd_encontrados || 0}|${estado.job.qtd_normalizados || 0}|${estado.job.etapa || ''}|${estado.job.qtd_enriquecidos || 0}`;
    if (ativo) return;
    if (estado.faseListada === undefined || estado.faseListada === null) { estado.faseListada = contagem; carregarItens(); return; }
    if (contagem !== estado.faseListada) {
      estado.faseListada = contagem;
      if (estado.selecionados.size) {
        const host = root.querySelector('#jobResultado');
        if (host && !host.querySelector('#novosResultados')) {
          host.insertAdjacentHTML('afterbegin', '<div class="captacao-aviso" id="novosResultados" role="status">Mais resultados chegaram. <button type="button" class="btn btn-ghost btn-xs" id="novosResultadosBtn">Atualizar lista</button></div>');
          host.querySelector('#novosResultadosBtn').addEventListener('click', () => carregarItens());
        }
      } else carregarItens();
    }
  }

  function renderCabecalho() {
    const j = estado.job;
    const st = STATUS_JOB[j.status] || STATUS_JOB.concluido;
    const p = j.parametros || {};
    root.querySelector('#jobTitulo').textContent = j.tipo === 'importacao' ? 'Importação de planilha' : j.tipo === 'inbound' ? 'Formulários do site' : `${p.setor || j.ramo || 'Captação'}${p.termo ? ` · ${p.termo}` : ''}`;
    const raioTxt = p.area && p.area.raio_metros ? `${(p.area.raio_metros / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} km` : p.raioKm ? `${p.raioKm} km` : '';
    root.querySelector('#jobSub').textContent = `${(j.cidades || []).join(', ')}${raioTxt ? ` · raio ${raioTxt}` : ''} · ${(j.providers || []).map((x) => PROVIDER_LABEL[x] || x).join(' + ')} · ${dataHora(j.created_at)}${j.campanha ? ` · campanha ${j.campanha}` : ''}`;
    const prog = lista(j.progresso);
    const total = (j.cidades || []).length || 1;
    const ativo = ['na_fila', 'em_andamento'].includes(j.status);
    const parado = j.status === 'na_fila' && Date.now() - new Date(j.created_at).getTime() > 60000;
    root.querySelector('#jobProgresso').innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:var(--space-3);flex-wrap:wrap">
        <div><span class="badge ${st.cls}">${st.label}</span> ${j.etapa ? `<span class="captacao-dica" role="status">${j.etapa === 'enriquecimento' && !ativo ? 'Verificando sites em segundo plano — você já pode revisar e aprovar' : j.etapa === 'coleta' && !ativo ? 'Primeiros resultados prontos — mais resultados chegando' : j.etapa === 'coleta' ? 'Encontrando empresas' : ETAPAS[j.etapa] || j.etapa}…</span>` : ''}</div>
        <div style="display:flex;gap:var(--space-2)">
          ${parado ? '<button class="btn btn-ghost btn-sm" id="jobProcessar">Processar</button>' : ''}
          ${ativo ? '<button class="btn btn-ghost btn-sm" id="jobCancelar">Cancelar</button>' : ''}
        </div>
      </div>
      ${j.tipo === 'pesquisa' ? `
      <div class="progresso-barra" style="margin-top:var(--space-3)" role="progressbar" aria-valuemin="0" aria-valuemax="${total}" aria-valuenow="${prog.length}">
        <div class="progresso-barra-preenchimento" style="width:${Math.round((prog.length / total) * 100)}%"></div></div>
      <ul class="progresso-lista" style="list-style:none;margin-top:var(--space-2)">${prog.map((e) => `<li>${e.ok ? '✓' : '⚠'} ${esc(e.cidade)} — ${e.encontrados} encontrado(s) ${Object.entries(e.fontes || {}).map(([f, n]) => `<span class="captacao-dica">${PROVIDER_LABEL[f] || esc(f)}: ${esc(typeof n === 'string' && /erro/.test(n) ? 'falhou' : n)}</span>`).join(' ')}${e.erro ? ` <span class="captacao-erro">${esc(e.erro)}</span>` : ''}</li>`).join('')}</ul>` : ''}
      ${j.tipo === 'pesquisa' && statusFontes(j).length ? `<ul class="captacao-fontes" aria-live="polite">${statusFontes(j).map((f) => `<li class="captacao-fonte-${f.cls}">${esc(f.txt)}</li>`).join('')}</ul>` : ''}
      ${!ativo && j.etapa !== 'coleta' && resumoBusca(j) ? `<p class="captacao-resumo-busca" role="status">${esc(resumoBusca(j))}</p>` : ''}
      ${j.mensagem_erro ? `<p class="captacao-erro">${esc(j.mensagem_erro)}</p>` : ''}
      ${lista(j.erros).length ? `<details><summary class="captacao-dica">${lista(j.erros).length} aviso(s) das fontes</summary><ul>${lista(j.erros).slice(0, 30).map((e) => `<li class="captacao-dica">${esc(e.cidade || '')} ${esc(PROVIDER_LABEL[e.provider] || e.provider || '')}: ${esc(e.provider === 'enriquecimento' ? 'a verificação de sites não terminou.' : mensagemFonte(e.mensagem))}</li>`).join('')}</ul>${souAdmin ? `<p class="captacao-dica"><a href="#/prospeccao/captacao/diagnostico">Detalhes técnicos</a></p>` : ''}</details>` : ''}
      ${!ativo ? `<div class="captacao-contadores">
        <div><strong>${j.qtd_encontrados || 0}</strong><span>Encontrados</span></div>
        ${ABAS.map((a) => `<div><strong>${a.contador(j)}</strong><span>${a.label}</span></div>`).join('')}
      </div>` : ''}
    `;
    const c = root.querySelector('#jobCancelar');
    if (c) c.addEventListener('click', async () => {
      if (!(await confirmDialog({ title: 'Cancelar captação?', description: 'O que já foi coletado até agora é descartado desta captação.', confirmLabel: 'Cancelar captação' }))) return;
      try { await cancelar(jobId); parar(); atualizarJob(); } catch (err) { showToast(err.message, { tone: 'danger' }); }
    });
    const pr = root.querySelector('#jobProcessar');
    if (pr) pr.addEventListener('click', async () => { pr.disabled = true; await dispararWorker(jobId); showToast('Processamento disparado.', { tone: 'ok' }); });
  }

  async function carregarItens() {
    const host = root.querySelector('#jobResultado');
    host.innerHTML = '';
    host.appendChild(LoadingState({ rows: 4 }));
    try {
      const r = await listarItens(jobId, { status: estado.aba, pagina: estado.pagina });
      estado.itens = r.itens;
      estado.total = r.total || 0;
      estado.selecionados.clear();
      renderItens();
    } catch (err) {
      host.innerHTML = '';
      host.appendChild(ErrorState({ description: err.message, onRetry: carregarItens }));
    }
  }

  function renderItens() {
    const host = root.querySelector('#jobResultado');
    const j = estado.job;
    const decidivel = ['pendente', 'possivel_duplicado', 'duplicado'].includes(estado.aba);
    host.innerHTML = `
      <div class="captacao-abas" role="tablist">${ABAS.map((a) => `<button type="button" role="tab" class="btn btn-ghost btn-sm ${a.status === estado.aba ? 'is-active' : ''}" data-aba="${a.status}" aria-selected="${a.status === estado.aba}">${a.label} (${a.contador(j)})</button>`).join('')}</div>
      ${decidivel && estado.itens.length ? `
      <div class="content-toolbar captacao-acoes">
        <label style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="selTodos"> Selecionar página</label>
        <span id="selCount" class="captacao-dica">0 selecionado(s)</span>
        ${estado.aba !== 'duplicado' ? '<button class="btn btn-primary btn-sm" data-acao="aprovar" disabled>Aprovar selecionados</button>' : ''}
        <button class="btn btn-ghost btn-sm" data-acao="descartar" disabled>Descartar</button>
      </div>` : ''}
      <div id="listaItens"></div>
      <div class="captacao-paginacao"></div>
    `;
    host.querySelectorAll('[data-aba]').forEach((b) => b.addEventListener('click', () => { estado.aba = b.dataset.aba; estado.pagina = 1; carregarItens(); }));
    const lista = host.querySelector('#listaItens');
    if (!estado.itens.length) {
      lista.appendChild(EmptyState({ title: 'Nada nesta aba', description: estado.aba === 'pendente' && j.qtd_encontrados === 0 ? 'Nenhuma empresa encontrada. Tente um raio maior, outra fonte ou outro setor.' : 'Nenhum registro com este status.' }));
    }
    estado.itens.forEach((it) => lista.appendChild(cartaoItem(it, decidivel)));
    const paginas = Math.max(1, Math.ceil(estado.total / 50));
    host.querySelector('.captacao-paginacao').innerHTML = paginas > 1 ? `
      <button class="btn btn-ghost btn-sm" data-pag="-1" ${estado.pagina <= 1 ? 'disabled' : ''}>Anterior</button>
      <span class="captacao-dica">Página ${estado.pagina} de ${paginas}</span>
      <button class="btn btn-ghost btn-sm" data-pag="1" ${estado.pagina >= paginas ? 'disabled' : ''}>Próxima</button>` : '';
    host.querySelectorAll('[data-pag]').forEach((b) => b.addEventListener('click', () => { estado.pagina += Number(b.dataset.pag); carregarItens(); }));
    const selTodos = host.querySelector('#selTodos');
    if (selTodos) selTodos.addEventListener('change', () => {
      host.querySelectorAll('[data-sel]').forEach((cb) => { cb.checked = selTodos.checked; if (selTodos.checked) estado.selecionados.add(cb.dataset.sel); else estado.selecionados.delete(cb.dataset.sel); });
      atualizarSelecao();
    });
    host.querySelectorAll('[data-acao]').forEach((b) => b.addEventListener('click', () => (b.dataset.acao === 'aprovar' ? acaoAprovar() : acaoDescartar())));
  }

  function atualizarSelecao() {
    const host = root.querySelector('#jobResultado');
    const n = estado.selecionados.size;
    const cnt = host.querySelector('#selCount');
    if (cnt) cnt.textContent = `${n} selecionado(s)`;
    host.querySelectorAll('[data-acao]').forEach((b) => { b.disabled = n === 0; });
  }

  function cartaoItem(it, decidivel) {
    const f = faixa(it.score_previsto, tax);
    const el = document.createElement('article');
    el.className = 'captacao-item';
    const sinais = lista(it.sinais).map((s) => `<span class="badge ${s.confianca === 'alta' ? 'badge-warning' : 'badge-demo'}" title="${esc(s.evidencia)} (confiança ${esc(s.confianca)})">${esc((tax.oportunidades[s.tipo] || {}).label || s.tipo)}</span>`).join(' ');
    const urlSegura = safeUrl(it.site);
    el.innerHTML = `
      ${decidivel ? `<input type="checkbox" data-sel="${esc(it.id)}" aria-label="Selecionar ${esc(it.empresa)}">` : '<span></span>'}
      <div class="captacao-item-corpo">
        <div class="captacao-item-topo">
          <strong>${esc(it.empresa)}</strong>
          <span class="badge ${f.cls}" title="${esc(lista(it.score_motivos).map((m) => `${m.label} (+${m.pontos})`).join('; ') || 'Sem pontos')}">Score ${it.score_previsto ?? 0} · ${esc(f.label)}</span>
        </div>
        <div class="captacao-dica">${esc([it.cidade, it.uf].filter(Boolean).join(', ') || 'Cidade não informada')}${it.telefone ? ` · ${esc(it.telefone)}` : ''}${it.email ? ` · ${esc(it.email)}` : ''}${urlSegura ? ` · <a href="${esc(urlSegura)}" target="_blank" rel="noopener noreferrer">${esc(it.dominio || it.site)}</a>` : ''}${it.instagram ? ` · ${esc(it.instagram)}` : ''}</div>
        <div class="captacao-dica">${esc(PROVIDER_LABEL[it.provider] || it.provider)}${it.setor ? ` · ${esc(it.setor)}` : ''}${it.subsetor ? ` / ${esc(it.subsetor)}` : ''}${it.categoria_origem ? ` · <span title="Categoria na origem">${esc(it.categoria_origem)}</span>` : ''}</div>
        ${sinais ? `<div class="captacao-sinais">${sinais}</div>` : ''}
        ${ENRIQ_LABEL[it.enriquecimento_status] ? `<div class="captacao-dica">${ENRIQ_LABEL[it.enriquecimento_status]}${it.enriquecimento && it.enriquecimento.site && it.enriquecimento.site.titulo ? ` · “${esc(it.enriquecimento.site.titulo)}”` : ''}</div>` : it.enriquecimento && it.enriquecimento.site && it.enriquecimento.site.titulo ? `<div class="captacao-dica">Site: “${esc(it.enriquecimento.site.titulo)}”</div>` : ''}
        ${lista(it.avisos).length ? `<div class="captacao-aviso">${lista(it.avisos).map(esc).join(' · ')}</div>` : ''}
        ${it.match_lead_id ? `<div class="captacao-match">${it.status === 'duplicado' ? 'Duplicado de' : 'Possível duplicado de'} <strong>${esc(it.match_empresa || 'lead existente')}</strong> (${esc(MATCH_LABEL[it.match_tipo] || it.match_tipo)}${it.match_confianca ? `, ${it.match_confianca}%` : ''})
          <button type="button" class="btn btn-ghost btn-xs" data-comparar>Comparar</button></div>` : ''}
        ${it.motivo_descarte ? `<div class="captacao-dica">Descartado: ${esc(MOTIVOS_DESCARTE[it.motivo_descarte] || it.motivo_descarte)}</div>` : ''}
        ${it.lead_id ? `<div class="captacao-dica">No CRM desde ${dataHora(it.decidido_em)}</div>` : ''}
      </div>
    `;
    const cb = el.querySelector('[data-sel]');
    if (cb) cb.addEventListener('change', () => { if (cb.checked) estado.selecionados.add(it.id); else estado.selecionados.delete(it.id); atualizarSelecao(); });
    const cmp = el.querySelector('[data-comparar]');
    if (cmp) cmp.addEventListener('click', () => abrirComparacao(it));
    return el;
  }

  async function abrirComparacao(it) {
    const { box, close } = abrirModal({ titulo: 'Comparar com o lead existente', html: '<div data-cmp><p class="captacao-dica">Carregando…</p></div>', host: root, maxWidth: '720px' });
    let lead = null;
    try { lead = await fetchLead(it.match_lead_id); } catch { /* sem acesso ao lead de outra pessoa */ }
    const campos = [['empresa', 'Empresa'], ['telefone', 'Telefone'], ['email', 'E-mail'], ['site', 'Site'], ['instagram', 'Instagram'], ['cnpj', 'CNPJ'], ['endereco', 'Endereço'], ['cidade', 'Cidade'], ['setor', 'Setor']];
    if (!box.isConnected) return;
    box.querySelector('[data-cmp]').innerHTML = `
      ${lead ? `<div class="table-wrap"><table class="app-table"><thead><tr><th></th><th>Nesta captação</th><th>No CRM${lead.arquivado_em ? ' (arquivado)' : ''}</th></tr></thead><tbody>
        ${campos.map(([c, l]) => `<tr><th>${l}</th><td>${esc(it[c] || '—')}</td><td>${esc(lead[c] || '—')}</td></tr>`).join('')}</tbody></table></div>`
        : `<p>O lead encontrado é <strong>${esc(it.match_empresa || '')}</strong>, de outro responsável — só um admin vê os detalhes.</p>`}
      <div style="display:flex;gap:var(--space-2);flex-wrap:wrap;justify-content:flex-end;margin-top:var(--space-4)">
        ${it.status !== 'duplicado' ? '<button class="btn btn-ghost btn-sm" data-c="dup">É o mesmo (marcar duplicado)</button>' : ''}
        ${lead ? '<button class="btn btn-ghost btn-sm" data-c="mesclar" title="Completa só os campos vazios do lead">Mesclar no lead existente</button>' : ''}
        ${it.status === 'possivel_duplicado' ? '<button class="btn btn-primary btn-sm" data-c="novo">São diferentes (aprovar como novo)</button>' : ''}
        <button class="btn btn-ghost btn-sm" data-c="fechar">Fechar</button>
      </div>`;
    box.querySelector('[data-c="fechar"]').addEventListener('click', close);
    const exec = async (fn, msg) => { try { await fn(); showToast(msg, { tone: 'ok' }); close(); recarregar(); } catch (err) { showToast(err.message, { tone: 'danger' }); } };
    box.querySelector('[data-c="dup"]')?.addEventListener('click', () => exec(() => marcarDuplicado(it.id, it.match_lead_id), 'Marcado como duplicado.'));
    box.querySelector('[data-c="mesclar"]')?.addEventListener('click', () => exec(() => mesclar(it.id, it.match_lead_id), 'Dados mesclados no lead existente.'));
    box.querySelector('[data-c="novo"]')?.addEventListener('click', () => { close(); acaoAprovar([it.id], true); });
  }

  async function acaoAprovar(idsFixos, forcarNovo = false) {
    const ids = idsFixos || Array.from(estado.selecionados);
    if (!ids.length) return;
    const possiveis = estado.itens.filter((i) => ids.includes(i.id) && i.status === 'possivel_duplicado').length;
    let funcionarios = [];
    if (souAdmin) { try { funcionarios = (await listarFuncionarios()).filter((f) => f.ativo && ['admin', 'prospeccao'].includes(f.role)); } catch { /* segue só com "eu" */ } }
    const { box, close } = abrirModal({ host: root, maxWidth: '520px', html: `
      <h3 style="font-size:1.05rem;margin-bottom:var(--space-2)">Aprovar ${ids.length} registro(s) para o CRM</h3>
      ${possiveis && !forcarNovo ? `<label class="captacao-aviso" style="display:flex;gap:6px"><input type="checkbox" id="apForcar"> ${possiveis} deles parecem duplicados. Confirmo que são empresas diferentes.</label>` : ''}
      <div class="content-editor-form">
        <div class="field"><label for="apResp">Responsável</label>
          <select id="apResp" ${souAdmin ? '' : 'disabled'}><option value="${esc(usuario.id)}">Eu (${esc(usuario.nome || usuario.email || '')})</option>
          ${funcionarios.filter((f) => f.id !== usuario.id).map((f) => `<option value="${esc(f.id)}">${esc(f.nome || f.email)}</option>`).join('')}</select>
          ${souAdmin ? '' : '<small class="captacao-dica">Prospecção aprova para si mesma.</small>'}</div>
        <div class="field"><label for="apPrio">Prioridade</label><select id="apPrio"><option value="alta">Alta</option><option value="media" selected>Média</option><option value="baixa">Baixa</option></select></div>
        <div class="field"><label for="apCamp">Campanha</label><input id="apCamp" maxlength="60" value="${esc(estado.job.campanha || '')}"></div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:var(--space-2);margin-top:var(--space-4)">
        <button class="btn btn-ghost btn-sm" id="apCancelar">Cancelar</button><button class="btn btn-primary btn-sm" id="apOk">Aprovar</button></div>` });
    box.querySelector('#apCancelar').addEventListener('click', close);
    const ok = box.querySelector('#apOk');
    box.insertAdjacentHTML('beforeend', '<div class="captacao-progresso-aprovacao" id="apStatus" role="status" aria-live="polite"></div>');
    const statusEl = box.querySelector('#apStatus');
    const cancelarBtn = box.querySelector('#apCancelar');
    let enviando = false;
    ok.addEventListener('click', async () => {
      if (enviando) return; // duplo clique: a RPC também é idempotente (ja_aprovado), mas nem chega a ir
      enviando = true;
      ok.disabled = true; cancelarBtn.disabled = true;
      statusEl.className = 'captacao-progresso-aprovacao captacao-dica';
      statusEl.textContent = `Aprovando ${ids.length} empresa(s)…`;
      try {
        const r = await aprovar({
          ids, responsavelId: box.querySelector('#apResp').value, prioridade: box.querySelector('#apPrio').value,
          campanha: box.querySelector('#apCamp').value.trim() || undefined, forcarNovo: forcarNovo || Boolean(box.querySelector('#apForcar')?.checked),
        });
        const texto = resumoAprovacao(r.resumo || {});
        const falhas = (r.resultado || []).filter((x) => x.resultado === 'erro');
        if (falhas.length) {
          // Parcial: o que deu certo JÁ está no CRM; mostra o que falhou sem esconder o sucesso
          const nomes = new Map(estado.itens.map((it) => [it.id, it.empresa]));
          statusEl.className = 'captacao-progresso-aprovacao captacao-aviso';
          statusEl.innerHTML = `<strong>${esc(texto)}</strong><ul style="margin:6px 0 0 18px">${falhas.slice(0, 10).map((f) => `<li>${esc(nomes.get(f.captura_id) || 'Registro')}: ${esc(f.mensagem || 'falha ao gravar')}</li>`).join('')}</ul>`;
          cancelarBtn.disabled = false; cancelarBtn.textContent = 'Fechar';
          cancelarBtn.addEventListener('click', recarregar, { once: true });
          ok.hidden = true;
          return;
        }
        showToast(texto, { tone: (r.resumo || {}).aprovado ? 'ok' : 'info' });
        close();
        recarregar();
      } catch (err) {
        // O servidor já devolve "A aprovação não foi concluída. Motivo: …"; o detalhe técnico fica só no console.
        console.error('[captacao] aprovação', err);
        const msg = err && err.message && err.message !== 'Erro desconhecido' ? err.message : 'A aprovação não foi concluída. Motivo: sem resposta do servidor. Nenhum lead foi criado; tente de novo.';
        statusEl.className = 'captacao-progresso-aprovacao captacao-erro';
        statusEl.textContent = /não foi concluída/.test(msg) ? msg : `A aprovação não foi concluída. Motivo: ${msg}`;
        ok.disabled = false; cancelarBtn.disabled = false; enviando = false;
      }
    });
  }

  async function acaoDescartar() {
    const ids = Array.from(estado.selecionados);
    const { box, close } = abrirModal({ host: root, maxWidth: '440px', html: `
      <h3 style="font-size:1.05rem;margin-bottom:var(--space-2)">Descartar ${ids.length} registro(s)</h3>
      <div class="field"><label for="dsMotivo">Motivo</label><select id="dsMotivo">${Object.entries(MOTIVOS_DESCARTE).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
      <div style="display:flex;justify-content:flex-end;gap:var(--space-2);margin-top:var(--space-4)"><button class="btn btn-ghost btn-sm" id="dsCancelar">Cancelar</button><button class="btn btn-danger btn-sm" id="dsOk">Descartar</button></div>` });
    box.querySelector('#dsCancelar').addEventListener('click', close);
    const ok = box.querySelector('#dsOk');
    ok.addEventListener('click', async () => {
      ok.disabled = true;
      try { const r = await descartar(ids, box.querySelector('#dsMotivo').value); showToast(`${r.descartados} descartado(s).`, { tone: 'ok' }); close(); recarregar(); } catch (err) { showToast(err.message, { tone: 'danger' }); ok.disabled = false; }
    });
  }

  root.querySelector('#jobProgresso').appendChild(LoadingState({ rows: 2 }));
  atualizarJob();
}

// ===========================================================================
// Painel técnico da captação (Fase 3) — só admin. Telemetria REAL dos jobs.
// ===========================================================================
export async function renderCaptacaoDiagnostico(container) {
  container.innerHTML = '';
  const root = document.createElement('div');
  root.className = 'prospeccao-view captacao-view';
  container.appendChild(root);
  root.innerHTML = `<div class="app-view-head"><div>
      <p class="eyebrow"><a href="#/prospeccao">Prospecção</a> › <a href="#/prospeccao/captacao">Captação</a> › Diagnóstico técnico</p>
      <h2>Diagnóstico técnico da captação</h2>
      <p>Tempos, fontes e erros das últimas 30 buscas. Só para administração — nada disto aparece para o cliente.</p></div></div>
    <section class="card" id="dgResumo"></section>
    <section class="card" id="dgSaude" style="margin-top:var(--space-5)"></section>
    <section class="card" id="dgJobs" style="margin-top:var(--space-5)"></section>`;
  root.querySelector('#dgResumo').appendChild(LoadingState({ rows: 3 }));
  let d;
  try { d = await diagnosticoTecnico(); } catch (err) {
    root.querySelector('#dgResumo').innerHTML = '';
    root.querySelector('#dgResumo').appendChild(ErrorState({ description: err.message, onRetry: () => renderCaptacaoDiagnostico(container) }));
    return;
  }
  const s = (ms) => (Number.isFinite(ms) ? segundos(ms) : '—');
  const a = d.agregado || {};
  root.querySelector('#dgResumo').innerHTML = `<div class="card-head"><h3>Resumo (${a.jobs_medidos || 0} busca(s) com telemetria)</h3></div>
    <div class="captacao-contadores">
      <div><strong>${s(a.ttfr_mediana_ms)}</strong><span>Mediana até o 1º resultado (TTFR)</span></div>
      <div><strong>${s(a.ttlc_mediana_ms)}</strong><span>Mediana até concluir (TTLC)</span></div>
      <div><strong>${s(a.dedup_mediana_ms)}</strong><span>Deduplicação</span></div>
      <div><strong>${s(a.gravacao_mediana_ms)}</strong><span>Gravação</span></div>
    </div>
    <table class="app-table" style="margin-top:var(--space-3)"><thead><tr><th>Fonte</th><th>Buscas</th><th>Sucesso</th><th>Sem resposta a tempo</th><th>Erros</th><th>Latência (mediana)</th><th>Resultados</th></tr></thead>
    <tbody>${Object.entries(a.provedores || {}).map(([k, p]) => `<tr><td>${esc(PROVIDER_LABEL[k] || k)}</td><td>${p.jobs}</td><td>${p.sucesso_pct ?? '—'}%</td><td>${p.timeouts}</td><td>${p.erros}</td><td>${s(p.latencia_mediana_ms)}</td><td>${p.resultados}</td></tr>`).join('') || '<tr><td colspan="7">Sem dados ainda.</td></tr>'}</tbody></table>`;
  root.querySelector('#dgSaude').innerHTML = `<div class="card-head"><h3>Saúde por servidor (espelhos)</h3></div>
    <p class="captacao-dica">Servidor com 3 falhas seguidas fica em pausa (5 a 60 min) e volta a ser testado depois. A ordem de uso segue a taxa de sucesso.</p>
    <table class="app-table"><thead><tr><th>Servidor</th><th>Tentativas</th><th>Sucesso</th><th>429</th><th>406</th><th>Timeout</th><th>Latência média</th><th>Último sucesso</th><th>Situação</th></tr></thead>
    <tbody>${(d.saude || []).map((h) => `<tr><td>${esc(h.host)}</td><td>${h.tentativas}</td><td>${h.sucesso_pct}%</td><td>${h.s429_pct}%</td><td>${h.s406_pct}%</td><td>${h.timeout_pct}%</td><td>${s(h.latencia_media_ms)}</td><td>${dataHora(h.ultimo_sucesso)}</td><td>${h.em_cooldown ? `<span class="badge badge-warning">em pausa até ${dataHora(h.cooldown_ate)}</span>` : '<span class="badge badge-ok">ativo</span>'}</td></tr>`).join('') || '<tr><td colspan="9">Sem histórico ainda (começa a ser registrado na próxima busca).</td></tr>'}</tbody></table>`;
  root.querySelector('#dgJobs').innerHTML = `<div class="card-head"><h3>Últimas buscas</h3></div>
    <div style="overflow-x:auto"><table class="app-table"><thead><tr><th>Quando</th><th>Busca</th><th>1º resultado</th><th>Concluída</th><th>Fontes</th><th>Encontr.</th><th>Dupl.</th><th>Aprov.</th><th>Enriq.</th><th>Erros</th></tr></thead>
    <tbody>${(d.jobs || []).map((j) => { const m = j.metricas || {}; return `<tr>
      <td>${dataHora(j.created_at)}</td><td><a href="#/prospeccao/captacao/${esc(j.id)}">${esc(j.ramo || '')}</a><br><span class="captacao-dica">${esc((j.cidades || []).join(', '))}</span></td>
      <td>${s(m.ttfr_ms)}</td><td>${s(m.ttlc_ms ?? m.total_ms)}</td>
      <td>${Object.entries(m.providers || {}).map(([k, p]) => `<span class="captacao-dica">${esc(PROVIDER_LABEL[k] || k)}: ${esc(p.status || (p.erros ? 'erro' : 'ok'))} · ${s(p.duration_ms)} · ${p.resultados ?? 0}</span>`).join('<br>')}</td>
      <td>${j.qtd_encontrados ?? 0}</td><td>${j.qtd_duplicados ?? 0}</td><td>${j.qtd_aprovados ?? 0}</td><td>${j.qtd_enriquecidos ?? 0}</td>
      <td>${lista(j.erros).length ? `<details><summary>${lista(j.erros).length}</summary>${lista(j.erros).slice(0, 8).map((e) => `<div class="captacao-dica">${esc(e.provider || '')}: ${esc(String(e.mensagem || '').slice(0, 220))}</div>`).join('')}</details>` : '0'}</td></tr>`; }).join('')}</tbody></table></div>`;
}
