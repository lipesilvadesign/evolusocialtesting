/**
 * Aba "Imagens" do EvoluiSocial (03/10/2026) — banco de imagens. Admin-only.
 * Imagens entram como rascunho; só viram "ativa" com licença preenchida (regra também no banco).
 */
import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { confirmDialog } from '../components/ConfirmDialog.js';
import { abrirModal } from '../components/Modal.js';
import { esc } from '../utils/html.js';
import {
  listarImagens, contarPorStatus, criarImagem, atualizarImagem, arquivarImagem, apagarImagem, usosDaImagem,
  lacunas, listarTermos, urlImagem, semAcento, slug, TIPOS_ACEITOS,
} from '../services/imagensClient.js';

const num = (n) => Number(n || 0).toLocaleString('pt-BR');
const dataBR = (d) => (d ? new Date(d).toLocaleDateString('pt-BR') : '—');
const dataHoraBR = (d) => (d ? new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');
const kb = (b) => (b >= 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round((b || 0) / 1024))} KB`);

const STATUS_ROT = { rascunho: 'Rascunho', ativa: 'Ativa', revisao: 'Em revisão', arquivada: 'Arquivada' };
const STATUS_CLS = { rascunho: 'badge-warning', ativa: 'badge-ok', revisao: 'badge-info', arquivada: 'badge-demo' };
const ORIGEM_ROT = { propria: 'Própria', licenciada: 'Licenciada', banco_gratuito: 'Banco gratuito', cliente_autorizado: 'Cliente autorizado', outra: 'Outra' };
const PLATAFORMAS = [['instagram', 'Instagram'], ['tiktok', 'TikTok'], ['youtube', 'YouTube'], ['facebook', 'Facebook'], ['linkedin', 'LinkedIn']];
const FORMATOS = [['reels', 'Reels'], ['stories', 'Stories'], ['carrossel', 'Carrossel'], ['imagem', 'Imagem'], ['video', 'Vídeo'], ['texto', 'Texto']];
const TIPOS_CARD = [['tendencia', 'Tendência'], ['insight', 'Insight'], ['oportunidade', 'Oportunidade'], ['ideia', 'Ideia'], ['aprendizado', 'Aprendizado']];

const opts = (lista, atual, vazio) => `${vazio != null ? `<option value="">${esc(vazio)}</option>` : ''}${lista.map(([v, t]) => `<option value="${esc(v)}"${v === atual ? ' selected' : ''}>${esc(t)}</option>`).join('')}`;
const checks = (nome, lista, marcados) => lista.map(([v, t]) => `<label class="ev-check"><input type="checkbox" name="${nome}" value="${esc(v)}"${(marcados || []).includes(v) ? ' checked' : ''}> ${esc(t)}</label>`).join('');
const marcados = (box, nome) => [...box.querySelectorAll(`input[name="${nome}"]:checked`)].map((i) => i.value);
const listaTags = (txt) => [...new Set(String(txt || '').split(/[,;\n]/).map((t) => slug(t)).filter(Boolean))];

// Casa o nome do arquivo com a taxonomia (chave, rótulo ou sinônimo de um tema).
function sugerirTema(tags, termos) {
  const toks = tags.map((t) => semAcento(t).toLowerCase());
  const grupos = new Set(toks);
  for (let i = 0; i < toks.length - 1; i++) grupos.add(`${toks[i]} ${toks[i + 1]}`);
  const norm = (s) => semAcento(s).toLowerCase().replace(/[_-]+/g, ' ').trim();
  for (const t of termos.filter((x) => x.tipo === 'tema' && x.ativo)) {
    const nomes = [t.chave, t.rotulo, ...(t.sinonimos || [])].map(norm);
    if (nomes.some((n) => grupos.has(n))) return t;
  }
  return null;
}
function caminhoDoTema(tema, porId) {
  const sub = tema ? porId.get(tema.pai_id) : null;
  const area = sub ? porId.get(sub.pai_id) : null;
  return { tema_id: tema?.id || null, subramo_id: sub?.id || null, area_id: area?.id || null };
}

export async function abaImagens(corpo) {
  corpo.innerHTML = '';
  corpo.appendChild(LoadingState({ variant: 'cards', rows: 3 }));
  let termos, cont;
  try { [termos, cont] = await Promise.all([listarTermos(), contarPorStatus()]); } catch (err) {
    corpo.innerHTML = ''; corpo.appendChild(ErrorState({ description: err.message, onRetry: () => abaImagens(corpo) })); return;
  }
  const porId = new Map(termos.map((t) => [t.id, t]));
  const areas = termos.filter((t) => t.tipo === 'area' && t.ativo);
  const f = { status: '', areaId: '', temaId: '', busca: '' };
  const kpi = (l, v, s) => `<div class="card kpi-card"><div class="kpi-label">${esc(l)}</div><div class="kpi-value">${v}</div>${s ? `<div class="kpi-empty">${esc(s)}</div>` : ''}</div>`;

  const temasDaArea = (areaId) => termos.filter((t) => t.tipo === 'tema' && t.ativo && (!areaId || porId.get(porId.get(t.pai_id)?.pai_id)?.id === areaId));

  corpo.innerHTML = `
    <div class="ev-img-topo">
      <div class="kpi-grid ev-kpis" id="imgKpis"></div>
      <div class="ev-img-acao"><button type="button" class="btn btn-primary btn-sm" id="imgEnviar">Enviar imagens</button>
        <input type="file" id="imgArquivos" multiple accept="${TIPOS_ACEITOS.join(',')}" hidden></div>
    </div>
    <div class="ev-drop" id="imgDrop" tabindex="0" role="button" aria-label="Solte imagens aqui ou pressione Enter para escolher arquivos">
      <b>Solte as imagens aqui</b>
      <span>JPG, PNG ou WebP, até 3 MB cada depois de reduzidas (máx. 1600 px). Cada uma vira rascunho; o título e as tags saem do nome do arquivo (ex.: academia-treino.jpg gera as tags academia e treino).</span>
      <div class="ev-drop-fila" id="imgFila" role="status" aria-live="polite"></div>
    </div>
    <section class="card">
      <div class="card-head"><h3>Imagens</h3>
        <div class="ev-filtros">
          <label class="ev-filtro"><span>Status</span><select id="imgFStatus" class="ev-select"><option value="">Todos</option>${opts(Object.entries(STATUS_ROT), '')}</select></label>
          <label class="ev-filtro"><span>Área</span><select id="imgFArea" class="ev-select"><option value="">Todas</option>${areas.map((a) => `<option value="${esc(a.id)}">${esc(a.rotulo)}</option>`).join('')}</select></label>
          <label class="ev-filtro"><span>Tema</span><select id="imgFTema" class="ev-select"></select></label>
          <label class="ev-filtro"><span>Buscar</span><input id="imgFBusca" class="ev-input" type="search" placeholder="Título, autor ou tag"></label>
        </div></div>
      <div id="imgGrade"></div>
    </section>
    <section class="card" id="imgLacunas"></section>`;

  const $ = (s) => corpo.querySelector(s);
  const pintarKpis = () => {
    const s = cont.porStatus;
    $('#imgKpis').innerHTML = [kpi('Total', num(cont.total)), kpi('Ativas', num(s.ativa), 'usadas nas pesquisas'), kpi('Rascunhos', num(s.rascunho), 'faltam dados'), kpi('Em revisão', num(s.revisao)), kpi('Arquivadas', num(s.arquivada))].join('');
  };
  const pintarTemas = () => {
    const l = temasDaArea(f.areaId);
    if (!l.some((t) => t.id === f.temaId)) f.temaId = '';
    $('#imgFTema').innerHTML = `<option value="">Todos</option>${l.map((t) => `<option value="${esc(t.id)}"${t.id === f.temaId ? ' selected' : ''}>${esc(t.rotulo)}</option>`).join('')}`;
  };

  let imagens = [];
  const grade = $('#imgGrade');
  const pintarGrade = () => {
    grade.innerHTML = '';
    if (!imagens.length) {
      grade.appendChild(EmptyState({ title: 'Nenhuma imagem encontrada', description: (f.status || f.areaId || f.temaId || f.busca) ? 'Nenhuma imagem combina com os filtros. Limpe os filtros ou envie novas imagens.' : 'O banco está vazio. Use "Enviar imagens" ou solte arquivos na área acima.' }));
      return;
    }
    const ul = document.createElement('ul');
    ul.className = 'ev-img-grade';
    ul.innerHTML = imagens.map((im) => {
      const tema = porId.get(im.tema_id);
      return `<li><button type="button" class="ev-img-card" data-id="${esc(im.id)}" aria-label="Editar imagem: ${esc(im.titulo || im.arquivo)}">
        <span class="ev-img-thumb"><img loading="lazy" src="${esc(urlImagem(im.arquivo))}" alt="${esc(im.texto_alternativo || '')}"></span>
        <span class="ev-img-info"><b>${esc(im.titulo || 'Sem título')}</b>
        <span><span class="badge ${STATUS_CLS[im.status] || 'badge-demo'}">${esc(STATUS_ROT[im.status] || im.status)}</span>${tema ? ` <span class="ev-muted">${esc(tema.rotulo)}</span>` : ''}</span>
        <span class="ev-muted">${num(im.usos)} uso(s) · ${im.largura}×${im.altura}</span></span></button></li>`;
    }).join('');
    grade.appendChild(ul);
    ul.querySelectorAll('[data-id]').forEach((b) => b.addEventListener('click', () => editar(imagens.find((x) => x.id === b.dataset.id), b)));
  };
  const carregar = async () => {
    grade.innerHTML = ''; grade.appendChild(LoadingState({ rows: 4 }));
    try { imagens = await listarImagens(f); } catch (err) { grade.innerHTML = ''; grade.appendChild(ErrorState({ description: err.message, onRetry: carregar })); return; }
    pintarGrade();
  };
  const recontar = async () => { try { cont = await contarPorStatus(); pintarKpis(); } catch { /* contadores são conforto */ } };
  const depoisDeMudar = async () => { await Promise.all([carregar(), recontar(), carregarLacunas()]); };

  // ---------------------------------------------------------------- lacunas
  const boxL = $('#imgLacunas');
  let diasL = 30;
  async function carregarLacunas() {
    boxL.innerHTML = `<div class="card-head"><h3>Sem cobertura</h3>
      <label class="ev-filtro"><select id="imgLDias" class="ev-select" aria-label="Período das lacunas">${[7, 30, 90].map((d) => `<option value="${d}"${d === diasL ? ' selected' : ''}>${d} dias</option>`).join('')}</select></label></div>
      <p class="ev-como-txt">Temas que as pessoas buscaram nos últimos ${diasL} dias e para os quais não existe nenhuma imagem ativa. Cada linha é uma imagem que vale a pena subir.</p><div id="imgLCorpo"></div>`;
    boxL.querySelector('#imgLDias').addEventListener('change', (e) => { diasL = Number(e.target.value) || 30; carregarLacunas(); });
    const c = boxL.querySelector('#imgLCorpo');
    c.appendChild(LoadingState({ rows: 2 }));
    let l;
    try { l = await lacunas(diasL); } catch (err) { c.innerHTML = ''; c.appendChild(ErrorState({ title: 'Não foi possível carregar as lacunas', description: err.message, onRetry: carregarLacunas })); return; }
    c.innerHTML = '';
    if (!l.length) { c.appendChild(EmptyState({ title: 'Tudo coberto', description: `Nenhum tema buscado nos últimos ${diasL} dias ficou sem imagem ativa.` })); return; }
    c.innerHTML = `<div class="table-wrap"><table class="app-table"><thead><tr><th>Tema buscado</th><th>Buscas</th><th></th></tr></thead><tbody>
      ${l.map((x) => `<tr><td>${esc(x.termo)}</td><td>${num(x.buscas)}</td><td><button type="button" class="btn btn-ghost btn-xs" data-lacuna="${esc(x.termo)}">Ver imagens parecidas</button></td></tr>`).join('')}</tbody></table></div>`;
    c.querySelectorAll('[data-lacuna]').forEach((b) => b.addEventListener('click', () => {
      $('#imgFBusca').value = b.dataset.lacuna; f.busca = b.dataset.lacuna; carregar(); $('#imgGrade').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }));
  }

  // ---------------------------------------------------------------- filtros
  $('#imgFStatus').addEventListener('change', (e) => { f.status = e.target.value; carregar(); });
  $('#imgFArea').addEventListener('change', (e) => { f.areaId = e.target.value; pintarTemas(); carregar(); });
  $('#imgFTema').addEventListener('change', (e) => { f.temaId = e.target.value; carregar(); });
  let tb;
  $('#imgFBusca').addEventListener('input', (e) => { clearTimeout(tb); tb = setTimeout(() => { f.busca = e.target.value.trim(); carregar(); }, 350); });

  // ---------------------------------------------------------------- envio
  const fila = $('#imgFila');
  const input = $('#imgArquivos');
  let enviando = false;
  async function enviar(arquivos) {
    const lista = [...arquivos];
    if (!lista.length || enviando) return;
    enviando = true;
    $('#imgEnviar').disabled = true;
    let ok = 0; const erros = [];
    for (let i = 0; i < lista.length; i++) {
      const file = lista[i];
      fila.textContent = `Enviando ${i + 1} de ${lista.length}: ${file.name}…`;
      try {
        const base = file.name.replace(/\.[^.]+$/, '');
        const tags = listaTags(base.replace(/[-_.]+/g, ',').replace(/\d+/g, ','));
        const titulo = base.replace(/[-_.]+/g, ' ').replace(/\s+/g, ' ').trim();
        const tema = sugerirTema(tags, termos);
        await criarImagem(file, { titulo: titulo ? titulo.charAt(0).toUpperCase() + titulo.slice(1) : null, tags, ...caminhoDoTema(tema, porId) });
        ok++;
      } catch (err) { erros.push(err.message); }
    }
    enviando = false; $('#imgEnviar').disabled = false; input.value = '';
    fila.innerHTML = erros.length ? `<ul class="ev-drop-erros">${erros.map((e) => `<li>${esc(e)}</li>`).join('')}</ul>` : '';
    if (ok) showToast(`${ok} imagem(ns) enviada(s) como rascunho.${erros.length ? ` ${erros.length} com erro.` : ''}`, { tone: erros.length ? 'info' : 'ok' });
    else if (erros.length) showToast('Nenhuma imagem foi enviada.', { tone: 'danger' });
    if (ok) { f.status = ''; $('#imgFStatus').value = ''; await depoisDeMudar(); }
  }
  $('#imgEnviar').addEventListener('click', () => input.click());
  input.addEventListener('change', () => enviar(input.files));
  const drop = $('#imgDrop');
  drop.addEventListener('click', (e) => { if (!e.target.closest('.ev-drop-fila')) input.click(); });
  drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('is-over'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('is-over'); }));
  drop.addEventListener('drop', (e) => enviar(e.dataTransfer?.files || []));

  // ---------------------------------------------------------------- edição
  function editar(im, origem) {
    const { box, close } = abrirModal({
      titulo: 'Editar imagem', maxWidth: '860px', origem,
      html: `<form class="ev-img-form" id="imgForm" novalidate>
        <div class="ev-img-form-prev">
          <img src="${esc(urlImagem(im.arquivo))}" alt="${esc(im.texto_alternativo || 'Prévia da imagem')}">
          <p class="ev-muted">${im.largura}×${im.altura} px · ${kb(im.peso)}<br>Enviada em ${dataBR(im.criado_em)} · atualizada em ${dataBR(im.atualizado_em)}</p>
          <h4 class="ev-sub">Uso</h4>
          <p class="ev-muted" id="imgUsosResumo">Apareceu <b>${num(im.usos)}</b> vez(es).</p>
          <div id="imgUsosLista" class="ev-muted">Carregando usos…</div>
        </div>
        <div class="ev-img-form-campos">
          <div class="field"><label for="imgTitulo">Título</label><input id="imgTitulo" type="text" maxlength="160" value="${esc(im.titulo || '')}"></div>
          <div class="field"><label for="imgAlt">Texto alternativo (descreva a imagem para quem não enxerga)</label><input id="imgAlt" type="text" maxlength="300" value="${esc(im.texto_alternativo || '')}"></div>
          <div class="ev-form3">
            <div class="field"><label for="imgArea">Área</label><select id="imgArea"></select></div>
            <div class="field"><label for="imgSub">Subramo</label><select id="imgSub"></select></div>
            <div class="field"><label for="imgTema">Tema</label><select id="imgTema"></select></div>
          </div>
          <div class="field"><label for="imgTags">Tags (separadas por vírgula)</label><input id="imgTags" type="text" value="${esc((im.tags || []).join(', '))}"></div>
          <fieldset class="ev-grupo"><legend>Plataformas</legend>${checks('plataformas', PLATAFORMAS, im.plataformas)}</fieldset>
          <fieldset class="ev-grupo"><legend>Formatos</legend>${checks('formatos', FORMATOS, im.formatos)}</fieldset>
          <fieldset class="ev-grupo"><legend>Tipos de card</legend>${checks('tipos_card', TIPOS_CARD, im.tipos_card)}</fieldset>
          <div class="ev-form3">
            <div class="field"><label for="imgOrigem">Origem</label><select id="imgOrigem">${opts(Object.entries(ORIGEM_ROT), im.origem)}</select></div>
            <div class="field"><label for="imgLicenca">Licença</label><input id="imgLicenca" type="text" maxlength="200" value="${esc(im.licenca || '')}" placeholder="ex.: CC0, Unsplash, contrato 2026/12"></div>
            <div class="field"><label for="imgAutor">Autor</label><input id="imgAutor" type="text" maxlength="160" value="${esc(im.autor || '')}"></div>
          </div>
          <div class="field"><label for="imgFonte">URL da fonte</label><input id="imgFonte" type="url" inputmode="url" value="${esc(im.url_fonte || '')}" placeholder="https://"></div>
          <div class="field"><label for="imgStatus">Status</label><select id="imgStatus">${opts(Object.entries(STATUS_ROT), im.status)}</select>
            <p class="field-hint" id="imgAtivaDica" role="status"></p></div>
          <p class="ev-erro" id="imgErro" role="alert" hidden></p>
          <div class="ev-img-botoes">
            <button type="submit" class="btn btn-primary btn-sm" id="imgSalvar">Salvar</button>
            <button type="button" class="btn btn-ghost btn-sm" id="imgAtivar">Ativar</button>
            <button type="button" class="btn btn-ghost btn-sm" id="imgArquivar">Arquivar</button>
            <button type="button" class="btn btn-danger btn-sm" id="imgApagar">Apagar</button>
          </div>
        </div>
      </form>`,
    });
    const q = (s) => box.querySelector(s);
    // selects encadeados área > subramo > tema
    const filhos = (tipo, paiId, atual) => termos.filter((t) => t.tipo === tipo && (t.ativo || t.id === atual) && t.pai_id === paiId);
    const sel = (el, lista, atual, vazio) => { el.innerHTML = `<option value="">${vazio}</option>${lista.map((t) => `<option value="${esc(t.id)}"${t.id === atual ? ' selected' : ''}>${esc(t.rotulo)}${t.ativo ? '' : ' (desativado)'}</option>`).join('')}`; };
    const areasOpc = termos.filter((t) => t.tipo === 'area' && (t.ativo || t.id === im.area_id));
    sel(q('#imgArea'), areasOpc, im.area_id, '— sem área —');
    const refazSub = (keep) => { sel(q('#imgSub'), q('#imgArea').value ? filhos('subramo', q('#imgArea').value, keep) : [], keep, q('#imgArea').value ? '— sem subramo —' : '— escolha a área —'); q('#imgSub').disabled = !q('#imgArea').value; };
    const refazTema = (keep) => { sel(q('#imgTema'), q('#imgSub').value ? filhos('tema', q('#imgSub').value, keep) : [], keep, q('#imgSub').value ? '— sem tema —' : '— escolha o subramo —'); q('#imgTema').disabled = !q('#imgSub').value; };
    refazSub(im.subramo_id); refazTema(im.tema_id);
    q('#imgArea').addEventListener('change', () => { refazSub(null); refazTema(null); });
    q('#imgSub').addEventListener('change', () => refazTema(null));

    // licença x ativar
    const dica = q('#imgAtivaDica');
    const atualizaAtivar = () => {
      const tem = q('#imgLicenca').value.trim().length > 0;
      q('#imgAtivar').disabled = !tem || im.status === 'ativa';
      q('#imgAtivar').setAttribute('aria-disabled', String(q('#imgAtivar').disabled));
      const optAtiva = q('#imgStatus option[value="ativa"]');
      optAtiva.disabled = !tem;
      if (!tem && q('#imgStatus').value === 'ativa') q('#imgStatus').value = im.status === 'ativa' ? 'revisao' : im.status;
      dica.textContent = tem ? (im.status === 'ativa' ? 'Imagem ativa: está disponível para as pesquisas.' : 'Licença preenchida: a imagem pode ser ativada.')
        : 'Para ativar, preencha o campo Licença: só imagens com licença conhecida podem ser usadas nas pesquisas.';
    };
    q('#imgLicenca').addEventListener('input', atualizaAtivar);
    atualizaAtivar();
    if (im.status === 'arquivada') q('#imgArquivar').disabled = true;

    usosDaImagem(im.id).then((u) => {
      q('#imgUsosLista').innerHTML = u.length ? `<ul class="ev-usos">${u.map((x) => `<li>${esc(x.tipo_card || '—')}${x.tema ? ` · ${esc(x.tema)}` : ''}<span> ${dataHoraBR(x.criado_em)}</span></li>`).join('')}</ul>` : 'Ainda não foi usada em nenhum card.';
    }).catch((err) => { q('#imgUsosLista').textContent = `Não foi possível carregar os usos: ${err.message}`; });

    const erro = (m) => { const e = q('#imgErro'); e.hidden = !m; e.textContent = m || ''; };
    const ler = (statusForcado) => {
      const status = statusForcado || q('#imgStatus').value;
      return {
        titulo: q('#imgTitulo').value.trim() || null, texto_alternativo: q('#imgAlt').value.trim() || null,
        area_id: q('#imgArea').value || null, subramo_id: q('#imgSub').value || null, tema_id: q('#imgTema').value || null,
        tags: listaTags(q('#imgTags').value), plataformas: marcados(box, 'plataformas'), formatos: marcados(box, 'formatos'), tipos_card: marcados(box, 'tipos_card'),
        origem: q('#imgOrigem').value, licenca: q('#imgLicenca').value.trim() || null, autor: q('#imgAutor').value.trim() || null,
        url_fonte: q('#imgFonte').value.trim() || null, status,
      };
    };
    const travar = (on) => box.querySelectorAll('.ev-img-botoes button').forEach((b) => { b.disabled = on; });
    async function salvar(statusForcado, msg) {
      erro('');
      const c = ler(statusForcado);
      if (c.status === 'ativa' && !c.licenca) { erro('Para ativar a imagem, preencha a licença.'); q('#imgLicenca').focus(); return; }
      if (c.url_fonte && !/^https?:\/\//i.test(c.url_fonte)) { erro('A URL da fonte precisa começar com http:// ou https://.'); q('#imgFonte').focus(); return; }
      travar(true);
      try { await atualizarImagem(im.id, c); showToast(msg || 'Imagem salva.'); close(); await depoisDeMudar(); }
      catch (err) { erro(err.message); travar(false); atualizaAtivar(); if (im.status === 'arquivada') q('#imgArquivar').disabled = true; }
    }
    q('#imgForm').addEventListener('submit', (e) => { e.preventDefault(); salvar(); });
    q('#imgAtivar').addEventListener('click', () => salvar('ativa', 'Imagem ativada.'));
    q('#imgArquivar').addEventListener('click', async () => {
      if (!await confirmDialog({ title: 'Arquivar imagem?', description: 'A imagem sai das pesquisas, mas continua guardada e pode ser reativada depois.', confirmLabel: 'Arquivar', tone: 'default' })) return;
      travar(true);
      try { await arquivarImagem(im.id); showToast('Imagem arquivada.'); close(); await depoisDeMudar(); } catch (err) { erro(err.message); travar(false); atualizaAtivar(); }
    });
    q('#imgApagar').addEventListener('click', async () => {
      if (!await confirmDialog({ title: 'Apagar imagem de vez?', description: `"${im.titulo || im.arquivo}" será removida do banco e o arquivo será apagado. Isso não pode ser desfeito. Se só quiser tirar das pesquisas, use Arquivar.`, confirmLabel: 'Apagar definitivamente' })) return;
      travar(true);
      try {
        const r = await apagarImagem(im);
        showToast(r.arquivoRemovido ? 'Imagem apagada.' : 'Registro apagado, mas o arquivo não pôde ser removido do armazenamento.', { tone: r.arquivoRemovido ? 'ok' : 'info' });
        close(); await depoisDeMudar();
      } catch (err) { erro(err.message); travar(false); atualizaAtivar(); }
    });
  }

  pintarKpis(); pintarTemas();
  carregar(); carregarLacunas();
}
