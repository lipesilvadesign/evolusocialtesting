/**
 * Aba "Taxonomia" do EvoluiSocial (03/10/2026) — Área > Subramo > Tema, mais entidades.
 * Termos nunca são apagados (imagens e buscas dependem deles): só desativados.
 */
import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { abrirModal } from '../components/Modal.js';
import { esc } from '../utils/html.js';
import { listarTermos, criarTermo, atualizarTermo, definirTermoAtivo, contarPorStatus, chaveDe } from '../services/imagensClient.js';

const num = (n) => Number(n || 0).toLocaleString('pt-BR');
const NOME = { area: 'Área', subramo: 'Subramo', tema: 'Tema', entidade: 'Entidade' };
const FILHO = { area: 'subramo', subramo: 'tema' };
const listaSin = (txt) => [...new Set(String(txt || '').split(',').map((s) => s.trim()).filter(Boolean))];

export async function abaTaxonomia(corpo) {
  corpo.innerHTML = '';
  corpo.appendChild(LoadingState({ variant: 'cards', rows: 3 }));
  let termos, cont;
  try { [termos, cont] = await Promise.all([listarTermos(), contarPorStatus()]); } catch (err) {
    corpo.innerHTML = ''; corpo.appendChild(ErrorState({ description: err.message, onRetry: () => abaTaxonomia(corpo) })); return;
  }
  const filhosDe = (id) => termos.filter((t) => t.pai_id === id);
  const ativas = (id) => cont.ativasPorNo[id] || 0;
  const total = (id) => cont.totalPorNo[id] || 0;
  const porRotulo = (a, b) => a.rotulo.localeCompare(b.rotulo, 'pt-BR');

  const linha = (t) => {
    const filhos = filhosDe(t.id);
    const acoes = `<span class="ev-tax-acoes">
      ${FILHO[t.tipo] ? `<button type="button" class="btn btn-ghost btn-xs" data-novo="${esc(FILHO[t.tipo])}" data-pai="${esc(t.id)}" aria-label="Adicionar ${NOME[FILHO[t.tipo]].toLowerCase()} em ${esc(t.rotulo)}">+ ${NOME[FILHO[t.tipo]]}</button>` : ''}
      <button type="button" class="btn btn-ghost btn-xs" data-editar="${esc(t.id)}" aria-label="Editar ${esc(t.rotulo)}">Editar</button>
      <button type="button" class="btn btn-ghost btn-xs" data-ativo="${esc(t.id)}" aria-label="${t.ativo ? 'Desativar' : 'Reativar'} ${esc(t.rotulo)}">${t.ativo ? 'Desativar' : 'Reativar'}</button></span>`;
    const dica = filhos.length || total(t.id) ? `Não pode ser apagado: ${filhos.length ? `${filhos.length} termo(s) abaixo` : ''}${filhos.length && total(t.id) ? ' e ' : ''}${total(t.id) ? `${num(total(t.id))} imagem(ns)` : ''}.` : '';
    return `<div class="ev-tax-linha${t.ativo ? '' : ' is-off'}">
      <span class="ev-tax-nome"><b>${esc(t.rotulo)}</b> <code>${esc(t.chave)}</code>${t.ativo ? '' : ' <span class="badge badge-demo">Desativado</span>'}
        ${(t.sinonimos || []).length ? `<span class="ev-muted">Sinônimos: ${esc(t.sinonimos.join(', '))}</span>` : ''}${dica ? `<span class="ev-muted">${esc(dica)}</span>` : ''}</span>
      <span class="badge ${ativas(t.id) ? 'badge-ok' : 'badge-demo'}" title="Imagens ativas neste termo">${num(ativas(t.id))} ativa(s)</span>${acoes}</div>`;
  };
  const no = (t) => {
    const f = filhosDe(t.id).sort(porRotulo);
    return `<li>${linha(t)}${f.length ? `<ul>${f.map(no).join('')}</ul>` : ''}</li>`;
  };

  const areas = termos.filter((t) => t.tipo === 'area').sort(porRotulo);
  const entidades = termos.filter((t) => t.tipo === 'entidade').sort(porRotulo);
  corpo.innerHTML = `
    <section class="card">
      <div class="card-head"><h3>Taxonomia</h3><button type="button" class="btn btn-primary btn-sm" data-novo="area">+ Nova área</button></div>
      <p class="ev-como-txt">Organiza o banco de imagens em Área, Subramo e Tema. A contagem mostra as imagens <b>ativas</b> em cada nível. Termos não são apagados: desative para tirar das listas. A chave é gerada a partir do rótulo e não muda depois.</p>
      ${areas.length ? `<ul class="ev-tax" aria-label="Árvore da taxonomia">${areas.map(no).join('')}</ul>` : ''}
      <div id="taxVazio"></div>
    </section>
    <section class="card">
      <div class="card-head"><h3>Entidades</h3><button type="button" class="btn btn-ghost btn-sm" data-novo="entidade">+ Nova entidade</button></div>
      <p class="ev-como-txt">Nomes de marcas, lugares e pessoas que ajudam a reconhecer o assunto de uma busca.</p>
      ${entidades.length ? `<ul class="ev-tax"><li>${entidades.map((t) => `<div class="ev-tax-flat">${linha(t)}</div>`).join('')}</li></ul>` : '<p class="kpi-empty">Nenhuma entidade cadastrada.</p>'}
    </section>`;
  if (!areas.length) corpo.querySelector('#taxVazio').appendChild(EmptyState({ title: 'Nenhuma área cadastrada', description: 'Crie a primeira área para começar a organizar as imagens.', actionLabel: '+ Nova área', onAction: () => formulario({ tipo: 'area' }, null) }));

  corpo.querySelectorAll('[data-novo]').forEach((b) => b.addEventListener('click', () => formulario({ tipo: b.dataset.novo, paiId: b.dataset.pai || null }, null, b)));
  corpo.querySelectorAll('[data-editar]').forEach((b) => b.addEventListener('click', () => formulario({}, termos.find((t) => t.id === b.dataset.editar), b)));
  corpo.querySelectorAll('[data-ativo]').forEach((b) => b.addEventListener('click', async () => {
    const t = termos.find((x) => x.id === b.dataset.ativo);
    b.disabled = true;
    try { await definirTermoAtivo(t.id, !t.ativo); showToast(t.ativo ? 'Termo desativado.' : 'Termo reativado.'); abaTaxonomia(corpo); }
    catch (err) { showToast(err.message, { tone: 'danger' }); b.disabled = false; }
  }));

  function formulario(novo, termo, origem) {
    const edita = !!termo;
    const tipo = termo ? termo.tipo : novo.tipo;
    const pai = termos.find((t) => t.id === (termo ? termo.pai_id : novo.paiId));
    const { box, close } = abrirModal({
      titulo: edita ? `Editar ${NOME[tipo].toLowerCase()}` : `Novo termo: ${NOME[tipo].toLowerCase()}`, maxWidth: '480px', origem,
      html: `<form id="taxForm" novalidate>
        ${pai ? `<p class="ev-muted">Dentro de: <b>${esc(pai.rotulo)}</b></p>` : ''}
        <div class="field"><label for="taxRotulo">Rótulo</label><input id="taxRotulo" type="text" maxlength="80" required value="${esc(termo?.rotulo || '')}"></div>
        <div class="field"><label for="taxChave">Chave</label><input id="taxChave" type="text" readonly aria-readonly="true" value="${esc(termo?.chave || '')}">
          <p class="field-hint">Gerada a partir do rótulo, sem acento. ${edita ? 'Não muda depois de criada.' : ''}</p></div>
        <div class="field"><label for="taxSin">Sinônimos (separados por vírgula)</label><input id="taxSin" type="text" value="${esc((termo?.sinonimos || []).join(', '))}" placeholder="ex.: musculação, treino, gym"></div>
        <p class="ev-erro" id="taxErro" role="alert" hidden></p>
        <div class="ev-img-botoes"><button type="submit" class="btn btn-primary btn-sm">${edita ? 'Salvar' : 'Criar'}</button><button type="button" class="btn btn-ghost btn-sm" data-cancelar>Cancelar</button></div>
      </form>`,
    });
    const q = (s) => box.querySelector(s);
    if (!edita) q('#taxRotulo').addEventListener('input', () => { q('#taxChave').value = chaveDe(q('#taxRotulo').value); });
    q('[data-cancelar]').addEventListener('click', close);
    q('#taxForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const erro = (m) => { q('#taxErro').hidden = !m; q('#taxErro').textContent = m || ''; };
      const rotulo = q('#taxRotulo').value.trim();
      if (!rotulo) { erro('Informe o rótulo.'); q('#taxRotulo').focus(); return; }
      const chave = edita ? termo.chave : chaveDe(rotulo);
      if (!chave) { erro('O rótulo precisa ter ao menos uma letra ou número.'); return; }
      const sinonimos = listaSin(q('#taxSin').value);
      const btn = q('button[type="submit"]'); btn.disabled = true;
      try {
        if (edita) await atualizarTermo(termo.id, { rotulo, sinonimos });
        else await criarTermo({ tipo, paiId: pai?.id || null, rotulo, chave, sinonimos });
        showToast(edita ? 'Termo salvo.' : 'Termo criado.'); close(); abaTaxonomia(corpo);
      } catch (err) { erro(err.message); btn.disabled = false; }
    });
  }
}
