import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { renderHealthStatus } from '../components/HealthStatusCard.js';
import { renderTaskBoard } from '../components/TaskBoard.js';
import { showToast } from '../components/Toast.js';
import { fetchHealth, fetchAuditLog } from '../services/systemClient.js';
import { fetchTasks, createTask } from '../services/tasksClient.js';

// achado nesta auditoria: a trilha de Auditoria interpolava actor_id/
// action/target_type/target_id direto em innerHTML sem escapar — mesma
// classe de falha já corrigida em todo o resto do painel (13-14/09).
// actor_id é um e-mail (pode, em tese, ter sido cadastrado por outro admin
// com caracteres incomuns); os demais campos vêm sempre do próprio código,
// mas escapar todos é a mesma regra "nunca confiar em texto -> innerHTML"
// já seguida no resto do projeto, sem depender de nenhum código atual
// nunca mudar.
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function renderSistema(container) {
  container.innerHTML = '';

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Sistema</h2>
      <p>Monitoramento, tarefas e auditoria.</p>
    </div>
  `;
  container.appendChild(head);

  const healthBody = section('Monitoramento');
  const tasksBody = section('Tarefas', { extraHtml: '<button class="btn btn-primary btn-sm" id="newTaskBtn">+ Nova tarefa</button>' });
  // Auditoria fica recolhida por padrão — é consulta ocasional (trilha de
  // segurança), não algo que precisa disputar espaço com o que se usa todo
  // dia nesta página.
  const auditDetails = document.createElement('details');
  auditDetails.className = 'card';
  auditDetails.innerHTML = '<summary style="cursor:pointer;padding:var(--space-2) 0"><h3 style="display:inline">Auditoria</h3></summary>';
  const auditBody = { card: auditDetails, body: document.createElement('div') };
  auditDetails.appendChild(auditBody.body);

  [healthBody, tasksBody].forEach((s) => container.appendChild(s.card));
  container.appendChild(auditBody.card);

  function section(title, opts = {}) {
    const card = document.createElement('section');
    card.className = 'card';
    card.innerHTML = `<div class="card-head"><h3>${title}</h3><div style="display:flex;gap:6px">${opts.extraHtml || ''}</div></div>`;
    const body = document.createElement('div');
    card.appendChild(body);
    return { card, body };
  }

  loadHealth();
  loadTasks();
  loadAudit();

  function loadHealth() {
    healthBody.body.innerHTML = '';
    healthBody.body.appendChild(LoadingState({ variant: 'cards', rows: 3 }));
    fetchHealth()
      .then((health) => {
        healthBody.body.innerHTML = '';
        healthBody.body.appendChild(renderHealthStatus(health));
      })
      .catch((err) => {
        healthBody.body.innerHTML = '';
        healthBody.body.appendChild(ErrorState({ description: err.message, onRetry: loadHealth }));
      });
  }

  function loadTasks() {
    tasksBody.body.innerHTML = '';
    tasksBody.body.appendChild(LoadingState({ variant: 'cards', rows: 3 }));
    fetchTasks()
      .then((tasks) => {
        tasksBody.body.innerHTML = '';
        tasksBody.body.appendChild(renderTaskBoard(tasks, { onChange: loadTasks }));
      })
      .catch((err) => {
        tasksBody.body.innerHTML = '';
        tasksBody.body.appendChild(ErrorState({ description: err.message, onRetry: loadTasks }));
      });
  }

  tasksBody.card.querySelector('#newTaskBtn').addEventListener('click', async () => {
    const titulo = window.prompt('Título da tarefa:');
    if (!titulo || !titulo.trim()) return;
    try {
      await createTask({ titulo: titulo.trim(), origemTipo: 'manual' });
      showToast('Tarefa criada.', { tone: 'ok' });
      loadTasks();
    } catch (err) {
      showToast(err.message || 'Falha ao criar tarefa.', { tone: 'danger' });
    }
  });

  function loadAudit() {
    auditBody.body.innerHTML = '';
    auditBody.body.appendChild(LoadingState({ rows: 4 }));
    fetchAuditLog()
      .then((entries) => {
        auditBody.body.innerHTML = '';
        if (entries.length === 0) {
          auditBody.body.appendChild(EmptyState({ title: 'Nenhum registro ainda', description: 'Alterações administrativas aparecem aqui.' }));
          return;
        }
        const wrap = document.createElement('div');
        wrap.className = 'table-wrap';
        wrap.innerHTML = `
          <table class="app-table">
            <thead><tr><th>Quando</th><th>Quem</th><th>Ação</th><th>Alvo</th></tr></thead>
            <tbody>${entries
              .map(
                (e) =>
                  `<tr><td>${esc(new Date(e.created_at).toLocaleString('pt-BR'))}</td><td>${esc(e.actor_id)}</td><td>${esc(e.action)}</td><td>${esc(e.target_type)}${e.target_id ? ' · ' + esc(e.target_id) : ''}</td></tr>`
              )
              .join('')}</tbody>
          </table>
        `;
        auditBody.body.appendChild(wrap);
      })
      .catch((err) => {
        auditBody.body.innerHTML = '';
        auditBody.body.appendChild(ErrorState({ description: err.message, onRetry: loadAudit }));
      });
  }
}
