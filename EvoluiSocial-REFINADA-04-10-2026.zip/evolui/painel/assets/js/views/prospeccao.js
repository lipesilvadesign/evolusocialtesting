import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { confirmDialog } from '../components/ConfirmDialog.js';
import { showToast } from '../components/Toast.js';
import { faixaScore } from '../services/scoreEngine.js';
import { getCurrentUser } from '../services/auth.js';
import { ehAdmin } from '../services/rbac.js';
import { leadsParaCSV } from '../services/csvLeads.js';
import { carregarTaxonomia } from '../services/captacaoClient.js';
import { carregarOperacao, criarTarefa, mudarTarefa } from '../services/tarefasClient.js';
import { gerarMensagem } from '../services/mensagensTemplates.js';
import { abrirModal as abrirModalBase } from '../components/Modal.js';
import {
  fetchLeads,
  fetchTodosLeads,
  fetchLead,
  createLeadComChecagem,
  updateLead,
  deleteLead,
  arquivarLeads,
  restaurarLeads,
  enviarEmails,
  consultarStatusEnvio,
  buscarRelatorio,
  listarContatos,
  criarContato,
  removerContato,
  listarAtividades,
  criarAtividade,
  registrarOptout,
} from '../services/prospeccaoClient.js';

// Nomes de empresa/contato/atividade e todo texto digitado livremente por
// qualquer funcionário — nunca inserir em innerHTML (nem dentro de
// <textarea>, onde um "</textarea>" no texto quebraria a tag) sem escapar antes.
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// Mesma cobertura da busca automática semanal (OSM) — reaproveitada aqui como
// opções prontas no popup, mas o campo aceita qualquer cidade digitada.
const CIDADES_SUGERIDAS = [
  'Petrolina, PE', 'Juazeiro, BA', 'Lagoa Grande, PE', 'Santa Maria da Boa Vista, PE',
  'Casa Nova, BA', 'Sobradinho, BA', 'Curaçá, BA', 'Orocó, PE', 'Dormentes, PE', 'Afrânio, PE',
];
const RAMOS_SUGERIDOS = [
  'Construtora', 'Indústria', 'Cooperativa agrícola', 'Atacado/Distribuidora',
  'Transportadora', 'Concessionária de veículos', 'Faculdade/Escola técnica', 'Hotel/Pousada',
];

// Exportado para o Dashboard (Início) reaproveitar os mesmos rótulos/cores
// do funil sem duplicar a definição (eliminação de duplicidade da limpeza final).
export const STATUS_MAP = {
  novo_lead: { label: 'Novo lead', cls: 'badge-demo' },
  contatado: { label: 'Contatado', cls: 'badge-info' },
  respondeu: { label: 'Respondeu', cls: 'badge-warning' },
  // "interessado" é novo (ver SQL_PENDENTE_estados_rapidos.sql) — precisa da
  // migração aplicada no Supabase antes de um PATCH com esse valor funcionar
  // de verdade contra o banco (a constraint antiga ainda rejeitaria).
  interessado: { label: 'Interessado', cls: 'badge-warning' },
  reuniao_marcada: { label: 'Reunião/orçamento', cls: 'badge-warning' },
  proposta_enviada: { label: 'Proposta enviada', cls: 'badge-warning' },
  cliente: { label: 'Convertido', cls: 'badge-ok' },
  nao_convertido: { label: 'Perdido', cls: 'badge-danger' },
};
export const STATUS_ORDER = Object.keys(STATUS_MAP);

const STATUS_LEAD_MAP = {
  novo: 'Novo', pesquisando: 'Pesquisando', qualificado: 'Qualificado',
  nao_qualificado: 'Não qualificado', duplicado: 'Duplicado', bloqueado: 'Bloqueado',
};
const STATUS_CONTATO_MAP = {
  sem_contato: 'Sem contato', email_encontrado: 'E-mail encontrado', email_validado: 'E-mail validado',
  whatsapp_disponivel: 'WhatsApp disponível', decisor_identificado: 'Decisor identificado',
  optout_solicitado: 'Opt-out solicitado', nao_contatar: 'Não contatar',
};
const TIPO_ATIVIDADE_MAP = {
  email_enviado: 'E-mail enviado', whatsapp_enviado: 'WhatsApp enviado', ligacao: 'Ligação',
  follow_up: 'Follow-up', resposta_recebida: 'Resposta recebida', reuniao_marcada: 'Reunião marcada',
  reuniao_realizada: 'Reunião realizada', proposta_enviada: 'Proposta enviada', negociacao: 'Negociação', nota: 'Nota',
  mudanca_status: 'Status atualizado',
};

const PRIORIDADE_MAP = {
  alta: { label: 'Alta', cls: 'badge-danger' },
  media: { label: 'Média', cls: 'badge-warning' },
  baixa: { label: 'Baixa', cls: 'badge-demo' },
};

// Junta score numérico + faixa calculada (calcularScore/faixaScore) num só
// badge — antes eram 2 colunas (Score e Prioridade, que é um campo manual
// separado). "Ranking" é o que decide a ordenação da lista (ver .sort logo
// abaixo), então faz sentido virar uma coisa só visualmente.
function rankingBadgeHtml(lead) {
  const score = lead.score || 0;
  const faixa = faixaScore(score);
  const cls = { prioritario: 'badge-ok', prospectar: 'badge-info', nutrir: 'badge-warning', aguardar: 'badge-demo' }[faixa.chave] || 'badge-demo';
  const motivos = (Array.isArray(lead.score_motivos) ? lead.score_motivos : []).map((m) => `${m.label} (+${m.pontos})`).join('; ') || 'Nenhum sinal marcado';
  return `<span class="badge ${cls}" title="${esc(motivos)}"><strong>${score}</strong> · ${faixa.label}</span>`;
}

const TEMPERATURA_MAP = { quente: { label: 'Quente', cls: 'badge-danger' }, morno: { label: 'Morno', cls: 'badge-warning' }, frio: { label: 'Frio', cls: 'badge-demo' } };
/** Temperatura = calculada pelo banco a partir de datas e respostas do lead (nunca opinião). */
// Fase 3 — composição do score EXATAMENTE como o banco gravou (score_motivos da função SQL);
// a tela só agrupa por componente e soma o que veio de lá, nunca recalcula.
const COMPONENTE_LABEL = { encaixe: 'Encaixe', oportunidade: 'Oportunidade', contato: 'Contato', intencao: 'Intenção', bloqueio: 'Bloqueio' };
function composicaoScoreHtml(motivos) {
  const lista = Array.isArray(motivos) ? motivos : [];
  if (!lista.length) return '<p style="margin-top:var(--space-2);font-size:.8rem;color:var(--text-muted)">Nenhum sinal marcado ainda.</p>';
  const grupos = {};
  for (const m of lista) { const c = m.componente || 'outros'; (grupos[c] = grupos[c] || []).push(m); }
  return `<ul class="score-composicao">${Object.entries(grupos).map(([c, ms]) => {
    const soma = ms.reduce((a, m) => a + (Number(m.pontos) || 0), 0);
    return `<li><strong>${soma >= 0 ? '+' : ''}${soma} ${esc(COMPONENTE_LABEL[c] || c)}</strong> <span>${ms.map((m) => `${esc(m.label)}${m.pontos ? ` (+${m.pontos})` : ''}`).join(' · ')}</span></li>`;
  }).join('')}</ul><p style="font-size:.72rem;color:var(--text-muted)">Cada componente tem teto (encaixe 35, oportunidade 40, contato 15, intenção 30); a soma dos itens pode passar do teto.</p>`;
}
const CONTATABILIDADE = {
  CONTATO_FORTE: { label: 'Contato forte', cls: 'badge-ok', dica: 'E-mail ou WhatsApp + outro canal.' },
  CONTATO_PARCIAL: { label: 'Contato parcial', cls: 'badge-warning', dica: 'Só um canal (telefone sozinho não conta como contato forte).' },
  SEM_CONTATO: { label: 'Sem contato', cls: 'badge-danger', dica: 'Nenhum canal cadastrado ou encontrado.' },
};
/** Potencial (score) e engajamento (temperatura) são coisas diferentes — a tela diz os dois. */
function potencialEngajamentoTexto(lead) {
  const pot = faixaScore(lead.score || 0).label; // mesmas faixas do banco (Prioritário/Prospectar/Nutrir/Aguardar)
  const eng = { quente: 'engajado agora', morno: 'interagiu há algum tempo', frio: 'sem interação recente' }[lead.temperatura] || 'sem registro de interação';
  return `<span style="font-size:.8rem;color:var(--text-muted)">Potencial: <strong>${esc(pot)}</strong> · Engajamento: ${eng}</span>`;
}
const TIPO_TAREFA = { ligar: 'Ligar', whatsapp: 'WhatsApp', email: 'E-mail', reuniao: 'Reunião', enviar_diagnostico: 'Enviar diagnóstico', enviar_proposta: 'Enviar proposta', follow_up: 'Follow-up', outro: 'Outro' };

/** Próxima ação + tarefas + histórico do score (dados do banco; a regra fica lá). */
async function montarOperacao(panel, lead) {
  const host = panel.querySelector('#proximaAcaoHost');
  const hist = panel.querySelector('#scoreHistoricoHost');
  if (!host) return;
  let dados;
  try { dados = await carregarOperacao(lead.id); } catch (err) {
    host.innerHTML = `<div class="card-head"><h3>Próxima ação</h3></div><p class="captacao-erro">${esc(err.message)}</p>`;
    return;
  }
  const abertas = dados.tarefas.filter((t) => t.status === 'aberta');
  const fmt = (iso) => new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const amanha = new Date(Date.now() + 86400000); amanha.setHours(9, 0, 0, 0);
  const valorData = new Date(amanha.getTime() - amanha.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  host.innerHTML = `<div class="card-head"><h3>Próxima ação</h3></div>
    ${abertas.length ? `<p style="font-size:1rem"><strong>${esc(abertas[0].descricao)}</strong> · ${fmt(abertas[0].data)}${new Date(abertas[0].data) < new Date() ? ' <span class="badge badge-danger">atrasada</span>' : ''}</p>` : '<p style="font-size:.85rem;color:var(--text-muted)">Nenhuma ação agendada.</p>'}
    <ul class="tarefas-lista">${dados.tarefas.slice(0, 8).map((t) => `<li class="tarefa-${esc(t.status)}"><span>${esc(TIPO_TAREFA[t.tipo] || t.tipo)} · ${esc(t.descricao)} · ${fmt(t.data)}</span>
      ${t.status === 'aberta' ? `<span><button type="button" class="btn btn-ghost btn-xs" data-tarefa="${esc(t.id)}" data-st="concluida">Concluir</button><button type="button" class="btn btn-ghost btn-xs" data-tarefa="${esc(t.id)}" data-st="cancelada">Cancelar</button></span>` : `<span class="badge badge-demo">${t.status === 'concluida' ? 'concluída' : 'cancelada'}</span>`}</li>`).join('')}</ul>
    <form class="tarefa-nova" novalidate>
      <select name="tipo" aria-label="Tipo da ação">${Object.entries(TIPO_TAREFA).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select>
      <input name="descricao" maxlength="300" placeholder="Ex.: Enviar diagnóstico" aria-label="Descrição da próxima ação" required>
      <input name="data" type="datetime-local" value="${valorData}" aria-label="Data da próxima ação" required>
      <button class="btn btn-primary btn-sm" type="submit">Agendar</button>
    </form>`;
  host.querySelectorAll('[data-tarefa]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    try { await mudarTarefa(b.dataset.tarefa, b.dataset.st); showToast(b.dataset.st === 'concluida' ? 'Ação concluída.' : 'Ação cancelada.', { tone: 'ok' }); montarOperacao(panel, lead); } catch (err) { showToast(err.message, { tone: 'danger' }); b.disabled = false; }
  }));
  host.querySelector('form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const f = ev.currentTarget;
    const btn = f.querySelector('button');
    if (!f.descricao.value.trim()) { showToast('Descreva a próxima ação.', { tone: 'danger' }); return; }
    btn.disabled = true;
    try {
      await criarTarefa({ leadId: lead.id, tipo: f.tipo.value, descricao: f.descricao.value.trim(), data: new Date(f.data.value).toISOString() });
      showToast('Próxima ação agendada.', { tone: 'ok' });
      montarOperacao(panel, lead);
    } catch (err) { showToast(err.message, { tone: 'danger' }); btn.disabled = false; }
  });
  if (hist) {
    const h = dados.historico || [];
    hist.innerHTML = `<summary style="font-size:.8rem;color:var(--text-muted)">Evolução do score (${h.length})</summary>
      <ul class="score-historico">${h.map((x) => `<li><strong>${x.score_anterior ?? '—'} → ${x.score_novo ?? '—'}</strong> <span>${new Date(x.criado_em).toLocaleDateString('pt-BR')}</span>
        ${(x.entrou || []).length ? `<br><span>+ ${(x.entrou || []).map((m) => esc(m.label)).join(', ')}</span>` : ''}${(x.saiu || []).length ? `<br><span>− ${(x.saiu || []).map((m) => esc(m.label)).join(', ')}</span>` : ''}</li>`).join('') || '<li>Sem alterações registradas.</li>'}</ul>`;
  }
}

function temperaturaBadgeHtml(lead) {
  const t = TEMPERATURA_MAP[lead.temperatura];
  return t ? ` <span class="badge ${t.cls}" title="Temperatura calculada: interações vindas do lead nos últimos dias">${t.label}</span>` : '';
}
const FONTE_LABEL = { manual: 'Manual', osm: 'OpenStreetMap', geoapify: 'Geoapify', csv: 'Planilha', xlsx: 'Planilha', site: 'Site', indicacao: 'Indicação', evento: 'Evento', osm_auto: 'OpenStreetMap', osm_manual: 'OpenStreetMap', geoapify_manual: 'Geoapify', busca_manual: 'Busca' };
const MOTIVOS_ARQUIVAR = { sem_interesse: 'Sem interesse', dados_invalidos: 'Dados inválidos', duplicado: 'Duplicado', optout: 'Pediu para não ser contatado', outro: 'Outro' };

function statusBadgeHtml(status) {
  const info = STATUS_MAP[status] || STATUS_MAP.novo_lead;
  return `<span class="badge ${info.cls}">${info.label}</span>`;
}

function onlyDigits(str) {
  return (str || '').replace(/\D/g, '');
}

/**
 * Monta a mensagem de abertura já personalizada com o nome da empresa e,
 * quando disponível, a avaliação no Google. Devolvida como texto editável,
 * o vendedor pode ajustar antes de copiar/enviar.
 */
function buildMessage(lead) {
  return gerarMensagem('primeiro_contato', {
    empresa: lead.empresa,
    segmento: lead.setor,
    instagram: lead.instagram || undefined,
    avaliacaoGoogle: lead.avaliacao_google || undefined,
    anosMercado: lead.anos_mercado || undefined,
  });
}

function whatsappUrl(telefone, message) {
  const digits = onlyDigits(telefone);
  if (!digits) return null;
  // números já vêm com DDI (+55...) na planilha de origem; se vier só DDD+número, assume BR.
  const withCountry = digits.startsWith('55') && digits.length >= 12 ? digits : `55${digits}`;
  const base = `https://wa.me/${withCountry}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

// ---------------------------------------------------------------------
// Ações rápidas (reformulação "prospecção extremamente rápida") — cada
// ação faz NO MÁXIMO uma mudança de status + um registro de atividade,
// sempre otimista na tela (o card/linha já reflete antes da confirmação do
// servidor, com reversão se der erro) e sempre com um toast curto. Nenhuma
// automação aqui declara algo que o sistema não pode determinar sozinho —
// ver notas em cada ação.
// ---------------------------------------------------------------------

export const NAO_TERMINAIS = ['novo_lead', 'contatado', 'respondeu', 'interessado', 'reuniao_marcada', 'proposta_enviada'];

/** Dias desde o último contato/atividade registrado — calculado, nunca declarado manualmente. */
export function diasSemAtividade(lead) {
  const referencia = lead.ultima_atividade_em || lead.created_at;
  if (!referencia) return null;
  const diffMs = Date.now() - new Date(referencia).getTime();
  return Math.floor(diffMs / (24 * 60 * 60 * 1000));
}

/** Selo "aguardando resposta há N dias" — só aparece em estágios não-terminais, e só é um indicador (não muda nada sozinho). */
function agingBadgeHtml(lead) {
  if (!NAO_TERMINAIS.includes(lead.status)) return '';
  const dias = diasSemAtividade(lead);
  if (dias === null || dias < 3) return '';
  const cls = dias >= 10 ? 'badge-danger' : dias >= 5 ? 'badge-warning' : 'badge-demo';
  return ` <span class="badge ${cls}" title="Nenhuma atividade registrada há ${dias} dia(s)">aguardando há ${dias}d</span>`;
}

// Definição das ações rápidas pedidas: no máximo 1 mudança de status + 1
// atividade cada. `status: null` = não muda o estágio do lead, só registra
// a atividade (caso do Follow-up e do "Sem resposta").
// Ícone (SVG inline, mesmo estilo dos ícones do menu) por ação — só
// visual, não muda nenhum comportamento.
const ACAO_ICONE = {
  respondeu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>',
  follow_up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
  interessado: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.7 7-6.3-3.9-6.3 3.9 1.7-7L2 9.2l7.1-.6z"/></svg>',
  sem_resposta: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>',
  reuniao: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4"/></svg>',
  convertido: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/></svg>',
  perdido: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M15 9l-6 6M9 9l6 6"/></svg>',
};

export const ACOES_RAPIDAS = [
  { id: 'respondeu', label: 'Respondeu', status: 'respondeu', tipoAtividade: 'resposta_recebida', descricao: 'Lead respondeu ao contato.' },
  { id: 'follow_up', label: 'Follow-up', status: null, tipoAtividade: 'follow_up', descricao: 'Follow-up registrado.', proximaEmDias: 3 },
  { id: 'interessado', label: 'Interessado', status: 'interessado', tipoAtividade: 'mudanca_status', descricao: null },
  { id: 'sem_resposta', label: 'Sem resposta', status: null, tipoAtividade: 'nota', descricao: 'Sem retorno até o momento (verificado manualmente).' },
  { id: 'reuniao', label: 'Reunião/Orçamento', status: 'reuniao_marcada', tipoAtividade: 'reuniao_marcada', descricao: 'Reunião ou orçamento em andamento.' },
  { id: 'convertido', label: 'Converter', status: 'cliente', tipoAtividade: 'mudanca_status', descricao: null, destaque: 'ok' },
  { id: 'perdido', label: 'Perdido', status: 'nao_convertido', tipoAtividade: 'mudanca_status', descricao: null, destaque: 'danger' },
];

function acoesRapidasHtml(lead) {
  // Estágio terminal (cliente/nao_convertido) não precisa mais de ações de
  // avanço — evita botão sem função nenhuma (perdido/convertido de novo).
  if (!NAO_TERMINAIS.includes(lead.status) || lead.arquivado_em) return '';
  return `<div class="lead-quick-actions">${ACOES_RAPIDAS.map((a) => (
    `<button type="button" class="btn btn-ghost btn-xs btn-icon-label${a.destaque ? ` btn-${a.destaque}` : ''}" data-acao-rapida="${a.id}" ${lead._acaoEmAndamento ? 'disabled' : ''}>${ACAO_ICONE[a.id] || ''}<span>${a.label}</span></button>`
  )).join('')}</div>`;
}

/**
 * Aplica uma ação rápida: PATCH de status (se houver) + POST de atividade,
 * sempre otimista (a linha já muda na tela) com reversão em caso de erro.
 * @param {object} lead
 * @param {object} acaoDef um item de ACOES_RAPIDAS
 * @param {{ onDone: () => void }} callbacks
 */
async function aplicarAcaoRapida(lead, acaoDef, { onDone }) {
  if (lead._acaoEmAndamento) return; // 30/09: evita registrar 2x com clique duplo
  lead._acaoEmAndamento = true;
  const statusAnterior = lead.status;
  if (acaoDef.status) lead.status = acaoDef.status; // otimista
  onDone();
  try {
    const promessas = [];
    if (acaoDef.status) promessas.push(updateLead(lead.id, { status: acaoDef.status }));
    promessas.push(criarAtividade({
      leadId: lead.id,
      tipo: acaoDef.tipoAtividade,
      descricao: acaoDef.descricao,
      ...(acaoDef.status ? { statusAnterior, statusNovo: acaoDef.status } : {}),
      ...(acaoDef.proximaEmDias ? { proximaEm: new Date(Date.now() + acaoDef.proximaEmDias * 86400000).toISOString() } : {}),
    }));
    await Promise.all(promessas);
    lead.ultima_atividade_em = new Date().toISOString();
    showToast(`${acaoDef.label} registrado.`, { tone: 'ok' });
    lead._acaoEmAndamento = false;
    onDone();
  } catch (err) {
    lead.status = statusAnterior; // reverte o otimismo
    lead._acaoEmAndamento = false;
    onDone();
    showToast(err.message || 'Falha ao registrar a ação — tente novamente.', { tone: 'danger' });
  }
}

/**
 * Registro automático e honesto do envio por WhatsApp: dispara no momento
 * do clique, sem exigir que o usuário volte à tela depois. Não afirma que a
 * mensagem foi "enviada e confirmada" (o navegador não tem como saber isso
 * depois que o WhatsApp abre) — só que o contato foi preparado e disparado
 * por esse canal, que é exatamente o que o sistema consegue determinar.
 * @param {object} lead
 * @param {string} mensagem
 * @param {{ onDone: () => void }} callbacks
 */
async function registrarWhatsapp(lead, mensagem, { onDone }) {
  const statusAnterior = lead.status;
  const eraNovoLead = lead.status === 'novo_lead';
  if (eraNovoLead) lead.status = 'contatado'; // otimista — único avanço automático de status desta tela
  onDone();
  try {
    const promessas = [
      criarAtividade({
        leadId: lead.id,
        tipo: 'whatsapp_enviado',
        descricao: 'Mensagem preparada e aberta no WhatsApp.',
        ...(eraNovoLead ? { statusAnterior, statusNovo: 'contatado' } : {}),
      }),
    ];
    if (eraNovoLead) promessas.push(updateLead(lead.id, { status: 'contatado' }));
    await Promise.all(promessas);
    lead.ultima_atividade_em = new Date().toISOString();
    onDone();
  } catch (err) {
    lead.status = statusAnterior;
    onDone();
    showToast('WhatsApp aberto, mas houve falha ao registrar a atividade — confira o histórico depois.', { tone: 'danger' });
  }
}

export async function renderProspeccao(container) {
  container.innerHTML = '';
  const usuarioAtual = await getCurrentUser();
  const souAdmin = ehAdmin(usuarioAtual);
  // Wrapper próprio, não a classe no container compartilhado entre telas do
  // painel — container.innerHTML é limpo a cada troca de rota, mas
  // classList NÃO é resetado automaticamente (app.js reaproveita o mesmo
  // elemento pra todas as views). Colocar a classe direto no container
  // vazaria o CSS escopado (.prospeccao-view ...) pra outras telas depois
  // que o usuário saísse desta.
  const root = document.createElement('div');
  root.className = 'prospeccao-view';
  container.appendChild(root);

  let leads = [];
  // 30/09: filtros e paginação NO SERVIDOR — a tela só guarda a página atual.
  const paramsIniciais = new URLSearchParams(window.location.hash.split('?')[1] || '');
  const filtros = {
    q: '', status: 'todos', setor: 'todos', prioridade: 'todos', periodo: 'tudo', temperatura: 'todos', faixa: 'todos',
    arquivados: paramsIniciais.get('arquivados') === 'so' ? 'so' : '0', ordem: 'score',
  };
  let pagina = 1;
  let total = 0;
  let porPagina = 50;
  let controleCarga = null;
  let taxonomia = null;
  const selectedIds = new Set();

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Prospecção</h2>
      <p>Empresas de médio/grande porte com presença online fraca — em prospecção via WhatsApp ou e-mail.</p>
    </div>
  `;
  root.appendChild(head);

  const toolbar = document.createElement('div');
  toolbar.className = 'content-toolbar';
  toolbar.innerHTML = `
    <div class="search-box-small">
      <input type="search" id="leadSearch" placeholder="Buscar por empresa…" aria-label="Buscar lead">
    </div>
    <select id="statusFilter" aria-label="Filtrar por status">
      <option value="todos">Todos os status</option>
      ${STATUS_ORDER.map((s) => `<option value="${s}">${STATUS_MAP[s].label}</option>`).join('')}
    </select>
    <select id="setorFilter" aria-label="Filtrar por setor">
      <option value="todos">Todos os setores</option>
    </select>
    <select id="temperaturaFilter" aria-label="Filtrar por temperatura">
      <option value="todos">Todas as temperaturas</option>
      <option value="quente">Quente</option><option value="morno">Morno</option><option value="frio">Frio</option>
    </select>
    <select id="faixaFilter" aria-label="Filtrar por faixa de score">
      <option value="todos">Todas as faixas</option>
      <option value="prioritario">Prioritário (&gt;90)</option><option value="prospectar">Prospectar (61–90)</option>
      <option value="nutrir">Nutrir (31–60)</option><option value="aguardar">Aguardar (≤30)</option>
    </select>
    <select id="arquivadosFilter" aria-label="Ativos ou arquivados">
      <option value="0">Ativos</option><option value="so">Arquivados</option>
    </select>
    <select id="prioridadeFilter" aria-label="Filtrar por prioridade">
      <option value="todos">Todas as prioridades</option>
      <option value="alta">Prioridade alta</option>
      <option value="media">Prioridade média</option>
      <option value="baixa">Prioridade baixa</option>
    </select>
    <select id="periodoFilter" aria-label="Filtrar por período">
      <option value="tudo">Todo o período</option>
      <option value="hoje">Hoje</option>
      <option value="semana">Últimos 7 dias</option>
      <option value="mes">Últimos 30 dias</option>
    </select>
    <button class="btn btn-ghost btn-sm" id="relatorioBtn" title="Relatório de buscas, envios e leads por período">Relatório</button>
    <button class="btn btn-ghost btn-sm" id="exportarCsvBtn" title="Exportar os leads filtrados (até 2.000) pra preencher CNPJ/porte fora do sistema">Exportar CSV</button>
    <a class="btn btn-ghost btn-sm" id="importarCsvBtn" href="#/prospeccao/captacao?modo=importar" title="Importar planilha: criar novos (com revisão) ou completar/atualizar existentes">Importar CSV</a>
    <a class="btn btn-ghost btn-sm" id="atualizarBtn" href="#/prospeccao/captacao" title="Buscar empresas por setor e cidade (Geoapify + OpenStreetMap), com revisão antes do CRM">Captar leads</a>
    <button class="btn btn-primary btn-sm" id="newLeadBtn">+ Novo lead</button>
  `;
  root.appendChild(toolbar);

  const selectionBar = document.createElement('div');
  selectionBar.className = 'content-toolbar';
  selectionBar.style.display = 'none';
  selectionBar.innerHTML = `
    <span id="selectionCount" style="font-size:.85rem;color:var(--text-muted)"></span>
    <button class="btn btn-primary btn-sm" id="enviarEmailBtn">Enviar e-mail para selecionados</button>
    <button class="btn btn-ghost btn-sm" id="arquivarSelBtn">Arquivar selecionados</button>
    ${souAdmin ? '<button class="btn btn-ghost btn-sm" id="restaurarSelBtn" style="display:none">Restaurar selecionados</button>' : ''}
    <button class="btn btn-ghost btn-sm" id="limparSelecaoBtn">Limpar seleção</button>
  `;
  root.appendChild(selectionBar);

  const listCard = document.createElement('section');
  listCard.className = 'card';
  root.appendChild(listCard);

  const editorHost = document.createElement('div');
  root.appendChild(editorHost);

  function populateSetorFilter() {
    const select = toolbar.querySelector('#setorFilter');
    const current = select.value;
    const setores = taxonomia ? taxonomia.setores.map((x) => x.id) : Array.from(new Set(leads.map((l) => l.setor).filter(Boolean))).sort();
    select.innerHTML = `<option value="todos">Todos os setores</option>${setores
      .map((s) => `<option value="${esc(s)}">${esc(s)}</option>`)
      .join('')}`;
    select.value = setores.includes(current) ? current : 'todos';
  }

  // Mesmos períodos que o relatório usa no backend (dateRangeProspeccao.js) —
  // "semana"/"mes" são janelas corridas (últimos N dias), não semana/mês civil.
  const DIAS_POR_PERIODO = { hoje: 1, semana: 7, mes: 30 };


  /** Filtros da tela → parâmetros da Function (o servidor filtra, ordena e pagina). */
  function parametrosServidor() {
    const p = { ...filtros, pagina, por_pagina: porPagina };
    if (filtros.periodo !== 'tudo') p.criado_de = new Date(Date.now() - DIAS_POR_PERIODO[filtros.periodo] * 86400000).toISOString();
    delete p.periodo;
    if (p.arquivados === '0') delete p.arquivados;
    return p;
  }

  function filteredLeads() {
    return leads; // já vêm filtrados e ordenados (score) do servidor
  }

  function renderList() {
    listCard.innerHTML = '';
    const rows = filteredLeads();

    const temFiltro = filtros.q || ['status', 'setor', 'prioridade', 'temperatura', 'faixa'].some((k) => filtros[k] !== 'todos') || filtros.periodo !== 'tudo';
    if (rows.length === 0) {
      listCard.appendChild(
        EmptyState({
          title: filtros.arquivados === 'so' ? 'Nenhum lead arquivado' : 'Nada por aqui ainda',
          description: temFiltro ? 'Nada encontrado com esses filtros.' : filtros.arquivados === 'so' ? 'Leads arquivados aparecem aqui e podem ser restaurados por um admin.' : 'Nenhum lead cadastrado ainda. Use “Captar leads” para buscar empresas.',
          actionLabel: !temFiltro && filtros.arquivados !== 'so' ? '+ Adicionar lead' : undefined,
          onAction: !temFiltro && filtros.arquivados !== 'so' ? () => openEditor(emptyLead()) : undefined,
        })
      );
      return;
    }

    const wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    const table = document.createElement('table');
    table.className = 'app-table';
    table.innerHTML = `
      <thead><tr><th style="width:2em"></th><th>Empresa</th><th>Ranking</th><th>Local</th><th>Contato</th><th>Status</th></tr></thead>
      <tbody></tbody>
    `;
    const tbody = table.querySelector('tbody');

    rows.forEach((lead) => {
      const tr = document.createElement('tr');
      const message = buildMessage(lead);
      const wa = whatsappUrl(lead.telefone, message);
      const fonteTag = (lead.fonte && lead.fonte !== 'manual'
        ? ` <span class="badge badge-demo" title="Fonte: ${esc(FONTE_LABEL[lead.fonte] || lead.fonte)}${lead.metodo_captacao ? ` · método: ${esc(lead.metodo_captacao)}` : ''}${lead.campanha ? ` · campanha: ${esc(lead.campanha)}` : ''}">${esc(FONTE_LABEL[lead.fonte] || lead.fonte)}</span>`
        : '') + (lead.arquivado_em ? ` <span class="badge badge-demo" title="Arquivado em ${new Date(lead.arquivado_em).toLocaleDateString('pt-BR')} (${esc(MOTIVOS_ARQUIVAR[lead.motivo_arquivamento] || lead.motivo_arquivamento || '')})">Arquivado</span>` : '') + temperaturaBadgeHtml(lead);
      const emailTag = lead.email_enviado_em
        ? ` <span class="badge badge-ok" title="Enviado em ${new Date(lead.email_enviado_em).toLocaleString('pt-BR')}">E-mail enviado</span>`
        : lead.email_status && lead.email_status.startsWith('erro')
        ? ` <span class="badge badge-danger" title="${esc(lead.email_status)}">Falha no envio</span>`
        : '';
      tr.innerHTML = `
        <td><input type="checkbox" data-select-lead ${selectedIds.has(lead.id) ? 'checked' : ''} aria-label="Selecionar ${esc(lead.empresa)}"></td>
        <td style="cursor:pointer"><button type="button" class="app-table-link" data-abrir-lead>${esc(lead.empresa)}</button>${fonteTag}${emailTag}${agingBadgeHtml(lead)}${lead.proxima_acao ? `<div class="lead-proxima-acao">Próxima ação: ${esc(lead.proxima_acao)}${lead.proxima_atividade_em ? ` · ${new Date(lead.proxima_atividade_em).toLocaleDateString('pt-BR')}` : ''}</div>` : ''}</td>
        <td>${rankingBadgeHtml(lead)}</td>
        <td>${esc(lead.setor || '—')}${lead.cidade ? ' · ' + esc(lead.cidade) : ''}</td>
        <td>
          ${wa ? `<a href="${wa}" target="_blank" rel="noopener" class="btn btn-ghost btn-xs" title="Abrir WhatsApp com mensagem já preenchida (registra o contato automaticamente)">WhatsApp</a>` : '—'}
        </td>
        <td><span data-status-cell>${statusBadgeHtml(lead.status || 'novo_lead')}</span><div data-acoes-rapidas>${acoesRapidasHtml(lead)}</div></td>
      `;
      tr.querySelector('[data-select-lead]').addEventListener('click', (e) => {
        e.stopPropagation();
        if (e.target.checked) selectedIds.add(lead.id);
        else selectedIds.delete(lead.id);
        updateSelectionBar();
      });
      tr.querySelectorAll('td:not(:nth-child(1)):not(:nth-child(5)):not(:nth-child(6))').forEach((td) => {
        td.style.cursor = 'pointer';
        td.addEventListener('click', () => openEditor(lead));
      });
      // Copiar mensagem/e-mail saíram da linha da tabela (deixava muito
      // poluído) — continuam disponíveis dentro do painel de edição
      // (openEditor), que já tinha "Copiar mensagem"; adicionei "Copiar
      // e-mail" lá também, pra não perder a função.
      // AÇÃO → REGISTRO → FEEDBACK, sem recarregar a tela inteira: só a
      // célula de status/badges desta linha é atualizada depois da ação.
      function atualizarCelulaDaLinha() {
        tr.querySelector('[data-status-cell]').innerHTML = statusBadgeHtml(lead.status || 'novo_lead');
        const empresaCell = tr.children[1];
        // 30/09: mantém o botão de abrir (antes sumia depois de uma ação rápida)
        empresaCell.innerHTML = `<button type="button" class="app-table-link" data-abrir-lead>${esc(lead.empresa)}</button>${fonteTag}${emailTag}${agingBadgeHtml(lead)}`;
        tr.querySelector('[data-acoes-rapidas]').innerHTML = acoesRapidasHtml(lead);
        wireAcoesRapidas();
      }
      function wireAcoesRapidas() {
        tr.querySelectorAll('[data-acao-rapida]').forEach((btn) => {
          btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const acaoDef = ACOES_RAPIDAS.find((a) => a.id === btn.dataset.acaoRapida);
            await aplicarAcaoRapida(lead, acaoDef, { onDone: atualizarCelulaDaLinha });
          });
        });
      }
      wireAcoesRapidas();
      const waLink = tr.querySelector('a[href^="https://wa.me/"]');
      if (waLink) {
        waLink.addEventListener('click', (e) => {
          e.stopPropagation();
          // Não usa preventDefault — o link abre o WhatsApp normalmente (nova
          // aba); o registro roda em paralelo, sem travar nem exigir volta à tela.
          registrarWhatsapp(lead, message, { onDone: atualizarCelulaDaLinha });
        });
      }
      tbody.appendChild(tr);
    });

    wrap.appendChild(table);
    listCard.appendChild(wrap);
    const paginas = Math.max(1, Math.ceil((total || 0) / porPagina));
    const rodape = document.createElement('div');
    rodape.className = 'captacao-paginacao';
    rodape.innerHTML = `
      <span class="captacao-dica">${total ?? rows.length} lead(s)${paginas > 1 ? ` · página ${pagina} de ${paginas}` : ''}</span>
      ${paginas > 1 ? `<button class="btn btn-ghost btn-sm" data-pag="-1" ${pagina <= 1 ? 'disabled' : ''}>Anterior</button>
      <button class="btn btn-ghost btn-sm" data-pag="1" ${pagina >= paginas ? 'disabled' : ''}>Próxima</button>` : ''}`;
    rodape.querySelectorAll('[data-pag]').forEach((b) => b.addEventListener('click', () => { pagina += Number(b.dataset.pag); load(); }));
    listCard.appendChild(rodape);
    updateSelectionBar();
  }

  function updateSelectionBar() {
    // remove seleção de leads que saíram da lista carregada (ex: excluídos)
    const idsAtuais = new Set(leads.map((l) => l.id));
    Array.from(selectedIds).forEach((id) => { if (!idsAtuais.has(id)) selectedIds.delete(id); });

    if (selectedIds.size === 0) {
      selectionBar.style.display = 'none';
      return;
    }
    selectionBar.style.display = 'flex';
    const comEmail = leads.filter((l) => selectedIds.has(l.id) && l.email).length;
    selectionBar.querySelector('#selectionCount').textContent =
      `${selectedIds.size} selecionado(s) — ${comEmail} com e-mail cadastrado`;
    const arquivados = filtros.arquivados === 'so';
    selectionBar.querySelector('#enviarEmailBtn').style.display = arquivados ? 'none' : '';
    selectionBar.querySelector('#arquivarSelBtn').style.display = arquivados ? 'none' : '';
    const rest = selectionBar.querySelector('#restaurarSelBtn');
    if (rest) rest.style.display = arquivados ? '' : 'none';
  }

  /** Arquivar (dono ou admin) — pede o motivo. Nunca apaga. */
  function pedirArquivamento(ids, aoConcluir) {
    const { box, close } = abrirModal(`
      <h3 style="font-size:1.05rem;margin-bottom:var(--space-2)">Arquivar ${ids.length} lead(s)</h3>
      <p class="captacao-dica" style="margin-bottom:var(--space-3)">Arquivado sai da lista e do funil, continua valendo para evitar duplicatas e pode ser restaurado por um admin. Nada é apagado.</p>
      <div class="field"><label for="arqMotivo">Motivo</label><select id="arqMotivo">${Object.entries(MOTIVOS_ARQUIVAR).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div>
      <div class="field"><label for="arqObs">Observação (opcional)</label><input id="arqObs" maxlength="500"></div>
      <div style="display:flex;justify-content:flex-end;gap:var(--space-2);margin-top:var(--space-4)">
        <button class="btn btn-ghost btn-sm" id="arqCancelar">Cancelar</button><button class="btn btn-primary btn-sm" id="arqOk">Arquivar</button></div>`);
    box.querySelector('#arqCancelar').addEventListener('click', close);
    const ok = box.querySelector('#arqOk');
    ok.addEventListener('click', async () => {
      ok.disabled = true;
      try {
        const r = await arquivarLeads(ids, box.querySelector('#arqMotivo').value, box.querySelector('#arqObs').value.trim());
        showToast(`${r.arquivados} lead(s) arquivado(s).${r.arquivados < ids.length ? ' Os demais não são seus (só admin arquiva lead de outra pessoa).' : ''}`, { tone: 'ok' });
        close();
        if (aoConcluir) aoConcluir();
      } catch (err) { showToast(err.message, { tone: 'danger' }); ok.disabled = false; }
    });
  }

  selectionBar.querySelector('#arquivarSelBtn').addEventListener('click', () => pedirArquivamento(Array.from(selectedIds), () => { selectedIds.clear(); load(); }));
  const restaurarSelBtn = selectionBar.querySelector('#restaurarSelBtn');
  if (restaurarSelBtn) restaurarSelBtn.addEventListener('click', async () => {
    try {
      const r = await restaurarLeads(Array.from(selectedIds));
      showToast(`${r.restaurados} lead(s) restaurado(s).`, { tone: 'ok' });
      selectedIds.clear();
      load();
    } catch (err) { showToast(err.message, { tone: 'danger' }); }
  });

  selectionBar.querySelector('#limparSelecaoBtn').addEventListener('click', () => {
    selectedIds.clear();
    updateSelectionBar();
    renderList();
  });

  selectionBar.querySelector('#enviarEmailBtn').addEventListener('click', () => abrirPopupEnviarEmail());


  // Anexa dentro de `root` (não document.body) — o CSS escopado desta tela
  // só vale dentro de .prospeccao-view. 29/09: modal compartilhado (foco
  // preso, Esc, foco devolvido, nome acessível).
  function abrirModal(innerHtml) {
    return abrirModalBase({ html: innerHtml, host: root, maxWidth: '520px' });
  }

  function formatarDataHora(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  async function exportarCSV() {
    let linhas;
    try {
      const { pagina: _p, por_pagina: _pp, ...f } = parametrosServidor();
      linhas = await fetchTodosLeads(f, 2000);
    } catch (err) { showToast(err.message || 'Falha ao exportar.', { tone: 'danger' }); return; }
    if (!linhas.length) { showToast('Nenhum lead pra exportar com os filtros atuais.', { tone: 'danger' }); return; }
    const csv = leadsParaCSV(linhas);
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }); // BOM pro Excel abrir acentuação certo
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `leads-prospeccao-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`${linhas.length} lead(s) exportado(s). Preencha CNPJ/porte/etc. e importe de volta pelo mesmo arquivo.`, { tone: 'ok' });
  }

  async function abrirRelatorio() {
    const periodoInicial = filtros.periodo === 'tudo' ? 'mes' : filtros.periodo; // "tudo" tende a ser muito genérico pro relatório — parte de um período mais útil por padrão
    const { box, close } = abrirModal(`
      <h3 style="font-size:1.05rem;margin-bottom:var(--space-2)">Relatório de Prospecção</h3>
      <div class="field field-full" style="margin-bottom:var(--space-3)">
        <label for="relatorioPeriodo">Período</label>
        <select id="relatorioPeriodo">
          <option value="hoje">Hoje</option>
          <option value="semana">Últimos 7 dias</option>
          <option value="mes" selected>Últimos 30 dias</option>
          <option value="tudo">Todo o período</option>
        </select>
      </div>
      <div id="relatorioConteudo" style="min-height:80px"><p style="color:var(--text-muted);font-size:.85rem">Carregando…</p></div>
      <div style="display:flex;justify-content:flex-end;margin-top:var(--space-4)">
        <button class="btn btn-ghost btn-sm" id="fecharRelatorioBtn">Fechar</button>
      </div>
    `);
    box.style.maxWidth = '640px';
    box.querySelector('#relatorioPeriodo').value = periodoInicial;
    box.querySelector('#fecharRelatorioBtn').addEventListener('click', close);
    box.querySelector('#relatorioPeriodo').addEventListener('change', (e) => carregarRelatorio(box, e.target.value));
    carregarRelatorio(box, periodoInicial);
  }

  async function carregarRelatorio(box, periodo) {
    const host = box.querySelector('#relatorioConteudo');
    if (!host) return; // popup fechado antes de terminar de carregar
    host.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem">Carregando…</p>';
    try {
      const dados = await buscarRelatorio(periodo);
      if (!box.isConnected) return;
      renderRelatorio(host, dados);
    } catch (err) {
      if (box.isConnected) host.innerHTML = `<p style="color:var(--danger);font-size:.85rem">${esc(err.message || 'Falha ao carregar relatório.')}</p>`;
    }
  }

  function renderRelatorio(host, dados) {
    const r = dados.resumo || {};
    const fontesTexto = Object.entries(r.leadsPorFonte || {})
      .map(([fonte, n]) => `${n} ${esc(FONTE_LABEL[fonte] || fonte)}`)
      .join(', ');

    const linhasEnvios = (dados.envios || [])
      .map((e) => {
        const res = e.resumo || {};
        return `<tr>
          <td>${formatarDataHora(e.created_at)}</td>
          <td>${res.enviados || 0}</td>
          <td>${res.falhas || 0}</td>
          <td>${res.semEmail || 0}</td>
          <td>${res.adiados || 0}</td>
        </tr>`;
      })
      .join('');

    const linhasBuscas = (dados.buscas || [])
      .map(
        (b) => `<tr>
          <td>${formatarDataHora(b.created_at)}</td>
          <td>${esc((b.cidades || []).join(', '))}</td>
          <td>${esc(b.ramo || '—')}</td>
          <td>${b.total_encontrado ?? '—'}</td>
        </tr>`
      )
      .join('');

    host.innerHTML = `
      <p style="color:var(--text-muted);font-size:.82rem;margin-bottom:var(--space-3)">${dados.periodo?.label || ''}</p>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:var(--space-3);margin-bottom:var(--space-5)">
        <div class="card" style="padding:var(--space-3);margin:0"><div style="font-size:1.4rem;font-weight:700">${r.emailsEnviados || 0}</div><div style="font-size:.75rem;color:var(--text-muted)">E-mails enviados</div></div>
        <div class="card" style="padding:var(--space-3);margin:0"><div style="font-size:1.4rem;font-weight:700">${r.emailsComFalha || 0}</div><div style="font-size:.75rem;color:var(--text-muted)">Falhas de envio</div></div>
        <div class="card" style="padding:var(--space-3);margin:0"><div style="font-size:1.4rem;font-weight:700">${r.buscasRealizadas || 0}</div><div style="font-size:.75rem;color:var(--text-muted)">Buscas realizadas</div></div>
        <div class="card" style="padding:var(--space-3);margin:0"><div style="font-size:1.4rem;font-weight:700">${r.empresasEncontradas || 0}</div><div style="font-size:.75rem;color:var(--text-muted)">Empresas encontradas</div></div>
        <div class="card" style="padding:var(--space-3);margin:0"><div style="font-size:1.4rem;font-weight:700">${r.leadsNoPeriodo || 0}</div><div style="font-size:.75rem;color:var(--text-muted)">Leads novos${fontesTexto ? ` (${fontesTexto})` : ''}</div></div>
      </div>

      <h4 style="font-size:.9rem;margin-bottom:var(--space-2)">Envios de e-mail</h4>
      ${
        linhasEnvios
          ? `<div class="table-wrap" style="margin-bottom:var(--space-5)"><table class="app-table"><thead><tr><th>Quando</th><th>Enviados</th><th>Falhas</th><th>Sem e-mail</th><th>Adiados</th></tr></thead><tbody>${linhasEnvios}</tbody></table></div>`
          : '<p style="color:var(--text-muted);font-size:.85rem;margin-bottom:var(--space-5)">Nenhum envio nesse período.</p>'
      }

      <h4 style="font-size:.9rem;margin-bottom:var(--space-2)">Buscas de empresas</h4>
      ${
        linhasBuscas
          ? `<div class="table-wrap"><table class="app-table"><thead><tr><th>Quando</th><th>Cidades</th><th>Ramo</th><th>Encontradas</th></tr></thead><tbody>${linhasBuscas}</tbody></table></div>`
          : '<p style="color:var(--text-muted);font-size:.85rem">Nenhuma busca nesse período.</p>'
      }
    `;
  }

  function abrirPopupEnviarEmail() {
    const idsSelecionados = Array.from(selectedIds);
    const selecionados = leads.filter((l) => idsSelecionados.includes(l.id));
    const comEmail = selecionados.filter((l) => l.email);
    const semEmail = selecionados.length - comEmail.length;

    const { box, close } = abrirModal(`
      <h3 style="font-size:1.05rem;margin-bottom:var(--space-2)">Enviar e-mail para ${comEmail.length} empresa(s)</h3>
      <p style="color:var(--text-muted);font-size:.85rem;margin-bottom:var(--space-4)">
        ${semEmail > 0 ? `${semEmail} selecionado(s) sem e-mail cadastrado será(ão) ignorado(s). ` : ''}
        Envio de um por vez, com pausa entre eles, respeitando o limite diário da conta. Use
        <code>{{empresa}}</code>, <code>{{setor}}</code> e <code>{{cidade}}</code> pra personalizar.
      </p>
      <div class="content-editor-form">
        <div class="field"><label for="assuntoEmail">Assunto *</label><input id="assuntoEmail" value="Uma ideia para a {{empresa}}"></div>
        <div class="field field-full">
          <label for="corpoEmail">Corpo *</label>
          <textarea id="corpoEmail" rows="8">Olá,

Meu nome é Felipe, da Felipe Branding, agência de identidade visual e marca aqui de Petrolina.

Estive olhando a {{empresa}} e fiquei curioso sobre como a marca de vocês se apresenta hoje pra quem está conhecendo ela pela primeira vez.

Se fizer sentido, gostaria de conversar alguns minutos, sem compromisso, sobre isso. Posso ligar essa semana?

Abraço,
Felipe Souto</textarea>
        </div>
      </div>
      <div id="envioProgressoHost"></div>
      <div style="display:flex;gap:var(--space-2);margin-top:var(--space-4);justify-content:flex-end" id="envioAcoesHost">
        <button class="btn btn-ghost btn-sm" id="cancelarEnvioBtn">Cancelar</button>
        <button class="btn btn-primary btn-sm" id="confirmarEnvioBtn">Iniciar envio</button>
      </div>
    `);
    box.querySelector('#cancelarEnvioBtn').addEventListener('click', close);
    box.querySelector('#confirmarEnvioBtn').addEventListener('click', async () => {
      const assunto = box.querySelector('#assuntoEmail').value.trim();
      const corpo = box.querySelector('#corpoEmail').value.trim();
      if (!assunto || !corpo) { showToast('Preencha assunto e corpo.', { tone: 'danger' }); return; }

      const ok = await confirmDialog({
        title: 'Confirmar envio?',
        description: `Isso vai enviar e-mail de verdade para ${comEmail.length} empresa(s), a partir de marketing@felipebranding.com.br.`,
        confirmLabel: 'Enviar',
        tone: 'default',
      });
      if (!ok) return;

      const btn = box.querySelector('#confirmarEnvioBtn');
      btn.disabled = true;
      btn.textContent = 'Iniciando…';

      const progressoHost = box.querySelector('#envioProgressoHost');
      box.querySelector('.content-editor-form').style.display = 'none';
      box.querySelector('#envioAcoesHost').style.display = 'none';
      progressoHost.innerHTML = `
        <span class="progresso-barra-texto" id="envioBarraTexto">0 de ${comEmail.length} e-mail(is)</span>
        <div class="progresso-barra"><div class="progresso-barra-preenchimento" id="envioBarraFill"></div></div>
        <ul id="envioProgressoLista" class="progresso-lista" style="list-style:none;display:flex;flex-direction:column;margin-bottom:var(--space-4);max-height:280px;overflow:auto">
          ${comEmail.map((l) => `<li data-empresa="${esc(l.empresa)}" style="font-size:.85rem;color:var(--text-muted)">⏳ ${esc(l.empresa)} — aguardando</li>`).join('')}
        </ul>
        <p id="envioResumo" style="font-size:.85rem;color:var(--text-muted)"></p>
        <div style="display:flex;justify-content:flex-end;margin-top:var(--space-3)">
          <button class="btn btn-ghost btn-sm" id="fecharEnvioBtn" style="display:none">Fechar</button>
        </div>
      `;
      box.addEventListener('click', (e) => { if (e.target.id === 'fecharEnvioBtn') close(); });

      try {
        const jobId = await enviarEmails(idsSelecionados, assunto, corpo);
        selectedIds.clear();
        pollStatusEnvio(box, jobId, 0, comEmail.length);
      } catch (err) {
        progressoHost.querySelector('#envioResumo').textContent = err.message || 'Falha ao iniciar envio.';
        progressoHost.querySelector('#fecharEnvioBtn').style.display = '';
      }
    });
  }

  function pollStatusEnvio(box, jobId, tentativa = 0, totalEmails = 1) {
    const MAX_TENTATIVAS = 90; // envio é mais lento que a busca (pausa de 4s por lead) — dá mais tempo
    consultarStatusEnvio(jobId)
      .then((envio) => {
        if (!envio) {
          if (tentativa < MAX_TENTATIVAS) setTimeout(() => pollStatusEnvio(box, jobId, tentativa + 1, totalEmails), 2000);
          return;
        }

        const lista = box.querySelector('#envioProgressoLista');
        const resumo = box.querySelector('#envioResumo');
        if (!lista) return; // popup já foi fechado

        const feitos = (envio.progresso || []).length;
        const fill = box.querySelector('#envioBarraFill');
        const barraTexto = box.querySelector('#envioBarraTexto');
        if (fill) fill.style.width = `${Math.min(100, Math.round((feitos / totalEmails) * 100))}%`;
        if (barraTexto) barraTexto.textContent = `${feitos} de ${totalEmails} e-mail(is)`;

        (envio.progresso || []).forEach((entrada) => {
          const item = lista.querySelector(`li[data-empresa="${CSS.escape(entrada.empresa)}"]`);
          if (!item) return;
          item.textContent = entrada.ok ? `✅ ${entrada.empresa} — enviado` : `⚠️ ${entrada.empresa} — ${entrada.erro || 'falha'}`;
          item.style.color = entrada.ok ? 'var(--text)' : 'var(--danger)';
        });

        if (envio.status === 'em_andamento') {
          if (tentativa < MAX_TENTATIVAS) setTimeout(() => pollStatusEnvio(box, jobId, tentativa + 1, totalEmails), 2000);
          else resumo.textContent = 'Isso está demorando mais que o esperado — confira de novo em alguns minutos ou veja os logs da function no Netlify.';
          return;
        }

        if (envio.status === 'concluido') {
          if (fill) fill.style.width = '100%';
          const r = envio.resumo || {};
          const partes = [`${r.enviados || 0} enviado(s)`];
          if (r.falhas) partes.push(`${r.falhas} falha(s)`);
          if (r.semEmail) partes.push(`${r.semEmail} sem e-mail (ignorado)`);
          if (r.adiados) partes.push(`${r.adiados} adiado(s) pro próximo dia (limite diário)`);
          if (r.bloqueados) partes.push(`${r.bloqueados} bloqueado(s) por opt-out`);
          resumo.textContent = `Concluído: ${partes.join(', ')}.`;
          box.querySelector('#fecharEnvioBtn').style.display = '';
          updateSelectionBar();
          load(); // reflete os badges de "E-mail enviado" na lista
          return;
        }

        if (envio.status === 'erro') {
          resumo.textContent = `Falha no envio: ${envio.mensagem_erro || 'erro desconhecido'}.`;
          resumo.style.color = 'var(--danger)';
          box.querySelector('#fecharEnvioBtn').style.display = '';
        }
      })
      .catch((err) => {
        const resumo = box.querySelector('#envioResumo');
        if (resumo) {
          resumo.textContent = `Falha ao consultar progresso: ${err.message}`;
          box.querySelector('#fecharEnvioBtn').style.display = '';
        }
      });
  }

  function emptyLead() {
    return {
      empresa: '',
      setor: '',
      telefone: '',
      email: '',
      endereco: '',
      cidade: '',
      site: '',
      avaliacao_google: '',
      anos_mercado: '',
      funcao_contato: '',
      prioridade: 'media',
      motivo: '',
      canal_sugerido: '',
      status: 'novo_lead',
      status_lead: 'novo',
      status_contato: 'sem_contato',
      problema_identificado: '',
      evidencia_problema: '',
      oferta_recomendada: '',
      sinal_site_desatualizado: false,
      sinal_instagram_desorganizado: false,
      sinal_gbp_fraco: false,
      sinal_porte_medio_grande: false,
      sinal_segmento_alto_potencial: false,
      sinal_email_validado: false,
      score: 0,
      cnpj: '',
      observacoes: '',
    };
  }

  function openEditor(lead) {
    editorHost.innerHTML = '';
    const isNew = !lead.id;
    // 30/09: o score é do BANCO (migration 008) — a tela só exibe o que foi calculado lá.
    const scoreAtual = { score: lead.score || 0, motivos: Array.isArray(lead.score_motivos) ? lead.score_motivos : [] };
    const panel = document.createElement('section');
    panel.className = 'card';
    panel.style.marginTop = 'var(--space-5)';
    panel.innerHTML = `
      <div class="card-head"><h3>${isNew ? 'Novo lead' : esc(lead.empresa)}</h3></div>
      ${!isNew ? `
      <div class="card" id="scoreCard" style="background:var(--bg-soft);margin-bottom:var(--space-5)">
        <div style="display:flex;align-items:baseline;gap:var(--space-3);flex-wrap:wrap">
          <span style="font-size:1.8rem;font-weight:700" id="scoreNumero">${scoreAtual.score}</span>
          <span style="font-size:.85rem;color:var(--text-muted)" id="scoreFaixa">${faixaScore(scoreAtual.score).label}</span>${temperaturaBadgeHtml(lead)}
        </div>
        <p style="font-size:.75rem;color:var(--text-muted);margin-top:4px">Calculado pelo sistema${lead.score_calculado_em ? ` em ${new Date(lead.score_calculado_em).toLocaleString('pt-BR')}` : ''}. Recalcula sozinho ao salvar.</p>
        ${composicaoScoreHtml(scoreAtual.motivos)}
        <p class="lead-potencial">${potencialEngajamentoTexto(lead)}</p>
        ${CONTATABILIDADE[lead.contatabilidade] ? `<p class="lead-contato"><span class="badge ${CONTATABILIDADE[lead.contatabilidade].cls}">${CONTATABILIDADE[lead.contatabilidade].label}</span> <span style="font-size:.78rem;color:var(--text-muted)">${CONTATABILIDADE[lead.contatabilidade].dica}</span></p>` : ''}
        <div id="oportunidadesHost"></div>
        <details id="scoreHistoricoHost" style="margin-top:var(--space-2)"><summary style="font-size:.8rem;color:var(--text-muted)">Evolução do score</summary><p style="font-size:.8rem;color:var(--text-muted)">Carregando…</p></details>
      </div>
      <div class="card" id="proximaAcaoHost" style="margin-bottom:var(--space-5)">
        <div class="card-head"><h3>Próxima ação</h3></div>
        <p style="font-size:.85rem;color:var(--text-muted)">Carregando…</p>
      </div>` : ''}
      ${lead.arquivado_em ? `<p class="captacao-aviso">Arquivado em ${new Date(lead.arquivado_em).toLocaleString('pt-BR')} — ${esc(MOTIVOS_ARQUIVAR[lead.motivo_arquivamento] || lead.motivo_arquivamento || '')}${lead.arquivado_por ? ` (por ${esc(lead.arquivado_por)})` : ''}.</p>` : ''}
      <div class="content-editor-form">
        <div class="field"><label for="f_empresa">Empresa *</label><input id="f_empresa" value="${esc(lead.empresa || '')}"></div>
        <div class="field"><label for="f_setor">Setor</label><input id="f_setor" value="${esc(lead.setor || '')}"></div>
        <div class="field"><label for="f_telefone">Telefone/WhatsApp</label><input id="f_telefone" value="${esc(lead.telefone || '')}"></div>
        <div class="field"><label for="f_email">E-mail</label><input id="f_email" value="${esc(lead.email || '')}"></div>
        <div class="field"><label for="f_funcao">Função do contato</label><input id="f_funcao" placeholder="Ex: Sócio-diretor" value="${esc(lead.funcao_contato || '')}"></div>
        <div class="field"><label for="f_endereco">Endereço</label><input id="f_endereco" value="${esc(lead.endereco || '')}"></div>
        <div class="field"><label for="f_cidade">Cidade</label><input id="f_cidade" value="${esc(lead.cidade || '')}"></div>
        <div class="field"><label for="f_site">Site</label><input id="f_site" value="${esc(lead.site || '')}"></div>
        <div class="field"><label for="f_cnpj">CNPJ</label><input id="f_cnpj" placeholder="Preenchido manualmente (ex: consultando no CNPJ.ws)" value="${esc(lead.cnpj || '')}"></div>
        <div class="field"><label for="f_anos">Anos de mercado</label><input id="f_anos" placeholder="Ex: 12 anos, desde 2008" value="${esc(lead.anos_mercado || '')}"></div>
        <div class="field"><label for="f_avaliacao">Avaliação Google</label><input id="f_avaliacao" value="${esc(lead.avaliacao_google || '')}"></div>
        <div class="field"><label for="f_canal">Canal sugerido</label><input id="f_canal" value="${esc(lead.canal_sugerido || '')}"></div>
        <div class="field">
          <label for="f_status">Estágio da oportunidade</label>
          <select id="f_status">${STATUS_ORDER.map((s) => `<option value="${s}" ${s === (lead.status || 'novo_lead') ? 'selected' : ''}>${STATUS_MAP[s].label}</option>`).join('')}</select>
        </div>
        <div class="field">
          <label for="f_prioridade">Prioridade</label>
          <select id="f_prioridade">${Object.keys(PRIORIDADE_MAP).map((p) => `<option value="${p}" ${p === (lead.prioridade || 'media') ? 'selected' : ''}>${PRIORIDADE_MAP[p].label}</option>`).join('')}</select>
        </div>
        <div class="field">
          <label for="f_status_lead">Qualidade do lead</label>
          <select id="f_status_lead">${Object.keys(STATUS_LEAD_MAP).map((s) => `<option value="${s}" ${s === (lead.status_lead || 'novo') ? 'selected' : ''}>${STATUS_LEAD_MAP[s]}</option>`).join('')}</select>
        </div>
        <div class="field">
          <label for="f_status_contato">Prontidão de contato</label>
          <select id="f_status_contato">${Object.keys(STATUS_CONTATO_MAP).map((s) => `<option value="${s}" ${s === (lead.status_contato || 'sem_contato') ? 'selected' : ''}>${STATUS_CONTATO_MAP[s]}</option>`).join('')}</select>
        </div>
        <div class="field field-full">
          <label>Sinais (marque só o que você verificou)</label>
          <div style="display:flex;flex-wrap:wrap;gap:var(--space-3)">
            <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;font-weight:400"><input type="checkbox" id="s_site_desatualizado" ${lead.sinal_site_desatualizado ? 'checked' : ''}> Site desatualizado/com problema</label>
            <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;font-weight:400"><input type="checkbox" id="s_instagram" ${lead.sinal_instagram_desorganizado ? 'checked' : ''}> Instagram ativo mas desorganizado</label>
            <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;font-weight:400"><input type="checkbox" id="s_gbp" ${lead.sinal_gbp_fraco ? 'checked' : ''}> Google Business Profile fraco</label>
            <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;font-weight:400"><input type="checkbox" id="s_porte" ${lead.sinal_porte_medio_grande ? 'checked' : ''}> Médio/grande porte</label>
            <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;font-weight:400"><input type="checkbox" id="s_segmento" ${lead.sinal_segmento_alto_potencial ? 'checked' : ''}> Segmento de alto potencial</label>
            <label style="display:flex;align-items:center;gap:6px;font-size:.85rem;font-weight:400"><input type="checkbox" id="s_email_validado" ${lead.sinal_email_validado ? 'checked' : ''}> E-mail validado</label>
          </div>
        </div>
        <div class="field field-full"><label for="f_problema">Problema identificado</label><textarea id="f_problema" rows="2" placeholder="Ex: Instagram ativo, mas sem link para orçamento">${esc(lead.problema_identificado || '')}</textarea></div>
        <div class="field field-full"><label for="f_evidencia">Evidência</label><textarea id="f_evidencia" rows="2" placeholder="Ex: 18 publicações nos últimos 30 dias e nenhum CTA">${esc(lead.evidencia_problema || '')}</textarea></div>
        <div class="field field-full"><label for="f_oferta">Oferta recomendada</label><textarea id="f_oferta" rows="2">${esc(lead.oferta_recomendada || '')}</textarea></div>
        <div class="field field-full"><label for="f_motivo">Por que se encaixa</label><textarea id="f_motivo" rows="2">${esc(lead.motivo || '')}</textarea></div>
        <div class="field field-full"><label for="f_obs">Observações</label><textarea id="f_obs" rows="3">${esc(lead.observacoes || '')}</textarea></div>
      </div>
      ${
        !isNew
          ? `
      <div class="card-head" style="margin-top:var(--space-5)"><h3>Contatos</h3></div>
      <div id="contatosHost"><p style="color:var(--text-muted);font-size:.85rem">Carregando…</p></div>

      <div class="card-head" style="margin-top:var(--space-5)"><h3>Atividades</h3></div>
      <div id="atividadesHost"><p style="color:var(--text-muted);font-size:.85rem">Carregando…</p></div>

      <div class="card-head" style="margin-top:var(--space-5)"><h3>Mensagem personalizada</h3></div>
      <p style="color:var(--text-muted);font-size:.82rem;margin-bottom:var(--space-2)">
        Gerada automaticamente com o nome e a avaliação da empresa. Ajuste o texto à vontade antes de copiar ou enviar.
      </p>
      <div class="field field-full"><textarea id="f_mensagem" rows="7">${esc(buildMessage(lead))}</textarea></div>
      <div style="display:flex;gap:var(--space-2);flex-wrap:wrap">
        <button class="btn btn-ghost btn-sm" id="copyMessageBtn">Copiar mensagem</button>
        ${lead.email ? `<button class="btn btn-ghost btn-sm" id="copyEmailBtn" data-copy-email="${esc(lead.email)}">Copiar e-mail</button>` : ''}
        ${
          whatsappUrl(lead.telefone)
            ? `<button class="btn btn-primary btn-sm" id="waMessageBtn">Abrir WhatsApp com esta mensagem</button>`
            : ''
        }
      </div>
      `
          : ''
      }
      <div style="display:flex;gap:var(--space-2);margin-top:var(--space-4);flex-wrap:wrap">
        <button class="btn btn-primary btn-sm" id="saveLeadBtn">${isNew ? 'Criar lead' : 'Salvar alterações'}</button>
        ${!isNew ? '<button class="btn btn-ghost btn-sm" id="optoutBtn" title="Bloqueia contato permanentemente, mesmo se a empresa for encontrada de novo numa busca futura">Registrar opt-out</button>' : ''}
        ${!isNew && !lead.arquivado_em ? '<button class="btn btn-ghost btn-sm" id="arquivarLeadBtn">Arquivar</button>' : ''}
        ${!isNew && lead.arquivado_em && souAdmin ? '<button class="btn btn-ghost btn-sm" id="restaurarLeadBtn">Restaurar</button>' : ''}
        ${!isNew && lead.arquivado_em && souAdmin ? '<button class="btn btn-danger btn-sm" id="deleteLeadBtn">Excluir definitivamente</button>' : ''}
        <button class="btn btn-ghost btn-sm" id="cancelLeadBtn">Cancelar</button>
      </div>
    `;
    editorHost.appendChild(panel);
    editorHost.scrollIntoView({ behavior: 'smooth', block: 'start' });
    if (!isNew) montarOperacao(panel, lead);

    let contatosAtuais = [];



    // Score não é mais calculado no navegador (30/09): o banco recalcula ao salvar.
    function recalcularScoreNaTela() {}

    async function carregarOportunidades() {
      const host = panel.querySelector('#oportunidadesHost');
      if (!host) return;
      try {
        const completo = await fetchLead(lead.id);
        const ops = ((completo && completo.admin_prospeccao_oportunidades) || []).filter((o) => !o.descartado);
        if (!ops.length) return;
        const nomes = (taxonomia && taxonomia.oportunidades) || {};
        host.innerHTML = `<p style="font-size:.8rem;font-weight:600;margin-top:var(--space-3)">Oportunidades</p><ul style="font-size:.8rem;color:var(--text-muted);padding-left:1.1em">${ops.map((o) => `<li><strong>${esc((nomes[o.tipo] || {}).label || o.tipo)}</strong> — ${esc(o.evidencia)} <span title="Confiança / fonte">(${esc(o.confianca)}, ${esc(o.fonte)}${o.confirmado ? ', confirmado' : ''})</span></li>`).join('')}</ul>`;
      } catch { /* opcional */ }
    }

    async function carregarContatos() {
      const host = panel.querySelector('#contatosHost');
      if (!host) return;
      try {
        contatosAtuais = await listarContatos(lead.id);
        recalcularScoreNaTela(); // agora com temContatoDecisor real, não o placeholder
        renderContatos(host);
      } catch (err) {
        host.innerHTML = `<p style="color:var(--danger);font-size:.85rem">${esc(err.message || 'Falha ao carregar contatos.')}</p>`;
      }
    }

    function renderContatos(host) {
      host.innerHTML = `
        <ul style="list-style:none;margin-bottom:var(--space-3)">
          ${contatosAtuais.map((c) => `
            <li style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;padding:6px 0;border-bottom:1px solid var(--border);font-size:.85rem">
              <span style="min-width:0;overflow-wrap:anywhere">${c.principal ? '⭐ ' : ''}<strong>${esc(c.nome)}</strong>${c.cargo ? ` — ${esc(c.cargo)}` : ''}${c.email ? ` · ${esc(c.email)}` : ''}${c.whatsapp ? ` · ${esc(c.whatsapp)}` : ''}</span>
              <button class="btn btn-ghost btn-sm" data-del-contato="${c.id}">Remover</button>
            </li>
          `).join('') || '<li style="font-size:.85rem;color:var(--text-muted)">Nenhum contato cadastrado.</li>'}
        </ul>
        <div style="display:flex;gap:var(--space-2);flex-wrap:wrap;align-items:flex-end">
          <div class="field" style="margin:0"><label for="novoContatoNome">Nome</label><input id="novoContatoNome" style="width:160px"></div>
          <div class="field" style="margin:0"><label for="novoContatoCargo">Cargo</label><input id="novoContatoCargo" style="width:140px"></div>
          <div class="field" style="margin:0"><label for="novoContatoEmail">E-mail</label><input id="novoContatoEmail" style="width:180px"></div>
          <div class="field" style="margin:0"><label for="novoContatoWhatsapp">WhatsApp</label><input id="novoContatoWhatsapp" style="width:140px"></div>
          <button class="btn btn-primary btn-sm" id="addContatoBtn">Adicionar</button>
        </div>
      `;
      host.querySelectorAll('[data-del-contato]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          try {
            await removerContato(btn.dataset.delContato);
            contatosAtuais = contatosAtuais.filter((c) => c.id !== btn.dataset.delContato);
            recalcularScoreNaTela();
            renderContatos(host);
          } catch (err) {
            showToast(err.message || 'Falha ao remover contato.', { tone: 'danger' });
          }
        });
      });
      host.querySelector('#addContatoBtn').addEventListener('click', async () => {
        const nome = host.querySelector('#novoContatoNome').value.trim();
        if (!nome) { showToast('Informe o nome do contato.', { tone: 'danger' }); return; }
        try {
          const criado = await criarContato({
            leadId: lead.id,
            nome,
            cargo: host.querySelector('#novoContatoCargo').value.trim(),
            email: host.querySelector('#novoContatoEmail').value.trim(),
            whatsapp: host.querySelector('#novoContatoWhatsapp').value.trim(),
          });
          contatosAtuais.push(criado);
          recalcularScoreNaTela();
          renderContatos(host);
        } catch (err) {
          showToast(err.message || 'Falha ao adicionar contato.', { tone: 'danger' });
        }
      });
    }

    async function carregarAtividades() {
      const host = panel.querySelector('#atividadesHost');
      if (!host) return;
      try {
        const atividades = await listarAtividades(lead.id);
        renderAtividades(host, atividades);
      } catch (err) {
        host.innerHTML = `<p style="color:var(--danger);font-size:.85rem">${esc(err.message || 'Falha ao carregar atividades.')}</p>`;
      }
    }

    function renderAtividades(host, atividades) {
      host.innerHTML = `
        <ul style="list-style:none;margin-bottom:var(--space-3)">
          ${atividades.map((a) => `
            <li style="padding:6px 0;border-bottom:1px solid var(--border);font-size:.85rem">
              <strong>${TIPO_ATIVIDADE_MAP[a.tipo] || esc(a.tipo)}</strong> — ${formatarDataHora(a.data)}
              ${a.descricao ? `<br><span style="color:var(--text-muted)">${esc(a.descricao)}</span>` : ''}
              ${a.proxima_em ? `<br><span style="color:var(--star)">Próxima ação: ${formatarDataHora(a.proxima_em)}</span>` : ''}
            </li>
          `).join('') || '<li style="font-size:.85rem;color:var(--text-muted)">Nenhuma atividade registrada.</li>'}
        </ul>
        <div style="display:flex;gap:var(--space-2);flex-wrap:wrap;align-items:flex-end">
          <div class="field" style="margin:0">
            <label for="novaAtividadeTipo">Tipo</label>
            <select id="novaAtividadeTipo" style="width:160px">${Object.keys(TIPO_ATIVIDADE_MAP).map((t) => `<option value="${t}">${TIPO_ATIVIDADE_MAP[t]}</option>`).join('')}</select>
          </div>
          <div class="field" style="margin:0"><label for="novaAtividadeDesc">Descrição</label><input id="novaAtividadeDesc" style="width:220px"></div>
          <div class="field" style="margin:0"><label for="novaAtividadeProxima">Próxima ação em</label><input type="date" id="novaAtividadeProxima"></div>
          <button class="btn btn-primary btn-sm" id="addAtividadeBtn">Registrar</button>
        </div>
      `;
      host.querySelector('#addAtividadeBtn').addEventListener('click', async () => {
        try {
          const proximaInput = host.querySelector('#novaAtividadeProxima').value;
          await criarAtividade({
            leadId: lead.id,
            tipo: host.querySelector('#novaAtividadeTipo').value,
            descricao: host.querySelector('#novaAtividadeDesc').value.trim(),
            // 30/09: data do <input type=date> é LOCAL (9h), não meia-noite UTC (que virava o dia anterior no Recife)
            proximaEm: proximaInput ? new Date(`${proximaInput}T09:00:00`).toISOString() : undefined,
          });
          showToast('Atividade registrada.', { tone: 'ok' });
          load(); // reflete ultima_atividade_em/proxima_atividade_em na lista
          carregarAtividades();
        } catch (err) {
          showToast(err.message || 'Falha ao registrar atividade.', { tone: 'danger' });
        }
      });
    }

    if (!isNew) {
      carregarContatos();
      carregarAtividades();
      carregarOportunidades();
    }

    panel.querySelector('#saveLeadBtn').addEventListener('click', async () => {
      const payload = {
        empresa: panel.querySelector('#f_empresa').value.trim(),
        setor: panel.querySelector('#f_setor').value.trim(),
        telefone: panel.querySelector('#f_telefone').value.trim(),
        email: panel.querySelector('#f_email').value.trim(),
        funcaoContato: panel.querySelector('#f_funcao').value.trim(),
        endereco: panel.querySelector('#f_endereco').value.trim(),
        cidade: panel.querySelector('#f_cidade').value.trim(),
        site: panel.querySelector('#f_site').value.trim(),
        cnpj: panel.querySelector('#f_cnpj').value.trim(),
        anosMercado: panel.querySelector('#f_anos').value.trim(),
        avaliacaoGoogle: panel.querySelector('#f_avaliacao').value.trim(),
        canalSugerido: panel.querySelector('#f_canal').value.trim(),
        status: panel.querySelector('#f_status').value,
        prioridade: panel.querySelector('#f_prioridade').value,
        statusLead: panel.querySelector('#f_status_lead').value,
        statusContato: panel.querySelector('#f_status_contato').value,
        sinalSiteDesatualizado: panel.querySelector('#s_site_desatualizado').checked,
        sinalInstagramDesorganizado: panel.querySelector('#s_instagram').checked,
        sinalGbpFraco: panel.querySelector('#s_gbp').checked,
        sinalPorteMedioGrande: panel.querySelector('#s_porte').checked,
        sinalSegmentoAltoPotencial: panel.querySelector('#s_segmento').checked,
        sinalEmailValidado: panel.querySelector('#s_email_validado').checked,
        problemaIdentificado: panel.querySelector('#f_problema').value.trim(),
        evidenciaProblema: panel.querySelector('#f_evidencia').value.trim(),
        ofertaRecomendada: panel.querySelector('#f_oferta').value.trim(),
        motivo: panel.querySelector('#f_motivo').value.trim(),
        observacoes: panel.querySelector('#f_obs').value.trim(),
      };
      if (!payload.empresa) {
        showToast('Informe o nome da empresa.', { tone: 'danger' });
        return;
      }
      const saveBtn = panel.querySelector('#saveLeadBtn');
      saveBtn.disabled = true;
      try {
        if (isNew) {
          let r = await createLeadComChecagem(payload);
          if (r.duplicados) {
            const lista = r.duplicados.map((d) => `${d.empresa}${d.cidade ? ` (${d.cidade})` : ''}`).join(', ');
            const ok = await confirmDialog({
              title: 'Já existe um lead parecido',
              description: `${lista}. Criar mesmo assim? (Se for a mesma empresa, abra o lead existente.)`,
              confirmLabel: 'Criar mesmo assim', tone: 'ok',
            });
            if (!ok) { saveBtn.disabled = false; return; }
            r = await createLeadComChecagem({ ...payload, confirmarDuplicado: true });
          }
          showToast('Lead criado.', { tone: 'ok' });
        } else {
          await updateLead(lead.id, payload);
          showToast('Lead atualizado.', { tone: 'ok' });
        }
        editorHost.innerHTML = '';
        load();
      } catch (err) {
        saveBtn.disabled = false;
        showToast(err.message || 'Falha ao salvar lead.', { tone: 'danger' });
      }
    });

    const arquivarBtn = panel.querySelector('#arquivarLeadBtn');
    if (arquivarBtn) arquivarBtn.addEventListener('click', () => pedirArquivamento([lead.id], () => { editorHost.innerHTML = ''; load(); }));
    const restaurarBtn = panel.querySelector('#restaurarLeadBtn');
    if (restaurarBtn) restaurarBtn.addEventListener('click', async () => {
      try { await restaurarLeads([lead.id]); showToast('Lead restaurado.', { tone: 'ok' }); editorHost.innerHTML = ''; load(); } catch (err) { showToast(err.message, { tone: 'danger' }); }
    });

    const delBtn = panel.querySelector('#deleteLeadBtn');
    if (delBtn) {
      delBtn.addEventListener('click', async () => {
        const ok = await confirmDialog({ title: 'Excluir definitivamente?', description: `${lead.empresa} e todo o histórico (atividades, contatos) serão apagados para sempre. Esta ação não pode ser desfeita.`, confirmLabel: 'Excluir definitivamente' });
        if (!ok) return;
        try {
          await deleteLead(lead.id);
          editorHost.innerHTML = '';
          load();
          showToast('Lead excluído definitivamente.', { tone: 'ok' });
        } catch (err) {
          showToast(err.message || 'Falha ao excluir lead.', { tone: 'danger' });
        }
      });
    }

    const optoutBtn = panel.querySelector('#optoutBtn');
    if (optoutBtn) {
      optoutBtn.addEventListener('click', async () => {
        const ok = await confirmDialog({
          title: 'Registrar opt-out?',
          description: `${lead.empresa} nunca mais poderá ser contatada por e-mail pela aba Prospecção — nem se for encontrada de novo numa busca futura. Essa ação não é reversível pela interface.`,
          confirmLabel: 'Bloquear contato',
        });
        if (!ok) return;
        try {
          await registrarOptout({
            email: lead.email || undefined,
            telefone: lead.telefone || undefined,
            origemId: lead.origem_id || undefined,
            motivo: 'Solicitado manualmente pelo editor de lead',
          });
          const updated = await updateLead(lead.id, { statusContato: 'nao_contatar' });
          load();
          showToast('Opt-out registrado — este contato não será mais incluído em envios.', { tone: 'ok' });
          openEditor(updated);
        } catch (err) {
          showToast(err.message || 'Falha ao registrar opt-out.', { tone: 'danger' });
        }
      });
    }

    panel.querySelector('#cancelLeadBtn').addEventListener('click', () => {
      editorHost.innerHTML = '';
    });

    const copyMessageBtn = panel.querySelector('#copyMessageBtn');
    if (copyMessageBtn) {
      copyMessageBtn.addEventListener('click', async () => {
        await navigator.clipboard.writeText(panel.querySelector('#f_mensagem').value);
        showToast('Mensagem copiada.', { tone: 'ok' });
      });
    }
    const copyEmailBtn = panel.querySelector('#copyEmailBtn');
    if (copyEmailBtn) {
      copyEmailBtn.addEventListener('click', async () => {
        await navigator.clipboard.writeText(copyEmailBtn.dataset.copyEmail);
        showToast('E-mail copiado.', { tone: 'ok' });
      });
    }
    const waMessageBtn = panel.querySelector('#waMessageBtn');
    if (waMessageBtn) {
      waMessageBtn.addEventListener('click', () => {
        const url = whatsappUrl(lead.telefone, panel.querySelector('#f_mensagem').value);
        window.open(url, '_blank', 'noopener');
      });
    }
  }

  function load() {
    if (controleCarga) controleCarga.abort(); // cancela a requisição anterior (filtro trocado rápido)
    controleCarga = new AbortController();
    const sinal = controleCarga.signal;
    listCard.innerHTML = '';
    listCard.appendChild(LoadingState({ rows: 5 }));
    fetchLeads(parametrosServidor(), { signal: sinal })
      .then((data) => {
        if (sinal.aborted) return;
        leads = data.leads || [];
        total = data.total ?? leads.length;
        porPagina = data.porPagina || porPagina;
        renderList();
      })
      .catch((err) => {
        if (err.name === 'AbortError' || sinal.aborted) return;
        listCard.innerHTML = '';
        listCard.appendChild(ErrorState({ description: err.message, onRetry: load }));
      });
  }

  let debounceBusca = null;
  toolbar.querySelector('#leadSearch').addEventListener('input', (e) => {
    clearTimeout(debounceBusca);
    debounceBusca = setTimeout(() => { filtros.q = e.target.value.trim(); pagina = 1; load(); }, 300);
  });
  const ligarFiltro = (sel, chave) => toolbar.querySelector(sel).addEventListener('change', (e) => { filtros[chave] = e.target.value; pagina = 1; selectedIds.clear(); load(); });
  ligarFiltro('#statusFilter', 'status');
  ligarFiltro('#setorFilter', 'setor');
  ligarFiltro('#prioridadeFilter', 'prioridade');
  ligarFiltro('#periodoFilter', 'periodo');
  ligarFiltro('#temperaturaFilter', 'temperatura');
  ligarFiltro('#faixaFilter', 'faixa');
  ligarFiltro('#arquivadosFilter', 'arquivados');
  toolbar.querySelector('#arquivadosFilter').value = filtros.arquivados;
  toolbar.querySelector('#relatorioBtn').addEventListener('click', () => abrirRelatorio());
  toolbar.querySelector('#exportarCsvBtn').addEventListener('click', () => exportarCSV());
  toolbar.querySelector('#newLeadBtn').addEventListener('click', () => openEditor(emptyLead()));

  carregarTaxonomia().then((t) => { taxonomia = t; populateSetorFilter(); }).catch(() => {});
  load();
}
