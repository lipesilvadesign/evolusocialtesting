import { LoadingState } from '../components/LoadingState.js';
import { ErrorState } from '../components/ErrorState.js';
import { showToast } from '../components/Toast.js';
import { getCurrentUser } from '../services/auth.js';
import { ehAdmin } from '../services/rbac.js';
import { AVATARES_DISPONIVEIS } from '../components/avatarIlustrado.js';
import {
  listarFuncionarios, atualizarFuncionario, convidarFuncionario,
  resetarSenhaFuncionario, excluirFuncionario,
} from '../services/funcionariosClient.js';

const ROLE_LABEL = { admin: 'Administrador', prospeccao: 'Prospecção', design: 'Design' };

// nome/tempo_experiencia/funcoes/biografia agora são autoeditáveis por
// qualquer funcionário (Meu Perfil, ver perfil.js) — nunca inserir esses
// campos em innerHTML sem escapar, ou um funcionário mal-intencionado
// poderia injetar HTML/JS que executaria no navegador do ADMIN ao abrir
// esta tela (achado numa auditoria de segurança, 13/09).
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export async function renderFuncionarios(container) {
  container.innerHTML = '';

  const user = await getCurrentUser();
  if (!ehAdmin(user)) {
    container.innerHTML = '<div class="app-view-head"><h2>Acesso restrito</h2><p>Esta área é exclusiva de administradores.</p></div>';
    return;
  }

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Funcionários</h2>
      <p>Quem tem acesso ao painel, e o que cada papel pode fazer. Revogar acesso é reversível — só desativa, não apaga o histórico da pessoa.</p>
    </div>
  `;
  container.appendChild(head);

  const conviteCard = document.createElement('section');
  conviteCard.className = 'card';
  conviteCard.innerHTML = `
    <h3>Adicionar funcionário</h3>
    <div class="content-editor-form">
      <div class="field"><label for="fn_nome">Nome</label><input id="fn_nome"></div>
      <div class="field"><label for="fn_email">E-mail</label><input id="fn_email" type="email"></div>
      <div class="field">
        <label for="fn_role">Papel</label>
        <select id="fn_role">
          <option value="prospeccao">Prospecção</option>
          <option value="design">Design</option>
          <option value="admin">Administrador</option>
        </select>
      </div>
      <div class="field">
        <label for="fn_modo">Como a pessoa entra</label>
        <select id="fn_modo">
          <option value="convite_email">Enviar convite por e-mail (ela mesma define a senha)</option>
          <option value="gerar_senha">Gerar login e senha agora (eu entrego direto pra ela)</option>
        </select>
      </div>
    </div>
    <button class="btn btn-primary btn-sm" id="fn_convidarBtn">Criar acesso</button>
    <div id="fn_senhaGeradaHost" style="margin-top:var(--space-3)"></div>
  `;
  container.appendChild(conviteCard);

  const listCard = document.createElement('section');
  listCard.className = 'card';
  listCard.style.marginTop = 'var(--space-5)';
  container.appendChild(listCard);

  function renderLista(funcionarios) {
    if (funcionarios.length === 0) {
      listCard.innerHTML = '<p style="color:var(--text-muted)">Nenhum funcionário cadastrado.</p>';
      return;
    }
    listCard.innerHTML = `<div class="table-wrap"><table class="app-table">
      <thead><tr><th>Nome</th><th>Perfil</th><th>E-mail</th><th>Papel</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${funcionarios.map((f) => `
          <tr>
            <td>${esc(f.nome)}${f.id === user.id ? ' <span class="badge badge-info">Você</span>' : ''}</td>
            <td style="font-size:.78rem;color:var(--text-muted);max-width:220px">
              ${f.tempo_experiencia ? `<div>${esc(f.tempo_experiencia)}</div>` : ''}
              ${f.funcoes ? `<div>${esc(f.funcoes)}</div>` : ''}
              ${!f.tempo_experiencia && !f.funcoes ? '—' : ''}
            </td>
            <td>${esc(f.email)}</td>
            <td>
              <select class="fn_roleSelect" data-id="${esc(f.id)}" aria-label="Papel de ${esc(f.nome || f.email)}" ${f.id === user.id ? 'disabled title="Você não pode alterar seu próprio papel"' : ''}>
                ${Object.entries(ROLE_LABEL).map(([v, l]) => `<option value="${v}" ${f.role === v ? 'selected' : ''}>${l}</option>`).join('')}
              </select>
            </td>
            <td>${f.ativo ? '<span class="badge badge-ok">Ativo</span>' : '<span class="badge badge-danger">Revogado</span>'}</td>
            <td style="text-align:right;white-space:nowrap">
              <button class="btn btn-ghost btn-sm" data-editar="${f.id}">Editar perfil</button>
              ${f.id === user.id ? '' : `
                <button class="btn btn-ghost btn-sm" data-toggle="${f.id}" data-ativo="${f.ativo}">${f.ativo ? 'Revogar acesso' : 'Reativar'}</button>
                <button class="btn btn-ghost btn-sm" data-resetar="${f.id}">Redefinir senha</button>
                <button class="btn btn-ghost btn-sm" data-excluir="${f.id}" data-nome="${esc(f.nome)}" style="color:var(--danger)">Excluir conta</button>
              `}
            </td>
          </tr>
        `).join('')}
      </tbody>
    </table></div>
    <div id="fn_acaoResultHost"></div>`;

    listCard.querySelectorAll('.fn_roleSelect').forEach((sel) => {
      sel.addEventListener('change', async () => {
        try {
          await atualizarFuncionario(sel.dataset.id, { role: sel.value });
          showToast('Papel atualizado.', { tone: 'ok' });
        } catch (err) {
          showToast(err.message || 'Falha ao atualizar papel.', { tone: 'danger' });
          carregar();
        }
      });
    });
    listCard.querySelectorAll('[data-toggle]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const ativo = btn.dataset.ativo === 'true';
        try {
          await atualizarFuncionario(btn.dataset.toggle, { ativo: !ativo });
          showToast(ativo ? 'Acesso revogado.' : 'Acesso reativado.', { tone: 'ok' });
          carregar();
        } catch (err) {
          showToast(err.message || 'Falha ao atualizar.', { tone: 'danger' });
        }
      });
    });
    listCard.querySelectorAll('[data-editar]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const f = funcionarios.find((x) => x.id === btn.dataset.editar);
        if (f) abrirEdicaoPerfil(f);
      });
    });
    listCard.querySelectorAll('[data-resetar]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const f = funcionarios.find((x) => x.id === btn.dataset.resetar);
        if (!f || !window.confirm(`Gerar uma nova senha pra ${f.nome}? A senha antiga deixa de funcionar.`)) return;
        try {
          const senhaGerada = await resetarSenhaFuncionario(f.id);
          mostrarSenhaGerada(listCard.querySelector('#fn_acaoResultHost'), f, senhaGerada);
        } catch (err) {
          showToast(err.message || 'Falha ao redefinir senha.', { tone: 'danger' });
        }
      });
    });
    listCard.querySelectorAll('[data-excluir]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const nome = btn.dataset.nome;
        const digitado = window.prompt(`Isso apaga a conta de ${nome} PRA SEMPRE (login, histórico de ponto, metas — tudo). Pra confirmar, digite o nome exatamente: ${nome}`);
        if (digitado !== nome) {
          if (digitado !== null) showToast('Nome não confere — nada foi excluído.', { tone: 'danger' });
          return;
        }
        try {
          await excluirFuncionario(btn.dataset.excluir);
          showToast(`Conta de ${nome} excluída.`, { tone: 'ok' });
          carregar();
        } catch (err) {
          showToast(err.message || 'Falha ao excluir conta.', { tone: 'danger' });
        }
      });
    });
  }

  /** Edição admin-only de nome/foto/tempo de experiência/funções/gênero — sequência de prompts, mesmo padrão já usado em "Definir meta" no Início. */
  async function abrirEdicaoPerfil(f) {
    const nome = window.prompt('Nome:', f.nome);
    if (nome === null) return;
    const fotoUrl = window.prompt('URL da foto (deixe vazio pra remover, cancele pra não mexer):', f.foto_url || '');
    if (fotoUrl === null) return;
    const tempoExperiencia = window.prompt('Tempo de experiência (ex.: "5 anos"):', f.tempo_experiencia || '');
    if (tempoExperiencia === null) return;
    const funcoes = window.prompt('Funções/responsabilidades:', f.funcoes || '');
    if (funcoes === null) return;
    // Avatar ilustrado (pro card de boas-vindas quando não tem foto) — o
    // jeito normal de escolher é a própria pessoa abrir "Meu Perfil" e
    // clicar na galeria; isto aqui é só um atalho rápido pro admin definir
    // por alguém (ex.: recém-contratado que ainda não logou). Lista os ids
    // porque um prompt de texto simples não dá pra mostrar a galeria
    // visual — quem quiser ver as opções antes escolhe direto em "Meu
    // Perfil" depois.
    const idsValidos = AVATARES_DISPONIVEIS.map((a) => a.id);
    const listaAvatares = AVATARES_DISPONIVEIS.map((a) => `${a.id} = ${a.label}`).join('\n');
    const avatarTxt = window.prompt(`Avatar ilustrado — digite um id ou deixe vazio pra não mexer:\n${listaAvatares}`, f.avatar_escolhido || '');
    if (avatarTxt === null) return;
    const avatarNormalizado = avatarTxt.trim().toLowerCase();
    if (avatarNormalizado && !idsValidos.includes(avatarNormalizado)) {
      showToast(`Avatar inválido — use um dos ids listados (${idsValidos.join(', ')}) ou deixe vazio. Nada foi salvo.`, { tone: 'danger' });
      return;
    }

    try {
      await atualizarFuncionario(f.id, {
        nome: nome.trim() || f.nome,
        fotoUrl: fotoUrl.trim(),
        tempoExperiencia: tempoExperiencia.trim(),
        funcoes: funcoes.trim(),
        avatarEscolhido: avatarNormalizado || null,
      });
      showToast('Perfil atualizado.', { tone: 'ok' });
      carregar();
    } catch (err) {
      showToast(err.message || 'Falha ao atualizar perfil.', { tone: 'danger' });
    }
  }

  function mostrarSenhaGerada(host, f, senhaGerada) {
    host.innerHTML = `
      <div class="card" style="background:var(--bg-soft);border:1px solid var(--star);margin-top:var(--space-3)">
        <p style="font-size:.85rem;margin-bottom:6px"><strong>${esc(f.nome)}</strong> — login: <code>${esc(f.email)}</code></p>
        <p style="font-size:.85rem;margin-bottom:6px">Nova senha: <code id="fn_novaSenhaTexto" style="font-size:1rem;letter-spacing:.02em">${esc(senhaGerada)}</code></p>
        <p style="font-size:.76rem;color:var(--text-muted);margin-bottom:8px">Copie e entregue agora — essa senha não aparece de novo depois que você sair desta tela.</p>
        <button class="btn btn-ghost btn-sm" id="fn_copiarNovaSenhaBtn">Copiar senha</button>
      </div>
    `;
    host.querySelector('#fn_copiarNovaSenhaBtn').addEventListener('click', async () => {
      await navigator.clipboard.writeText(senhaGerada);
      showToast('Senha copiada.', { tone: 'ok' });
    });
  }

  function carregar() {
    listCard.innerHTML = '';
    listCard.appendChild(LoadingState({ rows: 4 }));
    listarFuncionarios()
      .then(renderLista)
      .catch((err) => {
        listCard.innerHTML = '';
        listCard.appendChild(ErrorState({ description: err.message, onRetry: carregar }));
      });
  }

  const senhaHost = conviteCard.querySelector('#fn_senhaGeradaHost');

  conviteCard.querySelector('#fn_convidarBtn').addEventListener('click', async () => {
    const nome = conviteCard.querySelector('#fn_nome').value.trim();
    const email = conviteCard.querySelector('#fn_email').value.trim();
    const role = conviteCard.querySelector('#fn_role').value;
    const modo = conviteCard.querySelector('#fn_modo').value;
    if (!nome || !email) { showToast('Informe nome e e-mail.', { tone: 'danger' }); return; }
    senhaHost.innerHTML = '';
    try {
      const { senhaGerada } = await convidarFuncionario({ nome, email, role, modo });
      if (senhaGerada) {
        // Só aparece UMA vez — a senha não fica salva em lugar nenhum, se
        // fechar sem copiar o jeito é redefinir a senha da conta depois.
        senhaHost.innerHTML = `
          <div class="card" style="background:var(--bg-soft);border:1px solid var(--star)">
            <p style="font-size:.85rem;margin-bottom:6px"><strong>${esc(nome)}</strong> — login: <code>${esc(email)}</code></p>
            <p style="font-size:.85rem;margin-bottom:6px">Senha: <code id="fn_senhaTexto" style="font-size:1rem;letter-spacing:.02em">${esc(senhaGerada)}</code></p>
            <p style="font-size:.76rem;color:var(--text-muted);margin-bottom:8px">Copie e entregue agora — essa senha não aparece de novo depois que você sair desta tela.</p>
            <button class="btn btn-ghost btn-sm" id="fn_copiarSenhaBtn">Copiar senha</button>
          </div>
        `;
        senhaHost.querySelector('#fn_copiarSenhaBtn').addEventListener('click', async () => {
          await navigator.clipboard.writeText(senhaGerada);
          showToast('Senha copiada.', { tone: 'ok' });
        });
      }
      showToast(modo === 'gerar_senha' ? 'Acesso criado.' : 'Convite enviado.', { tone: 'ok' });
      conviteCard.querySelector('#fn_nome').value = '';
      conviteCard.querySelector('#fn_email').value = '';
      carregar();
    } catch (err) {
      showToast(err.message || 'Falha ao criar acesso.', { tone: 'danger' });
    }
  });

  carregar();
}
