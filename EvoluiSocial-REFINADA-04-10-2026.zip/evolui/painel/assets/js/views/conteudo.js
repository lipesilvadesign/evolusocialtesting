import { LoadingState } from '../components/LoadingState.js';
import { EmptyState } from '../components/EmptyState.js';
import { ErrorState } from '../components/ErrorState.js';
import { renderContentEditor } from '../components/ContentEditor.js';
import { statusBadgeHtml } from '../components/StatusBadge.js';
import { listContent, createContent, updateContent, deleteContent } from '../services/contentApi.js';
import { CONTENT_TYPES, getSchema, emptyItem, getField } from '../content-schemas.js';
import { getCurrentUser } from '../services/auth.js';
import { canManageContent } from '../services/rbac.js';

export async function renderConteudo(container) {
  container.innerHTML = '';

  const user = await getCurrentUser();
  const canEdit = canManageContent(user);

  let activeType = CONTENT_TYPES[0].type;
  let items = [];
  let filterStatus = 'todos';
  let searchTerm = '';

  const head = document.createElement('div');
  head.className = 'app-view-head';
  head.innerHTML = `
    <div>
      <p class="eyebrow">Central administrativa</p>
      <h2>Conteúdo</h2>
      <p>Posts, Projetos, Serviços, Marcas Parceiras e Páginas — tudo num só lugar.</p>
    </div>
  `;
  container.appendChild(head);

  const tabsBar = document.createElement('div');
  tabsBar.className = 'content-tabs';
  container.appendChild(tabsBar);

  const toolbar = document.createElement('div');
  toolbar.className = 'content-toolbar';
  toolbar.innerHTML = `
    <div class="search-box-small">
      <input type="search" id="contentSearch" placeholder="Buscar por título…" aria-label="Buscar conteúdo">
    </div>
    <select id="statusFilter" aria-label="Filtrar por status">
      <option value="todos">Todos os status</option>
      <option value="rascunho">Rascunho</option>
      <option value="publicado">Publicado</option>
      <option value="arquivado">Arquivado</option>
    </select>
    <button class="btn btn-primary btn-sm" id="newItemBtn" ${canEdit ? '' : 'disabled'}>+ Novo</button>
  `;
  container.appendChild(toolbar);

  const listCard = document.createElement('section');
  listCard.className = 'card';
  container.appendChild(listCard);

  const editorHost = document.createElement('div');
  container.appendChild(editorHost);

  function renderTabs() {
    tabsBar.innerHTML = '';
    CONTENT_TYPES.forEach((ct) => {
      const btn = document.createElement('button');
      btn.className = 'tab-btn' + (ct.type === activeType ? ' is-active' : '');
      btn.textContent = ct.label;
      btn.addEventListener('click', () => {
        if (ct.type === activeType) return;
        activeType = ct.type;
        filterStatus = 'todos';
        searchTerm = '';
        editorHost.innerHTML = '';
        toolbar.querySelector('#contentSearch').value = '';
        toolbar.querySelector('#statusFilter').value = 'todos';
        renderTabs();
        loadList();
      });
      tabsBar.appendChild(btn);
    });
  }

  function filteredItems() {
    const schema = getSchema(activeType);
    const titleField = schema.fields.find((f) => f.slugSource);
    const titleKey = titleField ? titleField.key : 'title';
    return items.filter((it) => {
      const matchesStatus = filterStatus === 'todos' || (it.status || 'rascunho') === filterStatus;
      const title = String(getField(it, titleKey) || '').toLowerCase();
      const matchesSearch = !searchTerm || title.includes(searchTerm.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }

  function renderList() {
    listCard.innerHTML = '';
    const schema = getSchema(activeType);
    const rows = filteredItems();

    if (rows.length === 0) {
      listCard.appendChild(
        EmptyState({
          title: 'Nada por aqui ainda',
          description:
            items.length === 0
              ? `Nenhum ${(schema.singular || 'item').toLowerCase()} criado ainda.`
              : 'Nada encontrado com esses filtros.',
          actionLabel: canEdit && items.length === 0 ? `+ Criar ${schema.singular}` : undefined,
          onAction: canEdit && items.length === 0 ? () => openEditor(emptyItem(activeType)) : undefined,
        })
      );
      return;
    }

    const wrap = document.createElement('div');
    wrap.className = 'table-wrap';
    const table = document.createElement('table');
    table.className = 'app-table';
    table.innerHTML = `
      <thead><tr>${schema.listColumns.map((c) => `<th>${c.label}</th>`).join('')}<th></th></tr></thead>
      <tbody></tbody>
    `;
    const tbody = table.querySelector('tbody');

    rows.forEach((it) => {
      const tr = document.createElement('tr');
      tr.style.cursor = 'pointer';
      const cells = schema.listColumns
        .map((c) => {
          if (c.isStatus) return `<td>${statusBadgeHtml(it.status || 'rascunho')}</td>`;
          if (c.isDate) {
            const raw = getField(it, c.key);
            return `<td>${raw ? String(raw).slice(0, 10) : '—'}</td>`;
          }
          const val = getField(it, c.key);
          return `<td>${val || '—'}</td>`;
        })
        .join('');
      tr.innerHTML = `${cells}<td style="text-align:right"><button type="button" class="btn btn-ghost btn-sm">${canEdit ? 'Editar' : 'Ver'}</button></td>`;
      tr.addEventListener('click', () => openEditor(it));
      tbody.appendChild(tr);
    });

    wrap.appendChild(table);
    listCard.appendChild(wrap);
  }

  function openEditor(item) {
    editorHost.innerHTML = '';
    if (!canEdit) {
      editorHost.appendChild(
        ErrorState({ title: 'Sem permissão', description: 'Sua conta não tem permissão para editar conteúdo.' })
      );
      return;
    }
    const panel = renderContentEditor({
      type: activeType,
      item,
      existingItems: items,
      onSave: async (payload) => {
        let saved;
        if (payload.id) {
          saved = await updateContent(activeType, payload.id, stripId(payload));
          const idx = items.findIndex((i) => i.id === saved.id);
          if (idx !== -1) items[idx] = saved;
          renderList();
        } else {
          saved = await createContent(activeType, stripId(payload));
          items.push(saved);
          renderList();
          // primeira gravação: troca pro modo edição (habilita autosave/excluir/publicar)
          openEditor(saved);
        }
        return saved;
      },
      onDelete: async () => {
        await deleteContent(activeType, item.id);
        items = items.filter((i) => i.id !== item.id);
        editorHost.innerHTML = '';
        renderList();
      },
      onCancel: () => {
        editorHost.innerHTML = '';
      },
    });
    editorHost.appendChild(panel);
    editorHost.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function stripId(payload) {
    const { id, ...rest } = payload;
    return rest;
  }

  function loadList() {
    listCard.innerHTML = '';
    listCard.appendChild(LoadingState({ rows: 4 }));
    listContent(activeType)
      .then((data) => {
        items = data;
        renderList();
      })
      .catch((err) => {
        listCard.innerHTML = '';
        listCard.appendChild(ErrorState({ description: err.message, onRetry: loadList }));
      });
  }

  toolbar.querySelector('#contentSearch').addEventListener('input', (e) => {
    searchTerm = e.target.value;
    renderList();
  });
  toolbar.querySelector('#statusFilter').addEventListener('change', (e) => {
    filterStatus = e.target.value;
    renderList();
  });
  toolbar.querySelector('#newItemBtn').addEventListener('click', () => openEditor(emptyItem(activeType)));

  renderTabs();
  loadList();
}
