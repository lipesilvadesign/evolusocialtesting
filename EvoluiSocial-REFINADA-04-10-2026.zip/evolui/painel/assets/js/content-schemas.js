export const CONTENT_TYPES = [
  { type: 'posts', label: 'Posts', singular: 'Post' },
  { type: 'projetos', label: 'Projetos', singular: 'Projeto' },
  { type: 'servicos', label: 'Serviços', singular: 'Serviço' },
  { type: 'parceiros', label: 'Marcas Parceiras', singular: 'Marca Parceira' },
  { type: 'paginas', label: 'Páginas', singular: 'Página' },
];

// Campos comuns de SEO — mesma forma (chave `seo`) nos 4 tipos.
const SEO_FIELDS = [
  { key: 'seo.titulo', label: 'Título para SEO', type: 'text' },
  { key: 'seo.descricao', label: 'Descrição para SEO', type: 'textarea' },
  { key: 'seo.ogImagem', label: 'Imagem Open Graph', type: 'image' },
];

const SCHEMAS = {
  // Tabela nova (admin_posts) — nomenclatura livre, escolhida nesta etapa.
  posts: {
    listColumns: [
      { key: 'titulo', label: 'Título' },
      { key: 'status', label: 'Status', isStatus: true },
      { key: 'data_publicacao', label: 'Data', isDate: true },
    ],
    fields: [
      { key: 'titulo', label: 'Título', type: 'text', required: true, slugSource: true },
      { key: 'slug', label: 'Slug', type: 'text', required: true },
      { key: 'descricao', label: 'Descrição', type: 'textarea' },
      { key: 'imagem', label: 'Imagem de capa', type: 'image' },
      { key: 'conteudo', label: 'Conteúdo', type: 'textarea', large: true },
      { key: 'status', label: 'Status', type: 'select', options: ['rascunho', 'publicado', 'arquivado'] },
      { key: 'data_publicacao', label: 'Data de publicação', type: 'date' },
      ...SEO_FIELDS,
    ],
  },
  // Tabela nova (admin_pages) — mesma forma de posts.
  paginas: {
    listColumns: [
      { key: 'titulo', label: 'Título' },
      { key: 'status', label: 'Status', isStatus: true },
      { key: 'data_publicacao', label: 'Data', isDate: true },
    ],
    fields: [
      { key: 'titulo', label: 'Título', type: 'text', required: true, slugSource: true },
      { key: 'slug', label: 'Slug', type: 'text', required: true },
      { key: 'descricao', label: 'Descrição', type: 'textarea' },
      { key: 'imagem', label: 'Imagem de capa', type: 'image' },
      { key: 'conteudo', label: 'Conteúdo', type: 'textarea', large: true },
      { key: 'status', label: 'Status', type: 'select', options: ['rascunho', 'publicado', 'arquivado'] },
      { key: 'data_publicacao', label: 'Data de publicação', type: 'date' },
      ...SEO_FIELDS,
    ],
  },
  // site_content.portfolio — nomes de campo (title/desc/image/category/categoryLabel)
  // são os MESMOS já usados pelo admin.html. Não renomear.
  projetos: {
    listColumns: [
      { key: 'title', label: 'Título' },
      { key: 'categoryLabel', label: 'Categoria' },
      { key: 'status', label: 'Status', isStatus: true },
    ],
    fields: [
      { key: 'title', label: 'Título', type: 'text', required: true, slugSource: true },
      { key: 'slug', label: 'Slug', type: 'text', required: true },
      {
        key: 'category',
        label: 'Categoria (filtro do site)',
        type: 'select',
        options: ['identidade', 'social', 'video'],
      },
      { key: 'categoryLabel', label: 'Categoria (rótulo exibido)', type: 'text' },
      { key: 'desc', label: 'Descrição', type: 'textarea' },
      { key: 'image', label: 'Imagem', type: 'image' },
      { key: 'status', label: 'Status', type: 'select', options: ['rascunho', 'publicado', 'arquivado'] },
      { key: 'dataPublicacao', label: 'Data de publicação', type: 'date' },
      ...SEO_FIELDS,
    ],
  },
  // site_content.services — nomes de campo (title/desc/tags/icon) são os
  // MESMOS já usados pelo admin.html. Não renomear.
  servicos: {
    listColumns: [
      { key: 'title', label: 'Título' },
      { key: 'status', label: 'Status', isStatus: true },
    ],
    fields: [
      { key: 'title', label: 'Título', type: 'text', required: true, slugSource: true },
      { key: 'slug', label: 'Slug', type: 'text', required: true },
      { key: 'desc', label: 'Descrição', type: 'textarea' },
      { key: 'tags', label: 'Tags (separadas por vírgula)', type: 'text' },
      { key: 'icon', label: 'Ícone', type: 'select', options: ['target', 'layers', 'arrows-h', 'spark', 'star4'] },
      { key: 'status', label: 'Status', type: 'select', options: ['rascunho', 'publicado', 'arquivado'] },
      { key: 'dataPublicacao', label: 'Data de publicação', type: 'date' },
      ...SEO_FIELDS,
    ],
  },

  // site_content.partners — array novo, exibido como carrossel/marquee de
  // logos parceiras na home (ver /assets/js/partners-marquee.js). "ordem"
  // controla a posição na esteira; menor primeiro.
  parceiros: {
    listColumns: [
      { key: 'nome', label: 'Nome' },
      { key: 'ordem', label: 'Ordem' },
      { key: 'status', label: 'Status', isStatus: true },
    ],
    fields: [
      { key: 'nome', label: 'Nome da marca parceira', type: 'text', required: true },
      { key: 'logoUrl', label: 'Logo', type: 'image', required: true },
      { key: 'link', label: 'Link do site da parceira (opcional)', type: 'text' },
      { key: 'ordem', label: 'Ordem de exibição (menor aparece primeiro)', type: 'text' },
      { key: 'status', label: 'Status', type: 'select', options: ['rascunho', 'publicado', 'arquivado'] },
    ],
  },
};

export function getSchema(type) {
  const schema = SCHEMAS[type];
  if (!schema) throw new Error(`Schema desconhecido: ${type}`);
  return schema;
}

export function emptyItem(type) {
  const schema = getSchema(type);
  const item = { status: 'rascunho', seo: {} };
  schema.fields.forEach((f) => {
    if (f.key.startsWith('seo.')) return;
    if (!(f.key in item)) item[f.key] = f.type === 'select' ? f.options[0] : '';
  });
  return item;
}

export function getField(item, key) {
  if (key.includes('.')) {
    const [a, b] = key.split('.');
    return (item[a] || {})[b] || '';
  }
  return item[key] != null ? item[key] : '';
}

export function setField(item, key, value) {
  if (key.includes('.')) {
    const [a, b] = key.split('.');
    item[a] = item[a] || {};
    item[a][b] = value;
    return;
  }
  item[key] = value;
}

export function slugify(text) {
  return (text || '')
    .toString()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}
