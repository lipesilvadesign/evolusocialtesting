/**
 * Pequenos efeitos visuais reutilizáveis (pedido do Felipe, 13/09 —
 * "utilize essas inspiração" apontando pra alguns componentes de animação).
 * Implementados aqui como CSS+JS próprios do projeto (sem dependência
 * externa/bundler) inspirados nesses padrões:
 * - applyWordStagger  → título de cada página "entra" palavra por palavra
 *   (inspirado em "words stagger").
 * - initTiltCard       → cartão de login inclina levemente seguindo o
 *   mouse (inspirado em "tilt card").
 * Ambos respeitam prefers-reduced-motion (checado no CSS via a mesma media
 * query já usada no resto do admin-app.css) e nunca quebram se o elemento
 * não existir — são só polimento, nunca lógica essencial.
 */

/** Envolve cada palavra do texto de `el` num <span> com --i pra animação de entrada escalonada (stagger). Idempotente — não duplica se já aplicado. */
export function applyWordStagger(el) {
  if (!el || el.dataset.fxStaggered === 'true') return;
  const texto = el.textContent;
  if (!texto || !texto.trim()) return;
  el.dataset.fxStaggered = 'true';
  el.innerHTML = texto
    .split(/(\s+)/)
    .map((parte, i) => (parte.trim() ? `<span class="fx-stagger-word" style="--i:${i}">${parte}</span>` : parte))
    .join('');
}

/** Aplica em todo h2 dentro de .app-view-head no container — usado uma vez por troca de rota. */
export function applyHeadingFx(container) {
  container.querySelectorAll('.app-view-head h2').forEach((h2) => applyWordStagger(h2));
}

/**
 * Leve inclinação 3D seguindo o mouse (tilt card) — só desktop (mousemove
 * não existe de verdade em touch, e não vale a pena simular). Sem efeito
 * nenhum se prefers-reduced-motion estiver ativo.
 */
export function initTiltCard(el) {
  if (!el || el.dataset.fxTilt === 'true') return;
  el.dataset.fxTilt = 'true';
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (window.matchMedia && !window.matchMedia('(pointer: fine)').matches) return; // sem mouse de verdade, não faz sentido

  const MAX_DEG = 4;
  el.style.transition = 'transform .15s ease';
  el.addEventListener('mousemove', (e) => {
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    el.style.transform = `perspective(600px) rotateY(${x * MAX_DEG * 2}deg) rotateX(${-y * MAX_DEG * 2}deg)`;
  });
  el.addEventListener('mouseleave', () => {
    el.style.transform = 'perspective(600px) rotateY(0) rotateX(0)';
  });
}
