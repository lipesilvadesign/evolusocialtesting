/**
 * Escape de HTML compartilhado (29/09). Antes cada view tinha sua própria
 * cópia de esc() — idênticas; esta é a mesma função, num lugar só, para os
 * componentes (EmptyState, ErrorState, ConfirmDialog…) também usarem.
 */
export function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** Só deixa passar http(s), mailto, tel, caminho relativo e data:image. */
export function safeUrl(url) {
  const v = String(url == null ? '' : url).trim();
  if (!v) return '';
  if (/^(https?:|mailto:|tel:)/i.test(v) || /^\/(?!\/)/.test(v) || /^#/.test(v)) return v;
  if (/^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,[a-z0-9+/=\s]+$/i.test(v)) return v;
  return '';
}
