/**
 * Modal acessível compartilhado (29/09). Substitui as cópias de
 * abrirModal() das views, que não prendiam o foco (Tab saía para a página
 * de trás), não devolviam o foco ao fechar, não tinham nome acessível e
 * deixavam a página de fundo rolar.
 *
 * Uso:
 *   const { box, close } = abrirModal({ titulo: 'Nome', html: '...', origem: botao });
 *   const { box, close } = abrirModal({ html: '<h3>…</h3>…', maxWidth: '640px' }); // título já no html
 */

import { esc } from '../utils/html.js';

const FOCAVEIS = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
let abertos = 0;
let contador = 0;

function travarRolagem(on) {
  abertos = Math.max(0, abertos + (on ? 1 : -1));
  document.documentElement.classList.toggle('is-modal-open', abertos > 0);
}

/**
 * @param {{ titulo?: string, html: string, maxWidth?: string, origem?: HTMLElement, host?: HTMLElement, role?: string, onClose?: () => void }} opts
 */
export function abrirModal({ titulo, html, maxWidth = '640px', origem, host, role = 'dialog', onClose } = {}) {
  const voltarFoco = origem || document.activeElement;
  const idTitulo = `modal-titulo-${++contador}`;

  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay is-open';
  const box = document.createElement('div');
  box.className = 'modal-box';
  box.setAttribute('role', role);
  box.setAttribute('aria-modal', 'true');
  box.tabIndex = -1;
  box.style.maxWidth = maxWidth;
  box.innerHTML = `
    <button type="button" class="modal-fechar" aria-label="Fechar">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
    </button>
    ${titulo != null ? `<h3 class="modal-titulo" id="${idTitulo}">${esc(titulo)}</h3>` : ''}
    ${html}
  `;
  const heading = box.querySelector('.modal-titulo, h2, h3, h4');
  if (heading) {
    if (!heading.id) heading.id = idTitulo;
    box.setAttribute('aria-labelledby', heading.id);
  }
  overlay.appendChild(box);
  (host || document.body).appendChild(overlay);
  travarRolagem(true);

  let fechado = false;
  function close() {
    if (fechado) return;
    fechado = true;
    document.removeEventListener('keydown', onKeydown, true);
    overlay.remove();
    travarRolagem(false);
    if (voltarFoco && voltarFoco.isConnected && typeof voltarFoco.focus === 'function') voltarFoco.focus();
    if (onClose) onClose();
  }

  function onKeydown(e) {
    if (!overlay.isConnected) return;
    // Só o modal do topo reage (ConfirmDialog pode abrir por cima deste).
    const todos = document.querySelectorAll('.modal-overlay.is-open');
    if (todos[todos.length - 1] !== overlay) return;
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key !== 'Tab') return;
    const itens = [...box.querySelectorAll(FOCAVEIS)].filter((el) => el.offsetParent !== null || el === document.activeElement);
    if (!itens.length) { e.preventDefault(); box.focus(); return; }
    const primeiro = itens[0];
    const ultimo = itens[itens.length - 1];
    if (e.shiftKey && (document.activeElement === primeiro || document.activeElement === box)) { e.preventDefault(); ultimo.focus(); }
    else if (!e.shiftKey && document.activeElement === ultimo) { e.preventDefault(); primeiro.focus(); }
  }

  overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) close(); });
  box.querySelector('.modal-fechar').addEventListener('click', close);
  document.addEventListener('keydown', onKeydown, true);

  // Foco inicial na própria caixa: o leitor de tela anuncia o título e o
  // próximo Tab já cai no primeiro controle, sem pular o texto do topo.
  requestAnimationFrame(() => box.focus({ preventScroll: true }));

  return { overlay, box, close };
}
