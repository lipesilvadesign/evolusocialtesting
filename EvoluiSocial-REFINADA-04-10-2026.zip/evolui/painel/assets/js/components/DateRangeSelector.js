const PRESETS = [
  ['hoje', 'Hoje'],
  ['ontem', 'Ontem'],
  ['7d', 'Últimos 7 dias'],
  ['28d', 'Últimos 28 dias'],
  ['30d', 'Últimos 30 dias'],
  ['90d', 'Últimos 90 dias'],
  ['personalizado', 'Período personalizado'],
];

/**
 * @param {{ initial?: {range:string,start?:string,end?:string}, onChange: (value:{range:string,start?:string,end?:string}) => void }} opts
 * @returns {HTMLElement}
 */
export function renderDateRangeSelector({ initial = { range: '7d' }, onChange }) {
  const wrap = document.createElement('div');
  wrap.className = 'date-range-selector';

  const select = document.createElement('select');
  select.setAttribute('aria-label', 'Selecionar período');
  PRESETS.forEach(([value, label]) => {
    const opt = document.createElement('option');
    opt.value = value;
    opt.textContent = label;
    select.appendChild(opt);
  });
  select.value = initial.range;

  const customBox = document.createElement('div');
  customBox.className = 'date-range-custom';
  customBox.style.display = initial.range === 'personalizado' ? 'flex' : 'none';

  const startInput = document.createElement('input');
  startInput.type = 'date';
  startInput.value = initial.start || '';
  startInput.setAttribute('aria-label', 'Data inicial');

  const endInput = document.createElement('input');
  endInput.type = 'date';
  endInput.value = initial.end || '';
  endInput.setAttribute('aria-label', 'Data final');

  const applyBtn = document.createElement('button');
  applyBtn.type = 'button';
  applyBtn.className = 'btn btn-ghost btn-sm';
  applyBtn.textContent = 'Aplicar';
  applyBtn.addEventListener('click', () => {
    if (!startInput.value || !endInput.value) return;
    onChange({ range: 'personalizado', start: startInput.value, end: endInput.value });
  });

  customBox.appendChild(startInput);
  customBox.appendChild(endInput);
  customBox.appendChild(applyBtn);

  select.addEventListener('change', () => {
    if (select.value === 'personalizado') {
      customBox.style.display = 'flex';
      return; // espera o usuário escolher as datas e clicar "Aplicar"
    }
    customBox.style.display = 'none';
    onChange({ range: select.value });
  });

  wrap.appendChild(select);
  wrap.appendChild(customBox);
  return wrap;
}
