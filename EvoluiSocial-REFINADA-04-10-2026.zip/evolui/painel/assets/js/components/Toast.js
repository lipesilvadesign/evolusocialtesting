let toastEl = null;
let hideTimer = null;

function ensureToastEl() {
  if (toastEl) return toastEl;
  toastEl = document.createElement('div');
  toastEl.className = 'app-toast';
  toastEl.setAttribute('role', 'status');
  toastEl.setAttribute('aria-live', 'polite');
  document.body.appendChild(toastEl);
  return toastEl;
}

/**
 * @param {string} message
 * @param {{ tone?: 'ok'|'danger'|'info' }} [opts]
 */
export function showToast(message, { tone = 'ok' } = {}) {
  const el = ensureToastEl();
  el.textContent = message;
  el.className = `app-toast is-visible app-toast-${tone}`;
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => el.classList.remove('is-visible'), 2600);
}
