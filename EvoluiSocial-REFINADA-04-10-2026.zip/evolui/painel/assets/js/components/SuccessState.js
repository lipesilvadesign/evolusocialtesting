import { esc } from '../utils/html.js';
/**
 * SuccessState — confirmação visual reutilizável após uma ação concluída.
 * @param {{ title: string, description?: string }} opts
 * @returns {HTMLElement}
 */
export function SuccessState({ title, description }) {
  const wrap = document.createElement('div');
  wrap.className = 'state-block';
  wrap.setAttribute('role', 'status');
  wrap.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="var(--ok)" stroke-width="1.8" aria-hidden="true">
      <path d="M20 6L9 17l-5-5"/>
    </svg>
    <h4>${esc(title)}</h4>
    ${description ? `<p>${esc(description)}</p>` : ''}
  `;
  return wrap;
}
