/**
 * MiniMapa — mapa leve (OpenStreetMap, projeção Web Mercator) para escolher
 * o CENTRO e o RAIO de uma captação. 30/09/2026.
 *
 * Por que não Leaflet: o projeto não tem biblioteca de mapa; baixar Leaflet de
 * um CDN dentro do painel autenticado seria um script de terceiro com acesso à
 * sessão (risco de cadeia de suprimentos) e a CSP do site é script-src 'self'.
 * O que precisamos é pouco (arrastar, zoom, clicar, marcador, círculo) — cabe
 * em ~250 linhas sem dependência. Os ladrilhos são <img> (img-src https: já
 * permitido) com a atribuição exigida pela política de uso do OpenStreetMap.
 *
 * Estado ÚNICO: o mapa não guarda cópia própria da seleção; ele lê/escreve
 * pelo callback `onChange({ latitude, longitude, raio_metros })` e pela função
 * `definir(...)` — quem manda é o formulário.
 *
 * 01/10 — ÁREA PERSONALIZADA: modo 'poligono' (definirModo). Cada clique
 * acrescenta um vértice (3 a 12); o centro vira o centróide e o raio, a maior
 * distância até um vértice (é o círculo que as fontes consultam). O servidor
 * depois descarta o que caiu FORA do polígono (pipeline.dentroDoPoligono).
 * onChange recebe também `geometry` (GeoJSON Polygon) ou null.
 *
 * Uso:
 *   const mapa = criarMiniMapa(host, { latitude, longitude, raio_metros, onChange });
 *   mapa.definir({ latitude, longitude });   // ex.: ao escolher uma cidade
 *   mapa.destruir();                          // remove listeners e DOM (sem vazamento)
 */
const TILE = 256;
const URL_TILE = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const ZOOM_MIN = 8;
const ZOOM_MAX = 17;

const lon2x = (lon, z) => ((lon + 180) / 360) * TILE * 2 ** z;
const lat2y = (lat, z) => {
  const r = (lat * Math.PI) / 180;
  return ((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2) * TILE * 2 ** z;
};
const x2lon = (x, z) => (x / (TILE * 2 ** z)) * 360 - 180;
const y2lat = (y, z) => {
  const n = Math.PI - (2 * Math.PI * y) / (TILE * 2 ** z);
  return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
};
/** metros por pixel na latitude dada (Web Mercator). */
const metrosPorPixel = (lat, z) => (156543.03392 * Math.cos((lat * Math.PI) / 180)) / 2 ** z;

function zoomParaRaio(raioM, lat, alturaPx) {
  // o círculo inteiro deve caber com folga (diâmetro ≈ 70% da altura)
  for (let z = ZOOM_MAX; z >= ZOOM_MIN; z -= 1) {
    if ((2 * raioM) / metrosPorPixel(lat, z) <= alturaPx * 0.7) return z;
  }
  return ZOOM_MIN;
}

let instanciaAtiva = null; // nunca dois mapas ao mesmo tempo

export function criarMiniMapa(host, { latitude, longitude, raio_metros = 5000, onChange, rotulo = 'Mapa para escolher a área da busca' } = {}) {
  if (instanciaAtiva) instanciaAtiva.destruir();

  const sel = { latitude: Number(latitude), longitude: Number(longitude), raio_metros: Number(raio_metros) };
  const el = document.createElement('div');
  el.className = 'minimapa';
  el.setAttribute('role', 'application');
  el.setAttribute('aria-label', `${rotulo}. Clique para marcar o centro; use as setas para mover o marcador e os botões + e − para o zoom.`);
  el.tabIndex = 0;
  el.innerHTML = `
    <div class="minimapa-tiles" aria-hidden="true"></div>
    <svg class="minimapa-sobre" aria-hidden="true"><circle class="minimapa-raio"></circle><polygon class="minimapa-poligono"></polygon></svg>
    <div class="minimapa-marcador" aria-hidden="true" title="Arraste para mover o centro"></div>
    <div class="minimapa-zoom">
      <button type="button" class="btn btn-ghost btn-xs" data-z="1" aria-label="Aproximar">+</button>
      <button type="button" class="btn btn-ghost btn-xs" data-z="-1" aria-label="Afastar">−</button>
    </div>
    <div class="minimapa-atrib">© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">colaboradores do OpenStreetMap</a></div>
  `;
  host.appendChild(el);
  const tilesEl = el.querySelector('.minimapa-tiles');
  const circulo = el.querySelector('.minimapa-raio');
  const poligonoEl = el.querySelector('.minimapa-poligono');
  let modo = 'circulo';
  let vertices = []; // [{latitude, longitude}]
  const marcador = el.querySelector('.minimapa-marcador');

  let largura = el.clientWidth || 600;
  let altura = el.clientHeight || 320;
  let z = zoomParaRaio(sel.raio_metros, sel.latitude, altura);
  // centro da VISTA em pixels do mundo (pode diferir do marcador depois de arrastar o mapa)
  let cx = lon2x(sel.longitude, z);
  let cy = lat2y(sel.latitude, z);
  let quadro = 0;
  let destruido = false;

  function geometria() {
    if (modo !== 'poligono' || vertices.length < 3) return null;
    const anel = vertices.map((v) => [Number(v.longitude.toFixed(6)), Number(v.latitude.toFixed(6))]);
    anel.push(anel[0]);
    return { type: 'Polygon', coordinates: [anel] };
  }
  /** área aproximada em km² (polígono: fórmula do laço em metros locais; círculo: π r²) */
  function areaKm2() {
    if (modo === 'poligono' && vertices.length >= 3) {
      const lat0 = (sel.latitude * Math.PI) / 180;
      const pts = vertices.map((v) => [v.longitude * 111320 * Math.cos(lat0), v.latitude * 110540]);
      let a = 0;
      for (let i = 0; i < pts.length; i += 1) { const [x1, y1] = pts[i]; const [x2, y2] = pts[(i + 1) % pts.length]; a += x1 * y2 - x2 * y1; }
      return Math.abs(a) / 2 / 1e6;
    }
    if (modo === 'poligono') return 0;
    return (Math.PI * sel.raio_metros * sel.raio_metros) / 1e6;
  }
  function avisar() { if (typeof onChange === 'function') onChange({ ...sel, geometry: geometria(), area_km2: areaKm2(), vertices: vertices.length }); }
  /** centro = centróide simples; raio = maior distância até um vértice (mín. 500 m) */
  function recalcularDoPoligono() {
    if (vertices.length < 3) return;
    const lat = vertices.reduce((a, v) => a + v.latitude, 0) / vertices.length;
    const lon = vertices.reduce((a, v) => a + v.longitude, 0) / vertices.length;
    const dist = (v) => {
      const R = 6371000; const r = Math.PI / 180;
      const dLat = (v.latitude - lat) * r; const dLon = (v.longitude - lon) * r;
      const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat * r) * Math.cos(v.latitude * r) * Math.sin(dLon / 2) ** 2;
      return 2 * R * Math.asin(Math.sqrt(h));
    };
    sel.latitude = Number(lat.toFixed(6));
    sel.longitude = Number(lon.toFixed(6));
    sel.raio_metros = Math.max(500, Math.ceil(Math.max(...vertices.map(dist)) / 100) * 100);
  }

  function desenhar() {
    quadro = 0;
    if (destruido) return;
    const x0 = cx - largura / 2;
    const y0 = cy - altura / 2;
    const n = 2 ** z;
    const ti0 = Math.floor(x0 / TILE); const ti1 = Math.floor((x0 + largura) / TILE);
    const tj0 = Math.max(0, Math.floor(y0 / TILE)); const tj1 = Math.min(n - 1, Math.floor((y0 + altura) / TILE));
    const frag = document.createDocumentFragment();
    for (let i = ti0; i <= ti1; i += 1) {
      for (let j = tj0; j <= tj1; j += 1) {
        const img = document.createElement('img');
        const xi = ((i % n) + n) % n;
        img.src = URL_TILE.replace('{z}', z).replace('{x}', xi).replace('{y}', j);
        img.alt = '';
        img.draggable = false;
        img.loading = 'lazy';
        img.decoding = 'async';
        img.referrerPolicy = 'strict-origin-when-cross-origin';
        img.style.transform = `translate(${Math.round(i * TILE - x0)}px, ${Math.round(j * TILE - y0)}px)`;
        frag.appendChild(img);
      }
    }
    tilesEl.replaceChildren(frag);
    const mx = lon2x(sel.longitude, z) - x0;
    const my = lat2y(sel.latitude, z) - y0;
    marcador.style.transform = `translate(${Math.round(mx)}px, ${Math.round(my)}px)`;
    circulo.setAttribute('cx', mx);
    circulo.setAttribute('cy', my);
    circulo.setAttribute('r', Math.max(2, sel.raio_metros / metrosPorPixel(sel.latitude, z)));
    const emPoligono = modo === 'poligono';
    circulo.style.display = emPoligono && vertices.length >= 3 ? 'none' : '';
    poligonoEl.setAttribute('points', emPoligono ? vertices.map((v) => `${lon2x(v.longitude, z) - x0},${lat2y(v.latitude, z) - y0}`).join(' ') : '');
    marcador.classList.toggle('is-fixo', emPoligono);
    el.classList.toggle('is-poligono', emPoligono);
  }
  const agendar = () => { if (!quadro) quadro = requestAnimationFrame(desenhar); };

  function pontoParaLatLon(px, py) {
    return { latitude: y2lat(cy - altura / 2 + py, z), longitude: x2lon(cx - largura / 2 + px, z) };
  }
  function moverMarcador(px, py) {
    const p = pontoParaLatLon(px, py);
    sel.latitude = Number(p.latitude.toFixed(6));
    sel.longitude = Number(p.longitude.toFixed(6));
    agendar();
  }
  function aplicarZoom(dz, ancora) {
    const nz = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, z + dz));
    if (nz === z) return;
    const ax = ancora ? ancora.x : largura / 2;
    const ay = ancora ? ancora.y : altura / 2;
    const alvo = pontoParaLatLon(ax, ay);
    z = nz;
    cx = lon2x(alvo.longitude, z) - ax + largura / 2;
    cy = lat2y(alvo.latitude, z) - ay + altura / 2;
    agendar();
  }

  // ---- ponteiro: arrastar o mapa, arrastar o marcador, clicar para marcar ----
  let arraste = null;
  function aoDescer(ev) {
    if (ev.button !== undefined && ev.button !== 0) return;
    if (ev.target.closest('.minimapa-zoom, .minimapa-atrib')) return;
    const r = el.getBoundingClientRect();
    arraste = { id: ev.pointerId, x: ev.clientX, y: ev.clientY, cx, cy, marcador: ev.target === marcador && modo !== 'poligono', moveu: false, r };
    el.setPointerCapture && el.setPointerCapture(ev.pointerId);
  }
  function aoMover(ev) {
    if (!arraste || ev.pointerId !== arraste.id) return;
    const dx = ev.clientX - arraste.x; const dy = ev.clientY - arraste.y;
    if (Math.abs(dx) + Math.abs(dy) > 3) arraste.moveu = true;
    if (arraste.marcador) moverMarcador(ev.clientX - arraste.r.left, ev.clientY - arraste.r.top);
    else { cx = arraste.cx - dx; cy = arraste.cy - dy; agendar(); }
  }
  function aoSubir(ev) {
    if (!arraste || ev.pointerId !== arraste.id) return;
    const a = arraste; arraste = null;
    if (a.marcador) { avisar(); return; }
    if (!a.moveu) {
      if (modo === 'poligono') {
        if (vertices.length >= 12) return;
        vertices.push(pontoParaLatLon(ev.clientX - a.r.left, ev.clientY - a.r.top));
        recalcularDoPoligono(); agendar(); avisar();
        return;
      }
      moverMarcador(ev.clientX - a.r.left, ev.clientY - a.r.top); avisar();
    }
  }
  let rodaEspera = 0;
  function aoRolar(ev) {
    ev.preventDefault();
    const agora = Date.now();
    if (agora - rodaEspera < 180) return; // debounce: uma "tecla" de zoom por gesto
    rodaEspera = agora;
    const r = el.getBoundingClientRect();
    aplicarZoom(ev.deltaY < 0 ? 1 : -1, { x: ev.clientX - r.left, y: ev.clientY - r.top });
  }
  function aoTeclar(ev) {
    const passo = 20 * metrosPorPixel(sel.latitude, z);
    const graus = passo / 111320;
    const mapa = { ArrowUp: [graus, 0], ArrowDown: [-graus, 0], ArrowLeft: [0, -graus], ArrowRight: [0, graus] };
    if (mapa[ev.key]) {
      ev.preventDefault();
      sel.latitude = Number((sel.latitude + mapa[ev.key][0]).toFixed(6));
      sel.longitude = Number((sel.longitude + mapa[ev.key][1] / Math.cos((sel.latitude * Math.PI) / 180)).toFixed(6));
      centralizar(); avisar();
    } else if (ev.key === '+' || ev.key === '=') { ev.preventDefault(); aplicarZoom(1); }
    else if (ev.key === '-') { ev.preventDefault(); aplicarZoom(-1); }
  }
  function aoZoomBotao(ev) {
    const b = ev.target.closest('[data-z]');
    if (b) aplicarZoom(Number(b.dataset.z));
  }
  function centralizar() {
    cx = lon2x(sel.longitude, z);
    cy = lat2y(sel.latitude, z);
    agendar();
  }
  const ro = typeof ResizeObserver === 'function' ? new ResizeObserver(() => {
    const nl = el.clientWidth; const na = el.clientHeight;
    if (nl && na && (nl !== largura || na !== altura)) { largura = nl; altura = na; agendar(); }
  }) : null;

  el.addEventListener('pointerdown', aoDescer);
  el.addEventListener('pointermove', aoMover);
  el.addEventListener('pointerup', aoSubir);
  el.addEventListener('pointercancel', aoSubir);
  el.addEventListener('wheel', aoRolar, { passive: false });
  el.addEventListener('keydown', aoTeclar);
  el.querySelector('.minimapa-zoom').addEventListener('click', aoZoomBotao);
  if (ro) ro.observe(el);
  desenhar();

  const api = {
    /** Atualiza a seleção vinda do formulário (cidade escolhida, raio alterado). Não chama onChange. */
    definir({ latitude: la, longitude: lo, raio_metros: rm } = {}, { enquadrar = true } = {}) {
      if (Number.isFinite(Number(la)) && Number.isFinite(Number(lo))) { sel.latitude = Number(la); sel.longitude = Number(lo); }
      if (Number.isFinite(Number(rm)) && Number(rm) > 0) sel.raio_metros = Number(rm);
      if (enquadrar) z = zoomParaRaio(sel.raio_metros, sel.latitude, altura);
      centralizar();
    },
    selecao: () => ({ ...sel, geometry: geometria(), area_km2: areaKm2(), vertices: vertices.length }),
    /** 'circulo' (padrão) ou 'poligono'. Trocar de modo limpa o polígono. */
    definirModo(novo) {
      modo = novo === 'poligono' ? 'poligono' : 'circulo';
      vertices = [];
      agendar(); avisar();
    },
    desfazerPonto() { vertices.pop(); if (vertices.length >= 3) recalcularDoPoligono(); agendar(); avisar(); },
    limparPoligono() { vertices = []; agendar(); avisar(); },
    totalPontos: () => vertices.length,
    destruir() {
      if (destruido) return;
      destruido = true;
      if (quadro) cancelAnimationFrame(quadro);
      if (ro) ro.disconnect();
      el.removeEventListener('pointerdown', aoDescer);
      el.removeEventListener('pointermove', aoMover);
      el.removeEventListener('pointerup', aoSubir);
      el.removeEventListener('pointercancel', aoSubir);
      el.removeEventListener('wheel', aoRolar);
      el.removeEventListener('keydown', aoTeclar);
      el.remove();
      if (instanciaAtiva === api) instanciaAtiva = null;
    },
    elemento: el,
  };
  instanciaAtiva = api;
  return api;
}

export const _internos = { lon2x, lat2y, x2lon, y2lat, metrosPorPixel, zoomParaRaio };
