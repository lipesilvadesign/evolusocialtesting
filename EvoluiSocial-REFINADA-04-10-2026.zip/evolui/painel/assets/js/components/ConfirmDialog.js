/**
 * Modal de confirmação, baseado em Promise — usado antes de qualquer ação
 * destrutiva (excluir conteúdo, despublicar).
 *
 * 29/09: title/description agora são SEMPRE texto (escapados aqui dentro —
 * quem chama não precisa mais lembrar de esc()), e o modal usa o
 * componente compartilhado: foco preso, Esc fecha, foco volta ao botão
 * que abriu. O foco inicial fica em "Cancelar" (ação segura) — antes caía
 * direto em "Excluir", e um Enter distraído apagava o registro.
 * @param {{ title: string, description: string, confirmLabel?: string, tone?: 'danger'|'default' }} opts
 * @returns {Promise<boolean>}
 */
import { abrirModal } from './Modal.js';
import { esc } from '../utils/html.js';

export function confirmDialog({ title, description, confirmLabel = 'Confirmar', tone = 'danger' }) {
  return new Promise((resolve) => {
    let resultado = false;
    const { box, close } = abrirModal({
      titulo: title,
      maxWidth: '480px',
      role: 'alertdialog',
      html: `
        <p class="confirm-descricao" style="color:var(--text-muted);font-size:.88rem;margin:var(--space-2) 0 var(--space-5)">${esc(description)}</p>
        <div style="display:flex;gap:var(--space-3);justify-content:flex-end;flex-wrap:wrap">
          <button type="button" class="btn btn-ghost btn-sm" data-confirm="cancelar">Cancelar</button>
          <button type="button" class="btn ${tone === 'danger' ? 'btn-danger' : 'btn-primary'} btn-sm" data-confirm="ok">${esc(confirmLabel)}</button>
        </div>
      `,
      onClose: () => resolve(resultado),
    });
    const desc = box.querySelector('.confirm-descricao');
    desc.id = `${box.getAttribute('aria-labelledby')}-desc`;
    box.setAttribute('aria-describedby', desc.id);
    box.querySelector('[data-confirm="cancelar"]').addEventListener('click', () => close());
    box.querySelector('[data-confirm="ok"]').addEventListener('click', () => { resultado = true; close(); });
    requestAnimationFrame(() => requestAnimationFrame(() => box.querySelector('[data-confirm="cancelar"]').focus()));
  });
}
