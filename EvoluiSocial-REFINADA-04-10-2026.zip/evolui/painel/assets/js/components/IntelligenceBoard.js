import { updateOpportunityStatus } from '../services/intelligenceClient.js';
import { showToast } from './Toast.js';
import { esc } from '../utils/html.js';

const STATUS_LABEL = { novo: 'Novo', em_andamento: 'Em andamento', concluido: 'Concluído', descartado: 'Descartado' };
const IMPACT_BADGE = { alto: 'badge-danger', medio: 'badge-warning', baixo: 'badge-demo' };
const EFFORT_LABEL = { alto: 'Esforço alto', medio: 'Esforço médio', baixo: 'Esforço baixo' };
const STRENGTH_BADGE = { forte: 'badge-ok', moderada: 'badge-warning', limitada: 'badge-demo' };

function scoreColor(score) {
  if (score == null) return 'var(--text-muted)';
  if (score >= 65) return 'var(--ok)';
  if (score >= 40) return 'var(--warning)';
  return 'var(--danger)';
}

function renderHealthScore(healthScore) {
  const card = document.createElement('section');
  card.className = 'card';
  card.innerHTML = '<div class="card-head"><h3>Health Score</h3></div>';

  const overallWrap = document.createElement('div');
  overallWrap.style.cssText = 'text-align:center;margin-bottom:var(--space-5)';
  overallWrap.innerHTML = `
    <div style="font-family:var(--font-display);font-size:2.6rem;font-weight:700;color:${scoreColor(healthScore.overall)}">
      ${healthScore.overall != null ? healthScore.overall : '—'}
    </div>
    <div style="color:var(--text-muted);font-size:.82rem">de 100 · média das sub-notas disponíveis</div>
  `;
  card.appendChild(overallWrap);

  const grid = document.createElement('div');
  grid.className = 'card-grid';
  healthScore.subScores.forEach((s) => {
    const el = document.createElement('div');
    el.className = 'card metric-card';
    el.innerHTML = `
      <div class="metric-label">${esc(s.label)}${s.isProxy ? ' <span class="badge badge-demo" style="margin-left:4px">proxy</span>' : ''}</div>
      <div class="metric-value" style="color:${scoreColor(s.score)}">${s.score != null ? s.score : '—'}</div>
      <p style="font-size:.78rem;color:var(--text-muted);margin-top:var(--space-2)">${esc(s.explanation)}</p>
    `;
    grid.appendChild(el);
  });
  card.appendChild(grid);
  return card;
}

function renderAnomalies(anomalies) {
  const card = document.createElement('section');
  card.className = 'card';
  card.innerHTML = '<div class="card-head"><h3>Anomalias</h3><span class="badge badge-demo">linha de base: 90 dias</span></div>';
  if (anomalies.length === 0) {
    const p = document.createElement('p');
    p.style.cssText = 'color:var(--text-muted);font-size:.86rem';
    p.textContent = 'Nada fora do padrão histórico nos últimos dias.';
    card.appendChild(p);
    return card;
  }
  anomalies.forEach((a) => {
    const row = document.createElement('div');
    row.style.cssText = 'padding:var(--space-3) 0;border-bottom:1px solid var(--border)';
    row.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:var(--space-2);align-items:center">
        <strong style="font-size:.88rem">${esc(a.metricLabel)} — ${esc(a.direction)} incomum em ${esc(a.date)}</strong>
        <span class="badge ${a.severity === 'alta' ? 'badge-danger' : 'badge-warning'}">${a.zScore >= 0 ? '+' : ''}${a.zScore}σ</span>
      </div>
      <p style="font-size:.8rem;color:var(--text-muted);margin-top:4px">
        Valor: ${esc(a.value)} · média dos últimos ${esc(a.baselineDays)} dias: ${esc(a.baselineMean)} (desvio-padrão ${esc(a.baselineStdDev)})
      </p>
    `;
    card.appendChild(row);
  });
  return card;
}

function renderCorrelations(correlations) {
  const card = document.createElement('section');
  card.className = 'card';
  card.innerHTML = '<div class="card-head"><h3>Correlações</h3></div>';
  if (correlations.length === 0) {
    const p = document.createElement('p');
    p.style.cssText = 'color:var(--text-muted);font-size:.86rem';
    p.textContent = 'Nenhuma correlação relevante identificada neste período.';
    card.appendChild(p);
    return card;
  }
  correlations.forEach((c) => {
    const row = document.createElement('div');
    row.style.cssText = 'padding:var(--space-3) 0;border-bottom:1px solid var(--border)';
    row.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:var(--space-2);align-items:flex-start">
        <strong style="font-size:.88rem">${esc(c.title)}</strong>
        <span class="badge ${STRENGTH_BADGE[c.strength] || 'badge-demo'}">${esc(c.strength)}</span>
      </div>
      <p style="font-size:.84rem;margin-top:4px">${esc(c.description)}</p>
    `;
    card.appendChild(row);
  });
  return card;
}

function renderOpportunityCard(o, onStatusChange) {
  const card = document.createElement('div');
  card.className = 'card';
  card.style.borderColor = o.impact === 'alto' ? 'var(--star)' : 'var(--border)';

  const head = document.createElement('div');
  head.className = 'card-head';
  head.innerHTML = `
    <h4 style="font-size:.92rem">${esc(o.title)}</h4>
    <span class="badge badge-demo">${esc(o.quadrant)}</span>
  `;
  card.appendChild(head);

  const desc = document.createElement('p');
  desc.style.cssText = 'font-size:.84rem;margin-bottom:var(--space-3)';
  desc.textContent = o.description;
  card.appendChild(desc);

  const badges = document.createElement('div');
  badges.style.cssText = 'display:flex;gap:var(--space-2);flex-wrap:wrap;margin-bottom:var(--space-3)';
  badges.innerHTML = `
    <span class="badge ${IMPACT_BADGE[o.impact] || 'badge-demo'}">Impacto ${esc(o.impact)}</span>
    <span class="badge badge-demo">${esc(EFFORT_LABEL[o.effort] || o.effort)}</span>
  `;
  card.appendChild(badges);

  if (o.id) {
    const statusRow = document.createElement('div');
    statusRow.className = 'field';
    statusRow.style.marginBottom = '0';
    const label = document.createElement('label');
    label.textContent = 'Status';
    const select = document.createElement('select');
    Object.entries(STATUS_LABEL).forEach(([value, text]) => {
      const opt = document.createElement('option');
      opt.value = value;
      opt.textContent = text;
      if (value === o.status) opt.selected = true;
      select.appendChild(opt);
    });
    select.addEventListener('change', async () => {
      const previous = o.status;
      select.disabled = true;
      try {
        await updateOpportunityStatus(o.id, select.value);
        o.status = select.value;
        showToast('Status atualizado.', { tone: 'ok' });
        if (onStatusChange) onStatusChange();
      } catch (err) {
        select.value = previous;
        showToast(err.message || 'Falha ao atualizar status.', { tone: 'danger' });
      } finally {
        select.disabled = false;
      }
    });
    statusRow.appendChild(label);
    statusRow.appendChild(select);
    card.appendChild(statusRow);
  }

  return card;
}

function renderOpportunities(opportunities, onStatusChange) {
  const card = document.createElement('section');
  card.className = 'card';
  card.innerHTML = '<div class="card-head"><h3>Oportunidades priorizadas</h3></div>';
  if (opportunities.length === 0) {
    const p = document.createElement('p');
    p.style.cssText = 'color:var(--text-muted);font-size:.86rem';
    p.textContent = 'Nenhuma oportunidade identificada neste período — bom sinal.';
    card.appendChild(p);
    return card;
  }
  const grid = document.createElement('div');
  grid.className = 'card-grid';
  opportunities.forEach((o) => grid.appendChild(renderOpportunityCard(o, onStatusChange)));
  card.appendChild(grid);
  return card;
}

/**
 * @param {object} intelligence - saída de intelligenceService.computeAdvancedIntelligence()
 * @param {{ onStatusChange?: () => void }} [opts]
 * @returns {HTMLElement}
 */
export function renderIntelligenceBoard(intelligence, opts = {}) {
  const wrap = document.createElement('div');
  wrap.appendChild(renderHealthScore(intelligence.healthScore));
  wrap.appendChild(renderAnomalies(intelligence.anomalies));
  wrap.appendChild(renderCorrelations(intelligence.correlations));
  wrap.appendChild(renderOpportunities(intelligence.opportunities, opts.onStatusChange));
  return wrap;
}
