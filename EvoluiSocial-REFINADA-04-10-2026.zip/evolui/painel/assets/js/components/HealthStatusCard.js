import { esc } from '../utils/html.js';
function badgeClass(ok) {
  return ok ? 'badge-ok' : 'badge-danger';
}

/**
 * @param {{ status: 'ok'|'degraded', checkedAt: string, services: Array<{name:string, ok:boolean, latencyMs:number, detail:string|null}> }} health
 * @returns {HTMLElement}
 */
export function renderHealthStatus(health) {
  const card = document.createElement('section');
  card.className = 'card';
  card.innerHTML = `
    <div class="card-head">
      <h3>Status dos serviços</h3>
      <span class="badge ${health.status === 'ok' ? 'badge-ok' : 'badge-warning'}">${health.status === 'ok' ? 'Tudo certo' : 'Atenção'}</span>
    </div>
  `;

  const grid = document.createElement('div');
  grid.className = 'card-grid';
  health.services.forEach((s) => {
    const el = document.createElement('div');
    el.className = 'card metric-card';
    el.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <span class="metric-label">${esc(s.name)}</span>
        <span class="badge ${badgeClass(s.ok)}">${s.ok ? 'OK' : 'Falha'}</span>
      </div>
      ${s.latencyMs ? `<div style="font-size:.78rem;color:var(--text-muted)">${esc(s.latencyMs)}ms</div>` : ''}
      ${s.detail ? `<p style="font-size:.78rem;color:var(--text-muted);margin-top:4px">${esc(s.detail)}</p>` : ''}
    `;
    grid.appendChild(el);
  });
  card.appendChild(grid);

  const footer = document.createElement('p');
  footer.style.cssText = 'font-size:.76rem;color:var(--text-muted);margin-top:var(--space-3)';
  footer.textContent = `Verificado em ${new Date(health.checkedAt).toLocaleString('pt-BR')}.`;
  card.appendChild(footer);

  return card;
}
