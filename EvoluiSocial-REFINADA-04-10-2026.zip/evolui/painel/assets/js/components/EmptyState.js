import { esc } from '../utils/html.js';
/**
 * EmptyState — usado quando a busca teve sucesso mas não há dados.
 * Sempre exige uma explicação do motivo (não deixa a UI vazia sem contexto).
 * @param {{ title: string, description: string, actionLabel?: string, onAction?: () => void }} opts
 * @returns {HTMLElement}
 */
export function EmptyState({ title, description, actionLabel, onAction }) {
  const wrap = document.createElement('div');
  wrap.className = 'state-block';
  wrap.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true">
      <rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
    </svg>
    <h4>${esc(title)}</h4>
    <p>${esc(description)}</p>
  `;
  if (actionLabel && onAction) {
    const btn = document.createElement('button');
    btn.className = 'btn btn-ghost btn-sm';
    btn.textContent = actionLabel;
    btn.addEventListener('click', onAction);
    wrap.appendChild(btn);
  }
  return wrap;
}
