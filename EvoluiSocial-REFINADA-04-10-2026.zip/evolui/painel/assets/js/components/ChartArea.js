/**
 * Gráfico de área com linha suave — inspirado no visual "estatísticas
 * estilo BTC/USD" que você mandou (linha curva + área com gradiente
 * esmaecendo até transparente), pedido 13/09 3ª rodada. Puro SVG nativo,
 * sem biblioteca de gráfico nova — a curva é calculada aqui mesmo (spline
 * Catmull-Rom convertida pra Bézier cúbica, uma técnica bem estabelecida
 * pra suavizar uma sequência de pontos sem depender de lib externa).
 *
 * Aviso honesto: não tive como reabrir https://spell.sh/docs/shimmer-text
 * nesta rodada (limite de acesso à web da sessão) pra copiar o componente
 * "Chart" exato que você colou — este é um equivalente nativo, no mesmo
 * espírito visual (linha + gradiente sob a curva), não uma cópia pixel a
 * pixel do original.
 */

let proximoId = 0;

// Achado nesta auditoria (endurecimento preventivo, não uma falha ativa
// hoje): nenhuma tela atual passa texto de usuário pra `series[].nome`/
// `categorias` (são sempre rótulos fixos no código, ex.: "Receitas"), mas
// o componente é reaproveitável — sem escapar aqui, a PRÓXIMA tela que
// reaproveitar ChartArea com um rótulo vindo do banco reintroduziria a
// mesma classe de XSS já corrigida em outros lugares, sem aviso nenhum.
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function pontosParaPathSuave(pontos) {
  if (pontos.length === 0) return '';
  if (pontos.length === 1) return `M ${pontos[0].x} ${pontos[0].y}`;
  let d = `M ${pontos[0].x} ${pontos[0].y}`;
  for (let i = 0; i < pontos.length - 1; i++) {
    const p0 = pontos[i === 0 ? i : i - 1];
    const p1 = pontos[i];
    const p2 = pontos[i + 1];
    const p3 = pontos[i + 2 < pontos.length ? i + 2 : i + 1];
    const cp1x = p1.x + (p2.x - p0.x) / 6;
    const cp1y = p1.y + (p2.y - p0.y) / 6;
    const cp2x = p2.x - (p3.x - p1.x) / 6;
    const cp2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${cp1x.toFixed(2)} ${cp1y.toFixed(2)}, ${cp2x.toFixed(2)} ${cp2y.toFixed(2)}, ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`;
  }
  return d;
}

/**
 * @param {{ categorias: string[], series: { nome: string, cor: string, valores: number[] }[] }} dados
 * @returns {string} HTML (svg + legenda + eixo). Usar com innerHTML/appendChild.
 */
export function chartAreaHtml({ categorias, series }) {
  const largura = 600;
  const altura = 170;
  const padX = 6;
  const padY = 16;

  const todosValores = series.flatMap((s) => s.valores);
  const maxValor = Math.max(1, ...todosValores);
  const n = categorias.length;

  const x = (i) => (n <= 1 ? largura / 2 : padX + (i * (largura - padX * 2)) / (n - 1));
  const y = (v) => altura - padY - (v / maxValor) * (altura - padY * 2);

  const grades = [0, 0.5, 1].map((f) => {
    const gy = padY + f * (altura - padY * 2);
    return `<line x1="${padX}" y1="${gy.toFixed(1)}" x2="${largura - padX}" y2="${gy.toFixed(1)}" class="chart-area-grade" />`;
  }).join('');

  const camadas = series.map((s) => {
    const idGrad = `chartAreaGrad${proximoId++}`;
    const pontos = s.valores.map((v, i) => ({ x: x(i), y: y(v) }));
    const linhaPath = pontosParaPathSuave(pontos);
    const baseY = altura - padY;
    const areaPath = pontos.length > 0
      ? `${linhaPath} L ${pontos[pontos.length - 1].x.toFixed(2)} ${baseY} L ${pontos[0].x.toFixed(2)} ${baseY} Z`
      : '';
    return `
      <defs>
        <linearGradient id="${idGrad}" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${s.cor}" stop-opacity="0.35" />
          <stop offset="100%" stop-color="${s.cor}" stop-opacity="0" />
        </linearGradient>
      </defs>
      <path d="${areaPath}" fill="url(#${idGrad})" class="chart-area-fill" />
      <path d="${linhaPath}" fill="none" stroke="${s.cor}" class="chart-area-linha" />
    `;
  }).join('');

  const legenda = series.map((s) => `<span><i style="background:${s.cor}"></i>${esc(s.nome)}</span>`).join('');
  const eixo = categorias.map((c) => `<span>${esc(c)}</span>`).join('');

  return `
    <div class="chart-area fx-blur-reveal">
      <svg viewBox="0 0 ${largura} ${altura}" class="chart-area-svg" preserveAspectRatio="none" role="img" aria-label="Gráfico de tendência por dia">
        ${grades}
        ${camadas}
      </svg>
      <div class="chart-area-eixo">${eixo}</div>
      <div class="chart-area-legenda">${legenda}</div>
    </div>
  `;
}
