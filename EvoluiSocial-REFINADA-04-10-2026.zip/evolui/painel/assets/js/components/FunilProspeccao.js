/**
 * Funil de prospecção — redesenho (pedido 13/09, 3ª rodada: "o funil de
 * prospecção tá horrível"). Antes era uma lista de barras simples, todas do
 * mesmo tom, sem nenhuma leitura de "quanto caiu de um estágio pro
 * próximo". Agora: cada estágio tem sua própria cor (reaproveitando as
 * MESMAS cores já usadas nos badges de status em Clientes — nenhuma cor
 * nova inventada), a barra afunila visualmente (trapézio via clip-path,
 * puro CSS), mostra "% do total de leads" (não só a contagem crua), e
 * anota a queda entre um estágio e o seguinte quando ela existe.
 *
 * "Perdido" (nao_convertido) fica FORA do afunilamento — não é um estágio
 * seguinte no funil, é uma saída dele — e some como uma linha separada
 * abaixo, do jeito que já era mostrado, só que fora do fluxo principal.
 *
 * Puro — só recebe contagens já calculadas por quem chama (desempenho.js),
 * fácil de testar sem precisar simular fetch/Supabase.
 */

const STATUS_PERDIDO = 'nao_convertido';

const COR_POR_CLS = {
  'badge-demo': 'var(--text-muted)',
  'badge-info': 'var(--info)',
  'badge-warning': 'var(--warning)',
  'badge-ok': 'var(--ok)',
  'badge-danger': 'var(--danger)',
};

/**
 * @param {Record<string, number>} contagemPorStatus
 * @param {string[]} statusOrder
 * @param {Record<string, { label: string, cls: string }>} statusMap
 * @returns {string} HTML (usar com innerHTML/appendChild dentro de um container já criado)
 */
export function funilProspeccaoHtml(contagemPorStatus, statusOrder, statusMap) {
  const estagios = statusOrder.filter((s) => s !== STATUS_PERDIDO);
  const perdidos = contagemPorStatus[STATUS_PERDIDO] || 0;
  const totalGeral = statusOrder.reduce((soma, s) => soma + (contagemPorStatus[s] || 0), 0);

  if (totalGeral === 0) {
    return '<p class="kpi-empty">Nenhum lead cadastrado ainda.</p>';
  }

  const maxContagem = Math.max(1, ...estagios.map((s) => contagemPorStatus[s] || 0));

  let anterior = null;
  const linhas = estagios.map((s) => {
    const n = contagemPorStatus[s] || 0;
    const pctLargura = Math.max(4, Math.round((n / maxContagem) * 100));
    const pctTotal = Math.round((n / totalGeral) * 100);
    const info = statusMap[s] || { label: s, cls: 'badge-demo' };
    const cor = COR_POR_CLS[info.cls] || 'var(--star)';

    let quedaHtml = '';
    if (anterior != null && anterior > 0 && n < anterior) {
      const queda = Math.round((1 - n / anterior) * 100);
      quedaHtml = `<div class="funil2-queda">↓ ${queda}% não avançou</div>`;
    }
    anterior = n;

    return `
      ${quedaHtml}
      <div class="funil2-estagio">
        <div class="funil2-track"><div class="funil2-barra" style="width:${pctLargura}%;--cor:${cor}"></div></div>
        <div class="funil2-info">
          <span class="funil2-label">${info.label}</span>
          <span class="funil2-numeros"><strong>${n}</strong> <small>(${pctTotal}%)</small></span>
        </div>
      </div>
    `;
  }).join('');

  const perdidosHtml = perdidos > 0
    ? `<div class="funil2-perdidos"><span class="badge badge-danger">Perdidos</span> <strong>${perdidos}</strong> <small>(${Math.round((perdidos / totalGeral) * 100)}% do total)</small></div>`
    : '';

  return `<div class="funil2">${linhas}</div>${perdidosHtml}`;
}
