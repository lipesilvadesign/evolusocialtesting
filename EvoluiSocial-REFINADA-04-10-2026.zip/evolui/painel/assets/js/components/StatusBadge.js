const STATUS_MAP = {
  rascunho: { label: 'Rascunho', cls: 'badge-warning' },
  publicado: { label: 'Publicado', cls: 'badge-ok' },
  arquivado: { label: 'Arquivado', cls: 'badge-danger' },
};

/** @param {import('../../../../netlify/functions/_lib/types').ContentStatus} status */
export function statusBadgeHtml(status) {
  const info = STATUS_MAP[status] || STATUS_MAP.rascunho;
  return `<span class="badge ${info.cls}">${info.label}</span>`;
}

// STATUS_OPTIONS/STATUS_LABELS existiam aqui sem nenhum import em nenhuma
// tela do painel (achado da auditoria) — removidos na limpeza final.
