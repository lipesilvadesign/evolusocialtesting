import { getSchema, getField, setField, slugify } from '../content-schemas.js';
import { confirmDialog } from './ConfirmDialog.js';
import { showToast } from './Toast.js';

const AUTOSAVE_DELAY = 900;

/**
 * @param {{
 *   type: string,
 *   item: object,
 *   existingItems: object[],
 *   onSave: (payload:object) => Promise<object>,
 *   onDelete: () => Promise<void>,
 *   onCancel: () => void,
 * }} opts
 * @returns {HTMLElement}
 */
export function renderContentEditor({ type, item, existingItems, onSave, onDelete, onCancel }) {
  const schema = getSchema(type);
  const working = JSON.parse(JSON.stringify(item)); // cópia de trabalho — nada é salvo até validar
  const isNew = !working.id;
  let slugWasAuto = !working.slug;
  let autosaveTimer = null;
  let savingNow = false;

  const panel = document.createElement('section');
  panel.className = 'card content-editor';

  const head = document.createElement('div');
  head.className = 'card-head';
  head.innerHTML = `
    <h3>${isNew ? `Novo ${schema.singular || 'item'}` : `Editar`}</h3>
    <span class="autosave-indicator" id="autosaveIndicator"></span>
  `;
  panel.appendChild(head);

  const form = document.createElement('form');
  form.className = 'content-editor-form';
  form.noValidate = true;
  panel.appendChild(form);

  const errorsBox = document.createElement('div');
  errorsBox.className = 'form-errors';
  form.appendChild(errorsBox);

  const fieldEls = {};

  schema.fields.forEach((f) => {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    const label = document.createElement('label');
    label.textContent = f.label + (f.required ? ' *' : '');
    wrap.appendChild(label);

    let input;
    if (f.type === 'textarea') {
      input = document.createElement('textarea');
      if (f.large) input.rows = 10;
      input.value = getField(working, f.key);
    } else if (f.type === 'select') {
      input = document.createElement('select');
      f.options.forEach((opt) => {
        const o = document.createElement('option');
        o.value = opt;
        o.textContent = opt;
        input.appendChild(o);
      });
      input.value = getField(working, f.key) || f.options[0];
    } else if (f.type === 'date') {
      input = document.createElement('input');
      input.type = 'date';
      const raw = getField(working, f.key);
      input.value = raw ? String(raw).slice(0, 10) : '';
    } else if (f.type === 'image') {
      input = buildImageField(working, f, wrap);
    } else {
      input = document.createElement('input');
      input.type = 'text';
      input.value = getField(working, f.key);
    }

    if (f.type !== 'image') {
      input.addEventListener('input', () => {
        setField(working, f.key, input.value);
        if (f.slugSource && slugWasAuto) {
          const slugInput = fieldEls.slug;
          const newSlug = slugify(input.value);
          setField(working, 'slug', newSlug);
          if (slugInput) slugInput.value = newSlug;
        }
        if (f.key === 'slug') slugWasAuto = false;
        clearErrorFor(f.key);
        scheduleAutosave();
      });
      wrap.appendChild(input);
    }

    fieldEls[f.key] = input;
    form.appendChild(wrap);
  });

  const actions = document.createElement('div');
  actions.className = 'actions-bar';
  actions.style.marginTop = 'var(--space-4)';

  const saveBtn = document.createElement('button');
  saveBtn.type = 'button';
  saveBtn.className = 'btn btn-primary btn-sm';
  saveBtn.textContent = isNew ? 'Criar' : 'Salvar';
  saveBtn.addEventListener('click', () => doSave({ manual: true }));
  actions.appendChild(saveBtn);

  if (!isNew) {
    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.className = 'btn btn-ghost btn-sm';
    toggleBtn.textContent = working.status === 'publicado' ? 'Despublicar' : 'Publicar';
    toggleBtn.addEventListener('click', async () => {
      working.status = working.status === 'publicado' ? 'rascunho' : 'publicado';
      if (fieldEls.status) fieldEls.status.value = working.status;
      await doSave({ manual: true });
      toggleBtn.textContent = working.status === 'publicado' ? 'Despublicar' : 'Publicar';
    });
    actions.appendChild(toggleBtn);

    const archiveBtn = document.createElement('button');
    archiveBtn.type = 'button';
    archiveBtn.className = 'btn btn-ghost btn-sm';
    archiveBtn.textContent = 'Arquivar';
    archiveBtn.addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Arquivar este conteúdo?',
        description: 'Ele sai do site publicado, mas continua salvo e pode ser restaurado depois.',
        confirmLabel: 'Arquivar',
      });
      if (!ok) return;
      working.status = 'arquivado';
      if (fieldEls.status) fieldEls.status.value = 'arquivado';
      await doSave({ manual: true });
    });
    actions.appendChild(archiveBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'btn btn-danger btn-sm';
    deleteBtn.textContent = 'Excluir';
    deleteBtn.addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Excluir permanentemente?',
        description: 'Esta ação não pode ser desfeita.',
        confirmLabel: 'Excluir',
      });
      if (!ok) return;
      try {
        await onDelete();
        showToast('Excluído.', { tone: 'ok' });
      } catch (err) {
        showToast(err.message || 'Falha ao excluir.', { tone: 'danger' });
      }
    });
    actions.appendChild(deleteBtn);
  }

  const cancelBtn = document.createElement('button');
  cancelBtn.type = 'button';
  cancelBtn.className = 'btn btn-ghost btn-sm';
  cancelBtn.textContent = 'Fechar';
  cancelBtn.addEventListener('click', onCancel);
  actions.appendChild(cancelBtn);

  form.appendChild(actions);

  function buildImageField(target, f, wrap) {
    const row = document.createElement('div');
    row.className = 'img-field';

    const preview = document.createElement('img');
    preview.className = 'img-preview';
    preview.alt = '';
    preview.src = getField(target, f.key) || '';
    preview.style.display = getField(target, f.key) ? 'block' : 'none';

    const inputsWrap = document.createElement('div');
    inputsWrap.className = 'img-inputs';

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.style.display = 'none';

    const fileBtn = document.createElement('span');
    fileBtn.className = 'file-btn';
    fileBtn.textContent = getField(target, f.key) ? 'Trocar imagem' : 'Enviar imagem';
    fileBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        setField(target, f.key, reader.result);
        preview.src = reader.result;
        preview.style.display = 'block';
        fileBtn.textContent = 'Trocar imagem';
        clearErrorFor(f.key);
        scheduleAutosave();
      };
      reader.readAsDataURL(file);
    });

    const hint = document.createElement('p');
    hint.className = 'hint';
    hint.textContent = 'Imagens ficam salvas embutidas (mesmo formato já usado no restante do site).';

    inputsWrap.appendChild(fileBtn);
    inputsWrap.appendChild(fileInput);
    inputsWrap.appendChild(hint);
    row.appendChild(preview);
    row.appendChild(inputsWrap);
    wrap.appendChild(row);
    return fileInput;
  }

  function clearErrorFor(key) {
    const el = errorsBox.querySelector(`[data-error-for="${key}"]`);
    if (el) el.remove();
  }

  function validate() {
    const errors = [];
    schema.fields.forEach((f) => {
      if (f.required && !String(getField(working, f.key) || '').trim()) {
        errors.push({ key: f.key, message: `${f.label} é obrigatório.` });
      }
    });
    const slugValue = String(getField(working, 'slug') || '').trim();
    if (slugValue) {
      const clash = existingItems.find((i) => i.id !== working.id && (i.slug || '') === slugValue);
      if (clash) errors.push({ key: 'slug', message: 'Já existe outro item com este slug.' });
    }
    return errors;
  }

  function showErrors(errors) {
    errorsBox.innerHTML = '';
    errors.forEach((e) => {
      const p = document.createElement('p');
      p.dataset.errorFor = e.key;
      p.style.cssText = 'color:var(--danger);font-size:.8rem;margin-bottom:6px';
      p.textContent = e.message;
      errorsBox.appendChild(p);
    });
  }

  function scheduleAutosave() {
    if (isNew) return; // autosave só depois do primeiro "Criar" salvar de verdade
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(() => doSave({ manual: false }), AUTOSAVE_DELAY);
  }

  async function doSave({ manual }) {
    const errors = validate();
    if (errors.length > 0) {
      if (manual) showErrors(errors);
      return;
    }
    if (savingNow) return;
    savingNow = true;
    const indicator = panel.querySelector('#autosaveIndicator');
    if (indicator) indicator.textContent = 'Salvando…';
    try {
      const saved = await onSave(working);
      Object.assign(working, saved);
      if (indicator) indicator.textContent = 'Salvo';
      if (manual) showToast('Conteúdo salvo.', { tone: 'ok' });
    } catch (err) {
      if (indicator) indicator.textContent = '';
      showToast(err.message || 'Falha ao salvar.', { tone: 'danger' });
    } finally {
      savingNow = false;
    }
  }

  return panel;
}
