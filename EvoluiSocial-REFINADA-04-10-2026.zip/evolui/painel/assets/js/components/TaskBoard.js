import { updateTaskStatus, deleteTask } from '../services/tasksClient.js';
import { showToast } from './Toast.js';
import { confirmDialog } from './ConfirmDialog.js';

const COLUMNS = [
  { status: 'TODO', label: 'A fazer' },
  { status: 'IN_PROGRESS', label: 'Em andamento' },
  { status: 'DONE', label: 'Concluído' },
];

// achado nesta auditoria — falha de segurança real, não só teórica:
// título/descrição de tarefa vêm direto do corpo do POST em
// netlify/functions/tasks.js, sem nenhuma sanitização no servidor, e
// QUALQUER funcionário autenticado pode criar uma tarefa. Sem escapar
// aqui, um funcionário mal-intencionado (ou uma conta comprometida)
// poderia cadastrar um título como "<img src=x onerror=...>" e esse código
// rodaria no navegador de quem quer que abrisse Sistema → Tarefas —
// inclusive um admin. Mesma classe de falha já corrigida em clientes.js/
// prospeccao.js (13-14/09); esta tela ficou pra trás porque não passa por
// nenhuma daquelas views.
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function taskCard(task, onChange) {
  const card = document.createElement('div');
  card.className = 'card';
  card.style.marginBottom = 'var(--space-3)';
  card.innerHTML = `
    <h4 style="font-size:.88rem;margin-bottom:4px">${esc(task.titulo)}</h4>
    ${task.descricao ? `<p style="font-size:.8rem;color:var(--text-muted);margin-bottom:var(--space-2)">${esc(task.descricao)}</p>` : ''}
    ${task.origem_tipo && task.origem_tipo !== 'manual' ? `<span class="badge badge-demo" style="margin-bottom:var(--space-2)">origem: ${esc(task.origem_tipo)}</span>` : ''}
  `;

  const actions = document.createElement('div');
  actions.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;margin-top:var(--space-2)';

  COLUMNS.forEach((col) => {
    if (col.status === task.status) return;
    const btn = document.createElement('button');
    btn.className = 'btn btn-ghost btn-sm';
    btn.textContent = `→ ${col.label}`;
    btn.addEventListener('click', async () => {
      try {
        await updateTaskStatus(task.id, col.status);
        showToast('Tarefa atualizada.', { tone: 'ok' });
        onChange();
      } catch (err) {
        showToast(err.message || 'Falha ao atualizar tarefa.', { tone: 'danger' });
      }
    });
    actions.appendChild(btn);
  });

  const delBtn = document.createElement('button');
  delBtn.className = 'btn btn-danger btn-sm';
  delBtn.textContent = 'Excluir';
  delBtn.addEventListener('click', async () => {
    const ok = await confirmDialog({ title: 'Excluir tarefa?', description: 'Esta ação não pode ser desfeita.', confirmLabel: 'Excluir' });
    if (!ok) return;
    try {
      await deleteTask(task.id);
      showToast('Tarefa excluída.', { tone: 'ok' });
      onChange();
    } catch (err) {
      showToast(err.message || 'Falha ao excluir tarefa.', { tone: 'danger' });
    }
  });
  actions.appendChild(delBtn);

  card.appendChild(actions);
  return card;
}

/**
 * @param {object[]} tasks
 * @param {{ onChange: () => void }} opts
 * @returns {HTMLElement}
 */
export function renderTaskBoard(tasks, { onChange }) {
  const wrap = document.createElement('div');
  wrap.className = 'card-grid';
  wrap.style.alignItems = 'start';

  COLUMNS.forEach((col) => {
    const colWrap = document.createElement('div');
    const items = tasks.filter((t) => t.status === col.status);
    colWrap.innerHTML = `<h4 style="font-size:.85rem;margin-bottom:var(--space-3);color:var(--text-muted)">${col.label} (${items.length})</h4>`;
    if (items.length === 0) {
      const empty = document.createElement('p');
      empty.style.cssText = 'font-size:.8rem;color:var(--text-muted)';
      empty.textContent = 'Nada aqui.';
      colWrap.appendChild(empty);
    } else {
      items.forEach((t) => colWrap.appendChild(taskCard(t, onChange)));
    }
    wrap.appendChild(colWrap);
  });

  return wrap;
}
