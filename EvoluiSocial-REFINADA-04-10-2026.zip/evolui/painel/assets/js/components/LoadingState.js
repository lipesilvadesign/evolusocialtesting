/**
 * LoadingState — skeleton reutilizável para qualquer view em carregamento.
 * @param {{ rows?: number, variant?: 'lines'|'cards' }} [opts]
 * @returns {HTMLElement}
 */
export function LoadingState({ rows = 3, variant = 'lines' } = {}) {
  const wrap = document.createElement('div');
  wrap.setAttribute('role', 'status');
  wrap.setAttribute('aria-live', 'polite');
  wrap.setAttribute('aria-label', 'Carregando');

  if (variant === 'cards') {
    wrap.className = 'card-grid';
    for (let i = 0; i < rows; i++) {
      const el = document.createElement('div');
      el.className = 'skeleton skeleton-card';
      wrap.appendChild(el);
    }
    return wrap;
  }

  wrap.style.padding = 'var(--space-2) 0';
  for (let i = 0; i < rows; i++) {
    const line = document.createElement('div');
    line.className = 'skeleton skeleton-line';
    line.style.width = i === rows - 1 ? '60%' : '100%';
    wrap.appendChild(line);
  }
  return wrap;
}
