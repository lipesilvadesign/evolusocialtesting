/**
 * Avatares ilustrados — galeria de escolha (pedido do Felipe, 14/09, 3ª
 * rodada). Substitui o esquema antigo (2 avatares fixos, escolhidos pelo
 * campo `genero`) por uma galeria de 10 personagens variados, num estilo
 * flat/traço grosso (inspirado numa referência visual enviada pelo Felipe:
 * rostos simples, contorno preto, um tom de destaque por personagem) —
 * mais dinâmico, contemporâneo e "com cara de gente" do que os dois
 * avatares em gradiente 3D de antes.
 *
 * Cada pessoa escolhe o próprio avatar em "Meu perfil" (ver perfil.js) —
 * fica salvo em `admin_funcionarios.avatar_escolhido` (ver
 * SQL_PENDENTE_avatar_escolhido.sql). O campo `genero` continua existindo
 * no banco (não foi removido — só parou de ser a forma de escolher
 * avatar); a migração faz backfill de `avatar_escolhido` a partir dele
 * pra ninguém "perder" o avatar que já tinha.
 *
 * Sempre desenho ORIGINAL — nunca a cópia de um personagem/marca
 * existente, nome nenhum aparece aqui, só a mesma linguagem visual da
 * referência (formas simples, contorno forte, uma cor de destaque).
 *
 * @typedef {{ id: string, label: string, svg: string }} AvatarOpcao
 */

const CONTORNO = '#181818';

/**
 * @param {object} p
 * @param {string} p.bg cor de fundo do círculo
 * @param {string} p.pele cor da pele
 * @param {string} [p.peleSombra] sombra sutil sob o cabelo/queixo
 * @param {string} p.hairContent markup SVG do cabelo (atrás do rosto, ex. franja larga) — opcional
 * @param {string} p.hairFrontContent markup SVG do cabelo por cima (franja, topete) — opcional
 * @param {string} [p.extra] markup extra (óculos, barba, boné, laço…)
 * @param {boolean} [p.sorrisoAberto]
 */
function montarRosto({ bg, pele, peleSombra, hairBackContent = '', hairFrontContent = '', extra = '', sorrisoAberto = false }) {
  return `
  <circle cx="48" cy="48" r="48" fill="${bg}"/>
  ${hairBackContent}
  <circle cx="48" cy="50" r="22" fill="${pele}" stroke="${CONTORNO}" stroke-width="2.5"/>
  ${peleSombra ? `<path d="M30 58c4 6 30 6 34 0" fill="${peleSombra}" opacity=".28"/>` : ''}
  <ellipse cx="39" cy="49" rx="2.6" ry="3.2" fill="${CONTORNO}"/>
  <ellipse cx="57" cy="49" rx="2.6" ry="3.2" fill="${CONTORNO}"/>
  ${sorrisoAberto
    ? `<path d="M39 60c3 4 15 4 18 0" fill="none" stroke="${CONTORNO}" stroke-width="2.4" stroke-linecap="round"/>`
    : `<path d="M40 60c2.5 3 13 3 16 0" fill="none" stroke="${CONTORNO}" stroke-width="2.2" stroke-linecap="round"/>`}
  <ellipse cx="33" cy="55" rx="3" ry="1.8" fill="#E0805A" opacity=".3"/>
  <ellipse cx="63" cy="55" rx="3" ry="1.8" fill="#E0805A" opacity=".3"/>
  ${hairFrontContent}
  ${extra}
  `;
}

function oculos(cor = CONTORNO) {
  return `<g fill="none" stroke="${cor}" stroke-width="2.4">
    <circle cx="39" cy="49" r="7"/><circle cx="57" cy="49" r="7"/>
    <path d="M46 49h4"/><path d="M32 47l-5-1"/><path d="M64 47l5-1"/>
  </g>`;
}

/** Touca de cabelo confiável: um círculo atrás do rosto que "espia" por
 * cima e dos lados — a base de quase todo estilo, sempre cobre bem em
 * vez de depender de um path frágil. Cada preset só varia o raio/posição
 * e acrescenta detalhes (topete, coque, rabo, franjas laterais…). */
function toucaBase({ r = 25, cy = 41, cor }) {
  return `<circle cx="48" cy="${cy}" r="${r}" fill="${cor}" stroke="${CONTORNO}" stroke-width="2.4"/>`;
}
function chumaco(cx, cy, rx, ry, cor, rot = 0) {
  return `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${cor}" stroke="${CONTORNO}" stroke-width="2.2" transform="rotate(${rot} ${cx} ${cy})"/>`;
}

const PRESETS = [
  {
    id: 'a1', label: 'Cacheado, tom escuro',
    bg: '#1D2A44', pele: '#E0A876', peleSombra: '#8A5A3A',
    hairBackContent: `${toucaBase({ r: 27, cy: 40, cor: '#2B2118' })}
      <circle cx="24" cy="30" r="7" fill="#2B2118" stroke="${CONTORNO}" stroke-width="2.2"/>
      <circle cx="35" cy="18" r="7" fill="#2B2118" stroke="${CONTORNO}" stroke-width="2.2"/>
      <circle cx="48" cy="14" r="7.5" fill="#2B2118" stroke="${CONTORNO}" stroke-width="2.2"/>
      <circle cx="61" cy="18" r="7" fill="#2B2118" stroke="${CONTORNO}" stroke-width="2.2"/>
      <circle cx="72" cy="30" r="7" fill="#2B2118" stroke="${CONTORNO}" stroke-width="2.2"/>`,
  },
  {
    id: 'a2', label: 'Bob liso, óculos',
    bg: '#C9A667', pele: '#F2C7A0', peleSombra: '#C98F5E',
    hairBackContent: `${chumaco(24, 56, 8, 19, '#4A3220')}${chumaco(72, 56, 8, 19, '#4A3220')}${toucaBase({ r: 25, cy: 38, cor: '#4A3220' })}`,
    extra: oculos('#2B2118'),
  },
  {
    id: 'a3', label: 'Ruivo, sardinhas',
    bg: '#6E8F72', pele: '#F6D3B5',
    hairBackContent: toucaBase({ r: 23, cy: 34, cor: '#D9662C' }),
    extra: `<g fill="#B9501E" opacity=".55"><circle cx="35" cy="55" r=".9"/><circle cx="38" cy="57" r=".9"/><circle cx="58" cy="55" r=".9"/><circle cx="61" cy="57" r=".9"/><circle cx="48" cy="58" r=".9"/></g>`,
  },
  {
    id: 'a4', label: 'Ondulado, tom profundo',
    bg: '#B5673A', pele: '#8C5A34', peleSombra: '#5A3A22',
    hairBackContent: `${chumaco(22, 60, 8, 24, '#241A12', -8)}${chumaco(74, 60, 8, 24, '#241A12', 8)}${toucaBase({ r: 26, cy: 40, cor: '#241A12' })}`,
  },
  {
    id: 'a5', label: 'Careca, óculos',
    bg: '#4C6E88', pele: '#7A4E2C',
    extra: oculos('#181818'),
  },
  {
    id: 'a6', label: 'Coque com laço',
    bg: '#243352', pele: '#EFC59B', peleSombra: '#C98F5E',
    hairBackContent: toucaBase({ r: 24, cy: 42, cor: '#3B2A21' }),
    extra: `<circle cx="48" cy="15" r="8" fill="#3B2A21" stroke="${CONTORNO}" stroke-width="2.2"/>
      <path d="M40 12l7 4-7 4z" fill="#C9A667" stroke="${CONTORNO}" stroke-width="1.8"/>
      <path d="M56 12l-7 4 7 4z" fill="#C9A667" stroke="${CONTORNO}" stroke-width="1.8"/>`,
  },
  {
    id: 'a7', label: 'Black power',
    bg: '#8C6A3F', pele: '#5A3A22', peleSombra: '#3B2416',
    hairBackContent: toucaBase({ r: 28, cy: 38, cor: '#1B140E' }),
  },
  {
    id: 'a8', label: 'Rabo de cavalo',
    bg: '#9C5B44', pele: '#F2C7A0', peleSombra: '#C98F5E',
    hairBackContent: `${chumaco(76, 46, 6.5, 17, '#5C3A20', 25)}${toucaBase({ r: 25, cy: 40, cor: '#5C3A20' })}`,
  },
  {
    id: 'a9', label: 'Barba, cabelo curto',
    bg: '#3E5C58', pele: '#E7B38A', peleSombra: '#B97A4E',
    hairBackContent: toucaBase({ r: 23, cy: 36, cor: '#2B2118' }),
    extra: `<path d="M28 54c0 12 9 21 20 21s20-9 20-21c-2 9-10 15-20 15s-18-6-20-15z" fill="#2B2118" stroke="${CONTORNO}" stroke-width="2.2"/>`,
  },
  {
    id: 'a10', label: 'Boné',
    bg: '#B08A3E', pele: '#F2C7A0', peleSombra: '#C98F5E',
    hairBackContent: `${chumaco(26, 54, 5, 9, '#3B2A21')}${chumaco(70, 54, 5, 9, '#3B2A21')}`,
    extra: `<path d="M19 37c0-15 13-27 29-27s29 12 29 27h-6c0-12-10-21-23-21s-23 9-23 21z" fill="#C9A667" stroke="${CONTORNO}" stroke-width="2.4"/>
      <ellipse cx="48" cy="37" rx="29" ry="7" fill="#C9A667" stroke="${CONTORNO}" stroke-width="2.4"/>
      <path d="M46 30c8 0 14 3 17 7-4-2-10-4-17-4z" fill="#A6853F"/>`,
  },
];

/** @type {AvatarOpcao[]} */
export const AVATARES_DISPONIVEIS = PRESETS.map((p) => ({
  id: p.id,
  label: p.label,
  svg: `<svg viewBox="0 0 96 96" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Avatar ilustrado: ${p.label}">${montarRosto({
    bg: p.bg,
    pele: p.pele,
    peleSombra: p.peleSombra,
    hairBackContent: p.hairBackContent,
    extra: p.extra,
    sorrisoAberto: p.id === 'a3' || p.id === 'a10',
  })}</svg>`,
}));

const POR_ID = new Map(AVATARES_DISPONIVEIS.map((a) => [a.id, a]));

/**
 * @param {string} id um dos ids em AVATARES_DISPONIVEIS (a1..a10)
 * @returns {string} markup de um <svg> pronto pra virar innerHTML, ou '' se o id não existir
 */
export function avatarIlustradoSvgPorId(id) {
  const av = POR_ID.get(id);
  return av ? av.svg : '';
}

/**
 * Compatibilidade com o esquema antigo (campo `genero`) — usado como
 * último fallback pra quem nunca escolheu um avatar novo nem tem
 * `avatar_escolhido` preenchido (a migração faz backfill pra quase todo
 * mundo, mas uma linha criada fora do fluxo normal pode escapar disso).
 * @param {'masculino'|'feminino'} genero
 */
export function avatarIlustradoSvgPorGenero(genero) {
  return avatarIlustradoSvgPorId(genero === 'feminino' ? 'a6' : 'a1');
}
