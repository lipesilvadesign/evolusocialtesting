import { esc } from '../utils/html.js';
const TYPE_LABEL = {
  positive: 'Indo bem',
  attention: 'Atenção',
  opportunity: 'Oportunidade',
  trend: 'Tendência',
  alert: 'Alerta',
  recommendation: 'Recomendação',
};

const TYPE_BADGE_CLASS = {
  positive: 'badge-ok',
  attention: 'badge-warning',
  opportunity: 'badge-info',
  trend: 'badge-info',
  alert: 'badge-danger',
  recommendation: 'badge-demo',
};

const CONFIDENCE_LABEL = { baixa: 'Confiança baixa', media: 'Confiança média', alta: 'Confiança alta' };
const SEVERITY_LABEL = { baixa: 'Severidade baixa', media: 'Severidade média', alta: 'Severidade alta' };

function formatComparison(comparison) {
  if (!comparison || comparison.previousValue == null) {
    return 'Sem período anterior comparável para esta leitura.';
  }
  const { previousValue, deltaPct, rangeLabel } = comparison;
  const pctText = deltaPct == null ? '' : ` (${deltaPct >= 0 ? '+' : ''}${deltaPct}%)`;
  return `Comparado com o período anterior (${rangeLabel}): ${previousValue} → ${pctText ? 'variação' + pctText : 'sem variação percentual calculável'}.`;
}

/**
 * @param {import('../../../../netlify/functions/_lib/types').StructuredInsight} insight
 * @returns {HTMLElement}
 */
export function renderInsightCard(insight) {
  const card = document.createElement('div');
  card.className = 'card insight-card';

  const head = document.createElement('div');
  head.className = 'card-head';
  head.innerHTML = `
    <h4 style="font-family:var(--font-body);font-size:.95rem;font-weight:700">${esc(insight.title)}</h4>
    <span class="badge ${TYPE_BADGE_CLASS[insight.type] || 'badge-demo'}">${esc(TYPE_LABEL[insight.type] || insight.type)}</span>
  `;
  card.appendChild(head);

  const desc = document.createElement('p');
  desc.style.cssText = 'font-size:.88rem;color:var(--text);margin-bottom:var(--space-3)';
  desc.textContent = insight.description;
  card.appendChild(desc);

  const evidence = document.createElement('div');
  evidence.className = 'insight-evidence';
  evidence.innerHTML = `
    <div><span class="eyebrow">Métrica</span><br>${esc(insight.metric)}</div>
    <div><span class="eyebrow">Valor atual</span><br>${esc(insight.value)}</div>
  `;
  card.appendChild(evidence);

  const comparison = document.createElement('p');
  comparison.style.cssText = 'font-size:.78rem;color:var(--text-muted);margin-top:var(--space-2)';
  comparison.textContent = formatComparison(insight.comparison);
  card.appendChild(comparison);

  const footer = document.createElement('div');
  footer.style.cssText = 'display:flex;gap:var(--space-2);flex-wrap:wrap;margin-top:var(--space-3)';
  const confBadge = document.createElement('span');
  confBadge.className = 'badge badge-demo';
  confBadge.textContent = CONFIDENCE_LABEL[insight.confidence] || insight.confidence;
  footer.appendChild(confBadge);
  if (insight.severity) {
    const sevBadge = document.createElement('span');
    sevBadge.className = `badge ${insight.severity === 'alta' ? 'badge-danger' : 'badge-warning'}`;
    sevBadge.textContent = SEVERITY_LABEL[insight.severity] || insight.severity;
    footer.appendChild(sevBadge);
  }
  card.appendChild(footer);

  return card;
}
