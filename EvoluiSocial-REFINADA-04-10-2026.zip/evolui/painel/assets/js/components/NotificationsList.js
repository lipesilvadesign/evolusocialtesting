import { markNotificationRead } from '../services/notificationsClient.js';

const SEVERITY_BADGE = { alta: 'badge-danger', media: 'badge-warning', baixa: 'badge-demo' };
const TIPO_LABEL = { anomalia: 'Anomalia', erro: 'Erro', oportunidade: 'Oportunidade', sistema: 'Sistema' };

/**
 * @param {object[]} notifications
 * @param {{ onChange: () => void }} opts
 * @returns {HTMLElement}
 */
export function renderNotifications(notifications, { onChange }) {
  const wrap = document.createElement('div');
  if (notifications.length === 0) {
    const p = document.createElement('p');
    p.style.cssText = 'color:var(--text-muted);font-size:.86rem';
    p.textContent = 'Nenhuma notificação.';
    wrap.appendChild(p);
    return wrap;
  }

  notifications.forEach((n) => {
    const row = document.createElement('div');
    // Efeito visual de prioridade (pedido 13/09, 2ª rodada — "as
    // notificações eu posso colocar uma prioridade, uns efeitos que
    // mostram a prioridade, tipo um brilho"): severidade alta ganha um
    // brilho pulsante na borda esquerda; média, um brilho fixo mais discreto;
    // baixa não ganha efeito nenhum (não é ruído visual pra tudo). Some
    // assim que a notificação é marcada como lida.
    row.className = `notif-row notif-severidade-${n.severidade || 'baixa'}${n.lida ? ' is-lida' : ''}`;

    const topo = document.createElement('div');
    topo.style.cssText = 'display:flex;flex-wrap:wrap;justify-content:space-between;align-items:flex-start;gap:4px var(--space-2)';
    const esquerda = document.createElement('div');
    esquerda.style.cssText = 'min-width:0;flex:1 1 180px;overflow-wrap:anywhere';
    const badge = document.createElement('span');
    badge.className = `badge ${SEVERITY_BADGE[n.severidade] || 'badge-demo'}`;
    badge.textContent = TIPO_LABEL[n.tipo] || n.tipo;
    const titulo = document.createElement('strong');
    titulo.style.cssText = 'font-size:.86rem;margin-left:6px';
    titulo.textContent = n.titulo; // texto pode vir de dado gerado a partir de entrada de funcionário (ex.: termo de busca) — nunca via innerHTML.
    esquerda.append(badge, titulo);
    const data = document.createElement('span');
    data.style.cssText = 'font-size:.72rem;color:var(--text-muted);white-space:nowrap';
    data.textContent = new Date(n.created_at).toLocaleString('pt-BR');
    topo.append(esquerda, data);

    const mensagem = document.createElement('p');
    mensagem.style.cssText = 'font-size:.82rem;margin-top:4px';
    mensagem.textContent = n.mensagem;

    row.append(topo, mensagem);

    // 29/09: notificação que aponta para uma tela do painel (ex.: "Novo
    // contato pelo site" → Contatos do site) ganha o atalho. Só rotas
    // internas "#/…" — nunca um link vindo de fora.
    const rota = n.metadata && typeof n.metadata.rota === 'string' && /^#\/[a-z-]+$/.test(n.metadata.rota) ? n.metadata.rota : null;
    if (rota) {
      const link = document.createElement('a');
      link.className = 'btn btn-ghost btn-sm';
      link.style.cssText = 'margin-top:6px;margin-right:6px';
      link.href = rota;
      link.textContent = 'Abrir';
      row.appendChild(link);
    }

    if (!n.lida) {
      const btn = document.createElement('button');
      btn.className = 'btn btn-ghost btn-sm';
      btn.style.marginTop = '6px';
      btn.textContent = 'Marcar como lida';
      btn.addEventListener('click', async () => {
        await markNotificationRead(n.id);
        onChange();
      });
      row.appendChild(btn);
    }
    wrap.appendChild(row);
  });

  return wrap;
}
