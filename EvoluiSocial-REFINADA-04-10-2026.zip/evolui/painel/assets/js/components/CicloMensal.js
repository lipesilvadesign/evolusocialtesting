/**
 * "Este mês" como um anel de progresso (pedido 13/09, 3ª rodada — "quero
 * que esse mês, primeiro dia zero resultados, possa ser um ciclo... mais
 * visual... responsivo"). Antes era só uma linha de texto ("Este mês: 1
 * dia(s) · 2h registrada(s)") — no primeiro dia do mês, ou com poucos
 * dados, ficava com cara de "vazio"/quebrado. Um anel sempre tem alguma
 * coisa pra mostrar, mesmo em 0%.
 *
 * Progresso = dias trabalhados ÷ dias corridos do mês até hoje (nunca os
 * dias que ainda vão acontecer — não dá pra "faltar" um dia que ainda não
 * chegou). Puro SVG nativo, sem biblioteca nova.
 */

/**
 * @param {{ diasTrabalhados: number, horasTrabalhadas: number }} resumo
 * @returns {string} HTML (usar com innerHTML dentro de um container já criado)
 */
export function cicloMensalHtml(resumo) {
  const hoje = new Date();
  const diasCorridos = hoje.getDate(); // dia do mês atual (1..31) — só o que já passou
  const dias = Math.max(0, resumo.diasTrabalhados || 0);
  const progresso = diasCorridos > 0 ? Math.min(1, dias / diasCorridos) : 0;

  const raio = 30;
  const circunferencia = 2 * Math.PI * raio;
  const offset = circunferencia * (1 - progresso);
  const horas = resumo.horasTrabalhadas || 0;

  return `
    <div class="ciclo-mensal">
      <div class="ciclo-mensal-linha">
        <svg viewBox="0 0 72 72" class="ciclo-mensal-svg" role="img" aria-label="${dias} de ${diasCorridos} dias trabalhados este mês">
          <circle class="ciclo-mensal-trilha" cx="36" cy="36" r="${raio}" />
          <circle class="ciclo-mensal-progresso" cx="36" cy="36" r="${raio}"
            stroke-dasharray="${circunferencia.toFixed(2)}" stroke-dashoffset="${offset.toFixed(2)}" />
        </svg>
        <div class="ciclo-mensal-texto">
          <strong>${dias}</strong><span>de ${diasCorridos} dia${diasCorridos === 1 ? '' : 's'}</span>
        </div>
      </div>
      <div class="ciclo-mensal-horas">${horas}h registrada${horas === 1 ? '' : 's'} este mês</div>
    </div>
  `;
}
