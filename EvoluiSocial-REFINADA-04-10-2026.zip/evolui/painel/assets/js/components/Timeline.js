/**
 * Timeline compacta de atividades de um lead (ou, no Dashboard, de vários
 * leads misturados) — pensada para "olhar e entender em 2 segundos", não
 * para ser um relatório. Cada linha é só: ícone/rótulo do tipo, uma
 * descrição curta e o horário.
 *
 * Importante (ver auditoria + pedido do usuário): isto só EXIBE o que já foi
 * gravado em admin_prospeccao_atividades — nenhuma linha aqui é inventada.
 * Se a lista vier vazia, mostra um estado vazio, nunca inventa "atividade
 * de exemplo".
 */

const TIPO_INFO = {
  lead_capturado: { label: 'Lead criado', icon: '✦', cls: 'tl-neutral' },
  whatsapp_enviado: { label: 'WhatsApp enviado', icon: '↗', cls: 'tl-info' },
  email_enviado: { label: 'E-mail enviado', icon: '↗', cls: 'tl-info' },
  ligacao: { label: 'Ligação registrada', icon: '☎', cls: 'tl-info' },
  follow_up: { label: 'Follow-up', icon: '↻', cls: 'tl-warning' },
  resposta_recebida: { label: 'Resposta recebida', icon: '✓', cls: 'tl-ok' },
  reuniao_marcada: { label: 'Reunião/orçamento', icon: '◆', cls: 'tl-warning' },
  reuniao_realizada: { label: 'Reunião realizada', icon: '◆', cls: 'tl-ok' },
  proposta_enviada: { label: 'Proposta enviada', icon: '◆', cls: 'tl-warning' },
  negociacao: { label: 'Em negociação', icon: '◆', cls: 'tl-warning' },
  mudanca_status: { label: 'Status alterado', icon: '●', cls: 'tl-neutral' },
  nota: { label: 'Nota', icon: '✎', cls: 'tl-neutral' },
  briefing_atualizado: { label: 'Briefing atualizado', icon: '✎', cls: 'tl-neutral' },
  diagnostico_criado: { label: 'Diagnóstico criado', icon: '✎', cls: 'tl-neutral' },
  diagnostico_publicado: { label: 'Diagnóstico publicado', icon: '✓', cls: 'tl-ok' },
  apresentacao_enviada: { label: 'Apresentação enviada', icon: '↗', cls: 'tl-info' },
};

const STATUS_LABEL_CURTO = {
  novo_lead: 'Novo', contatado: 'Contatado', respondeu: 'Respondeu', interessado: 'Interessado',
  reuniao_marcada: 'Reunião/orçamento', proposta_enviada: 'Proposta enviada',
  cliente: 'Convertido', nao_convertido: 'Perdido',
};

function escapeHtml(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

function formatarHorario(iso) {
  const d = new Date(iso);
  const hoje = new Date();
  const mesmoDia = d.toDateString() === hoje.toDateString();
  return mesmoDia
    ? d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

/**
 * @param {object} atividade linha de admin_prospeccao_atividades (mais
 *   opcionalmente `empresa`, quando a timeline mistura vários leads, como no
 *   Dashboard)
 * @returns {string} descrição pronta pra exibir, nunca vazia
 */
function descreverAtividade(a) {
  if (a.tipo === 'mudanca_status' && a.status_novo) {
    const de = a.status_anterior ? `${STATUS_LABEL_CURTO[a.status_anterior] || a.status_anterior} → ` : '';
    return `Status alterado: ${de}${STATUS_LABEL_CURTO[a.status_novo] || a.status_novo}`;
  }
  if (a.descricao) return escapeHtml(a.descricao);
  const info = TIPO_INFO[a.tipo];
  return info ? info.label : escapeHtml(a.tipo);
}

/**
 * @param {object[]} atividades já ordenadas (mais recente primeiro)
 * @param {{ vazio?: string, mostrarEmpresa?: boolean, limite?: number }} [opts]
 * @returns {HTMLElement}
 */
export function renderTimeline(atividades, opts = {}) {
  const { vazio = 'Sem atividades registradas ainda.', mostrarEmpresa = false, limite } = opts;
  const wrap = document.createElement('div');
  wrap.className = 'timeline';

  const lista = limite ? atividades.slice(0, limite) : atividades;

  if (!lista.length) {
    wrap.innerHTML = `<p class="timeline-empty">${escapeHtml(vazio)}</p>`;
    return wrap;
  }

  wrap.innerHTML = lista.map((a) => {
    const info = TIPO_INFO[a.tipo] || { label: a.tipo, icon: '•', cls: 'tl-neutral' };
    const horario = formatarHorario(a.data || a.created_at);
    const empresaHtml = mostrarEmpresa && a.empresa
      ? `<button type="button" class="timeline-lead-link" data-lead-id="${escapeHtml(a.lead_id || '')}">${escapeHtml(a.empresa)}</button> · `
      : '';
    return `
      <div class="timeline-item ${info.cls}">
        <span class="timeline-icon" aria-hidden="true">${info.icon}</span>
        <div class="timeline-body">
          <p class="timeline-desc">${empresaHtml}${descreverAtividade(a)}</p>
          <span class="timeline-time">${horario}</span>
        </div>
      </div>
    `;
  }).join('');

  return wrap;
}
