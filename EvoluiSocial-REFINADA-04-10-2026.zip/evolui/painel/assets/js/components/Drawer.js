/**
 * Drawer — controla a sidebar em modo "gaveta" no mobile.
 * Requisitos cobertos: overlay, fecha ao clicar fora, fecha com ESC,
 * navegação por teclado (foco preso enquanto aberto), aria-labels.
 *
 * @param {{ sidebarEl: HTMLElement, overlayEl: HTMLElement, triggerEl: HTMLElement }} opts
 */
export function createDrawer({ sidebarEl, overlayEl, triggerEl }) {
  let isOpen = false;
  let lastFocused = null;

  sidebarEl.setAttribute('role', 'dialog');
  sidebarEl.setAttribute('aria-modal', 'false');
  sidebarEl.setAttribute('aria-label', 'Menu de navegação do painel');

  function getFocusable() {
    return Array.from(
      sidebarEl.querySelectorAll('a[href], button:not([disabled]), input, select, [tabindex]:not([tabindex="-1"])')
    );
  }

  function open() {
    if (isOpen) return;
    isOpen = true;
    lastFocused = document.activeElement;
    sidebarEl.classList.add('is-open');
    overlayEl.classList.add('is-open');
    sidebarEl.setAttribute('aria-modal', 'true');
    triggerEl.setAttribute('aria-expanded', 'true');
    const focusable = getFocusable();
    if (focusable[0]) focusable[0].focus();
    document.addEventListener('keydown', onKeydown);
  }

  function close() {
    if (!isOpen) return;
    isOpen = false;
    sidebarEl.classList.remove('is-open');
    overlayEl.classList.remove('is-open');
    sidebarEl.setAttribute('aria-modal', 'false');
    triggerEl.setAttribute('aria-expanded', 'false');
    document.removeEventListener('keydown', onKeydown);
    if (lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus();
  }

  function onKeydown(e) {
    if (e.key === 'Escape') {
      close();
      return;
    }
    if (e.key === 'Tab') {
      // Prende o foco dentro do drawer enquanto aberto (navegação por teclado).
      const focusable = getFocusable();
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  }

  triggerEl.addEventListener('click', () => (isOpen ? close() : open()));
  overlayEl.addEventListener('click', close);

  // Fecha ao navegar (clique num item do menu) — evita ficar aberto após a troca de view.
  sidebarEl.addEventListener('click', (e) => {
    if (e.target.closest('.app-nav-item')) close();
  });

  return { open, close, isOpen: () => isOpen };
}
