import { esc } from '../utils/html.js';
const STRENGTH_LABEL = { forte: 'Evidência forte', moderada: 'Evidência moderada', limitada: 'Evidência limitada' };
const STRENGTH_BADGE = { forte: 'badge-ok', moderada: 'badge-warning', limitada: 'badge-demo' };
const PRIORITY_LABEL = { alta: 'Prioridade alta', media: 'Prioridade média', baixa: 'Prioridade baixa' };
const PRIORITY_BADGE = { alta: 'badge-danger', media: 'badge-warning', baixa: 'badge-demo' };

const METRIC_FORMATTERS = {
  activeUsers: (v) => new Intl.NumberFormat('pt-BR').format(v),
  sessions: (v) => new Intl.NumberFormat('pt-BR').format(v),
  screenPageViews: (v) => new Intl.NumberFormat('pt-BR').format(v),
  engagementRate: (v) => `${v}%`,
  averageSessionDuration: (v) => `${Math.floor(v / 60)}m ${v % 60}s`,
};

function renderPoint(point) {
  const el = document.createElement('div');
  el.style.cssText = 'padding:var(--space-3) 0;border-bottom:1px solid var(--border)';
  el.innerHTML = `
    <p style="font-size:.88rem;font-style:italic;color:var(--text)">"${esc(point.text)}"</p>
    <div style="display:flex;gap:var(--space-2);flex-wrap:wrap;margin-top:var(--space-2)">
      <span class="badge ${STRENGTH_BADGE[point.evidenceStrength] || 'badge-demo'}">${esc(STRENGTH_LABEL[point.evidenceStrength] || point.evidenceStrength)}</span>
      ${point.relatedMetric ? `<span class="badge badge-demo">Métrica: ${esc(point.relatedMetric)}</span>` : ''}
    </div>
  `;
  return el;
}

function renderRecommendation(rec, deps) {
  const card = document.createElement('div');
  card.className = 'card ai-recommendation-card';
  card.innerHTML = `
    <div class="card-head">
      <h4 style="font-size:.95rem">${esc(rec.title)}</h4>
      <span class="badge ${PRIORITY_BADGE[rec.priority] || 'badge-demo'}">${esc(PRIORITY_LABEL[rec.priority] || rec.priority)}</span>
    </div>
    <p style="font-size:.88rem;margin-bottom:var(--space-3)">${esc(rec.explanation)}</p>
    <div class="insight-evidence" style="margin-bottom:var(--space-3)">
      <div><span class="eyebrow">Evidência</span><br>${esc(rec.evidence)}</div>
      <div><span class="eyebrow">Ação sugerida</span><br>${esc(rec.suggestedAction)}</div>
    </div>
  `;

  const chips = document.createElement('div');
  chips.className = 'ai-action-chips';
  // "Analisar página" e "Ver métrica" existiam aqui só como texto estático
  // (sem handler nenhum) — removidos na limpeza final, já que um botão sem
  // função nenhuma é pior do que não ter botão.

  // Etapa "Operação, Automação e Escala": "Adicionar tarefa" deixou de ser
  // placeholder — cria de verdade uma tarefa (status TODO) referenciando
  // esta recomendação como origem.
  const taskBtn = document.createElement('button');
  taskBtn.type = 'button';
  taskBtn.className = 'btn btn-ghost btn-sm';
  taskBtn.textContent = '+ Adicionar tarefa';
  taskBtn.addEventListener('click', async () => {
    taskBtn.disabled = true;
    taskBtn.textContent = 'Criando…';
    try {
      await deps.createTask({
        titulo: rec.title,
        descricao: `${rec.explanation}\n\nAção sugerida: ${rec.suggestedAction}\nEvidência: ${rec.evidence}`,
        origemTipo: 'recomendacao_ia',
        origemReferencia: { title: rec.title, metric: rec.evidence },
        prioridade: rec.priority,
      });
      deps.showToast('Tarefa criada — veja em Sistema → Tarefas.', { tone: 'ok' });
      taskBtn.textContent = '✓ Adicionada';
    } catch (err) {
      deps.showToast(err.message || 'Falha ao criar tarefa.', { tone: 'danger' });
      taskBtn.disabled = false;
      taskBtn.textContent = '+ Adicionar tarefa';
    }
  });
  chips.appendChild(taskBtn);

  card.appendChild(chips);
  return card;
}

/**
 * @param {import('../../../../netlify/functions/_lib/types').AiAnalysis & { contextMetrics: object[] }} analysis
 * @param {{ createTask: Function, showToast: Function }} deps - injeção simples pra não criar dependência circular de import
 * @returns {HTMLElement}
 */
export function renderAiAnalysisSection(analysis, deps) {
  const wrap = document.createElement('div');


  const head = document.createElement('div');
  head.style.cssText = 'display:flex;justify-content:space-between;align-items:flex-start;gap:var(--space-3);margin-bottom:var(--space-4);flex-wrap:wrap';
  head.innerHTML = `
    <div>
      <h3 style="font-size:1.1rem">Análise por IA</h3>
      <p style="color:var(--text-muted);font-size:.82rem;margin-top:4px">
        Gerada em ${new Date(analysis.meta.generatedAt).toLocaleString('pt-BR')}
        ${analysis.meta.cacheHit ? '· resultado em cache' : '· análise nova'}
      </p>
    </div>
  `;
  wrap.appendChild(head);

  if (analysis.insufficientData) {
    const note = document.createElement('div');
    note.className = 'card';
    note.innerHTML = `<p style="font-size:.9rem">${esc(analysis.summary)}</p>`;
    wrap.appendChild(note);
    return wrap;
  }

  // ---- Nível DADO: números puros, sem interpretação ----
  if (analysis.contextMetrics && analysis.contextMetrics.length > 0) {
    const dataCard = document.createElement('section');
    dataCard.className = 'card';
    dataCard.innerHTML = `<div class="card-head"><h4 style="font-size:.85rem">Dado</h4></div>`;
    const grid = document.createElement('div');
    grid.className = 'card-grid';
    analysis.contextMetrics.forEach((m) => {
      const formatter = METRIC_FORMATTERS[m.key] || ((v) => v);
      const el = document.createElement('div');
      el.className = 'card metric-card';
      el.innerHTML = `<div class="metric-label">${esc(m.label)}</div><div class="metric-value">${formatter(m.value)}</div>`;
      grid.appendChild(el);
    });
    dataCard.appendChild(grid);
    wrap.appendChild(dataCard);
  }

  // ---- Nível INTERPRETAÇÃO: resumo executivo + pontos ----
  const summaryCard = document.createElement('section');
  summaryCard.className = 'card';
  summaryCard.innerHTML = `
    <div class="card-head"><h4 style="font-size:.85rem">Interpretação — resumo</h4></div>
    <p style="font-size:.92rem;font-style:italic">"${esc(analysis.summary)}"</p>
  `;
  wrap.appendChild(summaryCard);

  const sections = [
    { title: 'O que está funcionando', items: analysis.positivePoints },
    { title: 'Pontos de atenção', items: analysis.attentionPoints },
    { title: 'Oportunidades', items: analysis.opportunities },
  ];
  sections.forEach((s) => {
    if (!s.items || s.items.length === 0) return;
    const card = document.createElement('section');
    card.className = 'card';
    card.innerHTML = `<div class="card-head"><h4 style="font-size:.85rem">${esc(s.title)}</h4></div>`;
    s.items.forEach((p) => card.appendChild(renderPoint(p)));
    wrap.appendChild(card);
  });

  // ---- Nível RECOMENDAÇÃO: cards destacados, com ações só visuais ----
  if (analysis.recommendations && analysis.recommendations.length > 0) {
    const recHead = document.createElement('h4');
    recHead.style.cssText = 'font-size:1rem;margin-bottom:var(--space-3)';
    recHead.textContent = 'Recomendações';
    wrap.appendChild(recHead);
    const grid = document.createElement('div');
    grid.className = 'card-grid';
    analysis.recommendations.forEach((rec) => grid.appendChild(renderRecommendation(rec, deps)));
    wrap.appendChild(grid);
  }

  if (analysis.questionsToInvestigate && analysis.questionsToInvestigate.length > 0) {
    const qCard = document.createElement('section');
    qCard.className = 'card';
    qCard.innerHTML = `
      <div class="card-head"><h4 style="font-size:.85rem">Perguntas para investigar</h4></div>
      <ul style="padding-left:1.1rem;font-size:.88rem;color:var(--text-muted)">
        ${analysis.questionsToInvestigate.map((q) => `<li style="margin-bottom:6px">${esc(q)}</li>`).join('')}
      </ul>
    `;
    wrap.appendChild(qCard);
  }

  return wrap;
}
