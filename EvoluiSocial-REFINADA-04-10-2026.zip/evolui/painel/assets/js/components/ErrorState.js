import { esc } from '../utils/html.js';
/**
 * ErrorState — usado quando uma busca falha. Inclui retry quando o
 * chamador fornecer `onRetry`.
 * @param {{ title?: string, description: string, onRetry?: () => void }} opts
 * @returns {HTMLElement}
 */
export function ErrorState({ title = 'Não foi possível carregar', description, onRetry }) {
  const wrap = document.createElement('div');
  wrap.className = 'state-block';
  wrap.setAttribute('role', 'alert');
  wrap.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="var(--danger)" stroke-width="1.6" aria-hidden="true">
      <circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/>
    </svg>
    <h4>${esc(title)}</h4>
    <p>${esc(description)}</p>
  `;
  if (onRetry) {
    const btn = document.createElement('button');
    btn.className = 'btn btn-ghost btn-sm';
    btn.textContent = 'Tentar novamente';
    btn.addEventListener('click', onRetry);
    wrap.appendChild(btn);
  }
  return wrap;
}
