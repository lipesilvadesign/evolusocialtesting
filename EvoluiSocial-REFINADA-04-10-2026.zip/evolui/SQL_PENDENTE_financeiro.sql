-- ============================================================
-- Financeiro — schema novo (módulo não existia no projeto)
-- ============================================================
-- CONTEXTO HONESTO: até esta migração, o painel não tinha NENHUMA tabela,
-- Function ou tela financeira. O pedido era "auditar e corrigir a
-- integração Financeiro↔CRM" e "redesenhar a área financeira" — mas essa
-- área nunca existiu. Em vez de simular uma auditoria sobre algo que não
-- existe, construí o módulo do zero, seguindo o mesmo padrão arquitetural
-- já usado em todo o resto do painel (ver SQL_PENDENTE_equipe_permissoes.sql
-- e admin_tarefas em SQL_FIX_completo_13_09.sql):
--   - tabela admin_<algo>, RLS habilitada, policy via admin_eh_admin();
--   - id uuid, created_at/updated_at, sem chave nenhuma nova no frontend.
--
-- PRINCÍPIO FUNDAMENTAL SEGUIDO (pedido explícito): o financeiro NÃO cria
-- uma segunda base de clientes. "Cliente" continua sendo, como já é em
-- clientes.js, o MESMO registro de admin_prospeccao_leads com
-- status = 'cliente'. admin_financeiro_contratos.lead_id referencia essa
-- tabela diretamente (FK) — não existe nome/empresa duplicado aqui.
--
-- ACESSO: as 3 tabelas abaixo são admin-only (select/insert/update/delete),
-- mesmo padrão de admin_tarefas/admin_relatorios. Dado financeiro da agência
-- não é visível para os papéis "prospeccao"/"design" — decisão consistente
-- com o resto do painel (Equipe e Sistema/Diagnóstico já são admin-only),
-- não um requisito que você tenha pedido explicitamente; se quiser abrir
-- para outro papel depois, é só uma policy nova.
-- ============================================================

-- 1) Contratos — um por "negócio fechado" com um cliente já existente no CRM.
create table if not exists admin_financeiro_contratos (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references admin_prospeccao_leads(id) on delete restrict,
  servico text not null check (servico in (
    'branding', 'identidade_visual', 'estrategia', 'conteudo',
    'gestao', 'diagnostico', 'projeto_especial', 'outros'
  )),
  valor_total numeric(12,2) not null check (valor_total > 0),
  data_inicio date not null default current_date,
  numero_parcelas int not null default 1 check (numero_parcelas >= 1),
  -- "Receita recorrente" (pedido explícito no header do Financeiro) — contrato
  -- de gestão mensal contínua, não parcelamento de um valor fechado.
  recorrente boolean not null default false,
  status text not null default 'ativo' check (status in ('ativo', 'concluido', 'cancelado')),
  observacoes text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_financeiro_contratos enable row level security;
create index if not exists admin_financeiro_contratos_lead_id_idx on admin_financeiro_contratos (lead_id);
create index if not exists admin_financeiro_contratos_status_idx on admin_financeiro_contratos (status);

-- 2) Parcelas — 1 linha por parcela do contrato (contrato de parcela única
-- ainda assim gera 1 linha aqui, pra "contas a receber" ter uma fonte só).
create table if not exists admin_financeiro_parcelas (
  id uuid primary key default gen_random_uuid(),
  contrato_id uuid not null references admin_financeiro_contratos(id) on delete cascade,
  numero int not null check (numero >= 1),
  valor numeric(12,2) not null check (valor > 0),
  vencimento date not null,
  -- "atrasado" pode ser marcado manualmente, mas a tela também calcula um
  -- status EFETIVO (vencimento passada + não pago = atrasado na exibição)
  -- sem precisar de job agendado nem gatilho — ver financeiro.js,
  -- statusEfetivoParcela(). Evita depender de um cron pra manter isto correto.
  status text not null default 'previsto' check (status in ('previsto', 'aguardando', 'pago', 'atrasado', 'cancelado')),
  pago_em date,
  valor_pago numeric(12,2),
  forma_pagamento text,
  observacoes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz,
  unique (contrato_id, numero)
);
alter table admin_financeiro_parcelas enable row level security;
create index if not exists admin_financeiro_parcelas_contrato_id_idx on admin_financeiro_parcelas (contrato_id);
create index if not exists admin_financeiro_parcelas_vencimento_idx on admin_financeiro_parcelas (vencimento);
create index if not exists admin_financeiro_parcelas_status_idx on admin_financeiro_parcelas (status);

-- 3) Despesas — contas a pagar da agência (sem relação com cliente/CRM).
-- Categorias = vocabulário real de uma agência de branding (pedido
-- explícito), não uma lista genérica de ERP.
create table if not exists admin_financeiro_despesas (
  id uuid primary key default gen_random_uuid(),
  categoria text not null check (categoria in (
    'google_ads', 'meta_ads', 'ferramentas', 'ia', 'adobe', 'hospedagem',
    'dominio', 'supabase', 'netlify', 'freelancers', 'equipe', 'estagio',
    'equipamentos', 'transporte', 'telefonia_internet', 'impostos',
    'servicos_terceirizados', 'marketing', 'capacitacao', 'administrativo', 'outros'
  )),
  descricao text not null,
  fornecedor text,
  valor numeric(12,2) not null check (valor > 0),
  vencimento date not null,
  recorrente boolean not null default false,
  status text not null default 'previsto' check (status in ('previsto', 'pago', 'atrasado', 'cancelado')),
  pago_em date,
  -- Link para comprovante (ex.: nota fiscal já hospedada em algum lugar) —
  -- texto simples, não upload de arquivo. Este projeto não tem um bucket de
  -- Storage configurado em nenhum lugar do código existente; "inventar" um
  -- fluxo de upload novo seria além do que foi pedido e sem como testar
  -- contra o projeto real. Se quiser upload de arquivo depois, é um passo à
  -- parte (criar o bucket + policy de Storage).
  comprovante_url text,
  observacoes text,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_financeiro_despesas enable row level security;
create index if not exists admin_financeiro_despesas_vencimento_idx on admin_financeiro_despesas (vencimento);
create index if not exists admin_financeiro_despesas_status_idx on admin_financeiro_despesas (status);
create index if not exists admin_financeiro_despesas_categoria_idx on admin_financeiro_despesas (categoria);

-- ============================================================
-- 4) RLS — admin-only nas 3 tabelas, reaproveitando admin_eh_admin()
-- (já criada em SQL_PENDENTE_equipe_permissoes.sql — não duplicada aqui).
-- ============================================================
drop policy if exists admin_financeiro_contratos_select on admin_financeiro_contratos;
create policy admin_financeiro_contratos_select on admin_financeiro_contratos for select using (admin_eh_admin());
drop policy if exists admin_financeiro_contratos_insert on admin_financeiro_contratos;
create policy admin_financeiro_contratos_insert on admin_financeiro_contratos for insert with check (admin_eh_admin());
drop policy if exists admin_financeiro_contratos_update on admin_financeiro_contratos;
create policy admin_financeiro_contratos_update on admin_financeiro_contratos for update using (admin_eh_admin()) with check (admin_eh_admin());
drop policy if exists admin_financeiro_contratos_delete on admin_financeiro_contratos;
create policy admin_financeiro_contratos_delete on admin_financeiro_contratos for delete using (admin_eh_admin());

drop policy if exists admin_financeiro_parcelas_select on admin_financeiro_parcelas;
create policy admin_financeiro_parcelas_select on admin_financeiro_parcelas for select using (admin_eh_admin());
drop policy if exists admin_financeiro_parcelas_insert on admin_financeiro_parcelas;
create policy admin_financeiro_parcelas_insert on admin_financeiro_parcelas for insert with check (admin_eh_admin());
drop policy if exists admin_financeiro_parcelas_update on admin_financeiro_parcelas;
create policy admin_financeiro_parcelas_update on admin_financeiro_parcelas for update using (admin_eh_admin()) with check (admin_eh_admin());
drop policy if exists admin_financeiro_parcelas_delete on admin_financeiro_parcelas;
create policy admin_financeiro_parcelas_delete on admin_financeiro_parcelas for delete using (admin_eh_admin());

drop policy if exists admin_financeiro_despesas_select on admin_financeiro_despesas;
create policy admin_financeiro_despesas_select on admin_financeiro_despesas for select using (admin_eh_admin());
drop policy if exists admin_financeiro_despesas_insert on admin_financeiro_despesas;
create policy admin_financeiro_despesas_insert on admin_financeiro_despesas for insert with check (admin_eh_admin());
drop policy if exists admin_financeiro_despesas_update on admin_financeiro_despesas;
create policy admin_financeiro_despesas_update on admin_financeiro_despesas for update using (admin_eh_admin()) with check (admin_eh_admin());
drop policy if exists admin_financeiro_despesas_delete on admin_financeiro_despesas;
create policy admin_financeiro_despesas_delete on admin_financeiro_despesas for delete using (admin_eh_admin());

-- ============================================================
-- 5) Conferência — roda por último, tem que voltar tudo `true`.
-- ============================================================
select
  to_regclass('public.admin_financeiro_contratos') is not null as tabela_contratos_ok,
  to_regclass('public.admin_financeiro_parcelas') is not null as tabela_parcelas_ok,
  to_regclass('public.admin_financeiro_despesas') is not null as tabela_despesas_ok,
  (select count(*) from pg_policies where tablename = 'admin_financeiro_contratos') = 4 as policies_contratos_ok,
  (select count(*) from pg_policies where tablename = 'admin_financeiro_parcelas') = 4 as policies_parcelas_ok,
  (select count(*) from pg_policies where tablename = 'admin_financeiro_despesas') = 4 as policies_despesas_ok,
  exists (select 1 from pg_proc where proname = 'admin_eh_admin') as funcao_admin_eh_admin_existe;
