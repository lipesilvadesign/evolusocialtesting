-- =====================================================================
-- Contatos do formulário da home ("Vamos conversar") — 29/09
--
-- Antes: o formulário da home só abria o WhatsApp. Se o visitante fechasse
-- o WhatsApp sem enviar, o contato se perdia e nada chegava no painel nem
-- por e-mail. Agora:
--   1. a Function contato-criar grava o contato aqui (chave anônima, sob a
--      política restrita abaixo — mesmo padrão de consultas_leads);
--   2. o trigger cria na hora uma notificação no sino do painel;
--   3. a Function manda o aviso por e-mail (SMTP Umbler) e registra o
--      resultado pela RPC site_contato_registrar_email;
--   4. o job agendado (scheduled-sync-background, de hora em hora) confere
--      os avisos pendentes/falhos e tenta de novo; se o SMTP não estiver
--      configurado, avisa no sino (uma vez por dia).
-- Idempotente: pode rodar de novo sem quebrar nada.
-- =====================================================================

create table if not exists site_contatos (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  nome text not null check (char_length(nome) between 2 and 120),
  email text not null check (char_length(email) between 5 and 180 and email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  whatsapp text not null check (char_length(regexp_replace(whatsapp, '\D', '', 'g')) between 10 and 13),
  servico text not null check (char_length(servico) between 2 and 80),
  orcamento text check (orcamento is null or orcamento in ('ate-3k','3-8k','8k+')),
  mensagem text not null check (char_length(mensagem) between 8 and 2000),
  origem text not null default 'home' check (char_length(origem) <= 40),
  -- Atendimento (só a equipe altera)
  status text not null default 'novo'
    check (status in ('novo','em_atendimento','respondido','convertido','arquivado')),
  observacoes_internas text check (observacoes_internas is null or char_length(observacoes_internas) <= 4000),
  atualizado_por text,
  updated_at timestamptz,
  -- Aviso por e-mail (só a Function/o job alteram, via RPC/service role)
  email_status text not null default 'pendente'
    check (email_status in ('pendente','enviado','falhou','sem_smtp')),
  email_tentativas int not null default 0,
  email_ultimo_erro text,
  email_enviado_em timestamptz
);

create index if not exists site_contatos_created_idx on site_contatos (created_at desc);
create index if not exists site_contatos_email_pend_idx on site_contatos (email_status) where email_status <> 'enviado';

alter table site_contatos enable row level security;

-- ---------------------------------------------------------------------
-- Privilégios por coluna: o visitante (anon) só consegue ESCREVER os
-- campos do formulário — nunca status, observações ou o controle de e-mail.
-- Ele não consegue LER nada (nem o próprio contato).
-- ---------------------------------------------------------------------
revoke all on site_contatos from anon, authenticated;
grant insert (id, nome, email, whatsapp, servico, orcamento, mensagem, origem) on site_contatos to anon;
grant select, delete on site_contatos to authenticated;
grant update (status, observacoes_internas, atualizado_por, updated_at) on site_contatos to authenticated;

drop policy if exists anon_insert_site_contatos on site_contatos;
create policy anon_insert_site_contatos on site_contatos
  for insert to anon
  with check (status = 'novo' and email_status = 'pendente' and email_tentativas = 0
              and observacoes_internas is null and atualizado_por is null);

-- Equipe comercial: admin e prospecção ativos (contato da home é lead comercial).
drop policy if exists equipe_select_site_contatos on site_contatos;
create policy equipe_select_site_contatos on site_contatos
  for select to authenticated
  using (admin_eh_admin() or (admin_eh_funcionario_ativo() and admin_funcionario_role() = 'prospeccao'));

drop policy if exists equipe_update_site_contatos on site_contatos;
create policy equipe_update_site_contatos on site_contatos
  for update to authenticated
  using (admin_eh_admin() or (admin_eh_funcionario_ativo() and admin_funcionario_role() = 'prospeccao'))
  with check (admin_eh_admin() or (admin_eh_funcionario_ativo() and admin_funcionario_role() = 'prospeccao'));

drop policy if exists admin_delete_site_contatos on site_contatos;
create policy admin_delete_site_contatos on site_contatos
  for delete to authenticated
  using (admin_eh_admin());

-- ---------------------------------------------------------------------
-- Notificação no sino assim que o contato entra (não depende de e-mail).
-- ---------------------------------------------------------------------
create or replace function site_contatos_notificar()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into admin_notificacoes (tipo, titulo, mensagem, severidade, metadata)
  values (
    'oportunidade',
    'Novo contato pelo site: ' || left(new.nome, 80),
    left(new.servico, 80) || coalesce(' · orçamento ' || new.orcamento, '') || ' — ' || left(new.mensagem, 180),
    'alta',
    jsonb_build_object('siteContatoId', new.id, 'origem', new.origem, 'rota', '#/contatos-site')
  );
  return new;
end;
$$;
revoke all on function site_contatos_notificar() from public, anon, authenticated;

drop trigger if exists site_contatos_notificar_trg on site_contatos;
create trigger site_contatos_notificar_trg
  after insert on site_contatos
  for each row execute function site_contatos_notificar();

-- ---------------------------------------------------------------------
-- A Function pública (chave anônima) registra o resultado do e-mail.
-- Travas: só vale para contato criado há menos de 15 minutos e ainda
-- 'pendente' — ninguém de fora consegue reescrever o histórico.
-- ---------------------------------------------------------------------
create or replace function site_contato_registrar_email(p_id uuid, p_status text, p_erro text default null)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_linhas int;
begin
  if p_status not in ('enviado','falhou','sem_smtp') then
    return false;
  end if;
  update site_contatos
     set email_status = p_status,
         email_tentativas = email_tentativas + 1,
         email_ultimo_erro = case when p_status = 'enviado' then null else left(p_erro, 300) end,
         email_enviado_em = case when p_status = 'enviado' then now() else null end
   where id = p_id
     and email_status = 'pendente'
     and email_tentativas = 0
     and created_at > now() - interval '15 minutes';
  get diagnostics v_linhas = row_count;
  return v_linhas = 1;
end;
$$;
revoke all on function site_contato_registrar_email(uuid, text, text) from public;
grant execute on function site_contato_registrar_email(uuid, text, text) to anon, authenticated;

-- ---------------------------------------------------------------------
-- Reenvio manual pelo painel (botão "Reenviar aviso por e-mail"): a
-- Function contatos-site chama com o token do usuário logado. Só equipe
-- comercial ativa; não tem trava de tempo, mas só aceita os 3 resultados.
-- ---------------------------------------------------------------------
create or replace function site_contato_registrar_reenvio(p_id uuid, p_status text, p_erro text default null)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_linhas int;
begin
  if not (admin_eh_admin() or (admin_eh_funcionario_ativo() and admin_funcionario_role() = 'prospeccao')) then
    raise exception 'sem permissão' using errcode = '42501';
  end if;
  if p_status not in ('enviado','falhou','sem_smtp') then
    return false;
  end if;
  update site_contatos
     set email_status = p_status,
         email_tentativas = email_tentativas + 1,
         email_ultimo_erro = case when p_status = 'enviado' then null else left(p_erro, 300) end,
         email_enviado_em = case when p_status = 'enviado' then now() else email_enviado_em end
   where id = p_id;
  get diagnostics v_linhas = row_count;
  return v_linhas = 1;
end;
$$;
revoke all on function site_contato_registrar_reenvio(uuid, text, text) from public, anon;
grant execute on function site_contato_registrar_reenvio(uuid, text, text) to authenticated;
