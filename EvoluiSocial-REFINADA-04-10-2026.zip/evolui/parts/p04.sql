-- 3d) produtos, servicos, plataformas, formatos, negocios (sem pai; ligados por evolui_tax_relacoes)
insert into public.evolui_tax_termos(tipo,chave,rotulo,sinonimos,pai_id)
select v.tipo,v.chave,v.rotulo,string_to_array(v.sin,'|'),null
from (values
('produto','protetor_solar','Protetor solar','protetor solar|filtro solar|fps|bloqueador|bloqueador solar|protetores solares'),
('produto','hidratante','Hidratante','hidratante|hidratantes|creme hidratante'),
('produto','sabonete_facial','Sabonete facial','sabonete facial|sabonetes faciais|gel de limpeza'),
('produto','serum','Sérum','serum|sérum|serums|séruns'),
('produto','tonico','Tônico','tonico|tônico|tonicos|tônicos|tonico facial'),
('servico','limpeza_de_pele','Limpeza de pele','limpeza de pele|limpeza facial'),
('servico','peeling','Peeling','peeling|peelings'),
('plataforma','instagram','Instagram','instagram|insta|ig'),
('plataforma','tiktok','TikTok','tiktok|tik tok'),
('plataforma','youtube','YouTube','youtube|you tube'),
('plataforma','facebook','Facebook','facebook'),
('plataforma','linkedin','LinkedIn','linkedin'),
('plataforma','whatsapp','WhatsApp','whatsapp|whats|zap|zapzap'),
('formato','reels','Reels','reels|reel'),
('formato','stories','Stories','stories|story|storie'),
('formato','carrossel','Carrossel','carrossel|carrosseis|carrosséis|carousel'),
('formato','video','Vídeo','video|vídeo|videos|vídeos'),
('formato','imagem','Imagem','imagem|imagens|foto|fotos'),
('formato','texto','Texto','texto|textos|legenda|legendas'),
('formato','post','Post','post|posts|publicacao|publicação|postagem|postagens'),
('formato','live','Live','live|lives|ao vivo'),
('negocio','loja','Loja','loja|lojas|lojinha|lojinhas'),
('negocio','salao','Salão','salao|salão|saloes|salões'),
('negocio','clinica','Clínica','clinica|clínica|clinicas|clínicas'),
('negocio','restaurante','Restaurante','restaurante|restaurantes'),
('negocio','autonomo','Autônomo','autonomo|autônomo|autonoma|autônoma|freelancer|profissional liberal|profissional autonomo'),
('negocio','consultorio','Consultório','consultorio|consultório|consultorios|consultórios'),
('negocio','estudio','Estúdio','estudio|estúdio|estudios|estúdios'),
('negocio','academia','Academia','academia|academias')
) v(tipo,chave,rotulo,sin)
on conflict (tipo,chave) do update set sinonimos=(select coalesce(array_agg(x order by o),'{}') from (select x,min(o) o from unnest(public.evolui_tax_termos.sinonimos||excluded.sinonimos) with ordinality u(x,o) group by x) s);

-- relacoes: produtos e servicos de skincare
insert into public.evolui_tax_relacoes(de_id,para_id,tipo)
select d.id,t.id,case d.tipo when 'produto' then 'produto_de' else 'servico_de' end
from public.evolui_tax_termos d join public.evolui_tax_termos t on t.tipo='tema' and t.chave='skincare'
where (d.tipo='produto' and d.chave in ('protetor_solar','hidratante','sabonete_facial','serum','tonico'))
   or (d.tipo='servico' and d.chave in ('limpeza_de_pele','peeling'))
on conflict (de_id,para_id,tipo) do nothing;
