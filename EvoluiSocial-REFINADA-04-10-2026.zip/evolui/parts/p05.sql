-- 4) funcao de entendimento
create or replace function public.evolui_entender_termos(p_texto text, p_cidade text default null)
returns jsonb
language plpgsql
stable
security definer
set search_path = public, pg_temp
as $fn$
declare
  v_orig text := coalesce(p_texto,'');
  v_txt text;
  v_dims jsonb := '[]'::jsonb;
  v_acc_a int4range[] := '{}';   -- faixas aceitas (termos taxonomicos/entidades)
  v_acc_n int4range[] := '{}';   -- faixas aceitas (negocio)
  v_rng int4range;
  r record;
  v_ok boolean;
  v_seeds jsonb := '[]'::jsonb;
  v_n_areas int;
  v_area record; v_sub record; v_tema record;
  v_cadeia jsonb;
  v_loc jsonb := null;
  v_cand text; v_w text; v_pref text;
  v_cn text;
begin
  v_txt := ' ' || btrim(regexp_replace(public.evolui_tax_norm(v_orig),'[^a-z0-9]+',' ','g')) || ' ';
  if length(btrim(v_txt)) = 0 then
    return jsonb_build_object('dimensoes','[]'::jsonb,'cadeia',jsonb_build_object('area',null,'subramo',null,'tema',null),'localizacao',null);
  end if;

  for r in
    with fr as (
      select t.id, t.tipo, t.chave, t.rotulo,
             btrim(regexp_replace(public.evolui_tax_norm(s.raw),'[^a-z0-9]+',' ','g')) as frase
      from public.evolui_tax_termos t
      cross join lateral unnest(array[t.rotulo, replace(t.chave,'_',' ')] || coalesce(t.sinonimos,'{}')) as s(raw)
      where t.ativo
    ), vari as (
      select distinct f.id, f.tipo, f.chave, f.rotulo, v.variante
      from fr f
      cross join lateral unnest(array[
        f.frase, f.frase||'s', f.frase||'es',
        case when length(f.frase) > 3 and f.frase like '%s' then left(f.frase,-1) end,
        case when length(f.frase) > 4 and f.frase like '%es' then left(f.frase,-2) end,
        case when f.frase like '%ao' then left(f.frase,-2)||'oes' end,
        case when f.frase like '%ao' then left(f.frase,-2)||'aes' end,
        case when f.frase like '%ao' then f.frase||'s' end,
        case when f.frase like '%oes' then left(f.frase,-3)||'ao' end
      ]) as v(variante)
      where f.frase <> '' and v.variante is not null and v.variante <> ''
    )
    select id, tipo, chave, rotulo, variante, strpos(v_txt, ' '||variante||' ') as pos,
           length(variante) as len,
           case tipo when 'produto' then 1 when 'servico' then 1 when 'tema' then 2
                     when 'plataforma' then 2 when 'formato' then 2 when 'subramo' then 3
                     when 'area' then 4 else 5 end as prio
    from vari
    where strpos(v_txt, ' '||variante||' ') > 0
    order by length(variante) desc, 8, 6, chave
  loop
    v_rng := int4range(r.pos+1, r.pos + r.len, '[]');   -- somente o conteudo das palavras
    if r.tipo = 'negocio' then
      v_ok := not exists (select 1 from unnest(v_acc_n) x where x && v_rng)
              and not exists (select 1 from jsonb_array_elements(v_dims) d where d->>'tipo'='negocio' and d->>'chave'=r.chave);
      if v_ok then v_acc_n := v_acc_n || v_rng; end if;
    else
      v_ok := not exists (select 1 from unnest(v_acc_a) x where x && v_rng)
              and not exists (select 1 from jsonb_array_elements(v_dims) d where d->>'tipo'=r.tipo and d->>'chave'=r.chave);
      if v_ok then v_acc_a := v_acc_a || v_rng; end if;
    end if;
    if v_ok then
      v_dims := v_dims || jsonb_build_object('tipo',r.tipo,'chave',r.chave,'rotulo',r.rotulo,
                 'trecho',r.variante,'origem','dita','_id',r.id,'_pos',r.pos);
    end if;
  end loop;

  -- sementes da cadeia: termos taxonomicos citados + alvos das relacoes de produtos/servicos
  with d as (
    select (e->>'_id')::uuid id, e->>'tipo' tipo, (e->>'_pos')::int pos
    from jsonb_array_elements(v_dims) e
  ), seeds as (
    select id seed, pos, true dita from d where tipo in ('area','subramo','tema')
    union all
    select (select rr.para_id from public.evolui_tax_relacoes rr
             where rr.de_id = d.id and rr.tipo in ('produto_de','servico_de','tipo_de','parte_de','usado_em')
             order by rr.peso desc limit 1), pos, false
    from d where tipo in ('produto','servico')
  ), ch as (
    select s.pos, s.dita, t.id tid, t.tipo,
           case t.tipo when 'tema' then t.id end tema_id,
           case t.tipo when 'subramo' then t.id when 'tema' then p1.id end sub_id,
           case t.tipo when 'area' then t.id when 'subramo' then p1.id when 'tema' then p2.id end area_id
    from seeds s
    join public.evolui_tax_termos t on t.id = s.seed
    left join public.evolui_tax_termos p1 on p1.id = t.pai_id
    left join public.evolui_tax_termos p2 on p2.id = p1.pai_id
  )
  select coalesce(jsonb_agg(to_jsonb(ch) order by (not dita), pos), '[]'::jsonb) into v_seeds from ch;

  select count(distinct (e->>'area_id')) into v_n_areas from jsonb_array_elements(v_seeds) e where e->>'area_id' is not null;

  if v_n_areas > 1 then
    v_cadeia := jsonb_build_object('area',null,'subramo',null,'tema',null,'ambigua',true);
  elsif v_n_areas = 0 then
    v_cadeia := jsonb_build_object('area',null,'subramo',null,'tema',null);
  else
    select t.id, t.chave, t.rotulo into v_area from public.evolui_tax_termos t
      where t.id = (select (e->>'area_id')::uuid from jsonb_array_elements(v_seeds) e where e->>'area_id' is not null limit 1);
    select t.id, t.chave, t.rotulo into v_tema from public.evolui_tax_termos t
      where t.id = (select (e->>'tema_id')::uuid from jsonb_array_elements(v_seeds) e where e->>'tema_id' is not null limit 1);
    if v_tema.id is not null then
      select t.id, t.chave, t.rotulo into v_sub from public.evolui_tax_termos t
        where t.id = (select (e->>'sub_id')::uuid from jsonb_array_elements(v_seeds) e
                       where e->>'tema_id' = v_tema.id::text and e->>'sub_id' is not null limit 1);
    else
      select t.id, t.chave, t.rotulo into v_sub from public.evolui_tax_termos t
        where t.id = (select (e->>'sub_id')::uuid from jsonb_array_elements(v_seeds) e where e->>'sub_id' is not null limit 1);
    end if;
    v_cadeia := jsonb_build_object(
      'area', jsonb_build_object('chave',v_area.chave,'rotulo',v_area.rotulo,
               'origem', case when exists (select 1 from jsonb_array_elements(v_dims) d where (d->>'_id')::uuid = v_area.id) then 'dita' else 'inferida' end),
      'subramo', case when v_sub.id is null then null else jsonb_build_object('chave',v_sub.chave,'rotulo',v_sub.rotulo,
               'origem', case when exists (select 1 from jsonb_array_elements(v_dims) d where (d->>'_id')::uuid = v_sub.id) then 'dita' else 'inferida' end) end,
      'tema', case when v_tema.id is null then null else jsonb_build_object('chave',v_tema.chave,'rotulo',v_tema.rotulo,
               'origem', case when exists (select 1 from jsonb_array_elements(v_dims) d where (d->>'_id')::uuid = v_tema.id) then 'dita' else 'inferida' end) end);
  end if;

  -- localizacao
  v_cand := null;
  if p_cidade is not null and btrim(p_cidade) <> '' then
    v_cn := btrim(regexp_replace(public.evolui_tax_norm(p_cidade),'[^a-z0-9]+',' ','g'));
    if v_cn <> '' and position(' '||v_cn||' ' in v_txt) > 0 then v_cand := btrim(p_cidade); end if;
  end if;
  if v_cand is null then
    v_cand := (regexp_match(v_orig, '\m[Ee]m\s+([A-ZÀ-Ý][[:alpha:]]+(?:\s+(?:(?:de|da|do|das|dos)\s+)?[A-ZÀ-Ý][[:alpha:]]+)*)'))[1];
  end if;
  if v_cand is not null then
    -- corta a partir da primeira palavra que seja termo da taxonomia (plataforma, formato etc.)
    v_pref := '';
    foreach v_w in array regexp_split_to_array(v_cand, '\s+') loop
      if exists (
        select 1 from public.evolui_tax_termos t
        cross join lateral unnest(array[t.rotulo, replace(t.chave,'_',' ')] || coalesce(t.sinonimos,'{}')) s(raw)
        where t.ativo and btrim(regexp_replace(public.evolui_tax_norm(s.raw),'[^a-z0-9]+',' ','g'))
              in (btrim(regexp_replace(public.evolui_tax_norm(v_w),'[^a-z0-9]+',' ','g')),
                  left(btrim(regexp_replace(public.evolui_tax_norm(v_w),'[^a-z0-9]+',' ','g')), -1))
      ) then exit; end if;
      v_pref := btrim(v_pref || ' ' || v_w);
    end loop;
    v_pref := regexp_replace(v_pref, '\s+(de|da|do|das|dos)$', '');
    if v_pref <> '' then v_loc := jsonb_build_object('nome', v_pref, 'origem', 'dita'); end if;
  end if;

  return jsonb_build_object(
    'dimensoes', coalesce((select jsonb_agg(d - '_id' - '_pos' order by (d->>'_pos')::int) from jsonb_array_elements(v_dims) d), '[]'::jsonb),
    'cadeia', v_cadeia,
    'localizacao', v_loc);
end
$fn$;
