
revoke all on function public.evolui_entender_termos(text,text) from public, anon, authenticated;
grant execute on function public.evolui_entender_termos(text,text) to authenticated, service_role;
