-- 3c) temas
insert into public.evolui_tax_termos(tipo,chave,rotulo,sinonimos,pai_id)
select v.tipo,v.chave,v.rotulo,string_to_array(v.sin,'|'),(select p.id from public.evolui_tax_termos p where p.tipo=v.ptipo and p.chave=v.pchave)
from (values
('tema','skincare','Skincare','skincare|skin care|cuidados com a pele|rotina de pele|cuidados faciais|cuidados com o rosto|limpeza de pele|hidratacao facial|hidratação facial','subramo','cuidados_pele'),
('tema','barbearia','Barbearia','barbearias|barbeiros','subramo','cabelo_barbearia'),
('tema','odontologia','Odontologia','odonto|dentistas|consultorio odontologico','subramo','clinicas'),
('tema','restaurante','Restaurante','restaurantes','subramo','restaurantes_pizzarias'),
('tema','pizzaria','Pizzaria','pizzarias','subramo','restaurantes_pizzarias'),
('tema','bode_carneiro','Bode e carneiro (gastronomia regional)','bode|carneiro|carne de bode|carne de carneiro|bode assado|cabrito','subramo','restaurantes_pizzarias'),
('tema','festa_junina','Festa junina','festa junina|festas juninas|sao joao|são joão|arraial|quadrilha','subramo','eventos_sao_joao'),
('tema','forro','Forró','forro|forró|show de forro','subramo','eventos_sao_joao'),
('tema','comida_tipica','Comida típica','comida tipica|comida típica|prato tipico|pratos tipicos','subramo','gastronomia_regional'),
('tema','vinicolas','Vinícolas','vinicola|vinícola|vinicolas|vinícolas|vinhedo|vinhedos|espumante|espumantes','subramo','enoturismo'),
('tema','degustacao_vinhos','Degustação de vinhos','degustacao de vinho|degustação de vinho|degustacao de vinhos|degustação de vinhos|visita guiada','subramo','enoturismo'),
('tema','passeio_barco','Passeio de barco','barco|barcos|catamara|catamarã|navegacao','subramo','passeios_rio'),
('tema','pousadas','Pousadas','pousada|pousadas|hostel','subramo','hospedagem'),
('tema','hoteis','Hotéis','hotel|hoteis|hotéis','subramo','hospedagem'),
('tema','uva','Uva','uva|uvas|parreiral|parreirais','subramo','agro'),
('tema','manga','Manga','manga|mangas','subramo','agro'),
('tema','fruticultura_irrigada','Fruticultura irrigada','fruticultura irrigada|irrigacao|irrigação|agricultura irrigada','subramo','agro')
) v(tipo,chave,rotulo,sin,ptipo,pchave)
on conflict (tipo,chave) do update set sinonimos=(select coalesce(array_agg(x order by o),'{}') from (select x,min(o) o from unnest(public.evolui_tax_termos.sinonimos||excluded.sinonimos) with ordinality u(x,o) group by x) s);
