-- 3a) areas e subramos (sinonimos novos sao somados aos existentes, sem duplicar)
insert into public.evolui_tax_termos(tipo,chave,rotulo,sinonimos,pai_id)
select v.tipo,v.chave,v.rotulo,string_to_array(v.sin,'|'),(select p.id from public.evolui_tax_termos p where p.tipo=v.ptipo and p.chave=v.pchave)
from (values
('area','turismo','Turismo e eventos','turismo|turistico|turistica|turista|turistas',null,null),
('area','moda','Moda e acessórios','moda|boutique|vestuario|vestuário',null,null),
('area','alimentacao','Alimentação e restaurantes','alimentacao|alimentação|comida|gastronomia',null,null),
('area','saude','Saúde e bem-estar','saude|saúde|bem estar|bem-estar',null,null),
('area','fitness','Academia e fitness','fitness|academia|treino',null,null),
('area','pet','Pet','pet|pets|animais',null,null),
('area','casa','Casa e decoração','decoracao|decoração|casa e decoracao',null,null),
('area','educacao','Educação e cursos','educacao|educação|ensino|escola',null,null),
('area','servicos','Serviços profissionais','servicos profissionais|serviços profissionais|prestador de servicos',null,null),
('area','doces','Doces e confeitaria','doces|doce|confeitaria|docinhos',null,null),
('area','beleza','Beleza e estética','beleza|estetica|estética',null,null)
) v(tipo,chave,rotulo,sin,ptipo,pchave)
on conflict (tipo,chave) do update set sinonimos=(select coalesce(array_agg(x order by o),'{}') from (select x,min(o) o from unnest(public.evolui_tax_termos.sinonimos||excluded.sinonimos) with ordinality u(x,o) group by x) s);
