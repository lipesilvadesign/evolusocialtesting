-- SQL_EVOLUI_ENTENDIMENTO_03_10.sql
-- Evolui: camada de entendimento de termos (taxonomia ampliada + funcao evolui_entender_termos).
-- Aditivo e idempotente. Aplicado em 03/10 (projeto aligftypgtzlymmditeo) em lotes pequenos.
-- Backup previo: bkp_evolui_20261003.evolui_tax_termos (34 linhas).
-- Chaves novas seguem o padrao existente (underscore): ex. eventos_sao_joao, passeios_rio.
set lock_timeout='5s'; set statement_timeout='25s';

-- 1) colunas, constraint de tipo ampliada, indices
alter table public.evolui_tax_termos
  add column if not exists locais text[] not null default '{}',
  add column if not exists peso_local jsonb not null default '{}';

do $$ begin
  if not exists (select 1 from pg_constraint where conrelid='public.evolui_tax_termos'::regclass and conname='evolui_tax_termos_tipo_check'
                 and pg_get_constraintdef(oid) like '%produto%') then
    alter table public.evolui_tax_termos drop constraint if exists evolui_tax_termos_tipo_check;
    alter table public.evolui_tax_termos drop constraint if exists evolui_tax_termos_tipo_check2;
    alter table public.evolui_tax_termos add constraint evolui_tax_termos_tipo_check
      check (tipo in ('area','subramo','tema','entidade','produto','servico','plataforma','formato','negocio')) not valid;
    alter table public.evolui_tax_termos validate constraint evolui_tax_termos_tipo_check;
  end if;
end $$;

create index if not exists evolui_tax_termos_sin_gin on public.evolui_tax_termos using gin (sinonimos);
create index if not exists evolui_tax_termos_rotulo_trgm on public.evolui_tax_termos using gin (rotulo gin_trgm_ops);

-- 2) relacoes (RLS ligado na criacao; leitura authenticated, escrita admin)
create table if not exists public.evolui_tax_relacoes (
  id uuid primary key default gen_random_uuid(),
  de_id uuid not null references public.evolui_tax_termos(id) on delete cascade,
  para_id uuid not null references public.evolui_tax_termos(id) on delete cascade,
  tipo text not null check (tipo in ('sinonimo_de','parte_de','tipo_de','produto_de','servico_de','relacionado_a','usado_em')),
  peso numeric not null default 1,
  fonte text not null default 'curadoria',
  criado_em timestamptz not null default now(),
  unique (de_id,para_id,tipo));
alter table public.evolui_tax_relacoes enable row level security;
revoke all on public.evolui_tax_relacoes from anon;
do $$ begin
  if not exists (select 1 from pg_policies where tablename='evolui_tax_relacoes' and policyname='rel_sel') then
    create policy rel_sel on public.evolui_tax_relacoes for select to authenticated using (true); end if;
  if not exists (select 1 from pg_policies where tablename='evolui_tax_relacoes' and policyname='rel_ins') then
    create policy rel_ins on public.evolui_tax_relacoes for insert to authenticated with check ((select public.evolui_eh_admin())); end if;
  if not exists (select 1 from pg_policies where tablename='evolui_tax_relacoes' and policyname='rel_upd') then
    create policy rel_upd on public.evolui_tax_relacoes for update to authenticated using ((select public.evolui_eh_admin())) with check ((select public.evolui_eh_admin())); end if;
  if not exists (select 1 from pg_policies where tablename='evolui_tax_relacoes' and policyname='rel_del') then
    create policy rel_del on public.evolui_tax_relacoes for delete to authenticated using ((select public.evolui_eh_admin())); end if;
end $$;
create index if not exists evolui_tax_rel_de on public.evolui_tax_relacoes(de_id);
create index if not exists evolui_tax_rel_para on public.evolui_tax_relacoes(para_id);

