-- Evolui Social — Evolui Knowledge Engine (EKE)
-- ADITIVO: não remove nem altera estruturas existentes.
begin;
create table if not exists public.evolui_conhecimento (
  id uuid primary key default gen_random_uuid(),
  termo text not null,
  entidade text not null,
  tipo text not null default 'conceito',
  significados jsonb not null default '[]'::jsonb,
  termos_relacionados text[] not null default '{}',
  contexto text,
  confianca numeric(5,4) not null default 0.5 check (confianca between 0 and 1),
  status text not null default 'provisorio' check (status in ('provisorio','validado','desambiguacao')),
  fontes jsonb not null default '[]'::jsonb,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (termo, entidade)
);
create index if not exists evolui_conhecimento_termo_idx on public.evolui_conhecimento using gin (to_tsvector('simple', termo || ' ' || entidade || ' ' || coalesce(contexto,'')));
create index if not exists evolui_conhecimento_tipo_idx on public.evolui_conhecimento (tipo, atualizado_em desc);
alter table public.evolui_conhecimento enable row level security;
revoke all on public.evolui_conhecimento from anon, authenticated;
commit;
