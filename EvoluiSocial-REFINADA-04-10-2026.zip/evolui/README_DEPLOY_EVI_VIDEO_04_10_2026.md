# Deploy do EVI Video Intelligence v1

## 1. Banco

No Supabase SQL Editor, execute:

```text
SQL_EVI_VIDEO_INTELLIGENCE_04_10_2026.sql
```

O script contém `ADD COLUMN IF NOT EXISTS` para as extensões aditivas da tabela.

## 2. Worker

O worker **não roda dentro do Supabase Edge Function**. Ele precisa de um host que consiga executar Python + FFmpeg e, preferencialmente, tenha GPU quando o volume crescer.

Build:

```bash
cd evi-video-worker
docker build -t evolui-evi-video:v1 .
```

Execução:

```bash
docker run --rm \\
  -p 8080:8080 \\
  --env-file .env \\
  evolui-evi-video:v1
```

Health:

```text
GET http://SEU_WORKER:8080/health
```

## 3. Segredo interno do worker

Crie um segredo aleatório para:

```text
EVI_WORKER_TOKEN
```

Não é token de Whisper, Pinterest ou de outro fornecedor. É somente autenticação entre a Evolui e o worker.

## 4. Secrets no Supabase

Na Edge Function `evolui-api`:

```text
EVI_VIDEO_WORKER_URL=https://SEU_HOST/analyze
EVI_VIDEO_WORKER_TOKEN=mesmo-segredo-do-worker
```

O frontend nunca recebe essas variáveis.

O legado continua disponível como fallback:

```text
EVOLUI_VIDEO_ANALYZER_URL
EVOLUI_VIDEO_ANALYZER_TOKEN
```

## 5. Deploy da Edge Function

Publique novamente `supabase/functions/evolui-api`.

A ação existente permanece:

```text
analisar_video_pro
```

Quando `EVI_VIDEO_WORKER_URL` existe, a cadeia usa:

```text
analisar_video_pro
  ↓
EVI worker
  ↓
EVI Video Intelligence
```

## 6. Deploy do frontend

Publique a versão correspondente de:

```text
evoluisocial/app/
```

O Laboratório já mostra a análise estrutural EVI sem alterar o restante da experiência.

## 7. Primeiro teste

Use um vídeo público curto, preferencialmente entre 15 e 90 segundos.

Esperado:

```json
{
  "motor": "evi-video-worker"
}
```

e dentro de `analise`:

```text
versao = evi-video-v1
dna.formato_estrutural
ritmo.classificacao
evi_score
impressao_digital
ajuste_contextual_observavel
transcricao
```

## 8. Erros importantes

### `Ação desconhecida`

O backend remoto ainda não recebeu a versão que contém `analisar_video_pro`.

### `configuracao_pendente`

A ação existe, mas `EVI_VIDEO_WORKER_URL`/legado não está configurado.

### `401 Não autorizado`

O `EVI_WORKER_TOKEN` do Supabase não é igual ao token do worker.

### `502` após iniciar análise

Verifique o log do worker e a cadeia de aquisição (`yt-dlp`) / FFmpeg / modelo Whisper.

## 9. YouTube e yt-dlp

A linha 2026 do yt-dlp introduziu dependência de JavaScript externo para suporte completo a YouTube. O projeto recomenda `yt-dlp-ejs` e um runtime JS (Deno, Node.js, Bun ou QuickJS) para essa finalidade.

Na v1, o código de aquisição permanece isolado em `app/media.py`, para que essa camada possa ser atualizada sem alterar EVI/EIE.

## 10. Ordem segura de publicação

```text
SQL
 ↓
worker
 ↓
healthcheck
 ↓
secrets Supabase
 ↓
evolui-api
 ↓
frontend
 ↓
vídeo curto de teste
```

Não publique o frontend antes de confirmar que o worker responde em `/health`.
