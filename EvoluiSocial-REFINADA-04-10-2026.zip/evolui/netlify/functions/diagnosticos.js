/**
 * Diagnóstico do cliente/lead — versionado.
 * GET ?leadId=              lista todas as versões (mais recente primeiro)
 * POST ?leadId=             cria uma nova versão (vazia, pronta pra editar)
 * PATCH ?id=                atualiza o conteúdo de uma versão em rascunho
 * PATCH ?id=&acao=publicar  publica a versão (congela — não edita mais)
 */

const { requireUser } = require('./_lib/config/authGuard');
const diagnosticosService = require('./_lib/services/diagnosticosService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      if (!query.leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });
      const diagnosticos = await diagnosticosService.listarPorLead(token, query.leadId);
      return json(200, { diagnosticos });
    }

    if (event.httpMethod === 'POST') {
      if (!query.leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });
      const diagnostico = await diagnosticosService.criarNovaVersao(token, query.leadId, user.email);
      return json(201, { diagnostico });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      if (query.acao === 'publicar') {
        const diagnostico = await diagnosticosService.publicar(token, query.id);
        return json(200, { diagnostico });
      }
      const payload = JSON.parse(event.body || '{}');
      const diagnostico = await diagnosticosService.atualizarConteudo(token, query.id, payload.conteudo || {});
      return json(200, { diagnostico });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('diagnosticos', 'Falha na operação de diagnóstico', { message: err.message });
    return json(502, { error: err.message || 'Falha ao processar diagnóstico.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
