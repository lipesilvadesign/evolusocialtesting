const { requireUser } = require('./_lib/config/authGuard');
const intelligenceService = require('./_lib/services/intelligenceService');
const { resolveDateRange } = require('./_lib/dateRange');
const aiInsightsService = require('./_lib/services/aiInsightsService');
const { checkRateLimit } = require('./_lib/rateLimiter');
const { AiError, toHttpStatus } = require('./_lib/errors/aiErrors');
const { AnalyticsError, toHttpStatus: toAnalyticsHttpStatus } = require('./_lib/errors/analyticsErrors');

// Limite de "atualização manual" (refresh=true) — cada uma é uma chamada
// paga à IA. Leituras normais (com cache) não passam por este limite.
const AI_REFRESH_RATE_LIMIT = { max: 10, windowMs: 10 * 60 * 1000 }; // 10 refreshes / 10min por usuário

// Fluxo completo desta Function (etapa "Consultor de Marketing IA",
// estendida na etapa "Inteligência Avançada"):
// intelligenceService (reaproveita analyticsService + analyticsNormalizer
// + insightsEngine, e roda os motores novos: médias históricas, anomalias,
// correlações, health score, oportunidades) → aiInsightsService (Context
// Builder já inclui a inteligência avançada → cache → AI Provider →
// validação de schema) → resposta. A IA nunca chama o Google Analytics
// nem o Supabase diretamente — só recebe o que aiContextBuilder decide
// repassar.
exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') {
    return json(405, { error: 'Método não permitido.' });
  }

  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};
  const refresh = query.refresh === 'true' || query.refresh === '1';

  if (refresh) {
    const { allowed, retryAfterMs } = checkRateLimit(user.email, AI_REFRESH_RATE_LIMIT);
    if (!allowed) {
      return json(429, {
        error: `Muitas atualizações manuais em pouco tempo. Tente novamente em ${Math.ceil(retryAfterMs / 1000)}s.`,
        code: 'RATE_LIMITED',
      });
    }
  }

  try {
    const { key: rangeKey } = resolveDateRange(query);
    const intelligence = await intelligenceService.computeAdvancedIntelligence(token, query);

    const analysis = await aiInsightsService.getAiAnalysis(
      intelligence.normalized,
      intelligence.deterministicInsights,
      { rangeKey },
      { refresh },
      intelligence,
      token
    );

    return json(200, { analysis });
  } catch (err) {
    if (err instanceof AiError) {
      console.error('[ai-insights] AiError:', err.code, err.detail);
      return json(toHttpStatus(err.code), { error: err.message, code: err.code });
    }
    if (err instanceof AnalyticsError) {
      console.error('[ai-insights] AnalyticsError:', err.code, err.detail);
      return json(toAnalyticsHttpStatus(err.code), { error: err.message, code: err.code });
    }
    console.error('[ai-insights] erro inesperado:', err.message);
    return json(500, { error: 'Não foi possível gerar a análise por IA.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
