/**
 * Briefing do cliente/lead — GET ?leadId= busca (ou null), PUT ?leadId= cria
 * ou atualiza (upsert — só existe um briefing por lead).
 */

const { requireUser } = require('./_lib/config/authGuard');
const briefingsService = require('./_lib/services/briefingsService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const leadId = (event.queryStringParameters || {}).leadId;
  if (!leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });

  try {
    if (event.httpMethod === 'GET') {
      const briefing = await briefingsService.obter(token, leadId);
      return json(200, { briefing });
    }

    if (event.httpMethod === 'PUT') {
      const payload = JSON.parse(event.body || '{}');
      const briefing = await briefingsService.salvar(token, leadId, payload.conteudo || {}, user.email);
      return json(200, { briefing });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('briefings', 'Falha na operação de briefing', { message: err.message });
    return json(502, { error: err.message || 'Falha ao processar briefing.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
