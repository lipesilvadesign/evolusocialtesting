/**
 * Cadastro de novo funcionário — a ÚNICA Function do projeto (além dos
 * jobs agendados) que usa a service role key, porque criar uma conta no
 * Supabase Auth exige privilégio de admin na API do GoTrue; não tem outro
 * jeito de fazer isso com o token normal de um usuário.
 *
 * Dois modos (payload.modo), pedido do Felipe 13/09 — "convidar com link,
 * ou gerar um login aqui com senha e tudo":
 * - 'convite_email' (padrão, comportamento original): manda e-mail do
 *   Supabase, a pessoa define a própria senha.
 * - 'gerar_senha': cria a conta JÁ com uma senha temporária (gerada aqui,
 *   nunca escolhida pelo admin) e devolve essa senha na resposta desta
 *   chamada — só uma vez, não fica salva em lugar nenhum. O admin entrega
 *   login+senha direto pra pessoa (Whatsapp, por exemplo), sem depender de
 *   e-mail.
 *
 * SEGURANÇA (nesta ordem, sempre):
 * 1. requireUser() — o chamador precisa ter uma sessão válida (igual
 *    qualquer outra Function).
 * 2. Verifica, usando o TOKEN NORMAL do chamador (nunca a service role
 *    key nesta etapa), se ele é admin — uma query comum a
 *    admin_funcionarios, sujeita à RLS de verdade. Só um admin de verdade
 *    passa daqui; a RLS de admin_funcionarios não deixaria nem um "quase
 *    admin" enxergar isso.
 * 3. SÓ DEPOIS de passar pela checagem acima é que a service role key
 *    entra em cena — exclusivamente para (a) criar a conta (convite OU
 *    senha direta, conforme o modo) e (b) inserir a linha em
 *    admin_funcionarios.
 *
 * Se um dia a checagem do passo 2 for removida por engano, o pior caso
 * ainda é limitado: quem chamar precisa ter uma sessão válida (passo 1) —
 * mas mesmo assim, a intenção clara desta Function é nunca chegar nesse
 * cenário. Por isso o teste "funcionário tentando... " do PROMPT 4 deve
 * incluir tentar chamar esta Function sendo não-admin.
 */

const { requireUser } = require('./_lib/config/authGuard');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./_lib/config/supabase');
const { getServiceRoleKey } = require('./_lib/config/supabaseServiceRole');
const { gerarSenhaTemporaria } = require('./_lib/util/senha');
const auditLog = require('./_lib/services/auditLogService');
const logger = require('./_lib/logger');

// CORREÇÃO 29/09: filtra pela PRÓPRIA linha e exige ativo=true. Antes, um admin
// DESATIVADO ainda enxergava a própria linha role=admin e passava por aqui.
async function chamadorEhAdmin(token, userId) {
  if (!userId) return false;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/admin_funcionarios?select=role&id=eq.${encodeURIComponent(userId)}&role=eq.admin&ativo=eq.true`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
  });
  if (!res.ok) return false;
  const rows = await res.json();
  // A RLS de admin_funcionarios só deixa um admin ENXERGAR uma linha
  // role='admin' de qualquer pessoa (inclusive a própria) — se voltou
  // alguma linha, é porque quem chamou É admin. Ver policy
  // "select_propria_linha_ou_admin" no SQL.
  return rows.length > 0;
}

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });

  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const souAdmin = await chamadorEhAdmin(token, user && user.id);
  if (!souAdmin) {
    logger.warn('funcionarios-convidar', 'Tentativa de convite por não-admin', { actor: user.email });
    return json(403, { error: 'Só administradores podem convidar novos funcionários.' });
  }

  const serviceRoleKey = getServiceRoleKey();
  if (!serviceRoleKey) {
    return json(500, { error: 'SUPABASE_SERVICE_ROLE_KEY não configurada. Ver Netlify → Site settings → Environment variables.' });
  }

  try {
    const payload = JSON.parse(event.body || '{}');
    const { email, nome, role } = payload;
    const modo = payload.modo === 'gerar_senha' ? 'gerar_senha' : 'convite_email'; // padrão = comportamento de sempre
    if (!email || !nome || !role) return json(400, { error: 'Informe "email", "nome" e "role".' });
    if (!['admin', 'prospeccao', 'design'].includes(role)) return json(400, { error: `Papel inválido: ${role}` });

    let novoUserId;
    let senhaGerada = null;

    if (modo === 'gerar_senha') {
      // Cria a conta JÁ COM SENHA (o admin entrega login+senha direto pra
      // pessoa, sem depender de e-mail) — usa o endpoint admin do GoTrue,
      // não o /invite. email_confirm:true porque foi o próprio admin quem
      // cadastrou, não precisa confirmar por link.
      senhaGerada = gerarSenhaTemporaria();
      const criarRes = await fetch(`${SUPABASE_URL}/auth/v1/admin/users`, {
        method: 'POST',
        headers: { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password: senhaGerada, email_confirm: true, user_metadata: { nome } }),
      });
      const criarBody = await criarRes.json();
      if (!criarRes.ok) {
        return json(criarRes.status, { error: criarBody.msg || criarBody.error_description || 'Falha ao criar conta.' });
      }
      novoUserId = criarBody.id;
    } else {
      const conviteRes = await fetch(`${SUPABASE_URL}/auth/v1/invite`, {
        method: 'POST',
        headers: {
          apikey: serviceRoleKey,
          Authorization: `Bearer ${serviceRoleKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });
      const conviteBody = await conviteRes.json();
      if (!conviteRes.ok) {
        return json(conviteRes.status, { error: conviteBody.msg || conviteBody.error_description || 'Falha ao enviar convite.' });
      }
      novoUserId = conviteBody.id;
    }

    const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/admin_funcionarios`, {
      method: 'POST',
      headers: {
        apikey: serviceRoleKey,
        Authorization: `Bearer ${serviceRoleKey}`,
        'Content-Type': 'application/json',
        Prefer: 'return=representation',
      },
      body: JSON.stringify({ id: novoUserId, nome, email, role, ativo: true, criado_por: user.email }),
    });
    if (!insertRes.ok) {
      return json(502, { error: `Conta criada, mas falha ao registrar o papel (${insertRes.status}). Avise o suporte técnico.` });
    }
    const funcionario = (await insertRes.json())[0];

    await auditLog.record(token, {
      actorId: user.email,
      action: 'permission_change',
      targetType: 'funcionario',
      targetId: novoUserId,
      metadata: { acao: modo === 'gerar_senha' ? 'conta_criada_com_senha' : 'convite', email, role },
    });

    // senhaGerada só existe na resposta desta UMA chamada — nunca fica
    // salva em lugar nenhum (nem no admin_funcionarios, nem no audit log
    // acima). Se o admin perder, o jeito é resetar a senha depois.
    return json(201, { funcionario, senhaGerada });
  } catch (err) {
    logger.error('funcionarios-convidar', 'Falha ao convidar funcionário', { message: err.message });
    return json(502, { error: err.message || 'Falha ao convidar funcionário.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
