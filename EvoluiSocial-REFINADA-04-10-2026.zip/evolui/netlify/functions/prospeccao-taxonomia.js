/**
 * Taxonomia do Lead Capture Engine para o painel (fonte única: _lib/captacao/taxonomia.js).
 * GET → setores, fontes, métodos, status, oportunidades, faixas de score, limites.
 */
const { requireUser } = require('./_lib/config/authGuard');
const taxonomia = require('./_lib/captacao/taxonomia');
const flags = require('./_lib/captacao/flags');

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') return { statusCode: 405, body: '' };
  const { error } = await requireUser(event);
  if (error) return { statusCode: error.statusCode, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: error.message }) };
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'private, max-age=300' },
    body: JSON.stringify({ ...taxonomia.publica(), recursos: flags.publicas() }),
  };
};
