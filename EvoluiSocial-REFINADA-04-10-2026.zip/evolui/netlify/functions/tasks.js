const { requireUser } = require('./_lib/config/authGuard');
const tasksService = require('./_lib/services/tasksService');
const auditLog = require('./_lib/services/auditLogService');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      const tasks = await tasksService.list(token);
      return json(200, { tasks });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      if (!payload.titulo) return json(400, { error: 'Campo "titulo" é obrigatório.' });
      const task = await tasksService.create(token, { ...payload, criadoPor: user.email });
      await auditLog.record(token, { actorId: user.email, action: 'create', targetType: 'tarefa', targetId: task.id });
      return json(201, { task });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const { status } = JSON.parse(event.body || '{}');
      const task = await tasksService.updateStatus(token, query.id, status);
      await auditLog.record(token, {
        actorId: user.email,
        action: 'status_change',
        targetType: 'tarefa',
        targetId: query.id,
        metadata: { status },
      });
      return json(200, { task });
    }

    if (event.httpMethod === 'DELETE') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await tasksService.remove(token, query.id);
      await auditLog.record(token, { actorId: user.email, action: 'delete', targetType: 'tarefa', targetId: query.id });
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return json(500, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
