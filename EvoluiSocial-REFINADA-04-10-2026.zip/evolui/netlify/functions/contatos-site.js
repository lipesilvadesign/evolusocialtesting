/**
 * Área "Contatos do site" do painel. Exige sessão real (requireUser) e usa
 * o token do PRÓPRIO usuário em toda chamada — o RLS de site_contatos só
 * libera admin e prospecção ativos (ver SQL_PENDENTE_site_contatos.sql).
 *
 *   GET                         → { contatos, email: { configurado, destino } }
 *   PATCH  ?id=                 → muda status/observações
 *   DELETE ?id=                 → exclui (só admin, o banco confere)
 *   POST   ?acao=reenviar&id=   → reenvia o aviso por e-mail daquele contato
 *   POST   ?acao=testar-email   → manda um e-mail de teste para a caixa de destino
 */

const { requireUser } = require('./_lib/config/authGuard');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./_lib/config/supabase');
const contatos = require('./_lib/services/siteContatosService');
const { enviarEmail } = require('./_lib/integrations/umblerSmtp');
const auditLog = require('./_lib/services/auditLogService');
const logger = require('./_lib/logger');

const EMAIL_TIMEOUT_MS = 8000;

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}

async function papelDoChamador(token, userId) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_funcionarios?select=role&id=eq.${encodeURIComponent(userId)}&ativo=eq.true`,
    { headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) return null;
  const rows = await res.json();
  return rows[0] ? rows[0].role : null;
}

function mascararEmail(email) {
  const [u, d] = String(email).split('@');
  if (!d) return email;
  return `${u.slice(0, 2)}${'•'.repeat(Math.max(1, u.length - 2))}@${d}`;
}

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const papel = await papelDoChamador(token, user.id);
  if (papel !== 'admin' && papel !== 'prospeccao') {
    return json(403, { error: 'Seu perfil não tem acesso aos contatos do site.' });
  }

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      const lista = await contatos.list(token, { status: query.status });
      return json(200, {
        contatos: lista,
        email: { configurado: contatos.smtpConfigurado(), destino: mascararEmail(contatos.destinoAviso()) },
      });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      let payload;
      try { payload = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'JSON inválido.' }); }
      const contato = await contatos.update(token, query.id, payload, user.email);
      await auditLog.record(token, { actorId: user.email, action: 'update', targetType: 'site_contato', targetId: query.id, metadata: { status: payload.status } }).catch(() => {});
      return json(200, { contato });
    }

    if (event.httpMethod === 'DELETE') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await contatos.remove(token, query.id);
      await auditLog.record(token, { actorId: user.email, action: 'delete', targetType: 'site_contato', targetId: query.id }).catch(() => {});
      return json(200, { ok: true });
    }

    if (event.httpMethod === 'POST' && query.acao === 'reenviar') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const contato = await contatos.getById(token, query.id);
      if (!contato) return json(404, { error: 'Contato não encontrado.' });
      const resultado = await contatos.enviarAviso(contato, { timeoutMs: EMAIL_TIMEOUT_MS });
      await contatos.registrarReenvio(token, contato.id, resultado);
      const atualizado = await contatos.getById(token, contato.id);
      return json(200, { resultado: { status: resultado.status, erro: resultado.erro || null }, contato: atualizado });
    }

    if (event.httpMethod === 'POST' && query.acao === 'testar-email') {
      if (!contatos.smtpConfigurado()) {
        return json(200, { resultado: { status: 'sem_smtp', erro: 'UMBLER_SMTP_USER/UMBLER_SMTP_PASS não configurados no Netlify.' } });
      }
      try {
        await enviarEmail({
          para: contatos.destinoAviso(),
          assunto: 'Teste de aviso de contatos do site',
          corpo: `Teste disparado pelo painel por ${user.email} em ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Recife' })}.\n\nSe este e-mail chegou, os avisos de novos contatos do site estão funcionando.`,
          timeoutMs: EMAIL_TIMEOUT_MS,
        });
        return json(200, { resultado: { status: 'enviado', destino: mascararEmail(contatos.destinoAviso()) } });
      } catch (err) {
        return json(200, { resultado: { status: 'falhou', erro: String(err.message || err).slice(0, 300) } });
      }
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('contatos-site', 'Falha na operação', { message: err.message });
    return json(500, { error: err.message || 'Erro inesperado.' });
  }
};
