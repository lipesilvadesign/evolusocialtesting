/**
 * Relatório da aba Prospecção — buscas realizadas, e-mails enviados e leads
 * criados num período (hoje / últimos 7 dias / últimos 30 dias / tudo).
 * Function síncrona normal (só leitura, tabelas pequenas, rápido).
 */

const { requireUser } = require('./_lib/config/authGuard');
const { resolverPeriodo } = require('./_lib/dateRangeProspeccao');
const { agregarRelatorio } = require('./_lib/templateUtil');
const relatorioService = require('./_lib/services/relatorioService');

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Método não permitido.' });

  const { token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const periodoChave = (event.queryStringParameters || {}).periodo || 'mes';

  let periodo;
  try {
    periodo = resolverPeriodo(periodoChave);
  } catch (err) {
    return json(400, { error: err.message });
  }

  try {
    const [envios, buscas, leads, atividades, statusAtual] = await Promise.all([
      relatorioService.buscarEnvios(token, periodo),
      relatorioService.buscarBuscas(token, periodo),
      relatorioService.contarLeadsPorPeriodo(token, periodo),
      relatorioService.buscarAtividadesPeriodo(token, periodo),
      relatorioService.listarStatusAtual(token),
    ]);

    const resumo = agregarRelatorio(envios, buscas, leads);

    return json(200, {
      periodo: { chave: periodo.periodo, label: periodo.label, inicio: periodo.inicio, fim: periodo.fim },
      resumo,
      envios,
      buscas,
      // Adicionado para o Dashboard (Início) calcular indicadores reais
      // (mensagens enviadas, respostas, funil, desempenho por dia) sem
      // nenhuma chamada extra — nada aqui é inventado: se a tabela não tiver
      // atividade no período, o array vem vazio e a interface mostra "sem
      // dados", não zero forjado.
      atividades,
      statusAtual,
    });
  } catch (err) {
    return json(502, { error: err.message || 'Falha ao gerar relatório.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
