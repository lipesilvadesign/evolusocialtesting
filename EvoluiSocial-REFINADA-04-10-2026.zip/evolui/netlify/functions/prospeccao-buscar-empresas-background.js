/**
 * DESCONTINUADO em 30/09 (Lead Capture Engine) — mantido só para
 * compatibilidade com uma aba do painel antigo que ainda esteja aberta.
 *
 * A busca antiga inseria resultados DIRETO no CRM e filtrava por nome
 * (causa das 21 buscas com zero resultado). Agora esta Function apenas
 * registra o pedido como uma captação (job) e o processa pelo mesmo
 * pipeline do Capture Engine: os resultados vão para a CAPTURA, para
 * revisão em Prospecção → Captação. Nada entra no CRM sem aprovação.
 */
const crypto = require('crypto');
const { requireUser } = require('./_lib/config/authGuard');
const { rest } = require('./_lib/supabaseRest');
const taxonomia = require('./_lib/captacao/taxonomia');
const pipeline = require('./_lib/captacao/pipeline');
const { criarDeps } = require('./_lib/captacao/deps');
const { ehUuid } = require('./_lib/captacao/acesso');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: '' };
  const { user, token, error } = await requireUser(event);
  if (error) return { statusCode: error.statusCode, body: '' };
  let b = {};
  try { b = JSON.parse(event.body || '{}'); } catch { return { statusCode: 400, body: '' }; }
  const cidades = Array.isArray(b.cidades) ? b.cidades.filter(Boolean).slice(0, taxonomia.LIMITES.cidadesPorJob) : [];
  const { setor, subsetor } = taxonomia.classificarSetor(b.ramo);
  if (!cidades.length || !setor) return { statusCode: 400, body: '' };
  const id = ehUuid(b.jobId) ? b.jobId : crypto.randomUUID();
  try {
    await rest(token, 'admin_prospeccao_buscas', {
      method: 'POST', prefer: 'return=minimal',
      body: { id, tipo: 'pesquisa', status: 'em_andamento', metodo_captacao: 'pesquisa_local', providers: ['geoapify', 'overpass'], cidades,
        ramo: b.ramo || setor, parametros: { setor, termo: subsetor, cidades, raioKm: 15 }, progresso: [], criado_por: user.email, criado_por_id: user.id },
    });
    const { data } = await rest(token, `admin_prospeccao_buscas?id=eq.${id}&select=*`);
    await pipeline.executarPesquisa(data[0], criarDeps(token));
  } catch (err) {
    logger.error('prospeccao-buscar-empresas', 'Falha (rota de compatibilidade)', { message: err.message });
  }
  return { statusCode: 200, body: '' };
};
