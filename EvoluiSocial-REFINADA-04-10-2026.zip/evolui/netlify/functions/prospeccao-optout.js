/**
 * Registra um opt-out (bloqueio permanente de contato) — POST apenas.
 * Ver admin_prospeccao_optouts no SQL: sobrevive à exclusão do lead de
 * propósito, pra nunca recontatar mesmo se a empresa for reencontrada numa
 * busca futura.
 */

const { requireUser } = require('./_lib/config/authGuard');
const optoutService = require('./_lib/services/optoutService');
const auditLog = require('./_lib/services/auditLogService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });

  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Corpo da requisição inválido.' });
  }

  try {
    const registro = await optoutService.registrar(token, { ...payload, criadoPor: user.email });
    await auditLog.record(token, {
      actorId: user.email,
      action: 'optout_prospeccao',
      targetType: 'lead_prospeccao',
      metadata: { email: payload.email, telefone: payload.telefone, origemId: payload.origemId, motivo: payload.motivo },
    });
    return json(201, { registro });
  } catch (err) {
    logger.error('prospeccao-optout', 'Falha ao registrar opt-out', { message: err.message });
    return json(502, { error: err.message || 'Falha ao registrar opt-out.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
