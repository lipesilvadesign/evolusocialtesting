/**
 * Analytics Normalizer.
 *
 * Fluxo: analyticsService → analyticsNormalizer → insightsEngine →
 * structuredInsights → UI. Este arquivo é o normalizer: não faz nenhuma
 * chamada de rede, não conhece o Google Analytics nem a UI — só pega o
 * snapshot bruto (analyticsService.getInsightsSnapshot) e devolve um
 * "NormalizedSnapshot" onde cada métrica/página/evento/canal já vem com
 * seu par do período anterior casado, e as variações já calculadas.
 *
 * Responsabilidades daqui: casar chaves (path/nome/canal), calcular
 * variação absoluta e percentual tratando divisão por zero, marcar itens
 * "novos" (sem correspondente no período anterior) — nada de regras de
 * negócio (isso é do insightsEngine).
 */

/**
 * @param {number} current
 * @param {number|undefined|null} previous
 * @returns {{ deltaAbs: number|null, deltaPct: number|null, isNew: boolean }}
 */
function computeDelta(current, previous) {
  if (previous == null) return { deltaAbs: null, deltaPct: null, isNew: false };
  if (previous === 0) {
    // Divisão por zero tratada explicitamente: se antes era 0 e agora não
    // é, é crescimento "novo" (percentual não faz sentido matemático) —
    // nunca retorna Infinity/NaN.
    return { deltaAbs: current, deltaPct: current > 0 ? null : 0, isNew: current > 0 };
  }
  const deltaAbs = current - previous;
  const deltaPct = Math.round((deltaAbs / previous) * 1000) / 10;
  return { deltaAbs, deltaPct, isNew: false };
}

function normalizeSnapshot(raw) {
  const hasPreviousOverview = Boolean(raw.overview.previous) && !raw.overview.previous.isEmpty;

  const metrics = {};
  Object.keys(raw.overview.current.metrics).forEach((name) => {
    const value = raw.overview.current.metrics[name];
    const previousValue = hasPreviousOverview ? raw.overview.previous.metrics[name] : null;
    metrics[name] = { value, previousValue, ...computeDelta(value, previousValue) };
  });

  const prevPagesByPath = new Map((raw.pages.previous || []).map((p) => [p.path, p]));
  const pages = (raw.pages.current || []).map((p) => {
    const prev = prevPagesByPath.get(p.path);
    // Página fora do top do período anterior é tratada como "sem dado
    // equivalente" (previousViews=0) — aproximação deliberada, documentada
    // na descrição do insight (nunca afirma "zero visualizações", só que
    // não apareceu entre as principais do período anterior).
    const previousViews = prev ? prev.views : 0;
    const viewsDelta = computeDelta(p.views, previousViews);
    return {
      path: p.path,
      title: p.title,
      views: p.views,
      activeUsers: p.activeUsers,
      eventCount: p.eventCount,
      eventsPerView: p.views > 0 ? Math.round((p.eventCount / p.views) * 100) / 100 : 0,
      previousViews: prev ? prev.views : null,
      ...viewsDelta,
    };
  });

  const prevEventsByName = new Map((raw.events.previous || []).map((e) => [e.name, e]));
  const events = (raw.events.current || []).map((e) => {
    const prev = prevEventsByName.get(e.name);
    const previousCount = prev ? prev.count : 0;
    const countDelta = computeDelta(e.count, previousCount);
    return { name: e.name, count: e.count, previousCount: prev ? prev.count : null, ...countDelta };
  });

  const prevTrafficByChannel = new Map((raw.trafficSources.previous || []).map((t) => [t.channel, t]));
  const trafficSources = (raw.trafficSources.current || []).map((t) => {
    const prev = prevTrafficByChannel.get(t.channel);
    const previousSessions = prev ? prev.sessions : 0;
    const sessionsDelta = computeDelta(t.sessions, previousSessions);
    return {
      channel: t.channel,
      sessions: t.sessions,
      activeUsers: t.activeUsers,
      previousSessions: prev ? prev.sessions : null,
      ...sessionsDelta,
    };
  });

  const totalDeviceUsers = (raw.devices.current || []).reduce((sum, d) => sum + d.activeUsers, 0);
  const devices = (raw.devices.current || []).map((d) => ({
    category: d.category,
    activeUsers: d.activeUsers,
    sessions: d.sessions,
    share: totalDeviceUsers > 0 ? Math.round((d.activeUsers / totalDeviceUsers) * 1000) / 10 : 0,
  }));

  const avgEventsPerView = pages.length > 0 ? pages.reduce((sum, p) => sum + p.eventsPerView, 0) / pages.length : 0;

  return {
    rangeLabel: raw.rangeLabel,
    hasComparison: hasPreviousOverview,
    metrics,
    pages,
    events,
    trafficSources,
    devices,
    avgEventsPerView: Math.round(avgEventsPerView * 100) / 100,
    generatedAt: new Date().toISOString(),
  };
}

module.exports = { normalizeSnapshot, computeDelta };
