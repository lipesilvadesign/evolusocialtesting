const PRESETS = {
  hoje: { startDate: 'today', endDate: 'today' },
  ontem: { startDate: 'yesterday', endDate: 'yesterday' },
  '7d': { startDate: '7daysAgo', endDate: 'today' },
  '28d': { startDate: '28daysAgo', endDate: 'today' },
  '30d': { startDate: '30daysAgo', endDate: 'today' },
  '90d': { startDate: '90daysAgo', endDate: 'today' },
};

const PRESET_LABELS = {
  hoje: 'Hoje',
  ontem: 'Ontem',
  '7d': 'Últimos 7 dias',
  '28d': 'Últimos 28 dias',
  '30d': 'Últimos 30 dias',
  '90d': 'Últimos 90 dias',
  personalizado: 'Período personalizado',
};

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * @param {{ range?: string, start?: string, end?: string }} query
 * @returns {{ dateRange: {startDate:string,endDate:string}, label: string, key: string }}
 */
function resolveDateRange(query = {}) {
  const key = query.range || '7d';

  if (key === 'personalizado') {
    if (!DATE_RE.test(query.start || '') || !DATE_RE.test(query.end || '')) {
      throw new Error('Período personalizado exige "start" e "end" no formato AAAA-MM-DD.');
    }
    return { dateRange: { startDate: query.start, endDate: query.end }, label: PRESET_LABELS.personalizado, key };
  }

  const preset = PRESETS[key];
  if (!preset) throw new Error(`Período inválido: ${key}`);
  return { dateRange: preset, label: PRESET_LABELS[key], key };
}

/** Período imediatamente anterior, de mesma duração — usado pra comparação. */
function previousDateRange(dateRange) {
  // Só calculável de forma exata para períodos com data absoluta; para
  // presets relativos (today/NdaysAgo) a Data API aceita datas relativas
  // só no `dateRanges` principal — para comparação usamos um segundo
  // dateRange relativo equivalente, deslocado.
  const RELATIVE_SHIFT = {
    today: { startDate: 'yesterday', endDate: 'yesterday' },
    yesterday: { startDate: '2daysAgo', endDate: '2daysAgo' },
  };
  if (RELATIVE_SHIFT[dateRange.startDate]) return RELATIVE_SHIFT[dateRange.startDate];

  const match = /^(\d+)daysAgo$/.exec(dateRange.startDate);
  if (match) {
    const n = Number(match[1]);
    return { startDate: `${n * 2}daysAgo`, endDate: `${n + 1}daysAgo` };
  }
  // Datas absolutas (período personalizado): desloca pelo mesmo número de dias.
  const start = new Date(dateRange.startDate);
  const end = new Date(dateRange.endDate);
  const days = Math.round((end - start) / 86400000) + 1;
  const prevEnd = new Date(start.getTime() - 86400000);
  const prevStart = new Date(prevEnd.getTime() - (days - 1) * 86400000);
  const iso = (d) => d.toISOString().slice(0, 10);
  return { startDate: iso(prevStart), endDate: iso(prevEnd) };
}

module.exports = { resolveDateRange, previousDateRange, PRESET_LABELS };
