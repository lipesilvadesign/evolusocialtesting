/**
 * Códigos de erro previstos pela integração com o Google Analytics.
 * Cada Function traduz isto numa resposta JSON segura — nunca inclui stack
 * trace, nunca inclui qualquer trecho de credencial/token.
 */
const CODES = {
  CREDENTIALS_MISSING: 'Credenciais do Google Analytics não configuradas.',
  PROPERTY_INVALID: 'GA4 Property ID inválido ou não configurado.',
  API_UNAVAILABLE: 'O Google Analytics está indisponível no momento.',
  AUTH_ERROR: 'Falha de autenticação com o Google Analytics.',
  QUOTA_EXCEEDED: 'Limite de consultas do Google Analytics excedido. Tente novamente em alguns minutos.',
  EMPTY_RESPONSE: 'O Google Analytics não retornou dados para este período.',
  TIMEOUT: 'O Google Analytics demorou demais para responder.',
  UNKNOWN: 'Não foi possível carregar os dados do Google Analytics.',
};

class AnalyticsError extends Error {
  constructor(code, detail) {
    super(CODES[code] || CODES.UNKNOWN);
    this.code = CODES[code] ? code : 'UNKNOWN';
    // `detail` é só pra log server-side (console.error) — nunca vai na resposta HTTP.
    this.detail = detail;
  }
}

function toHttpStatus(code) {
  switch (code) {
    case 'CREDENTIALS_MISSING':
    case 'PROPERTY_INVALID':
      return 400;
    case 'AUTH_ERROR':
      return 401;
    case 'QUOTA_EXCEEDED':
      return 429;
    case 'TIMEOUT':
      return 504;
    case 'API_UNAVAILABLE':
      return 502;
    case 'EMPTY_RESPONSE':
      return 200; // não é bem um erro — resposta válida, só sem linhas
    default:
      return 500;
  }
}

module.exports = { AnalyticsError, CODES, toHttpStatus };
