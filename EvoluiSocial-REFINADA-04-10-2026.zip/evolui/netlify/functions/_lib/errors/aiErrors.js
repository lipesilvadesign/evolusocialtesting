const CODES = {
  AI_CREDENTIALS_MISSING: 'A chave da IA não está configurada.',
  AI_PROVIDER_UNAVAILABLE: 'O provedor de IA está indisponível no momento.',
  AI_AUTH_ERROR: 'Falha de autenticação com o provedor de IA.',
  AI_RATE_LIMIT: 'Limite de uso da IA excedido. Tente novamente em alguns minutos.',
  AI_TIMEOUT: 'O provedor de IA demorou demais para responder.',
  AI_INVALID_RESPONSE: 'A IA retornou uma resposta em formato inesperado.',
  UNKNOWN: 'Não foi possível gerar a análise por IA.',
};

class AiError extends Error {
  constructor(code, detail) {
    super(CODES[code] || CODES.UNKNOWN);
    this.code = CODES[code] ? code : 'UNKNOWN';
    // `detail` é só pra log server-side — nunca vai na resposta HTTP nem
    // inclui a chave de API ou o corpo completo do prompt/resposta.
    this.detail = detail;
  }
}

function toHttpStatus(code) {
  switch (code) {
    case 'AI_CREDENTIALS_MISSING':
      return 400;
    case 'AI_AUTH_ERROR':
      return 401;
    case 'AI_RATE_LIMIT':
      return 429;
    case 'AI_TIMEOUT':
      return 504;
    case 'AI_PROVIDER_UNAVAILABLE':
    case 'AI_INVALID_RESPONSE':
      return 502;
    default:
      return 500;
  }
}

module.exports = { AiError, CODES, toHttpStatus };
