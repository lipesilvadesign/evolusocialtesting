/**
 * Cliente SMTP mínimo — só net/tls nativos do Node, sem nenhum pacote
 * externo. Implementa exatamente a conversa que o envio da Umbler precisa:
 * conectar, EHLO, STARTTLS, EHLO de novo (agora seguro), AUTH LOGIN,
 * MAIL FROM, RCPT TO, DATA, QUIT.
 *
 * Por quê não usar nodemailer: era a única dependência externa do projeto
 * inteiro, e isso muda o deploy no Netlify de "puramente estático, publica
 * na hora" pra "precisa rodar `npm install` antes" — o usuário notou a
 * diferença de velocidade e pediu pra tirar. SMTP com STARTTLS é um
 * protocolo simples o suficiente pra implementar direto, com teste real
 * (ver tests/rawSmtp.test.js, que sobe um servidor SMTP falso em
 * localhost e verifica a conversa inteira, sem precisar de rede externa).
 */

const net = require('net');
const tls = require('tls');

const TIMEOUT_MS = 20000;

function normalizarErroRede(err) {
  if (err && Array.isArray(err.errors) && err.errors.length) {
    const preferido = err.errors.find((x) => x && (x.code === 'ECONNREFUSED' || x.code === 'EACCES')) || err.errors[0];
    return normalizarErroRede(preferido);
  }
  if (err instanceof Error) return err;
  return new Error(String(err || 'Erro de rede SMTP'));
}

function b64(str) {
  return Buffer.from(str, 'utf8').toString('base64');
}

/** Escapa CRLF sozinho e o encurta pra evitar SMTP command/header injection
 * via campos vindos de dados de lead (assunto, endereço). */
function sanitizarLinha(str) {
  return String(str || '').replace(/[\r\n]/g, ' ');
}

/**
 * Gerencia a leitura de respostas SMTP linha a linha, incluindo respostas
 * multi-linha (código seguido de "-" em vez de espaço = "tem mais linha
 * vindo"). Uma única resposta pendente por vez — SMTP aqui é estritamente
 * pergunta/resposta, nunca pipeline.
 */
function criarLeitorSmtp() {
  let buffer = '';
  let linhasAcumuladas = [];
  let resolverPendente = null;
  let rejeitarPendente = null;

  function processarBuffer() {
    let idx;
    while ((idx = buffer.indexOf('\n')) !== -1) {
      let linha = buffer.slice(0, idx);
      buffer = buffer.slice(idx + 1);
      if (linha.endsWith('\r')) linha = linha.slice(0, -1);
      if (!linha) continue;
      linhasAcumuladas.push(linha);
      const ehUltimaLinha = linha.length >= 4 && linha[3] === ' ';
      if (ehUltimaLinha) {
        const codigo = Number(linha.slice(0, 3));
        const resposta = { codigo, texto: linhasAcumuladas.join('\n') };
        linhasAcumuladas = [];
        if (resolverPendente) {
          const r = resolverPendente;
          resolverPendente = null;
          rejeitarPendente = null;
          r(resposta);
        }
      }
    }
  }

  return {
    alimentar(chunk) {
      buffer += chunk.toString('utf8');
      processarBuffer();
    },
    falhar(err) {
      if (rejeitarPendente) {
        const r = rejeitarPendente;
        resolverPendente = null;
        rejeitarPendente = null;
        r(err);
      }
    },
    aguardarResposta() {
      return new Promise((resolve, reject) => {
        resolverPendente = resolve;
        rejeitarPendente = reject;
      });
    },
  };
}

/**
 * Assunto com acento (nome do visitante, "Serviço"...) precisa ir codificado
 * (RFC 2047) — cabeçalho cru em UTF-8 aparece como "ServiÃ§o" em alguns
 * clientes de e-mail. Assunto só com ASCII continua exatamente igual.
 */
function codificarAssunto(texto) {
  if (/^[\x20-\x7e]*$/.test(texto)) return texto;
  return `=?UTF-8?B?${Buffer.from(texto, 'utf8').toString('base64')}?=`;
}

/**
 * @param {{ host: string, port: number, user: string, pass: string, from: string, fromDisplay?: string, to: string, replyTo?: string, subject: string, text: string, timeoutMs?: number }} opts
 */
async function enviarEmailRaw(opts) {
  const leitor = criarLeitorSmtp();
  let socket = net.connect({ host: opts.host, port: opts.port });

  // timeoutMs opcional: quem responde a um visitante (contato-criar) não pode
  // esperar 20 s — a Function síncrona da Netlify corta em 10 s.
  const limiteMs = Number(opts.timeoutMs) > 0 ? Number(opts.timeoutMs) : TIMEOUT_MS;
  const timer = setTimeout(() => {
    leitor.falhar(new Error(`Timeout SMTP após ${limiteMs}ms`));
    socket.destroy();
  }, limiteMs);

  function ligarListeners(s) {
    s.on('data', (chunk) => leitor.alimentar(chunk));
    s.on('error', (err) => leitor.falhar(normalizarErroRede(err)));
  }
  ligarListeners(socket);

  function enviarLinha(linha) {
    socket.write(linha + '\r\n');
  }

  async function comando(linha, codigosEsperados) {
    if (linha !== null) enviarLinha(linha);
    const resposta = await leitor.aguardarResposta();
    if (!codigosEsperados.includes(resposta.codigo)) {
      throw new Error(`SMTP: esperava ${codigosEsperados.join('/')}, servidor respondeu "${resposta.texto}"`);
    }
    return resposta;
  }

  try {
    await comando(null, [220]); // saudação inicial do servidor
    await comando('EHLO felipebranding.com.br', [250]);
    await comando('STARTTLS', [220]);

    // Upgrade da conexão pra TLS — o socket TCP já aberto vira a base de um
    // socket seguro, sem reconectar.
    socket.removeAllListeners('data');
    socket.removeAllListeners('error');
    const socketSeguro = tls.connect({ socket, servername: opts.host, ...(opts.tlsOptions || {}) });
    await new Promise((resolve, reject) => {
      socketSeguro.once('secureConnect', resolve);
      socketSeguro.once('error', reject);
    });
    socket = socketSeguro;
    ligarListeners(socket);

    await comando('EHLO felipebranding.com.br', [250]);
    await comando('AUTH LOGIN', [334]);
    await comando(b64(opts.user), [334]);
    await comando(b64(opts.pass), [235]);
    await comando(`MAIL FROM:<${sanitizarLinha(opts.from)}>`, [250]);
    await comando(`RCPT TO:<${sanitizarLinha(opts.to)}>`, [250]);
    await comando('DATA', [354]);

    const dataAtual = new Date().toUTCString();
    const mensagem = [
      `From: ${sanitizarLinha(opts.fromDisplay || opts.from)} <${opts.from}>`,
      `To: <${opts.to}>`,
      // Reply-To opcional (29/09): no aviso de contato do site, "Responder"
      // no e-mail já vai direto para o visitante.
      ...(opts.replyTo ? [`Reply-To: <${sanitizarLinha(opts.replyTo)}>`] : []),
      `Subject: ${codificarAssunto(sanitizarLinha(opts.subject))}`,
      `Date: ${dataAtual}`,
      // Message-ID próprio (30/09): sem ele alguns provedores pontuam como spam.
      `Message-ID: <${Date.now().toString(36)}.${require('crypto').randomBytes(8).toString('hex')}@${String(opts.from).split('@')[1] || 'felipebranding.com.br'}>`,
      // Descadastro (30/09): e-mail de prospecção leva List-Unsubscribe (mailto).
      ...(opts.listUnsubscribe ? [`List-Unsubscribe: <${sanitizarLinha(opts.listUnsubscribe)}>`] : []),
      'MIME-Version: 1.0',
      'Content-Type: text/plain; charset=utf-8',
      'Content-Transfer-Encoding: 8bit',
      '',
      String(opts.text || '').replace(/\r\n/g, '\n').replace(/\n/g, '\r\n'),
    ].join('\r\n');

    // Byte-stuffing: uma linha que começa com "." precisa virar ".." (regra
    // do protocolo SMTP, senão o servidor interpreta como fim de mensagem).
    const mensagemEscapada = mensagem.replace(/\r\n\./g, '\r\n..');

    await comando(mensagemEscapada + '\r\n.', [250]);
    await comando('QUIT', [221]).catch(() => {}); // QUIT falhar não é motivo pra reportar erro — o e-mail já foi aceito antes dele
  } finally {
    clearTimeout(timer);
    socket.destroy();
  }
}

module.exports = { enviarEmailRaw };
