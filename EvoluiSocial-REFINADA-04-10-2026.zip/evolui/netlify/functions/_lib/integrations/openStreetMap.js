/**
 * Busca manual de empresas via OpenStreetMap — gratuita, sem chave de API.
 * Usada pelo botão "Atualizar" da aba Prospecção (prospeccao-buscar-empresas-background.js).
 *
 * Dois passos:
 * 1. Geocodificação (Nominatim, com fallback pro Photon) — converte o nome da
 *    cidade digitada/escolhida no popup em coordenadas (lat/lon), já que o
 *    Overpass busca por raio ao redor de um ponto, não por nome de cidade.
 * 2. Overpass API — busca por nome/regex dentro de um raio, tentando uma
 *    LISTA de espelhos públicos em sequência (não um único servidor fixo).
 *
 * Por quê múltiplos espelhos: o servidor público principal (overpass-api.de)
 * vem devolvendo 406 de forma instável desde meados de 2026 — problema
 * documentado e reportado por vários projetos diferentes (não é bug deste
 * código), então depender de um único servidor é frágil por natureza. A
 * defesa aqui é tentar cada espelho da lista até um responder OK, e lembrar
 * qual funcionou por último pra tentar ele primeiro nas próximas cidades da
 * mesma execução (evita perder tempo re-testando espelhos já sabidos ruins).
 *
 * Usa o MESMO namespace de origem_id (`osm:${type}/${id}`) do job semanal —
 * de propósito, pra nunca inserir duas vezes o mesmo local só porque veio
 * por um caminho diferente (manual vs. automático).
 */

const { calcularRadical } = require('../templateUtil');

// 01/10: overpass-api.de (instância principal) primeiro. Medido em produção
// (job ceb4fe77, 01/10): kumi e private.coffee responderam 429 e
// overpass-api.de 406 — 406 é a recusa de requisições SEM User-Agent
// identificado (política de uso do Overpass). Agora todas as chamadas
// mandam o User-Agent do app (HEADERS_OVERPASS).
const OVERPASS_MIRRORS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass.private.coffee/api/interpreter',
  'https://overpass.osm.ch/api/interpreter',
  'https://overpass.openstreetmap.ru/api/interpreter',
  'https://overpass.monicz.dev/api/interpreter',
];
const RETRY_APOS_429_MS = 4000; // dá uma segunda chance ao MESMO espelho antes de desistir dele
// 30/09: Retry-After vinha sem teto (um espelho pedindo 60 s travava a busca inteira).
const RETRY_AFTER_MAX_MS = 5000;
const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search';
const PHOTON_URL = 'https://photon.komoot.io/api/'; // fallback de geocodificação, sem chave, se o Nominatim falhar

const RADIUS_METERS = 15000; // ~15km ao redor do centro da cidade escolhida
const MAX_RESULTS_PER_CIDADE = 30;
// 8s por tentativa, não 20s — com até 6 espelhos tentados em sequência (mais
// retry em 429), um timeout alto multiplica rápido: 6 × 20s passaria de 2
// minutos só no Overpass, estourando o tempo que a interface espera antes
// de desistir de esperar (ver pollStatusBusca no painel). 8s ainda é
// generoso pra um servidor saudável responder.
const TIMEOUT_MS = Number(process.env.OSM_TIMEOUT_MS) || 8000; // ajustável via env var se precisar, sem redeploy de código

// Nominatim pede um identificador do app no header (política de uso pública deles).
const HEADERS_NOMINATIM = { 'User-Agent': 'FelipeBrandingProspeccao/1.0 (contato@felipebranding.com.br)' };
const HEADERS_OVERPASS = { 'User-Agent': 'FelipeBrandingProspeccao/1.0 (+https://felipebranding.com.br; contato@felipebranding.com.br)' };

// Lembra qual espelho funcionou por último NESTA execução da Function (module-level:
// cada invocação de Background Function roda em um processo próprio, então isto
// não "vaza" estado entre cliques diferentes — só ajuda dentro do mesmo clique
// quando várias cidades são buscadas em sequência).
let ultimoMirrorFuncionando = 0;

/**
 * fetch com timeout — Node/undici não tem timeout nativo, então usamos
 * AbortController. Sem isso, um servidor que nunca responde travaria a
 * Background Function até o limite de 15 minutos do Netlify.
 */
async function fetchComTimeout(url, opts, timeoutMs = TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function aguardar(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * @param {string} cidade
 * @returns {Promise<{ lat: number, lon: number } | null>}
 */
async function geocodeViaNominatim(cidade) {
  const url = `${NOMINATIM_URL}?q=${encodeURIComponent(cidade)}&format=jsonv2&limit=1&countrycodes=br`;
  const res = await fetchComTimeout(url, { headers: HEADERS_NOMINATIM });
  if (!res.ok) throw new Error(`Nominatim respondeu ${res.status}`);
  const data = await res.json();
  if (!Array.isArray(data) || !data.length) return null;
  return { lat: Number(data[0].lat), lon: Number(data[0].lon) };
}

/**
 * Fallback de geocodificação — usado só se o Nominatim falhar (erro de rede,
 * timeout, 5xx). Photon (komoot) é um serviço público, gratuito, sem chave,
 * que também indexa dados do OpenStreetMap.
 * @param {string} cidade
 * @returns {Promise<{ lat: number, lon: number } | null>}
 */
async function geocodeViaPhoton(cidade) {
  const url = `${PHOTON_URL}?q=${encodeURIComponent(cidade)}&limit=1&lang=pt`;
  const res = await fetchComTimeout(url, {});
  if (!res.ok) throw new Error(`Photon respondeu ${res.status}`);
  const data = await res.json();
  const feature = data && Array.isArray(data.features) ? data.features[0] : null;
  if (!feature || !feature.geometry || !Array.isArray(feature.geometry.coordinates)) return null;
  const [lon, lat] = feature.geometry.coordinates; // GeoJSON é [lon, lat], invertido do usual
  return { lat, lon };
}

/**
 * @param {string} cidade ex: "Petrolina, PE"
 * @returns {Promise<{ lat: number, lon: number } | null>}
 */
async function geocodeCidade(cidade) {
  try {
    const viaNominatim = await geocodeViaNominatim(cidade);
    if (viaNominatim) return viaNominatim;
    // Nominatim respondeu OK mas sem resultado — tenta Photon antes de desistir.
  } catch (err) {
    // Nominatim falhou de vez (rede/timeout/5xx) — cai pro fallback.
  }
  try {
    return await geocodeViaPhoton(cidade);
  } catch (err) {
    throw new Error(`Não foi possível geocodificar "${cidade}" (Nominatim e Photon falharam): ${err.message}`);
  }
}

function buildOverpassQuery(ramo, lat, lon) {
  const around = `around:${RADIUS_METERS},${lat},${lon}`;
  // Usa o RADICAL da palavra, não a palavra inteira — "construção" digitada
  // não bate com "Construtora" nem "Construções" como substring literal
  // (sufixo diferente: -ção vs -tora/-ções). O radical ("constru") bate com
  // as duas. Mesma lógica compartilhada usada no filtro local do Geoapify
  // (templateUtil.js) — as duas fontes precisam concordar em como
  // interpretam o ramo digitado, senão uma acha o que a outra não acharia
  // pela mesma palavra.
  const termo = ramo.trim().toLowerCase();
  const radical = calcularRadical(termo);
  const termoEscapado = radical.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // escapa regex especial só depois de calcular o radical
  return `
    [out:json][timeout:25];
    (
      node["name"~"${termoEscapado}",i](${around});
      way["name"~"${termoEscapado}",i](${around});
    );
    out center tags;
  `;
}

/**
 * Tenta cada espelho do Overpass em sequência (começando pelo último que
 * funcionou nesta execução) até um responder OK. Só desiste de vez se
 * TODOS falharem — nesse caso o erro final lista o que cada um respondeu,
 * pra facilitar diagnóstico se isso um dia voltar a acontecer.
 *
 * Função de baixo nível — recebe a query Overpass QL já pronta. Usada tanto
 * por buscarEmpresasOSM (busca manual, esta arquivo) quanto por
 * prospeccao-sync-osm.js (job semanal), pra nenhum dos dois duplicar a
 * lógica de fallback entre espelhos.
 * @param {string} query Overpass QL já montada
 * @returns {Promise<object[]>} elementos brutos do Overpass
 */
async function postOverpassQuery(query, opcoes = {}) {
  // 30/09: `prazoMs` = orçamento TOTAL (todas as tentativas somadas). Sem ele,
  // 6 espelhos × 8 s + esperas de 429 passavam de 1 minuto (causa medida da
  // lentidão da captação). Chamadas antigas sem opções mantêm o comportamento.
  const inicio = Date.now();
  const prazoMs = Number(opcoes.prazoMs) > 0 ? Number(opcoes.prazoMs) : null;
  const restante = () => (prazoMs ? prazoMs - (Date.now() - inicio) : Infinity);
  let ordem = [
    ...OVERPASS_MIRRORS.slice(ultimoMirrorFuncionando),
    ...OVERPASS_MIRRORS.slice(0, ultimoMirrorFuncionando),
  ];
  // 01/10 (Fase 3): ordem pela SAÚDE medida (histórico no banco) quando disponível
  if (typeof opcoes.ordenar === 'function') {
    try { const o = opcoes.ordenar(ordem.slice()); if (Array.isArray(o) && o.length) ordem = o; } catch { /* mantém a ordem padrão */ }
  }
  // registra cada tentativa (host, status, duração) — nunca derruba a busca
  const registrar = (url, status, ms) => {
    if (typeof opcoes.registrar !== 'function') return;
    try { opcoes.registrar(new URL(url).host, status, ms); } catch { /* telemetria é melhor-esforço */ }
  };
  const falhas = [];

  for (let i = 0; i < ordem.length; i++) {
    const mirrorUrl = ordem[i];
    // Até 2 tentativas NO MESMO espelho só quando ele responde 429 (limite de
    // uso). Qualquer outro tipo de falha passa direto pro próximo espelho.
    for (let tentativa = 0; tentativa < 2; tentativa++) {
      if (restante() < 1500) {
        falhas.push(`orçamento de ${Math.round(prazoMs / 1000)} s esgotado`);
        throw new Error(`Overpass não respondeu a tempo: ${falhas.join('; ')}`);
      }
      const t0 = Date.now();
      try {
        const res = await fetchComTimeout(mirrorUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain', Accept: 'application/json', ...HEADERS_OVERPASS },
          body: query,
        }, Math.min(TIMEOUT_MS, restante()));
        // 01/10: com espelhos sobrando, 429 pula direto para o próximo (esperar
        // queimava o orçamento); só o ÚLTIMO espelho ganha uma 2ª tentativa.
        if (res.status === 429 || res.status === 406 || res.status >= 500) registrar(mirrorUrl, res.status === 429 ? '429' : res.status === 406 ? '406' : '5xx', Date.now() - t0);
        else if (!res.ok) registrar(mirrorUrl, 'erro', Date.now() - t0);
        if (res.status === 429 && i < ordem.length - 1) { falhas.push(`${mirrorUrl} → HTTP 429`); break; }
        if (res.status === 429 && tentativa === 0) {
          const retryAfterHeader = Number(res.headers && res.headers.get && res.headers.get('retry-after'));
          const pedida = Number.isFinite(retryAfterHeader) && retryAfterHeader > 0 ? retryAfterHeader * 1000 : RETRY_APOS_429_MS;
          const espera = Math.min(pedida, RETRY_AFTER_MAX_MS, Math.max(0, restante() - 2000));
          if (espera <= 0) { falhas.push(`${mirrorUrl} → HTTP 429`); break; }
          await aguardar(espera);
          continue; // 2ª (e última) tentativa neste mesmo espelho
        }
        if (!res.ok) {
          falhas.push(`${mirrorUrl} → HTTP ${res.status}`);
          break;
        }
        const data = await res.json().catch(() => null);
        if (!data || !Array.isArray(data.elements)) {
          registrar(mirrorUrl, 'erro', Date.now() - t0);
          falhas.push(`${mirrorUrl} → resposta inválida (não é JSON esperado)`);
          break;
        }
        // 30/09: o Overpass responde 200 com lista VAZIA + "remark" quando estoura
        // tempo/memória no servidor. Antes isso virava "0 resultados, sucesso".
        if (!data.elements.length && data.remark && /runtime error|timed out|out of memory|Query timed/i.test(String(data.remark))) {
          registrar(mirrorUrl, 'timeout', Date.now() - t0);
          falhas.push(`${mirrorUrl} → consulta interrompida pelo servidor (${String(data.remark).slice(0, 120)})`);
          break;
        }
        ultimoMirrorFuncionando = Math.max(0, OVERPASS_MIRRORS.indexOf(mirrorUrl));
        registrar(mirrorUrl, 'ok', Date.now() - t0);
        return data.elements;
      } catch (err) {
        registrar(mirrorUrl, err.name === 'AbortError' ? 'timeout' : 'erro', Date.now() - t0);
        falhas.push(`${mirrorUrl} → ${err.name === 'AbortError' ? 'timeout' : err.message}`);
        break;
      }
    }
  }

  throw new Error(`Todos os espelhos do Overpass falharam: ${falhas.join('; ')}`);
}

/**
 * @param {string} ramo texto livre digitado no popup (ex: "distribuidora de bebidas")
 * @param {number} lat
 * @param {number} lon
 * @returns {Promise<object[]>} elementos brutos do Overpass (já limitado ao teto de resultados da busca manual)
 */
async function buscarEmpresasOSM(ramo, lat, lon) {
  const elementos = await postOverpassQuery(buildOverpassQuery(ramo, lat, lon));
  return elementos.slice(0, MAX_RESULTS_PER_CIDADE);
}

function buildEndereco(tags) {
  const parts = [tags['addr:street'], tags['addr:housenumber'], tags['addr:suburb']].filter(Boolean);
  return parts.length ? parts.join(', ') : null;
}

/**
 * @param {object} el elemento bruto do Overpass
 * @param {string} cidade cidade buscada (usada como fallback/rótulo)
 * @param {string} ramo rótulo digitado no popup, vira o "setor" do lead
 */
function elementToLead(el, cidade, ramo) {
  const tags = el.tags || {};
  if (!tags.name) return null;
  const site = tags.website || tags['contact:website'] || null;
  return {
    empresa: tags.name,
    setor: ramo,
    telefone: tags.phone || tags['contact:phone'] || null,
    endereco: buildEndereco(tags),
    cidade: tags['addr:city'] || cidade,
    site,
    // Não é "chance de fechar contrato" — é o critério real da Felipe
    // Branding (presença online fraca = prioridade). Sempre editável depois.
    prioridade: site ? 'media' : 'alta',
    origemId: `osm:${el.type}/${el.id}`,
    fonte: 'osm_manual',
  };
}

module.exports = { geocodeCidade, buscarEmpresasOSM, elementToLead, postOverpassQuery, OVERPASS_MIRRORS, RETRY_AFTER_MAX_MS };
