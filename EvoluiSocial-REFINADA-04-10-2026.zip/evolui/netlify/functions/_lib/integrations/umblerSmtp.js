/**
 * Envio de e-mail via SMTP da Umbler (a caixa marketing@felipebranding.com.br
 * já usada no domínio) — usando o cliente SMTP mínimo (net/tls nativos,
 * sem dependência nenhuma), ver rawSmtp.js.
 *
 * IMPORTANTE — a Umbler proíbe, nos termos de uso, disparo em massa/marketing
 * a partir de uma caixa de e-mail profissional (risco real de bloqueio da
 * conta ou do domínio inteiro). Por isso: nada de envio simultâneo em lote
 * aqui — a Function que chama isto (prospeccao-enviar-email-background.js)
 * manda um e-mail de cada vez, com pausa entre eles, e aplica um teto diário
 * baixo (EMAIL_PROSPECCAO_LIMITE_DIARIO, ver config/env.js).
 */

const { enviarEmailRaw } = require('./rawSmtp');
const { env } = require('../config/env');

/**
 * @param {{ para: string, assunto: string, corpo: string, responderPara?: string, timeoutMs?: number }} msg corpo em texto simples
 * (sem HTML — reduz ainda mais a chance de cair em filtro de spam vindo de
 * uma caixa de e-mail comum, não uma plataforma de disparo)
 */
async function enviarEmail({ para, assunto, corpo, responderPara, timeoutMs, listaDescadastro }) {
  const user = env.email.smtpUser();
  const pass = env.email.smtpPass();
  if (!user || !pass) {
    throw new Error('UMBLER_SMTP_USER/UMBLER_SMTP_PASS não configurados. Ver Netlify → Site settings → Environment variables.');
  }

  await enviarEmailRaw({
    host: 'smtp.umbler.com',
    port: 587,
    user,
    pass,
    from: user,
    fromDisplay: 'Felipe Souto - Felipe Branding',
    to: para,
    replyTo: responderPara || undefined,
    listUnsubscribe: listaDescadastro || undefined,
    timeoutMs,
    subject: assunto,
    text: corpo,
  });
}

module.exports = { enviarEmail };
