/**
 * Integração com a Google Places API (New) — Text Search.
 *
 * Usada só pelo botão manual "Atualizar" da aba Prospecção (nunca por um job
 * agendado): o usuário escolhe cidades + ramo no painel, e isto busca
 * empresas reais via Google (nome, endereço, telefone, site, nota/avaliações,
 * status de funcionamento). Complementa a busca automática semanal gratuita
 * (OpenStreetMap, ver prospeccao-sync-osm.js) com dado de qualidade melhor,
 * mas paga por chamada — por isso é sob demanda, não agendada.
 *
 * Documentação: https://developers.google.com/maps/documentation/places/web-service/text-search
 */

const { env } = require('../config/env');

const SEARCH_URL = 'https://places.googleapis.com/v1/places:searchText';
const MAX_RESULTS_PER_QUERY = 20; // teto da própria API por requisição

// Campos pedidos explicitamente (FieldMask) — a Places API (New) cobra por
// grupo de campos solicitado, então só pedimos o que a tela realmente usa.
const FIELD_MASK = [
  'places.id',
  'places.displayName',
  'places.formattedAddress',
  'places.nationalPhoneNumber',
  'places.internationalPhoneNumber',
  'places.websiteUri',
  'places.rating',
  'places.userRatingCount',
  'places.businessStatus',
  'places.primaryTypeDisplayName',
].join(',');

/**
 * @param {string} ramo texto livre (ex: "construtora", "distribuidora de bebidas")
 * @param {string} cidade ex: "Petrolina, PE"
 * @returns {Promise<object[]>} lugares brutos da API do Google
 */
async function buscarEmpresas(ramo, cidade) {
  const apiKey = env.googlePlaces.apiKey();
  if (!apiKey) {
    throw new Error('GOOGLE_PLACES_API_KEY não configurada. Ver Netlify → Site settings → Environment variables.');
  }

  const res = await fetch(SEARCH_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Api-Key': apiKey,
      'X-Goog-FieldMask': FIELD_MASK,
    },
    body: JSON.stringify({
      textQuery: `${ramo} em ${cidade}`,
      languageCode: 'pt-BR',
      regionCode: 'BR',
      maxResultCount: MAX_RESULTS_PER_QUERY,
    }),
  });

  if (!res.ok) {
    const detalhe = await res.text().catch(() => '');
    throw new Error(`Google Places respondeu ${res.status} para "${ramo} em ${cidade}": ${detalhe}`);
  }

  const data = await res.json();
  return Array.isArray(data.places) ? data.places : [];
}

/**
 * Converte um resultado bruto do Google no formato de lead usado pela tabela
 * admin_prospeccao_leads. Não inclui e-mail (a Places API não fornece) nem
 * anos de mercado — ficam para preenchimento manual antes do primeiro contato.
 * @param {object} place
 * @param {string} cidade cidade buscada (fallback se o endereço não trouxer)
 * @param {string} setor rótulo do ramo escolhido no popup
 */
function placeToLead(place, cidade, setor) {
  if (!place.id || !place.displayName) return null;
  const avaliacao =
    typeof place.rating === 'number' && typeof place.userRatingCount === 'number'
      ? `${place.rating.toFixed(1)} (${place.userRatingCount} avaliações)`
      : null;

  return {
    empresa: place.displayName.text || place.displayName,
    setor,
    telefone: place.nationalPhoneNumber || place.internationalPhoneNumber || null,
    endereco: place.formattedAddress || null,
    cidade,
    site: place.websiteUri || null,
    avaliacaoGoogle: avaliacao,
    origemId: `google:${place.id}`,
    aberta: place.businessStatus ? place.businessStatus === 'OPERATIONAL' : null,
  };
}

module.exports = { buscarEmpresas, placeToLead };
