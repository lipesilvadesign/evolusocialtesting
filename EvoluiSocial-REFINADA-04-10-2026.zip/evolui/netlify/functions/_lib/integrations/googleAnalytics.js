const { env } = require('../config/env');
const { getAccessToken } = require('../config/googleAuth');
const { AnalyticsError } = require('../errors/analyticsErrors');

const DATA_API_BASE = 'https://analyticsdata.googleapis.com/v1beta';
const REQUEST_TIMEOUT_MS = 10000;

/** Lê e valida as credenciais a partir da variável de ambiente (nunca hardcode). */
function loadServiceAccount() {
  const raw = env.googleAnalytics.serviceAccountJson();
  if (!raw) throw new AnalyticsError('CREDENTIALS_MISSING', 'GA_SERVICE_ACCOUNT_JSON ausente.');
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new AnalyticsError('CREDENTIALS_MISSING', 'GA_SERVICE_ACCOUNT_JSON não é um JSON válido.');
  }
  if (!parsed.client_email || !parsed.private_key) {
    throw new AnalyticsError('CREDENTIALS_MISSING', 'JSON da service account sem client_email/private_key.');
  }
  // Em variáveis de ambiente, quebras de linha da chave privada costumam
  // vir escapadas como "\\n" — normaliza pra quebra de linha real.
  parsed.private_key = parsed.private_key.replace(/\\n/g, '\n');
  return parsed;
}

function loadPropertyId() {
  const id = env.googleAnalytics.propertyId();
  if (!id) throw new AnalyticsError('PROPERTY_INVALID', 'GA_PROPERTY_ID ausente.');
  return id;
}

async function fetchWithTimeout(url, opts) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } catch (err) {
    if (err.name === 'AbortError') throw new AnalyticsError('TIMEOUT', 'Timeout chamando a Data API.');
    throw new AnalyticsError('API_UNAVAILABLE', err.message);
  } finally {
    clearTimeout(timer);
  }
}

async function callDataApi(path, body) {
  const serviceAccount = loadServiceAccount();
  const propertyId = loadPropertyId();
  const token = await getAccessToken(serviceAccount);

  const res = await fetchWithTimeout(`${DATA_API_BASE}/properties/${propertyId}:${path}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (res.status === 429) throw new AnalyticsError('QUOTA_EXCEEDED', 'HTTP 429 da Data API.');
  if (res.status === 401 || res.status === 403) {
    const text = await res.text().catch(() => '');
    throw new AnalyticsError('AUTH_ERROR', text.slice(0, 300));
  }
  if (res.status === 400) {
    const text = await res.text().catch(() => '');
    throw new AnalyticsError('PROPERTY_INVALID', text.slice(0, 300));
  }
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new AnalyticsError('API_UNAVAILABLE', `HTTP ${res.status}: ${text.slice(0, 300)}`);
  }

  const json = await res.json();
  if (!json.rows || json.rows.length === 0) {
    // Não é erro — só sinaliza pro service que veio vazio, pra ele decidir
    // o que mostrar (nunca inventamos números).
    json.__empty = true;
  }
  return json;
}

/** @param {object} reportRequest - corpo de runReport (dateRanges/dimensions/metrics/...) */
function runReport(reportRequest) {
  return callDataApi('runReport', reportRequest);
}

/** @param {object} reportRequest - corpo de runRealtimeReport */
function runRealtimeReport(reportRequest) {
  return callDataApi('runRealtimeReport', reportRequest);
}

/** Consulta mínima real, usada pelo botão "Testar conexão" em Configurações. */
async function testConnection() {
  const result = await runReport({
    dateRanges: [{ startDate: 'yesterday', endDate: 'today' }],
    metrics: [{ name: 'activeUsers' }],
  });
  return { ok: true, empty: Boolean(result.__empty) };
}

module.exports = { runReport, runRealtimeReport, testConnection, loadPropertyId };
