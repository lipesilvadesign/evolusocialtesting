/**
 * Busca manual de empresas via Geoapify Places API — infraestrutura de
 * empresa (paga por trás, com plano gratuito de 3.000 créditos/dia), em vez
 * de servidores comunitários do Overpass, que se mostraram instáveis sob
 * carga (406/429 em produção). Usada só pelo botão "Atualizar" — a busca
 * automática semanal continua no OpenStreetMap/Overpass (gratuita, já com
 * fallback entre espelhos, ver openStreetMap.js), sem mudança nenhuma nela.
 *
 * Diferença de arquitetura importante: o Overpass aceita busca por
 * nome/regex livre. O Geoapify Places API busca por CATEGORIA (taxonomia
 * fixa de ~400 categorias), não por texto livre. Pra não depender de
 * adivinhar a categoria exata certa pra cada ramo digitado no popup (e
 * arriscar retornar zero resultados por engano de categoria), a estratégia
 * aqui é: buscar um conjunto AMPLO de categorias de negócio (comercial,
 * escritório, indústria, educação, hospedagem, serviços) dentro do raio, e
 * depois filtrar localmente pelo nome do lugar conter o termo digitado —
 * mesma lógica de correspondência por nome que já era usada no Overpass,
 * só que aplicada depois da resposta da API em vez de dentro da query.
 */

const { calcularRadical } = require('../templateUtil');

// "building" (sozinho ou como building.commercial/office/industrial) foi
// removido de propósito: a maioria dos objetos nessa categoria no OSM é só
// o contorno físico do prédio, SEM nome nenhum. Numa cidade grande como
// Petrolina, isso lota o limite de resultados com prédios anônimos antes
// mesmo dos negócios de verdade (que têm nome) aparecerem na resposta —
// causa raiz confirmada de "buscar em Petrolina não acha nada" apesar da
// cidade ser bem mapeada. As categorias abaixo só trazem POIs que já
// nascem com nome no OSM (loja, escritório, fábrica, escola, hotel...).
const CATEGORIAS_NEGOCIO = 'commercial,office,production,education,accommodation,service,healthcare';
const RADIUS_METERS = 15000;
// Limite alto de propósito — mais categorias juntas retornam muita coisa
// antes do filtro por nome entrar em ação; um teto baixo corta a resposta
// cedo demais e os negócios que bateriam com o ramo digitado nem chegam a
// aparecer. 500 é o máximo por página da Places API; custo é baixo (1
// crédito a cada 20 resultados, cota gratuita é 3.000/dia).
const MAX_RESULTS_PER_CIDADE = 500;
const TIMEOUT_MS = Number(process.env.GEOAPIFY_TIMEOUT_MS) || 20000;

async function fetchComTimeout(url, opts) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * @param {string} ramo texto livre digitado no popup (ex: "construtora")
 * @param {number} lat
 * @param {number} lon
 * @param {string} apiKey
 * @returns {Promise<object[]>} features (GeoJSON) já filtradas pelo nome conter o ramo
 */
async function buscarEmpresasGeoapify(ramo, lat, lon, apiKey) {
  if (!apiKey) throw new Error('GEOAPIFY_API_KEY não configurada.');

  const url =
    `https://api.geoapify.com/v2/places?categories=${CATEGORIAS_NEGOCIO}` +
    `&filter=circle:${lon},${lat},${RADIUS_METERS}` +
    `&limit=${MAX_RESULTS_PER_CIDADE}&apiKey=${encodeURIComponent(apiKey)}`;

  let res;
  try {
    res = await fetchComTimeout(url, {});
  } catch (err) {
    throw new Error(`Geoapify: falha de rede (${err.name === 'AbortError' ? 'timeout' : err.message})`);
  }

  if (!res.ok) {
    const detalhe = await res.text().catch(() => '');
    const dica = res.status === 401 ? ' (chave de API inválida)' : res.status === 429 ? ' (limite diário de créditos atingido)' : '';
    throw new Error(`Geoapify respondeu ${res.status}${dica}: ${detalhe.slice(0, 200)}`);
  }

  const data = await res.json().catch(() => null);
  if (!data || !Array.isArray(data.features)) {
    throw new Error('Geoapify: resposta inválida (não é GeoJSON esperado)');
  }

  const termo = ramo.trim().toLowerCase();
  if (!termo) return data.features;

  // Correspondência por radical, não substring cru do termo inteiro — assim
  // "construção" também casa com "Construtora Silva" ou "Construções" (nenhuma
  // das duas contém a palavra "construção" literal — sufixo diferente).
  const radical = calcularRadical(termo);
  return data.features.filter((f) => {
    const nome = ((f.properties && f.properties.name) || '').toLowerCase();
    return nome.includes(termo) || (radical.length >= 4 && nome.includes(radical));
  });
}

// address_line1 normalmente é o NOME do lugar (repete o que já vai em
// "empresa"); address_line2 é o endereço de verdade (rua, número, cidade).
// Documentação oficial confirma isso com exemplo real:
// address_line1: "Vaporetto" (nome), address_line2: "Albrechtstraße 12,
// 10117 Berlin, Germany" (endereço). Usar os dois juntos duplicava o nome
// da empresa dentro do campo de endereço — corrigido pra usar só address_line2.
function buildEndereco(props) {
  return props.address_line2 || props.formatted || props.address_line1 || null;
}

/**
 * @param {object} feature GeoJSON feature da resposta do Geoapify
 * @param {string} cidade cidade buscada (fallback/rótulo)
 * @param {string} ramo rótulo digitado no popup, vira o "setor" do lead
 */
function featureToLead(feature, cidade, ramo) {
  const props = feature.properties || {};
  if (!props.name || !props.place_id) return null;
  const site = props.website || (props.contact && props.contact.website) || null;
  return {
    empresa: props.name,
    setor: ramo,
    telefone: (props.contact && props.contact.phone) || props.phone || null,
    endereco: buildEndereco(props),
    cidade: props.city || cidade,
    site,
    // Não é "chance de fechar contrato" — é o critério real da Felipe
    // Branding (presença online fraca = prioridade). Sempre editável depois.
    prioridade: site ? 'media' : 'alta',
    origemId: `geoapify:${props.place_id}`,
    fonte: 'geoapify_manual',
  };
}

module.exports = { buscarEmpresasGeoapify, featureToLead, CATEGORIAS_NEGOCIO };
