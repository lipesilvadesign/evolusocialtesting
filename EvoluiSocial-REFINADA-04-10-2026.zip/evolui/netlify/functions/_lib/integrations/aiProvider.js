const { env } = require('../config/env');
const { AiError } = require('../errors/aiErrors');

const API_URL = 'https://api.anthropic.com/v1/messages';
const API_VERSION = '2023-06-01';
const REQUEST_TIMEOUT_MS = 20000;

// Modelo padrão: Haiku, por custo — esta tarefa é extração/análise
// estruturada, não exige o modelo mais caro. Pode ser trocado via AI_MODEL
// (ex: "claude-sonnet-5" para análises mais elaboradas, a um custo maior).
const DEFAULT_MODEL = 'claude-haiku-4-5-20251001';
const MAX_TOKENS = 1600;

const TOOL_NAME = 'submit_marketing_analysis';

function pointSchema() {
  return {
    type: 'object',
    properties: {
      text: { type: 'string' },
      evidence_strength: { type: 'string', enum: ['forte', 'moderada', 'limitada'] },
      related_metric: { type: 'string' },
    },
    required: ['text', 'evidence_strength'],
  };
}

const TOOL_INPUT_SCHEMA = {
  type: 'object',
  properties: {
    summary: { type: 'string' },
    insufficient_data: { type: 'boolean' },
    positive_points: { type: 'array', items: pointSchema() },
    attention_points: { type: 'array', items: pointSchema() },
    opportunities: { type: 'array', items: pointSchema() },
    recommendations: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          explanation: { type: 'string' },
          evidence: { type: 'string' },
          suggested_action: { type: 'string' },
          priority: { type: 'string', enum: ['baixa', 'media', 'alta'] },
        },
        required: ['title', 'explanation', 'evidence', 'suggested_action', 'priority'],
      },
    },
    questions_to_investigate: { type: 'array', items: { type: 'string' } },
  },
  required: [
    'summary',
    'insufficient_data',
    'positive_points',
    'attention_points',
    'opportunities',
    'recommendations',
    'questions_to_investigate',
  ],
};

const SYSTEM_PROMPT = `Você é um consultor de marketing digital analisando dados reais de Google Analytics 4 de um site de branding/design.

REGRAS OBRIGATÓRIAS:
- Use SOMENTE os dados fornecidos no contexto (métricas, páginas, eventos, fontes de tráfego, leituras determinísticas já calculadas). NUNCA invente métricas, páginas, eventos, números ou crescimento que não estejam no contexto.
- NUNCA afirme causalidade a partir de correlação. Não diga "X aconteceu porque Y". Prefira "os dados indicam", "foi observado", "pode ser interessante investigar".
- NUNCA afirme ter realizado uma ação (você só analisa, não executa nada).
- Se o contexto não tiver dados suficientes (pouco tráfego, sem período de comparação, poucos itens), defina insufficient_data como true e deixe claro no summary que não há dados suficientes para concluir — mesmo assim preencha os arrays (podem ficar vazios).
- Cada ponto (positive_points/attention_points/opportunities) precisa de um "evidence_strength" honesto: "forte" (métrica robusta, volume alto, já confirmada por leitura determinística), "moderada" (tendência real mas volume baixo ou só 1 evidência), "limitada" (indício fraco, deve ser tratado com cautela). NUNCA apresente confiança como percentual estatístico.
- Recomendações devem ser PRÁTICAS e ESPECÍFICAS aos dados recebidos — nunca genéricas como "continue criando conteúdo". Toda recomendação precisa citar a evidência (métrica/página/evento específico) que a sustenta.
- As "deterministicInsights" no contexto já foram calculadas por um motor de regras determinístico (não são geradas por você) — use-as como uma das fontes de evidência, mas produza sua própria síntese executiva, não apenas repita os títulos.
- Responda SOMENTE através da ferramenta submit_marketing_analysis — nunca em texto livre.`;

async function fetchWithTimeout(url, opts) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } catch (err) {
    if (err.name === 'AbortError') throw new AiError('AI_TIMEOUT', 'Timeout chamando o provedor de IA.');
    throw new AiError('AI_PROVIDER_UNAVAILABLE', err.message);
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Núcleo genérico de chamada à IA por tool-use (saída estruturada,
 * obrigatória — nunca texto livre). Extraído nesta etapa (PROMPT 5) pra
 * ser reaproveitado tanto pela análise de marketing (já existente, sem
 * NENHUMA mudança de comportamento) quanto pelo gerador de diagnóstico
 * (novo) — evita duplicar timeout/tratamento de erro/parsing de resposta.
 * @param {{ systemPrompt: string, toolName: string, toolDescription: string,
 *   inputSchema: object, userContent: string, maxTokens?: number }} opts
 * @returns {Promise<{ result: object, usage: { tokensInput: number, tokensOutput: number } }>}
 */
async function callClaudeTool({ systemPrompt, toolName, toolDescription, inputSchema, userContent, maxTokens }) {
  const apiKey = env.ai.apiKey();
  if (!apiKey) throw new AiError('AI_CREDENTIALS_MISSING', 'AI_API_KEY ausente.');
  const model = process.env.AI_MODEL || DEFAULT_MODEL;

  const res = await fetchWithTimeout(API_URL, {
    method: 'POST',
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': API_VERSION,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens || MAX_TOKENS,
      system: systemPrompt,
      messages: [{ role: 'user', content: userContent }],
      tools: [{ name: toolName, description: toolDescription, input_schema: inputSchema }],
      tool_choice: { type: 'tool', name: toolName },
    }),
  });

  if (res.status === 401 || res.status === 403) {
    throw new AiError('AI_AUTH_ERROR', `HTTP ${res.status} do provedor de IA.`);
  }
  if (res.status === 429) {
    throw new AiError('AI_RATE_LIMIT', 'HTTP 429 do provedor de IA.');
  }
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new AiError('AI_PROVIDER_UNAVAILABLE', `HTTP ${res.status}: ${text.slice(0, 300)}`);
  }

  const data = await res.json();
  const toolUse = (data.content || []).find((block) => block.type === 'tool_use' && block.name === toolName);
  if (!toolUse || !toolUse.input) {
    throw new AiError('AI_INVALID_RESPONSE', 'Nenhum tool_use com o nome esperado na resposta.');
  }
  return {
    result: toolUse.input,
    usage: {
      tokensInput: (data.usage && data.usage.input_tokens) || 0,
      tokensOutput: (data.usage && data.usage.output_tokens) || 0,
    },
  };
}

/**
 * @param {object} aiContext - saída de aiContextBuilder.buildAiContext()
 * @returns {Promise<object>} objeto bruto retornado pela IA (ainda não validado contra o schema)
 */
async function generateAnalysis(aiContext) {
  return callClaudeTool({
    systemPrompt: SYSTEM_PROMPT,
    toolName: TOOL_NAME,
    toolDescription: 'Envia a análise de marketing estruturada.',
    inputSchema: TOOL_INPUT_SCHEMA,
    userContent: JSON.stringify(aiContext),
  });
}

module.exports = { generateAnalysis, callClaudeTool, DEFAULT_MODEL, TOOL_NAME };
