/**
 * Ponto único de leitura de variáveis de ambiente server-side.
 *
 * Regra do projeto: NENHUM segredo (API key privada, token, service account)
 * pode ser enviado ao frontend. Tudo que é sensível é lido aqui, dentro de
 * uma Netlify Function (ambiente Node, nunca exposto ao navegador), e nunca
 * repassado bruto numa resposta JSON.
 *
 * Nesta etapa não há nenhuma integração real (Google Analytics/IA) ainda —
 * este arquivo só define ONDE essas chaves vão morar quando existirem, para
 * as próximas etapas não precisarem inventar uma convenção nova.
 */

function getEnv(name, { required = false } = {}) {
  const value = process.env[name];
  if (required && !value) {
    throw new Error(
      `Variável de ambiente obrigatória ausente: ${name}. ` +
        `Configure em Netlify → Site settings → Environment variables.`
    );
  }
  return value || null;
}

const env = {
  // Usado por netlify/functions/_lib/integrations/googleAnalytics.js.
  // GA_SERVICE_ACCOUNT_JSON: conteúdo integral do JSON da service account
  // (nunca commitado). GA_PROPERTY_ID: só o número da propriedade GA4.
  googleAnalytics: {
    propertyId: () => getEnv('GA_PROPERTY_ID'),
    serviceAccountJson: () => getEnv('GA_SERVICE_ACCOUNT_JSON'),
  },
  // Usado por netlify/functions/_lib/integrations/aiProvider.js.
  // AI_API_KEY: chave da Anthropic (server-side, nunca vai ao frontend).
  // AI_MODEL é lido diretamente via process.env no aiProvider (opcional,
  // tem default) — não precisou de getter aqui.
  ai: {
    apiKey: () => getEnv('AI_API_KEY'),
  },
  // Usado por netlify/functions/_lib/integrations/googlePlaces.js (não usado
  // por nenhum botão hoje — ver geoapify abaixo, escolhido no lugar dele).
  googlePlaces: {
    apiKey: () => getEnv('GOOGLE_PLACES_API_KEY'),
  },
  // Usado por netlify/functions/_lib/integrations/geoapify.js (busca manual
  // de empresas na aba Prospecção — botão "Atualizar"). Plano gratuito:
  // 3.000 créditos/dia, sem cartão de crédito. https://myprojects.geoapify.com
  geoapify: {
    apiKey: () => getEnv('GEOAPIFY_API_KEY'),
  },
  // Usado por netlify/functions/_lib/integrations/umblerSmtp.js (envio de
  // e-mail da aba Prospecção). Credenciais da própria caixa contato@ hospedada
  // na Umbler — nunca a senha de login do painel da Umbler, só a do e-mail.
  email: {
    smtpUser: () => getEnv('UMBLER_SMTP_USER'),
    smtpPass: () => getEnv('UMBLER_SMTP_PASS'),
    // Limite de segurança por dia — a Umbler proíbe uso de e-mail profissional
    // pra disparo em massa/marketing nos termos de uso; manter baixo evita
    // risco de bloqueio da conta ou do domínio inteiro.
    dailyLimit: () => Number(getEnv('EMAIL_PROSPECCAO_LIMITE_DIARIO') || 25),
  },
};

module.exports = { getEnv, env };
