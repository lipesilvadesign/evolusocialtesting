const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./supabase');

/**
 * Valida a sessão de quem está chamando a Function.
 *
 * Requisito da etapa: "Não confiar apenas na interface para proteger
 * ações. A autorização real deverá ocorrer no backend". É isto aqui —
 * mesmo que alguém chame estas Functions diretamente (sem passar pela
 * interface do painel), sem um token de sessão válido de uma conta
 * autenticada de verdade no Supabase, a chamada é rejeitada.
 *
 * Não usa chave privada/service role nenhuma — só valida o token que o
 * PRÓPRIO usuário já tem (o mesmo criado pelo login em painel/index.html).
 * As chamadas ao banco depois disso também usam esse mesmo token (não a
 * chave anônima crua), então o Postgres/Supabase aplica Row Level Security
 * como o usuário real — dupla camada, não só "confiar que validamos".
 *
 * @returns {Promise<{ user: object|null, token: string|null, error: {statusCode:number, message:string}|null }>}
 */
async function requireUser(event) {
  const authHeader = event.headers.authorization || event.headers.Authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return { user: null, token: null, error: { statusCode: 401, message: 'Não autenticado.' } };
  }

  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      return { user: null, token: null, error: { statusCode: 401, message: 'Sessão inválida ou expirada.' } };
    }
    const user = await res.json();

    // 01/10 (EvoluiSocial): o Supabase passou a aceitar cadastro público com
    // Google para a EvoluiSocial. Uma conta logada NÃO é mais sinônimo de
    // funcionário — então, além da sessão válida, toda Function do painel
    // exige uma linha ATIVA em admin_funcionarios (lida com o próprio token,
    // sob RLS: "select_propria_linha_ou_admin"). Sem isso, um usuário da
    // EvoluiSocial conseguiria chamar, por exemplo, analytics-insights (dados
    // do Google Analytics da agência) ou ai-insights (custo de IA).
    const fr = await fetch(
      `${SUPABASE_URL}/rest/v1/admin_funcionarios?select=role&id=eq.${encodeURIComponent(user.id)}&ativo=eq.true&limit=1`,
      { headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` } }
    );
    const linhas = fr.ok ? await fr.json() : [];
    if (!Array.isArray(linhas) || !linhas.length) {
      return { user: null, token: null, error: { statusCode: 403, message: 'Acesso restrito à equipe.' } };
    }
    user.funcionario_role = linhas[0].role;
    return { user, token, error: null };
  } catch (err) {
    return { user: null, token: null, error: { statusCode: 502, message: 'Falha ao validar sessão.' } };
  }
}

module.exports = { requireUser };
