/**
 * Service role key — ignora RLS inteiramente. Duas (e só duas) exceções ao
 * padrão do projeto de sempre usar o token da sessão do próprio usuário:
 *
 * 1. netlify/functions/scheduled-sync-background.js e
 *    netlify/functions/prospeccao-sync-osm.js — jobs por cron, sem usuário
 *    logado disponível.
 * 2. netlify/functions/funcionarios-convidar.js — PRECISA da service role
 *    pra criar a conta no Supabase Auth (a API de convite/criação de
 *    usuário exige privilégio de admin, não existe outro jeito). Mesmo
 *    sendo chamada pelo frontend, é segura porque a própria Function
 *    verifica — usando o token normal do chamador, ANTES de tocar na
 *    service role key — que quem está pedindo o convite já é admin. Ver
 *    o comentário no topo daquele arquivo.
 * 3. netlify/functions/funcionarios-conta.js — mesmo caso do item acima,
 *    pra redefinir senha e excluir conta (também exige privilégio de admin
 *    na API do GoTrue). Mesma checagem de admin antes de usar a chave.
 *
 * Fora desses casos: NUNCA usar esta chave em código que atende
 * requisição do frontend — RLS deixa de valer, e a Function vira a única
 * barreira (exatamente o que o projeto evita).
 */
const { SUPABASE_URL } = require('./supabase');

function getServiceRoleKey() {
  return process.env.SUPABASE_SERVICE_ROLE_KEY || null;
}

module.exports = { getServiceRoleKey, SUPABASE_URL };
