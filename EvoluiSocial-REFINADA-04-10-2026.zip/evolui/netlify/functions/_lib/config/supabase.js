/**
 * Mesma URL e chave PÚBLICA (anon/publishable) já usadas em todo o projeto
 * (assets/js/admin.1b9240a4b5.js, assets/js/site.bdacb7b1a8.js). Não é um
 * segredo — é a chave feita pra ser pública.
 *
 * CORREÇÃO (achado nesta auditoria): este comentário afirmava "nenhuma
 * chave privada/service role é usada em nenhuma Function deste projeto" —
 * isso deixou de ser verdade quando funcionarios-convidar.js/
 * funcionarios-conta.js e os dois jobs agendados passaram a precisar da
 * service role key (ver _lib/config/supabaseServiceRole.js pra saber onde,
 * por quê, e a checagem de admin que precede cada uso). O comentário errado
 * não muda nada em produção — é só documentação desatualizada — mas uma
 * afirmação de segurança incorreta é exatamente o tipo de coisa que faz
 * uma auditoria futura pular um arquivo que merecia atenção. Corrigido
 * aqui; a chave privada em si nunca fica neste arquivo nem em nenhum outro
 * do repositório — vem sempre de process.env.SUPABASE_SERVICE_ROLE_KEY.
 */
const SUPABASE_URL = 'https://aligftypgtzlymmditeo.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_lLKYguXwi6isaw1C4X5uiA_25-MT7ym';

module.exports = { SUPABASE_URL, SUPABASE_ANON_KEY };
