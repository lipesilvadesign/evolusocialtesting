const crypto = require('crypto');

const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
const SCOPE = 'https://www.googleapis.com/auth/analytics.readonly';

// Cache em memória do processo — só vive enquanto a Function estiver "quente"
// (Netlify reaproveita a mesma instância entre chamadas próximas). Isto é
// só uma otimização de quota (evita gerar um token novo a cada request);
// se a instância for reciclada, o próximo request simplesmente gera outro.
let cachedToken = null; // { accessToken, expiresAt }

function base64url(input) {
  return Buffer.from(input)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

/**
 * Monta e assina o JWT do fluxo "Service Account" do Google (RFC 7523),
 * usando só `crypto` (RSA-SHA256) — nenhuma lib de terceiros.
 */
function buildSignedJwt(serviceAccount) {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const claims = {
    iss: serviceAccount.client_email,
    scope: SCOPE,
    aud: TOKEN_ENDPOINT,
    iat: now,
    exp: now + 3600,
  };
  const unsigned = `${base64url(JSON.stringify(header))}.${base64url(JSON.stringify(claims))}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  signer.end();
  const signature = signer
    .sign(serviceAccount.private_key)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
  return `${unsigned}.${signature}`;
}

/**
 * @param {{ client_email: string, private_key: string }} serviceAccount
 * @returns {Promise<string>} access token válido
 */
async function getAccessToken(serviceAccount) {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 30_000) {
    return cachedToken.accessToken;
  }

  const jwt = buildSignedJwt(serviceAccount);
  const res = await fetch(TOKEN_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion: jwt,
    }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    const err = new Error('Falha ao autenticar com o Google (token OAuth2).');
    err.code = res.status === 401 || res.status === 403 ? 'AUTH_ERROR' : 'API_UNAVAILABLE';
    err.detail = text.slice(0, 300); // nunca inclui a chave privada — só a resposta de erro do Google
    throw err;
  }

  const data = await res.json();
  cachedToken = {
    accessToken: data.access_token,
    expiresAt: Date.now() + (data.expires_in || 3600) * 1000,
  };
  return cachedToken.accessToken;
}

module.exports = { getAccessToken };
