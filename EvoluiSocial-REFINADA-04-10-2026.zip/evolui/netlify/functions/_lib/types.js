/**
 * Contratos de domínio da central administrativa Felipe Branding.
 *
 * Este projeto é JavaScript puro (sem TypeScript, sem bundler de build).
 * Para não espalhar objetos anônimos pela aplicação, os formatos de dados
 * usados entre Functions, Services e o painel (/painel) ficam documentados
 * aqui via JSDoc @typedef. Isso dá autocomplete/checagem em editores que
 * entendem JSDoc, sem exigir um passo de compilação novo no projeto.
 *
 * Nenhum destes tipos é um contrato "fechado" — são a forma esperada dos
 * dados. Ao trocar um mock por uma integração real (Google Analytics, IA),
 * o formato retornado deve continuar batendo com o typedef correspondente.
 */

/**
 * @typedef {Object} AdminUser
 * @property {string} id
 * @property {string} email
 * @property {string|null} nome
 * @property {'administrator'|'editor'|'analyst'|'viewer'} role
 */

/**
 * @typedef {'rascunho'|'publicado'|'arquivado'} ContentStatus
 */

/**
 * @typedef {Object} SeoBlock
 * @property {string} [titulo]
 * @property {string} [descricao]
 * @property {string} [ogImagem] - base64 ou URL, mesmo padrão de imagem já usado no projeto
 */

/**
 * @typedef {Object} Post
 * @property {string} id
 * @property {string} titulo
 * @property {string} slug
 * @property {string} [descricao]
 * @property {string} [imagem] - base64, mesmo padrão do restante do site (sem bucket de Storage)
 * @property {string} [conteudo]
 * @property {ContentStatus} status
 * @property {string|null} [data_publicacao] - ISO date string
 * @property {SeoBlock} [seo]
 * @property {string} [criado_por]
 * @property {string} [created_at]
 * @property {string} [updated_at]
 */

/**
 * @typedef {Post} Page  - mesma forma de Post; tabela separada (admin_pages)
 */

/**
 * @typedef {Object} ContentArrayItem - item de Projetos (portfolio) ou Serviços (services)
 * @property {string} id
 * @property {string} title
 * @property {string} [desc]
 * @property {string} [image]
 * @property {string} [category]      - só Projetos
 * @property {string} [categoryLabel] - só Projetos
 * @property {string} [tags]          - só Serviços
 * @property {string} [icon]          - só Serviços
 * @property {string} [slug]
 * @property {ContentStatus} [status]
 * @property {string} [dataPublicacao]
 * @property {SeoBlock} [seo]
 */

/**
 * @typedef {Object} SiteSettings
 * @property {Object} informacoesGerais
 * @property {string} informacoesGerais.nomeMarca
 * @property {string} informacoesGerais.descricao
 * @property {string} [informacoesGerais.logo]     - base64
 * @property {string} [informacoesGerais.favicon]  - base64
 * @property {Object} contato
 * @property {string} contato.whatsapp
 * @property {string} contato.telefone
 * @property {string} contato.email
 * @property {string} contato.localizacao
 * @property {Object} contato.redesSociais
 * @property {string} [contato.redesSociais.instagram]
 * @property {string} [contato.redesSociais.linkedin]
 * @property {string} [contato.redesSociais.behance]
 * @property {Object} seo
 * @property {string} seo.tituloPadrao
 * @property {string} seo.descricaoPadrao
 * @property {string} [seo.ogImagemPadrao]
 * @property {boolean} seo.indexavel
 * @property {Object} analytics
 * @property {string} [analytics.ga4PropertyId] - não é secreto (é o mesmo tipo de ID já público no gtag.js)
 * @property {'nao_conectado'|'conectado'} analytics.status
 * @property {string|null} analytics.ultimaSincronizacao
 * @property {Object} integracoes
 * @property {boolean} integracoes.googleAnalytics
 * @property {boolean} integracoes.searchConsole
 * @property {boolean} integracoes.googleBusinessProfile
 * @property {boolean} integracoes.ia
 */

/**
 * @typedef {Object} AuditLogEntry
 * @property {string} actorId
 * @property {'create'|'update'|'delete'|'publish'|'unpublish'|'settings_change'|'permission_change'} action
 * @property {string} targetType
 * @property {string} [targetId]
 * @property {object} [metadata]
 */

/**
 * @typedef {Object} ContentItem
 * @property {string} sectionId    - ex: "hero", "about", "services"
 * @property {string} sectionLabel - rótulo legível, ex: "Hero (abertura)"
 * @property {string} updatedAt    - ISO date string
 */

/**
 * @typedef {Object} AnalyticsMetric
 * @property {string} id
 * @property {string} label
 * @property {number} value
 * @property {number} [previousValue]
 * @property {'number'|'percent'|'duration'} format
 */

/**
 * @typedef {Object} AnalyticsOverview
 * @property {AnalyticsMetric[]} metrics
 * @property {string} rangeLabel - ex: "Últimos 7 dias"
 * @property {boolean} isMock    - false a partir desta etapa (integração real com GA4)
 * @property {boolean} isEmpty   - true quando o GA4 respondeu sem nenhuma linha pro período
 */

/**
 * @typedef {Object} AnalyticsEvent
 * @property {string} id
 * @property {string} name
 * @property {number} count
 * @property {string|null} occurredAt - ISO date string; null quando o dado é agregado (não pontual)
 */

/**
 * @typedef {Object} AnalyticsPage
 * @property {string} path
 * @property {string} [title]
 * @property {number} views
 * @property {number} activeUsers
 */

/**
 * @typedef {Object} AnalyticsTrafficSource
 * @property {string} channel - ex: "Organic Search", "Direct", "Referral"
 * @property {number} sessions
 * @property {number} activeUsers
 */

/**
 * @typedef {Object} AnalyticsDevice
 * @property {string} category - "desktop" | "mobile" | "tablet" (valor cru do GA4)
 * @property {number} activeUsers
 * @property {number} sessions
 */

/**
 * @typedef {Object} AnalyticsRealtime
 * @property {number} activeUsers - total agora, não histórico
 * @property {Array<{country:string, activeUsers:number}>} byCountry
 * @property {string} generatedAt - ISO date string de quando esta leitura foi feita
 * @property {boolean} isEmpty
 */

/**
 * @typedef {Object} AnalyticsDateRange
 * @property {'hoje'|'ontem'|'7d'|'28d'|'30d'|'90d'|'personalizado'} key
 * @property {string} [start] - AAAA-MM-DD, só quando key === 'personalizado'
 * @property {string} [end]   - AAAA-MM-DD, só quando key === 'personalizado'
 */

/**
 * @typedef {'positive'|'attention'|'opportunity'|'trend'|'alert'|'recommendation'} InsightType
 */

/**
 * @typedef {'baixa'|'media'|'alta'} InsightSeverity
 */

/**
 * @typedef {'baixa'|'media'|'alta'} InsightConfidence - indicador interno da robustez do insight; NÃO é probabilidade científica
 */

/**
 * @typedef {Object} InsightComparison
 * @property {number|null} previousValue
 * @property {number|null} deltaAbs
 * @property {number|null} deltaPct
 * @property {string} rangeLabel - ex: "Últimos 7 dias" (o que foi comparado)
 */

/**
 * @typedef {Object} StructuredInsight
 * @property {string} id
 * @property {InsightType} type
 * @property {string} title
 * @property {string} description - sempre em linguagem de correlação/observação, nunca causal
 * @property {string} metric - chave da métrica de origem (ex: "activeUsers", "pages.views")
 * @property {number} value
 * @property {InsightComparison} comparison
 * @property {InsightSeverity|null} severity - null para insights não-negativos (positive/opportunity/trend/recommendation)
 * @property {InsightConfidence} confidence
 * @property {string} generatedAt - ISO date string
 * @property {Object} [evidence] - dados extras de rastreabilidade (ex: path da página, nome do evento)
 */

/**
 * @typedef {Object} AnalyticsInsight
 * @property {string} id
 * @property {'info'|'positive'|'warning'} tone
 * @property {string} title
 * @property {string} description
 */

/**
 * @typedef {Object} AnalyticsRecommendation
 * @property {string} id
 * @property {string} title
 * @property {string} description
 * @property {'baixo'|'médio'|'alto'} impact
 */

/**
 * @typedef {'forte'|'moderada'|'limitada'} EvidenceStrength - linguagem qualitativa, nunca percentual estatístico
 */

/**
 * @typedef {Object} AiPoint
 * @property {string} text
 * @property {EvidenceStrength} evidenceStrength
 * @property {string|null} relatedMetric
 */

/**
 * @typedef {Object} AiRecommendation
 * @property {string} title
 * @property {string} explanation
 * @property {string} evidence
 * @property {string} suggestedAction
 * @property {'baixa'|'media'|'alta'} priority
 */

/**
 * @typedef {Object} AiAnalysis
 * @property {string} summary
 * @property {boolean} insufficientData
 * @property {AiPoint[]} positivePoints
 * @property {AiPoint[]} attentionPoints
 * @property {AiPoint[]} opportunities
 * @property {AiRecommendation[]} recommendations
 * @property {string[]} questionsToInvestigate
 * @property {Object} meta
 * @property {string} meta.generatedAt
 * @property {string} meta.promptVersion
 * @property {string} meta.model
 * @property {boolean} meta.cacheHit
 * @property {boolean} meta.skippedAiCall
 */

/**
 * @typedef {Object} AiHistoryRecord - estrutura preparada, ainda não persistida (ver aiHistoryService.js)
 * @property {string} rangeLabel
 * @property {string} promptVersion
 * @property {string} model
 * @property {string[]} metricsUsed
 * @property {number} recommendationCount
 * @property {boolean} cacheHit
 */

/**
 * @typedef {Object} Anomaly
 * @property {string} metric
 * @property {string} metricLabel
 * @property {string} date
 * @property {number} value
 * @property {number} baselineMean
 * @property {number} baselineStdDev
 * @property {number} zScore
 * @property {'alta'|'baixa'} direction
 * @property {'alta'|'media'} severity
 * @property {number} baselineDays
 */

/**
 * @typedef {Object} Correlation
 * @property {string} type
 * @property {string} title
 * @property {string} description
 * @property {Object} evidence
 * @property {EvidenceStrength} strength
 */

/**
 * @typedef {Object} HealthSubScore
 * @property {string} key
 * @property {string} label
 * @property {number|null} score - 0-100, null se não avaliável no período
 * @property {string} explanation
 * @property {Array<{label:string, value:string|number}>} factors
 * @property {boolean} [isProxy] - true quando a nota é uma aproximação heurística, não uma métrica real do GA4
 */

/**
 * @typedef {Object} HealthScore
 * @property {number|null} overall
 * @property {HealthSubScore[]} subScores
 */

/**
 * @typedef {Object} Opportunity
 * @property {string|null} id - id estável (hash), presente depois de persistido no histórico
 * @property {string} title
 * @property {string} description
 * @property {'alto'|'medio'|'baixo'} impact
 * @property {'alto'|'medio'|'baixo'} effort
 * @property {string} quadrant - ex: "Ganho rápido", "Projeto estratégico"
 * @property {number} priorityScore
 * @property {Object} evidence
 * @property {'insight'|'anomalia'|'health-score'} sourceType
 * @property {'novo'|'em_andamento'|'concluido'|'descartado'} status
 */

/**
 * @typedef {Object} AdvancedIntelligence
 * @property {string} rangeLabel
 * @property {number} timeSeriesDays
 * @property {Array} deterministicInsights
 * @property {Object} historicalAverages
 * @property {Anomaly[]} anomalies
 * @property {Correlation[]} correlations
 * @property {HealthScore} healthScore
 * @property {Opportunity[]} opportunities
 */

module.exports = {};
