function mean(values) {
  if (!values.length) return 0;
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

function standardDeviation(values) {
  if (values.length < 2) return 0;
  const m = mean(values);
  const variance = values.reduce((sum, v) => sum + (v - m) ** 2, 0) / values.length;
  return Math.sqrt(variance);
}

/** z-score: quantos desvios-padrão o valor está da média. stddev=0 → 0 (evita divisão por zero). */
function zScore(value, baselineMean, baselineStdDev) {
  if (baselineStdDev === 0) return 0;
  return (value - baselineMean) / baselineStdDev;
}

function round1(v) {
  return Math.round(v * 10) / 10;
}

module.exports = { mean, standardDeviation, zScore, round1 };
