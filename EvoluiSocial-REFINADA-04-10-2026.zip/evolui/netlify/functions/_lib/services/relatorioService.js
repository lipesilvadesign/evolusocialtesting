const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

function filtroData(coluna, inicio, fim) {
  const partes = [`${coluna}=lte.${encodeURIComponent(fim)}`];
  if (inicio) partes.push(`${coluna}=gte.${encodeURIComponent(inicio)}`);
  return partes.join('&');
}

/**
 * Todo envio de e-mail feito no período (um registro por clique em "Enviar
 * e-mail para selecionados" — cada um já guarda o resultado lead por lead
 * em `progresso`, então isto sozinho já é o histórico completo de envios).
 * @param {string} token
 * @param {{ inicio: string|null, fim: string }} periodo
 * @returns {Promise<object[]>}
 */
async function buscarEnvios(token, { inicio, fim }) {
  const filtro = filtroData('created_at', inicio, fim);
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_prospeccao_envios?select=*&${filtro}&order=created_at.desc`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao consultar envios (${res.status}).`);
  return res.json();
}

/**
 * Toda busca de empresas feita no período (um registro por clique em
 * "Atualizar").
 * @param {string} token
 * @param {{ inicio: string|null, fim: string }} periodo
 * @returns {Promise<object[]>}
 */
async function buscarBuscas(token, { inicio, fim }) {
  const filtro = filtroData('created_at', inicio, fim);
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_prospeccao_buscas?select=*&${filtro}&order=created_at.desc`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao consultar buscas (${res.status}).`);
  return res.json();
}

/**
 * Leads criados no período, agrupados por fonte (manual, auto, planilha
 * original) — contagem simples, feita em JS a partir da lista (a tabela é
 * pequena o suficiente pra não precisar de agregação no banco).
 * @param {string} token
 * @param {{ inicio: string|null, fim: string }} periodo
 * @returns {Promise<{ total: number, porFonte: Record<string, number> }>}
 */
async function contarLeadsPorPeriodo(token, { inicio, fim }) {
  const filtro = filtroData('created_at', inicio, fim);
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_prospeccao_leads?select=fonte,created_at&${filtro}`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao consultar leads do período (${res.status}).`);
  const rows = await res.json();
  const porFonte = {};
  rows.forEach((r) => {
    const chave = r.fonte || 'manual';
    porFonte[chave] = (porFonte[chave] || 0) + 1;
  });
  return { total: rows.length, porFonte };
}

/**
 * Atividades de prospecção (todas os leads) no período — base real para os
 * indicadores do Dashboard (mensagens enviadas via WhatsApp, respostas
 * registradas, mudanças de status etc.). Cada linha já existe hoje em
 * admin_prospeccao_atividades; isto só lê o período pedido, sem inventar
 * nenhum dado — se não houver atividade no período, o array volta vazio e a
 * interface deve mostrar "sem dados", nunca forjar um número.
 * @param {string} token
 * @param {{ inicio: string|null, fim: string }} periodo
 * @returns {Promise<object[]>}
 */
async function buscarAtividadesPeriodo(token, { inicio, fim }) {
  const filtro = filtroData('data', inicio, fim);
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_prospeccao_atividades?select=id,lead_id,tipo,data,status_anterior,status_novo&${filtro}&order=data.desc`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao consultar atividades (${res.status}).`);
  return res.json();
}

/**
 * Snapshot atual (não filtrado por período) de todos os leads, só com as
 * colunas necessárias para o funil/estados do Dashboard — leve o bastante
 * pra não repetir o custo da listagem completa (`GET /prospeccao`) que a
 * tela de Prospecção já usa.
 * @param {string} token
 * @returns {Promise<object[]>}
 */
async function listarStatusAtual(token) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_prospeccao_leads?select=id,empresa,status,created_at,updated_at,responsavel_id,convertido_cliente_em&arquivado_em=is.null`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao consultar status dos leads (${res.status}).`);
  return res.json();
}

module.exports = { buscarEnvios, buscarBuscas, contarLeadsPorPeriodo, buscarAtividadesPeriodo, listarStatusAtual };
