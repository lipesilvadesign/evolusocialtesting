/**
 * Analytics Service.
 *
 * Fluxo pedido: Frontend → Netlify Function → Analytics Service →
 * Google Analytics Data API → resposta normalizada → Frontend. Este
 * arquivo é o "Analytics Service" — nenhuma Function HTTP chama a
 * integração (../integrations/googleAnalytics.js) diretamente, sempre
 * passa por aqui. Este arquivo também é quem monta o Domain Model (ver
 * ../types.js) a partir do formato intermediário devolvido pelo Adapter
 * (../adapters/gaAdapter.js) — quem consome isto (Functions/UI) nunca vê
 * o JSON bruto do Google.
 *
 * Etapa "Motor de Insights": este arquivo ganhou getInsightsSnapshot(),
 * que busca dados do período ATUAL e do período ANTERIOR já casados por
 * chave (página por path, evento por nome) — é o insumo bruto que o
 * analyticsNormalizer (../analyticsNormalizer.js) e depois o
 * insightsEngine (../insightsEngine.js) transformam em insights. Este
 * service não sabe o que é um "insight" — só busca e monta dados.
 */

const ga = require('../integrations/googleAnalytics');
const { parseReport, metricByName, dimByName } = require('../adapters/gaAdapter');
const { resolveDateRange, previousDateRange } = require('../dateRange');
const { withCache } = require('../cache/memoryCache');

const HISTORICAL_TTL_MS = 2 * 60 * 1000; // 2min — reduz chamadas repetidas sem deixar o dado velho
const REALTIME_TTL_MS = 15 * 1000; // realtime pede frescor bem maior

function metricFormat(name) {
  if (name === 'engagementRate' || name === 'bounceRate') return 'percent';
  if (name === 'averageSessionDuration') return 'duration';
  return 'number';
}

function toMetricValue(name, raw) {
  if (metricFormat(name) === 'percent') return Math.round(raw * 1000) / 10; // fração -> %
  if (metricFormat(name) === 'duration') return Math.round(raw);
  return Math.round(raw);
}

const OVERVIEW_METRIC_DEFS = [
  { name: 'activeUsers', label: 'Usuários' },
  { name: 'sessions', label: 'Sessões' },
  { name: 'screenPageViews', label: 'Visualizações' },
  { name: 'engagementRate', label: 'Taxa de engajamento' },
  { name: 'averageSessionDuration', label: 'Duração média' },
];

// ---------------------------------------------------------------------
// Helpers internos — recebem um dateRange já resolvido (não um rangeQuery
// de UI) e não usam cache. São reaproveitados tanto pelas funções públicas
// (que resolvem o range da UI e cacheiam) quanto por getInsightsSnapshot
// (que precisa buscar dois períodos — atual e anterior — para comparar).
// ---------------------------------------------------------------------

async function _overviewFor(dateRange) {
  const raw = await ga.runReport({
    dateRanges: [dateRange],
    metrics: OVERVIEW_METRIC_DEFS.map((m) => ({ name: m.name })),
  });
  const parsed = parseReport(raw);
  const row = parsed.rows[0];
  const metrics = {};
  OVERVIEW_METRIC_DEFS.forEach((def) => {
    metrics[def.name] = row ? toMetricValue(def.name, metricByName(parsed, row, def.name)) : 0;
  });
  return { metrics, isEmpty: !row };
}

async function _topPagesFor(dateRange, limit = 10) {
  const raw = await ga.runReport({
    dateRanges: [dateRange],
    dimensions: [{ name: 'pagePath' }, { name: 'pageTitle' }],
    metrics: [{ name: 'screenPageViews' }, { name: 'activeUsers' }, { name: 'eventCount' }],
    orderBys: [{ metric: { metricName: 'screenPageViews' }, desc: true }],
    limit,
  });
  const parsed = parseReport(raw);
  return parsed.rows.map((row) => ({
    path: dimByName(parsed, row, 'pagePath'),
    title: dimByName(parsed, row, 'pageTitle'),
    views: Math.round(metricByName(parsed, row, 'screenPageViews')),
    activeUsers: Math.round(metricByName(parsed, row, 'activeUsers')),
    eventCount: Math.round(metricByName(parsed, row, 'eventCount')),
  }));
}

async function _eventsFor(dateRange, limit = 10) {
  const raw = await ga.runReport({
    dateRanges: [dateRange],
    dimensions: [{ name: 'eventName' }],
    metrics: [{ name: 'eventCount' }],
    orderBys: [{ metric: { metricName: 'eventCount' }, desc: true }],
    limit,
  });
  const parsed = parseReport(raw);
  return parsed.rows.map((row, i) => ({
    id: `${dimByName(parsed, row, 'eventName')}-${i}`,
    name: dimByName(parsed, row, 'eventName'),
    count: Math.round(metricByName(parsed, row, 'eventCount')),
    occurredAt: null,
  }));
}

async function _trafficSourcesFor(dateRange, limit = 10) {
  const raw = await ga.runReport({
    dateRanges: [dateRange],
    dimensions: [{ name: 'sessionDefaultChannelGroup' }],
    metrics: [{ name: 'sessions' }, { name: 'activeUsers' }],
    orderBys: [{ metric: { metricName: 'sessions' }, desc: true }],
    limit,
  });
  const parsed = parseReport(raw);
  return parsed.rows.map((row) => ({
    channel: dimByName(parsed, row, 'sessionDefaultChannelGroup') || '(não definido)',
    sessions: Math.round(metricByName(parsed, row, 'sessions')),
    activeUsers: Math.round(metricByName(parsed, row, 'activeUsers')),
  }));
}

async function _devicesFor(dateRange) {
  const raw = await ga.runReport({
    dateRanges: [dateRange],
    dimensions: [{ name: 'deviceCategory' }],
    metrics: [{ name: 'activeUsers' }, { name: 'sessions' }],
    orderBys: [{ metric: { metricName: 'activeUsers' }, desc: true }],
  });
  const parsed = parseReport(raw);
  return parsed.rows.map((row) => ({
    category: dimByName(parsed, row, 'deviceCategory'),
    activeUsers: Math.round(metricByName(parsed, row, 'activeUsers')),
    sessions: Math.round(metricByName(parsed, row, 'sessions')),
  }));
}

// ---------------------------------------------------------------------
// Funções públicas usadas pelo dashboard (Function analytics-ga.js) —
// resolvem o range vindo da UI e cacheiam.
// ---------------------------------------------------------------------

/** @returns {Promise<import('../types').AnalyticsOverview>} */
async function getOverview(rangeQuery) {
  const { dateRange, label, key } = resolveDateRange(rangeQuery);
  return withCache(`overview:${key}:${rangeQuery.start || ''}:${rangeQuery.end || ''}`, HISTORICAL_TTL_MS, async () => {
    const current = await _overviewFor(dateRange);
    let previous = null;
    try {
      previous = await _overviewFor(previousDateRange(dateRange));
    } catch (err) {
      previous = null; // comparação é um extra — se falhar, segue sem ela
    }
    const metrics = OVERVIEW_METRIC_DEFS.map((def) => ({
      id: def.name,
      label: def.label,
      value: current.metrics[def.name],
      previousValue: previous ? previous.metrics[def.name] : undefined,
      format: metricFormat(def.name),
    }));
    return { metrics, rangeLabel: label, isMock: false, isEmpty: current.isEmpty };
  });
}

/** @returns {Promise<import('../types').AnalyticsTrafficSource[]>} */
async function getTrafficSources(rangeQuery) {
  const { dateRange, key } = resolveDateRange(rangeQuery);
  return withCache(`traffic:${key}`, HISTORICAL_TTL_MS, () => _trafficSourcesFor(dateRange));
}

/** @returns {Promise<import('../types').AnalyticsPage[]>} */
async function getTopPages(rangeQuery) {
  const { dateRange, key } = resolveDateRange(rangeQuery);
  return withCache(`pages:${key}`, HISTORICAL_TTL_MS, () => _topPagesFor(dateRange));
}

/** @returns {Promise<import('../types').AnalyticsEvent[]>} */
async function getEvents(rangeQuery) {
  const { dateRange, key } = resolveDateRange(rangeQuery);
  return withCache(`events:${key}`, HISTORICAL_TTL_MS, () => _eventsFor(dateRange));
}

/** @returns {Promise<import('../types').AnalyticsDevice[]>} */
async function getDevices(rangeQuery) {
  const { dateRange, key } = resolveDateRange(rangeQuery);
  return withCache(`devices:${key}`, HISTORICAL_TTL_MS, () => _devicesFor(dateRange));
}

/** @returns {Promise<Array<{country:string, activeUsers:number}>>} */
async function getLocations(rangeQuery) {
  const { dateRange, key } = resolveDateRange(rangeQuery);
  return withCache(`locations:${key}`, HISTORICAL_TTL_MS, async () => {
    const raw = await ga.runReport({
      dateRanges: [dateRange],
      dimensions: [{ name: 'country' }],
      metrics: [{ name: 'activeUsers' }],
      orderBys: [{ metric: { metricName: 'activeUsers' }, desc: true }],
      limit: 10,
    });
    const parsed = parseReport(raw);
    return parsed.rows.map((row) => ({
      country: dimByName(parsed, row, 'country') || '(desconhecido)',
      activeUsers: Math.round(metricByName(parsed, row, 'activeUsers')),
    }));
  });
}

/** @returns {Promise<import('../types').AnalyticsRealtime>} */
async function getRealtime() {
  return withCache('realtime', REALTIME_TTL_MS, async () => {
    const raw = await ga.runRealtimeReport({
      dimensions: [{ name: 'country' }],
      metrics: [{ name: 'activeUsers' }],
      orderBys: [{ metric: { metricName: 'activeUsers' }, desc: true }],
      limit: 10,
    });
    const parsed = parseReport(raw);
    const byCountry = parsed.rows.map((row) => ({
      country: dimByName(parsed, row, 'country') || '(desconhecido)',
      activeUsers: Math.round(metricByName(parsed, row, 'activeUsers')),
    }));
    const activeUsers = byCountry.reduce((sum, r) => sum + r.activeUsers, 0);
    return { activeUsers, byCountry, generatedAt: new Date().toISOString(), isEmpty: parsed.rows.length === 0 };
  });
}

async function testConnection() {
  return ga.testConnection();
}

/**
 * Insumo bruto pro motor de insights: período atual + período anterior,
 * para overview/páginas/eventos/fontes de tráfego/dispositivos — tudo já
 * buscado, nada "casado"/comparado ainda (isso é trabalho do
 * analyticsNormalizer). Este service só sabe buscar dados, não interpreta.
 */
async function getInsightsSnapshot(rangeQuery) {
  const { dateRange, label, key } = resolveDateRange(rangeQuery);
  const prevRange = previousDateRange(dateRange);

  return withCache(`insights-snapshot:${key}:${rangeQuery.start || ''}:${rangeQuery.end || ''}`, HISTORICAL_TTL_MS, async () => {
    const [overviewCur, overviewPrev, pagesCur, pagesPrev, eventsCur, eventsPrev, trafficCur, trafficPrev, devicesCur] =
      await Promise.all([
        _overviewFor(dateRange),
        _overviewFor(prevRange).catch(() => null),
        _topPagesFor(dateRange, 15),
        _topPagesFor(prevRange, 15).catch(() => []),
        _eventsFor(dateRange, 15),
        _eventsFor(prevRange, 15).catch(() => []),
        _trafficSourcesFor(dateRange, 15),
        _trafficSourcesFor(prevRange, 15).catch(() => []),
        _devicesFor(dateRange).catch(() => []),
      ]);

    return {
      rangeLabel: label,
      dateRange,
      previousDateRange: prevRange,
      overview: { current: overviewCur, previous: overviewPrev },
      pages: { current: pagesCur, previous: pagesPrev },
      events: { current: eventsCur, previous: eventsPrev },
      trafficSources: { current: trafficCur, previous: trafficPrev },
      devices: { current: devicesCur },
    };
  });
}

/**
 * Etapa "Inteligência Avançada": série diária dos últimos N dias (dimensão
 * `date` do GA4) — insumo pra médias de 7/30/90 dias e pra detecção de
 * anomalias (que precisam de uma linha de base histórica, não só do
 * período atual vs. anterior). Método novo, período fixo (não depende do
 * range escolhido na UI) — não mexe em nada do que já existia.
 * @param {number} days
 * @returns {Promise<Array<{date:string, activeUsers:number, sessions:number, screenPageViews:number, engagementRate:number, averageSessionDuration:number}>>}
 */
async function getDailyTimeSeries(days = 90) {
  return withCache(`timeseries:${days}`, HISTORICAL_TTL_MS, async () => {
    const raw = await ga.runReport({
      dateRanges: [{ startDate: `${days}daysAgo`, endDate: 'today' }],
      dimensions: [{ name: 'date' }],
      metrics: OVERVIEW_METRIC_DEFS.map((m) => ({ name: m.name })),
      orderBys: [{ dimension: { dimensionName: 'date' } }],
      limit: days + 5,
    });
    const parsed = parseReport(raw);
    return parsed.rows.map((row) => {
      const entry = { date: dimByName(parsed, row, 'date') };
      OVERVIEW_METRIC_DEFS.forEach((def) => {
        entry[def.name] = toMetricValue(def.name, metricByName(parsed, row, def.name));
      });
      return entry;
    });
  });
}

module.exports = {
  getOverview,
  getTrafficSources,
  getTopPages,
  getEvents,
  getDevices,
  getLocations,
  getRealtime,
  testConnection,
  getInsightsSnapshot,
  getDailyTimeSeries,
};
