/**
 * AI Insights Service.
 *
 * Orquestra o resto do fluxo depois do motor determinístico:
 * NormalizedSnapshot + StructuredInsight[] → AI Context Builder → cache →
 * AI Provider → validação de schema → histórico (stub) → resposta final.
 *
 * Este é o único lugar que decide QUANDO chamar a IA de verdade (cache /
 * dados insuficientes) — nem a Function HTTP nem o AI Provider tomam essa
 * decisão sozinhos.
 */

const crypto = require('crypto');
const { buildAiContext, hasEnoughDataForAi } = require('../aiContextBuilder');
const aiProvider = require('../integrations/aiProvider');
const { validateAiResponse } = require('../aiResponseSchema');
const { withCache, invalidate } = require('../cache/memoryCache');
const aiHistoryService = require('./aiHistoryService');

// Sobe a cada mudança de conteúdo/regra do prompt (SYSTEM_PROMPT ou
// TOOL_INPUT_SCHEMA em aiProvider.js) — entra na chave de cache e no
// histórico, pra nunca misturar análises geradas por prompts diferentes.
const PROMPT_VERSION = 'v1';

// IA custa dinheiro por chamada — cache mais longo que o de analytics puro
// (2min). "Atualização manual" (bypass) é o parâmetro refresh=true na Function.
const AI_CACHE_TTL_MS = 60 * 60 * 1000; // 1 hora

function hashMetrics(aiContext) {
  const compact = aiContext.metrics.map((m) => `${m.key}:${m.value}:${m.deltaPct}`).join('|');
  const advanced = aiContext.advancedIntelligence
    ? `|health:${aiContext.advancedIntelligence.healthScore.overall}|opp:${aiContext.advancedIntelligence.topOpportunities.length}`
    : '';
  return crypto.createHash('sha256').update(compact + advanced).digest('hex').slice(0, 12);
}

function insufficientDataResponse(rangeLabel) {
  return {
    summary: 'Não há dados suficientes para concluir. O período selecionado tem tráfego muito baixo para uma análise confiável.',
    insufficientData: true,
    positivePoints: [],
    attentionPoints: [],
    opportunities: [],
    recommendations: [],
    questionsToInvestigate: [],
    contextMetrics: [],
    meta: { rangeLabel, cacheHit: false, generatedAt: new Date().toISOString(), skippedAiCall: true },
  };
}

/**
 * @param {object} normalizedSnapshot
 * @param {Array} deterministicInsights
 * @param {{ range?: string, start?: string, end?: string, rangeKey: string }} rangeInfo
 * @param {{ refresh?: boolean }} [opts]
 * @param {object} [advancedIntelligence] - saída de intelligenceService.computeAdvancedIntelligence() (etapa "Inteligência Avançada"); opcional
 * @param {string} [token] - token de sessão do usuário, usado só pra persistir o Controle de IA (etapa "Operação, Automação e Escala"); opcional para não quebrar chamadas antigas sem token
 * @returns {Promise<object>}
 */
async function getAiAnalysis(normalizedSnapshot, deterministicInsights, rangeInfo, opts = {}, advancedIntelligence, token) {
  if (!hasEnoughDataForAi(normalizedSnapshot)) {
    return insufficientDataResponse(normalizedSnapshot.rangeLabel);
  }

  const aiContext = buildAiContext(normalizedSnapshot, deterministicInsights, advancedIntelligence);
  const metricsHash = hashMetrics(aiContext);
  const cacheKey = `ai-analysis:${PROMPT_VERSION}:${rangeInfo.rangeKey}:${metricsHash}`;

  if (opts.refresh) invalidate(cacheKey);

  let cacheHit = true;
  const result = await withCache(cacheKey, AI_CACHE_TTL_MS, runFresh);

  return {
    ...result,
    contextMetrics: aiContext.metrics, // nível "DADO" puro — mesmos números, sem interpretação nenhuma
    meta: { ...result.meta, cacheHit, rangeLabel: normalizedSnapshot.rangeLabel },
  };

  async function runFresh() {
    cacheHit = false;
    const model = process.env.AI_MODEL || aiProvider.DEFAULT_MODEL;
    const { result: raw, usage } = await aiProvider.generateAnalysis(aiContext);
    const validated = validateAiResponse(raw);

    if (token) {
      await aiHistoryService.record(token, {
        rangeLabel: normalizedSnapshot.rangeLabel,
        promptVersion: PROMPT_VERSION,
        model,
        metricsUsed: aiContext.metrics.map((m) => m.key),
        recommendationCount: validated.recommendations.length,
        cacheHit: false,
        tokensInput: usage.tokensInput,
        tokensOutput: usage.tokensOutput,
      });
    }

    return {
      ...validated,
      meta: {
        generatedAt: new Date().toISOString(),
        promptVersion: PROMPT_VERSION,
        model,
        skippedAiCall: false,
      },
    };
  }
}

module.exports = { getAiAnalysis, PROMPT_VERSION, AI_CACHE_TTL_MS };
