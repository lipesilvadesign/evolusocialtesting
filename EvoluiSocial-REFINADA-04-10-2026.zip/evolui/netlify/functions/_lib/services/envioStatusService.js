const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_prospeccao_envios';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {{ id: string, totalSelecionado: number, criadoPor: string }} dados
 */
async function iniciar(token, dados) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=minimal' }),
    body: JSON.stringify({
      id: dados.id,
      total_selecionado: dados.totalSelecionado,
      status: 'em_andamento',
      progresso: [],
      criado_por: dados.criadoPor,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao registrar início do envio (${res.status}): ${await res.text()}`);
}

/**
 * Acrescenta uma entrada ao array de progresso (um item por lead processado).
 * @param {string} token
 * @param {string} id
 * @param {object[]} progressoAtual array já lido antes (pra fazer append sem sobrescrever)
 * @param {{ empresa: string, ok: boolean, erro?: string }} entrada
 */
async function atualizarProgresso(token, id, progressoAtual, entrada) {
  const novoProgresso = [...progressoAtual, entrada];
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ progresso: novoProgresso, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar progresso (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0].progresso;
}

/**
 * @param {string} token
 * @param {string} id
 * @param {{ enviados: number, falhas: number, semEmail: number, adiados: number }} resumo
 */
async function concluir(token, id, resumo) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token),
    body: JSON.stringify({ status: 'concluido', resumo, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao concluir envio (${res.status}): ${await res.text()}`);
}

/**
 * @param {string} token
 * @param {string} id
 * @param {string} mensagemErro
 */
async function marcarErro(token, id, mensagemErro) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token),
    body: JSON.stringify({ status: 'erro', mensagem_erro: mensagemErro, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao marcar erro do envio (${res.status}): ${await res.text()}`);
}

/**
 * @param {string} token
 * @param {string} id
 * @returns {Promise<object|null>}
 */
async function buscarPorId(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}&select=*`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao consultar progresso (${res.status}).`);
  const rows = await res.json();
  return rows[0] || null;
}

module.exports = { iniciar, atualizarProgresso, concluir, marcarErro, buscarPorId };
