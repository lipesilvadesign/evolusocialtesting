const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_metricas';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {string} leadId
 * @returns {Promise<object[]>}
 */
async function listarPorLead(token, leadId) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/${TABLE}?lead_id=eq.${encodeURIComponent(leadId)}&order=data_coleta.desc.nullslast,created_at.desc`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao listar métricas (${res.status}).`);
  return res.json();
}

/**
 * @param {string} token
 * @param {{ leadId: string, nome: string, valor?: number, valorTexto?: string, unidade?: string,
 *   origem?: string, periodo?: string, dataColeta?: string, definicao?: string, criadoPor?: string }} dados
 * @returns {Promise<object>}
 */
async function criar(token, dados) {
  if (!dados.nome) throw new Error('Campo "nome" é obrigatório.');
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      lead_id: dados.leadId,
      nome: dados.nome,
      valor: dados.valor != null && dados.valor !== '' ? dados.valor : null,
      valor_texto: dados.valorTexto || null,
      unidade: dados.unidade || null,
      origem: dados.origem || null,
      periodo: dados.periodo || null,
      data_coleta: dados.dataColeta || null,
      definicao: dados.definicao || null,
      criado_por: dados.criadoPor || null,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao registrar métrica (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/** @param {string} token @param {string} id */
async function remover(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao excluir métrica (${res.status}).`);
}

module.exports = { listarPorLead, criar, remover };
