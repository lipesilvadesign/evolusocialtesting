/**
 * Financeiro — Contratos. Mesmo padrão REST-com-token-do-usuário de
 * tasksService.js/auditLogService.js: RLS aplica como o próprio usuário
 * (admin_eh_admin() em SQL_PENDENTE_financeiro.sql), nenhuma chave privada.
 *
 * `lead_id` é sempre um id que já existe em admin_prospeccao_leads — esta
 * tabela nunca guarda nome/empresa do cliente duplicado (ver comentário no
 * topo do SQL). O join com o lead (nome da empresa etc.) é feito no
 * frontend, cruzando com a mesma lista que Clientes/Prospecção já buscam —
 * não existe aqui uma segunda consulta "buscar cliente por nome".
 */
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_financeiro_contratos';
const SERVICOS_VALIDOS = new Set([
  'branding', 'identidade_visual', 'estrategia', 'conteudo',
  'gestao', 'diagnostico', 'projeto_especial', 'outros',
]);
const STATUS_VALIDOS = new Set(['ativo', 'concluido', 'cancelado']);

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/** @returns {Promise<object[]>} */
async function list(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&order=data_inicio.desc`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao listar contratos (${res.status}). A tabela ${TABLE} existe? Ver SQL_PENDENTE_financeiro.sql.`);
  return res.json();
}

/**
 * @param {string} token
 * @param {{ leadId: string, servico: string, valorTotal: number, dataInicio?: string, numeroParcelas?: number, recorrente?: boolean, observacoes?: string, criadoPor: string }} payload
 */
async function create(token, payload) {
  if (!payload.leadId) throw new Error('Selecione o cliente (o contrato precisa estar ligado a um cliente já existente no CRM).');
  if (!SERVICOS_VALIDOS.has(payload.servico)) throw new Error(`Serviço inválido: ${payload.servico}`);
  const valorTotal = Number(payload.valorTotal);
  if (!Number.isFinite(valorTotal) || valorTotal <= 0) throw new Error('Valor total precisa ser um número maior que zero.');
  const numeroParcelas = Math.max(1, Number(payload.numeroParcelas) || 1);

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      lead_id: payload.leadId,
      servico: payload.servico,
      valor_total: valorTotal,
      data_inicio: payload.dataInicio || new Date().toISOString().slice(0, 10),
      numero_parcelas: numeroParcelas,
      recorrente: Boolean(payload.recorrente),
      status: 'ativo',
      observacoes: payload.observacoes || null,
      criado_por: payload.criadoPor,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao criar contrato (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/** @param {string} token @param {string} id @param {object} payload campos a atualizar */
async function update(token, id, payload) {
  const body = { updated_at: new Date().toISOString() };
  if (payload.servico !== undefined) {
    if (!SERVICOS_VALIDOS.has(payload.servico)) throw new Error(`Serviço inválido: ${payload.servico}`);
    body.servico = payload.servico;
  }
  if (payload.valorTotal !== undefined) {
    const v = Number(payload.valorTotal);
    if (!Number.isFinite(v) || v <= 0) throw new Error('Valor total precisa ser um número maior que zero.');
    body.valor_total = v;
  }
  if (payload.status !== undefined) {
    if (!STATUS_VALIDOS.has(payload.status)) throw new Error(`Status inválido: ${payload.status}`);
    body.status = payload.status;
  }
  if (payload.recorrente !== undefined) body.recorrente = Boolean(payload.recorrente);
  if (payload.observacoes !== undefined) body.observacoes = payload.observacoes || null;

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar contrato (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  if (!rows[0]) throw new Error('Contrato não encontrado.');
  return rows[0];
}

/** Exclui o contrato — as parcelas dele saem junto (ON DELETE CASCADE, ver SQL). */
async function remove(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao excluir contrato (${res.status}): ${await res.text()}`);
}

module.exports = { list, create, update, remove, SERVICOS_VALIDOS, STATUS_VALIDOS, TABLE };
