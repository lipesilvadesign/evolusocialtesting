/**
 * Mural/comunicação da equipe (pedido do Felipe, 13/09) — um canal único
 * onde qualquer funcionário ativo manda mensagem e tira dúvida, visível
 * pra todo mundo cadastrado no painel. Sem edição (mensagem enviada é
 * definitiva); só admin apaga, pra moderar se precisar — ver
 * SQL_FIX_completo_13_09.sql pra tabela/policies.
 */
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_equipe_mensagens';
const LIMITE_PADRAO = 100;
const TAMANHO_MAXIMO = 2000;

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/** Mais recentes primeiro no banco, mas devolve em ordem cronológica (mais antiga primeiro) — é assim que uma conversa se lê. */
async function listar(token, { limit = LIMITE_PADRAO } = {}) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&order=created_at.desc&limit=${limit}`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao listar mensagens (${res.status}).`);
  const linhas = await res.json();
  return linhas.reverse();
}

/**
 * @param {string} token
 * @param {string} autorId
 * @param {string} mensagem
 * @param {string|null} [leadId] Pedido 13/09 (2ª rodada) — "compartilhar" uma
 *   dúvida/aviso sobre um cliente pro mural, com link de volta pra ele. FK
 *   opcional (ver SQL_FIX_completo_13_09.sql §4e); null = mensagem comum,
 *   sem cliente ligado.
 */
async function enviar(token, autorId, mensagem, leadId = null) {
  const texto = (mensagem || '').trim();
  if (!texto) throw new Error('Escreva alguma coisa antes de enviar.');
  if (texto.length > TAMANHO_MAXIMO) throw new Error(`Mensagem muito longa (máximo ${TAMANHO_MAXIMO} caracteres).`);

  const body = { autor_id: autorId, mensagem: texto };
  if (leadId) body.lead_id = leadId;

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Falha ao enviar mensagem (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

async function excluir(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: headers(token, { Prefer: 'return=representation' }),
  });
  if (!res.ok) throw new Error(`Falha ao excluir mensagem (${res.status}).`);
  const rows = await res.json();
  if (!rows[0]) throw new Error('Você não tem permissão para excluir esta mensagem, ou ela não existe.');
}

module.exports = { listar, enviar, excluir, TABLE };
