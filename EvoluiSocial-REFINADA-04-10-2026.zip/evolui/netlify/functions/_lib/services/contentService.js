/**
 * Service de Conteúdo.
 *
 * Diferente do analyticsService, este é REAL — não mockado. Lê a mesma
 * tabela `site_content` (id=1, coluna `content` em JSON) que o admin.html
 * atual já edita e que o site público (assets/js/site.bdacb7b1a8.js) já lê.
 *
 * A edição de conteúdo em si continua 100% no admin.html existente — não
 * foi reescrita aqui (ver decisão registrada na view "Conteúdo" do painel).
 * Este service só existe para a aba "Visão Geral" mostrar um resumo real
 * (quais seções existem, quando o conteúdo foi salvo pela última vez),
 * sem duplicar a lógica de edição.
 *
 * URL/chave vêm de ../config/supabase.js (extraído nesta etapa pra um
 * único lugar — antes estava duplicado aqui e em painel/assets/js/services/auth.js).
 */

const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

// Mesma lista de seções que o admin.html atual edita (assets/js/admin.1b9240a4b5.js).
// Mantida aqui só para rotular a "Visão Geral" — não é a fonte de verdade,
// que continua sendo o JSON salvo em site_content.
const KNOWN_SECTIONS = [
  { id: 'hero', label: 'Hero (abertura)' },
  { id: 'about', label: 'Sobre' },
  { id: 'services', label: 'Serviços' },
  { id: 'process', label: 'Processo' },
  { id: 'portfolio', label: 'Portfólio' },
  { id: 'compare', label: 'Antes / Depois' },
  { id: 'testimonials', label: 'Depoimentos' },
  { id: 'faq', label: 'FAQ' },
  { id: 'cta', label: 'Chamada final (CTA)' },
  { id: 'contact', label: 'Contato' },
  { id: 'footer', label: 'Rodapé' },
];

/**
 * Nota: a tabela `site_content` hoje só tem a coluna `content` (confirmado
 * por inspeção do admin.js — nenhuma referência a `updated_at`/`created_at`
 * no código atual). Por isso este service NÃO inventa uma data de última
 * edição — `updatedAt` fica `null` até que essa coluna exista de fato.
 *
 * @returns {Promise<{ sections: import('../types').ContentItem[], raw: object|null, error: string|null }>}
 */
async function getContentOverview() {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/site_content?select=content&id=eq.1`, {
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      },
    });
    if (!res.ok) throw new Error(`Supabase respondeu ${res.status}`);
    const rows = await res.json();
    const row = rows && rows[0];
    const content = row && row.content ? row.content : {};

    const sections = KNOWN_SECTIONS.map((s) => ({
      sectionId: s.id,
      sectionLabel: s.label,
      updatedAt: null,
      hasContent: Boolean(content[s.id]),
    }));

    return { sections, raw: content, error: null };
  } catch (err) {
    return { sections: [], raw: null, error: err.message || 'Falha ao carregar conteúdo.' };
  }
}

module.exports = { getContentOverview, KNOWN_SECTIONS };
