/**
 * Financeiro — Parcelas (contas a receber). Sempre ligadas a um contrato
 * (contrato_id, FK) — nunca um pagamento solto sem contrato/cliente por
 * trás, exatamente o que evita duplicar/perder o relacionamento
 * cliente → contrato → parcela → pagamento pedido.
 */
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_financeiro_parcelas';
const STATUS_VALIDOS = new Set(['previsto', 'aguardando', 'pago', 'atrasado', 'cancelado']);

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * Soma `i` meses a `dataBase`, cravando no ÚLTIMO DIA do mês-alvo quando o
 * dia original não existir nele (ex.: contrato iniciado dia 31 — fevereiro
 * não tem 31, a parcela daquele mês vence no dia 28/29).
 *
 * ACHADO NESTA AUDITORIA: `date.setMonth(date.getMonth() + i)` sozinho NÃO
 * faz esse ajuste — ele estoura pro mês seguinte (dia 31 + 1 mês vira 03/03
 * em vez de 28/02, quando fevereiro tem 28 dias), o que desalinhava todas as
 * parcelas seguintes de um contrato iniciado nos dias 29, 30 ou 31 de
 * qualquer mês. Pego por um teste automatizado antes de chegar a produção
 * (ver tests/financeiroService.test.js) — corrigido calculando o último dia
 * do mês-alvo primeiro.
 */
function adicionarMesesCravando(dataBase, i) {
  const ano = dataBase.getFullYear();
  const mesAlvo = dataBase.getMonth() + i;
  const ultimoDiaMesAlvo = new Date(ano, mesAlvo + 1, 0).getDate();
  const dia = Math.min(dataBase.getDate(), ultimoDiaMesAlvo);
  return new Date(ano, mesAlvo, dia, 12, 0, 0);
}

/** @param {string} token @param {string} [contratoId] quando ausente, lista todas (uso do dashboard) */
async function list(token, contratoId) {
  const filtro = contratoId ? `&contrato_id=eq.${encodeURIComponent(contratoId)}` : '';
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*${filtro}&order=vencimento.asc`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao listar parcelas (${res.status}). A tabela ${TABLE} existe? Ver SQL_PENDENTE_financeiro.sql.`);
  return res.json();
}

/**
 * Gera as parcelas de um contrato recém-criado — divisão igual do valor
 * total, 1 parcela por mês a partir de data_inicio. Ajusta a ÚLTIMA parcela
 * pra absorver a diferença de centavos do arredondamento (soma das parcelas
 * bate exatamente com valor_total, sempre).
 * @param {string} token
 * @param {{ id: string, valor_total: number, data_inicio: string, numero_parcelas: number }} contrato
 * @returns {Promise<object[]>}
 */
async function gerarParaContrato(token, contrato) {
  const n = Math.max(1, contrato.numero_parcelas);
  const valorTotalCentavos = Math.round(Number(contrato.valor_total) * 100);
  const valorParcelaCentavos = Math.floor(valorTotalCentavos / n);
  const dataBase = new Date(`${contrato.data_inicio}T12:00:00`);

  const parcelas = Array.from({ length: n }, (_, i) => {
    const centavos = i === n - 1 ? valorTotalCentavos - valorParcelaCentavos * (n - 1) : valorParcelaCentavos;
    const vencimento = adicionarMesesCravando(dataBase, i);
    return {
      contrato_id: contrato.id,
      numero: i + 1,
      valor: centavos / 100,
      vencimento: vencimento.toISOString().slice(0, 10),
      status: 'previsto',
    };
  });

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(parcelas),
  });
  if (!res.ok) throw new Error(`Falha ao gerar parcelas (${res.status}): ${await res.text()}`);
  return res.json();
}

/**
 * Marca uma parcela como paga (ou outra transição de status manual).
 * @param {string} token @param {string} id
 * @param {{ status: string, pagoEm?: string, valorPago?: number, formaPagamento?: string }} payload
 */
async function updateStatus(token, id, payload) {
  if (!STATUS_VALIDOS.has(payload.status)) throw new Error(`Status inválido: ${payload.status}`);
  const body = { status: payload.status, updated_at: new Date().toISOString() };
  if (payload.status === 'pago') {
    body.pago_em = payload.pagoEm || new Date().toISOString().slice(0, 10);
    if (payload.valorPago !== undefined && payload.valorPago !== null) {
      const v = Number(payload.valorPago);
      if (!Number.isFinite(v) || v <= 0) throw new Error('Valor pago precisa ser um número maior que zero.');
      body.valor_pago = v;
    }
    if (payload.formaPagamento) body.forma_pagamento = payload.formaPagamento;
  } else {
    // Voltar de "pago" pra outro status limpa o registro de pagamento —
    // evita ficar com pago_em preenchido numa parcela que não está mais paga.
    body.pago_em = null;
    body.valor_pago = null;
  }

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar parcela (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  if (!rows[0]) throw new Error('Parcela não encontrada.');
  return rows[0];
}

module.exports = { list, gerarParaContrato, updateStatus, adicionarMesesCravando, STATUS_VALIDOS, TABLE };
