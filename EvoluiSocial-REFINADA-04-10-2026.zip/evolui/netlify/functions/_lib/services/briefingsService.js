const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_briefings';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {string} leadId
 * @returns {Promise<object|null>} null se o cliente ainda não tem briefing iniciado
 */
async function obter(token, leadId) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?lead_id=eq.${encodeURIComponent(leadId)}&select=*`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao buscar briefing (${res.status}).`);
  const rows = await res.json();
  return rows[0] || null;
}

/**
 * Cria ou atualiza o briefing do lead/cliente (upsert manual — só existe UM
 * briefing por lead, ver constraint unique(lead_id) na tabela).
 * @param {string} token
 * @param {string} leadId
 * @param {object} conteudo estrutura modular (empresa/publico/posicionamento/
 *   personalidade/preferenciasVisuais/objetivos) — validada só no front,
 *   aqui é gravada como está pra não travar em campo novo que o front some.
 * @param {string} atualizadoPor
 * @returns {Promise<object>}
 */
async function salvar(token, leadId, conteudo, atualizadoPor) {
  const existente = await obter(token, leadId);

  if (existente) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${existente.id}`, {
      method: 'PATCH',
      headers: headers(token, { Prefer: 'return=representation' }),
      body: JSON.stringify({ conteudo, atualizado_por: atualizadoPor, updated_at: new Date().toISOString() }),
    });
    if (!res.ok) throw new Error(`Falha ao atualizar briefing (${res.status}): ${await res.text()}`);
    const rows = await res.json();
    return rows[0];
  }

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ lead_id: leadId, conteudo, atualizado_por: atualizadoPor }),
  });
  if (!res.ok) throw new Error(`Falha ao criar briefing (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

module.exports = { obter, salvar };
