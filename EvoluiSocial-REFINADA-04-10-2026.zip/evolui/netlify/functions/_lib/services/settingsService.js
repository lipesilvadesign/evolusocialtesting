const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/** @returns {Promise<object>} */
async function get(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/admin_settings?select=content&id=eq.1`, {
    headers: headers(token),
  });
  if (!res.ok) {
    throw new Error(
      `Falha ao ler configurações (${res.status}). A tabela admin_settings existe? Ver SQL pendente.`
    );
  }
  const rows = await res.json();
  return (rows[0] && rows[0].content) || {};
}

function deepMerge(base, patch) {
  const out = { ...base };
  for (const k of Object.keys(patch || {})) {
    const patchVal = patch[k];
    const baseVal = base[k];
    if (
      patchVal &&
      typeof patchVal === 'object' &&
      !Array.isArray(patchVal) &&
      baseVal &&
      typeof baseVal === 'object'
    ) {
      out[k] = deepMerge(baseVal, patchVal);
    } else {
      out[k] = patchVal;
    }
  }
  return out;
}

/** Merge parcial — só as seções enviadas mudam, o resto do JSON é preservado. */
async function update(token, partial) {
  const current = await get(token);
  const merged = deepMerge(current, partial);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/admin_settings?id=eq.1`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ content: merged, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao salvar configurações (${res.status}): ${await res.text()}`);
  return merged;
}

module.exports = { get, update };
