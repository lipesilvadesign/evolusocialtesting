/**
 * CRM de prospecção (admin_prospeccao_leads) — acesso com o token do
 * usuário (RLS decide o que cada papel vê/edita).
 *
 * 30/09 (Lead Capture Engine):
 * - list() virou listar(): filtros e paginação NO SERVIDOR (nunca mais a
 *   tabela inteira no navegador); arquivados fora por padrão.
 * - create() grava todos os campos válidos do formulário (antes descartava
 *   CNPJ, status, sinais, problema/evidência/oferta) por lista branca;
 *   campos protegidos (score, temperatura, origem, arquivamento) nunca vêm
 *   do cliente — score e temperatura são calculados pelo banco (migration 008).
 * - update() com corpo vazio do Supabase não vira erro falso.
 * - Arquivar / restaurar / mesclar / excluir definitivo por RPC (regras de
 *   papel conferidas no banco, migration 009).
 * - Inserção em lote direto no CRM (bulkInsertAuto/bulkInsertManual) foi
 *   DESLIGADA: todo resultado automático passa pela captura
 *   (admin_prospeccao_captura) e por decisão humana.
 */
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');
const { rest, rpc, valorFiltro } = require('../supabaseRest');
const taxonomia = require('../captacao/taxonomia');

const TABLE = 'admin_prospeccao_leads';
const VALID_STATUS = new Set([
  'novo_lead', 'contatado', 'respondeu', 'interessado', 'reuniao_marcada', 'proposta_enviada', 'cliente', 'nao_convertido',
]);
const VALID_STATUS_LEAD = new Set(['novo', 'pesquisando', 'qualificado', 'nao_qualificado', 'duplicado', 'bloqueado']);
const VALID_STATUS_CONTATO = new Set(['sem_contato', 'email_encontrado', 'email_validado', 'whatsapp_disponivel', 'decisor_identificado', 'optout_solicitado', 'nao_contatar']);
const VALID_PRIORIDADE = new Set(['alta', 'media', 'baixa']);
// Fontes que uma pessoa pode escolher ao cadastrar à mão (as automáticas vêm da captação).
const FONTES_MANUAIS = new Set(['manual', 'indicacao', 'evento']);

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/** camelCase do painel → coluna. Só o que o cliente PODE escrever. */
const CAMPOS_EDITAVEIS = {
  empresa: 'empresa',
  setor: 'setor',
  subsetor: 'subsetor',
  telefone: 'telefone',
  email: 'email',
  endereco: 'endereco',
  cidade: 'cidade',
  uf: 'uf',
  site: 'site',
  instagram: 'instagram',
  responsavelInterno: 'responsavel_interno',
  responsavelId: 'responsavel_id',
  avaliacaoGoogle: 'avaliacao_google',
  anosMercado: 'anos_mercado',
  funcaoContato: 'funcao_contato',
  prioridade: 'prioridade',
  motivo: 'motivo',
  cnpj: 'cnpj',
  statusLead: 'status_lead',
  statusContato: 'status_contato',
  problemaIdentificado: 'problema_identificado',
  evidenciaProblema: 'evidencia_problema',
  ofertaRecomendada: 'oferta_recomendada',
  sinalSiteDesatualizado: 'sinal_site_desatualizado',
  sinalInstagramDesorganizado: 'sinal_instagram_desorganizado',
  sinalGbpFraco: 'sinal_gbp_fraco',
  sinalPorteMedioGrande: 'sinal_porte_medio_grande',
  sinalSegmentoAltoPotencial: 'sinal_segmento_alto_potencial',
  sinalEmailValidado: 'sinal_email_validado',
  canalSugerido: 'canal_sugerido',
  status: 'status',
  observacoes: 'observacoes',
  campanha: 'campanha',
  proximaAtividadeEm: 'proxima_atividade_em',
};
const BOOLEANOS = new Set(['sinal_site_desatualizado', 'sinal_instagram_desorganizado', 'sinal_gbp_fraco', 'sinal_porte_medio_grande', 'sinal_segmento_alto_potencial', 'sinal_email_validado']);

class ErroValidacao extends Error {
  constructor(msg) { super(msg); this.statusCode = 400; }
}

/** Valida e converte o payload do painel em colunas. Lança ErroValidacao. */
function montarCorpo(payload, { parcial }) {
  const body = {};
  for (const [key, column] of Object.entries(CAMPOS_EDITAVEIS)) {
    if (!Object.prototype.hasOwnProperty.call(payload, key)) continue;
    let v = payload[key];
    if (typeof v === 'string') v = v.trim();
    if (BOOLEANOS.has(column)) v = Boolean(v);
    else if (v === '' || v === undefined) v = null;
    body[column] = v;
  }
  if (!parcial && !body.empresa) throw new ErroValidacao('Campo "empresa" é obrigatório.');
  if (parcial && Object.prototype.hasOwnProperty.call(body, 'empresa') && !body.empresa) throw new ErroValidacao('Campo "empresa" não pode ficar vazio.');
  if (body.empresa && body.empresa.length > 300) throw new ErroValidacao('Nome da empresa muito longo.');
  if (body.status && !VALID_STATUS.has(body.status)) throw new ErroValidacao(`Status inválido: ${body.status}`);
  if (body.status_lead && !VALID_STATUS_LEAD.has(body.status_lead)) throw new ErroValidacao(`Qualificação inválida: ${body.status_lead}`);
  if (body.status_contato && !VALID_STATUS_CONTATO.has(body.status_contato)) throw new ErroValidacao(`Status de contato inválido: ${body.status_contato}`);
  if (body.prioridade && !VALID_PRIORIDADE.has(body.prioridade)) throw new ErroValidacao(`Prioridade inválida: ${body.prioridade}`);
  if (body.campanha && !/^[a-z0-9_]{1,60}$/.test(body.campanha)) throw new ErroValidacao('Campanha: use só letras minúsculas, números e _ (até 60).');
  if (body.uf && !/^[A-Z]{2}$/.test(body.uf)) throw new ErroValidacao('UF inválida.');
  if (body.proxima_atividade_em && Number.isNaN(Date.parse(body.proxima_atividade_em))) throw new ErroValidacao('Data da próxima atividade inválida.');
  for (const c of ['observacoes', 'problema_identificado', 'evidencia_problema', 'oferta_recomendada', 'motivo']) {
    if (body[c] && body[c].length > 5000) throw new ErroValidacao(`Campo ${c} muito longo.`);
  }
  return body;
}

// --------------------------------------------------------------------------
// Listagem com filtros e paginação no servidor
// --------------------------------------------------------------------------
const ORDENS = {
  score: 'score.desc.nullslast,id.asc',
  recentes: 'created_at.desc,id.asc',
  atividade: 'ultima_atividade_em.desc.nullslast,id.asc',
  empresa: 'empresa.asc,id.asc',
};
const LISTA_CSV = (v) => String(v).split(',').map((s) => s.trim()).filter(Boolean).slice(0, 20);

/**
 * Converte a query string da Function em filtros PostgREST.
 * Aceita: q, setor, subsetor, cidade, uf, fonte, metodo, campanha, score_min, score_max,
 * faixa, temperatura, prioridade, status, responsavel (me|sem|uuid), criado_de, criado_ate,
 * atividade_de, atividade_ate, oportunidade, tem_site, tem_instagram, tem_telefone,
 * tem_email, arquivados (0 padrão | 1 todos | so), ordem, pagina, por_pagina.
 * @returns {{ partes: string[], select: string, ordem: string, limite: number, offset: number, pagina: number }}
 */
function montarConsulta(q = {}, userId) {
  const partes = [];
  const add = (s) => partes.push(s);
  const norm = (s) => taxonomia.semAcento(s).replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();

  if (q.q) {
    const termo = norm(q.q).slice(0, 80);
    if (termo) add(`empresa_norm=ilike.${encodeURIComponent(`*${termo}*`)}`);
  }
  const inList = (col, v) => add(`${col}=in.(${LISTA_CSV(v).map((x) => encodeURIComponent(valorFiltro(x))).join(',')})`);
  if (q.setor) inList('setor', q.setor);
  if (q.subsetor) add(`subsetor=ilike.${encodeURIComponent(`*${String(q.subsetor).slice(0, 60)}*`)}`);
  if (q.cidade) add(`cidade_norm=eq.${encodeURIComponent(taxonomia.semAcento(String(q.cidade).split(/[,/-]/)[0]).trim())}`);
  if (q.uf) add(`uf=eq.${encodeURIComponent(String(q.uf).toUpperCase().slice(0, 2))}`);
  if (q.fonte) inList('fonte', q.fonte);
  if (q.metodo) inList('metodo_captacao', q.metodo);
  if (q.campanha) inList('campanha', q.campanha);
  if (q.temperatura) inList('temperatura', q.temperatura);
  if (q.prioridade) inList('prioridade', q.prioridade);
  if (q.status) inList('status', q.status);
  if (q.contatabilidade) inList('contatabilidade', String(q.contatabilidade).split(',').filter((x) => ['CONTATO_FORTE', 'CONTATO_PARCIAL', 'SEM_CONTATO'].includes(x)).join(',') || 'X');
  if (q.com_proxima_acao === '1') add('proxima_acao=not.is.null');
  const num = (v) => (v === undefined || v === '' || Number.isNaN(Number(v)) ? null : Math.round(Number(v)));
  let min = num(q.score_min);
  let max = num(q.score_max);
  if (q.faixa) {
    const f = taxonomia.FAIXAS_SCORE.find((x) => x.chave === q.faixa);
    if (f) {
      const idx = taxonomia.FAIXAS_SCORE.indexOf(f);
      min = f.min;
      max = idx > 0 ? taxonomia.FAIXAS_SCORE[idx - 1].min - 1 : 100;
    }
  }
  if (min !== null) add(`score=gte.${min}`);
  if (max !== null) add(`score=lte.${max}`);
  if (q.responsavel === 'me' && userId) add(`responsavel_id=eq.${encodeURIComponent(userId)}`);
  else if (q.responsavel === 'sem') add('responsavel_id=is.null');
  else if (q.responsavel && /^[0-9a-f-]{36}$/i.test(q.responsavel)) add(`responsavel_id=eq.${q.responsavel}`);
  const data = (v) => (v && !Number.isNaN(Date.parse(v)) ? new Date(v).toISOString() : null);
  if (data(q.criado_de)) add(`created_at=gte.${data(q.criado_de)}`);
  if (data(q.criado_ate)) add(`created_at=lt.${data(q.criado_ate)}`);
  if (data(q.atividade_de)) add(`ultima_atividade_em=gte.${data(q.atividade_de)}`);
  if (data(q.atividade_ate)) add(`ultima_atividade_em=lt.${data(q.atividade_ate)}`);
  const tem = (v, col) => {
    if (v === '1' || v === 'true') add(`${col}=not.is.null`);
    if (v === '0' || v === 'false') add(`${col}=is.null`);
  };
  tem(q.tem_site, 'site');
  tem(q.tem_instagram, 'instagram_handle');
  tem(q.tem_telefone, 'telefone_norm');
  tem(q.tem_email, 'email');
  if (q.arquivados === 'so') add('arquivado_em=not.is.null');
  else if (q.arquivados !== '1') add('arquivado_em=is.null');

  let select = '*';
  if (q.oportunidade && taxonomia.OPORTUNIDADES[q.oportunidade]) {
    select = '*,admin_prospeccao_oportunidades!inner(tipo)';
    add(`admin_prospeccao_oportunidades.tipo=eq.${q.oportunidade}`);
    add('admin_prospeccao_oportunidades.descartado=eq.false');
  }

  const porPagina = Math.min(Math.max(num(q.por_pagina) || taxonomia.LIMITES.paginaPadrao, 1), taxonomia.LIMITES.paginaMaxima);
  const pagina = Math.max(num(q.pagina) || 1, 1);
  return { partes, select, ordem: ORDENS[q.ordem] || ORDENS.score, limite: porPagina, offset: (pagina - 1) * porPagina, pagina };
}

/**
 * @returns {Promise<{ itens: object[], total: number|null, pagina: number, porPagina: number }>}
 */
async function listar(token, query = {}, userId = null) {
  const c = montarConsulta(query, userId);
  const caminho = `${TABLE}?select=${encodeURIComponent(c.select)}&${c.partes.join('&')}${c.partes.length ? '&' : ''}order=${c.ordem}&limit=${c.limite}&offset=${c.offset}`;
  // count=exact até ~10 mil é barato; acima disso "estimated" (ver docs/LEAD_CAPTURE_ENGINE.md)
  const { data, total } = await rest(token, caminho, { prefer: query.contagem === 'estimada' ? 'count=estimated' : 'count=exact' });
  const itens = (data || []).map((l) => {
    const { admin_prospeccao_oportunidades: _o, ...resto } = l;
    return resto;
  });
  return { itens, total, pagina: c.pagina, porPagina: c.limite };
}

/** Compatibilidade: lista simples (primeira página, sem arquivados). */
async function list(token) {
  const r = await listar(token, { por_pagina: taxonomia.LIMITES.paginaMaxima });
  return r.itens;
}

async function buscarPorId(token, id) {
  const { data } = await rest(token, `${TABLE}?id=eq.${encodeURIComponent(id)}&select=*,admin_prospeccao_oportunidades(id,tipo,evidencia,evidencia_url,fonte,confianca,detectado_em,confirmado,descartado)`);
  return (data && data[0]) || null;
}

/**
 * @param {string} token
 * @param {object} payload campos do formulário (camelCase) + criadoPor
 * @param {{ ehAdmin?: boolean, userId?: string }} [ctx]
 */
async function create(token, payload, ctx = {}) {
  const body = montarCorpo(payload, { parcial: false });
  // Responsável: prospecção só atribui a si mesma (o RLS também barra; aqui a mensagem é clara)
  if (!ctx.ehAdmin && ctx.userId && body.responsavel_id && body.responsavel_id !== ctx.userId) {
    throw new ErroValidacao('Você só pode cadastrar leads sob sua responsabilidade.');
  }
  body.status = body.status || 'novo_lead';
  body.prioridade = body.prioridade || 'media';
  body.fonte = FONTES_MANUAIS.has(payload.fonte) ? payload.fonte : 'manual';
  body.metodo_captacao = body.fonte === 'indicacao' ? 'indicacao' : body.fonte === 'evento' ? 'networking' : 'prospeccao_manual';
  body.criado_por = payload.criadoPor;
  const { data } = await rest(token, TABLE, { method: 'POST', body, prefer: 'return=representation' });
  return data && data[0];
}

/**
 * @param {string} token
 * @param {string} id
 * @param {object} payload campos parciais (score/scoreMotivos enviados por painel antigo são IGNORADOS)
 */
async function update(token, id, payload, ctx = {}) {
  const body = montarCorpo(payload, { parcial: true });
  if (!ctx.ehAdmin && ctx.userId && Object.prototype.hasOwnProperty.call(body, 'responsavel_id') && body.responsavel_id !== ctx.userId) {
    throw new ErroValidacao('Somente admin pode passar o lead para outra pessoa.');
  }
  body.updated_at = new Date().toISOString();
  const { data } = await rest(token, `${TABLE}?id=eq.${encodeURIComponent(id)}`, { method: 'PATCH', body, prefer: 'return=representation' });
  if (Array.isArray(data) && data.length) return data[0];
  // Corpo vazio = nenhuma linha visível/alterada (RLS ou id inexistente) — não é "sucesso"
  const erro = new Error('Lead não encontrado ou sem permissão para editar.');
  erro.statusCode = 404;
  throw erro;
}

/** Exclusão definitiva: o banco só permite para admin e lead já arquivado. */
async function remove(token, id) {
  const { data } = await rest(token, `${TABLE}?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE', prefer: 'return=representation' });
  if (!Array.isArray(data) || !data.length) {
    const erro = new Error('Não foi possível excluir: só admin exclui, e só lead já arquivado (arquive antes).');
    erro.statusCode = 403;
    throw erro;
  }
  return data[0];
}

async function arquivar(token, ids, motivo, obs) {
  return rpc(token, 'prospeccao_arquivar', { p_ids: ids, p_motivo: motivo, p_obs: obs || null });
}
async function restaurar(token, ids) {
  return rpc(token, 'prospeccao_restaurar', { p_ids: ids });
}
async function mesclar(token, manterId, absorverId) {
  return rpc(token, 'prospeccao_mesclar_leads', { p_manter: manterId, p_absorver: absorverId });
}
async function converterInbound(token, tipo, id) {
  return rpc(token, 'prospeccao_converter_inbound', { p_tipo: tipo, p_id: id });
}

/**
 * E-mails de prospecção enviados HOJE (meia-noite de America/Recife), de
 * TODOS os responsáveis — o limite diário protege a caixa de e-mail, que é
 * uma só. Contagem feita no banco (RPC), não pelo tamanho da lista visível.
 */
async function countEmailsSentToday(token) {
  const n = await rpc(token, 'prospeccao_emails_enviados_hoje', {});
  if (n === null || n === undefined) throw new Error('Sem permissão para consultar o limite de e-mails.');
  return Number(n);
}

async function listByIds(token, ids) {
  if (!ids.length) return [];
  const filtro = ids.map((id) => encodeURIComponent(id)).join(',');
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/${TABLE}?select=id,empresa,setor,cidade,email,anos_mercado,telefone,origem_id,status_contato,arquivado_em&id=in.(${filtro})&arquivado_em=is.null`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao buscar leads selecionados (${res.status}).`);
  return res.json();
}

async function markEmailSent(token, id, resultado) {
  const body = resultado.ok
    ? { email_enviado_em: new Date().toISOString(), email_status: 'enviado' }
    : { email_status: `erro: ${String(resultado.erro || 'falha desconhecida').slice(0, 200)}` };
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Falha ao registrar envio de e-mail (${res.status}).`);
}

module.exports = {
  list,
  listar,
  montarConsulta,
  montarCorpo,
  buscarPorId,
  create,
  update,
  remove,
  arquivar,
  restaurar,
  mesclar,
  converterInbound,
  countEmailsSentToday,
  listByIds,
  markEmailSent,
  ErroValidacao,
  VALID_STATUS,
  CAMPOS_EDITAVEIS,
  TABLE,
};
