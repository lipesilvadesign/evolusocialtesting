/**
 * Atividades (linha do tempo) de um lead da Consultoria de Instagram —
 * mesmo padrão de _lib/services/atividadesService.js (Prospecção), tabela
 * própria (consultas_atividades). Usado tanto pelo painel (observação,
 * contato realizado, mudança de status — token do usuário autenticado)
 * quanto, para os 4 tipos de evento público, pelas Netlify Functions
 * consultas-criar.js/consultas-evento.js (token = chave anônima).
 */

const { randomUUID } = require('crypto');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'consultas_atividades';

const TIPOS_VALIDOS = [
  'analise_concluida',
  'cta_whatsapp',
  'cta_agendamento',
  'cta_instagram',
  'contato_realizado',
  'mudanca_status',
  'observacao',
];

/** Tipos que a Function pública (visitante sem login) tem permissão de gravar — ver RLS anon_insert_consultas_atividades. */
const TIPOS_PUBLICOS = ['analise_concluida', 'cta_whatsapp', 'cta_agendamento', 'cta_instagram'];

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {string} leadId
 * @returns {Promise<object[]>}
 */
async function listarPorLead(token, leadId) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?lead_id=eq.${encodeURIComponent(leadId)}&order=data.desc`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao listar atividades (${res.status}).`);
  return res.json();
}

/**
 * @param {string} token token da sessão (painel) OU a chave anônima (evento público)
 * @param {{ leadId: string, tipo: string, descricao?: string, data?: string, criadoPor?: string }} dados
 * @returns {Promise<object>}
 */
async function criar(token, dados) {
  if (!TIPOS_VALIDOS.includes(dados.tipo)) {
    throw new Error(`Tipo de atividade inválido: "${dados.tipo}".`);
  }
  // Gera o id aqui (em vez de deixar o Postgres gerar e pedir de volta com
  // "Prefer: return=representation") de propósito: o visitante anônimo (que
  // usa esta mesma função para os 4 tipos públicos) não tem — nem deveria
  // ter — política de SELECT em consultas_atividades. E um RETURNING/
  // "return=representation" depois de INSERT/UPDATE exige visibilidade via
  // política de SELECT além da de INSERT, mesmo que a de INSERT já tenha
  // liberado a gravação (comportamento documentado do Postgres RLS). Sem
  // essa política, a gravação era recusada com o mesmo erro genérico de
  // "violates row-level security policy" — mesmo a política de INSERT
  // estando 100% correta. Gerando o id aqui e usando "return=minimal", a
  // gravação nunca precisa dessa leitura de volta.
  const id = randomUUID();
  const registro = {
    id,
    lead_id: dados.leadId,
    tipo: dados.tipo,
    descricao: dados.descricao || null,
    data: dados.data || new Date().toISOString(),
    criado_por: dados.criadoPor || null,
  };
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=minimal' }),
    body: JSON.stringify(registro),
  });
  if (!res.ok) throw new Error(`Falha ao registrar atividade (${res.status}): ${await res.text()}`);
  return registro;
}

module.exports = { listarPorLead, criar, TIPOS_VALIDOS, TIPOS_PUBLICOS, TABLE };
