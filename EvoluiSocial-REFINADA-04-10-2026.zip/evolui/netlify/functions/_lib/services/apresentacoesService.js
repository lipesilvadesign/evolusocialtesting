const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_apresentacoes';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

function slugify(text) {
  return (text || '')
    .toString()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

/**
 * @param {string} token
 * @param {string} leadId
 * @returns {Promise<object[]>} versões, mais recente primeiro
 */
async function listarPorLead(token, leadId) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/${TABLE}?lead_id=eq.${encodeURIComponent(leadId)}&select=*&order=versao.desc`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao listar apresentações (${res.status}).`);
  return res.json();
}

/**
 * Cria uma nova versão em rascunho. O slug é gerado só na PRIMEIRA versão
 * (a partir do nome da empresa) e reaproveitado pelas versões seguintes do
 * MESMO cliente — o link público não muda quando uma nova versão é
 * publicada, só o conteúdo por trás dele.
 * @param {string} token
 * @param {string} leadId
 * @param {string} nomeEmpresa usado só se ainda não existir slug pra este cliente
 * @param {{ tema?: object, conteudo?: object }} dados
 * @param {string} criadoPor
 */
async function criarNovaVersao(token, leadId, nomeEmpresa, dados, criadoPor) {
  const existentes = await listarPorLead(token, leadId);
  const proximaVersao = existentes.length ? Math.max(...existentes.map((a) => a.versao)) + 1 : 1;
  const slug = existentes.length ? existentes[0].slug : await gerarSlugUnico(token, nomeEmpresa);

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      lead_id: leadId,
      slug,
      versao: proximaVersao,
      status: 'rascunho',
      tema: (dados && dados.tema) || {},
      conteudo: (dados && dados.conteudo) || {},
      criado_por: criadoPor,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao criar apresentação (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

async function gerarSlugUnico(token, nomeEmpresa) {
  const base = slugify(nomeEmpresa) || 'cliente';
  for (let tentativa = 0; tentativa < 6; tentativa += 1) {
    const candidato = tentativa === 0 ? base : `${base}-${Math.random().toString(36).slice(2, 6)}`;
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?slug=eq.${encodeURIComponent(candidato)}&select=id`, {
      headers: headers(token),
    });
    if (res.ok) {
      const rows = await res.json();
      if (rows.length === 0) return candidato;
    }
  }
  return `${base}-${Date.now().toString(36)}`;
}

/**
 * Atualiza conteúdo/tema de uma versão — só permitido enquanto 'rascunho'.
 * @param {string} token @param {string} id @param {{ tema?: object, conteudo?: object }} dados
 */
async function atualizar(token, id, dados) {
  const resAtual = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}&select=status`, {
    headers: headers(token),
  });
  if (!resAtual.ok) throw new Error(`Falha ao verificar apresentação (${resAtual.status}).`);
  const atual = (await resAtual.json())[0];
  if (!atual) throw new Error('Apresentação não encontrada.');
  if (atual.status === 'publicado') {
    throw new Error('Esta versão já foi publicada e não pode mais ser editada. Crie uma nova versão.');
  }

  const body = { updated_at: new Date().toISOString() };
  if (dados.tema !== undefined) body.tema = dados.tema;
  if (dados.conteudo !== undefined) body.conteudo = dados.conteudo;

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Falha ao salvar apresentação (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/** @param {string} token @param {string} id */
async function publicar(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ status: 'publicado', publicado_em: new Date().toISOString(), updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao publicar apresentação (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

// ---------------------------------------------------------------------------
// 30/09: LISTA BRANCA do que a página pública pode receber. O snapshot salvo
// pelo painel trazia `metricasDisponiveis` = TODAS as métricas do lead (com
// ids internos), inclusive as desmarcadas. O banco já filtra (RPC
// apresentacao_publica, migration 011); isto é a segunda camada e também
// garante tipos (null-safe) para a página.
// ---------------------------------------------------------------------------
const MAX_TEXTO = 6000;
const txt = (v, max = MAX_TEXTO) => (typeof v === 'string' ? v.slice(0, max) : typeof v === 'number' ? String(v) : '');
const bool = (v) => v === true;
const obj = (v) => (v && typeof v === 'object' && !Array.isArray(v) ? v : {});
const COR = /^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/;
const IMG = /^(data:image\/(png|jpe?g|webp|gif|svg\+xml);base64,[A-Za-z0-9+/=]+|https:\/\/[^\s"'<>]+)$/;

function sanitizarTema(t) {
  const o = obj(t);
  const out = {};
  for (const k of ['primaryColor', 'secondaryColor', 'accentColor', 'backgroundColor']) if (COR.test(String(o[k] || ''))) out[k] = o[k];
  if (typeof o.logo === 'string' && o.logo.length < 1_500_000 && IMG.test(o.logo)) out.logo = o.logo;
  return out;
}

function sanitizarConteudo(c) {
  const o = obj(c);
  const secao = (v, campos) => { const x = obj(v); const r = { incluir: bool(x.incluir) }; for (const k of campos) r[k] = txt(x[k]); return r; };
  const ids = Array.isArray(o.metricasIds) ? o.metricasIds.map(String) : [];
  const metricas = (Array.isArray(o.metricasDisponiveis) ? o.metricasDisponiveis : [])
    .filter((m) => m && ids.includes(String(m.id)))
    .slice(0, 24)
    .map((m) => ({
      id: String(m.id), nome: txt(m.nome, 200), valor: typeof m.valor === 'number' && Number.isFinite(m.valor) ? m.valor : null,
      valor_texto: txt(m.valor_texto, 120), unidade: txt(m.unidade, 30), periodo: txt(m.periodo, 80), origem: txt(m.origem, 120),
    }));
  const capa = obj(o.capa);
  return {
    capa: { titulo: txt(capa.titulo, 200), subtitulo: txt(capa.subtitulo, 200), data: txt(capa.data, 40), localizacao: txt(capa.localizacao, 120) },
    sobreEmpresa: secao(o.sobreEmpresa, ['contexto', 'segmento', 'produtos', 'diferenciais']),
    presencaAtual: secao(o.presencaAtual, ['instagram', 'site', 'identidade', 'comunicacao', 'posicionamento']),
    metricasIds: metricas.map((m) => m.id),
    metricasDisponiveis: metricas,
    interpretacao: (Array.isArray(o.interpretacao) ? o.interpretacao : []).slice(0, 20).map((r) => ({ dado: txt(obj(r).dado), significado: txt(obj(r).significado), impacto: txt(obj(r).impacto) })),
    oportunidades: txt(o.oportunidades),
    direcaoEstrategica: secao(o.direcaoEstrategica, ['posicionamento', 'percepcaoDesejada', 'diferenciacao', 'comunicacao']),
    direcaoVisual: secao(o.direcaoVisual, ['cores', 'tipografia', 'referencias']),
    proximosPassos: txt(o.proximosPassos),
  };
}

/**
 * Busca pública por slug — usa a mesma anon key (a policy `anon` da tabela
 * já restringe a status='publicado'), e SÓ retorna os campos que a página
 * pública precisa. Nunca devolve lead_id/criado_por/id interno.
 * @param {string} slug
 * @returns {Promise<{ slug: string, versao: number, tema: object, conteudo: object, publicadoEm: string }|null>}
 */
async function obterPublicaPorSlug(slug) {
  // CORREÇÃO 29/09: lê pela função apresentacao_publica (SQL_CORRECAO_SEGURANCA_29_09.sql)
  // em vez de SELECT direto na tabela. A política anon antiga deixava qualquer
  // pessoa com a chave pública LISTAR todas as apresentações publicadas.
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/apresentacao_publica`, {
    method: 'POST',
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ p_slug: String(slug).slice(0, 200) }),
  });
  if (!res.ok) throw new Error(`Falha ao buscar apresentação pública (${res.status}).`);
  const rows = await res.json();
  if (!rows[0]) return null;
  return {
    slug: rows[0].slug,
    versao: rows[0].versao,
    tema: sanitizarTema(rows[0].tema),
    conteudo: sanitizarConteudo(rows[0].conteudo),
    publicadoEm: rows[0].publicado_em,
  };
}

module.exports = { listarPorLead, criarNovaVersao, atualizar, publicar, obterPublicaPorSlug, sanitizarConteudo, sanitizarTema };
