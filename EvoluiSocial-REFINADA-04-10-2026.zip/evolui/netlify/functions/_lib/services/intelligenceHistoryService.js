const crypto = require('crypto');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_insights_historico';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * ID estável (não aleatório): mesmo tipo+título+período sempre gera o
 * mesmo id, então recalcular a inteligência não duplica registros — só
 * atualiza os campos analíticos, preservando o `status` que o usuário já
 * tiver definido (ver upsertMany).
 */
function stableId(tipo, titulo, rangeLabel) {
  return crypto.createHash('sha256').update(`${tipo}::${titulo}::${rangeLabel}`).digest('hex').slice(0, 32);
}

/**
 * Grava (ou atualiza, preservando status) uma leva de itens — oportunidades,
 * anomalias, correlações etc. Usa upsert nativo do PostgREST
 * (Prefer: resolution=merge-duplicates) por id estável.
 *
 * IMPORTANTE: merge-duplicates faz UPDATE de TODAS as colunas enviadas —
 * por isso `status` só é incluído no payload quando o item ainda NÃO
 * existir (checagem feita aqui buscando os ids já existentes antes).
 */
async function upsertMany(token, items) {
  if (items.length === 0) return [];

  const ids = items.map((i) => i.id);
  const existingRes = await fetch(
    `${SUPABASE_URL}/rest/v1/${TABLE}?select=id,status&id=in.(${ids.map(encodeURIComponent).join(',')})`,
    { headers: headers(token) }
  );
  if (!existingRes.ok) throw new Error(`Falha ao consultar histórico existente (${existingRes.status}).`);
  const existingRows = await existingRes.json();
  const existingStatus = new Map(existingRows.map((r) => [r.id, r.status]));

  const payload = items.map((item) => ({
    ...item,
    status: existingStatus.has(item.id) ? existingStatus.get(item.id) : 'novo',
    updated_at: new Date().toISOString(),
  }));

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?on_conflict=id`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'resolution=merge-duplicates,return=representation' }),
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Falha ao salvar histórico (${res.status}): ${await res.text()}`);
  return res.json();
}

/** @returns {Promise<object[]>} */
async function list(token, { rangeLabel } = {}) {
  const filter = rangeLabel ? `&range_label=eq.${encodeURIComponent(rangeLabel)}` : '';
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*${filter}&order=prioridade_score.desc`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao listar histórico (${res.status}). A tabela ${TABLE} existe? Ver SQL pendente.`);
  return res.json();
}

async function updateStatus(token, id, status) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ status, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar status (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

module.exports = { stableId, upsertMany, list, updateStatus, TABLE };
