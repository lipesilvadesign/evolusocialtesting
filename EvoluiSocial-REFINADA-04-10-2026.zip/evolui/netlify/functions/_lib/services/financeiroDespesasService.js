/**
 * Financeiro — Despesas (contas a pagar da agência). Sem relação com
 * cliente/CRM — categorias fixas do vocabulário real de uma agência de
 * branding (pedido explícito, não uma lista genérica de ERP).
 */
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_financeiro_despesas';
const CATEGORIAS_VALIDAS = new Set([
  'google_ads', 'meta_ads', 'ferramentas', 'ia', 'adobe', 'hospedagem',
  'dominio', 'supabase', 'netlify', 'freelancers', 'equipe', 'estagio',
  'equipamentos', 'transporte', 'telefonia_internet', 'impostos',
  'servicos_terceirizados', 'marketing', 'capacitacao', 'administrativo', 'outros',
]);
const STATUS_VALIDOS = new Set(['previsto', 'pago', 'atrasado', 'cancelado']);

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/** @returns {Promise<object[]>} */
async function list(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&order=vencimento.asc`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao listar despesas (${res.status}). A tabela ${TABLE} existe? Ver SQL_PENDENTE_financeiro.sql.`);
  return res.json();
}

/**
 * @param {string} token
 * @param {{ categoria: string, descricao: string, fornecedor?: string, valor: number, vencimento: string, recorrente?: boolean, comprovanteUrl?: string, observacoes?: string, criadoPor: string }} payload
 */
async function create(token, payload) {
  if (!CATEGORIAS_VALIDAS.has(payload.categoria)) throw new Error(`Categoria inválida: ${payload.categoria}`);
  if (!payload.descricao || !payload.descricao.trim()) throw new Error('Descrição é obrigatória.');
  const valor = Number(payload.valor);
  if (!Number.isFinite(valor) || valor <= 0) throw new Error('Valor precisa ser um número maior que zero.');
  if (!payload.vencimento) throw new Error('Vencimento é obrigatório.');

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      categoria: payload.categoria,
      descricao: payload.descricao.trim(),
      fornecedor: payload.fornecedor || null,
      valor,
      vencimento: payload.vencimento,
      recorrente: Boolean(payload.recorrente),
      status: 'previsto',
      comprovante_url: payload.comprovanteUrl || null,
      observacoes: payload.observacoes || null,
      criado_por: payload.criadoPor,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao criar despesa (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/** @param {string} token @param {string} id @param {object} payload campos a atualizar */
async function update(token, id, payload) {
  const body = { updated_at: new Date().toISOString() };
  if (payload.status !== undefined) {
    if (!STATUS_VALIDOS.has(payload.status)) throw new Error(`Status inválido: ${payload.status}`);
    body.status = payload.status;
    body.pago_em = payload.status === 'pago' ? (payload.pagoEm || new Date().toISOString().slice(0, 10)) : null;
  }
  if (payload.categoria !== undefined) {
    if (!CATEGORIAS_VALIDAS.has(payload.categoria)) throw new Error(`Categoria inválida: ${payload.categoria}`);
    body.categoria = payload.categoria;
  }
  if (payload.valor !== undefined) {
    const v = Number(payload.valor);
    if (!Number.isFinite(v) || v <= 0) throw new Error('Valor precisa ser um número maior que zero.');
    body.valor = v;
  }
  if (payload.observacoes !== undefined) body.observacoes = payload.observacoes || null;
  if (payload.comprovanteUrl !== undefined) body.comprovante_url = payload.comprovanteUrl || null;

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar despesa (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  if (!rows[0]) throw new Error('Despesa não encontrada.');
  return rows[0];
}

async function remove(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao excluir despesa (${res.status}): ${await res.text()}`);
}

module.exports = { list, create, update, remove, CATEGORIAS_VALIDAS, STATUS_VALIDOS, TABLE };
