const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_tarefas';
const VALID_STATUS = new Set(['TODO', 'IN_PROGRESS', 'DONE']);

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/** @returns {Promise<object[]>} */
async function list(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&order=created_at.desc`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao listar tarefas (${res.status}). A tabela ${TABLE} existe? Ver SQL pendente.`);
  return res.json();
}

/**
 * @param {string} token
 * @param {{ titulo: string, descricao?: string, origemTipo?: string, origemReferencia?: object, prioridade?: string, criadoPor: string }} payload
 */
async function create(token, payload) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      titulo: payload.titulo,
      descricao: payload.descricao || null,
      status: 'TODO',
      origem_tipo: payload.origemTipo || 'manual',
      origem_referencia: payload.origemReferencia || null,
      prioridade: payload.prioridade || null,
      criado_por: payload.criadoPor,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao criar tarefa (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

async function updateStatus(token, id, status) {
  if (!VALID_STATUS.has(status)) throw new Error(`Status inválido: ${status}`);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ status, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar tarefa (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

async function remove(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao excluir tarefa (${res.status}): ${await res.text()}`);
}

module.exports = { list, create, updateStatus, remove, VALID_STATUS, TABLE };
