const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_notificacoes';

function headers(authToken, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${authToken}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} authToken - token do usuário OU a service role key (a Function agendada usa a segunda)
 * @param {{ tipo: 'anomalia'|'erro'|'oportunidade'|'sistema', titulo: string, mensagem: string, severidade: 'baixa'|'media'|'alta', metadata?: object }} entry
 */
async function create(authToken, entry) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(authToken, { Prefer: 'return=minimal' }),
    body: JSON.stringify({
      tipo: entry.tipo,
      titulo: entry.titulo,
      mensagem: entry.mensagem,
      severidade: entry.severidade,
      metadata: entry.metadata || {},
    }),
  });
  if (!res.ok) throw new Error(`Falha ao criar notificação (${res.status}): ${await res.text()}`);
}

/** @returns {Promise<object[]>} */
async function list(authToken, { onlyUnread = false, limit = 50 } = {}) {
  const filter = onlyUnread ? '&lida=eq.false' : '';
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*${filter}&order=created_at.desc&limit=${limit}`, {
    headers: headers(authToken),
  });
  if (!res.ok) throw new Error(`Falha ao listar notificações (${res.status}). A tabela ${TABLE} existe? Ver SQL pendente.`);
  return res.json();
}

async function markRead(authToken, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(authToken, { Prefer: 'return=minimal' }),
    body: JSON.stringify({ lida: true }),
  });
  if (!res.ok) throw new Error(`Falha ao marcar notificação como lida (${res.status}).`);
}

module.exports = { create, list, markRead, TABLE };
