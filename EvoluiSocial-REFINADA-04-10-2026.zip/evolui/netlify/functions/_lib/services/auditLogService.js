/**
 * Service de Auditoria — persistência REAL (etapa "Operação, Automação e
 * Escala"; antes era stub só de console.log). Tabela nova: admin_audit_log
 * (SQL pendente documentado). Mesmo padrão REST-com-token-do-usuário já
 * usado em collectionService.js/siteArrayService.js — RLS aplica como o
 * próprio usuário que fez a ação, nunca uma chave privilegiada.
 */

const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');
const logger = require('../logger');

const TABLE = 'admin_audit_log';

/**
 * @param {string} token - token de sessão do usuário que executou a ação
 * @param {{ actorId: string, action: 'create'|'update'|'delete'|'publish'|'unpublish'|'settings_change'|'permission_change'|'status_change', targetType: string, targetId?: string, metadata?: object }} entry
 * @returns {Promise<void>}
 */
async function record(token, entry) {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal',
      },
      body: JSON.stringify({
        actor_id: entry.actorId,
        action: entry.action,
        target_type: entry.targetType,
        target_id: entry.targetId || null,
        metadata: entry.metadata || {},
      }),
    });
    if (!res.ok) {
      // Falha ao auditar NUNCA derruba a ação principal (criar/editar
      // conteúdo continua funcionando mesmo sem log) — só registra o
      // problema pros logs da Function.
      logger.warn('auditLogService', 'Falha ao persistir log de auditoria', { status: res.status, action: entry.action });
    }
  } catch (err) {
    logger.warn('auditLogService', 'Erro ao persistir log de auditoria', { message: err.message, action: entry.action });
  }
}

/** @returns {Promise<object[]>} usado pela view de Sistema/Monitoramento */
async function list(token, { limit = 50 } = {}) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&order=created_at.desc&limit=${limit}`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(`Falha ao listar auditoria (${res.status}). A tabela ${TABLE} existe? Ver SQL pendente.`);
  return res.json();
}

module.exports = { record, list, TABLE };
