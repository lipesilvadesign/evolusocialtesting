const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_prospeccao_contatos';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {string} leadId
 * @returns {Promise<object[]>}
 */
async function listarPorLead(token, leadId) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?lead_id=eq.${encodeURIComponent(leadId)}&order=principal.desc,created_at.asc`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao listar contatos (${res.status}).`);
  return res.json();
}

/**
 * @param {string} token
 * @param {{ leadId: string, nome: string, cargo?: string, email?: string, whatsapp?: string, linkedin?: string, principal?: boolean, criadoPor?: string }} dados
 * @returns {Promise<object>}
 */
async function criar(token, dados) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      lead_id: dados.leadId,
      nome: dados.nome,
      cargo: dados.cargo || null,
      email: dados.email || null,
      whatsapp: dados.whatsapp || null,
      linkedin: dados.linkedin || null,
      principal: Boolean(dados.principal),
      criado_por: dados.criadoPor || null,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao criar contato (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/**
 * @param {string} token
 * @param {string} id
 */
async function remover(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao remover contato (${res.status}).`);
}

module.exports = { listarPorLead, criar, remover };
