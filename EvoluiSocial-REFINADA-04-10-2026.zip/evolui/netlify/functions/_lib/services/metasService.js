const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_metas_prospeccao';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * Metas visíveis pra quem chama (RLS: a própria pessoa vê as próprias;
 * admin vê de todo mundo). Sem filtro de período aqui — a tela decide o
 * que mostrar (mais recente por pessoa/periodo).
 * @param {string} token
 */
async function listar(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&order=referencia.desc`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao listar metas (${res.status}).`);
  return res.json();
}

/**
 * @param {string} token
 * @param {{ funcionarioId: string, periodo: 'semanal'|'mensal', referencia: string, meta: number, criadoPor: string }} payload
 */
async function definir(token, payload) {
  if (!payload.funcionarioId) throw new Error('Informe "funcionarioId".');
  if (!['semanal', 'mensal'].includes(payload.periodo)) throw new Error(`Período inválido: ${payload.periodo}`);
  if (!payload.referencia) throw new Error('Informe "referencia" (data).');
  const meta = Number(payload.meta);
  if (!Number.isInteger(meta) || meta <= 0) throw new Error('"meta" precisa ser um número inteiro maior que zero.');

  // upsert manual (on_conflict) — permite redefinir a meta de uma
  // semana/mês que já tinha meta, sem duplicar linha (unique
  // funcionario_id+periodo+referencia já garante isso no banco).
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?on_conflict=funcionario_id,periodo,referencia`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'resolution=merge-duplicates,return=representation' }),
    body: JSON.stringify({
      funcionario_id: payload.funcionarioId,
      periodo: payload.periodo,
      referencia: payload.referencia,
      meta,
      criado_por: payload.criadoPor,
      updated_at: new Date().toISOString(),
    }),
  });
  if (!res.ok) throw new Error(`Falha ao definir meta (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

module.exports = { listar, definir };
