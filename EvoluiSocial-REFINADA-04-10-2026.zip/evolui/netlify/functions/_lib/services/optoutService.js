const { normalizarNome, onlyDigits } = require('../templateUtil');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_prospeccao_optouts';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {{ email?: string, telefone?: string, origemId?: string, motivo?: string, criadoPor?: string }} dados
 */
async function registrar(token, dados) {
  if (!dados.email && !dados.telefone && !dados.origemId) {
    throw new Error('Opt-out precisa de pelo menos e-mail, telefone ou origem_id pra identificar quem bloquear.');
  }
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      email: dados.email || null,
      telefone: dados.telefone || null,
      origem_id: dados.origemId || null,
      motivo: dados.motivo || null,
      criado_por: dados.criadoPor || null,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao registrar opt-out (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/**
 * Carrega toda a lista de opt-out de uma vez, em três Sets (email/telefone/
 * origemId) — usado pra checagem em lote (busca manual, envio de e-mail),
 * evitando uma consulta por lead.
 * @param {string} token
 * @returns {Promise<{ emails: Set<string>, telefones: Set<string>, origemIds: Set<string> }>}
 */
async function carregarBloqueios(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=email,telefone,origem_id`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao carregar opt-outs (${res.status}).`);
  const rows = await res.json();
  return {
    emails: new Set(rows.map((r) => normalizarNome(r.email)).filter(Boolean)),
    telefones: new Set(rows.map((r) => onlyDigits(r.telefone)).filter(Boolean)),
    origemIds: new Set(rows.map((r) => r.origem_id).filter(Boolean)),
  };
}

module.exports = { registrar, carregarBloqueios };
