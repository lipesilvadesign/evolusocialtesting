/**
 * Service da Consultoria Gratuita de Perfil para Instagram (/consultas —
 * ETAPA 2). Mesmo padrão REST-com-token-do-usuário já usado em
 * prospeccaoService.js — RLS aplica como o próprio usuário autenticado,
 * nunca uma chave privilegiada. A criação do lead (feita pelo visitante,
 * sem login) NÃO passa por aqui — ver netlify/functions/consultas-criar.js,
 * que usa a chave anônima diretamente (mesma chave pública de sempre, sob
 * a política RLS restrita "anon_insert_consultas_leads").
 */

const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'consultas_leads';
const VALID_STATUS = new Set([
  'novo',
  'analisando',
  'analise_enviada',
  'contatado',
  'reuniao_agendada',
  'convertido',
  'arquivado',
]);

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {{ status?: string }} [filtros]
 * @returns {Promise<object[]>}
 */
async function list(token, filtros = {}) {
  const params = new URLSearchParams({ select: '*', order: 'created_at.desc' });
  if (filtros.status) params.set('status', `eq.${filtros.status}`);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?${params.toString()}`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao listar consultorias (${res.status}). A tabela ${TABLE} existe? Ver SQL_PENDENTE_consultas.sql.`);
  return res.json();
}

/**
 * @param {string} token
 * @param {string} id
 * @returns {Promise<object|null>}
 */
async function getById(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}&select=*`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao buscar consultoria (${res.status}).`);
  const rows = await res.json();
  return rows[0] || null;
}

/**
 * Atualiza campos administrativos de um lead (status, observações, contato
 * realizado etc). Só os campos presentes no payload são alterados.
 * @param {string} token
 * @param {string} id
 * @param {{ status?: string, observacoesInternas?: string, contatoRealizado?: boolean,
 *   ultimoContatoEm?: string, atualizadoPor?: string }} payload
 */
async function update(token, id, payload) {
  if (payload.status && !VALID_STATUS.has(payload.status)) throw new Error(`Status inválido: ${payload.status}`);
  const body = { updated_at: new Date().toISOString() };
  const map = {
    status: 'status',
    observacoesInternas: 'observacoes_internas',
    contatoRealizado: 'contato_realizado',
    ultimoContatoEm: 'ultimo_contato_em',
    atualizadoPor: 'atualizado_por',
  };
  for (const [key, column] of Object.entries(map)) {
    if (Object.prototype.hasOwnProperty.call(payload, key)) body[column] = payload[key];
  }
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar consultoria (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/** @param {string} token @param {string} id */
async function remove(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao excluir consultoria (${res.status}): ${await res.text()}`);
}

module.exports = { list, getById, update, remove, VALID_STATUS, TABLE };
