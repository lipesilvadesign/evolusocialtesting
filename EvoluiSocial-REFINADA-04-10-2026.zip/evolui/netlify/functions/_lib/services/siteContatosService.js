/**
 * Contatos do formulário "Vamos conversar" da home (tabela site_contatos —
 * ver SQL_PENDENTE_site_contatos.sql). Três quem-chama diferentes:
 *   - contato-criar.js (público, chave anônima): cria e avisa por e-mail;
 *   - contatos-site.js (painel, token do usuário): lista/atualiza/reenvia;
 *   - scheduled-sync-background.js (job, service role): confere pendentes.
 */

const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');
const { enviarEmail } = require('../integrations/umblerSmtp');
const { env, getEnv } = require('../config/env');

const TABLE = 'site_contatos';
// 30/09: a caixa real da Umbler é marketing@ (contato@ não autentica).
const DESTINO_PADRAO = 'marketing@felipebranding.com.br';
const STATUS = new Set(['novo', 'em_atendimento', 'respondido', 'convertido', 'arquivado']);
const SERVICOS = new Set(['Identidade Visual', 'Design Gráfico', 'Produção de Vídeo', 'Consultoria de Redes Sociais', 'Não sei ainda']);
const ORCAMENTOS = { 'ate-3k': 'Até R$3 mil', '3-8k': 'R$3 a 8 mil', '8k+': 'Acima de R$8 mil' };

function headers(token, extra = {}) {
  return { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...extra };
}

function destinoAviso() {
  // Sem destino próprio configurado, o aviso vai para a mesma caixa que envia
  // (UMBLER_SMTP_USER) — assim nunca aponta para uma caixa que não existe.
  return getEnv('CONTATO_EMAIL_DESTINO') || env.email.smtpUser() || DESTINO_PADRAO;
}

function smtpConfigurado() {
  return Boolean(env.email.smtpUser() && env.email.smtpPass());
}

/** Valida e normaliza o que veio do formulário. @returns {{ dados?: object, erros?: object }} */
function validar(payload = {}) {
  const nome = String(payload.nome || '').trim().replace(/\s+/g, ' ').slice(0, 120);
  const email = String(payload.email || '').trim().toLowerCase().slice(0, 180);
  const whatsapp = String(payload.whatsapp || '').replace(/\D/g, '').slice(0, 13);
  const servico = String(payload.servico || '').trim();
  const orcamento = Object.prototype.hasOwnProperty.call(ORCAMENTOS, payload.orcamento) ? payload.orcamento : null;
  const mensagem = String(payload.mensagem || '').trim().slice(0, 2000);

  const erros = {};
  if (nome.length < 2) erros.nome = 'Digite seu nome.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) erros.email = 'Digite um e-mail válido.';
  if (whatsapp.length < 10 || whatsapp.length > 13) erros.whatsapp = 'Digite um WhatsApp válido, com DDD.';
  if (!SERVICOS.has(servico)) erros.servico = 'Selecione um serviço.';
  if (mensagem.length < 8) erros.mensagem = 'Conte um pouco mais sobre o projeto.';
  if (Object.keys(erros).length) return { erros };

  return { dados: { nome, email, whatsapp, servico, orcamento, mensagem, origem: 'home' } };
}

function formatarWhatsapp(digitos) {
  const d = String(digitos || '').replace(/^55(?=\d{10,11}$)/, '');
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return d;
}

/** E-mail em texto simples (mesma regra de umblerSmtp.js: sem HTML). */
function montarAviso(contato) {
  const whats = String(contato.whatsapp || '').replace(/\D/g, '');
  const linkWhats = `https://wa.me/${whats.startsWith('55') ? whats : `55${whats}`}`;
  const quando = new Date(contato.created_at || Date.now()).toLocaleString('pt-BR', { timeZone: 'America/Recife' });
  return {
    assunto: `Novo contato pelo site: ${contato.nome} (${contato.servico})`,
    corpo: [
      'Chegou um novo contato pelo formulário "Vamos conversar" do site.',
      '',
      `Nome: ${contato.nome}`,
      `E-mail: ${contato.email}`,
      `WhatsApp: ${formatarWhatsapp(contato.whatsapp)} — ${linkWhats}`,
      `Serviço: ${contato.servico}`,
      `Investimento: ${ORCAMENTOS[contato.orcamento] || 'não informado'}`,
      `Recebido em: ${quando}`,
      '',
      'Mensagem:',
      contato.mensagem,
      '',
      '—',
      'Responda este e-mail para falar direto com o visitante.',
      'Todos os contatos ficam no painel: https://felipebranding.com.br/painel/#/contatos-site',
    ].join('\n'),
  };
}

/**
 * Manda o aviso. Nunca lança: devolve o resultado para ser registrado.
 * @returns {Promise<{ status: 'enviado'|'falhou'|'sem_smtp', erro?: string }>}
 */
async function enviarAviso(contato, { timeoutMs } = {}) {
  if (!smtpConfigurado()) {
    return { status: 'sem_smtp', erro: 'UMBLER_SMTP_USER/UMBLER_SMTP_PASS não configurados no Netlify.' };
  }
  try {
    const { assunto, corpo } = montarAviso(contato);
    await enviarEmail({ para: destinoAviso(), assunto, corpo, responderPara: contato.email, timeoutMs });
    return { status: 'enviado' };
  } catch (err) {
    return { status: 'falhou', erro: String(err && err.message ? err.message : err).slice(0, 300) };
  }
}

/** Grava pelo papel anônimo (a política só deixa escrever os campos do formulário). */
async function criarPublico(id, dados) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(SUPABASE_ANON_KEY, { Prefer: 'return=minimal' }),
    body: JSON.stringify({ id, ...dados }),
  });
  if (!res.ok) {
    const texto = await res.text().catch(() => '');
    const err = new Error(`Falha ao gravar contato (${res.status}).`);
    err.detalhe = texto.slice(0, 300);
    throw err;
  }
}

async function rpc(token, nome, corpo) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${nome}`, {
    method: 'POST',
    headers: headers(token),
    body: JSON.stringify(corpo),
  });
  if (!res.ok) throw new Error(`Falha ao registrar resultado do e-mail (${res.status}).`);
  return res.json();
}

/** Primeiro aviso, logo depois de criar (chave anônima; RPC travada a 15 min). */
function registrarAvisoInicial(id, resultado) {
  return rpc(SUPABASE_ANON_KEY, 'site_contato_registrar_email', { p_id: id, p_status: resultado.status, p_erro: resultado.erro || null });
}

/** Reenvio manual pelo painel (token do usuário; RPC confere se é equipe comercial). */
function registrarReenvio(token, id, resultado) {
  return rpc(token, 'site_contato_registrar_reenvio', { p_id: id, p_status: resultado.status, p_erro: resultado.erro || null });
}

async function list(token, { status } = {}) {
  const params = new URLSearchParams({ select: '*', order: 'created_at.desc', limit: '500' });
  if (status && STATUS.has(status)) params.set('status', `eq.${status}`);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?${params}`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao listar contatos do site (${res.status}). A tabela ${TABLE} existe? Ver SQL_PENDENTE_site_contatos.sql.`);
  return res.json();
}

async function getById(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}&select=*`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao buscar contato (${res.status}).`);
  const rows = await res.json();
  return rows[0] || null;
}

async function update(token, id, payload, atualizadoPor) {
  const body = { updated_at: new Date().toISOString(), atualizado_por: atualizadoPor || null };
  if (Object.prototype.hasOwnProperty.call(payload, 'status')) {
    if (!STATUS.has(payload.status)) throw new Error('Status inválido.');
    body.status = payload.status;
  }
  if (Object.prototype.hasOwnProperty.call(payload, 'observacoesInternas')) {
    const obs = payload.observacoesInternas == null ? null : String(payload.observacoesInternas).slice(0, 4000);
    body.observacoes_internas = obs && obs.trim() ? obs : null;
  }
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar contato (${res.status}).`);
  const rows = await res.json();
  if (!rows[0]) throw new Error('Contato não encontrado ou sem permissão.');
  return rows[0];
}

async function remove(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: headers(token, { Prefer: 'return=representation' }),
  });
  if (!res.ok) throw new Error(`Falha ao excluir contato (${res.status}).`);
  const rows = await res.json();
  if (!rows[0]) throw new Error('Só administradores podem excluir contatos.');
}

module.exports = {
  TABLE,
  ORCAMENTOS,
  validar,
  montarAviso,
  enviarAviso,
  smtpConfigurado,
  destinoAviso,
  criarPublico,
  registrarAvisoInicial,
  registrarReenvio,
  list,
  getById,
  update,
  remove,
};
