const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_prospeccao_atividades';
const LEADS_TABLE = 'admin_prospeccao_leads';

const TIPOS_VALIDOS = [
  'email_enviado', 'whatsapp_enviado', 'ligacao', 'follow_up', 'resposta_recebida',
  'reuniao_marcada', 'reuniao_realizada', 'proposta_enviada', 'negociacao', 'nota',
  'mudanca_status',
  'briefing_atualizado', 'diagnostico_criado', 'diagnostico_publicado', 'apresentacao_enviada',
];

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {string} leadId
 * @returns {Promise<object[]>}
 */
async function listarPorLead(token, leadId) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?lead_id=eq.${encodeURIComponent(leadId)}&order=data.desc`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao listar atividades (${res.status}).`);
  return res.json();
}

/**
 * Cria a atividade E atualiza ultima_atividade_em/proxima_atividade_em no
 * lead (duas escritas, não uma transação — Supabase REST não expõe
 * transação multi-tabela; na pior hipótese de falha entre as duas, a
 * atividade fica registrada mas o resumo no lead não atualiza, o que é
 * visível e corrigível, nunca um dado inconsistente silencioso).
 * @param {string} token
 * @param {{ leadId: string, tipo: string, descricao?: string, data?: string, proximaEm?: string,
 *   criadoPor?: string, statusAnterior?: string, statusNovo?: string }} dados
 * @returns {Promise<object>}
 */
async function criar(token, dados) {
  if (!TIPOS_VALIDOS.includes(dados.tipo)) {
    throw new Error(`Tipo de atividade inválido: "${dados.tipo}".`);
  }
  const dataAtividade = dados.data || new Date().toISOString();

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      lead_id: dados.leadId,
      tipo: dados.tipo,
      descricao: dados.descricao || null,
      data: dataAtividade,
      proxima_em: dados.proximaEm || null,
      objecao: dados.objecao || null,
      criado_por: dados.criadoPor || null,
      // Aditivo (ver SQL_PENDENTE_estados_rapidos.sql) — usado pela timeline
      // pra mostrar "status alterado de X para Y" sem depender de texto
      // livre em `descricao`. Fica null pra atividades que não mudam status.
      status_anterior: dados.statusAnterior || null,
      status_novo: dados.statusNovo || null,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao registrar atividade (${res.status}): ${await res.text()}`);
  const rows = await res.json();

  const resUpdate = await fetch(`${SUPABASE_URL}/rest/v1/${LEADS_TABLE}?id=eq.${encodeURIComponent(dados.leadId)}`, {
    method: 'PATCH',
    headers: headers(token),
    body: JSON.stringify({
      ultima_atividade_em: dataAtividade,
      ...(dados.proximaEm ? { proxima_atividade_em: dados.proximaEm } : {}),
    }),
  });
  if (!resUpdate.ok) throw new Error(`Atividade registrada, mas falha ao atualizar o lead (${resUpdate.status}).`);

  return rows[0];
}

module.exports = { listarPorLead, criar, TIPOS_VALIDOS };
