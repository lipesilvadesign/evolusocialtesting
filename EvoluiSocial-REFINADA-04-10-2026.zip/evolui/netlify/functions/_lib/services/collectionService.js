const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

// Únicas tabelas que este service tem permissão de tocar — qualquer outro
// nome é rejeitado, mesmo que alguém chame a Function com um "type" forjado.
const ALLOWED_TABLES = new Set(['admin_posts', 'admin_pages']);

function restHeaders(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

function assertTable(table) {
  if (!ALLOWED_TABLES.has(table)) throw new Error(`Tabela não permitida: ${table}`);
}

/** @returns {Promise<object[]>} */
async function list(token, table) {
  assertTable(table);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?select=*&order=updated_at.desc`, {
    headers: restHeaders(token),
  });
  if (!res.ok) throw new Error(`Falha ao listar ${table} (${res.status}). A tabela existe? Ver SQL pendente.`);
  return res.json();
}

/** @returns {Promise<object>} */
async function create(token, table, payload) {
  assertTable(table);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method: 'POST',
    headers: restHeaders(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Falha ao criar em ${table} (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/** @returns {Promise<object>} */
async function update(token, table, id, payload) {
  assertTable(table);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: restHeaders(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ ...payload, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar ${table} (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

async function remove(token, table, id) {
  assertTable(table);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: restHeaders(token),
  });
  if (!res.ok) throw new Error(`Falha ao excluir em ${table} (${res.status}): ${await res.text()}`);
}

module.exports = { list, create, update, remove, ALLOWED_TABLES };
