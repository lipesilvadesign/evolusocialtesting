/**
 * Intelligence Service.
 *
 * Orquestra a "Inteligência Avançada": busca dados (reaproveitando
 * analyticsService.getInsightsSnapshot + getDailyTimeSeries, já
 * existentes), processa pelos motores puros (normalizer, insightsEngine —
 * reaproveitados — e os novos: historicalAverages, anomalyEngine,
 * correlationEngine, healthScoreEngine, opportunityEngine), e persiste as
 * oportunidades no histórico real (intelligenceHistoryService), com
 * upsert por id estável pra preservar o status que o usuário já tenha
 * definido numa chamada anterior.
 */

const analyticsService = require('./analyticsService');
const { normalizeSnapshot } = require('../analyticsNormalizer');
const { generateInsights } = require('../insightsEngine');
const { computeHistoricalAverages } = require('../historicalAverages');
const { detectAnomalies } = require('../anomalyEngine');
const { findCorrelations } = require('../correlationEngine');
const { computeHealthScore } = require('../healthScoreEngine');
const { deriveOpportunities } = require('../opportunityEngine');
const { resolveDateRange } = require('../dateRange');
const intelligenceHistoryService = require('./intelligenceHistoryService');

const TIME_SERIES_DAYS = 90;

/**
 * @param {string} token - token de sessão do usuário (repassado pro histórico, RLS aplica como ele)
 * @param {object} rangeQuery
 * @returns {Promise<object>} AdvancedIntelligence — tudo que a UI e a IA precisam
 */
async function computeAdvancedIntelligence(token, rangeQuery) {
  const { label: rangeLabel } = resolveDateRange(rangeQuery);

  const [rawSnapshot, timeSeries] = await Promise.all([
    analyticsService.getInsightsSnapshot(rangeQuery),
    analyticsService.getDailyTimeSeries(TIME_SERIES_DAYS),
  ]);

  const normalized = normalizeSnapshot(rawSnapshot);
  const deterministicInsights = generateInsights(normalized);
  const historicalAverages = computeHistoricalAverages(timeSeries);
  const anomalies = detectAnomalies(timeSeries);
  const correlations = findCorrelations(normalized);
  const healthScore = computeHealthScore(normalized);
  const opportunitiesRaw = deriveOpportunities(deterministicInsights, anomalies, healthScore);

  const opportunityItems = opportunitiesRaw.map((o) => ({
    id: intelligenceHistoryService.stableId('oportunidade', o.title, rangeLabel),
    tipo: 'oportunidade',
    titulo: o.title,
    descricao: o.description,
    evidencia: o.evidence,
    impacto: o.impact,
    esforco: o.effort,
    prioridade_score: o.priorityScore,
    range_label: rangeLabel,
  }));

  let opportunitiesWithStatus = opportunitiesRaw.map((o) => ({ ...o, status: 'novo', id: null }));
  try {
    const saved = await intelligenceHistoryService.upsertMany(token, opportunityItems);
    const byId = new Map(saved.map((r) => [r.id, r]));
    opportunitiesWithStatus = opportunityItems.map((item, i) => {
      const row = byId.get(item.id);
      return { ...opportunitiesRaw[i], id: item.id, status: row ? row.status : 'novo' };
    });
  } catch (err) {
    // Falha ao persistir não derruba a resposta inteira — a UI ainda mostra
    // as oportunidades calculadas, só sem controle de status funcional até
    // a tabela existir/RLS liberar (ver SQL pendente na documentação).
    console.error('[intelligenceService] falha ao persistir histórico:', err.message);
  }

  return {
    rangeLabel,
    timeSeriesDays: timeSeries.length,
    normalized,
    deterministicInsights,
    historicalAverages,
    anomalies,
    correlations,
    healthScore,
    opportunities: opportunitiesWithStatus,
  };
}

module.exports = { computeAdvancedIntelligence, TIME_SERIES_DAYS };
