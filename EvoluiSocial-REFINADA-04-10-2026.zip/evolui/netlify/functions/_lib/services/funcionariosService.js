const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_funcionarios';
const ROLES_VALIDAS = new Set(['admin', 'prospeccao', 'design']);
const GENEROS_VALIDOS = new Set(['masculino', 'feminino']);
// Ids da galeria de avatares ilustrados (ver AVATARES_DISPONIVEIS em
// painel/assets/js/components/avatarIlustrado.js) — mantidos em sincronia
// manualmente, mesma lógica de ROLES_VALIDAS/GENEROS_VALIDOS acima.
const AVATARES_VALIDOS = new Set(['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8', 'a9', 'a10']);

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * Lista funcionários — a RLS já decide o que volta: admin vê todo mundo,
 * qualquer outra pessoa só vê a PRÓPRIA linha. Esta função não filtra nada
 * sozinha — não precisa, e não deveria (é a RLS que é a barreira real).
 * @param {string} token
 * @returns {Promise<object[]>}
 */
async function listar(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&order=created_at.asc`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao listar funcionários (${res.status}).`);
  return res.json();
}

/**
 * Atualiza um funcionário. Desde 13/09 (2ª rodada), a RLS permite tanto o
 * admin quanto o DONO DA LINHA chamar isto (antes, só admin). Um trigger no
 * banco (admin_funcionarios_protege_colunas_sensiveis, ver
 * SQL_FIX_completo_13_09.sql §4c) ignora silenciosamente qualquer tentativa
 * de mudar role/ativo/email/criado_por vinda de quem não é admin — mesmo
 * que estes campos venham no payload, não é este código que impede isso,
 * é o banco (defesa em profundidade: mesmo um bug aqui não escala
 * privilégio). role/ativo continuam de uso exclusivo da tela Equipe
 * (admin); nome/biografia/fotoUrl/tempoExperiencia/funcoes/genero também
 * são usados pela nova página "Meu Perfil" (autoedição).
 * @param {string} token
 * @param {string} id
 * @param {{ nome?: string, role?: string, ativo?: boolean, fotoUrl?: string, tempoExperiencia?: string, funcoes?: string, genero?: string, avatarEscolhido?: string, biografia?: string, muralUltimaLeitura?: string }} payload
 */
async function atualizar(token, id, payload) {
  if (payload.role && !ROLES_VALIDAS.has(payload.role)) throw new Error(`Papel inválido: ${payload.role}`);
  if (payload.genero && !GENEROS_VALIDOS.has(payload.genero)) throw new Error(`Gênero inválido: ${payload.genero}`);
  if (payload.avatarEscolhido && !AVATARES_VALIDOS.has(payload.avatarEscolhido)) throw new Error(`Avatar inválido: ${payload.avatarEscolhido}`);
  if (payload.biografia !== undefined && payload.biografia !== null && payload.biografia.length > 500) {
    throw new Error('Biografia muito longa (máximo 500 caracteres).');
  }
  const body = { updated_at: new Date().toISOString() };
  if (payload.nome !== undefined) body.nome = payload.nome;
  if (payload.role !== undefined) body.role = payload.role;
  if (payload.ativo !== undefined) body.ativo = payload.ativo;
  if (payload.fotoUrl !== undefined) body.foto_url = payload.fotoUrl;
  if (payload.tempoExperiencia !== undefined) body.tempo_experiencia = payload.tempoExperiencia;
  if (payload.funcoes !== undefined) body.funcoes = payload.funcoes;
  if (payload.genero !== undefined) body.genero = payload.genero || null;
  if (payload.avatarEscolhido !== undefined) body.avatar_escolhido = payload.avatarEscolhido || null;
  if (payload.biografia !== undefined) body.biografia = payload.biografia || null;
  if (payload.muralUltimaLeitura !== undefined) body.mural_ultima_leitura = payload.muralUltimaLeitura;

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    // Se a policy de RLS bloquear (quem chamou não é admin nem dono da
    // linha), o Postgres simplesmente não altera nenhuma linha — não é um
    // erro de rede, é "0 linhas afetadas". Tratamos os dois casos como
    // falha explícita.
    throw new Error(`Falha ao atualizar funcionário (${res.status}): ${await res.text()}`);
  }
  const rows = await res.json();
  if (!rows[0]) throw new Error('Você não tem permissão para alterar este funcionário, ou ele não existe.');
  return rows[0];
}

module.exports = { listar, atualizar, ROLES_VALIDAS };
