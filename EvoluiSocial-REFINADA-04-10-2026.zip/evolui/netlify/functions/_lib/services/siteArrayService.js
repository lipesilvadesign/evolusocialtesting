const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

// "projetos" e "servicos" são só apelidos em português pro que já existe
// no site_content — não são tabelas novas. Isto NÃO duplica o sistema do
// admin.html: os dois editam a mesma linha, o mesmo array.
const TYPE_KEY = { projetos: 'portfolio', servicos: 'services', parceiros: 'partners' };

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

function assertType(type) {
  if (!TYPE_KEY[type]) throw new Error(`Tipo não suportado: ${type}`);
  return TYPE_KEY[type];
}

async function readContent(token) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/site_content?select=content&id=eq.1`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao ler site_content (${res.status}).`);
  const rows = await res.json();
  return (rows[0] && rows[0].content) || {};
}

async function writeArray(token, key, array) {
  const content = await readContent(token);
  content[key] = array;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/site_content?id=eq.1`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ content }),
  });
  if (!res.ok) throw new Error(`Falha ao salvar site_content (${res.status}): ${await res.text()}`);
  return array;
}

function randomId() {
  return globalThis.crypto && globalThis.crypto.randomUUID
    ? globalThis.crypto.randomUUID()
    : `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

/**
 * Itens antigos (criados antes desta etapa, pelo admin.html) não têm `id`.
 * Preenche na primeira leitura e persiste, pra edição/exclusão por id
 * funcionar de forma estável daqui pra frente.
 */
async function list(token, type) {
  const key = assertType(type);
  const content = await readContent(token);
  const raw = content[key] || [];
  let changed = false;
  const withIds = raw.map((item) => {
    if (item.id) return item;
    changed = true;
    return { id: randomId(), ...item };
  });
  if (changed) await writeArray(token, key, withIds);
  return withIds;
}

async function create(token, type, payload) {
  const key = assertType(type);
  const items = await list(token, type);
  const item = { id: randomId(), status: 'rascunho', ...payload };
  items.push(item);
  await writeArray(token, key, items);
  return item;
}

async function update(token, type, id, payload) {
  const key = assertType(type);
  const items = await list(token, type);
  const idx = items.findIndex((i) => i.id === id);
  if (idx === -1) throw new Error('Item não encontrado.');
  items[idx] = { ...items[idx], ...payload, id };
  await writeArray(token, key, items);
  return items[idx];
}

async function remove(token, type, id) {
  const key = assertType(type);
  const items = await list(token, type);
  const next = items.filter((i) => i.id !== id);
  await writeArray(token, key, next);
}

module.exports = { list, create, update, remove, TYPE_KEY };
