/**
 * Gerador de diagnóstico por IA (PROMPT 5, item 1). Reaproveita o núcleo
 * genérico de aiProvider.js (callClaudeTool) — a mesma infraestrutura já
 * usada pela análise de marketing/GA4, só com um prompt e schema próprios.
 *
 * A IA só recebe o que já está cadastrado (briefing + métricas do cliente)
 * — nunca é solicitada a "pesquisar" ou "saber" algo sobre a empresa. O
 * rascunho gerado preenche DADO FORNECIDO / CÁLCULO / ANÁLISE DA IA /
 * RECOMENDAÇÃO (nunca ANÁLISE DO ESPECIALISTA — essa seção é só humana, por
 * design, desde o PROMPT 2).
 */

const aiProvider = require('../integrations/aiProvider');
const aiHistoryService = require('./aiHistoryService');
const { validateDiagnosticoAiResponse } = require('../diagnosticoAiSchema');

const PROMPT_VERSION = 'diagnostico-v1';

const TOOL_NAME = 'submit_diagnostico_draft';

const TOOL_INPUT_SCHEMA = {
  type: 'object',
  properties: {
    dados_insuficientes: { type: 'boolean' },
    dado_fornecido: {
      type: 'array',
      items: { type: 'string' },
      description: 'Lista de fatos, tal como fornecidos — sem interpretação. Cada item deve ser rastreável a um campo do briefing ou uma métrica recebida.',
    },
    calculo: {
      type: 'array',
      items: {
        type: 'object',
        properties: { formula: { type: 'string' }, resultado: { type: 'string' } },
        required: ['formula', 'resultado'],
      },
      description: 'Só contas feitas EM CIMA dos dados recebidos (ex.: variação percentual entre duas métricas fornecidas). Vazio se não houver dados numéricos suficientes para nenhuma conta.',
    },
    interpretacao: {
      type: 'string',
      description: 'Leitura do que os dados acima sugerem — nunca inventa números novos, nunca cita concorrentes ou fatos não fornecidos.',
    },
    recomendacao: {
      type: 'string',
      description: 'Recomendação prática, ancorada no que foi fornecido.',
    },
    motivo_dados_insuficientes: { type: 'string', description: 'Preenchido só quando dados_insuficientes=true.' },
  },
  required: ['dados_insuficientes', 'dado_fornecido', 'calculo', 'interpretacao', 'recomendacao'],
};

const SYSTEM_PROMPT = `Você é um analista de branding e marketing ajudando a preparar um diagnóstico estratégico de marca para um cliente da Felipe Branding.

REGRAS OBRIGATÓRIAS, SEM EXCEÇÃO:
- Use SOMENTE os dados fornecidos no contexto (briefing preenchido pelo cliente e métricas registradas manualmente). NUNCA invente números de crescimento, métricas, informações sobre a empresa, concorrentes, resultados ou qualquer fato que não esteja explicitamente no contexto recebido.
- Se um campo do briefing estiver vazio ou uma métrica não existir, NÃO invente um valor plausível — declare explicitamente que aquele dado não está disponível.
- "calculo" só pode conter contas que usem números que JÁ ESTÃO no contexto recebido (ex.: diferença entre dois valores da mesma métrica em períodos diferentes). Se não houver pelo menos duas métricas numéricas comparáveis, deixe "calculo" como lista vazia — não invente uma fórmula sem números reais para aplicar.
- "interpretacao" é sua leitura do que os dados sugerem, nunca uma alegação de fato novo. Nunca afirme ter pesquisado a empresa, o mercado ou concorrentes — você só tem o que foi passado no contexto.
- Se o contexto tiver menos que o mínimo pra qualquer leitura útil (briefing vazio E nenhuma métrica), defina dados_insuficientes=true, explique o motivo, e ainda assim preencha os outros campos com listas/textos vazios (nunca omita campos obrigatórios).
- Responda SOMENTE através da ferramenta submit_diagnostico_draft — nunca em texto livre.`;

/**
 * @param {{ empresa: string, setor?: string, briefing?: object, metricas?: object[] }} contexto
 * @param {string} token - token do usuário (admin, já verificado pela Function) — usado só pra registrar o uso em admin_ai_usage
 * @param {string} geradoPorEmail
 * @returns {Promise<object>} rascunho validado, pronto pra popular o formulário (o usuário ainda revisa/edita/salva)
 */
async function gerarRascunho(contexto, token, geradoPorEmail) {
  const userContent = JSON.stringify({
    empresa: contexto.empresa,
    setor: contexto.setor || null,
    briefing: contexto.briefing || null,
    metricas: (contexto.metricas || []).map((m) => ({
      nome: m.nome,
      valor: m.valor,
      valor_texto: m.valor_texto,
      unidade: m.unidade,
      periodo: m.periodo,
      origem: m.origem,
    })),
  });

  const model = process.env.AI_MODEL || aiProvider.DEFAULT_MODEL;
  const { result: raw, usage } = await aiProvider.callClaudeTool({
    systemPrompt: SYSTEM_PROMPT,
    toolName: TOOL_NAME,
    toolDescription: 'Envia o rascunho de diagnóstico estruturado.',
    inputSchema: TOOL_INPUT_SCHEMA,
    userContent,
    maxTokens: 1400,
  });

  const validado = validateDiagnosticoAiResponse(raw);

  const dadosUsados = [
    ...(contexto.briefing ? ['briefing'] : []),
    ...(contexto.metricas || []).map((m) => `metrica:${m.nome}`),
  ];

  await aiHistoryService.record(token, {
    rangeLabel: `diagnostico:${contexto.empresa}`,
    promptVersion: PROMPT_VERSION,
    model,
    metricsUsed: dadosUsados,
    recommendationCount: validado.recomendacao ? 1 : 0,
    cacheHit: false,
    tokensInput: usage.tokensInput,
    tokensOutput: usage.tokensOutput,
    geradoPor: geradoPorEmail,
  });

  return { ...validado, meta: { geradoEm: new Date().toISOString(), promptVersion: PROMPT_VERSION, model, geradoPor: geradoPorEmail } };
}

module.exports = { gerarRascunho, PROMPT_VERSION };
