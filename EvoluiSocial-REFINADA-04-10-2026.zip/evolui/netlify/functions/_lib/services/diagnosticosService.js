const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_diagnosticos';

// As 5 seções pedidas — sempre nesta ordem na interface. Cada seção guarda
// { texto, visibilidade } dentro de `conteudo`; visibilidade é sempre
// 'interna' por padrão (nunca publica nada pro cliente sem decisão explícita).
const SECOES = ['dado_fornecido', 'calculo', 'analise_ia', 'analise_especialista', 'recomendacao'];

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * @param {string} token
 * @param {string} leadId
 * @returns {Promise<object[]>} todas as versões, mais recente primeiro
 */
async function listarPorLead(token, leadId) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/${TABLE}?lead_id=eq.${encodeURIComponent(leadId)}&select=*&order=versao.desc`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error(`Falha ao listar diagnósticos (${res.status}).`);
  return res.json();
}

/**
 * Cria uma nova versão (v1, v2, v3...) — nunca edita uma versão publicada.
 * @param {string} token
 * @param {string} leadId
 * @param {string} criadoPor
 * @returns {Promise<object>}
 */
async function criarNovaVersao(token, leadId, criadoPor) {
  const existentes = await listarPorLead(token, leadId);
  const proximaVersao = existentes.length ? Math.max(...existentes.map((d) => d.versao)) + 1 : 1;
  const conteudoVazio = Object.fromEntries(SECOES.map((s) => [s, { texto: '', visibilidade: 'interna' }]));

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({
      lead_id: leadId,
      versao: proximaVersao,
      status: 'rascunho',
      conteudo: conteudoVazio,
      criado_por: criadoPor,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao criar nova versão do diagnóstico (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/**
 * Atualiza o conteúdo de uma versão — só permitido enquanto ela for
 * 'rascunho'. Uma vez publicada, o histórico fica congelado (crie uma nova
 * versão pra continuar editando).
 * @param {string} token
 * @param {string} id
 * @param {object} conteudo
 */
async function atualizarConteudo(token, id, conteudo) {
  const resAtual = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}&select=status`, {
    headers: headers(token),
  });
  if (!resAtual.ok) throw new Error(`Falha ao verificar diagnóstico (${resAtual.status}).`);
  const atual = (await resAtual.json())[0];
  if (!atual) throw new Error('Diagnóstico não encontrado.');
  if (atual.status === 'publicado') {
    throw new Error('Esta versão já foi publicada e não pode mais ser editada. Crie uma nova versão.');
  }

  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ conteudo, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao salvar diagnóstico (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/** @param {string} token @param {string} id */
async function publicar(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ status: 'publicado', updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao publicar diagnóstico (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

module.exports = { listarPorLead, criarNovaVersao, atualizarConteudo, publicar, SECOES };
