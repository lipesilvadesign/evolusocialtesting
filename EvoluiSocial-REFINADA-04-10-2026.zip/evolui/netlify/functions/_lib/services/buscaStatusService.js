const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_prospeccao_buscas';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * Cria a linha de progresso no início da busca. O id vem PRONTO do
 * navegador (crypto.randomUUID()) — assim a interface já pode começar a
 * consultar por esse id antes mesmo da Background Function terminar de
 * criar a linha (a primeira consulta simplesmente não acha nada ainda,
 * e tenta de novo alguns segundos depois).
 * @param {string} token
 * @param {{ id: string, cidades: string[], ramo: string, criadoPor: string }} dados
 */
async function iniciar(token, dados) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=minimal' }),
    body: JSON.stringify({
      id: dados.id,
      cidades: dados.cidades,
      ramo: dados.ramo,
      status: 'em_andamento',
      progresso: [],
      criado_por: dados.criadoPor,
    }),
  });
  if (!res.ok) throw new Error(`Falha ao registrar início da busca (${res.status}): ${await res.text()}`);
}

/**
 * Acrescenta uma entrada ao array de progresso (uma por cidade processada).
 * @param {string} token
 * @param {string} id
 * @param {object[]} progressoAtual array já lido antes (pra fazer append sem sobrescrever)
 * @param {{ cidade: string, encontrados: number, ok: boolean, erro?: string }} entrada
 */
async function atualizarProgresso(token, id, progressoAtual, entrada) {
  const novoProgresso = [...progressoAtual, entrada];
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ progresso: novoProgresso, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao atualizar progresso (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0].progresso;
}

/**
 * @param {string} token
 * @param {string} id
 * @param {{ totalEncontrado: number }} resultado
 */
async function concluir(token, id, { totalEncontrado }) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token),
    body: JSON.stringify({ status: 'concluido', total_encontrado: totalEncontrado, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao concluir busca (${res.status}): ${await res.text()}`);
}

/**
 * @param {string} token
 * @param {string} id
 * @param {string} mensagemErro
 */
async function marcarErro(token, id, mensagemErro) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: headers(token),
    body: JSON.stringify({ status: 'erro', mensagem_erro: mensagemErro, updated_at: new Date().toISOString() }),
  });
  if (!res.ok) throw new Error(`Falha ao marcar erro da busca (${res.status}): ${await res.text()}`);
}

/**
 * @param {string} token
 * @param {string} id
 * @returns {Promise<object|null>}
 */
async function buscarPorId(token, id) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}&select=*`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error(`Falha ao consultar progresso (${res.status}).`);
  const rows = await res.json();
  return rows[0] || null;
}

module.exports = { iniciar, atualizarProgresso, concluir, marcarErro, buscarPorId };
