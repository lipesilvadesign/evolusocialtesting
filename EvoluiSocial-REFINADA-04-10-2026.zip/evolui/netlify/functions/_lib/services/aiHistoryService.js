/**
 * Histórico/Controle de uso de IA — persistência REAL (etapa "Operação,
 * Automação e Escala"; antes era stub). Tabela nova: admin_ai_usage.
 * Nunca grava o prompt completo nem a resposta inteira — só metadados
 * (modelo, tokens estimados, custo estimado, cache hit/miss).
 */

const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');
const logger = require('../logger');

const TABLE = 'admin_ai_usage';

// Preços aproximados por 1M tokens (USD) — só pra estimativa exibida no
// painel, não é fatura oficial da Anthropic. Ajustar aqui se os preços
// mudarem; documentado em IA_CONSULTOR_DOCUMENTACAO.md / OPERACAO.md.
const PRICE_PER_MILLION_TOKENS = {
  'claude-haiku-4-5-20251001': { input: 1, output: 5 },
  'claude-sonnet-5': { input: 3, output: 15 },
};

function estimateCostUsd(model, tokensInput, tokensOutput) {
  const price = PRICE_PER_MILLION_TOKENS[model] || PRICE_PER_MILLION_TOKENS['claude-haiku-4-5-20251001'];
  const cost = (tokensInput / 1_000_000) * price.input + (tokensOutput / 1_000_000) * price.output;
  return Math.round(cost * 100000) / 100000;
}

/**
 * @param {string} token - token de sessão do usuário que disparou a chamada
 * @param {{ rangeLabel: string, promptVersion: string, model: string, metricsUsed: string[], recommendationCount: number, cacheHit: boolean, tokensInput?: number, tokensOutput?: number }} entry
 * @returns {Promise<void>}
 */
async function record(token, entry) {
  const tokensInput = entry.tokensInput || 0;
  const tokensOutput = entry.tokensOutput || 0;
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal',
      },
      body: JSON.stringify({
        range_label: entry.rangeLabel,
        prompt_version: entry.promptVersion,
        model: entry.model,
        metrics_used: entry.metricsUsed || [],
        recommendation_count: entry.recommendationCount || 0,
        cache_hit: Boolean(entry.cacheHit),
        tokens_input: tokensInput,
        tokens_output: tokensOutput,
        estimated_cost_usd: estimateCostUsd(entry.model, tokensInput, tokensOutput),
        // Novo (PROMPT 5) — opcional, pra não quebrar quem já chamava sem
        // isto (a análise de marketing/GA4 continua sem passar geradoPor).
        ...(entry.geradoPor ? { gerado_por: entry.geradoPor } : {}),
      }),
    });
    if (!res.ok) {
      logger.warn('aiHistoryService', 'Falha ao persistir uso de IA', { status: res.status });
    }
  } catch (err) {
    logger.warn('aiHistoryService', 'Erro ao persistir uso de IA', { message: err.message });
  }
}

/** @returns {Promise<{ rows: object[], totals: { calls:number, cacheHits:number, estimatedCostUsd:number } }>} */
async function summary(token, { limit = 100 } = {}) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&order=created_at.desc&limit=${limit}`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(`Falha ao carregar uso de IA (${res.status}). A tabela ${TABLE} existe? Ver SQL pendente.`);
  const rows = await res.json();
  const totals = rows.reduce(
    (acc, r) => ({
      calls: acc.calls + 1,
      cacheHits: acc.cacheHits + (r.cache_hit ? 1 : 0),
      estimatedCostUsd: Math.round((acc.estimatedCostUsd + Number(r.estimated_cost_usd || 0)) * 100000) / 100000,
    }),
    { calls: 0, cacheHits: 0, estimatedCostUsd: 0 }
  );
  return { rows, totals };
}

module.exports = { record, summary, estimateCostUsd, TABLE };
