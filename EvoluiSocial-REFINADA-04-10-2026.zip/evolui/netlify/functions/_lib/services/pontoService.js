const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('../config/supabase');

const TABLE = 'admin_ponto_registros';

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

/**
 * Registra um evento de ponto (entrada/saída) do PRÓPRIO usuário — a RLS de
 * admin_ponto_registros só permite insert com funcionario_id = auth.uid(),
 * então nem precisa validar aqui: se alguém tentar registrar em nome de
 * outra pessoa, o Postgres recusa.
 * @param {string} token
 * @param {string} funcionarioId
 * @param {'entrada'|'saida'} tipo
 */
async function registrar(token, funcionarioId, tipo) {
  if (!['entrada', 'saida'].includes(tipo)) throw new Error(`Tipo de ponto inválido: ${tipo}`);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
    method: 'POST',
    headers: headers(token, { Prefer: 'return=representation' }),
    body: JSON.stringify({ funcionario_id: funcionarioId, tipo }),
  });
  if (!res.ok) throw new Error(`Falha ao registrar ponto (${res.status}): ${await res.text()}`);
  const rows = await res.json();
  return rows[0];
}

/**
 * Lista os registros de ponto do usuário logado (ou, se ele for admin, de
 * quem for passado em funcionarioId) num período — usado pra calcular
 * horas/dias trabalhados no Início.
 * @param {string} token
 * @param {{ funcionarioId?: string, inicio: string, fim: string }} opts
 */
async function listar(token, { funcionarioId, inicio, fim }) {
  const partes = [`registrado_em=gte.${encodeURIComponent(inicio)}`, `registrado_em=lte.${encodeURIComponent(fim)}`, 'order=registrado_em.asc'];
  if (funcionarioId) partes.push(`funcionario_id=eq.${encodeURIComponent(funcionarioId)}`);
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?select=*&${partes.join('&')}`, { headers: headers(token) });
  if (!res.ok) throw new Error(`Falha ao consultar ponto (${res.status}).`);
  return res.json();
}

/**
 * A partir dos registros brutos (entrada/saida intercalados), calcula:
 * total de horas no período e quantos dias distintos tiveram ao menos 1
 * registro. Puro/determinístico — não inventa nada: um "entrada" sem
 * "saida" correspondente (esqueceu de bater saída, ou é o dia de hoje ainda
 * em andamento) simplesmente não soma horas daquele par, só conta o dia.
 * @param {object[]} registros
 */
function calcularResumo(registros) {
  const porDia = new Map();
  registros.forEach((r) => {
    const dia = r.registrado_em.slice(0, 10);
    if (!porDia.has(dia)) porDia.set(dia, []);
    porDia.get(dia).push(r);
  });

  let totalMs = 0;
  porDia.forEach((eventosDoDia) => {
    eventosDoDia.sort((a, b) => new Date(a.registrado_em) - new Date(b.registrado_em));
    let entradaAberta = null;
    eventosDoDia.forEach((ev) => {
      if (ev.tipo === 'entrada') {
        entradaAberta = new Date(ev.registrado_em);
      } else if (ev.tipo === 'saida' && entradaAberta) {
        totalMs += new Date(ev.registrado_em) - entradaAberta;
        entradaAberta = null;
      }
    });
  });

  return {
    diasTrabalhados: porDia.size,
    horasTrabalhadas: Math.round((totalMs / (1000 * 60 * 60)) * 10) / 10,
  };
}

module.exports = { registrar, listar, calcularResumo };
