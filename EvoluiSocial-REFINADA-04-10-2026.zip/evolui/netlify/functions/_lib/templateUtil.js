/**
 * Preenche um modelo de texto com variáveis do lead. Usado no assunto e no
 * corpo do e-mail de prospecção — extraído num módulo próprio só pra poder
 * testar a lógica isoladamente, sem precisar simular toda a Function.
 * @param {string} texto modelo com {{empresa}}, {{setor}}, {{cidade}}
 * @param {{ empresa?: string, setor?: string, cidade?: string }} lead
 * @returns {string}
 */
function preencherModelo(texto, lead) {
  return String(texto || '')
    .replaceAll('{{empresa}}', lead.empresa || '')
    .replaceAll('{{setor}}', lead.setor || '')
    .replaceAll('{{cidade}}', lead.cidade || '');
}

/**
 * Normaliza um nome de empresa pra comparação — usado quando a mesma
 * empresa pode vir de duas fontes diferentes na mesma busca (Geoapify +
 * OpenStreetMap) e não pode duplicar mesmo tendo IDs de origem diferentes.
 * @param {string} nome
 * @returns {string}
 */
function normalizarNome(nome) {
  return String(nome || '').trim().toLowerCase();
}

/**
 * Calcula o "radical" de uma palavra digitada pelo usuário — a raiz comum
 * que ainda bate com variações de sufixo em português (singular/plural,
 * substantivo/adjetivo). Ex: "construção" → "constru", que bate tanto com
 * "Construtora" quanto "Construções" (nenhuma das duas contém a palavra
 * "construção" literal, sufixo diferente).
 * @param {string} termo já em minúsculo/trim
 * @returns {string}
 */
function calcularRadical(termo) {
  return termo.slice(0, Math.max(4, termo.length - 4));
}

/**
 * Agrega os dados brutos (envios, buscas, contagem de leads) do período em
 * um resumo pronto pra exibir. Extraído do handler pra poder testar essa
 * conta isoladamente, sem precisar simular Supabase/autenticação.
 * @param {object[]} envios linhas de admin_prospeccao_envios no período
 * @param {object[]} buscas linhas de admin_prospeccao_buscas no período
 * @param {{ total: number, porFonte: Record<string, number> }} leads
 * @returns {object}
 */
function agregarRelatorio(envios, buscas, leads) {
  const resumoEnvios = envios.reduce(
    (acc, e) => {
      const r = e.resumo || {};
      acc.enviados += r.enviados || 0;
      acc.falhas += r.falhas || 0;
      return acc;
    },
    { enviados: 0, falhas: 0 }
  );
  const totalEncontrado = buscas.reduce((acc, b) => acc + (b.total_encontrado || 0), 0);

  return {
    buscasRealizadas: buscas.length,
    empresasEncontradas: totalEncontrado,
    leadsNoPeriodo: leads.total,
    leadsPorFonte: leads.porFonte,
    emailsEnviados: resumoEnvios.enviados,
    emailsComFalha: resumoEnvios.falhas,
  };
}

module.exports = { preencherModelo, normalizarNome, calcularRadical, agregarRelatorio, onlyDigits, candidatoEstaBloqueado, leadEstaBloqueado };

/**
 * @param {string} str
 * @returns {string}
 */
function onlyDigits(str) {
  return String(str || '').replace(/\D/g, '');
}

/**
 * Usado na busca manual (candidato ainda não é um lead salvo) — só dá pra
 * checar o que a fonte de dados já trouxe: origem_id sempre, e-mail/telefone
 * só se por acaso vierem preenchidos (raro, mas gratuito checar).
 * @param {{ origemId?: string, email?: string, telefone?: string }} candidato
 * @param {{ origemIds: Set<string>, emails: Set<string>, telefones: Set<string> }} bloqueios
 * @returns {boolean}
 */
function candidatoEstaBloqueado(candidato, bloqueios) {
  if (candidato.origemId && bloqueios.origemIds.has(candidato.origemId)) return true;
  if (candidato.email && bloqueios.emails.has(normalizarNome(candidato.email))) return true;
  if (candidato.telefone && bloqueios.telefones.has(onlyDigits(candidato.telefone))) return true;
  return false;
}

/**
 * Usado no envio de e-mail — lead já salvo, então também checa o campo
 * status_contato (setado manualmente ou pelo botão "Registrar opt-out").
 * @param {{ statusContato?: string, origemId?: string, email?: string, telefone?: string }} lead
 * @param {{ origemIds: Set<string>, emails: Set<string>, telefones: Set<string> }} bloqueios
 * @returns {boolean}
 */
function leadEstaBloqueado(lead, bloqueios) {
  if (lead.statusContato === 'nao_contatar' || lead.statusContato === 'optout_solicitado') return true;
  return candidatoEstaBloqueado(lead, bloqueios);
}
