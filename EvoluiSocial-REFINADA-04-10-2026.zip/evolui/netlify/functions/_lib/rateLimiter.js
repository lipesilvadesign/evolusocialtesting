/**
 * Rate limiter simples, em memória do processo — mesma limitação já
 * documentada em cache/memoryCache.js (não é distribuído, não sobrevive a
 * cold start). Objetivo aqui não é segurança perfeita contra ataque
 * coordenado, e sim evitar uso acidental excessivo do endpoint mais caro
 * do sistema (chamadas de IA) — cliques repetidos, loop de retry no
 * frontend, etc.
 */
const hits = new Map(); // key -> [timestamps]

/**
 * @param {string} key - normalmente o e-mail do usuário
 * @param {{ max: number, windowMs: number }} opts
 * @returns {{ allowed: boolean, retryAfterMs: number }}
 */
function checkRateLimit(key, { max, windowMs }) {
  const now = Date.now();
  const timestamps = (hits.get(key) || []).filter((t) => now - t < windowMs);

  if (timestamps.length >= max) {
    const retryAfterMs = windowMs - (now - timestamps[0]);
    return { allowed: false, retryAfterMs };
  }

  timestamps.push(now);
  hits.set(key, timestamps);
  return { allowed: true, retryAfterMs: 0 };
}

module.exports = { checkRateLimit };
