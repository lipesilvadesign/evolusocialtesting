/**
 * Motor de diagnóstico da Consultoria Gratuita de Perfil para Instagram
 * (/consultas — ETAPA 3).
 *
 * IMPORTANTE — o que este motor NÃO faz: ele não acessa o Instagram de
 * verdade (não existe integração com a API do Instagram/Meta neste projeto,
 * e criar uma exigiria verificação de negócio e sairia do escopo desta
 * etapa). O diagnóstico é construído a partir do que a PESSOA respondeu no
 * formulário (segmento e objetivo principal, sobretudo) cruzado com os
 * padrões que a Felipe Branding observa naquele tipo de negócio — nunca
 * afirma ter "olhado o perfil" ou visto algo que não foi enviado. Por isso a
 * linguagem é sempre em tom de leitura preliminar/direcional, terminando
 * numa conversa real (WhatsApp/agendamento) onde a revisão do perfil de
 * verdade acontece.
 *
 * Determinístico e sem custo/latência de API externa, por design (pedido
 * explícito da ETAPA 3). Preparado para evoluir: uma futura
 * netlify/functions/_lib/integrations/aiProvider.js (o MESMO módulo já usado
 * pelo Assistente de Conteúdo/Consultor de Marketing) pode um dia GERAR ou
 * ENRIQUECER este resultado — desde que devolva o mesmo formato de saída
 * documentado abaixo, nada mais no projeto (tela de resultado, painel,
 * banco) precisa mudar. Até lá, "motorVersao" abaixo identifica que este
 * resultado veio do motor de regras, não de IA.
 *
 * Formato de saída (o que fica salvo em consultas_leads.resultado_analise):
 * {
 *   motorVersao: 'regras-v1',
 *   geradoEm: string (ISO),
 *   resumo: string,
 *   categorias: [{ chave, titulo, avaliacao: 'atencao'|'base'|'oportunidade', avaliacaoLabel, texto, dicasPraticas: string[] (5 a 7 dicas de ação, não conceito) }],
 *   pontosFortes: string[],
 *   pontosDeAtencao: string[],
 *   oportunidades: string[],
 *   proximasAcoes: string[],
 *   ctaTexto: string,
 * }
 */

const MOTOR_VERSAO = 'regras-v1';

/** Rótulos exibidos — usados pelo painel e (via cópia idêntica) pelo formulário público em assets/js/consultas.js. */
const SEGMENTOS = {
  moda_vestuario: 'Moda e vestuário',
  beleza_estetica: 'Beleza e estética',
  saude_bem_estar: 'Saúde e bem-estar',
  fitness: 'Fitness e esporte',
  alimentacao: 'Alimentação e gastronomia',
  imoveis: 'Imóveis',
  educacao_cursos: 'Educação e cursos',
  servicos_profissionais: 'Serviços profissionais e consultoria',
  direito_contabilidade: 'Direito, contabilidade e finanças',
  construcao_arquitetura: 'Construção, arquitetura e engenharia',
  varejo_ecommerce: 'Varejo e e-commerce',
  pet: 'Pet',
  tecnologia: 'Tecnologia e software',
  artesanato_criativo: 'Artesanato e criativo',
  eventos: 'Eventos e festas',
  outro: 'Outro segmento',
};

const OBJETIVOS = {
  crescer_seguidores: { label: 'Crescer o número de seguidores', foco: 'atrair um público novo e relevante' },
  gerar_vendas: { label: 'Gerar vendas diretas pelo Instagram', foco: 'transformar quem vê o perfil em comprador' },
  atrair_clientes_locais: { label: 'Atrair clientes da minha região', foco: 'ser a primeira lembrança de quem procura na sua cidade' },
  fortalecer_autoridade: { label: 'Fortalecer autoridade e profissionalismo', foco: 'ser visto como referência no que faz' },
  organizar_identidade: { label: 'Organizar a identidade visual do perfil', foco: 'ter um perfil com cara de marca, não de perfil pessoal' },
  converter_contatos: { label: 'Converter seguidores em contatos (WhatsApp/e-mail)', foco: 'transformar visualização em conversa real' },
  outro: { label: 'Outro objetivo', foco: 'dar um próximo passo claro para o negócio' },
};

function labelSegmento(chave) {
  return SEGMENTOS[chave] || SEGMENTOS.outro;
}
function objetivoInfo(chave) {
  return OBJETIVOS[chave] || OBJETIVOS.outro;
}

/** Hash simples e determinístico (mesma entrada → mesmo resultado sempre) — só para variar redação sem precisar de aleatoriedade real. */
function hash(str) {
  let h = 0;
  const s = String(str || '');
  for (let i = 0; i < s.length; i++) {
    h = (h * 31 + s.charCodeAt(i)) >>> 0;
  }
  return h;
}
function pick(arr, seed) {
  return arr[seed % arr.length];
}

const CATEGORIAS_BASE = [
  {
    chave: 'posicionamento',
    titulo: 'Posicionamento',
    variantes: [
      (c) => `Um perfil de ${c.segmentoLabel} só compete de igual pra igual quando quem chega na bio entende em 3 segundos pra quem ele existe e por que escolher você. Sem essa clareza, o objetivo de ${c.objetivoFoco} fica mais difícil do que precisa ser.`,
      (c) => `Negócios de ${c.segmentoLabel} costumam ter concorrência direta no feed de quem os segue: o que diferencia não é postar mais, é comunicar uma posição clara. Isso pesa diretamente sobre o objetivo de ${c.objetivoFoco}.`,
      (c) => `Antes de qualquer ajuste visual, vale perguntar: alguém de fora do seu segmento entenderia, só pela bio, o que você faz e para quem? Em ${c.segmentoLabel}, essa clareza costuma ser o que separa quem só posta de quem de fato consegue ${c.objetivoFoco}.`,
    ],
  },
  {
    chave: 'identidade',
    titulo: 'Identidade visual',
    variantes: [
      (c) => `Cores, fonte de destaque e o padrão dos primeiros quadradinhos do feed são o que dão a sensação de "marca" antes de qualquer legenda ser lida. Em ${c.segmentoLabel}, isso costuma ser a diferença entre parecer um negócio estabelecido ou um perfil amador.`,
      (c) => `Identidade visual consistente não é sobre ficar "bonito", é repetição reconhecível: mesma paleta, mesma tipografia, mesmo tom de foto toda vez. Sem isso, quem passa pelo feed de ${c.segmentoLabel} não guarda a marca na memória.`,
      (c) => `Um símbolo, uma paleta e um jeito de fotografar que se repetem em cada post criam confiança visual, especialmente relevante em ${c.segmentoLabel}, onde a decisão de compra passa por parecer confiável antes mesmo da primeira mensagem.`,
    ],
  },
  {
    chave: 'conteudo',
    titulo: 'Conteúdo',
    variantes: [
      (c) => `A pergunta não é "quanto postar", é "cada post empurra alguém em direção ao objetivo de ${c.objetivoFoco}, ou só preenche o feed?". Conteúdo de ${c.segmentoLabel} rende mais quando alterna prova social, bastidor e uma chamada clara, não só uma dessas coisas repetida.`,
      (c) => `Em ${c.segmentoLabel}, o conteúdo que mais aproxima do objetivo de ${c.objetivoFoco} costuma ser o que mostra resultado real (antes/depois, cliente satisfeito, processo), mais do que arte polida sem contexto.`,
      (c) => `Consistência de tema pesa mais que frequência: 3 posts por semana com um fio condutor claro convertem mais, em ${c.segmentoLabel}, do que postar todo dia sem repetir um ângulo que já funcionou.`,
    ],
  },
  {
    chave: 'conversao',
    titulo: 'Conversão',
    variantes: [
      (c) => `Todo post deveria terminar em algum lugar: link na bio, um Direct, um "manda mensagem". Se esse caminho não está claro hoje, é aí que o objetivo de ${c.objetivoFoco} esbarra, não na quantidade de seguidores.`,
      (c) => `Bio, destaques e o primeiro post fixado são o "balcão" do perfil: é onde quem já se interessou decide se continua ou sai. Em ${c.segmentoLabel}, um caminho de contato confuso custa mais conversão do que falta de alcance.`,
      (c) => `Chamadas para ação genéricas ("segue aí") convertem pouco. O que costuma funcionar em ${c.segmentoLabel} é um convite específico e de baixo risco (pedir orçamento, tirar uma dúvida, ver disponibilidade), alinhado ao objetivo de ${c.objetivoFoco}.`,
    ],
  },
  {
    chave: 'presencaDigital',
    titulo: 'Presença digital',
    variantes: [
      (c) => `O Instagram raramente carrega o peso todo sozinho: ele funciona melhor como porta de entrada que leva a um WhatsApp, um site ou um catálogo já prontos para fechar. Vale checar se esse encaixe existe hoje.`,
      (c) => `Presença digital consistente em ${c.segmentoLabel} significa: quem te encontra no Instagram, te acha igual no Google e no boca a boca. Divergência entre esses canais é o que mais atrapalha o objetivo de ${c.objetivoFoco}.`,
      (c) => `Destaques organizados, link de contato funcionando e um Google Business Profile (quando aplicável) atualizado formam a base que sustenta qualquer esforço de ${c.objetivoFoco} feito dentro do Instagram.`,
    ],
  },
];

const AVALIACOES = [
  { chave: 'atencao', label: 'Ponto de atenção' },
  { chave: 'base', label: 'Base a confirmar' },
  { chave: 'oportunidade', label: 'Oportunidade clara' },
];

const PONTOS_FORTES_BANCO = [
  (c) => `Ter procurado uma leitura estratégica antes de sair postando mais já coloca ${c.nome} à frente da maioria dos perfis de ${c.segmentoLabel}.`,
  (c) => `Um objetivo específico definido (${c.objetivoLabel}) é o ponto de partida certo: muita gente publica sem saber para onde quer ir.`,
  (c) => `Segmentos como ${c.segmentoLabel} respondem bem a marca bem trabalhada, e o potencial de diferenciação aqui é real.`,
];

const PONTOS_ATENCAO_BANCO = [
  (c) => `Sem ver o perfil publicado ainda, o ponto mais comum em ${c.segmentoLabel} é a falta de um fio condutor visual entre os posts.`,
  (c) => `Objetivos como "${c.objetivoLabel}" costumam esbarrar em uma bio ou destaque que não deixa claro o próximo passo para quem chega.`,
  (c) => `Perfis de ${c.segmentoLabel} tendem a variar o tom entre posts institucionais e informais sem um critério, o que dilui a percepção de marca.`,
];

const OPORTUNIDADES_BANCO = [
  (c) => `Um sistema de identidade simples (paleta + tipografia + um padrão de foto) já muda a percepção de ${c.segmentoLabel} em poucas semanas.`,
  (c) => `Alinhar cada post a um passo do objetivo de ${c.objetivoFoco} (em vez de postar por postar) tende a acelerar resultado sem aumentar o volume de conteúdo.`,
  (c) => `Um caminho de contato mais claro (bio + destaque + CTA específico) costuma render mais conversas qualificadas do que qualquer aumento de alcance.`,
];

const PROXIMAS_ACOES_BANCO = [
  (c) => `Revisar a bio para deixar claro, em uma frase, o que ${c.nome} faz e para quem.`,
  (c) => `Definir 3 cores e 1 fonte de destaque e aplicar nos próximos 9 posts, sem exceção.`,
  (c) => `Criar 1 destaque fixo com o caminho de contato (WhatsApp, orçamento, agendamento).`,
  (c) => `Mapear, entre os últimos posts, quais 2 ou 3 formatos tiveram mais resposta e repetir esse padrão.`,
];

/**
 * Dicas PRÁTICAS por categoria — o pedido explícito foi "prática, não
 * conceitual": cada item aqui é uma ação que dá pra fazer ainda hoje, não uma
 * ideia abstrata. 8 variantes por categoria, amostradas (sem repetir) pelo
 * mesmo motor determinístico das outras listas — a quantidade final (5 a 7)
 * também varia por lead, mas de forma estável para o mesmo Instagram.
 */
const DICAS_PRATICAS_BANCO = {
  posicionamento: [
    (c) => `Escreva a bio neste formato: [o que você faz] + [para quem] + [um diferencial em poucas palavras]. Ex.: "Consultoria de marketing para ${c.segmentoLabel.toLowerCase()}, direto ao ponto, sem enrolação".`,
    (c) => `Peça pra 3 pessoas que não te conhecem lerem sua bio por 5 segundos e dizerem o que entenderam. Se ninguém acertar "o que você faz" e "para quem", vale reescrever.`,
    (c) => `Escolha uma frase de apresentação e repita ela, igual, na bio, nos destaques e no post fixado: é a repetição que gruda na memória de quem vê.`,
    (c) => `Liste 3 coisas que só ${c.nome} tem e o concorrente direto de ${c.segmentoLabel} não tem. Se não sair nenhuma, esse é o primeiro trabalho antes de postar mais.`,
    (c) => `Troque frases genéricas como "qualidade e compromisso" por um resultado concreto que a pessoa ganha: um número, um prazo ou uma transformação específica.`,
    (c) => `Fixe no topo do feed o post que resume melhor "quem sou, o que faço, pra quem": é ele que decide se quem chega fica ou sai.`,
    (c) => `Confira se o @ de usuário e o nome de exibição batem com o que as pessoas digitariam no Google pra te procurar, isso também é posicionamento.`,
    (c) => `Escreva em uma frase só o que você quer que pensem ao ver seu perfil. Se a frase não citar ${c.segmentoLabel.toLowerCase()} nem o público, ainda está vaga.`,
  ],
  identidade: [
    (c) => `Escolha no máximo 2 cores principais e 1 de apoio, e use sempre essas mesmas, inclusive nas capas de destaque dos stories.`,
    (c) => `Defina 1 fonte de destaque pra textos dentro das artes (Canva ou parecido) e pare de trocar de fonte a cada post novo.`,
    (c) => `Padronize o enquadramento das fotos: mesmo ângulo, mesma luz, mesmo tipo de fundo. Isso já cria identidade sem precisar de designer.`,
    (c) => `Crie capas de destaque com os mesmos ícones e cores: é um dos primeiros lugares que quem chega no perfil olha.`,
    (c) => `Separe 9 fotos que representam a marca ideal (um "moodboard" simples) e compare com o feed atual todo mês.`,
    (c) => `Se ainda usa foto de banco de imagens, troque aos poucos por fotos reais do negócio: em ${c.segmentoLabel.toLowerCase()}, autenticidade converte mais que estética genérica.`,
    (c) => `Teste se a foto de perfil continua legível bem pequena, do jeito que aparece nos stories e nos comentários.`,
    (c) => `Anote as cores (em hexadecimal) e a fonte escolhida num lugar fixo (Notas do celular resolve) pra nunca mais "esquecer" o padrão.`,
  ],
  conteudo: [
    (c) => `Publique um "antes e depois" real de um cliente ou resultado: é o formato que mais gera prova em ${c.segmentoLabel.toLowerCase()}.`,
    (c) => `Antes de postar, pergunte: por que alguém pararia de rolar o feed pra ler isso? Se a resposta não é clara, mude a primeira linha da legenda.`,
    (c) => `Alterne 3 tipos de post em loop: bastidor (confiança), resultado/prova (credibilidade) e convite direto (${c.objetivoFoco}), não poste sempre o mesmo tipo.`,
    (c) => `Responda, em um post ou story, a pergunta que mais aparece no Direct ou nos comentários: costuma virar o conteúdo de melhor alcance.`,
    (c) => `Use os 3 primeiros segundos de cada vídeo pra mostrar o resultado final, não a introdução: é o tempo que alguém leva pra decidir continuar assistindo.`,
    (c) => `Escreva a legenda como se estivesse respondendo uma pessoa específica que te mandou mensagem, não como um comunicado geral pra todo mundo.`,
    (c) => `Reaproveite o tema que mais performou nos últimos 3 meses: grave uma versão nova em vez de sempre criar do zero.`,
    (c) => `Feche pelo menos 1 a cada 3 posts com um convite direto ligado a ${c.objetivoFoco}, no lugar de um "segue aí" genérico.`,
  ],
  conversao: [
    (c) => `Troque o link da bio pelo link da ação que você mais quer agora (agendar, orçar, ver catálogo), não a home do site.`,
    (c) => `Crie um destaque fixo tipo "Como funciona" explicando em 3 passos simples como iniciar um atendimento com você.`,
    (c) => `Deixe pronta uma mensagem-padrão pro primeiro contato no Direct/WhatsApp, já direcionando pro próximo passo (orçamento, agendamento).`,
    (c) => `Troque CTAs genéricos ("segue aí", "salva esse post") por um convite específico e de baixo risco: "manda mensagem e te falo o valor".`,
    (c) => `Deixe um botão ou link de WhatsApp visível na bio ou nos destaques: cada clique extra de distância custa conversão.`,
    (c) => `Peça depoimentos de clientes satisfeitos e crie um destaque só com prints/vídeos deles: prova social reduz a hesitação de quem ainda não te conhece.`,
    (c) => `Anote, mesmo que numa lista simples, quantas mensagens chegaram pelo Instagram essa semana: sem esse número não dá pra saber se uma mudança funcionou.`,
    (c) => `Se hoje existem 3 lugares diferentes pra clicar (link, WhatsApp, e-mail), escolha 1 principal e deixe só ele em destaque.`,
  ],
  presencaDigital: [
    (c) => `Pesquise seu negócio no Google e confira se o nome, telefone e endereço batem com o Instagram: divergência confunde e derruba confiança.`,
    (c) => `Se atende presencialmente, crie ou atualize o Google Business Profile: muita gente pesquisa no Google antes de seguir no Instagram.`,
    (c) => `Teste, agora, cada link da bio (WhatsApp, site, agendamento) clicando neles: link quebrado é a forma mais boba de perder um cliente pronto.`,
    (c) => `Padronize o @ de usuário entre Instagram, WhatsApp Business e outras redes que usar, o que facilita ser encontrado de qualquer lugar.`,
    (c) => `Ative (ou revise) a conta comercial do Instagram: ela libera métricas básicas que ajudam a entender o que está funcionando.`,
    (c) => `Se tiver site, coloque o link do Instagram nele e vice-versa: cada canal deveria levar tráfego pros outros, não competir sozinho.`,
    (c) => `Confira se a cidade/região aparece visível no perfil: em ${c.segmentoLabel.toLowerCase()}, isso pode decidir se alguém local te encontra ou não.`,
    (c) => `Uma vez por mês, olhe o próprio perfil como se fosse a primeira vez: é a forma mais simples de notar o que está desatualizado.`,
  ],
};

/**
 * @param {{ nome: string, instagram: string, segmento: string, objetivo: string }} dados
 * @returns {object} contrato documentado no topo deste arquivo
 */
function gerarDiagnostico(dados) {
  const nome = (dados.nome || '').trim().split(/\s+/)[0] || 'você';
  const instagram = (dados.instagram || '').replace(/^@/, '').trim();
  const segmentoLabel = labelSegmento(dados.segmento);
  const { label: objetivoLabel, foco: objetivoFoco } = objetivoInfo(dados.objetivo);

  const ctx = { nome, instagram, segmentoLabel, objetivoLabel, objetivoFoco };
  const seedBase = hash(`${instagram}|${dados.segmento}|${dados.objetivo}`);

  function amostra(banco, offset, qtd) {
    const usados = new Set();
    const out = [];
    let tentativa = 0;
    while (out.length < qtd && tentativa < banco.length * 2) {
      const idx = (seedBase + offset + tentativa) % banco.length;
      if (!usados.has(idx)) {
        usados.add(idx);
        out.push(banco[idx](ctx));
      }
      tentativa++;
    }
    return out;
  }

  const categorias = CATEGORIAS_BASE.map((cat, i) => {
    const seed = seedBase + i * 7;
    const texto = pick(cat.variantes, seed)(ctx);
    const avaliacao = pick(AVALIACOES, seed + 3);
    const bancoDicas = DICAS_PRATICAS_BANCO[cat.chave] || [];
    // 5 a 7 dicas por categoria (pedido explícito), variando de forma
    // estável por lead — nunca menos de 5, nunca mais que o banco tem.
    const qtdDicas = Math.min(bancoDicas.length, 5 + (seed % 3));
    const dicasPraticas = amostra(bancoDicas, seed + 11, qtdDicas);
    return {
      chave: cat.chave,
      titulo: cat.titulo,
      avaliacao: avaliacao.chave,
      avaliacaoLabel: avaliacao.label,
      texto,
      dicasPraticas,
    };
  });

  const resumo =
    `@${instagram || 'seu perfil'} atua em ${segmentoLabel.toLowerCase()} com um objetivo claro (${objetivoLabel.toLowerCase()}). ` +
    `Com base no que ${nome} contou por aqui, esta é uma leitura inicial e direcional (não uma auditoria completa do perfil), ` +
    `apontando onde costumam estar as maiores oportunidades para esse tipo de negócio e onde vale focar primeiro.`;

  return {
    motorVersao: MOTOR_VERSAO,
    geradoEm: new Date().toISOString(),
    resumo,
    categorias,
    pontosFortes: amostra(PONTOS_FORTES_BANCO, 1, 2),
    pontosDeAtencao: amostra(PONTOS_ATENCAO_BANCO, 2, 2),
    oportunidades: amostra(OPORTUNIDADES_BANCO, 4, 2),
    proximasAcoes: amostra(PROXIMAS_ACOES_BANCO, 6, 3),
    ctaTexto: 'Esse diagnóstico foi só o ponto de partida. Numa conversa, a gente transforma isso em um plano de ação pro seu Instagram.',
  };
}

module.exports = { gerarDiagnostico, SEGMENTOS, OBJETIVOS, MOTOR_VERSAO };
