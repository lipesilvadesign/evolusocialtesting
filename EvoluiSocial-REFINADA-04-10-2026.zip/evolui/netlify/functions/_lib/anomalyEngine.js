/**
 * Anomaly Engine.
 *
 * Diferente do insightsEngine (que compara só período atual vs. anterior),
 * este motor olha a SÉRIE de 90 dias como linha de base (média + desvio-
 * padrão) e verifica se os dias mais recentes fogem muito desse padrão —
 * é "comportamento fora do padrão" de verdade, não só "caiu/subiu".
 *
 * Puro, sem I/O. Recebe a série diária já buscada (analyticsService) e
 * devolve Anomaly[].
 */

const { mean, standardDeviation, zScore, round1 } = require('./stats');
const { TRACKED_METRICS } = require('./historicalAverages');

const Z_THRESHOLD = 2; // >=2 desvios-padrão da média = fora do padrão
const Z_SEVERE = 3; // >=3 desvios-padrão = severidade alta
const RECENT_WINDOW = 3; // só avalia os últimos 3 dias como candidatos a anomalia
const MIN_BASELINE_POINTS = 14; // com menos de 2 semanas de dado, o z-score não é confiável

const METRIC_LABEL = {
  activeUsers: 'Usuários ativos',
  sessions: 'Sessões',
  screenPageViews: 'Visualizações',
  engagementRate: 'Taxa de engajamento',
  averageSessionDuration: 'Duração média da sessão',
};

/**
 * @param {Array<{date:string}>} timeSeries - série diária, ordenada crescente (mais recente por último)
 * @returns {import('./types').Anomaly[]}
 */
function detectAnomalies(timeSeries) {
  if (!timeSeries || timeSeries.length < MIN_BASELINE_POINTS) return [];

  const anomalies = [];

  TRACKED_METRICS.forEach((metric) => {
    const allValues = timeSeries.map((d) => d[metric]).filter((v) => typeof v === 'number');
    if (allValues.length < MIN_BASELINE_POINTS) return;

    const baselineMean = mean(allValues);
    const baselineStdDev = standardDeviation(allValues);
    if (baselineStdDev === 0) return; // métrica constante — sem variação, sem anomalia possível

    const recentDays = timeSeries.slice(-RECENT_WINDOW);
    let mostExtreme = null;

    recentDays.forEach((day) => {
      const value = day[metric];
      if (typeof value !== 'number') return;
      const z = zScore(value, baselineMean, baselineStdDev);
      if (Math.abs(z) < Z_THRESHOLD) return;
      if (!mostExtreme || Math.abs(z) > Math.abs(mostExtreme.z)) {
        mostExtreme = { date: day.date, value, z };
      }
    });

    if (!mostExtreme) return;

    anomalies.push({
      metric,
      metricLabel: METRIC_LABEL[metric] || metric,
      date: mostExtreme.date,
      value: mostExtreme.value,
      baselineMean: round1(baselineMean),
      baselineStdDev: round1(baselineStdDev),
      zScore: round1(mostExtreme.z),
      direction: mostExtreme.z > 0 ? 'alta' : 'baixa',
      severity: Math.abs(mostExtreme.z) >= Z_SEVERE ? 'alta' : 'media',
      baselineDays: allValues.length,
    });
  });

  return anomalies;
}

module.exports = { detectAnomalies, Z_THRESHOLD, Z_SEVERE, MIN_BASELINE_POINTS };
