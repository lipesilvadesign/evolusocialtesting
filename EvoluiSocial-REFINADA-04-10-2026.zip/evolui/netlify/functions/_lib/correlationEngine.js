/**
 * Correlation Engine.
 *
 * "Correlação de dados: tráfego, páginas, eventos e conversões" — este
 * motor cruza métricas DIFERENTES entre si (não é "métrica X subiu",
 * isso já é o insightsEngine; aqui é "o crescimento de sessões veio
 * principalmente do canal Y", "visualizações subiram mas eventos não
 * acompanharam"). Puro, sem I/O — sempre com o número exato da correlação
 * como evidência, nunca uma afirmação vaga.
 */

const MIN_TOTAL_DELTA_ABS = 5; // abaixo disso, calcular "% da contribuição" é ruído

/**
 * Quanto de uma variação total veio de cada fonte/canal (atribuição de
 * crescimento/queda) — só faz sentido quando a soma total variou de forma
 * relevante e na mesma direção da maioria das partes.
 */
function trafficContributionCorrelation(normalizedSnapshot) {
  const total = normalizedSnapshot.metrics.sessions;
  if (!total || total.deltaAbs == null || Math.abs(total.deltaAbs) < MIN_TOTAL_DELTA_ABS) return [];

  const contributors = (normalizedSnapshot.trafficSources || [])
    .filter((t) => t.deltaAbs != null && Math.sign(t.deltaAbs) === Math.sign(total.deltaAbs) && t.deltaAbs !== 0)
    .map((t) => ({
      channel: t.channel,
      deltaAbs: t.deltaAbs,
      share: Math.round((Math.abs(t.deltaAbs) / Math.abs(total.deltaAbs)) * 1000) / 10,
    }))
    .sort((a, b) => b.share - a.share);

  if (contributors.length === 0) return [];
  const top = contributors[0];
  if (top.share < 30) return []; // nenhum canal isolado explica uma fatia relevante — não vale destacar

  return [
    {
      type: 'traffic-contribution',
      title: `"${top.channel}" concentra boa parte da variação de sessões`,
      description: `Dos ${total.deltaAbs >= 0 ? '+' : ''}${total.deltaAbs} de variação total em sessões, os dados indicam que aproximadamente ${top.share}% vieram do canal "${top.channel}" (${top.deltaAbs >= 0 ? '+' : ''}${top.deltaAbs}).`,
      evidence: { totalSessionsDelta: total.deltaAbs, channel: top.channel, channelDelta: top.deltaAbs, sharePct: top.share },
      strength: top.share >= 60 ? 'forte' : 'moderada',
    },
  ];
}

/**
 * Visualizações subindo sem os eventos acompanharem na mesma proporção —
 * correlação agregada (visão do site inteiro, complementar à regra de
 * página individual que já existe no insightsEngine).
 */
function viewsVsEventsCorrelation(normalizedSnapshot) {
  const views = normalizedSnapshot.metrics.screenPageViews;
  const pages = normalizedSnapshot.pages || [];
  if (!views || views.deltaPct == null || views.deltaPct < 15) return [];

  const totalEvents = pages.reduce((sum, p) => sum + (p.eventCount || 0), 0);
  const avgRatio = normalizedSnapshot.avgEventsPerView || 0;
  if (avgRatio <= 0 || totalEvents === 0) return [];

  // Se visualizações cresceram de forma relevante mas a razão eventos/visualização
  // das páginas monitoradas está baixa (abaixo de 0.3), é um indício (não causal)
  // de que o crescimento de tráfego não está acompanhado de engajamento equivalente.
  if (avgRatio >= 0.3) return [];

  return [
    {
      type: 'views-vs-events',
      title: 'Visualizações cresceram mais que os eventos registrados',
      description: `As visualizações de página cresceram ${views.deltaPct}% no período, mas a média de eventos por visualização entre as páginas monitoradas está em ${avgRatio} — os dados indicam que o crescimento de tráfego não está sendo acompanhado, na mesma proporção, por interações registradas.`,
      evidence: { viewsDeltaPct: views.deltaPct, avgEventsPerView: avgRatio, totalEventsObserved: totalEvents },
      strength: avgRatio < 0.15 ? 'forte' : 'moderada',
    },
  ];
}

/**
 * @param {object} normalizedSnapshot - saída de analyticsNormalizer.normalizeSnapshot()
 * @returns {Array}
 */
function findCorrelations(normalizedSnapshot) {
  return [...trafficContributionCorrelation(normalizedSnapshot), ...viewsVsEventsCorrelation(normalizedSnapshot)];
}

module.exports = { findCorrelations };
