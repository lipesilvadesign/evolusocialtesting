const { AiError } = require('./errors/aiErrors');

const VALID_STRENGTH = new Set(['forte', 'moderada', 'limitada']);
const VALID_PRIORITY = new Set(['baixa', 'media', 'alta']);

function isNonEmptyString(v) {
  return typeof v === 'string' && v.trim().length > 0;
}

function validatePoint(point, fieldName) {
  if (!point || typeof point !== 'object') {
    throw new AiError('AI_INVALID_RESPONSE', `${fieldName}: item não é um objeto.`);
  }
  if (!isNonEmptyString(point.text)) {
    throw new AiError('AI_INVALID_RESPONSE', `${fieldName}: "text" ausente ou vazio.`);
  }
  if (!VALID_STRENGTH.has(point.evidence_strength)) {
    throw new AiError('AI_INVALID_RESPONSE', `${fieldName}: "evidence_strength" inválido.`);
  }
  return {
    text: point.text,
    evidenceStrength: point.evidence_strength,
    relatedMetric: typeof point.related_metric === 'string' ? point.related_metric : null,
  };
}

function validateRecommendation(rec) {
  if (!rec || typeof rec !== 'object') {
    throw new AiError('AI_INVALID_RESPONSE', 'recommendations: item não é um objeto.');
  }
  const required = ['title', 'explanation', 'evidence', 'suggested_action'];
  required.forEach((key) => {
    if (!isNonEmptyString(rec[key])) {
      throw new AiError('AI_INVALID_RESPONSE', `recommendations: "${key}" ausente ou vazio.`);
    }
  });
  if (!VALID_PRIORITY.has(rec.priority)) {
    throw new AiError('AI_INVALID_RESPONSE', 'recommendations: "priority" inválida.');
  }
  return {
    title: rec.title,
    explanation: rec.explanation,
    evidence: rec.evidence,
    suggestedAction: rec.suggested_action,
    priority: rec.priority,
  };
}

/**
 * Valida (e normaliza pra camelCase) a resposta bruta da IA contra o
 * schema esperado. Lança AiError('AI_INVALID_RESPONSE') em qualquer
 * desvio — uma resposta que não bate 100% com o formato nunca chega na UI.
 * @returns {import('./types').AiAnalysis}
 */
function validateAiResponse(raw) {
  if (!raw || typeof raw !== 'object') {
    throw new AiError('AI_INVALID_RESPONSE', 'Resposta não é um objeto.');
  }
  if (!isNonEmptyString(raw.summary)) {
    throw new AiError('AI_INVALID_RESPONSE', '"summary" ausente ou vazio.');
  }
  if (typeof raw.insufficient_data !== 'boolean') {
    throw new AiError('AI_INVALID_RESPONSE', '"insufficient_data" ausente ou não-booleano.');
  }

  const arrayFields = ['positive_points', 'attention_points', 'opportunities', 'recommendations', 'questions_to_investigate'];
  arrayFields.forEach((f) => {
    if (!Array.isArray(raw[f])) throw new AiError('AI_INVALID_RESPONSE', `"${f}" ausente ou não é array.`);
  });

  raw.questions_to_investigate.forEach((q, i) => {
    if (!isNonEmptyString(q)) throw new AiError('AI_INVALID_RESPONSE', `questions_to_investigate[${i}] inválido.`);
  });

  return {
    summary: raw.summary,
    insufficientData: raw.insufficient_data,
    positivePoints: raw.positive_points.map((p) => validatePoint(p, 'positive_points')),
    attentionPoints: raw.attention_points.map((p) => validatePoint(p, 'attention_points')),
    opportunities: raw.opportunities.map((p) => validatePoint(p, 'opportunities')),
    recommendations: raw.recommendations.map(validateRecommendation),
    questionsToInvestigate: raw.questions_to_investigate,
  };
}

module.exports = { validateAiResponse };
