/**
 * Cliente REST do Supabase (PostgREST) usado pelo Lead Capture Engine.
 *
 * Por que existe: cada service antigo tinha a própria função headers() e
 * fetch sem timeout — uma chamada presa travava a Function até o limite da
 * plataforma. Aqui:
 * - timeout de 10 s em toda chamada (SUPABASE_TIMEOUT_MS ajusta);
 * - 1 nova tentativa só para leituras (GET) em erro de rede/5xx;
 *   escritas NUNCA são repetidas às cegas (idempotência fica no banco:
 *   índices únicos, on conflict, RPCs que conferem estado);
 * - erro com status e trecho da resposta, sem vazar token/chave.
 *
 * Os services antigos continuam com o próprio código (migração gradual,
 * sem refatoração estética em massa — regra da Fase 0).
 */
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./config/supabase');

const TIMEOUT_MS = Number(process.env.SUPABASE_TIMEOUT_MS) || 10000;

class SupabaseErro extends Error {
  constructor(mensagem, status, detalhe) {
    super(mensagem);
    this.status = status;
    this.detalhe = detalhe;
  }
}

function headers(token, extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

async function fetchComTimeout(url, opts, timeoutMs = TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * @param {string} token JWT do usuário OU a service role key (só em rotinas agendadas)
 * @param {string} caminho ex.: 'admin_prospeccao_leads?select=id' ou 'rpc/aprovar_captura'
 * @param {{ method?: string, body?: any, prefer?: string, headers?: object, timeoutMs?: number }} [opts]
 * @returns {Promise<{ data: any, total: number|null, status: number }>}
 */
async function rest(token, caminho, opts = {}) {
  const method = (opts.method || 'GET').toUpperCase();
  const url = `${SUPABASE_URL}/rest/v1/${caminho}`;
  const extra = { ...(opts.headers || {}) };
  if (opts.prefer) extra.Prefer = opts.prefer;
  const init = { method, headers: headers(token, extra) };
  if (opts.body !== undefined) init.body = JSON.stringify(opts.body);

  const tentativas = method === 'GET' ? 2 : 1;
  let ultimoErro;
  for (let i = 0; i < tentativas; i++) {
    let res;
    try {
      res = await fetchComTimeout(url, init, opts.timeoutMs);
    } catch (err) {
      ultimoErro = new SupabaseErro(`Banco não respondeu (${err.name === 'AbortError' ? 'timeout' : 'rede'}).`, 0);
      continue;
    }
    if (res.status >= 500 && i + 1 < tentativas) {
      ultimoErro = new SupabaseErro(`Banco respondeu ${res.status}.`, res.status);
      continue;
    }
    const texto = await res.text().catch(() => '');
    if (!res.ok) {
      let detalhe = texto.slice(0, 300);
      try {
        const j = JSON.parse(texto);
        detalhe = j.message || j.hint || detalhe;
      } catch { /* texto puro */ }
      throw new SupabaseErro(`Falha no banco (${res.status}): ${detalhe}`, res.status, detalhe);
    }
    let data = null;
    if (texto) {
      try { data = JSON.parse(texto); } catch { data = texto; }
    }
    let total = null;
    const range = res.headers && res.headers.get ? res.headers.get('content-range') : null;
    if (range && range.includes('/')) {
      const t = range.split('/')[1];
      total = t === '*' ? null : Number(t);
    }
    return { data, total, status: res.status };
  }
  throw ultimoErro;
}

/** Chamada de função SQL (RPC). */
async function rpc(token, nome, args = {}, opts = {}) {
  const { data } = await rest(token, `rpc/${nome}`, { method: 'POST', body: args, ...opts });
  return data;
}

/** Codifica valor para filtro PostgREST (in.(...), eq.) — aspas quando há vírgula/parênteses. */
function valorFiltro(v) {
  const s = String(v);
  if (/[,()"\s]/.test(s)) return `"${s.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
  return s;
}

module.exports = { rest, rpc, headers, fetchComTimeout, valorFiltro, SupabaseErro, TIMEOUT_MS };
