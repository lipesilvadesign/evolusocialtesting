/**
 * Health Score Engine.
 *
 * "Avaliar aquisição, engajamento, conversão e conteúdo, com pontuação
 * explicável." Puro, sem I/O. Cada sub-nota (0-100) vem com `factors` —
 * a lista exata de números que a formaram, pra nunca virar caixa-preta.
 *
 * IMPORTANTE (transparência): o site não tem um evento de "conversão"
 * configurado/definido no GA4 (ex: formulário enviado, compra). Por isso
 * a sub-nota "Conversão" usa um PROXY heurístico (eventos por
 * visualização nas páginas monitoradas) — documentado explicitamente
 * como aproximação, nunca apresentado como taxa de conversão real.
 */

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function scoreAquisicao(metrics) {
  const users = metrics.activeUsers;
  if (!users || users.deltaPct == null) {
    return {
      key: 'aquisicao',
      label: 'Aquisição',
      score: null,
      explanation: 'Sem período anterior comparável para avaliar aquisição.',
      factors: [],
    };
  }
  const score = Math.round(clamp(50 + users.deltaPct, 0, 100));
  return {
    key: 'aquisicao',
    label: 'Aquisição',
    score,
    explanation: `Baseado na variação de usuários ativos (${users.deltaPct >= 0 ? '+' : ''}${users.deltaPct}% em relação ao período anterior).`,
    factors: [{ label: 'Variação de usuários ativos', value: `${users.deltaPct >= 0 ? '+' : ''}${users.deltaPct}%` }],
  };
}

function scoreEngajamento(metrics) {
  const engagement = metrics.engagementRate;
  if (!engagement) {
    return {
      key: 'engajamento',
      label: 'Engajamento',
      score: null,
      explanation: 'Sem dado de taxa de engajamento disponível.',
      factors: [],
    };
  }
  const score = Math.round(clamp(engagement.value * 1.2, 0, 100));
  return {
    key: 'engajamento',
    label: 'Engajamento',
    score,
    explanation: `Baseado na taxa de engajamento do período (${engagement.value}%).`,
    factors: [{ label: 'Taxa de engajamento', value: `${engagement.value}%` }],
  };
}

function scoreConversao(normalizedSnapshot) {
  const avgRatio = normalizedSnapshot.avgEventsPerView;
  if (!avgRatio || normalizedSnapshot.pages.length === 0) {
    return {
      key: 'conversao',
      label: 'Conversão (proxy)',
      score: null,
      explanation: 'Sem páginas suficientes no período para estimar este proxy.',
      factors: [],
    };
  }
  // Escala heurística deliberada: eventsPerView 0 → nota 0; ~2.5 eventos
  // por visualização → nota 100 (teto). Documentado como aproximação, não
  // como taxa de conversão real (o site não define um evento de
  // "conversão" específico no GA4).
  const score = Math.round(clamp(avgRatio * 40, 0, 100));
  return {
    key: 'conversao',
    label: 'Conversão (proxy)',
    score,
    explanation: `Proxy heurístico baseado em eventos por visualização nas páginas monitoradas (média de ${avgRatio}). Não é uma taxa de conversão real — o site não tem um evento de conversão específico configurado.`,
    factors: [{ label: 'Eventos por visualização (média)', value: avgRatio }],
    isProxy: true,
  };
}

function scoreConteudo(normalizedSnapshot) {
  const pages = (normalizedSnapshot.pages || []).filter((p) => p.deltaPct != null && !p.isNew);
  if (pages.length === 0) {
    return {
      key: 'conteudo',
      label: 'Conteúdo',
      score: null,
      explanation: 'Sem páginas com período anterior comparável.',
      factors: [],
    };
  }
  const growing = pages.filter((p) => p.deltaPct >= 10).length;
  const declining = pages.filter((p) => p.deltaPct <= -10).length;
  const score = Math.round(clamp(50 + (growing - declining) * 10, 0, 100));
  return {
    key: 'conteudo',
    label: 'Conteúdo',
    score,
    explanation: `Baseado em quantas páginas monitoradas cresceram (${growing}) vs. caíram (${declining}) no período, entre ${pages.length} páginas com dado comparável.`,
    factors: [
      { label: 'Páginas em crescimento (≥10%)', value: growing },
      { label: 'Páginas em queda (≤-10%)', value: declining },
    ],
  };
}

/**
 * @param {object} normalizedSnapshot
 * @returns {{ overall: number|null, subScores: Array }}
 */
function computeHealthScore(normalizedSnapshot) {
  const subScores = [
    scoreAquisicao(normalizedSnapshot.metrics),
    scoreEngajamento(normalizedSnapshot.metrics),
    scoreConversao(normalizedSnapshot),
    scoreConteudo(normalizedSnapshot),
  ];
  const valid = subScores.filter((s) => s.score != null);
  const overall = valid.length ? Math.round(valid.reduce((sum, s) => sum + s.score, 0) / valid.length) : null;
  return { overall, subScores };
}

module.exports = { computeHealthScore };
