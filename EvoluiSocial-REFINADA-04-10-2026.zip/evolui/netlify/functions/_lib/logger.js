/**
 * Logger estruturado.
 *
 * Regra: nunca logar valores de variáveis de ambiente, tokens, chaves de
 * API, corpo completo de prompt/resposta de IA, ou qualquer coisa que
 * pareça um segredo. Sempre metadados (nomes, códigos, contagens,
 * durações) — nunca o conteúdo sensível em si. Isto já era seguido "no
 * olho" nas Functions anteriores (analyticsErrors.js, aiErrors.js); este
 * arquivo só formaliza o padrão pras Functions novas desta etapa.
 */

function safeMeta(meta) {
  if (!meta || typeof meta !== 'object') return {};
  const DENY_KEYS = /key|token|secret|password|credential|authorization/i;
  const out = {};
  Object.keys(meta).forEach((k) => {
    out[k] = DENY_KEYS.test(k) ? '[omitido]' : meta[k];
  });
  return out;
}

function log(level, source, message, meta) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    source,
    message,
    ...safeMeta(meta),
  };
  const line = JSON.stringify(entry);
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
}

module.exports = {
  info: (source, message, meta) => log('info', source, message, meta),
  warn: (source, message, meta) => log('warn', source, message, meta),
  error: (source, message, meta) => log('error', source, message, meta),
};
