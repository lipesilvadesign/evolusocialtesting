/**
 * Lead Capture Engine — PIPELINE.
 *
 *   coleta (providers) → normalização → deduplicação (job + CRM) → opt-out
 *   → enriquecimento → gravação na CAPTURA (admin_prospeccao_captura)
 *   → job em_revisao (decisão humana)
 *
 * NUNCA escreve em admin_prospeccao_leads: a passagem para o CRM é só pela
 * RPC aprovar_captura, disparada por uma pessoa na tela de prévia.
 *
 * 30/09 (ENABLE_NEW_CAPTURE_FLOW, padrão ligado) — executarPesquisaV2:
 *   coleta PARALELA (Promise.allSettled; no máximo 2 consultas simultâneas ao
 *   Overpass, 4 ao Geoapify), prazo por provider, cache 24 h, área do mapa,
 *   resultados gravados ANTES do enriquecimento (job já fica em_revisao) e
 *   enriquecimento depois, pela RPC prospeccao_gravar_enriquecimento.
 *   Telemetria em admin_prospeccao_buscas.metricas.
 *   Flag desligada → executarPesquisaLegado (fluxo anterior, intacto).
 *
 * Tudo que fala com rede/banco entra por `deps` (injetável nos testes).
 * Cancelamento: o status do job é relido entre cidades e entre etapas; se
 * estiver 'cancelado', o pipeline para ali (nunca no meio de uma gravação).
 */
const normalizar = require('./normalizar');
const deduplicar = require('./deduplicar');
const enriquecer = require('./enriquecer');
const taxonomia = require('./taxonomia');
const { validarRegistro } = require('./tipos');
const geoapify = require('./providers/geoapify');
const overpass = require('./providers/overpass');
const cache = require('./cache');
const flags = require('./flags');
const cnpjProvider = require('./providers/cnpj');

const PAUSA_ENTRE_CIDADES_MS = 1200; // política do Nominatim (1 req/s)
const LOTE_GRAVACAO = 200;
// Orçamento por consulta (v2). Somado ao paralelismo, uma busca de 1 cidade
// termina em no máximo ~PRAZO_OVERPASS mesmo com o Overpass fora do ar.
const PRAZO_MS = {
  geoapify: Number(process.env.CAPTACAO_PRAZO_GEOAPIFY_MS) || 12000,
  overpass: Number(process.env.CAPTACAO_PRAZO_OVERPASS_MS) || 20000,
};
const CONCORRENCIA = { geoapify: 4, overpass: 2 };
const CONCORRENCIA_SITES = 5;

class JobCancelado extends Error {}

/** Registro intermediário → linha da captura (normalizada). */
function paraLinha(reg, jobId) {
  const n = normalizar.registro(reg);
  return {
    job_id: jobId,
    provider: reg.provider,
    external_id: reg.external_id,
    payload: reg.payload || null,
    ...n,
    status: n.empresa ? 'pendente' : 'erro',
    erro: n.empresa ? null : 'Sem nome de empresa',
    sinais: [],
  };
}

/** Colunas aceitas pela tabela (o resto fica fora do insert). */
const COLUNAS_CAPTURA = ['job_id', 'provider', 'external_id', 'payload', 'empresa', 'empresa_norm', 'telefone', 'telefone_norm', 'email',
  'site', 'dominio', 'instagram', 'instagram_handle', 'cnpj', 'endereco', 'cidade', 'cidade_norm', 'uf', 'lat', 'lon', 'setor', 'subsetor',
  'categoria_origem', 'sinais', 'avisos', 'status', 'match_lead_id', 'match_tipo', 'match_confianca', 'match_empresa', 'erro',
  'site_verificado_em', 'site_http_status', 'site_https', 'enriquecimento_status'];

function paraBanco(linha) {
  const o = {};
  for (const c of COLUNAS_CAPTURA) o[c] = linha[c] === undefined ? null : linha[c];
  if (!o.empresa) o.empresa = '(sem nome)';
  o.sinais = o.sinais || [];
  o.avisos = o.avisos || [];
  return o;
}

/**
 * Normaliza, deduplica, aplica opt-out, (opcionalmente) enriquece e grava.
 * Usado pela pesquisa (worker) e pela importação CSV (síncrona, sem checagem de site).
 * @returns {Promise<{ gravados: number, fundidos: number, invalidos: number, bloqueados: number, checados: number }>}
 */
async function processarRegistros(registros, { jobId, deps, enriquecerSites = true, enriquecerDepois = false, fontesConsultadas = [], limiteChecagens = taxonomia.LIMITES.checagensSitePorJob, semSiteConfianca, tempos = {} }) {
  const relogio = () => Date.now();
  let t = relogio();
  let invalidos = 0;
  const linhas = [];
  for (const reg of registros) {
    const problemas = validarRegistro(reg);
    if (problemas.length) { invalidos += 1; continue; }
    const l = paraLinha(reg, jobId);
    if (l.status === 'erro') { invalidos += 1; continue; }
    linhas.push(l);
  }
  tempos.normalizacao_ms = relogio() - t;
  t = relogio();
  const { linhas: unicas, fundidos } = deduplicar.dedupNoJob(linhas.slice(0, taxonomia.LIMITES.registrosPorJob));

  const bloqueios = await deps.carregarBloqueios();
  const bloqueados = deduplicar.aplicarOptout(unicas, bloqueios);
  await deduplicar.classificarContraCrm(unicas, deps.buscarCandidatos);
  tempos.dedup_ms = relogio() - t;
  await deps.verificarCancelamento('enriquecimento');

  let checados = 0;
  const agora = deps.agora ? deps.agora() : new Date();
  if (enriquecerSites) {
    const alvos = unicas.filter((l) => l.site && ['pendente', 'possivel_duplicado'].includes(l.status)).slice(0, limiteChecagens);
    await enriquecer.emLotes(alvos, 5, async (l) => {
      try {
        const r = await deps.verificarSite(l.site);
        l.site_verificado_em = agora.toISOString();
        l.site_http_status = r.httpStatus;
        l.site_https = r.https;
        if (!l.instagram && r.instagram) { l.instagram = `@${r.instagram}`; l.instagram_handle = r.instagram; }
        l.sinais = enriquecer.sinaisPara(l, r, { agora, fontesConsultadas });
        checados += 1;
      } catch {
        /* checagem é melhor-esforço: sem sinal, sem evidência inventada */
      }
    });
  }
  for (const l of unicas) {
    if (!l.site && !l.sinais.length) {
      const s = enriquecer.sinaisPara(l, null, { agora, fontesConsultadas });
      if (semSiteConfianca) s.forEach((x) => { x.confianca = semSiteConfianca; });
      l.sinais = s;
    }
  }

  let aEnriquecer = 0;
  if (enriquecerDepois) {
    // Só os N primeiros sites elegíveis entram na fila (limite por job); o resto fica explícito como não aplicável.
    let naFila = 0;
    for (const l of unicas) {
      const elegivel = l.site && ['pendente', 'possivel_duplicado'].includes(l.status) && naFila < limiteChecagens;
      l.enriquecimento_status = elegivel ? 'pendente' : 'nao_aplicavel';
      if (elegivel) naFila += 1;
    }
    aEnriquecer = naFila;
  }

  t = relogio();
  let gravados = 0;
  for (let i = 0; i < unicas.length; i += LOTE_GRAVACAO) {
    const lote = unicas.slice(i, i + LOTE_GRAVACAO).map(paraBanco);
    await deps.gravarCaptura(lote);
    gravados += lote.length;
  }
  tempos.gravacao_ms = relogio() - t;
  const porStatus = {};
  for (const l of unicas) porStatus[l.status] = (porStatus[l.status] || 0) + 1;
  return { gravados, fundidos, invalidos, bloqueados, checados, porStatus, aEnriquecer };
}

/**
 * Executa um job de PESQUISA (Geoapify + Overpass) de ponta a ponta.
 * @param {object} job linha de admin_prospeccao_buscas (status já 'em_andamento')
 * @param {object} deps { atualizarJob, lerStatusJob, geocodificar, coletar: {geoapify, overpass}, carregarBloqueios,
 *                        buscarCandidatos, verificarSite, gravarCaptura, aguardar, apiKeyGeoapify }
 */
async function executarPesquisaLegado(job, deps) {
  const p = job.parametros || {};
  const providers = (job.providers && job.providers.length ? job.providers : ['geoapify', 'overpass'])
    .filter((x) => x === 'geoapify' || x === 'overpass');
  const erros = [];
  const progresso = [];
  const registros = [];

  deps.verificarCancelamento = async (etapa) => {
    const st = await deps.lerStatusJob(job.id);
    if (st === 'cancelado') throw new JobCancelado(`Cancelado antes da etapa ${etapa}.`);
  };

  await deps.atualizarJob(job.id, { etapa: 'coleta', iniciado_em: new Date().toISOString() });
  const cidades = (p.cidades || job.cidades || []).slice(0, taxonomia.LIMITES.cidadesPorJob);
  for (const [i, cidade] of cidades.entries()) {
    await deps.verificarCancelamento('coleta');
    const entrada = { cidade, ok: true, encontrados: 0, fontes: {} };
    let coords = null;
    try {
      coords = await deps.geocodificar(cidade);
      if (!coords) throw new Error('cidade não encontrada');
    } catch (err) {
      entrada.ok = false;
      entrada.erro = `Geocodificação: ${err.message}`;
      erros.push({ cidade, provider: 'geocodificacao', mensagem: err.message, em: new Date().toISOString() });
    }
    if (coords) {
      const falhas = [];
      const setores = Array.isArray(p.setores) && p.setores.length ? p.setores : [p.setor];
      for (const prov of providers) {
        for (const setor of setores) {
        try {
          const { registros: regs, avisos } = await deps.coletar[prov]({ setor, termo: p.termo, lat: coords.lat, lon: coords.lon, raioKm: p.raioKm });
          const cabe = taxonomia.LIMITES.registrosPorJob - registros.length;
          registros.push(...regs.slice(0, Math.max(0, cabe)));
          entrada.fontes[prov] = (Number(entrada.fontes[prov]) || 0) + regs.length;
          entrada.encontrados += regs.length;
          for (const a of avisos || []) erros.push({ cidade, provider: prov, mensagem: a, em: new Date().toISOString() });
        } catch (err) {
          if (!falhas.includes(prov)) falhas.push(prov);
          entrada.fontes[prov] = `erro: ${err.message}`;
          erros.push({ cidade, provider: prov, setor, mensagem: err.message, em: new Date().toISOString() });
        }
        }
      }
      if (falhas.length === providers.length) { entrada.ok = false; entrada.erro = 'Todas as fontes falharam nesta cidade'; }
    }
    progresso.push(entrada);
    await deps.atualizarJob(job.id, { progresso, erros, qtd_encontrados: registros.length });
    if (i < cidades.length - 1) await deps.aguardar(PAUSA_ENTRE_CIDADES_MS);
  }

  await deps.verificarCancelamento('normalizacao');
  await deps.atualizarJob(job.id, { etapa: 'deduplicacao' });
  const resumo = await processarRegistros(registros, {
    jobId: job.id, deps, enriquecerSites: true, fontesConsultadas: providers.map((x) => (x === 'overpass' ? 'OpenStreetMap' : 'Geoapify')),
  });
  const final = { etapa: null, erros, progresso, status: resumo.gravados ? 'em_revisao' : 'concluido' };
  if (!resumo.gravados) final.finalizado_em = new Date().toISOString();
  if (!resumo.gravados && erros.length && progresso.every((e) => !e.ok)) {
    final.status = 'erro';
    final.mensagem_erro = 'Nenhuma fonte respondeu. Veja os erros por cidade.';
  }
  await deps.atualizarJob(job.id, final);
  return { ...resumo, encontrados: registros.length, status: final.status };
}


/** Semáforo simples: no máximo `n` execuções simultâneas de `fn`. */
function limitador(n) {
  let ativos = 0;
  const fila = [];
  const proximo = () => {
    if (ativos >= n || !fila.length) return;
    ativos += 1;
    const { fn, ok, falha } = fila.shift();
    Promise.resolve().then(fn).then(ok, falha).finally(() => { ativos -= 1; proximo(); });
  };
  return (fn) => new Promise((ok, falha) => { fila.push({ fn, ok, falha }); proximo(); });
}

/** Rejeita se a promessa passar do prazo (o provider também tem timeout próprio; isto é o teto). */
function comPrazo(promessa, ms, rotulo) {
  let timer;
  return Promise.race([
    promessa,
    new Promise((_, rej) => { timer = setTimeout(() => rej(new Error(`${rotulo}: sem resposta em ${Math.round(ms / 1000)} s`)), ms); }),
  ]).finally(() => clearTimeout(timer));
}

/**
 * Área escolhida no mapa: { latitude, longitude, raio_metros }. Validada também
 * no servidor em captacao.js; aqui é a segunda checagem (o job pode vir do banco).
 */
function areaValida(a) {
  if (!a || typeof a !== 'object') return null;
  const lat = Number(a.latitude);
  const lon = Number(a.longitude);
  const raio = Number(a.raio_metros);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || !Number.isFinite(raio)) return null;
  if (!noBrasil(lat, lon)) return null;
  if (raio < 500 || raio > 30000) return null;
  let geometry = null;
  if (a.geometry !== undefined && a.geometry !== null) {
    geometry = poligonoValido(a.geometry);
    if (!geometry) return null; // geometria enviada e inválida: recusa (não ignora em silêncio)
    // o círculo consultado precisa cobrir o polígono inteiro
    const maior = Math.max(...geometry.coordinates[0].map(([x, y]) => distanciaM(lat, lon, y, x)));
    if (maior > raio + 50) return null;
  }
  return { lat, lon, raioKm: raio / 1000, geometry, rotulo: typeof a.rotulo === 'string' && a.rotulo.trim() ? a.rotulo.trim().slice(0, 80) : 'Área escolhida no mapa' };
}

function noBrasil(lat, lon) { return lat >= -34 && lat <= 6 && lon >= -74.5 && lon <= -28.5; }

function distanciaM(lat1, lon1, lat2, lon2) {
  const r = Math.PI / 180;
  const h = Math.sin(((lat2 - lat1) * r) / 2) ** 2 + Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(((lon2 - lon1) * r) / 2) ** 2;
  return 2 * 6371000 * Math.asin(Math.sqrt(h));
}

/** GeoJSON Polygon simples: 1 anel fechado, 3–20 vértices, todos no Brasil. */
function poligonoValido(g) {
  if (!g || g.type !== 'Polygon' || !Array.isArray(g.coordinates) || g.coordinates.length !== 1) return null;
  const anel = g.coordinates[0];
  if (!Array.isArray(anel) || anel.length < 4 || anel.length > 21) return null;
  const pts = anel.map((p) => (Array.isArray(p) && p.length >= 2 ? [Number(p[0]), Number(p[1])] : null));
  if (pts.some((p) => !p || !Number.isFinite(p[0]) || !Number.isFinite(p[1]) || !noBrasil(p[1], p[0]))) return null;
  const [p0, pn] = [pts[0], pts[pts.length - 1]];
  if (p0[0] !== pn[0] || p0[1] !== pn[1]) return null;
  return { type: 'Polygon', coordinates: [pts.map(([x, y]) => [Number(x.toFixed(6)), Number(y.toFixed(6))])] };
}

/** Ponto dentro do polígono (ray casting; [lon, lat]). */
function dentroDoPoligono(lat, lon, geometry) {
  const anel = geometry.coordinates[0];
  let dentro = false;
  for (let i = 0, j = anel.length - 1; i < anel.length; j = i++) {
    const [xi, yi] = anel[i]; const [xj, yj] = anel[j];
    if ((yi > lat) !== (yj > lat) && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) dentro = !dentro;
  }
  return dentro;
}

async function geocodificarComCache(cidade, deps, metricas) {
  const ch = cache.chave('geocodificacao', { cidade });
  if (deps.lerCache) {
    try {
      const c = await deps.lerCache(ch);
      if (c && c.registros && Number.isFinite(Number(c.registros.lat))) { metricas.geocodificacao_cache = (metricas.geocodificacao_cache || 0) + 1; return { coords: c.registros, rede: false }; }
    } catch { /* cache indisponível: segue para a rede */ }
  }
  const coords = await deps.geocodificar(cidade);
  if (coords && deps.gravarCache) deps.gravarCache(ch, 'geocodificacao', { cidade }, coords, cache.TTL_GEO_HORAS).catch(() => {});
  return { coords, rede: true };
}

/**
 * Enriquecimento assíncrono de um job: lê a fila (enriquecimento_status = 'pendente'),
 * checa cada site (5 em paralelo) e grava pela RPC (só preenche campo vazio).
 * Nunca derruba o job: falha de um site vira status 'erro' naquele registro.
 */
async function enriquecerJob(jobId, deps, { fontesConsultadas = [], limite = taxonomia.LIMITES.checagensSitePorJob, consultaCnpj = false } = {}) {
  const inicio = Date.now();
  const pendentes = await deps.listarPendentesEnriquecimento(jobId, limite);
  const cont = { total: pendentes.length, concluido: 0, parcial: 0, erro: 0, cnpj_consultados: 0 };
  await enriquecer.emLotes(pendentes, CONCORRENCIA_SITES, async (l) => {
    const agora = deps.agora ? deps.agora() : new Date();
    try {
      // checagem de site com cache de 7 dias por domínio (mesmo site em buscas próximas não é visitado de novo)
      let r = null;
      const chSite = cache.chave('site', { termo: String(l.site).replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase() });
      if (deps.lerCache) { try { const c = await deps.lerCache(chSite); if (c && c.registros && c.registros.resultado) { r = c.registros; cont.cache = (cont.cache || 0) + 1; } } catch { /* sem cache */ } }
      if (!r) {
        r = await deps.verificarSite(l.site);
        if (deps.gravarCache && r && r.resultado !== 'nao_verificado') deps.gravarCache(chSite, 'site', { site: l.site }, r, cache.TTL_POR_TIPO.site).catch(() => {});
      }
      const dados = enriquecer.montarEnriquecimento(l, r, { agora, fontesConsultadas });
      if (consultaCnpj && l.cnpj && deps.consultarCnpj) {
        const c = await deps.consultarCnpj(l.cnpj);
        cont.cnpj_consultados += 1;
        dados.enriquecimento.cnpj = c.ok ? c.dados : { erro: c.motivo, consultado_em: agora.toISOString() };
        const nova = c.ok ? cnpjProvider.sinalEmpresaNova(c.dados, agora) : null;
        if (nova) dados.sinais.push(nova);
      }
      await deps.gravarEnriquecimento(l.id, dados);
      cont[dados.status] = (cont[dados.status] || 0) + 1;
    } catch (err) {
      cont.erro += 1;
      await deps.gravarEnriquecimento(l.id, { status: 'erro', enriquecimento: { erro: String(err.message || err).slice(0, 200), em: new Date().toISOString() } }).catch(() => {});
    }
  });
  return { ...cont, duracao_ms: Date.now() - inicio };
}

/**
 * FASE 3 — CAPTURA PROGRESSIVA (substitui a v2 de 30/09; mesma flag).
 *
 *   providers em paralelo ──► cada consulta que termina vira um LOTE
 *   lote: área → validação → dedup (contra o que JÁ foi gravado neste job e
 *         dentro do lote) → opt-out → CRM → grava → job em_revisao
 *   → a lista aparece com o PRIMEIRO lote (TTFR); os seguintes só somam ou
 *     completam registros já gravados (nunca duplicam).
 *
 * Lotes são processados um por vez (mutex) — a dedup entre lotes fica
 * determinística. Provider que estoura o prazo vira status 'timeout' só nele:
 * os resultados dos outros continuam válidos.
 * Métricas: ttfr_ms (início → 1º resultado gravado), ttlc_ms (→ último
 * provider terminado e gravado), providers[x].status/duration_ms/resultados.
 */
async function executarPesquisaV2(job, deps) {
  const t0 = Date.now();
  const p = job.parametros || {};
  const providers = (job.providers && job.providers.length ? job.providers : ['geoapify', 'overpass'])
    .filter((x) => x === 'geoapify' || x === 'overpass');
  const erros = [];
  const progresso = [];
  const metricas = { versao: 3, providers: {}, iniciado_em: new Date(t0).toISOString() };
  for (const prov of providers) metricas.providers[prov] = { status: 'aguardando', chamadas: 0, duration_ms: 0, soma_ms: 0, resultados: 0, novos: 0, erros: 0, cache: 0 };
  const agoraIso = () => new Date().toISOString();
  const ROTULO = { geoapify: 'Geoapify', overpass: 'OpenStreetMap' };

  deps.verificarCancelamento = async (etapa) => {
    const st = await deps.lerStatusJob(job.id);
    if (st === 'cancelado') throw new JobCancelado(`Cancelado antes da etapa ${etapa}.`);
  };
  await deps.atualizarJob(job.id, { etapa: 'coleta', iniciado_em: new Date(t0).toISOString(), metricas });

  // 1. Alvos: área do mapa (sem geocodificar) OU cidades (geocodificação com cache 30 dias)
  let t = Date.now();
  const alvos = [];
  const area = areaValida(p.area);
  if (area) {
    alvos.push({ cidade: area.rotulo, coords: { lat: area.lat, lon: area.lon }, raioKm: area.raioKm });
  } else {
    const cidades = (p.cidades || job.cidades || []).slice(0, taxonomia.LIMITES.cidadesPorJob);
    let ultimaRede = 0;
    for (const cidade of cidades) {
      try {
        const espera = PAUSA_ENTRE_CIDADES_MS - (Date.now() - ultimaRede);
        if (ultimaRede && espera > 0) await deps.aguardar(espera); // política do Nominatim, só entre chamadas REAIS
        const { coords, rede } = await geocodificarComCache(cidade, deps, metricas);
        if (rede) ultimaRede = Date.now();
        if (!coords) throw new Error('cidade não encontrada');
        alvos.push({ cidade, coords, raioKm: p.raioKm });
      } catch (err) {
        alvos.push({ cidade, erro: `Geocodificação: ${err.message}` });
        erros.push({ cidade, provider: 'geocodificacao', mensagem: err.message, em: agoraIso() });
      }
    }
  }
  metricas.geocodificacao_ms = Date.now() - t;
  await deps.verificarCancelamento('coleta');

  // Saúde dos hosts (ordem dos espelhos + circuito). Falha aqui = ordem padrão.
  let saudeLinhas = [];
  if (deps.carregarSaude) { try { saudeLinhas = await deps.carregarSaude(); } catch { saudeLinhas = []; } }
  const registrosSaude = [];
  const ordenar = deps.ordenarHosts ? (urls) => deps.ordenarHosts(urls, saudeLinhas) : undefined;
  const registrarHost = (prov) => (host, status, ms) => {
    (metricas.hosts = metricas.hosts || []).push({ host, status, duration_ms: Math.round(ms) });
    if (deps.registrarSaude) registrosSaude.push(Promise.resolve(deps.registrarSaude(host, prov, status, ms)).catch(() => {}));
  };

  // 2. Estado acumulado da captura progressiva
  const porCidade = new Map();
  for (const alvo of alvos) {
    porCidade.set(alvo.cidade, alvo.coords
      ? { cidade: alvo.cidade, ok: true, encontrados: 0, fontes: {}, falhas: new Set() }
      : { cidade: alvo.cidade, ok: false, erro: alvo.erro, encontrados: 0, fontes: {} });
  }
  const E = { gravadas: [], fundidos: 0, invalidos: 0, bloqueados: 0, aEnriquecer: 0, brutos: 0, foraDaArea: 0 };
  const tempos = { normalizacao_ms: 0, dedup_ms: 0, gravacao_ms: 0 };
  const limiteEnriq = taxonomia.LIMITES.checagensSitePorJob;
  const concluidos = new Set();
  let bloqueios = null;
  const mutex = limitador(1);

  function contarPorStatus() {
    const c = {};
    for (const l of E.gravadas) c[l.status] = (c[l.status] || 0) + 1;
    return c;
  }
  function atualizarMetricasContagem() {
    const st = contarPorStatus();
    metricas.encontrados = E.brutos;
    metricas.dentro_da_area = area && area.geometry ? E.brutos - E.foraDaArea : undefined;
    metricas.fora_da_area = area && area.geometry ? E.foraDaArea : undefined;
    metricas.duplicados = E.fundidos + (st.duplicado || 0);
    metricas.possiveis_duplicados = st.possivel_duplicado || 0;
    metricas.bloqueados = st.bloqueado_optout || 0;
    metricas.invalidos = E.invalidos;
    metricas.disponiveis = (st.pendente || 0) + (st.possivel_duplicado || 0);
    metricas.na_fila_enriquecimento = E.aEnriquecer;
    Object.assign(metricas, tempos);
  }
  const progressoAtual = () => [...porCidade.values()].map((e) => { const { falhas, ...resto } = e; return resto; });

  async function processarLote(prov, alvo, regsBrutos) {
    let regs = regsBrutos;
    if (area && area.geometry) {
      const dentro = regs.filter((r) => Number.isFinite(Number(r.lat)) && Number.isFinite(Number(r.lon)) && dentroDoPoligono(Number(r.lat), Number(r.lon), area.geometry));
      E.foraDaArea += regs.length - dentro.length;
      regs = dentro;
    }
    E.brutos += regsBrutos.length;
    const cabe = taxonomia.LIMITES.registrosPorJob - E.gravadas.length;
    regs = regs.slice(0, Math.max(0, cabe));
    // normalização
    let tt = Date.now();
    const linhas = [];
    for (const reg of regs) {
      if (validarRegistro(reg).length) { E.invalidos += 1; continue; }
      const l = paraLinha(reg, job.id);
      if (l.status === 'erro') { E.invalidos += 1; continue; }
      linhas.push(l);
    }
    tempos.normalizacao_ms += Date.now() - tt;
    // dedup: primeiro contra o que JÁ foi gravado neste job, depois dentro do lote
    tt = Date.now();
    const alteradas = new Set();
    const candidatas = [];
    for (const l of linhas) {
      const existente = E.gravadas.find((g) => deduplicar.mesmaEmpresa(g, l));
      if (!existente) { candidatas.push(l); continue; }
      E.fundidos += 1;
      const ganhouSite = !existente.site && l.site;
      for (const c of deduplicar.CAMPOS_FUNDIR) if ((existente[c] === null || existente[c] === undefined) && l[c] !== null && l[c] !== undefined) existente[c] = l[c];
      existente.payload = existente.payload || {};
      existente.payload.outras_fontes = [...(existente.payload.outras_fontes || []), { provider: l.provider, external_id: l.external_id }];
      if (ganhouSite) {
        // a evidência "nenhuma fonte informou site" deixou de ser verdadeira
        existente.sinais = (existente.sinais || []).filter((x) => x.tipo !== 'SEM_SITE');
        if (['pendente', 'possivel_duplicado'].includes(existente.status) && E.aEnriquecer < limiteEnriq) { existente.enriquecimento_status = 'pendente'; E.aEnriquecer += 1; }
      }
      alteradas.add(existente);
    }
    const { linhas: novas, fundidos } = deduplicar.dedupNoJob(candidatas);
    E.fundidos += fundidos;
    if (!bloqueios) bloqueios = await deps.carregarBloqueios();
    deduplicar.aplicarOptout(novas, bloqueios);
    await deduplicar.classificarContraCrm(novas, deps.buscarCandidatos);
    tempos.dedup_ms += Date.now() - tt;
    // sinais sem rede (SEM_SITE) com as fontes que JÁ responderam — evidência verdadeira no momento
    const agora = deps.agora ? deps.agora() : new Date();
    const fontesAte = [...new Set([...concluidos, prov])].map((x) => ROTULO[x] || x);
    for (const l of novas) {
      if (!l.site && !(l.sinais || []).length) l.sinais = enriquecer.sinaisPara(l, null, { agora, fontesConsultadas: fontesAte });
      const elegivel = l.site && ['pendente', 'possivel_duplicado'].includes(l.status) && E.aEnriquecer < limiteEnriq;
      l.enriquecimento_status = elegivel ? 'pendente' : 'nao_aplicavel';
      if (elegivel) E.aEnriquecer += 1;
    }
    await deps.verificarCancelamento('gravacao');
    // gravação
    tt = Date.now();
    for (let k = 0; k < novas.length; k += LOTE_GRAVACAO) await deps.gravarCaptura(novas.slice(k, k + LOTE_GRAVACAO).map(paraBanco));
    E.gravadas.push(...novas);
    if (deps.atualizarCaptura) {
      for (const g of alteradas) {
        const b = paraBanco(g);
        const campos = {};
        for (const c of [...deduplicar.CAMPOS_FUNDIR, 'payload', 'sinais', 'enriquecimento_status']) campos[c] = b[c];
        await deps.atualizarCaptura(job.id, g.provider, g.external_id, campos).catch((err) => {
          erros.push({ provider: prov, mensagem: `Não foi possível completar um registro já exibido: ${String(err.message).slice(0, 120)}`, em: agoraIso() });
        });
      }
    }
    tempos.gravacao_ms += Date.now() - tt;
    metricas.providers[prov].novos += novas.length;
    const entrada = porCidade.get(alvo.cidade);
    if (entrada) { entrada.encontrados += regsBrutos.length; entrada.fontes[prov] = (Number(entrada.fontes[prov]) || 0) + regsBrutos.length; }
    if (E.gravadas.length && metricas.ttfr_ms === undefined) metricas.ttfr_ms = Date.now() - t0;
    atualizarMetricasContagem();
    // resultados parciais já revisáveis: job em_revisao com a coleta ainda em andamento
    await deps.atualizarJob(job.id, { progresso: progressoAtual(), erros, metricas, ...(E.gravadas.length ? { status: 'em_revisao', etapa: 'coleta' } : {}) });
  }

  // 3. Coleta paralela (cidade × provider × setor) — cada consulta que termina vira lote
  t = Date.now();
  const setores = Array.isArray(p.setores) && p.setores.length ? p.setores : [p.setor];
  const fila = {};
  for (const prov of providers) fila[prov] = limitador(CONCORRENCIA[prov] || 2);
  const pendentesPorProv = {};
  const cadeias = [];
  for (const alvo of alvos) {
    if (!alvo.coords) continue;
    for (const prov of providers) {
      for (const setor of setores) {
        pendentesPorProv[prov] = (pendentesPorProv[prov] || 0) + 1;
        metricas.providers[prov].status = 'em_andamento';
        const params = { setor, termo: p.termo, lat: alvo.coords.lat, lon: alvo.coords.lon, raioKm: alvo.raioKm };
        const m = metricas.providers[prov];
        const consulta = fila[prov](async () => {
          const ini = Date.now();
          const ch = cache.chave(prov, params);
          if (deps.lerCache) {
            try {
              const c = await deps.lerCache(ch);
              if (c && Array.isArray(c.registros)) return { regs: c.registros, avisos: [], cache: true, ms: Date.now() - ini };
            } catch { /* segue para o provider */ }
          }
          const prazo = (deps.prazosMs && deps.prazosMs[prov]) || PRAZO_MS[prov] || 15000;
          const r = await comPrazo(Promise.resolve(deps.coletar[prov](params, { prazoMs: prazo, ordenar, registrar: registrarHost(prov) })), prazo + Math.min(3000, Math.max(200, prazo * 0.15)), prov);
          const regs = (r && r.registros) || [];
          const avisos = (r && r.avisos) || [];
          if (!avisos.length && deps.gravarCache) deps.gravarCache(ch, prov, params, regs).catch(() => {});
          return { regs, avisos, cache: false, ms: Date.now() - ini };
        });
        cadeias.push(consulta.then(
          (res) => mutex(async () => {
            m.chamadas += 1; m.duration_ms = Math.max(m.duration_ms, res.ms); m.soma_ms += res.ms; m.resultados += res.regs.length;
            if (res.cache) m.cache += 1;
            for (const a of res.avisos) erros.push({ cidade: alvo.cidade, provider: prov, mensagem: a, em: agoraIso() });
            pendentesPorProv[prov] -= 1;
            if (!pendentesPorProv[prov]) { m.status = m.erros ? 'parcial' : 'concluido'; concluidos.add(prov); }
            await processarLote(prov, alvo, res.regs);
          }),
          (err) => mutex(async () => {
            const msg = String((err && err.message) || err).slice(0, 300);
            const timeout = /sem resposta em|a tempo|timeout/i.test(msg);
            m.chamadas += 1; m.erros += 1; m.ultimo_erro = msg;
            pendentesPorProv[prov] -= 1;
            if (!pendentesPorProv[prov]) { m.status = m.resultados ? 'parcial' : (timeout ? 'timeout' : 'erro'); concluidos.add(prov); }
            const entrada = porCidade.get(alvo.cidade);
            if (entrada) { entrada.falhas.add(prov); entrada.fontes[prov] = timeout ? 'sem resposta a tempo' : 'falhou'; }
            erros.push({ cidade: alvo.cidade, provider: prov, setor, mensagem: msg, em: agoraIso() });
            await deps.atualizarJob(job.id, { progresso: progressoAtual(), erros, metricas });
          }),
        ));
      }
    }
  }
  const finais = await Promise.allSettled(cadeias);
  const falhaInterna = finais.find((x) => x.status === 'rejected');
  if (falhaInterna) throw falhaInterna.reason; // cancelamento ou erro de banco: o worker trata
  metricas.coleta_ms = Date.now() - t;
  await Promise.all(registrosSaude);

  for (const e of porCidade.values()) {
    if (e.falhas && e.falhas.size === providers.length && !e.encontrados) { e.ok = false; e.erro = 'Nenhuma fonte respondeu nesta cidade'; }
  }
  progresso.push(...progressoAtual());
  atualizarMetricasContagem();
  metricas.ttlc_ms = Date.now() - t0;
  metricas.total_ms = metricas.ttlc_ms;

  const gravados = E.gravadas.length;
  const final = { erros, progresso, metricas, status: gravados ? 'em_revisao' : 'concluido', etapa: null };
  if (!gravados) final.finalizado_em = agoraIso();
  if (!gravados && erros.length && progresso.every((e) => !e.ok)) {
    final.status = 'erro';
    final.mensagem_erro = 'Nenhuma fonte de dados respondeu agora. Tente de novo em alguns minutos.';
  }
  if (final.status === 'em_revisao' && E.aEnriquecer) final.etapa = 'enriquecimento';
  // se a pessoa já decidiu tudo durante a coleta, o recontador do banco fecha o job — não reabrir à toa
  if (final.status === 'em_revisao' && !metricas.disponiveis && !E.aEnriquecer) delete final.status;
  await deps.atualizarJob(job.id, final);

  // 4. Enriquecimento DEPOIS dos resultados (não bloqueia a revisão)
  const fontesConsultadas = [...concluidos].map((x) => ROTULO[x] || x);
  if (final.etapa === 'enriquecimento') {
    try {
      await deps.verificarCancelamento('enriquecimento');
      const enriq = await enriquecerJob(job.id, deps, { fontesConsultadas, consultaCnpj: deps.consultaCnpj === true });
      metricas.enriquecimento = enriq;
      metricas.enriquecimento_ms = enriq.duracao_ms;
    } catch (err) {
      if (err instanceof JobCancelado) throw err;
      metricas.enriquecimento = { erro: String(err.message).slice(0, 300) };
      erros.push({ provider: 'enriquecimento', mensagem: String(err.message).slice(0, 300), em: agoraIso() });
    }
    await deps.atualizarJob(job.id, { etapa: null, metricas, erros });
  }
  return { gravados, fundidos: E.fundidos, invalidos: E.invalidos, bloqueados: metricas.bloqueados, encontrados: E.brutos, status: final.status || 'em_revisao', metricas };
}

async function executarPesquisa(job, deps) {
  const novo = deps.novoFluxo !== undefined ? deps.novoFluxo : flags.ligada('ENABLE_NEW_CAPTURE_FLOW');
  return novo ? executarPesquisaV2(job, deps) : executarPesquisaLegado(job, deps);
}

module.exports = { executarPesquisa, executarPesquisaV2, executarPesquisaLegado, enriquecerJob, areaValida, poligonoValido, dentroDoPoligono, limitador, processarRegistros, paraLinha, paraBanco, JobCancelado, COLUNAS_CAPTURA, providersPadrao: { geoapify, overpass } };
