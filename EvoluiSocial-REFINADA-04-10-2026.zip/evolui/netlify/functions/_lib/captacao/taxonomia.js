/**
 * Lead Capture Engine — TAXONOMIA (fonte única).
 *
 * Tudo que classifica um lead mora aqui: setores, sinônimos, categorias
 * Geoapify / tags OpenStreetMap por setor, fontes, métodos, status da
 * captura, oportunidades e parâmetros de temperatura. O painel NÃO tem
 * cópia própria: lê isto pela Function `prospeccao-taxonomia`.
 *
 * Paridade com o banco: as listas marcadas com [SQL] também existem nas
 * migrations (constraints e funções de score/temperatura). O teste
 * tests/captacaoTaxonomia.test.js lê os arquivos de migration e falha se
 * divergirem — mude os dois juntos.
 *
 * Categorias Geoapify: conferidas na documentação oficial da Places API
 * (apidocs.geoapify.com/docs/places, lida em 30/09/2026). Tags OSM: são as
 * tags de origem dessas mesmas categorias (a Geoapify é construída sobre o
 * OpenStreetMap) mais `craft=builder`/`office=company`, de uso comum no OSM.
 * NÃO FOI POSSÍVEL CONFIRMAR no wiki do OSM nesta execução a lista completa
 * de valores de office=*; por isso só entram tags que espelham categorias
 * Geoapify documentadas.
 *
 * `especificas` = a categoria por si só já diz que é do setor → todos os
 *   resultados entram na captura, sem depender do nome.
 * `genericas` + `termos` = categoria ampla (ex.: office.company). Só entra
 *   o resultado cujo NOME contém um dos termos. É um reforço, nunca a única
 *   estratégia — foi exatamente o "só pelo nome" que zerou as 21 buscas.
 */

// [SQL] migrations/002_taxonomia.sql (admin_prospeccao_leads_fonte_check)
const FONTES = ['manual', 'osm', 'geoapify', 'csv', 'xlsx', 'site', 'indicacao', 'evento'];
// Valores antigos continuam aceitos no banco (dados e código publicado antes de 30/09).
const FONTES_LEGADAS = { osm_auto: 'osm', osm_manual: 'osm', geoapify_manual: 'geoapify', busca_manual: 'osm' };

// [SQL] migrations/002_taxonomia.sql (admin_prospeccao_leads_metodo_check)
const METODOS = [
  'pesquisa_local',
  'sincronizacao_automatica',
  'importacao',
  'formulario',
  'indicacao',
  'networking',
  'prospeccao_manual',
];
/** inbound/outbound é DERIVADO do método — não é gravado (evita dado duplicado). */
function direcao(metodo) {
  if (metodo === 'formulario') return 'inbound';
  if (metodo === 'indicacao') return null; // pode ser qualquer um dos dois
  return metodo ? 'outbound' : null;
}

const PROVIDERS = ['geoapify', 'overpass', 'csv', 'consultoria', 'site_contato', 'manual'];

// [SQL] migrations/005_capture_jobs.sql
const STATUS_JOB = ['na_fila', 'em_andamento', 'em_revisao', 'concluido', 'erro', 'cancelado'];
const ETAPAS_JOB = ['coleta', 'normalizacao', 'deduplicacao', 'enriquecimento', 'score'];
const TIPOS_JOB = ['pesquisa', 'importacao', 'inbound', 'manual'];

// [SQL] migrations/006_capture_raw.sql
const STATUS_CAPTURA = ['pendente', 'duplicado', 'possivel_duplicado', 'descartado', 'bloqueado_optout', 'aprovado', 'erro'];
const MOTIVOS_DESCARTE = ['fora_do_perfil', 'dados_invalidos', 'duplicado', 'empresa_fechada', 'sem_interesse', 'outro'];

// [SQL] migrations/001_arquivamento.sql
const MOTIVOS_ARQUIVAMENTO = ['inatividade_automatica', 'sem_interesse', 'dados_invalidos', 'duplicado', 'mesclado', 'optout', 'outro'];

// [SQL] migrations/007_oportunidades.sql
const OPORTUNIDADES = {
  SEM_SITE: { label: 'Sem site', automatica: true },
  SITE_FORA_DO_AR: { label: 'Site fora do ar', automatica: true },
  SITE_SEM_HTTPS: { label: 'Site sem HTTPS', automatica: true },
  // [SQL] migrations/011_refinamento.sql — medidos na página inicial (enriquecer.js)
  SITE_SEM_CONTATO: { label: 'Site sem contato visível', automatica: true },
  SITE_SEM_FORMULARIO: { label: 'Site sem formulário', automatica: true },
  // [SQL] migrations/013_fase3_operacao.sql — medidos nas páginas verificadas (enriquecer.js)
  SITE_SEM_META_DESCRIPTION: { label: 'Site sem descrição para o Google', automatica: true },
  SITE_SEM_FAVICON: { label: 'Site sem ícone (favicon)', automatica: true },
  SITE_SEM_WHATSAPP: { label: 'Site sem link de WhatsApp', automatica: true },
  SITE_SEM_INSTAGRAM: { label: 'Site sem link para o Instagram', automatica: true },
  EMPRESA_NOVA: { label: 'Empresa nova', automatica: true },
  BAIXA_PRESENCA_DIGITAL: { label: 'Baixa presença digital', automatica: true, derivada: true },
  INSTAGRAM_INATIVO: { label: 'Instagram inativo', automatica: false },
  INSTAGRAM_DESORGANIZADO: { label: 'Instagram desorganizado', automatica: false },
  GOOGLE_PERFIL_FRACO: { label: 'Perfil do Google fraco', automatica: false },
  SITE_DESATUALIZADO: { label: 'Site desatualizado', automatica: false },
  IDENTIDADE_INCONSISTENTE: { label: 'Identidade visual inconsistente', automatica: false },
  EXPANSAO: { label: 'Em expansão / nova unidade', automatica: false },
};

// Cidades do Vale do São Francisco (mesma lista das sugestões do painel).
// [SQL] migrations/008_score_temperatura.sql (prospeccao_cidades_regiao)
const CIDADES_REGIAO = [
  { cidade: 'Petrolina', uf: 'PE', ddd: '87' },
  { cidade: 'Juazeiro', uf: 'BA', ddd: '74' },
  { cidade: 'Lagoa Grande', uf: 'PE', ddd: '87' },
  { cidade: 'Santa Maria da Boa Vista', uf: 'PE', ddd: '87' },
  { cidade: 'Casa Nova', uf: 'BA', ddd: '74' },
  { cidade: 'Sobradinho', uf: 'BA', ddd: '74' },
  { cidade: 'Curaçá', uf: 'BA', ddd: '74' },
  { cidade: 'Orocó', uf: 'PE', ddd: '87' },
  { cidade: 'Dormentes', uf: 'PE', ddd: '87' },
  { cidade: 'Afrânio', uf: 'PE', ddd: '87' },
];
const DDD_PADRAO = '87';

// [SQL] migrations/008_score_temperatura.sql (calcular_temperatura)
const TEMPERATURA = {
  quenteDiasInteracao: 14,
  quenteDiasInbound: 7,
  mornoDiasInteracao: 45,
  mornoDiasInbound: 30,
  mornoDiasRespondeu: 30,
  // Atividades que vêm DO LEAD (não da equipe). whatsapp_enviado/email_enviado NÃO aquecem.
  atividadesDoLead: ['resposta_recebida', 'reuniao_marcada', 'reuniao_realizada', 'proposta_enviada', 'negociacao'],
};

// Faixas de score (mesmas de antes — a equipe já lê assim).
const FAIXAS_SCORE = [
  { chave: 'prioritario', label: 'Prioritário', min: 91 },
  { chave: 'prospectar', label: 'Prospectar', min: 61 },
  { chave: 'nutrir', label: 'Nutrir', min: 31 },
  { chave: 'aguardar', label: 'Aguardar', min: 0 },
];
function faixaScore(score) {
  const s = Number(score) || 0;
  return FAIXAS_SCORE.find((f) => s >= f.min);
}

/**
 * Setores. `estrategico` marca o setor que ganha pontos de encaixe no score
 * (a captação preenche sinal_segmento_alto_potencial com isso). A lista
 * inicial de estratégicos segue os setores citados pelo dono no briefing
 * do Capture Engine — DECISÃO DE NEGÓCIO, ajuste aqui.
 */
const SETORES = [
  {
    id: 'Arquitetura', estrategico: true,
    sinonimos: ['arquitet', 'urbanis', 'design de interiores', 'interiores', 'paisagis'],
    geoapify: { especificas: ['office.architect'], genericas: [] },
    osm: { especificas: [['office', 'architect']], genericas: [] },
    termos: ['arquitet', 'interiores'],
  },
  {
    id: 'Construção', estrategico: true,
    sinonimos: ['constru', 'engenharia', 'edifica', 'incorpora', 'empreiteir', 'obras', 'material de constru'],
    geoapify: {
      especificas: [
        'commercial.houseware_and_hardware.building_materials',
        'commercial.houseware_and_hardware.hardware_and_tools',
        'commercial.houseware_and_hardware.doityourself',
        'service.metal_construction',
      ],
      genericas: ['office.company', 'office'],
    },
    osm: {
      especificas: [['shop', 'hardware'], ['shop', 'doityourself'], ['craft', 'builder']],
      genericas: [['office', 'company']],
    },
    termos: ['constru', 'engenharia', 'edifica', 'incorpora', 'empreiteir', 'obras'],
  },
  {
    id: 'Imobiliário', estrategico: true,
    sinonimos: ['imobili', 'imóve', 'imove', 'corretor', 'loteament'],
    geoapify: { especificas: ['office.estate_agent', 'service.estate_agent'], genericas: ['office.company'] },
    osm: { especificas: [['office', 'estate_agent']], genericas: [['office', 'company']] },
    termos: ['imobili', 'imove', 'imóve', 'loteament'],
  },
  {
    id: 'Saúde', estrategico: true,
    sinonimos: ['saude', 'saúde', 'clinic', 'clínic', 'odonto', 'dentist', 'medic', 'médic', 'hospital', 'fisio', 'psicolog', 'nutri', 'laborat'],
    geoapify: { especificas: ['healthcare.clinic_or_praxis', 'healthcare.dentist', 'healthcare.hospital'], genericas: [] },
    osm: { especificas: [['amenity', 'clinic'], ['amenity', 'doctors'], ['amenity', 'dentist'], ['amenity', 'hospital']], genericas: [] },
    termos: ['clinic', 'clínic', 'odonto', 'saude', 'saúde'],
  },
  {
    id: 'Beleza e estética', estrategico: true,
    sinonimos: ['beleza', 'estetic', 'estétic', 'salao', 'salão', 'cabeleir', 'barbear', 'cosmet', 'manicure', 'spa'],
    geoapify: {
      especificas: ['service.beauty', 'commercial.health_and_beauty.cosmetics'],
      genericas: [],
    },
    osm: { especificas: [['shop', 'hairdresser'], ['shop', 'beauty'], ['shop', 'cosmetics']], genericas: [] },
    termos: ['estetic', 'estétic', 'beleza'],
  },
  {
    id: 'Agronegócio', estrategico: true,
    sinonimos: ['agro', 'agric', 'agríc', 'fazenda', 'fruta', 'cooperativa', 'vinicola', 'vinícola', 'irriga', 'pecuar'],
    geoapify: { especificas: ['commercial.agrarian', 'production.winery', 'commercial.food_and_drink.farm'], genericas: ['office.company', 'office.association'] },
    osm: { especificas: [['shop', 'agrarian'], ['craft', 'winery']], genericas: [['office', 'company'], ['office', 'association']] },
    termos: ['agro', 'agric', 'agríc', 'cooperativa', 'fruta', 'irriga', 'vinicola', 'vinícola'],
  },
  {
    id: 'Alimentação', estrategico: false,
    sinonimos: ['aliment', 'restaurant', 'lanchon', 'padaria', 'pizzar', 'cafe', 'café', 'hamburg', 'doceria', 'buffet', 'bar '],
    geoapify: { especificas: ['catering.restaurant', 'catering.cafe', 'catering.fast_food', 'commercial.food_and_drink.bakery'], genericas: [] },
    osm: { especificas: [['amenity', 'restaurant'], ['amenity', 'cafe'], ['amenity', 'fast_food'], ['shop', 'bakery']], genericas: [] },
    termos: [],
  },
  {
    id: 'Tecnologia', estrategico: false,
    sinonimos: ['tecnolog', 'software', 'informat', 'sistemas', 'internet', 'provedor', 'telecom', ' ti '],
    geoapify: { especificas: ['office.it', 'office.telecommunication'], genericas: ['office.company'] },
    osm: { especificas: [['office', 'it'], ['office', 'telecommunication']], genericas: [['office', 'company']] },
    termos: ['tecnolog', 'software', 'informat', 'sistemas', 'telecom', 'provedor'],
  },
  {
    id: 'Coworking', estrategico: true,
    sinonimos: ['cowork', 'coliving', 'escritorio compartilhado', 'escritório compartilhado', 'espaco de trabalho', 'espaço de trabalho'],
    geoapify: { especificas: ['office.coworking'], genericas: ['office.company'] },
    osm: { especificas: [['office', 'coworking'], ['amenity', 'coworking_space']], genericas: [['office', 'company']] },
    termos: ['cowork'],
  },
  {
    id: 'Varejo', estrategico: false,
    sinonimos: ['varejo', 'loja', 'comerc', 'magazine', 'boutique', 'supermerc', 'atacad', 'distribuidor', 'moda', 'calçad', 'calcad', 'otica', 'ótica', 'farmac'],
    geoapify: {
      especificas: ['commercial.clothing', 'commercial.supermarket', 'commercial.department_store', 'commercial.shopping_mall', 'commercial.furniture_and_interior', 'commercial.jewelry', 'commercial.health_and_beauty.optician'],
      genericas: ['commercial.trade'],
    },
    osm: { especificas: [['shop', 'clothes'], ['shop', 'supermarket'], ['shop', 'department_store'], ['shop', 'furniture'], ['shop', 'jewelry'], ['shop', 'optician']], genericas: [['shop', 'wholesale']] },
    termos: ['atacad', 'distribuid'],
  },
  {
    id: 'Serviços', estrategico: false,
    sinonimos: ['servic', 'serviç', 'contabil', 'advoca', 'advog', 'consultor', 'agencia', 'agência', 'marketing', 'seguro', 'transport', 'logistic', 'logíst', 'mudanc', 'mudanç'],
    geoapify: {
      especificas: ['office.accountant', 'office.lawyer', 'office.consulting', 'office.insurance', 'office.logistics', 'office.advertising_agency', 'office.tax_advisor'],
      genericas: [],
    },
    osm: { especificas: [['office', 'accountant'], ['office', 'lawyer'], ['office', 'consulting'], ['office', 'insurance'], ['office', 'logistics'], ['office', 'advertising_agency'], ['office', 'tax_advisor']], genericas: [] },
    termos: [],
  },
  {
    id: 'Educação', estrategico: false,
    sinonimos: ['educa', 'escola', 'colegio', 'colégio', 'faculdade', 'universidade', 'curso', 'idioma', 'autoescola', 'creche'],
    geoapify: { especificas: ['education.school', 'education.college', 'education.university', 'education.language_school', 'education.driving_school', 'childcare.kindergarten'], genericas: [] },
    osm: { especificas: [['amenity', 'school'], ['amenity', 'college'], ['amenity', 'university'], ['amenity', 'language_school'], ['amenity', 'driving_school'], ['amenity', 'kindergarten']], genericas: [] },
    termos: [],
  },
  {
    id: 'Hotelaria e turismo', estrategico: false,
    sinonimos: ['hotel', 'pousada', 'resort', 'hostel', 'turism', 'viagem', 'viagens', 'hospedag', 'motel'],
    geoapify: { especificas: ['accommodation.hotel', 'accommodation.guest_house', 'accommodation.hostel', 'accommodation.motel', 'office.travel_agent'], genericas: [] },
    osm: { especificas: [['tourism', 'hotel'], ['tourism', 'guest_house'], ['tourism', 'hostel'], ['tourism', 'motel'], ['shop', 'travel_agency']], genericas: [] },
    termos: [],
  },
  {
    id: 'Indústria', estrategico: false,
    sinonimos: ['industr', 'fabrica', 'fábrica', 'textil', 'têxtil', 'embalag', 'plastic', 'plástic', 'metalurg', 'cervejar', 'destilar'],
    geoapify: { especificas: ['production.factory', 'production.brewery', 'production.distillery'], genericas: ['office.company'] },
    osm: { especificas: [['man_made', 'works'], ['craft', 'brewery'], ['craft', 'distillery']], genericas: [['office', 'company']] },
    termos: ['industr', 'fabrica', 'fábrica', 'textil', 'têxtil', 'embalag'],
  },
  {
    id: 'Automotivo', estrategico: false,
    sinonimos: ['automo', 'automó', 'veicul', 'veícul', 'concession', 'oficina', 'auto pec', 'autopec', 'motos', 'motors', 'seminov', 'pneu'],
    geoapify: { especificas: ['commercial.vehicle', 'rental.car'], genericas: [] },
    osm: { especificas: [['shop', 'car'], ['shop', 'car_repair'], ['shop', 'car_parts'], ['shop', 'tyres'], ['shop', 'motorcycle']], genericas: [] },
    termos: [],
  },
  {
    id: 'Outro', estrategico: false,
    sinonimos: [],
    geoapify: { especificas: [], genericas: [] },
    osm: { especificas: [], genericas: [] },
    termos: [],
  },
];

const SETOR_IDS = SETORES.map((s) => s.id);

function semAcento(s) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
}

function porId(id) {
  return SETORES.find((s) => s.id === id) || null;
}

/**
 * Texto livre → setor da lista (ou null). Compara sem acento.
 * Setores legados do banco ("Construção Civil/Engenharia", "Coworking (nicho
 * saúde)", "Coworking/Coliving") caem aqui também.
 * @returns {{ setor: string|null, subsetor: string|null }}
 */
function classificarSetor(texto) {
  const original = String(texto || '').trim();
  if (!original) return { setor: null, subsetor: null };
  const exato = SETORES.find((s) => semAcento(s.id) === semAcento(original));
  if (exato) return { setor: exato.id, subsetor: null };
  // Compara por INÍCIO de palavra (pontuação vira espaço): "spa" não casa com "espaço".
  const alvo = ` ${semAcento(original).replace(/[^a-z0-9]+/g, ' ')} `;
  // Coworking primeiro: "Coworking (nicho saúde)" é coworking, não saúde.
  const ordem = [porId('Coworking'), ...SETORES.filter((s) => s.id !== 'Coworking')];
  for (const s of ordem) {
    if (s.sinonimos.some((sin) => alvo.includes(` ${semAcento(sin).replace(/[^a-z0-9]+/g, ' ').trim()}`))) {
      return { setor: s.id, subsetor: subsetorDe(original, s.id) };
    }
  }
  return { setor: null, subsetor: original.slice(0, 120) };
}

/** "Coworking (nicho saúde)" → "Nicho saúde"; "Coworking/Coliving" → "Coliving"; "Construtora" → "Construtora". */
function subsetorDe(original, setor) {
  let resto = original;
  const re = new RegExp(`^${semAcento(setor).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'i');
  if (re.test(semAcento(original))) resto = original.slice(setor.length);
  resto = resto.replace(/^[\s/()\-–:]+|[\s)]+$/g, '').trim();
  if (!resto || semAcento(resto) === semAcento(setor)) return null;
  return resto.charAt(0).toUpperCase() + resto.slice(1);
}

/** Versão pública (sem funções) para o painel. */
function publica() {
  return {
    setores: SETORES.map((s) => ({ id: s.id, estrategico: s.estrategico })),
    fontes: FONTES,
    metodos: METODOS,
    providers: PROVIDERS,
    statusJob: STATUS_JOB,
    statusCaptura: STATUS_CAPTURA,
    motivosDescarte: MOTIVOS_DESCARTE,
    motivosArquivamento: MOTIVOS_ARQUIVAMENTO,
    oportunidades: OPORTUNIDADES,
    cidadesRegiao: CIDADES_REGIAO.map((c) => `${c.cidade}, ${c.uf}`),
    faixasScore: FAIXAS_SCORE,
    temperatura: TEMPERATURA,
    limites: LIMITES,
  };
}

// Limites operacionais (seção 16 da especificação).
const LIMITES = {
  cidadesPorJob: 6,
  raiosKm: [5, 15, 30],
  resultadosPorProviderCidade: 500,
  registrosPorJob: 1500,
  jobsAtivosPorUsuario: 1,
  jobsPorDia: 10,
  checagensSitePorJob: 50,
  csvMaxBytes: 4 * 1024 * 1024,
  paginaPadrao: 50,
  paginaMaxima: 100,
};

module.exports = {
  FONTES, FONTES_LEGADAS, METODOS, PROVIDERS, STATUS_JOB, ETAPAS_JOB, TIPOS_JOB,
  STATUS_CAPTURA, MOTIVOS_DESCARTE, MOTIVOS_ARQUIVAMENTO, OPORTUNIDADES,
  CIDADES_REGIAO, DDD_PADRAO, TEMPERATURA, FAIXAS_SCORE, SETORES, SETOR_IDS, LIMITES,
  direcao, faixaScore, porId, classificarSetor, semAcento, publica,
};
