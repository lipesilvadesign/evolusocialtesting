/**
 * Provider OpenStreetMap / Overpass — busca por TAGS do setor (taxonomia.js)
 * + tags genéricas filtradas por termo no nome. Reaproveita a estratégia de
 * resiliência existente (espelhos, 429/Retry-After, timeout 8 s por espelho)
 * de _lib/integrations/openStreetMap.js (postOverpassQuery).
 */
const { registro } = require('../tipos');
const taxonomia = require('../taxonomia');
const osm = require('../../integrations/openStreetMap');

function escaparRegex(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\"]/g, '\\$&');
}

/** Monta a consulta Overpass QL (exportada para teste). */
function montarConsulta(def, lat, lon, raioM, termos, timeoutS = 25) {
  const around = `around:${raioM},${lat},${lon}`;
  const linhas = [];
  for (const [k, v] of def.osm.especificas) {
    linhas.push(`nwr["${k}"="${v}"]["name"](${around});`);
  }
  if (def.osm.genericas.length && termos.length) {
    const re = [...new Set(termos)].map((t) => escaparRegex(t)).join('|');
    for (const [k, v] of def.osm.genericas) linhas.push(`nwr["${k}"="${v}"]["name"~"${re}",i](${around});`);
    // Reforço por nome sem tag (muitas empresas no OSM só têm nome) — nunca a ÚNICA estratégia do setor
    // 30/09: só node/way (relações com regex de nome são a parte mais cara da consulta)
    linhas.push(`nw["name"~"${re}",i]["building"!~"."](${around});`);
  }
  if (!linhas.length) return null;
  return `[out:json][timeout:${Math.max(5, Math.min(25, Math.round(timeoutS)))}];(${linhas.join('')});out center tags;`;
}

function montarEndereco(tags) {
  const partes = [tags['addr:street'], tags['addr:housenumber'], tags['addr:suburb']].filter(Boolean);
  return partes.length ? partes.join(', ') : null;
}

function paraRegistro(el, setor) {
  const t = (el && el.tags) || {};
  if (!t.name || !el.type || el.id === undefined) return null;
  const lat = el.lat !== undefined ? el.lat : el.center && el.center.lat;
  const lon = el.lon !== undefined ? el.lon : el.center && el.center.lon;
  const categoria = ['office', 'shop', 'craft', 'amenity', 'tourism', 'man_made'].filter((k) => t[k]).map((k) => `${k}=${t[k]}`).join(',');
  return registro({
    provider: 'overpass',
    external_id: `osm:${el.type}/${el.id}`,
    payload: { type: el.type, id: el.id, tags: t },
    empresa: t.name,
    telefone: t.phone || t['contact:phone'] || t['contact:mobile'] || null,
    email: t.email || t['contact:email'] || null,
    site: t.website || t['contact:website'] || t.url || null,
    instagram: t['contact:instagram'] || null,
    cnpj: t['ref:vatin'] || t['ref:CNPJ'] || null,
    endereco: montarEndereco(t),
    cidade: t['addr:city'] || null,
    uf: t['addr:state'] && /^[A-Za-z]{2}$/.test(t['addr:state']) ? t['addr:state'].toUpperCase() : null,
    lat: Number.isFinite(Number(lat)) ? Number(lat) : null,
    lon: Number.isFinite(Number(lon)) ? Number(lon) : null,
    categoria_origem: categoria || null,
    setor_sugerido: setor || null,
  });
}

/**
 * @param {{ setor: string, termo?: string, lat: number, lon: number, raioKm: number, limite?: number }} params
 * @param {{ consultar?: Function }} [ctx] consultar injetável nos testes
 */
async function coletar(params, ctx = {}) {
  const def = taxonomia.porId(params.setor);
  if (!def) return { registros: [], avisos: [`Setor sem mapeamento OSM: ${params.setor}`] };
  const termos = [...def.termos, ...(params.termo ? [params.termo] : [])];
  const prazoMs = Number(ctx.prazoMs) > 0 ? Number(ctx.prazoMs) : null;
  const q = montarConsulta(def, params.lat, params.lon, Math.round(Math.min(params.raioKm || 15, 30) * 1000), termos, prazoMs ? prazoMs / 1000 - 2 : 25);
  if (!q) return { registros: [], avisos: [`Setor "${params.setor}" não tem tag OSM`] };
  const consultar = ctx.consultar || osm.postOverpassQuery;
  const opcoes = {};
  if (prazoMs) opcoes.prazoMs = prazoMs;
  if (typeof ctx.ordenar === 'function') opcoes.ordenar = ctx.ordenar;
  if (typeof ctx.registrar === 'function') opcoes.registrar = ctx.registrar;
  const elementos = await consultar(q, Object.keys(opcoes).length ? opcoes : undefined);
  const limite = Math.min(params.limite || taxonomia.LIMITES.resultadosPorProviderCidade, 500);
  const vistos = new Set();
  const registros = [];
  for (const el of elementos) {
    const r = paraRegistro(el, params.setor);
    if (r && !vistos.has(r.external_id)) { vistos.add(r.external_id); registros.push(r); }
    if (registros.length >= limite) break;
  }
  return { registros, avisos: [] };
}

module.exports = { id: 'overpass', requer: [], suportaTipo: ['pesquisa'], coletar, paraRegistro, montarConsulta };
