/**
 * Provider manual — o formulário "Novo lead" do painel. Não cria job: o
 * cadastro manual já É a decisão humana. Passa pela mesma normalização e
 * deduplicação (a Function avisa "possível duplicado" antes de gravar).
 */
const crypto = require('crypto');
const { registro } = require('../tipos');

function paraRegistro(payload) {
  return registro({
    provider: 'manual',
    external_id: `manual:${crypto.randomUUID()}`,
    payload: {},
    empresa: payload.empresa,
    telefone: payload.telefone,
    email: payload.email,
    site: payload.site,
    instagram: payload.instagram,
    cnpj: payload.cnpj,
    endereco: payload.endereco,
    cidade: payload.cidade,
    uf: payload.uf,
    lat: null,
    lon: null,
    categoria_origem: null,
    setor_sugerido: payload.setor,
  });
}

module.exports = { id: 'manual', requer: [], suportaTipo: ['manual'], paraRegistro };
