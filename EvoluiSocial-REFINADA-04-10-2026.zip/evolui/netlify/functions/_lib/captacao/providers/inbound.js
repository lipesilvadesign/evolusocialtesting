/**
 * Providers de entrada pelo site (inbound): consultoria gratuita
 * (consultas_leads) e formulário "Vamos conversar" (site_contatos).
 * Transformam uma linha do formulário em RegistroIntermediario.
 *
 * Empresa: formulário identifica uma PESSOA e nem sempre traz o nome da
 * empresa. Regra (sem inventar): @instagram se houver, senão
 * "<nome da pessoa> (a identificar)". A pessoa vira contato principal na
 * conversão (RPC prospeccao_converter_inbound, migration 009).
 */
const { registro } = require('../tipos');

function empresaDe(nome, instagram) {
  const ig = String(instagram || '').trim().replace(/^@/, '');
  if (ig) return `@${ig}`;
  return `${String(nome || 'Contato').trim() || 'Contato'} (a identificar)`;
}

const consultoria = {
  id: 'consultoria',
  requer: [],
  suportaTipo: ['inbound'],
  paraRegistro(row) {
    return registro({
      provider: 'consultoria',
      external_id: `consulta:${row.id}`,
      payload: { nome: row.nome, segmento: row.segmento, objetivo: row.objetivo, criado_em: row.created_at },
      empresa: empresaDe(row.nome, row.instagram),
      telefone: row.whatsapp || null,
      email: row.email || null,
      site: null,
      instagram: row.instagram || null,
      cnpj: null, endereco: null, cidade: null, uf: null, lat: null, lon: null,
      categoria_origem: row.segmento || null,
      setor_sugerido: row.segmento ? String(row.segmento).replace(/_/g, ' ') : null,
    });
  },
};

const siteContato = {
  id: 'site_contato',
  requer: [],
  suportaTipo: ['inbound'],
  paraRegistro(row) {
    return registro({
      provider: 'site_contato',
      external_id: `site_contato:${row.id}`,
      payload: { nome: row.nome, servico: row.servico, orcamento: row.orcamento, criado_em: row.created_at },
      empresa: empresaDe(row.nome, null),
      telefone: row.whatsapp || null,
      email: row.email || null,
      site: null, instagram: null, cnpj: null, endereco: null, cidade: null, uf: null, lat: null, lon: null,
      categoria_origem: row.servico || null,
      setor_sugerido: null,
    });
  },
};

module.exports = { consultoria, siteContato, empresaDe };
