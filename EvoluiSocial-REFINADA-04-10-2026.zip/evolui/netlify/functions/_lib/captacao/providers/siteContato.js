/** Provider "contato do site" (site_contatos) — ver inbound.js. */
module.exports = require('./inbound').siteContato;
