/**
 * Consulta de CNPJ — BrasilAPI (https://brasilapi.com.br/api/cnpj/v1/{cnpj}),
 * serviço público e gratuito que republica dados abertos da Receita Federal.
 *
 * DESLIGADO por padrão (ENABLE_CNPJ_LOOKUP): a escolha do fornecedor é decisão
 * do dono (pendência registrada desde a especificação). Com a flag desligada
 * este módulo não faz nenhuma requisição.
 *
 * Regras:
 *  - só consulta CNPJ que já veio da fonte e passou na validação de dígitos;
 *  - timeout 6 s, sem nova tentativa (é enriquecimento, nunca bloqueia);
 *  - grava fonte e data da consulta; nunca sobrescreve dado manual (o banco
 *    só preenche campo vazio — prospeccao_gravar_enriquecimento);
 *  - EMPRESA_NOVA só com data de início de atividade informada pela fonte
 *    (menos de 12 meses — critério documentado, não um julgamento).
 * LGPD: dados cadastrais de pessoa jurídica (dado público). Quadro de sócios
 * NÃO é gravado (pode conter nome de pessoa física) — VALIDAÇÃO JURÍDICA NECESSÁRIA
 * antes de ampliar os campos guardados.
 */
const { cnpj: normalizarCnpj } = require('../normalizar');

const URL_BASE = 'https://brasilapi.com.br/api/cnpj/v1/';
const TIMEOUT_MS = 6000;
const MESES_EMPRESA_NOVA = 12;

async function consultar(cnpjBruto, { fetchImpl = fetch, timeoutMs = TIMEOUT_MS } = {}) {
  const doc = normalizarCnpj(cnpjBruto);
  if (!doc) return { ok: false, motivo: 'CNPJ inválido' };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const inicio = Date.now();
  try {
    const res = await fetchImpl(`${URL_BASE}${doc}`, { signal: controller.signal, headers: { Accept: 'application/json' } });
    if (res.status === 404) return { ok: false, motivo: 'CNPJ não encontrado na fonte', duracao_ms: Date.now() - inicio };
    if (!res.ok) return { ok: false, motivo: `BrasilAPI respondeu ${res.status}`, duracao_ms: Date.now() - inicio };
    const d = await res.json();
    return {
      ok: true,
      duracao_ms: Date.now() - inicio,
      dados: {
        cnpj: doc,
        razao_social: d.razao_social || null,
        nome_fantasia: d.nome_fantasia || null,
        situacao: d.descricao_situacao_cadastral || null,
        inicio_atividade: d.data_inicio_atividade || null,
        cnae_principal: d.cnae_fiscal_descricao || null,
        municipio: d.municipio || null,
        uf: d.uf || null,
        porte: d.porte || null,
        fonte: 'BrasilAPI (dados abertos da Receita Federal)',
        consultado_em: new Date().toISOString(),
      },
    };
  } catch (err) {
    return { ok: false, motivo: err.name === 'AbortError' ? 'timeout' : 'falha de rede', duracao_ms: Date.now() - inicio };
  } finally {
    clearTimeout(timer);
  }
}

/** Sinal EMPRESA_NOVA com evidência da própria fonte (ou nada). */
function sinalEmpresaNova(dados, agora = new Date()) {
  if (!dados || !/^\d{4}-\d{2}-\d{2}$/.test(String(dados.inicio_atividade || ''))) return null;
  const inicio = new Date(`${dados.inicio_atividade}T00:00:00Z`);
  const limite = new Date(agora);
  limite.setUTCMonth(limite.getUTCMonth() - MESES_EMPRESA_NOVA);
  if (inicio < limite || inicio > agora) return null;
  return {
    tipo: 'EMPRESA_NOVA', confianca: 'alta', fonte: 'sistema', detectado_em: agora.toISOString(),
    evidencia: `${dados.fonte}: início de atividade em ${dados.inicio_atividade} (consultado em ${dados.consultado_em.slice(0, 10)}).`,
  };
}

module.exports = { consultar, sinalEmpresaNova, MESES_EMPRESA_NOVA };
