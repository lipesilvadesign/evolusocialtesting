/** Provider "consultoria gratuita" (consultas_leads) — ver inbound.js. */
module.exports = require('./inbound').consultoria;
