/**
 * Provider Geoapify Places — busca por CATEGORIA do setor (taxonomia.js),
 * não pelo nome.
 *
 * Por que a busca antiga dava zero: pedia 7 categorias amplíssimas e depois
 * filtrava localmente "nome contém o ramo". Numa cidade como Petrolina os 500
 * primeiros resultados vinham de outras coisas e nenhum tinha "constru" no
 * nome. Agora:
 *   1. categorias ESPECÍFICAS do setor → todo resultado entra (sem filtro de nome);
 *   2. categorias GENÉRICAS (ex.: office.company) → entra só quem tem um termo
 *      do setor no nome (reforço, nunca a única estratégia).
 * Retry: 1 nova tentativa em 429/5xx com espera (backoff). Timeout 20 s.
 */
const { registro } = require('../tipos');
const taxonomia = require('../taxonomia');

const TIMEOUT_MS = Number(process.env.GEOAPIFY_TIMEOUT_MS) || 20000;
const BACKOFF_MS = 2500;

async function fetchComTimeout(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    return await fetch(url, { signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}
const aguardar = (ms) => new Promise((r) => setTimeout(r, ms));

async function buscarCategorias(categorias, lat, lon, raioM, limite, apiKey) {
  const url = `https://api.geoapify.com/v2/places?categories=${categorias.join(',')}` +
    `&filter=circle:${lon},${lat},${raioM}&bias=proximity:${lon},${lat}&limit=${limite}&apiKey=${encodeURIComponent(apiKey)}`;
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    let res;
    try {
      res = await fetchComTimeout(url);
    } catch (err) {
      if (tentativa === 0) { await aguardar(BACKOFF_MS); continue; }
      throw new Error(`Geoapify: falha de rede (${err.name === 'AbortError' ? 'timeout' : 'conexão'})`);
    }
    if ((res.status === 429 || res.status >= 500) && tentativa === 0) {
      const ra = Number(res.headers && res.headers.get && res.headers.get('retry-after'));
      await aguardar(Number.isFinite(ra) && ra > 0 ? Math.min(ra * 1000, 10000) : BACKOFF_MS);
      continue;
    }
    if (!res.ok) {
      const dica = res.status === 401 ? ' (chave inválida)' : res.status === 429 ? ' (limite de créditos)' : '';
      throw new Error(`Geoapify respondeu ${res.status}${dica}`);
    }
    const data = await res.json().catch(() => null);
    if (!data || !Array.isArray(data.features)) throw new Error('Geoapify: resposta inválida');
    return data.features;
  }
  return [];
}

function nomeTemTermo(nome, termos) {
  const n = taxonomia.semAcento(nome);
  return termos.some((t) => n.includes(taxonomia.semAcento(t)));
}

/** Feature GeoJSON → RegistroIntermediario (null se não tiver nome/id). */
function paraRegistro(feature, setor) {
  const p = (feature && feature.properties) || {};
  if (!p.name || !p.place_id) return null;
  const contato = p.contact || {};
  const coords = feature.geometry && Array.isArray(feature.geometry.coordinates) ? feature.geometry.coordinates : [p.lon, p.lat];
  return registro({
    provider: 'geoapify',
    external_id: `geoapify:${p.place_id}`,
    payload: { properties: p },
    empresa: p.name,
    telefone: contato.phone || p.phone || null,
    email: contato.email || p.email || null,
    site: p.website || contato.website || null,
    instagram: (p.datasource && p.datasource.raw && (p.datasource.raw['contact:instagram'] || p.datasource.raw.instagram)) || null,
    cnpj: null,
    endereco: p.address_line2 || p.formatted || null,
    cidade: p.city || null,
    uf: p.state_code && /^[A-Za-z]{2}$/.test(p.state_code) ? p.state_code.toUpperCase() : null,
    lat: Number.isFinite(Number(coords[1])) ? Number(coords[1]) : null,
    lon: Number.isFinite(Number(coords[0])) ? Number(coords[0]) : null,
    categoria_origem: Array.isArray(p.categories) ? p.categories.slice(0, 6).join(',') : null,
    setor_sugerido: setor || null,
  });
}

/**
 * @param {{ setor: string, termo?: string, lat: number, lon: number, raioKm: number, limite?: number }} params
 * @param {{ apiKey: string, buscar?: Function }} ctx  buscar é injetável nos testes
 * @returns {Promise<{ registros: object[], avisos: string[] }>}
 */
async function coletar(params, ctx) {
  if (!ctx.apiKey) return { registros: [], avisos: ['Geoapify não configurado (GEOAPIFY_API_KEY ausente)'] };
  const def = taxonomia.porId(params.setor);
  if (!def) return { registros: [], avisos: [`Setor sem mapeamento Geoapify: ${params.setor}`] };
  const buscar = ctx.buscar || buscarCategorias;
  const raioM = Math.round(Math.min(params.raioKm || 15, 30) * 1000);
  const limite = Math.min(params.limite || taxonomia.LIMITES.resultadosPorProviderCidade, 500);
  const termos = [...def.termos, ...(params.termo ? [params.termo] : [])];
  const vistos = new Set();
  const registros = [];
  const avisos = [];

  if (def.geoapify.especificas.length) {
    const features = await buscar(def.geoapify.especificas, params.lat, params.lon, raioM, limite, ctx.apiKey);
    for (const f of features) {
      const r = paraRegistro(f, params.setor);
      if (r && !vistos.has(r.external_id)) { vistos.add(r.external_id); registros.push(r); }
    }
  }
  if (def.geoapify.genericas.length && termos.length) {
    try {
      const features = await buscar(def.geoapify.genericas, params.lat, params.lon, raioM, limite, ctx.apiKey);
      for (const f of features) {
        const r = paraRegistro(f, params.setor);
        if (r && !vistos.has(r.external_id) && nomeTemTermo(r.empresa, termos)) { vistos.add(r.external_id); registros.push(r); }
      }
    } catch (err) {
      avisos.push(`Geoapify (categorias genéricas): ${err.message}`);
    }
  }
  if (!def.geoapify.especificas.length && !def.geoapify.genericas.length) avisos.push(`Setor "${params.setor}" não tem categoria Geoapify`);
  return { registros: registros.slice(0, limite), avisos };
}

module.exports = { id: 'geoapify', requer: ['GEOAPIFY_API_KEY'], suportaTipo: ['pesquisa'], coletar, paraRegistro, buscarCategorias };
