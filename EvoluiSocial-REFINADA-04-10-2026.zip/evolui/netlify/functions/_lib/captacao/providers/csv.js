/**
 * Provider CSV — parser NO SERVIDOR (antes era no navegador e só aceitava
 * vírgula).
 * - Bytes chegam em base64; UTF-8 é tentado primeiro (BOM removido); se o
 *   arquivo não for UTF-8 válido, cai para Windows-1252 (padrão do Excel em
 *   português) e avisa.
 * - Delimitador detectado pela primeira linha, contando ; , e TAB fora de
 *   aspas (pode ser forçado).
 * - Aspas duplas, aspas escapadas ("") e quebra de linha dentro de campo.
 * - Cabeçalhos diferentes → mapeamento automático por sinônimos; o usuário
 *   pode trocar na prévia.
 * XLSX: não suportado nesta versão (ver docs/LEAD_CAPTURE_ENGINE.md — decisão
 * de dependência pendente). Orientação: "Salvar como CSV UTF-8".
 */
const crypto = require('crypto');
const { registro } = require('../tipos');
const taxonomia = require('../taxonomia');

const MAX_LINHAS = taxonomia.LIMITES.registrosPorJob;

/** @returns {{ texto: string, codificacao: 'utf-8'|'windows-1252', avisos: string[] }} */
function decodificar(buffer) {
  const avisos = [];
  let bytes = buffer;
  if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) bytes = bytes.subarray(3);
  try {
    const texto = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    return { texto: texto.replace(/^﻿/, ''), codificacao: 'utf-8', avisos };
  } catch {
    avisos.push('Arquivo não está em UTF-8: lido como Windows-1252 (Excel). Confira os acentos na prévia.');
    return { texto: new TextDecoder('windows-1252').decode(bytes), codificacao: 'windows-1252', avisos };
  }
}

function detectarDelimitador(texto) {
  const primeira = texto.split(/\r?\n/).find((l) => l.trim()) || '';
  const contagem = { ';': 0, ',': 0, '\t': 0 };
  let aspas = false;
  for (const ch of primeira) {
    if (ch === '"') aspas = !aspas;
    else if (!aspas && ch in contagem) contagem[ch] += 1;
  }
  const [melhor, n] = Object.entries(contagem).sort((a, b) => b[1] - a[1])[0];
  return n > 0 ? melhor : ',';
}

/** @returns {string[][]} */
function parse(texto, delimitador) {
  const linhas = [];
  let linha = [];
  let campo = '';
  let aspas = false;
  for (let i = 0; i < texto.length; i++) {
    const ch = texto[i];
    if (aspas) {
      if (ch === '"') {
        if (texto[i + 1] === '"') { campo += '"'; i++; } else aspas = false;
      } else campo += ch;
    } else if (ch === '"' && campo === '') aspas = true;
    else if (ch === delimitador) { linha.push(campo); campo = ''; }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && texto[i + 1] === '\n') i++;
      linha.push(campo); campo = '';
      if (linha.some((c) => c.trim() !== '')) linhas.push(linha);
      linha = [];
      if (linhas.length > MAX_LINHAS + 1) break;
    } else campo += ch;
  }
  linha.push(campo);
  if (linha.some((c) => c.trim() !== '')) linhas.push(linha);
  return linhas;
}

// Coluna do contrato → sinônimos de cabeçalho (comparados sem acento/caixa)
const SINONIMOS = {
  id: ['id'],
  empresa: ['empresa', 'nome', 'razao social', 'razão social', 'nome fantasia', 'fantasia', 'company', 'nome da empresa'],
  telefone: ['telefone', 'fone', 'celular', 'whatsapp', 'whats', 'tel', 'contato telefone', 'phone'],
  email: ['email', 'e-mail', 'e mail', 'correio'],
  site: ['site', 'website', 'url', 'pagina', 'página'],
  instagram: ['instagram', 'insta', '@'],
  cnpj: ['cnpj', 'cpf/cnpj', 'documento'],
  endereco: ['endereco', 'endereço', 'logradouro', 'rua'],
  cidade: ['cidade', 'municipio', 'município', 'city'],
  uf: ['uf', 'estado', 'state'],
  setor: ['setor', 'segmento', 'ramo', 'atividade', 'categoria'],
  observacoes: ['observacoes', 'observações', 'obs', 'notas'],
};

function chave(s) {
  return taxonomia.semAcento(s).replace(/[_\-.]+/g, ' ').replace(/\s+/g, ' ').trim();
}

/** @returns {Record<string, number>} campo → índice da coluna */
function sugerirMapeamento(cabecalhos) {
  const mapa = {};
  const usados = new Set();
  const cab = cabecalhos.map(chave);
  for (const [campo, sins] of Object.entries(SINONIMOS)) {
    const alvos = sins.map(chave);
    const idx = cab.findIndex((c, i) => !usados.has(i) && alvos.includes(c));
    if (idx !== -1) { mapa[campo] = idx; usados.add(idx); }
  }
  // segunda passada: contém (ex.: "Telefone comercial")
  for (const [campo, sins] of Object.entries(SINONIMOS)) {
    if (campo in mapa || campo === 'id') continue;
    const alvos = sins.map(chave).filter((a) => a.length > 2);
    const idx = cab.findIndex((c, i) => !usados.has(i) && alvos.some((a) => c.includes(a)));
    if (idx !== -1) { mapa[campo] = idx; usados.add(idx); }
  }
  return mapa;
}

/**
 * Lê o arquivo e devolve a prévia (não grava nada).
 * @param {string} base64
 * @param {{ delimitador?: string }} [opts]
 */
function ler(base64, opts = {}) {
  const buffer = Buffer.from(String(base64 || ''), 'base64');
  if (!buffer.length) throw new Error('Arquivo vazio.');
  if (buffer.length > taxonomia.LIMITES.csvMaxBytes) throw new Error('Arquivo maior que 4 MB. Divida em partes.');
  if (buffer[0] === 0x50 && buffer[1] === 0x4b) throw new Error('Isto parece um arquivo Excel (.xlsx). Abra no Excel e use "Salvar como → CSV UTF-8".');
  const { texto, codificacao, avisos } = decodificar(buffer);
  const delimitador = [';', ',', '\t'].includes(opts.delimitador) ? opts.delimitador : detectarDelimitador(texto);
  const linhas = parse(texto, delimitador);
  if (linhas.length < 2) throw new Error('O arquivo precisa de uma linha de cabeçalho e ao menos uma linha de dados.');
  const cabecalhos = linhas[0].map((c) => c.trim());
  const dados = linhas.slice(1);
  if (dados.length > MAX_LINHAS) avisos.push(`Só as primeiras ${MAX_LINHAS} linhas serão importadas.`);
  const hash = crypto.createHash('sha1').update(buffer).digest('hex').slice(0, 10);
  return {
    hash, codificacao, delimitador, cabecalhos,
    totalLinhas: Math.min(dados.length, MAX_LINHAS),
    amostra: dados.slice(0, 5),
    mapeamentoSugerido: sugerirMapeamento(cabecalhos),
    linhas: dados.slice(0, MAX_LINHAS),
    avisos,
  };
}

/** Linha do CSV → RegistroIntermediario (+ id/observações para os modos atualizar/mesclar). */
function paraRegistro(linha, mapa, hash, numeroLinha) {
  const v = (campo) => (mapa[campo] === undefined || mapa[campo] === null ? null : String(linha[mapa[campo]] ?? '').trim() || null);
  const empresa = v('empresa');
  if (!empresa) return null;
  const payload = {};
  linha.forEach((valor, i) => { payload[`col_${i}`] = valor; });
  return {
    registro: registro({
      provider: 'csv',
      external_id: `csv:${hash}:${numeroLinha}`,
      payload,
      empresa,
      telefone: v('telefone'),
      email: v('email'),
      site: v('site'),
      instagram: v('instagram'),
      cnpj: v('cnpj'),
      endereco: v('endereco'),
      cidade: v('cidade'),
      uf: v('uf'),
      lat: null,
      lon: null,
      categoria_origem: null,
      setor_sugerido: v('setor'),
    }),
    leadId: v('id'),
    observacoes: v('observacoes'),
  };
}

module.exports = { id: 'csv', requer: [], suportaTipo: ['importacao'], ler, parse, detectarDelimitador, decodificar, sugerirMapeamento, paraRegistro, SINONIMOS };
