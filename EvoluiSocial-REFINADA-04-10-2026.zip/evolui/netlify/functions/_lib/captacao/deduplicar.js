/**
 * Lead Capture Engine — DEDUPLICAÇÃO.
 *
 * 1. Dentro do próprio job (mesma empresa vinda do Geoapify E do OSM, ou
 *    linha repetida na planilha): os registros são FUNDIDOS num só (campos
 *    vazios completados), a origem extra fica em payload.outras_fontes.
 * 2. Contra o CRM (inclui leads ARQUIVADOS): RPC prospeccao_dedup_candidatos
 *    (migration 009), na ordem CNPJ > external_id > domínio(+nome) > telefone
 *    > Instagram > e-mail > nome+cidade > nome+endereço.
 *    - duplicado (automático): CNPJ, mesma origem, domínio + nome compatível (confiança ≥ 95)
 *    - possivel_duplicado (revisão humana): o resto
 * 3. Opt-out: e-mail, telefone normalizado ou origem bloqueados → bloqueado_optout.
 */
const { similaridade, distanciaMetros, telefone: normTel } = require('./normalizar');

const AUTOMATICOS = new Set(['cnpj', 'external_id', 'dominio_nome']);
const CAMPOS_FUNDIR = ['telefone', 'telefone_norm', 'email', 'site', 'dominio', 'instagram', 'instagram_handle', 'cnpj', 'endereco', 'cidade', 'cidade_norm', 'uf', 'lat', 'lon', 'setor', 'subsetor', 'categoria_origem'];

function mesmaEmpresa(a, b) {
  if (a.external_id && a.external_id === b.external_id) return true;
  if (a.cnpj && a.cnpj === b.cnpj) return true;
  if (a.dominio && a.dominio === b.dominio && similaridade(a.empresa_norm, b.empresa_norm) >= 0.5) return true;
  if (a.telefone_norm && a.telefone_norm === b.telefone_norm && similaridade(a.empresa_norm, b.empresa_norm) >= 0.5) return true;
  if (a.empresa_norm && a.empresa_norm === b.empresa_norm && (a.cidade_norm || '') === (b.cidade_norm || '')) return true;
  const d = distanciaMetros(a.lat, a.lon, b.lat, b.lon);
  if (d !== null && d < 80 && similaridade(a.empresa_norm, b.empresa_norm) >= 0.6) return true;
  return false;
}

/**
 * @param {object[]} linhas já normalizadas
 * @returns {{ linhas: object[], fundidos: number }}
 */
function dedupNoJob(linhas) {
  const saida = [];
  let fundidos = 0;
  for (const l of linhas) {
    const igual = saida.find((s) => mesmaEmpresa(s, l));
    if (!igual) { saida.push(l); continue; }
    fundidos += 1;
    for (const c of CAMPOS_FUNDIR) if ((igual[c] === null || igual[c] === undefined) && l[c] !== null && l[c] !== undefined) igual[c] = l[c];
    igual.payload = igual.payload || {};
    igual.payload.outras_fontes = [...(igual.payload.outras_fontes || []), { provider: l.provider, external_id: l.external_id }];
    igual.avisos = [...new Set([...(igual.avisos || []), ...(l.avisos || [])])];
  }
  return { linhas: saida, fundidos };
}

/**
 * @param {object[]} linhas
 * @param {(lote: object[]) => Promise<object[]>} buscarCandidatos chama a RPC
 */
async function classificarContraCrm(linhas, buscarCandidatos, tamanhoLote = 200) {
  for (let i = 0; i < linhas.length; i += tamanhoLote) {
    const lote = linhas.slice(i, i + tamanhoLote);
    const entrada = lote.map((l, j) => ({
      idx: i + j, cnpj: l.cnpj, external_id: l.external_id, dominio: l.dominio, empresa_norm: l.empresa_norm,
      telefone_norm: l.telefone_norm, instagram_handle: l.instagram_handle, email: l.email, cidade_norm: l.cidade_norm, endereco: l.endereco,
    }));
    const achados = await buscarCandidatos(entrada);
    for (const m of achados || []) {
      const l = linhas[m.idx];
      if (!l || l.status === 'bloqueado_optout') continue;
      l.match_lead_id = m.lead_id;
      l.match_tipo = m.match_tipo;
      l.match_confianca = m.confianca;
      l.match_empresa = m.empresa;
      l.status = AUTOMATICOS.has(m.match_tipo) ? 'duplicado' : 'possivel_duplicado';
    }
  }
  return linhas;
}

/** @param {{ emails: Set<string>, telefones: Set<string>, origemIds: Set<string> }} bloqueios telefones JÁ normalizados */
function aplicarOptout(linhas, bloqueios) {
  let n = 0;
  for (const l of linhas) {
    if ((l.email && bloqueios.emails.has(l.email.toLowerCase()))
      || (l.telefone_norm && bloqueios.telefones.has(l.telefone_norm))
      || (l.external_id && bloqueios.origemIds.has(l.external_id))) {
      l.status = 'bloqueado_optout';
      n += 1;
    }
  }
  return n;
}

/** Converte a lista crua de opt-outs (email/telefone/origem_id) em Sets normalizados. */
function montarBloqueios(rows) {
  return {
    emails: new Set(rows.map((r) => String(r.email || '').trim().toLowerCase()).filter(Boolean)),
    telefones: new Set(rows.map((r) => r.telefone_norm || normTel(r.telefone)).filter(Boolean)),
    origemIds: new Set(rows.map((r) => r.origem_id).filter(Boolean)),
  };
}

module.exports = {
  CAMPOS_FUNDIR, dedupNoJob, classificarContraCrm, aplicarOptout, montarBloqueios, mesmaEmpresa, AUTOMATICOS };
