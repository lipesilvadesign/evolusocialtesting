/**
 * Implementações reais das dependências do pipeline (rede + banco).
 * `credencial` é o JWT do usuário (RLS vale) OU, só na rotina agendada, a
 * service role key — motivo: não há usuário logado num cron; mesmo assim a
 * rotina só escreve na CAPTURA (nunca no CRM) e só lê do CRM as chaves de
 * deduplicação via RPC.
 */
const { rest, rpc } = require('../supabaseRest');
const osm = require('../integrations/openStreetMap');
const geoapify = require('./providers/geoapify');
const overpass = require('./providers/overpass');
const enriquecer = require('./enriquecer');
const { montarBloqueios } = require('./deduplicar');
const { env } = require('../config/env');
const cache = require('./cache');
const cnpjProvider = require('./providers/cnpj');
const flags = require('./flags');
const saude = require('./saude');

function criarDeps(credencial) {
  const apiKey = env.geoapify.apiKey();
  return {
    async atualizarJob(id, campos) {
      await rest(credencial, `admin_prospeccao_buscas?id=eq.${encodeURIComponent(id)}`, {
        method: 'PATCH', body: { ...campos, updated_at: new Date().toISOString() }, prefer: 'return=minimal',
      });
    },
    async lerStatusJob(id) {
      const { data } = await rest(credencial, `admin_prospeccao_buscas?id=eq.${encodeURIComponent(id)}&select=status`);
      return data && data[0] ? data[0].status : null;
    },
    geocodificar: (cidade) => osm.geocodeCidade(cidade),
    coletar: {
      geoapify: (params) => geoapify.coletar(params, { apiKey }),
      overpass: (params, opcoes = {}) => overpass.coletar(params, { prazoMs: opcoes.prazoMs, ordenar: opcoes.ordenar, registrar: opcoes.registrar }),
    },
    /** Saúde por host (migration 013). Falha de leitura = sem histórico (ordem padrão). */
    async carregarSaude() {
      const { data } = await rest(credencial, 'admin_prospeccao_provider_saude?select=host,provider,tentativas,sucessos,latencia_media_ms,cooldown_ate', { timeoutMs: 3000 });
      return data || [];
    },
    registrarSaude(host, provider, status, ms) {
      return rpc(credencial, 'prospeccao_registrar_saude', { p_host: host, p_provider: provider, p_status: status, p_ms: Math.round(ms) || 0 }, { timeoutMs: 4000 });
    },
    async atualizarCaptura(jobId, provider, externalId, campos) {
      // só registro ainda NÃO decidido (a RLS também barra aprovado)
      await rest(credencial, `admin_prospeccao_captura?job_id=eq.${encodeURIComponent(jobId)}&provider=eq.${encodeURIComponent(provider)}&external_id=eq.${encodeURIComponent(externalId)}&status=in.(pendente,possivel_duplicado,duplicado,bloqueado_optout)&lead_id=is.null`, {
        method: 'PATCH', body: { ...campos, updated_at: new Date().toISOString() }, prefer: 'return=minimal',
      });
    },
    ordenarHosts: saude.ordenar,
    /** Cache (migration 011). Devolve null se não houver, estiver expirado ou a leitura falhar. */
    async lerCache(chaveCache) {
      const { data } = await rest(credencial, `admin_prospeccao_cache_provider?chave=eq.${encodeURIComponent(chaveCache)}&expira_em=gt.${encodeURIComponent(new Date().toISOString())}&select=registros,qtd,criado_em`, { timeoutMs: 4000 });
      return data && data[0] ? data[0] : null;
    },
    async gravarCache(chaveCache, provider, parametros, registros, horas = cache.TTL_HORAS) {
      if (!horas) return;
      await rest(credencial, 'admin_prospeccao_cache_provider?on_conflict=chave', {
        method: 'POST', prefer: 'resolution=merge-duplicates,return=minimal', timeoutMs: 6000,
        body: { chave: chaveCache, provider, parametros, registros, qtd: registros.length, criado_em: new Date().toISOString(), expira_em: cache.expiraEm(horas) },
      });
    },
    async listarPendentesEnriquecimento(jobId, limite = 50) {
      const { data } = await rest(credencial, `admin_prospeccao_captura?job_id=eq.${encodeURIComponent(jobId)}&enriquecimento_status=eq.pendente&select=id,site,email,telefone,instagram,cnpj&order=created_at.asc&limit=${Number(limite) || 50}`);
      return data || [];
    },
    async gravarEnriquecimento(capturaId, dados) {
      return rpc(credencial, 'prospeccao_gravar_enriquecimento', { p_captura: capturaId, p_dados: dados });
    },
    consultarCnpj: (doc) => cnpjProvider.consultar(doc),
    async carregarBloqueios() {
      const { data } = await rest(credencial, 'admin_prospeccao_optouts?select=email,telefone,telefone_norm,origem_id');
      return montarBloqueios(data || []);
    },
    async buscarCandidatos(lote) {
      return (await rpc(credencial, 'prospeccao_dedup_candidatos', { p_registros: lote })) || [];
    },
    verificarSite: (site) => enriquecer.verificarSite(site),
    async gravarCaptura(lote) {
      // ignore-duplicates = ON CONFLICT DO NOTHING no índice (job_id, provider, external_id):
      // reprocessar o mesmo job não duplica nem sobrescreve decisões já tomadas.
      await rest(credencial, 'admin_prospeccao_captura?on_conflict=job_id,provider,external_id', {
        method: 'POST', body: lote, prefer: 'resolution=ignore-duplicates,return=minimal',
      });
    },
    aguardar: (ms) => new Promise((r) => setTimeout(r, ms)),
    temGeoapify: Boolean(apiKey),
    consultaCnpj: flags.ligada('ENABLE_CNPJ_LOOKUP'),
  };
}

module.exports = { criarDeps };
