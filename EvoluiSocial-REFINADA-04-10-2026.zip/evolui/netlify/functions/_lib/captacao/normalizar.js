/**
 * Lead Capture Engine — NORMALIZAÇÃO.
 *
 * Módulo puro (sem rede, sem banco): mesma entrada → mesma saída. Usado
 * pelo pipeline de captação, pela criação manual de lead, pela importação
 * CSV e pela conversão de formulários. As regras de telefone, domínio,
 * Instagram, cidade e nome têm uma versão SQL equivalente em
 * migrations/003_normalizacao.sql (preenche as colunas *_norm por trigger);
 * tests/captacaoNormalizar.test.js garante que as duas concordam nos casos
 * principais (roda contra o Postgres local quando disponível).
 *
 * Regra geral: nunca inventar. Entrada inválida vira null + aviso, nunca
 * um valor "corrigido" por suposição.
 */

const { classificarSetor, CIDADES_REGIAO, DDD_PADRAO, semAcento } = require('./taxonomia');

function limpar(v) {
  if (v === undefined || v === null) return '';
  return String(v).replace(/\s+/g, ' ').trim();
}

function soDigitos(v) {
  return String(v || '').replace(/\D/g, '');
}

/** DDD da cidade (quando conhecida na região) — base para telefone de 8/9 dígitos. */
function dddDaCidade(cidade) {
  const alvo = semAcento(cidade).split(/[,/-]/)[0].trim();
  const achada = CIDADES_REGIAO.find((c) => semAcento(c.cidade) === alvo);
  return achada ? achada.ddd : null;
}

/**
 * Telefone brasileiro → E.164 sem "+": 55 + DDD + número.
 * (87) 99999-9999 → 5587999999999 · 3862-0000 (DDD padrão 87) → 558738620000
 * @param {string} v
 * @param {string} [dddPadrao] usado só para número sem DDD (8 ou 9 dígitos)
 * @returns {string|null}
 */
function telefone(v, dddPadrao = DDD_PADRAO) {
  let d = soDigitos(v);
  if (!d) return null;
  d = d.replace(/^0+/, ''); // 0xx87..., 087...
  // Prefixo de operadora (0 + 2 dígitos + DDD + número): 21 87 99999 9999 → 13 dígitos sem 55.
  if ((d.length === 12 || d.length === 13) && !d.startsWith('55')) d = d.slice(2);
  if (d.length === 8 || d.length === 9) {
    if (!dddPadrao) return null;
    d = `${dddPadrao}${d}`;
  }
  if (d.length === 10 || d.length === 11) d = `55${d}`;
  if (!(d.length === 12 || d.length === 13) || !d.startsWith('55')) return null;
  const ddd = Number(d.slice(2, 4));
  if (ddd < 11 || ddd > 99) return null;
  const numero = d.slice(4);
  if (numero.length === 9 && numero[0] !== '9') return null; // celular com 9 dígitos sempre começa com 9
  if (/^0+$/.test(numero)) return null; // 0000-0000
  return d;
}

const INSTAGRAM_RESERVADOS = new Set(['p', 'reel', 'reels', 'explore', 'stories', 'accounts', 'direct', 'tv', 'about', 'legal', 'share']);

/**
 * https://instagram.com/empresa/ · @empresa · instagram.com/empresa?igsh=x → "empresa"
 * @returns {string|null}
 */
function instagram(v) {
  let s = limpar(v).toLowerCase();
  if (!s) return null;
  s = s.replace(/^https?:\/\//, '').replace(/^(www\.|m\.)/, '');
  if (s.startsWith('instagram.com/') || s.startsWith('instagr.am/')) s = s.split('/')[1] || '';
  else if (s.includes('/')) return null; // outra URL qualquer — não é um perfil
  s = s.replace(/^@/, '').split(/[?#]/)[0].replace(/\/+$/, '');
  if (!/^[a-z0-9._]{1,30}$/.test(s) || INSTAGRAM_RESERVADOS.has(s) || /^\.+$/.test(s)) return null;
  return s;
}

/** Domínios que não identificam uma empresa (rede social, encurtador, e-mail gratuito, construtor de site). */
const DOMINIOS_GENERICOS = new Set([
  'instagram.com', 'facebook.com', 'fb.com', 'wa.me', 'whatsapp.com', 'api.whatsapp.com', 'linktr.ee', 'linktree.com',
  'google.com', 'sites.google.com', 'g.page', 'goo.gl', 'maps.google.com', 'business.site', 'gmail.com', 'hotmail.com',
  'outlook.com', 'yahoo.com', 'yahoo.com.br', 'bol.com.br', 'uol.com.br', 'terra.com.br', 'icloud.com', 'live.com',
  'wixsite.com', 'wix.com', 'blogspot.com', 'wordpress.com', 'youtube.com', 'tiktok.com', 'twitter.com', 'x.com',
  'linkedin.com', 'bit.ly', 'ifood.com.br', 'beacons.ai', 'bio.link', 'taplink.cc', 'carrd.co', 'negocio.site',
]);

/**
 * https://www.empresa.com.br/pagina → empresa.com.br
 * Domínio genérico (instagram.com, gmail.com, x.wixsite.com...) → null.
 * @returns {string|null}
 */
function dominio(v) {
  let s = limpar(v).toLowerCase();
  if (!s) return null;
  if (s.includes('@') && !s.includes('/')) s = s.split('@').pop(); // aceita e-mail: pega o domínio
  s = s.replace(/^[a-z]+:\/\//, '').split(/[/?#]/)[0].split(':')[0].replace(/^www\d?\./, '').replace(/\.$/, '');
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(s)) return null;
  if (DOMINIOS_GENERICOS.has(s)) return null;
  const partes = s.split('.');
  for (let i = 1; i < partes.length - 1; i++) {
    if (DOMINIOS_GENERICOS.has(partes.slice(i).join('.'))) return null; // loja.wixsite.com, x.blogspot.com
  }
  return s;
}

/** Site como URL utilizável (https:// por padrão). Não verifica se existe. */
function site(v) {
  const s = limpar(v);
  if (!s) return null;
  const comProtocolo = /^https?:\/\//i.test(s) ? s : `https://${s}`;
  try {
    const u = new URL(comProtocolo);
    if (!u.hostname.includes('.')) return null;
    return u.toString().replace(/\/$/, '');
  } catch {
    return null;
  }
}

/**
 * CNPJ: remove máscara e VALIDA os dois dígitos verificadores.
 * "14 dígitos" sozinho não é válido.
 * @returns {string|null} 14 dígitos ou null
 */
function cnpj(v) {
  const d = soDigitos(v);
  if (d.length !== 14 || /^(\d)\1{13}$/.test(d)) return null;
  const calc = (base) => {
    const pesos = base.length === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    const soma = base.split('').reduce((acc, n, i) => acc + Number(n) * pesos[i], 0);
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  };
  const d1 = calc(d.slice(0, 12));
  const d2 = calc(d.slice(0, 12) + d1);
  return d.endsWith(`${d1}${d2}`) ? d : null;
}

/** E-mail em minúsculas, validação estrutural simples. */
function email(v) {
  const s = limpar(v).toLowerCase();
  if (!s) return null;
  return /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/.test(s) ? s : null;
}

const UFS = new Set(['AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO']);
const PARTICULAS = new Set(['da', 'de', 'do', 'das', 'dos', 'e']);

function tituloCidade(s) {
  return s
    .toLowerCase()
    .split(' ')
    .map((p, i) => (i > 0 && PARTICULAS.has(p) ? p : p.charAt(0).toUpperCase() + p.slice(1)))
    .join(' ');
}

/**
 * PETROLINA · petrolina · "Petrolina - PE" · "Petrolina/PE" · "Petrolina, PE" →
 * { cidade: 'Petrolina', uf: 'PE', cidadeNorm: 'petrolina' }
 * @param {string} v
 * @param {string} [ufInformada]
 */
function cidade(v, ufInformada) {
  let s = limpar(v);
  let uf = limpar(ufInformada).toUpperCase() || null;
  if (!s) return { cidade: null, uf: uf && UFS.has(uf) ? uf : null, cidadeNorm: null };
  const m = s.match(/^(.*?)[\s]*[,/\-–]\s*([A-Za-z]{2})$/);
  if (m && UFS.has(m[2].toUpperCase())) {
    s = m[1].trim();
    uf = uf || m[2].toUpperCase();
  }
  if (!uf) {
    const conhecida = CIDADES_REGIAO.find((c) => semAcento(c.cidade) === semAcento(s));
    if (conhecida) uf = conhecida.uf;
  }
  const exibicao = tituloCidade(s);
  return { cidade: exibicao, uf: uf && UFS.has(uf) ? uf : null, cidadeNorm: semAcento(exibicao) };
}

const SUFIXOS_SOCIETARIOS = /(\s*[-–,.]?\s*\b(ltda|me|epp|eireli|mei|s\/?a|s\.a|sa|cia|limitada)\.?)+\s*$/i;

/**
 * Nome da empresa.
 * - exibicao: o nome como veio, só sem espaços duplicados (não mexe na marca).
 * - norm: minúsculas, sem acento, sem sufixo societário (Ltda, ME, EIRELI, S/A)
 *   e sem pontuação — base da comparação por similaridade.
 */
function empresa(v) {
  const exibicao = limpar(v).replace(/^[\s\-–,.;:]+|[\s\-–,;:]+$/g, '');
  if (!exibicao) return { exibicao: null, norm: null };
  let norm = semAcento(exibicao).replace(SUFIXOS_SOCIETARIOS, '');
  norm = norm.replace(/[^a-z0-9]+/g, ' ').trim();
  return { exibicao, norm: norm || semAcento(exibicao) };
}

/** Setor livre → taxonomia controlada ({ setor, subsetor }). */
function setor(v) {
  return classificarSetor(v);
}

// --------------------------------------------------------------------------
// Similaridade de nomes — mesma ideia do pg_trgm (trigramas com borda),
// para o pipeline comparar sem ir ao banco e para os testes.
// --------------------------------------------------------------------------
function trigramas(s) {
  const out = new Set();
  const palavras = semAcento(s).replace(/[^a-z0-9]+/g, ' ').trim().split(' ').filter(Boolean);
  for (const p of palavras) {
    const w = `  ${p} `;
    for (let i = 0; i < w.length - 2; i++) out.add(w.slice(i, i + 3));
  }
  return out;
}

/** 0..1 — interseção / união de trigramas (equivalente ao similarity() do pg_trgm). */
function similaridade(a, b) {
  const ta = trigramas(a);
  const tb = trigramas(b);
  if (!ta.size || !tb.size) return 0;
  let inter = 0;
  for (const t of ta) if (tb.has(t)) inter += 1;
  return inter / (ta.size + tb.size - inter);
}

/** Distância em metros entre dois pontos (haversine). */
function distanciaMetros(lat1, lon1, lat2, lon2) {
  if ([lat1, lon1, lat2, lon2].some((x) => x === null || x === undefined || Number.isNaN(Number(x)))) return null;
  const R = 6371000;
  const rad = (g) => (Number(g) * Math.PI) / 180;
  const dLat = rad(lat2 - lat1);
  const dLon = rad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/**
 * Normaliza um RegistroIntermediario (ver tipos.js) inteiro. Devolve os
 * campos prontos para a tabela admin_prospeccao_captura + avisos.
 */
function registro(r) {
  const avisos = [];
  const emp = empresa(r.empresa);
  const cid = cidade(r.cidade, r.uf);
  const ddd = dddDaCidade(cid.cidade || '') || DDD_PADRAO;

  const tel = telefone(r.telefone, ddd);
  if (limpar(r.telefone) && !tel) avisos.push('Telefone em formato não reconhecido');
  const mail = email(r.email);
  if (limpar(r.email) && !mail) avisos.push('E-mail inválido');
  const siteUrl = site(r.site);
  const dom = dominio(siteUrl) || (mail ? dominio(mail) : null);
  const ig = instagram(r.instagram);
  if (limpar(r.instagram) && !ig) avisos.push('Instagram em formato não reconhecido');
  const doc = cnpj(r.cnpj);
  if (limpar(r.cnpj) && !doc) avisos.push('CNPJ inválido (dígitos verificadores não conferem)');
  const set = r.setor_sugerido ? setor(r.setor_sugerido) : { setor: null, subsetor: null };
  if (!emp.exibicao) avisos.push('Sem nome de empresa');
  if (!tel && !mail && !siteUrl && !ig) avisos.push('Sem nenhum canal de contato');

  const lat = r.lat === undefined || r.lat === null || r.lat === '' ? null : Number(r.lat);
  const lon = r.lon === undefined || r.lon === null || r.lon === '' ? null : Number(r.lon);

  return {
    empresa: emp.exibicao,
    empresa_norm: emp.norm,
    telefone: limpar(r.telefone) || null,
    telefone_norm: tel,
    email: mail,
    site: siteUrl,
    dominio: dom,
    instagram: ig ? `@${ig}` : null,
    instagram_handle: ig,
    cnpj: doc,
    endereco: limpar(r.endereco) || null,
    cidade: cid.cidade,
    cidade_norm: cid.cidadeNorm,
    uf: cid.uf,
    lat: Number.isFinite(lat) ? lat : null,
    lon: Number.isFinite(lon) ? lon : null,
    setor: set.setor,
    subsetor: set.subsetor,
    categoria_origem: limpar(r.categoria_origem) || null,
    avisos,
  };
}

module.exports = {
  telefone, instagram, dominio, site, cnpj, email, cidade, empresa, setor,
  similaridade, distanciaMetros, registro, soDigitos, dddDaCidade, DOMINIOS_GENERICOS,
};
