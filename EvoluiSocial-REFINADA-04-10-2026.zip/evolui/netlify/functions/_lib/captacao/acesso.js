/**
 * Autenticação + autorização das Functions de prospecção / captação.
 *
 * 1. requireUser: token de sessão válido no Supabase Auth (senão 401).
 * 2. Papel ativo em admin_funcionarios lido com o PRÓPRIO token (RLS):
 *    só 'admin' e 'prospeccao' operam prospecção (senão 403).
 * 3. Rate limit por usuário (memória da instância — reduz abuso/cliques
 *    repetidos; os limites que importam de verdade, como 1 job ativo e 10
 *    jobs/dia, são contados NO BANCO em captacao.js).
 * A autorização final de cada linha continua no banco (RLS + RPCs).
 */
const { requireUser } = require('../config/authGuard');
const { rest } = require('../supabaseRest');
const { checkRateLimit } = require('../rateLimiter');

function json(statusCode, body, extraHeaders = {}) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...extraHeaders },
    body: JSON.stringify(body),
  };
}

async function papelDoUsuario(token, userId) {
  try {
    const { data } = await rest(token, `admin_funcionarios?select=role&id=eq.${encodeURIComponent(userId)}&ativo=eq.true`);
    return (data && data[0] && data[0].role) || null;
  } catch {
    return null;
  }
}

/**
 * @param {object} event
 * @param {{ limite?: { max: number, windowMs: number }, chave?: string, papeis?: string[] }} [opts]
 * @returns {Promise<{ user?: object, token?: string, papel?: string, ehAdmin?: boolean, resposta?: object }>}
 */
async function exigirOperador(event, opts = {}) {
  const { user, token, error } = await requireUser(event);
  if (error) return { resposta: json(error.statusCode, { error: error.message }) };
  const papel = await papelDoUsuario(token, user.id);
  const papeis = opts.papeis || ['admin', 'prospeccao'];
  if (!papeis.includes(papel)) return { resposta: json(403, { error: 'Seu perfil não tem acesso a esta área.' }) };
  const limite = opts.limite || { max: 120, windowMs: 60 * 1000 };
  const rl = checkRateLimit(`${opts.chave || 'prospeccao'}:${user.id}`, limite);
  if (!rl.allowed) {
    return { resposta: json(429, { error: 'Muitas requisições seguidas. Aguarde alguns segundos.' }, { 'Retry-After': String(Math.ceil(rl.retryAfterMs / 1000)) }) };
  }
  return { user, token, papel, ehAdmin: papel === 'admin' };
}

function lerCorpo(event) {
  if (!event.body) return {};
  try {
    const b = JSON.parse(event.body);
    return b && typeof b === 'object' ? b : null;
  } catch {
    return null;
  }
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ehUuid = (v) => typeof v === 'string' && UUID.test(v);

/** Erro → resposta HTTP sem vazar detalhes internos (tokens nunca entram na mensagem). */
function respostaErro(err) {
  const status = err.statusCode || (err.status === 401 || err.status === 403 ? 403 : err.status === 400 || err.status === 409 ? err.status : 500);
  let msg = err.message || 'Erro inesperado.';
  if (/42501|permission denied|row-level security/i.test(msg)) msg = 'Sem permissão para esta ação.';
  return json(status, { error: msg });
}

module.exports = { exigirOperador, papelDoUsuario, json, lerCorpo, ehUuid, respostaErro };
