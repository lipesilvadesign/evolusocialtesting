/**
 * Lead Capture Engine — ENRIQUECIMENTO automático (só o que pode ser
 * MEDIDO; julgamento visual nunca vira fato automático).
 *
 * Checagem de site:
 *   - timeout 5 s por requisição, no máximo 1 nova tentativa, até 3 redirects;
 *   - HTTPS detectado (https responde? redireciona para http?);
 *   - código HTTP final;
 *   - baixa no máximo 200 KB da página inicial e procura link de Instagram;
 *   - bloqueio de robô (401/403/429/999) = "não verificado", NUNCA "fora do ar".
 * Oportunidades geradas (sempre com evidência medida):
 *   SITE_FORA_DO_AR (alta) · SITE_SEM_HTTPS (alta) · SEM_SITE (média: pode
 *   existir e não estar nas fontes consultadas).
 * 30/09 (refinamento) — da MESMA página já baixada (nenhuma requisição extra):
 *   título, meta description, <form>, link de WhatsApp (wa.me / api.whatsapp),
 *   e-mail (mailto: e texto), telefone (tel:), Instagram.
 *   SITE_SEM_FORMULARIO (média) · SITE_SEM_CONTATO (média) — só quando a página
 *   inicial respondeu 2xx E tem conteúdo suficiente (site montado só por
 *   JavaScript devolve HTML quase vazio → "não conclusivo", nenhum sinal).
 *   A evidência diz sempre "na página inicial": contato em outra página é possível.
 * SITE_DESATUALIZADO NÃO é gerado automaticamente: não existe critério medível
 * confiável (ano no rodapé não prova nada). Continua sinal manual.
 * EMPRESA_NOVA: só com a consulta de CNPJ ligada (ENABLE_CNPJ_LOOKUP) — ver providers/cnpj.js.
 */
const TIMEOUT_MS = 5000;
const MAX_REDIRECTS = 3;
const MAX_BYTES = 200 * 1024;
const BLOQUEIO = new Set([401, 403, 406, 429, 999]);
const UA = 'Mozilla/5.0 (compatible; FelipeBrandingBot/1.0; +https://felipebranding.com.br)';

function hostDe(url) {
  try { return new URL(url).hostname; } catch { return null; }
}

async function lerCorpoLimitado(res, maxBytes = MAX_BYTES) {
  if (!res.body || !res.body.getReader) return (await res.text().catch(() => '')).slice(0, maxBytes);
  const reader = res.body.getReader();
  const partes = [];
  let total = 0;
  try {
    while (total < maxBytes) {
      const { done, value } = await reader.read();
      if (done) break;
      partes.push(Buffer.from(value));
      total += value.length;
    }
  } finally {
    reader.cancel().catch(() => {});
  }
  return Buffer.concat(partes).subarray(0, maxBytes).toString('utf8');
}

/** Uma tentativa seguindo até MAX_REDIRECTS manualmente. */
async function tentar(url, fetchImpl, timeoutMs) {
  let atual = url;
  let usouHttp = url.startsWith('http://');
  for (let i = 0; i <= MAX_REDIRECTS; i++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res;
    try {
      res = await fetchImpl(atual, { redirect: 'manual', signal: controller.signal, headers: { 'User-Agent': UA, Accept: 'text/html,*/*' } });
    } finally {
      clearTimeout(timer);
    }
    if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
      atual = new URL(res.headers.get('location'), atual).toString();
      if (atual.startsWith('http://')) usouHttp = true;
      continue;
    }
    const html = res.status < 400 ? await lerCorpoLimitado(res) : '';
    return { status: res.status, urlFinal: atual, https: atual.startsWith('https://') && !usouHttp, html };
  }
  return { status: 310, urlFinal: atual, https: atual.startsWith('https://'), html: '', redirecionamentos: true };
}

function motivoErro(err) {
  const code = (err && err.cause && err.cause.code) || (err && err.code) || '';
  if (err && err.name === 'AbortError') return 'timeout';
  if (/ENOTFOUND|EAI_AGAIN/.test(code)) return 'dns';
  if (/CERT|TLS|SSL|ALTNAME/i.test(code)) return 'tls';
  if (/ECONNREFUSED|ECONNRESET|UND_ERR/.test(code)) return 'conexao';
  return code || 'rede';
}

function decodificar(t) {
  return String(t || '')
    .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/\s+/g, ' ').trim();
}

const IMAGEM = /\.(png|jpe?g|gif|webp|svg|avif)$/i;

/**
 * Lê sinais objetivos da página inicial (HTML já baixado, ≤ 200 KB).
 * @param {string} html
 * @returns {{ titulo: string|null, descricao: string|null, formulario: boolean, whatsapp: string|null,
 *            emails: string[], telefones: string[], instagram: string|null, conteudoSuficiente: boolean }}
 */
function analisarPagina(html) {
  const h = String(html || '');
  const titulo = (h.match(/<title[^>]*>([\s\S]{1,300}?)<\/title>/i) || [])[1];
  const meta = h.match(/<meta[^>]+name=["']description["'][^>]*>/i) || h.match(/<meta[^>]+property=["']og:description["'][^>]*>/i);
  const descricao = meta ? (meta[0].match(/content=["']([^"']{1,500})["']/i) || [])[1] : null;
  const wa = h.match(/(?:wa\.me\/|api\.whatsapp\.com\/send\/?\?phone=|web\.whatsapp\.com\/send\?phone=)\+?(\d{10,13})/i);
  const emails = new Set();
  for (const m of h.matchAll(/mailto:([^"'?\s>]{3,120})/gi)) emails.add(decodificar(m[1]).toLowerCase());
  const texto = h.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ');
  for (const m of texto.matchAll(/\b[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{2,120}\.[A-Za-z]{2,10}\b/g)) {
    if (!IMAGEM.test(m[0])) emails.add(m[0].toLowerCase());
  }
  const telefones = new Set();
  for (const m of h.matchAll(/href=["']tel:([+\d\s().-]{8,24})["']/gi)) telefones.add(m[1].trim());
  const textoVisivel = decodificar(texto);
  return {
    titulo: titulo ? decodificar(titulo).slice(0, 200) || null : null,
    descricao: descricao ? decodificar(descricao).slice(0, 300) || null : null,
    formulario: /<form[\s>]/i.test(h),
    whatsapp: wa ? wa[1] : null,
    emails: [...emails].filter((e) => !IMAGEM.test(e)).slice(0, 5),
    telefones: [...telefones].slice(0, 5),
    instagram: extrairInstagram(h),
    favicon: /<link[^>]+rel=["'][^"']*(icon|apple-touch-icon)[^"']*["']/i.test(h) ? true : null,
    linksContato: linksRelacionados(h),
    conteudoSuficiente: h.length >= 1500 && textoVisivel.length >= 200,
  };
}

/** Links internos CLARAMENTE de contato/sobre (nada de varrer o site). */
function linksRelacionados(html) {
  const out = [];
  for (const m of String(html || '').matchAll(/<a[^>]+href=["']([^"'#]{1,200})["'][^>]*>([\s\S]{0,120}?)<\/a>/gi)) {
    const href = m[1].trim();
    const texto = m[2].replace(/<[^>]+>/g, ' ').toLowerCase();
    if (/^(mailto|tel|javascript|whatsapp):/i.test(href)) continue;
    if (/(contato|contact|fale-conosco|fale_conosco|atendimento|sobre|about|quem-somos|empresa)/i.test(href) || /(contato|fale conosco|sobre|quem somos)/i.test(texto)) out.push(href);
  }
  return [...new Set(out)].slice(0, 6);
}

// ------------------------------------------------------------------
// 01/10 (Fase 3) — CRAWL CONTROLADO: além da página inicial, no máximo
// 2 páginas claramente de contato/sobre do MESMO domínio, só se a inicial
// não mostrou contato; respeita robots.txt (User-agent: * / nosso UA).
// Limites: 3 páginas por domínio, 200 KB cada, 5 s cada.
// ------------------------------------------------------------------
const MAX_PAGINAS_EXTRAS = 2;

function regrasRobots(texto) {
  const regras = [];
  let aplica = false;
  for (const linha of String(texto || '').split(/\r?\n/)) {
    const l = linha.replace(/#.*/, '').trim();
    if (!l) continue;
    const [chave, ...resto] = l.split(':');
    const valor = resto.join(':').trim();
    if (/^user-agent$/i.test(chave)) aplica = valor === '*' || /felipebranding/i.test(valor);
    else if (aplica && /^disallow$/i.test(chave) && valor) regras.push(valor);
  }
  return regras;
}
const permitido = (caminho, regras) => !regras.some((r) => caminho.startsWith(r.replace(/\*.*$/, '')));

async function buscarTexto(url, fetchImpl, timeoutMs, maxBytes) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetchImpl(url, { redirect: 'follow', signal: controller.signal, headers: { 'User-Agent': UA, Accept: 'text/html,text/plain,*/*' } });
    if (!res || res.status >= 400) return { status: res ? res.status : 0, texto: '' };
    return { status: res.status, texto: await lerCorpoLimitado(res, maxBytes) };
  } finally {
    clearTimeout(timer);
  }
}

/** Visita páginas de contato/sobre e o favicon; devolve o que foi MEDIDO e quais URLs foram vistas. */
async function rastrearContato(urlBase, paginaInicial, { fetchImpl = fetch, timeoutMs = TIMEOUT_MS } = {}) {
  const base = new URL(urlBase);
  const vistas = [base.toString()];
  const agregada = { ...paginaInicial, emails: [...paginaInicial.emails], telefones: [...paginaInicial.telefones] };
  let regras = [];
  try { regras = regrasRobots((await buscarTexto(`${base.origin}/robots.txt`, fetchImpl, 3000, 20 * 1024)).texto); } catch { regras = []; }
  const temContato = (p) => p.formulario || p.whatsapp || p.emails.length || p.telefones.length;
  if (!temContato(paginaInicial)) {
    const candidatos = (paginaInicial.linksContato || []).map((h) => { try { return new URL(h, base); } catch { return null; } })
      .filter((u) => u && u.host === base.host && /^https?:$/.test(u.protocol));
    if (!candidatos.length) candidatos.push(new URL('/contato', base));
    let n = 0;
    for (const u of candidatos) {
      if (n >= MAX_PAGINAS_EXTRAS) break;
      if (!permitido(u.pathname, regras) || vistas.includes(u.toString())) continue;
      n += 1;
      try {
        const r = await buscarTexto(u.toString(), fetchImpl, timeoutMs, MAX_BYTES);
        if (r.status >= 200 && r.status < 300 && r.texto) {
          vistas.push(u.toString());
          const p = analisarPagina(r.texto);
          agregada.formulario = agregada.formulario || p.formulario;
          agregada.whatsapp = agregada.whatsapp || p.whatsapp;
          agregada.instagram = agregada.instagram || p.instagram;
          agregada.emails = [...new Set([...agregada.emails, ...p.emails])].slice(0, 5);
          agregada.telefones = [...new Set([...agregada.telefones, ...p.telefones])].slice(0, 5);
        }
      } catch { /* página extra é melhor-esforço */ }
    }
  }
  if (agregada.favicon !== true && permitido('/favicon.ico', regras)) {
    try {
      const r = await buscarTexto(`${base.origin}/favicon.ico`, fetchImpl, 3000, 1024);
      agregada.favicon = r.status >= 200 && r.status < 300 ? true : r.status === 404 ? false : null;
    } catch { agregada.favicon = null; }
  }
  agregada.paginasVistas = vistas;
  agregada.robotsBloqueios = regras.length;
  return agregada;
}

function extrairInstagram(html) {
  const m = String(html || '').match(/instagram\.com\/([A-Za-z0-9._]{1,30})(?:[/?"'#\s]|$)/i);
  if (!m) return null;
  const h = m[1].toLowerCase();
  return ['p', 'reel', 'reels', 'explore', 'stories', 'accounts', 'tv', 'sharer'].includes(h) ? null : h;
}

/**
 * @param {string} site URL (com ou sem protocolo)
 * @param {{ fetchImpl?: Function, timeoutMs?: number, agora?: Date }} [opts]
 * @returns {Promise<{ resultado: 'ok'|'fora_do_ar'|'sem_https'|'nao_verificado', httpStatus: number|null, https: boolean|null, instagram: string|null, evidencia: string, url: string }>}
 */
async function verificarSite(site, opts = {}) {
  const fetchImpl = opts.fetchImpl || fetch;
  const timeoutMs = opts.timeoutMs || TIMEOUT_MS;
  const quando = (opts.agora || new Date()).toISOString().slice(0, 16).replace('T', ' ');
  const host = hostDe(/^https?:\/\//i.test(site) ? site : `https://${site}`);
  if (!host) return { resultado: 'nao_verificado', httpStatus: null, https: null, instagram: null, evidencia: 'URL inválida', url: site };

  const erros = [];
  for (const url of [`https://${host}/`, `http://${host}/`]) {
    for (let tentativa = 0; tentativa < 2; tentativa++) {
      try {
        const r = await tentar(url, fetchImpl, timeoutMs);
        if (r.redirecionamentos) {
          return { resultado: 'nao_verificado', httpStatus: null, https: null, instagram: null, evidencia: `${url}: mais de ${MAX_REDIRECTS} redirecionamentos em ${quando} UTC`, url };
        }
        if (BLOQUEIO.has(r.status)) {
          return { resultado: 'nao_verificado', httpStatus: r.status, https: null, instagram: null, evidencia: `${url} respondeu ${r.status} (acesso de robô bloqueado) em ${quando} UTC`, url };
        }
        if (r.status >= 500 && tentativa === 0) { erros.push(`${url} → HTTP ${r.status}`); continue; }
        if (r.status >= 500) { erros.push(`${url} → HTTP ${r.status}`); break; }
        const https = url.startsWith('https://') && r.https;
        let pagina = r.status >= 200 && r.status < 300 && r.html ? analisarPagina(r.html) : null;
        if (pagina && opts.crawl !== false) {
          try { pagina = await rastrearContato(r.urlFinal || url, pagina, { fetchImpl, timeoutMs }); } catch { /* fica só a inicial */ }
        }
        return {
          pagina,
          resultado: https ? 'ok' : 'sem_https',
          httpStatus: r.status,
          https,
          instagram: extrairInstagram(r.html),
          evidencia: https
            ? `GET ${url} → HTTP ${r.status} em ${quando} UTC`
            : `HTTPS indisponível (${erros.slice(-1)[0] || 'redireciona para http'}); ${url} → HTTP ${r.status} em ${quando} UTC`,
          url: r.urlFinal,
        };
      } catch (err) {
        erros.push(`${url} → ${motivoErro(err)}`);
        if (tentativa === 0) continue;
      }
    }
  }
  const soBloqueioTls = erros.every((e) => /tls/.test(e));
  if (soBloqueioTls) return { resultado: 'nao_verificado', httpStatus: null, https: false, instagram: null, evidencia: `Falha de certificado: ${erros.join('; ')}`, url: site };
  return { resultado: 'fora_do_ar', httpStatus: null, https: null, instagram: null, evidencia: `2 tentativas por protocolo falharam em ${quando} UTC: ${erros.join('; ')}`, url: site };
}

/** Sinais (oportunidades) a partir do registro + resultado da checagem. Nunca sem evidência. */
function sinaisPara(linha, checagem, { agora = new Date(), fontesConsultadas = [] } = {}) {
  const sinais = [];
  const quando = agora.toISOString();
  if (!linha.site) {
    if (fontesConsultadas.length) {
      sinais.push({
        tipo: 'SEM_SITE', confianca: 'media', fonte: 'sistema', detectado_em: quando,
        evidencia: `Nenhuma das fontes consultadas (${fontesConsultadas.join(', ')}) informou site para esta empresa em ${quando.slice(0, 10)}.`,
      });
    }
    return sinais;
  }
  if (!checagem) return sinais;
  if (checagem.resultado === 'fora_do_ar') {
    sinais.push({ tipo: 'SITE_FORA_DO_AR', confianca: 'alta', fonte: 'sistema', detectado_em: quando, evidencia: checagem.evidencia, evidencia_url: linha.site });
  } else if (checagem.resultado === 'sem_https') {
    sinais.push({ tipo: 'SITE_SEM_HTTPS', confianca: 'alta', fonte: 'sistema', detectado_em: quando, evidencia: checagem.evidencia, evidencia_url: linha.site });
  }
  const pg = checagem.pagina;
  if ((checagem.resultado === 'ok' || checagem.resultado === 'sem_https') && pg && pg.conteudoSuficiente) {
    const base = `GET ${checagem.url || linha.site} → HTTP ${checagem.httpStatus} em ${quando.slice(0, 16).replace('T', ' ')} UTC`;
    const vistas = Array.isArray(pg.paginasVistas) && pg.paginasVistas.length > 1 ? pg.paginasVistas : null;
    const onde = vistas ? `nas ${vistas.length} páginas verificadas (${vistas.map((u) => u.replace(/^https?:\/\/[^/]+/, '') || '/').join(', ')})` : 'na página inicial';
    const ressalva = vistas ? 'Outras páginas do site não foram verificadas.' : 'Pode existir em outra página do site.';
    const sinal = (tipo, txt) => sinais.push({ tipo, confianca: 'media', fonte: 'sistema', detectado_em: quando, evidencia_url: linha.site, evidencia: `${base}: ${txt}` });
    if (!pg.formulario) sinal('SITE_SEM_FORMULARIO', `nenhum formulário (<form>) ${onde}. ${ressalva}`);
    if (!pg.formulario && !pg.whatsapp && !pg.emails.length && !pg.telefones.length) {
      sinal('SITE_SEM_CONTATO', `sem formulário, link de WhatsApp, e-mail ou telefone clicável ${onde}. ${ressalva}`);
    }
    if (!pg.whatsapp) sinal('SITE_SEM_WHATSAPP', `nenhum link de WhatsApp (wa.me / api.whatsapp.com) ${onde}. ${ressalva}`);
    if (!pg.instagram && !linha.instagram) sinal('SITE_SEM_INSTAGRAM', `nenhum link para o Instagram ${onde}, e as fontes não informaram perfil. Não significa que a empresa não tenha Instagram.`);
    if (pg.descricao === null || pg.descricao === undefined) sinal('SITE_SEM_META_DESCRIPTION', 'a página inicial não tem <meta name="description"> (texto usado pelo Google no resultado de busca).');
    if (pg.favicon === false) sinal('SITE_SEM_FAVICON', 'a página inicial não declara ícone (<link rel="icon">) e /favicon.ico respondeu 404.');
  }
  return sinais;
}

/**
 * Resultado da checagem → dados para a RPC prospeccao_gravar_enriquecimento.
 * Campos de contato só são PROPOSTOS; o banco só preenche o que estiver vazio.
 */
function montarEnriquecimento(linha, checagem, { agora = new Date(), fontesConsultadas = [] } = {}) {
  const pg = checagem && checagem.pagina;
  const origem = {};
  const dados = {
    status: !checagem || checagem.resultado === 'nao_verificado' ? 'parcial' : 'concluido',
    site_verificado_em: agora.toISOString(),
    site_http_status: checagem ? checagem.httpStatus : null,
    site_https: checagem ? checagem.https : null,
    sinais: sinaisPara(linha, checagem, { agora, fontesConsultadas }),
  };
  if (pg) {
    if (!linha.email && pg.emails[0]) { dados.email = pg.emails[0]; origem.email = 'site'; }
    if (!linha.telefone && (pg.telefones[0] || pg.whatsapp)) { dados.telefone = pg.telefones[0] || pg.whatsapp; origem.telefone = pg.telefones[0] ? 'site (tel:)' : 'site (WhatsApp)'; }
  }
  const ig = (pg && pg.instagram) || (checagem && checagem.instagram);
  if (!linha.instagram && ig) { dados.instagram = `@${ig}`; dados.instagram_handle = ig; origem.instagram = 'link no site'; }
  dados.enriquecimento = {
    site: checagem ? {
      resultado: checagem.resultado, http_status: checagem.httpStatus, https: checagem.https, url_final: checagem.url || null,
      evidencia: checagem.evidencia, titulo: pg ? pg.titulo : null, descricao: pg ? pg.descricao : null,
      formulario: pg ? pg.formulario : null, whatsapp: pg ? Boolean(pg.whatsapp) : null,
      instagram_no_site: pg ? Boolean(pg.instagram) : null, meta_description: pg ? Boolean(pg.descricao) : null,
      favicon: pg ? pg.favicon : null, paginas_verificadas: pg && pg.paginasVistas ? pg.paginasVistas : null,
      contato_visivel: pg ? Boolean(pg.formulario || pg.whatsapp || pg.emails.length || pg.telefones.length) : null,
      conclusivo: pg ? pg.conteudoSuficiente : false, verificado_em: agora.toISOString(),
    } : null,
    origem_campos: origem,
  };
  return dados;
}

/** Concorrência limitada (sem Promise.all de centenas de requisições). */
async function emLotes(itens, concorrencia, fn) {
  const resultados = new Array(itens.length);
  let i = 0;
  async function trabalhador() {
    while (i < itens.length) {
      const atual = i++;
      resultados[atual] = await fn(itens[atual], atual);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concorrencia, itens.length) }, trabalhador));
  return resultados;
}

module.exports = { verificarSite, sinaisPara, extrairInstagram, analisarPagina, montarEnriquecimento, rastrearContato, regrasRobots, linksRelacionados, emLotes, TIMEOUT_MS, MAX_REDIRECTS, MAX_BYTES };
