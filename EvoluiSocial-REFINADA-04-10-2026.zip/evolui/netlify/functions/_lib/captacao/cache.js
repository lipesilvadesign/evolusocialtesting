/**
 * Cache de resultado por provider (tabela admin_prospeccao_cache_provider, migration 011).
 *
 * Por que: repetir a mesma busca (mesmo setor, termo, centro e raio) refazia
 * todas as chamadas externas. A chave arredonda o centro em ~110 m (3 casas),
 * então "Petrolina, 15 km" hoje e daqui a 2 horas reaproveita o resultado.
 * TTL padrão 24 h (CAPTACAO_CACHE_HORAS). Geocodificação: 30 dias.
 * Falha do cache NUNCA derruba a busca — só vira métrica.
 */
const crypto = require('crypto');

const TTL_HORAS = Math.max(0, Number(process.env.CAPTACAO_CACHE_HORAS) || 24);
const TTL_GEO_HORAS = 24 * 30;
/**
 * 01/10 (Fase 3) — TTL por TIPO de dado (não um número único):
 *   listagens (Geoapify/OSM)  24 h  — empresas abrem/fecham; busca repetida no mesmo dia reaproveita
 *   geocodificação           30 dias — centro de cidade praticamente não muda
 *   site (checagem)           7 dias — site muda pouco; evita bater no mesmo domínio em buscas próximas
 *   CNPJ                     30 dias — dado cadastral muda raramente (consulta está DESLIGADA)
 */
const TTL_POR_TIPO = {
  geoapify: TTL_HORAS, overpass: TTL_HORAS, geocodificacao: TTL_GEO_HORAS,
  site: Math.max(0, Number(process.env.CAPTACAO_CACHE_SITE_HORAS) || 24 * 7), cnpj: 24 * 30,
};

function chave(provider, params) {
  const p = params || {};
  const base = [
    provider,
    p.setor || '',
    String(p.termo || '').trim().toLowerCase(),
    Number.isFinite(Number(p.lat)) ? Number(p.lat).toFixed(3) : '',
    Number.isFinite(Number(p.lon)) ? Number(p.lon).toFixed(3) : '',
    Number.isFinite(Number(p.raioKm)) ? Number(p.raioKm).toFixed(1) : '',
    p.cidade ? String(p.cidade).trim().toLowerCase() : '',
  ].join('|');
  return `${provider}:${crypto.createHash('sha1').update(base).digest('hex')}`;
}

function expiraEm(horas, agora = new Date()) {
  return new Date(agora.getTime() + horas * 3600 * 1000).toISOString();
}

module.exports = { chave, expiraEm, TTL_HORAS, TTL_GEO_HORAS, TTL_POR_TIPO };
