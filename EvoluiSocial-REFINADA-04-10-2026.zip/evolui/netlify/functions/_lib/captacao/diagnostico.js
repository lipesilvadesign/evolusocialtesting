/**
 * Agregados da telemetria REAL dos jobs (admin_prospeccao_buscas.metricas) para o
 * painel técnico e para o benchmark do relatório. Só conta o que foi medido:
 * job sem métrica de um campo não entra na mediana daquele campo.
 */
function mediana(v) {
  const a = v.filter((x) => Number.isFinite(x)).sort((x, y) => x - y);
  if (!a.length) return null;
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : Math.round((a[m - 1] + a[m]) / 2);
}

function agregar(jobs) {
  const comMetrica = jobs.filter((j) => j.metricas && Number.isFinite(j.metricas.total_ms));
  const prov = {};
  for (const j of comMetrica) {
    for (const [nome, p] of Object.entries(j.metricas.providers || {})) {
      const a = (prov[nome] = prov[nome] || { jobs: 0, sucesso: 0, timeout: 0, erro: 0, duracoes: [], resultados: 0 });
      a.jobs += 1;
      const ok = p.status ? ['concluido', 'parcial'].includes(p.status) : !p.erros;
      if (ok) a.sucesso += 1;
      else if (p.status === 'timeout' || /a tempo|timeout/i.test(p.ultimo_erro || '')) a.timeout += 1;
      else a.erro += 1;
      if (ok && Number.isFinite(p.duration_ms) && p.duration_ms > 0) a.duracoes.push(p.duration_ms);
      a.resultados += Number(p.resultados || 0);
    }
  }
  const provedores = Object.fromEntries(Object.entries(prov).map(([k, a]) => [k, {
    jobs: a.jobs, sucesso_pct: a.jobs ? Math.round((a.sucesso / a.jobs) * 100) : null, timeouts: a.timeout, erros: a.erro,
    latencia_mediana_ms: mediana(a.duracoes), resultados: a.resultados,
  }]));
  return {
    jobs_medidos: comMetrica.length,
    ttfr_mediana_ms: mediana(comMetrica.map((j) => j.metricas.ttfr_ms)),
    ttlc_mediana_ms: mediana(comMetrica.map((j) => j.metricas.ttlc_ms ?? j.metricas.total_ms)),
    dedup_mediana_ms: mediana(comMetrica.map((j) => j.metricas.dedup_ms)),
    gravacao_mediana_ms: mediana(comMetrica.map((j) => j.metricas.gravacao_ms)),
    provedores,
  };
}

module.exports = { agregar, mediana };
