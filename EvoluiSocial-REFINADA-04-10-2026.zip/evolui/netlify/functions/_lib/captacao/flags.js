/**
 * Feature flags do refinamento (30/09/2026) — variáveis de ambiente do Netlify.
 * Valor "0", "false", "off" ou "nao" DESLIGA; ausente = padrão abaixo.
 * Desligar uma flag volta ao comportamento anterior sem novo deploy de código
 * (basta mudar a variável e fazer "Clear cache and deploy" ou aguardar o
 * próximo deploy — Functions leem o ambiente a cada inicialização).
 *
 *   ENABLE_NEW_CAPTURE_FLOW  (padrão: ligado)   coleta paralela + cache + enriquecimento assíncrono + telemetria
 *   ENABLE_MAP_SELECTION     (padrão: ligado)   minimapa para escolher centro/raio da busca
 *   ENABLE_NEW_PDF_ENGINE    (padrão: ligado)   motor novo do PDF da apresentação pública
 *   ENABLE_CNPJ_LOOKUP       (padrão: DESLIGADO) consulta de CNPJ na BrasilAPI (decisão do dono — fornecedor)
 *
 * 01/10 — nomes da Fase 2 aceitos como SINÔNIMOS (o novo vale se os dois existirem):
 *   ENABLE_CAPTURE_ENGINE_V2 = ENABLE_NEW_CAPTURE_FLOW · ENABLE_PDF_V2 = ENABLE_NEW_PDF_ENGINE
 * ENABLE_NEW_APPROVAL e ENABLE_PRESENTATION_V2 NÃO existem de propósito: não há
 * versão anterior para onde voltar (a aprovação antiga inseria direto no CRM;
 * a apresentação manteve o mesmo HTML) — uma flag sem alternativa seria enganosa.
 */
const SINONIMOS = { ENABLE_NEW_CAPTURE_FLOW: 'ENABLE_CAPTURE_ENGINE_V2', ENABLE_NEW_PDF_ENGINE: 'ENABLE_PDF_V2' };
const PADROES = {
  ENABLE_NEW_CAPTURE_FLOW: true,
  ENABLE_MAP_SELECTION: true,
  ENABLE_NEW_PDF_ENGINE: true,
  ENABLE_CNPJ_LOOKUP: false,
};

function ligada(nome, env = process.env) {
  const sin = SINONIMOS[nome];
  const v = sin && env[sin] !== undefined && String(env[sin]).trim() !== '' ? env[sin] : env[nome];
  if (v === undefined || v === null || String(v).trim() === '') return PADROES[nome] === true;
  return !/^(0|false|off|nao|não|no)$/i.test(String(v).trim());
}

/** Só os nomes/estados — seguro para mandar ao navegador (sem valores de ambiente). */
function publicas(env = process.env) {
  return {
    novoFluxoCaptacao: ligada('ENABLE_NEW_CAPTURE_FLOW', env),
    selecaoNoMapa: ligada('ENABLE_MAP_SELECTION', env),
    novoPdf: ligada('ENABLE_NEW_PDF_ENGINE', env),
    consultaCnpj: ligada('ENABLE_CNPJ_LOOKUP', env),
  };
}

module.exports = { ligada, publicas, PADROES };
