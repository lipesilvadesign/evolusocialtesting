/**
 * Lead Capture Engine — CONTRATO dos providers.
 *
 * Todo provider (Geoapify, Overpass, CSV, consultoria, contato do site,
 * manual) devolve registros neste formato. Nenhum campo específico de API
 * vaza para o resto do pipeline: o formato original fica só em `payload`
 * (guardado para auditoria/reprocessamento).
 *
 * @typedef {Object} RegistroIntermediario
 * @property {string} provider        geoapify | overpass | csv | xlsx | consultoria | site_contato | manual
 * @property {string} external_id     id estável na origem, com prefixo: "geoapify:<place_id>", "osm:node/123",
 *                                    "csv:<hash>:<linha>", "consulta:<uuid>", "site_contato:<uuid>", "manual:<uuid>"
 * @property {object} payload         dado original (sem alteração)
 * @property {string} empresa
 * @property {string|null} telefone
 * @property {string|null} email
 * @property {string|null} site
 * @property {string|null} instagram
 * @property {string|null} cnpj
 * @property {string|null} endereco
 * @property {string|null} cidade
 * @property {string|null} uf
 * @property {number|null} lat
 * @property {number|null} lon
 * @property {string|null} categoria_origem  categoria/tag da origem, sem tradução
 * @property {string|null} setor_sugerido    texto livre; a normalização mapeia para a taxonomia
 */

const CAMPOS = ['provider', 'external_id', 'payload', 'empresa', 'telefone', 'email', 'site', 'instagram', 'cnpj',
  'endereco', 'cidade', 'uf', 'lat', 'lon', 'categoria_origem', 'setor_sugerido'];
const { PROVIDERS } = require('./taxonomia');

/** Monta um registro com TODAS as chaves do contrato (ausentes = null). */
function registro(parcial) {
  const r = {};
  for (const c of CAMPOS) r[c] = parcial[c] === undefined || parcial[c] === '' ? null : parcial[c];
  return r;
}

/** @returns {string[]} problemas (vazio = válido) */
function validarRegistro(r) {
  const problemas = [];
  if (!r || typeof r !== 'object') return ['registro ausente'];
  for (const c of CAMPOS) if (!(c in r)) problemas.push(`campo ausente: ${c}`);
  if (!PROVIDERS.includes(r.provider)) problemas.push(`provider desconhecido: ${r.provider}`);
  if (!r.external_id || typeof r.external_id !== 'string') problemas.push('external_id obrigatório');
  if (!r.empresa || typeof r.empresa !== 'string') problemas.push('empresa obrigatória');
  const extras = Object.keys(r).filter((k) => !CAMPOS.includes(k));
  if (extras.length) problemas.push(`campos fora do contrato: ${extras.join(', ')}`);
  return problemas;
}

module.exports = { CAMPOS, registro, validarRegistro };
