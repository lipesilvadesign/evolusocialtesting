/**
 * Saúde dos providers por HOST (Fase 3, migration 013).
 *
 * Fonte: admin_prospeccao_provider_saude (escrita só pela RPC
 * prospeccao_registrar_saude, que também abre/fecha o cooldown — circuito de
 * proteção: 3 falhas seguidas → 5, 10, 20… até 60 min sem usar o host).
 *
 * ordenar(): hosts em cooldown vão para o FIM (não somem: se todos estiverem
 * em cooldown, ainda são tentados); os demais por taxa de sucesso suavizada
 * ((sucessos+1)/(tentativas+2)) e, no empate, menor latência. Sem histórico
 * = 0,5 (neutro) e ordem original preservada.
 */
function hostDe(url) { try { return new URL(url).host; } catch { return url; } }

function ordenar(urls, linhas, agora = new Date()) {
  const porHost = new Map((linhas || []).map((l) => [l.host, l]));
  const item = (url, i) => {
    const l = porHost.get(hostDe(url));
    const cooldown = Boolean(l && l.cooldown_ate && new Date(l.cooldown_ate) > agora);
    const taxa = l ? (Number(l.sucessos || 0) + 1) / (Number(l.tentativas || 0) + 2) : 0.5;
    const lat = l && Number.isFinite(Number(l.latencia_media_ms)) ? Number(l.latencia_media_ms) : 5000;
    return { url, i, cooldown, taxa, lat };
  };
  return urls.map(item)
    .sort((a, b) => (a.cooldown - b.cooldown) || (b.taxa - a.taxa) || (a.lat - b.lat) || (a.i - b.i))
    .map((x) => x.url);
}

/** Resumo legível para o painel técnico. */
function resumo(l) {
  const t = Number(l.tentativas || 0);
  const pct = (n) => (t ? Math.round((Number(n || 0) / t) * 100) : 0);
  return {
    host: l.host, provider: l.provider, tentativas: t,
    sucesso_pct: pct(l.sucessos), s429_pct: pct(l.s429), s406_pct: pct(l.s406), timeout_pct: pct(l.timeouts), s5xx_pct: pct(l.s5xx),
    latencia_media_ms: l.latencia_media_ms, ultimo_sucesso: l.ultimo_sucesso, ultimo_status: l.ultimo_status,
    em_cooldown: Boolean(l.cooldown_ate && new Date(l.cooldown_ate) > new Date()), cooldown_ate: l.cooldown_ate,
  };
}

module.exports = { ordenar, resumo, hostDe };
