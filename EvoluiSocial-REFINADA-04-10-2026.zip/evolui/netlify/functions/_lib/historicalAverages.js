/**
 * Comparação histórica: médias de 7/30/90 dias, calculadas a partir da
 * série diária (analyticsService.getDailyTimeSeries). Puro — não busca
 * dado nenhum, só recebe a série já pronta e agrega.
 */

const { mean, round1 } = require('./stats');

const WINDOWS = [7, 30, 90];
const TRACKED_METRICS = ['activeUsers', 'sessions', 'screenPageViews', 'engagementRate', 'averageSessionDuration'];

/**
 * @param {Array<{date:string}>} timeSeries - ordenada por data crescente, mais recente por último
 * @returns {Object} ex: { activeUsers: { avg7: 12.3, avg30: 10.1, avg90: 9.8 }, ... }
 */
function computeHistoricalAverages(timeSeries) {
  const result = {};
  TRACKED_METRICS.forEach((metric) => {
    result[metric] = {};
    WINDOWS.forEach((w) => {
      const slice = timeSeries
        .slice(-w)
        .map((row) => row[metric])
        .filter((v) => typeof v === 'number');
      result[metric][`avg${w}`] = slice.length ? round1(mean(slice)) : null;
    });
  });
  return result;
}

module.exports = { computeHistoricalAverages, WINDOWS, TRACKED_METRICS };
