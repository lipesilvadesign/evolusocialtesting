/**
 * Calcula o score de um lead a partir de sinais reais marcados (não é uma
 * "chance de fechar contrato" mágica — é uma soma pontuada de critérios
 * concretos, cada um explicado em `motivos`, pra nunca virar um número
 * opaco). Pontuação inspirada na análise recebida do usuário sobre como
 * agências maduras qualificam leads.
 *
 * Sinais automáticos (derivados de dados que o sistema já tem):
 *   - Sem site encontrado
 *   - Decisor identificado (tem contato cadastrado)
 *   - Respondeu / pediu proposta ou reunião (derivado do estágio da oportunidade)
 *
 * Sinais manuais (ninguém tem API que avalie isso — o humano marca no
 * editor): site desatualizado, Instagram desorganizado, GBP fraco, porte
 * médio/grande, segmento de alto potencial, e-mail validado.
 */

const PONTOS = {
  semSite: 30,
  siteDesatualizado: 20,
  instagramDesorganizado: 15,
  gbpFraco: 15,
  porteMedioGrande: 15,
  segmentoAltoPotencial: 15,
  decisorIdentificado: 20,
  emailValidado: 10,
  respondeu: 40,
  pediuPropostaOuReuniao: 70,
};

// Estágios do funil (coluna "status" — o ESTÁGIO DA OPORTUNIDADE) que já
// implicam "respondeu" ou "pediu proposta/reunião", sem precisar de um
// checkbox manual redundante pra isso.
// 30/09: 'interessado' também conta como resposta (antes valia menos que 'respondeu'). A partir da migration 008 o score oficial é o do banco.
const ESTAGIOS_RESPONDEU = ['respondeu', 'interessado', 'reuniao_marcada', 'proposta_enviada', 'cliente'];
const ESTAGIOS_PEDIU_PROPOSTA_OU_REUNIAO = ['reuniao_marcada', 'proposta_enviada', 'cliente'];

/**
 * @param {{
 *   site?: string|null,
 *   status?: string,
 *   temContatoDecisor?: boolean,
 *   sinalSiteDesatualizado?: boolean,
 *   sinalInstagramDesorganizado?: boolean,
 *   sinalGbpFraco?: boolean,
 *   sinalPorteMedioGrande?: boolean,
 *   sinalSegmentoAltoPotencial?: boolean,
 *   sinalEmailValidado?: boolean,
 * }} lead
 * @returns {{ score: number, motivos: Array<{ label: string, pontos: number }> }}
 */
function calcularScore(lead) {
  const motivos = [];

  if (!lead.site) motivos.push({ label: 'Sem site encontrado', pontos: PONTOS.semSite });
  if (lead.sinalSiteDesatualizado) motivos.push({ label: 'Site desatualizado/com problema técnico', pontos: PONTOS.siteDesatualizado });
  if (lead.sinalInstagramDesorganizado) motivos.push({ label: 'Instagram ativo, mas desorganizado', pontos: PONTOS.instagramDesorganizado });
  if (lead.sinalGbpFraco) motivos.push({ label: 'Google Business Profile fraco', pontos: PONTOS.gbpFraco });
  if (lead.sinalPorteMedioGrande) motivos.push({ label: 'Empresa de médio/grande porte', pontos: PONTOS.porteMedioGrande });
  if (lead.sinalSegmentoAltoPotencial) motivos.push({ label: 'Segmento de alto potencial', pontos: PONTOS.segmentoAltoPotencial });
  if (lead.temContatoDecisor) motivos.push({ label: 'Contato decisor identificado', pontos: PONTOS.decisorIdentificado });
  if (lead.sinalEmailValidado) motivos.push({ label: 'E-mail validado', pontos: PONTOS.emailValidado });

  const estagio = lead.status || 'novo_lead';
  if (ESTAGIOS_PEDIU_PROPOSTA_OU_REUNIAO.includes(estagio)) {
    motivos.push({ label: 'Pediu proposta ou reunião', pontos: PONTOS.pediuPropostaOuReuniao });
  } else if (ESTAGIOS_RESPONDEU.includes(estagio)) {
    motivos.push({ label: 'Respondeu ao contato', pontos: PONTOS.respondeu });
  }

  const score = motivos.reduce((acc, m) => acc + m.pontos, 0);
  return { score, motivos };
}

/**
 * Faixa de leitura do score, pra exibir na interface junto do número.
 * @param {number} score
 * @returns {{ chave: string, label: string }}
 */
function faixaScore(score) {
  if (score > 90) return { chave: 'prioritario', label: 'Prioritário' };
  if (score >= 61) return { chave: 'prospectar', label: 'Prospectar' };
  if (score >= 31) return { chave: 'nutrir', label: 'Nutrir' };
  return { chave: 'aguardar', label: 'Aguardar' };
}

module.exports = { calcularScore, faixaScore, PONTOS };
