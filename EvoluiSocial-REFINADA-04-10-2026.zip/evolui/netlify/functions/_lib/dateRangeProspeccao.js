/**
 * Resolve um período nomeado (hoje/semana/mês/tudo) em limites de data reais
 * (ISO 8601, timestamptz), pra filtrar consultas no Postgres — diferente de
 * dateRange.js (que resolve pra strings relativas específicas da API do
 * GA4, tipo "7daysAgo", e não serve pra filtro de banco de dados de verdade).
 *
 * Semana = últimos 7 dias corridos (não "esta semana civil", que teria uma
 * borda estranha na segunda-feira). Mês = últimos 30 dias corridos, mesma
 * lógica. "Tudo" não tem limite de início (retorna null).
 */

const PERIODOS_VALIDOS = ['hoje', 'semana', 'mes', 'tudo'];
const LABELS = { hoje: 'Hoje', semana: 'Últimos 7 dias', mes: 'Últimos 30 dias', tudo: 'Todo o período' };

/**
 * @param {string} periodo um de: 'hoje' | 'semana' | 'mes' | 'tudo'
 * @param {Date} [agora] injetável só pra teste — produção sempre usa o relógio real
 * @returns {{ inicio: string|null, fim: string, periodo: string, label: string }}
 */
function resolverPeriodo(periodo, agora = new Date()) {
  if (!PERIODOS_VALIDOS.includes(periodo)) {
    throw new Error(`Período inválido: "${periodo}". Use um de: ${PERIODOS_VALIDOS.join(', ')}.`);
  }

  const fim = agora.toISOString();

  if (periodo === 'tudo') {
    return { inicio: null, fim, periodo, label: LABELS[periodo] };
  }

  const dias = { hoje: 1, semana: 7, mes: 30 }[periodo];
  const inicioDate = new Date(agora.getTime() - dias * 24 * 60 * 60 * 1000);
  return { inicio: inicioDate.toISOString(), fim, periodo, label: LABELS[periodo] };
}

module.exports = { resolverPeriodo, PERIODOS_VALIDOS };
