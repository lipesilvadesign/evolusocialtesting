/**
 * Opportunity Engine.
 *
 * "Identificar problemas e priorizar ações por impacto e esforço." Puro,
 * sem I/O. Junta 3 fontes já calculadas (insightsEngine determinístico,
 * anomalyEngine, healthScoreEngine) num board único de oportunidades,
 * cada uma com impacto/esforço/prioridade e a evidência que a originou.
 */

const IMPACT_WEIGHT = { alto: 3, medio: 2, baixo: 1 };
const EFFORT_WEIGHT = { alto: 3, medio: 2, baixo: 1 };

// Esforço estimado por tipo de causa raiz — heurística deliberada e
// documentada (não é medida real de esforço de implementação): mudanças
// de conteúdo/CTA = baixo, ajustes de engajamento/UX = médio, mudanças
// de estratégia de canal = alto.
const EFFORT_BY_METRIC = {
  'pages.eventsPerView': 'baixo',
  'pages.views': 'baixo',
  'events.count': 'baixo',
  engagementRate: 'medio',
  'trafficSources.sessions': 'alto',
  activeUsers: 'alto',
};

function impactFromSeverityOrConfidence(insight) {
  if (insight.severity) return insight.severity === 'alta' ? 'alto' : insight.severity === 'media' ? 'medio' : 'baixo';
  if (insight.confidence === 'alta') return 'alto';
  if (insight.confidence === 'media') return 'medio';
  return 'baixo';
}

function quadrant(impact, effort) {
  if (impact === 'alto' && effort !== 'alto') return 'Ganho rápido';
  if (impact === 'alto' && effort === 'alto') return 'Projeto estratégico';
  if (impact !== 'alto' && effort === 'baixo') return 'Ganho menor';
  return 'Baixa prioridade';
}

function buildOpportunity({ title, description, impact, effort, evidence, sourceType }) {
  const priorityScore = IMPACT_WEIGHT[impact] * 10 - EFFORT_WEIGHT[effort];
  return {
    title,
    description,
    impact,
    effort,
    quadrant: quadrant(impact, effort),
    priorityScore,
    evidence,
    sourceType, // 'insight' | 'anomalia' | 'health-score'
  };
}

function fromDeterministicInsights(deterministicInsights) {
  return (deterministicInsights || [])
    .filter((i) => ['attention', 'alert', 'opportunity'].includes(i.type))
    .map((i) => {
      const impact = impactFromSeverityOrConfidence(i);
      const effort = EFFORT_BY_METRIC[i.metric] || 'medio';
      return buildOpportunity({
        title: i.title,
        description: i.description,
        impact,
        effort,
        evidence: { metric: i.metric, value: i.value, comparison: i.comparison },
        sourceType: 'insight',
      });
    });
}

function fromAnomalies(anomalies) {
  return (anomalies || []).map((a) => {
    const impact = a.severity === 'alta' ? 'alto' : 'medio';
    return buildOpportunity({
      title: `Investigar anomalia em ${a.metricLabel}`,
      description: `Os dados indicam um valor fora do padrão histórico em ${a.metricLabel} no dia ${a.date} (${a.direction}, ${a.zScore} desvios-padrão da média dos últimos ${a.baselineDays} dias).`,
      impact,
      effort: 'medio',
      evidence: { metric: a.metric, value: a.value, baselineMean: a.baselineMean, zScore: a.zScore, date: a.date },
      sourceType: 'anomalia',
    });
  });
}

const HEALTH_SCORE_THRESHOLD = 40;

function fromHealthScore(healthScore) {
  return (healthScore.subScores || [])
    .filter((s) => s.score != null && s.score < HEALTH_SCORE_THRESHOLD)
    .map((s) =>
      buildOpportunity({
        title: `Melhorar ${s.label.toLowerCase()}`,
        description: `A nota de ${s.label} está em ${s.score}/100, abaixo do patamar de referência (${HEALTH_SCORE_THRESHOLD}). ${s.explanation}`,
        impact: s.score < 25 ? 'alto' : 'medio',
        effort: 'alto',
        evidence: { subScore: s.key, score: s.score, factors: s.factors },
        sourceType: 'health-score',
      })
    );
}

/**
 * @param {Array} deterministicInsights
 * @param {Array} anomalies
 * @param {{ overall: number|null, subScores: Array }} healthScore
 * @returns {Array} ordenado por priorityScore desc
 */
function deriveOpportunities(deterministicInsights, anomalies, healthScore) {
  const all = [
    ...fromDeterministicInsights(deterministicInsights),
    ...fromAnomalies(anomalies),
    ...fromHealthScore(healthScore),
  ];
  return all.sort((a, b) => b.priorityScore - a.priorityScore);
}

module.exports = { deriveOpportunities, HEALTH_SCORE_THRESHOLD };
