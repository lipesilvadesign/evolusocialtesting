/**
 * Cache simples em memória do processo (mapa chave→{value, expiresAt}).
 *
 * LIMITAÇÃO REAL, documentada de propósito: Netlify Functions não garantem
 * uma instância "quente" entre chamadas — isto reduz chamadas repetidas em
 * rajada (ex: usuário troca de aba e volta rápido), mas NÃO é um cache
 * distribuído nem sobrevive a cold start. Suficiente pra aliviar quota sem
 * inventar infraestrutura nova (Redis etc.) que o projeto não tem.
 */
const store = new Map();

// Etapa "Operação, Automação e Escala" (performance): coalescimento de
// chamadas concorrentes idênticas. Se duas requisições pedirem a MESMA
// chave ao mesmo tempo (ex: dois cliques rápidos, ou várias seções da UI
// pedindo o mesmo dado em paralelo), só a primeira dispara o loader — as
// outras esperam a mesma Promise em vez de disparar chamadas duplicadas
// ao GA4/Supabase/IA.
const inFlight = new Map();

/**
 * @param {string} key
 * @param {number} ttlMs
 * @param {() => Promise<any>} loader
 */
async function withCache(key, ttlMs, loader) {
  const hit = store.get(key);
  if (hit && hit.expiresAt > Date.now()) return hit.value;

  if (inFlight.has(key)) return inFlight.get(key);

  const promise = loader()
    .then((value) => {
      store.set(key, { value, expiresAt: Date.now() + ttlMs });
      return value;
    })
    .finally(() => inFlight.delete(key));

  inFlight.set(key, promise);
  return promise;
}

/**
 * Remove uma chave do cache antes de recarregar — usado pela "atualização
 * manual" (ex: botão "Gerar nova análise"), pra forçar um loader novo E já
 * deixar o resultado fresco salvo no cache pra próxima leitura normal.
 */
function invalidate(key) {
  store.delete(key);
}

module.exports = { withCache, invalidate };
