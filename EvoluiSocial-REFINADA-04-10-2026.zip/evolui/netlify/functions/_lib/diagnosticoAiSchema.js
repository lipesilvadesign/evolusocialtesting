const { AiError } = require('./errors/aiErrors');

function isNonEmptyString(v) {
  return typeof v === 'string' && v.trim().length > 0;
}

function validateCalculo(item, i) {
  if (!item || typeof item !== 'object') {
    throw new AiError('AI_INVALID_RESPONSE', `calculo[${i}]: item não é um objeto.`);
  }
  if (!isNonEmptyString(item.formula) || !isNonEmptyString(item.resultado)) {
    throw new AiError('AI_INVALID_RESPONSE', `calculo[${i}]: "formula" e "resultado" são obrigatórios.`);
  }
  return { formula: item.formula, resultado: item.resultado };
}

/**
 * @param {object} raw - saída bruta do tool_use da IA
 * @returns {{ dadosInsuficientes: boolean, dadoFornecido: string[], calculo: {formula:string,resultado:string}[],
 *   interpretacao: string, recomendacao: string, motivoDadosInsuficientes: string|null }}
 */
function validateDiagnosticoAiResponse(raw) {
  if (!raw || typeof raw !== 'object') {
    throw new AiError('AI_INVALID_RESPONSE', 'Resposta da IA não é um objeto.');
  }
  if (typeof raw.dados_insuficientes !== 'boolean') {
    throw new AiError('AI_INVALID_RESPONSE', '"dados_insuficientes" ausente ou não é booleano.');
  }
  if (!Array.isArray(raw.dado_fornecido) || !raw.dado_fornecido.every(isNonEmptyString)) {
    throw new AiError('AI_INVALID_RESPONSE', '"dado_fornecido" precisa ser uma lista de textos.');
  }
  if (!Array.isArray(raw.calculo)) {
    throw new AiError('AI_INVALID_RESPONSE', '"calculo" precisa ser uma lista.');
  }
  if (!isNonEmptyString(raw.interpretacao) && !raw.dados_insuficientes) {
    throw new AiError('AI_INVALID_RESPONSE', '"interpretacao" ausente ou vazia.');
  }
  if (!isNonEmptyString(raw.recomendacao) && !raw.dados_insuficientes) {
    throw new AiError('AI_INVALID_RESPONSE', '"recomendacao" ausente ou vazia.');
  }
  return {
    dadosInsuficientes: raw.dados_insuficientes,
    dadoFornecido: raw.dado_fornecido,
    calculo: raw.calculo.map(validateCalculo),
    interpretacao: raw.interpretacao || '',
    recomendacao: raw.recomendacao || '',
    motivoDadosInsuficientes: typeof raw.motivo_dados_insuficientes === 'string' ? raw.motivo_dados_insuficientes : null,
  };
}

module.exports = { validateDiagnosticoAiResponse };
