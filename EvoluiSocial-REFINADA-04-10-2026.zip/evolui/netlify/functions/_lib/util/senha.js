/**
 * Gerador de senha temporária — usado tanto ao criar uma conta com
 * "gerar login e senha agora" quanto ao redefinir a senha de uma conta já
 * existente. Extraído aqui pra não duplicar a mesma lógica em duas
 * Functions (funcionarios-convidar.js e funcionarios-conta.js).
 *
 * 12 caracteres, alfanumérico + símbolo — gerado com crypto (não
 * Math.random, que não é seguro pra isto).
 */
const crypto = require('crypto');

function gerarSenhaTemporaria() {
  const alfabeto = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  const bytes = crypto.randomBytes(12);
  let senha = '';
  for (let i = 0; i < 12; i++) senha += alfabeto[bytes[i] % alfabeto.length];
  return senha;
}

module.exports = { gerarSenhaTemporaria };
