/**
 * Insights Engine.
 *
 * Fluxo: analyticsService → analyticsNormalizer → insightsEngine →
 * structuredInsights → UI. Este arquivo é o motor: 100% determinístico,
 * baseado em regras explícitas e legíveis — SEM IA generativa (por pedido
 * explícito desta etapa). Não sabe o que é uma Netlify Function nem um
 * card de UI; só recebe um NormalizedSnapshot e devolve uma lista de
 * StructuredInsight.
 *
 * Princípio seguido em toda regra: nunca afirmar causalidade
 * ("X aconteceu porque Y") a partir de correlação. A linguagem sempre usa
 * "os dados indicam", "foi observado", "pode ser interessante investigar".
 */

// ---------------------------------------------------------------------
// Limiares — todos nomeados e comentados, nenhum "número mágico" solto.
// Ajustar aqui muda o comportamento do motor inteiro, sem mexer nas regras.
// ---------------------------------------------------------------------
const THRESHOLDS = {
  USERS_GROWTH_PCT: 15, // crescimento de usuários ativos considerado "significativo"
  USERS_DROP_PCT: -15, // queda considerada "significativa" (gera alerta)
  CHANNEL_GROWTH_PCT: 25,
  CHANNEL_MIN_PREVIOUS_SESSIONS: 10, // abaixo disso, variação % é ruído
  PAGE_GROWTH_PCT: 25,
  PAGE_MIN_PREVIOUS_VIEWS: 15,
  PAGE_MIN_NEW_VIEWS: 10, // página nova (sem dado anterior) precisa desse mínimo pra virar insight
  EVENT_GROWTH_PCT: 30,
  EVENT_MIN_PREVIOUS_COUNT: 10,
  EVENT_MIN_NEW_COUNT: 10,
  ENGAGEMENT_RATE_LOW_PCT: 40, // abaixo disso, taxa de engajamento é "baixa"
  ENGAGEMENT_MIN_SESSIONS: 20, // volume mínimo pra essa leitura fazer sentido
  CONVERSION_ATTENTION_RATIO: 0.5, // eventsPerView < 50% da média das top páginas
  CONVERSION_TOP_N_PAGES: 5, // só olha essa regra nas N páginas mais visitadas
  MAX_RECOMMENDATIONS: 5,
};

function computeConfidence(volume, deltaPct) {
  const absPct = deltaPct == null ? 0 : Math.abs(deltaPct);
  if (volume < 10) return 'baixa';
  if (volume < 50 || absPct < 20) return 'media';
  return 'alta';
}

function computeSeverity(deltaPct) {
  const absPct = Math.abs(deltaPct || 0);
  if (absPct >= 40) return 'alta';
  if (absPct >= 20) return 'media';
  return 'baixa';
}

function comparisonOf(entry, rangeLabel) {
  return {
    previousValue: entry.previousValue ?? entry.previousViews ?? entry.previousCount ?? entry.previousSessions ?? null,
    deltaAbs: entry.deltaAbs,
    deltaPct: entry.deltaPct,
    rangeLabel,
  };
}

let counter = 0;
function nextId(prefix) {
  counter += 1;
  return `${prefix}-${counter}`;
}

// ---------------------------------------------------------------------
// Regras individuais — cada uma só olha uma fatia do snapshot e devolve
// 0..N insights. Nenhuma regra depende de outra (independência é o que
// mantém isto "transparente": dá pra ler cada uma isoladamente).
// ---------------------------------------------------------------------

function ruleUsersGrowth(snapshot) {
  const m = snapshot.metrics.activeUsers;
  if (!m) return [];
  const out = [];
  if (m.isNew && m.value >= THRESHOLDS.PAGE_MIN_NEW_VIEWS) {
    out.push({
      type: 'positive',
      title: 'Novo volume de usuários ativos',
      description: `Foi observado tráfego de usuários ativos (${m.value}) neste período, sem base de comparação no período anterior (que estava zerado).`,
      metric: 'activeUsers',
      value: m.value,
      comparison: comparisonOf(m, snapshot.rangeLabel),
      severity: null,
      confidence: 'baixa',
    });
  } else if (m.deltaPct != null && m.deltaPct >= THRESHOLDS.USERS_GROWTH_PCT) {
    out.push({
      type: 'positive',
      title: 'Crescimento de usuários ativos',
      description: `Os dados indicam um aumento de ${m.deltaPct}% em usuários ativos (${m.previousValue} → ${m.value}) em relação ao período anterior.`,
      metric: 'activeUsers',
      value: m.value,
      comparison: comparisonOf(m, snapshot.rangeLabel),
      severity: null,
      confidence: computeConfidence(m.value, m.deltaPct),
    });
  }
  return out;
}

function ruleUsersDrop(snapshot) {
  const m = snapshot.metrics.activeUsers;
  if (!m || m.deltaPct == null) return [];
  if (m.deltaPct > THRESHOLDS.USERS_DROP_PCT) return [];
  return [
    {
      type: 'alert',
      title: 'Queda de usuários ativos',
      description: `Os dados indicam uma redução de ${Math.abs(m.deltaPct)}% em usuários ativos (${m.previousValue} → ${m.value}) em relação ao período anterior. Pode ser interessante investigar o que mudou nesse intervalo.`,
      metric: 'activeUsers',
      value: m.value,
      comparison: comparisonOf(m, snapshot.rangeLabel),
      severity: computeSeverity(m.deltaPct),
      confidence: computeConfidence(m.previousValue || 0, m.deltaPct),
    },
  ];
}

function ruleEngagementLow(snapshot) {
  const engagement = snapshot.metrics.engagementRate;
  const sessions = snapshot.metrics.sessions;
  if (!engagement || !sessions) return [];
  if (sessions.value < THRESHOLDS.ENGAGEMENT_MIN_SESSIONS) return [];
  if (engagement.value >= THRESHOLDS.ENGAGEMENT_RATE_LOW_PCT) return [];
  return [
    {
      type: 'attention',
      title: 'Taxa de engajamento baixa',
      description: `A taxa de engajamento está em ${engagement.value}% no período, abaixo do patamar de referência (${THRESHOLDS.ENGAGEMENT_RATE_LOW_PCT}%). Pode ser interessante investigar a experiência de navegação ou a relevância do conteúdo para quem chega ao site.`,
      metric: 'engagementRate',
      value: engagement.value,
      comparison: comparisonOf(engagement, snapshot.rangeLabel),
      severity: 'media',
      confidence: computeConfidence(sessions.value, 0),
    },
  ];
}

function ruleTrafficSourceTrend(snapshot) {
  const out = [];
  (snapshot.trafficSources || []).forEach((t) => {
    if (t.isNew || t.deltaPct == null) return;
    if ((t.previousSessions || 0) < THRESHOLDS.CHANNEL_MIN_PREVIOUS_SESSIONS) return;
    if (t.deltaPct >= THRESHOLDS.CHANNEL_GROWTH_PCT) {
      out.push({
        type: 'trend',
        title: `Canal em alta: ${t.channel}`,
        description: `Os dados indicam um aumento de ${t.deltaPct}% em sessões vindas de "${t.channel}" (${t.previousSessions} → ${t.sessions}) em relação ao período anterior.`,
        metric: 'trafficSources.sessions',
        value: t.sessions,
        comparison: comparisonOf(t, snapshot.rangeLabel),
        severity: null,
        confidence: computeConfidence(t.previousSessions, t.deltaPct),
      });
    } else if (t.deltaPct <= -THRESHOLDS.CHANNEL_GROWTH_PCT) {
      out.push({
        type: 'attention',
        title: `Canal em queda: ${t.channel}`,
        description: `Os dados indicam uma redução de ${Math.abs(t.deltaPct)}% em sessões vindas de "${t.channel}" (${t.previousSessions} → ${t.sessions}) em relação ao período anterior.`,
        metric: 'trafficSources.sessions',
        value: t.sessions,
        comparison: comparisonOf(t, snapshot.rangeLabel),
        severity: computeSeverity(t.deltaPct),
        confidence: computeConfidence(t.previousSessions, t.deltaPct),
      });
    }
  });
  return out;
}

function ruleUnderlyingPageOpportunity(snapshot) {
  const out = [];
  (snapshot.pages || []).forEach((p) => {
    const label = p.title || p.path;
    if (p.isNew && p.views >= THRESHOLDS.PAGE_MIN_NEW_VIEWS) {
      out.push({
        type: 'opportunity',
        title: `Nova página recebendo tráfego: ${label}`,
        description: `Foi observado tráfego (${p.views} visualizações) nesta página, sem histórico no período anterior. Pode ser interessante acompanhar sua evolução.`,
        metric: 'pages.views',
        value: p.views,
        comparison: comparisonOf(p, snapshot.rangeLabel),
        severity: null,
        confidence: 'baixa',
        evidence: { path: p.path },
      });
      return;
    }
    if (p.deltaPct == null) return;
    if ((p.previousViews || 0) < THRESHOLDS.PAGE_MIN_PREVIOUS_VIEWS) return;
    if (p.deltaPct >= THRESHOLDS.PAGE_GROWTH_PCT) {
      out.push({
        type: 'opportunity',
        title: `Página em crescimento: ${label}`,
        description: `Os dados indicam um aumento de ${p.deltaPct}% nas visualizações desta página (${p.previousViews} → ${p.views}) em relação ao período anterior.`,
        metric: 'pages.views',
        value: p.views,
        comparison: comparisonOf(p, snapshot.rangeLabel),
        severity: null,
        confidence: computeConfidence(p.previousViews, p.deltaPct),
        evidence: { path: p.path },
      });
    }
  });
  return out;
}

function rulePageConversionAttention(snapshot) {
  const out = [];
  const topPages = (snapshot.pages || []).slice(0, THRESHOLDS.CONVERSION_TOP_N_PAGES);
  const avg = snapshot.avgEventsPerView || 0;
  if (avg <= 0) return out;
  topPages.forEach((p) => {
    if (p.views < THRESHOLDS.PAGE_MIN_PREVIOUS_VIEWS) return;
    if (p.eventsPerView >= avg * THRESHOLDS.CONVERSION_ATTENTION_RATIO) return;
    const label = p.title || p.path;
    out.push({
      type: 'attention',
      title: `Muitas visualizações, poucos eventos: ${label}`,
      description: `Esta página está entre as mais visitadas (${p.views} visualizações), mas registra ${p.eventsPerView} eventos por visualização — abaixo da média das páginas mais visitadas (${avg}). Os dados apenas mostram essa diferença; pode ser interessante investigar se há um problema de conversão ou de chamada para ação nessa página.`,
      metric: 'pages.eventsPerView',
      value: p.eventsPerView,
      comparison: { previousValue: null, deltaAbs: null, deltaPct: null, rangeLabel: snapshot.rangeLabel },
      severity: 'media',
      confidence: computeConfidence(p.views, 0),
      evidence: { path: p.path, avgEventsPerView: avg },
    });
  });
  return out;
}

function ruleEventTrend(snapshot) {
  const out = [];
  (snapshot.events || []).forEach((e) => {
    if (e.isNew && e.count >= THRESHOLDS.EVENT_MIN_NEW_COUNT) {
      out.push({
        type: 'trend',
        title: `Novo comportamento observado: ${e.name}`,
        description: `O evento "${e.name}" foi registrado ${e.count} vezes neste período, sem ocorrências no período anterior.`,
        metric: 'events.count',
        value: e.count,
        comparison: comparisonOf(e, snapshot.rangeLabel),
        severity: null,
        confidence: 'baixa',
        evidence: { eventName: e.name },
      });
      return;
    }
    if (e.deltaPct == null) return;
    if ((e.previousCount || 0) < THRESHOLDS.EVENT_MIN_PREVIOUS_COUNT) return;
    if (e.deltaPct >= THRESHOLDS.EVENT_GROWTH_PCT) {
      out.push({
        type: 'trend',
        title: `Evento em alta: ${e.name}`,
        description: `Os dados indicam um aumento de ${e.deltaPct}% nas ocorrências do evento "${e.name}" (${e.previousCount} → ${e.count}) em relação ao período anterior.`,
        metric: 'events.count',
        value: e.count,
        comparison: comparisonOf(e, snapshot.rangeLabel),
        severity: null,
        confidence: computeConfidence(e.previousCount, e.deltaPct),
        evidence: { eventName: e.name },
      });
    }
  });
  return out;
}

const RULES = [
  ruleUsersGrowth,
  ruleUsersDrop,
  ruleEngagementLow,
  ruleTrafficSourceTrend,
  ruleUnderlyingPageOpportunity,
  rulePageConversionAttention,
  ruleEventTrend,
];

/** Gera recomendações a partir de insights já produzidos — sempre referenciando a mesma evidência (transparência). */
function deriveRecommendations(insights) {
  const recs = [];
  insights.forEach((insight) => {
    if (insight.type === 'opportunity' && insight.metric === 'pages.views') {
      recs.push({
        base: insight,
        title: `Considere destacar: ${insight.title.replace('Página em crescimento: ', '').replace('Nova página recebendo tráfego: ', '')}`,
        description:
          'Como esta página está em crescimento, pode ser interessante destacá-la em outros canais (redes sociais, e-mail, navegação do site) enquanto o interesse está alto.',
      });
    }
    if (insight.type === 'attention' && insight.metric === 'pages.eventsPerView') {
      recs.push({
        base: insight,
        title: `Revisar conversão da página`,
        description:
          'Pode ser interessante revisar títulos, imagens e chamadas para ação dessa página para entender por que o engajamento está abaixo da média das páginas mais visitadas.',
      });
    }
    if (insight.type === 'alert' && insight.metric === 'activeUsers') {
      recs.push({
        base: insight,
        title: 'Investigar queda de usuários',
        description:
          'Pode valer revisar o que mudou no período (campanhas pausadas, sazonalidade, problemas técnicos no site) para entender a causa da queda.',
      });
    }
    if (insight.type === 'attention' && insight.metric === 'trafficSources.sessions') {
      recs.push({
        base: insight,
        title: `Revisar estratégia do canal`,
        description: 'Pode valer revisar a estratégia para este canal, já que ele perdeu participação no período.',
      });
    }
  });

  return recs
    .sort((a, b) => severityRank(b.base.severity) - severityRank(a.base.severity))
    .slice(0, THRESHOLDS.MAX_RECOMMENDATIONS)
    .map((r) => ({
      type: 'recommendation',
      title: r.title,
      description: r.description,
      metric: r.base.metric,
      value: r.base.value,
      comparison: r.base.comparison,
      severity: null,
      confidence: r.base.confidence,
    }));
}

function severityRank(sev) {
  return { alta: 3, media: 2, baixa: 1 }[sev] || 0;
}

/**
 * @param {object} normalizedSnapshot - saída de analyticsNormalizer.normalizeSnapshot()
 * @returns {import('./types').StructuredInsight[]}
 */
function generateInsights(normalizedSnapshot) {
  const generatedAt = new Date().toISOString();

  const base = RULES.flatMap((rule) => rule(normalizedSnapshot));
  const recommendations = deriveRecommendations(base);
  const all = [...base, ...recommendations];

  return all.map((insight) => ({
    id: nextId(insight.type),
    generatedAt,
    ...insight,
  }));
}

module.exports = { generateInsights, THRESHOLDS };
