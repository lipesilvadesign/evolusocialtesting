/**
 * AI Context Builder.
 *
 * Fluxo: Google Analytics → Analytics Service → Normalizer → Insights
 * Engine → AI Context Builder → AI Provider → Structured AI Response →
 * Insights UI. Este arquivo é o "AI Context Builder": puro, sem chamada de
 * rede, não conhece o provedor de IA nem a UI. Só pega o NormalizedSnapshot
 * (analyticsNormalizer) + os StructuredInsight já calculados pelo motor
 * determinístico (insightsEngine) e devolve um objeto compacto — a IA
 * nunca recebe o JSON bruto do Google, nunca acessa o Analytics ou o
 * banco diretamente, só o que este builder decidir repassar.
 *
 * Limites deliberados (evitar contexto desnecessário / custo de tokens):
 * até 5 páginas, 5 eventos, 5 fontes de tráfego, 10 insights determinísticos.
 */

const MAX_ITEMS = { pages: 5, events: 5, trafficSources: 5, insights: 10 };

function pickMetric(metrics, key, label) {
  const m = metrics[key];
  if (!m) return null;
  return { key, label, value: m.value, previousValue: m.previousValue, deltaPct: m.deltaPct };
}

/**
 * @param {object} normalizedSnapshot - saída de analyticsNormalizer.normalizeSnapshot()
 * @param {Array} deterministicInsights - saída de insightsEngine.generateInsights()
 * @param {object} [advancedIntelligence] - saída de intelligenceService.computeAdvancedIntelligence() (etapa "Inteligência Avançada") — opcional, mantém compatibilidade com quem já chamava sem esse parâmetro
 * @returns {object} AiContext — o único objeto que vai pro AI Provider
 */
function buildAiContext(normalizedSnapshot, deterministicInsights, advancedIntelligence) {
  const metrics = [
    pickMetric(normalizedSnapshot.metrics, 'activeUsers', 'Usuários ativos'),
    pickMetric(normalizedSnapshot.metrics, 'sessions', 'Sessões'),
    pickMetric(normalizedSnapshot.metrics, 'screenPageViews', 'Visualizações'),
    pickMetric(normalizedSnapshot.metrics, 'engagementRate', 'Taxa de engajamento (%)'),
    pickMetric(normalizedSnapshot.metrics, 'averageSessionDuration', 'Duração média da sessão (s)'),
  ].filter(Boolean);

  const pages = (normalizedSnapshot.pages || []).slice(0, MAX_ITEMS.pages).map((p) => ({
    path: p.path,
    title: p.title || p.path,
    views: p.views,
    previousViews: p.previousViews,
    deltaPct: p.deltaPct,
    eventsPerView: p.eventsPerView,
  }));

  const events = (normalizedSnapshot.events || []).slice(0, MAX_ITEMS.events).map((e) => ({
    name: e.name,
    count: e.count,
    previousCount: e.previousCount,
    deltaPct: e.deltaPct,
  }));

  const trafficSources = (normalizedSnapshot.trafficSources || []).slice(0, MAX_ITEMS.trafficSources).map((t) => ({
    channel: t.channel,
    sessions: t.sessions,
    previousSessions: t.previousSessions,
    deltaPct: t.deltaPct,
  }));

  const insights = (deterministicInsights || []).slice(0, MAX_ITEMS.insights).map((i) => ({
    type: i.type,
    title: i.title,
    description: i.description,
    metric: i.metric,
    value: i.value,
    comparison: i.comparison,
    confidence: i.confidence,
  }));

  return {
    rangeLabel: normalizedSnapshot.rangeLabel,
    hasComparison: normalizedSnapshot.hasComparison,
    avgEventsPerView: normalizedSnapshot.avgEventsPerView,
    metrics,
    pages,
    events,
    trafficSources,
    deterministicInsights: insights,
    ...(advancedIntelligence ? { advancedIntelligence: pickAdvancedIntelligence(advancedIntelligence) } : {}),
  };
}

/**
 * Recorte compacto da Inteligência Avançada — só o que a IA precisa pra
 * contextualizar (health score já com sub-notas explicadas, até 5
 * anomalias, até 5 correlações, até 5 oportunidades já priorizadas).
 * Nunca manda a série de 90 dias bruta nem o snapshot normalizado inteiro
 * de novo (já veio em `metrics`/`pages`/`events`/`trafficSources`).
 */
function pickAdvancedIntelligence(advancedIntelligence) {
  return {
    healthScore: advancedIntelligence.healthScore,
    anomalies: (advancedIntelligence.anomalies || []).slice(0, 5),
    correlations: (advancedIntelligence.correlations || []).slice(0, 5),
    topOpportunities: (advancedIntelligence.opportunities || []).slice(0, 5).map((o) => ({
      title: o.title,
      description: o.description,
      impact: o.impact,
      effort: o.effort,
      quadrant: o.quadrant,
    })),
    historicalAverages: advancedIntelligence.historicalAverages,
  };
}

/** Heurística simples: dá pra dizer "sem dados suficientes" sem nem chamar a IA (economiza custo). */
function hasEnoughDataForAi(normalizedSnapshot) {
  const activeUsers = normalizedSnapshot.metrics.activeUsers;
  if (!activeUsers) return false;
  return activeUsers.value >= 5; // limiar bem baixo — só evita chamar IA com site praticamente sem tráfego
}

module.exports = { buildAiContext, hasEnoughDataForAi, MAX_ITEMS };
