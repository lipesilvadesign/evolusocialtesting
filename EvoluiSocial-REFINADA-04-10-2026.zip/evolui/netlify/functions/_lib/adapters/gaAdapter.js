/**
 * Fluxo pedido: Google Analytics Response → Adapter → Analytics Service →
 * Domain Model → UI. Este arquivo é o Adapter — só entende o formato bruto
 * do Google (dimensionHeaders/metricHeaders/rows) e devolve algo neutro.
 * Quem monta os tipos de domínio (AnalyticsOverview, AnalyticsPage, etc.)
 * é o analyticsService, não este arquivo.
 */

/**
 * @param {object} raw - resposta bruta de runReport/runRealtimeReport
 * @returns {{ dimensionNames: string[], metricNames: string[], rows: Array<{dims: string[], metrics: number[]}>, rowCount: number }}
 */
function parseReport(raw) {
  const dimensionNames = (raw.dimensionHeaders || []).map((h) => h.name);
  const metricNames = (raw.metricHeaders || []).map((h) => h.name);
  const rows = (raw.rows || []).map((r) => ({
    dims: (r.dimensionValues || []).map((v) => v.value),
    metrics: (r.metricValues || []).map((v) => Number(v.value)),
  }));
  return { dimensionNames, metricNames, rows, rowCount: raw.rowCount || rows.length };
}

/** Pega o valor de uma métrica pelo nome, numa linha já parseada. */
function metricByName(parsed, row, name) {
  const idx = parsed.metricNames.indexOf(name);
  return idx === -1 ? 0 : row.metrics[idx];
}

/** Pega o valor de uma dimensão pelo nome, numa linha já parseada. */
function dimByName(parsed, row, name) {
  const idx = parsed.dimensionNames.indexOf(name);
  return idx === -1 ? '' : row.dims[idx];
}

module.exports = { parseReport, metricByName, dimByName };
