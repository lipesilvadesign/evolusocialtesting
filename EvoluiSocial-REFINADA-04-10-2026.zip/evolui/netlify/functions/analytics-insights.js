const { requireUser } = require('./_lib/config/authGuard');
const analyticsService = require('./_lib/services/analyticsService');
const { normalizeSnapshot } = require('./_lib/analyticsNormalizer');
const { generateInsights } = require('./_lib/insightsEngine');
const { AnalyticsError, toHttpStatus } = require('./_lib/errors/analyticsErrors');

// Etapa "Motor de Insights": substitui o mock da etapa anterior. Fluxo
// completo aqui dentro: analyticsService (busca) → analyticsNormalizer
// (casa período atual/anterior) → insightsEngine (regras determinísticas,
// SEM IA) → agrupamento por categoria → resposta pro painel.
const CATEGORY_ORDER = ['positive', 'attention', 'opportunity', 'trend', 'alert', 'recommendation'];

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') {
    return json(405, { error: 'Método não permitido.' });
  }

  const { error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    const rawSnapshot = await analyticsService.getInsightsSnapshot(query);
    const normalized = normalizeSnapshot(rawSnapshot);
    const insights = generateInsights(normalized);

    const byCategory = {};
    CATEGORY_ORDER.forEach((cat) => {
      byCategory[cat] = insights.filter((i) => i.type === cat);
    });

    return json(200, {
      rangeLabel: normalized.rangeLabel,
      hasComparison: normalized.hasComparison,
      generatedAt: insights[0]?.generatedAt || new Date().toISOString(),
      total: insights.length,
      byCategory,
      isEmpty: insights.length === 0,
    });
  } catch (err) {
    if (err instanceof AnalyticsError) {
      console.error('[analytics-insights] AnalyticsError:', err.code, err.detail);
      return json(toHttpStatus(err.code), { error: err.message, code: err.code });
    }
    console.error('[analytics-insights] erro inesperado:', err);
    return json(500, { error: 'Não foi possível gerar os insights.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
