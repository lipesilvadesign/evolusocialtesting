const { requireUser } = require('./_lib/config/authGuard');
const despesasService = require('./_lib/services/financeiroDespesasService');
const auditLog = require('./_lib/services/auditLogService');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      const despesas = await despesasService.list(token);
      return json(200, { despesas });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      const despesa = await despesasService.create(token, { ...payload, criadoPor: user.email });
      await auditLog.record(token, {
        actorId: user.email,
        action: 'create',
        targetType: 'despesa_financeiro',
        targetId: despesa.id,
        metadata: { categoria: despesa.categoria, valor: despesa.valor },
      });
      return json(201, { despesa });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const payload = JSON.parse(event.body || '{}');
      const despesa = await despesasService.update(token, query.id, payload);
      await auditLog.record(token, {
        actorId: user.email,
        action: 'status_change',
        targetType: 'despesa_financeiro',
        targetId: query.id,
        metadata: payload,
      });
      return json(200, { despesa });
    }

    if (event.httpMethod === 'DELETE') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await despesasService.remove(token, query.id);
      await auditLog.record(token, { actorId: user.email, action: 'delete', targetType: 'despesa_financeiro', targetId: query.id });
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return json(err.message && err.message.startsWith('Falha') ? 502 : 400, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
