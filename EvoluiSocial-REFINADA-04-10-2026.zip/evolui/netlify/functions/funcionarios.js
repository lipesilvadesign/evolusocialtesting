/**
 * Equipe/permissões — GET lista (RLS decide: admin vê todos, os demais só
 * a própria linha). PATCH ?id= atualiza um funcionário — usada tanto pela
 * tela Equipe (admin, qualquer funcionário) quanto pela página "Meu Perfil"
 * (qualquer funcionário, só a própria linha). Quem pode escrever o quê é
 * decidido no banco (RLS + trigger, ver SQL_FIX_completo_13_09.sql §4c),
 * não aqui — este handler não faz distinção nenhuma por payload.
 *
 * Convite de novo funcionário é OUTRA Function (funcionarios-convidar.js)
 * — precisa da service role key pra criar a conta no Supabase Auth, e por
 * isso fica isolada, com verificação de admin própria, nunca aqui.
 */

const { requireUser } = require('./_lib/config/authGuard');
const funcionariosService = require('./_lib/services/funcionariosService');
const auditLog = require('./_lib/services/auditLogService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      const funcionarios = await funcionariosService.listar(token);
      return json(200, { funcionarios });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const payload = JSON.parse(event.body || '{}');
      const funcionario = await funcionariosService.atualizar(token, query.id, payload);
      await auditLog.record(token, {
        actorId: user.email,
        action: 'permission_change',
        targetType: 'funcionario',
        targetId: query.id,
        metadata: payload,
      });
      return json(200, { funcionario });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('funcionarios', 'Falha na operação de funcionário', { message: err.message });
    return json(err.message.includes('permissão') ? 403 : 502, { error: err.message || 'Falha ao processar.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
