/**
 * Gera um RASCUNHO de diagnóstico por IA — não salva nada sozinho. O
 * front-end recebe o rascunho, o admin revisa/edita e só então salva pelo
 * fluxo normal (diagnosticos.js, já protegido por RLS pra admin).
 *
 * Verificação de admin EXPLÍCITA aqui (mesmo padrão de
 * funcionarios-convidar.js): gerar por IA custa dinheiro e precisa ficar
 * rastreável (admin_ai_usage) — não basta deixar a RLS de admin_diagnosticos
 * barrar só na hora de salvar, porque a CHAMADA à IA já teria acontecido e
 * já teria custado, sem registro de quem pediu.
 */

const { requireUser } = require('./_lib/config/authGuard');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./_lib/config/supabase');
const diagnosticoIaService = require('./_lib/services/diagnosticoIaService');
const { toHttpStatus } = require('./_lib/errors/aiErrors');
const logger = require('./_lib/logger');

// CORREÇÃO 29/09: filtra pela PRÓPRIA linha e exige ativo=true. Antes, um admin
// DESATIVADO ainda enxergava a própria linha role=admin e passava por aqui.
async function chamadorEhAdmin(token, userId) {
  if (!userId) return false;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/admin_funcionarios?select=role&id=eq.${encodeURIComponent(userId)}&role=eq.admin&ativo=eq.true`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
  });
  if (!res.ok) return false;
  return (await res.json()).length > 0;
}

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });

  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const souAdmin = await chamadorEhAdmin(token, user && user.id);
  if (!souAdmin) {
    logger.warn('diagnostico-ia', 'Tentativa de geração por não-admin', { actor: user.email });
    return json(403, { error: 'Só administradores podem gerar diagnóstico por IA.' });
  }

  try {
    const payload = JSON.parse(event.body || '{}');
    if (!payload.empresa) return json(400, { error: 'Informe "empresa".' });
    const rascunho = await diagnosticoIaService.gerarRascunho(payload, token, user.email);
    return json(200, { rascunho });
  } catch (err) {
    logger.error('diagnostico-ia', 'Falha ao gerar rascunho', { message: err.message, code: err.code });
    return json(toHttpStatus(err.code) || 502, { error: err.message || 'Falha ao gerar diagnóstico por IA.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
