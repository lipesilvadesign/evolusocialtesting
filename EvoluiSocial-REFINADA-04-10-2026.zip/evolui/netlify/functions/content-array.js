const { requireUser } = require('./_lib/config/authGuard');
const siteArrayService = require('./_lib/services/siteArrayService');
const auditLog = require('./_lib/services/auditLogService');

exports.handler = async function handler(event) {
  const type = (event.queryStringParameters || {}).type;
  if (!siteArrayService.TYPE_KEY[type]) {
    return json(400, { error: 'Parâmetro "type" inválido. Use "projetos", "servicos" ou "parceiros".' });
  }

  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const id = (event.queryStringParameters || {}).id;

  try {
    if (event.httpMethod === 'GET') {
      const items = await siteArrayService.list(token, type);
      return json(200, { items });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      const item = await siteArrayService.create(token, type, payload);
      await auditLog.record(token, { actorId: user.email, action: 'create', targetType: type, targetId: item.id });
      return json(201, { item });
    }

    if (event.httpMethod === 'PUT') {
      if (!id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const payload = JSON.parse(event.body || '{}');
      const item = await siteArrayService.update(token, type, id, payload);
      await auditLog.record(token, { actorId: user.email, action: 'update', targetType: type, targetId: id });
      return json(200, { item });
    }

    if (event.httpMethod === 'DELETE') {
      if (!id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await siteArrayService.remove(token, type, id);
      await auditLog.record(token, { actorId: user.email, action: 'delete', targetType: type, targetId: id });
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return json(500, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
