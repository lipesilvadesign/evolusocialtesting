const { requireUser } = require('./_lib/config/authGuard');
const collectionService = require('./_lib/services/collectionService');
const auditLog = require('./_lib/services/auditLogService');

const TYPE_TABLE = { posts: 'admin_posts', paginas: 'admin_pages' };

exports.handler = async function handler(event) {
  const type = (event.queryStringParameters || {}).type;
  const table = TYPE_TABLE[type];
  if (!table) {
    return json(400, { error: 'Parâmetro "type" inválido. Use "posts" ou "paginas".' });
  }

  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const id = (event.queryStringParameters || {}).id;

  try {
    if (event.httpMethod === 'GET') {
      const items = await collectionService.list(token, table);
      return json(200, { items });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      payload.criado_por = user.email;
      const item = await collectionService.create(token, table, payload);
      await auditLog.record(token, { actorId: user.email, action: 'create', targetType: type, targetId: item.id });
      return json(201, { item });
    }

    if (event.httpMethod === 'PUT') {
      if (!id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const payload = JSON.parse(event.body || '{}');
      const item = await collectionService.update(token, table, id, payload);
      await auditLog.record(token, { actorId: user.email, action: 'update', targetType: type, targetId: id });
      return json(200, { item });
    }

    if (event.httpMethod === 'DELETE') {
      if (!id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await collectionService.remove(token, table, id);
      await auditLog.record(token, { actorId: user.email, action: 'delete', targetType: type, targetId: id });
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return json(500, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
