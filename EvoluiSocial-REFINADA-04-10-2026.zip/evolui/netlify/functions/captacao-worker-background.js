/**
 * Lead Capture Engine — WORKER (Netlify Background Function, até 15 min).
 *
 * Só processa um job que JÁ foi validado e criado por captacao.js
 * (status 'na_fila'). Por isso o 202 imediato da plataforma não esconde
 * erro de validação: a validação aconteceu antes, na chamada síncrona.
 *
 * Reivindicação atômica: PATCH ... where status = 'na_fila' → 'em_andamento'.
 * Duas chamadas com o mesmo jobId → só uma processa (idempotente).
 *
 * Credencial:
 *  - com token de usuário: RLS vale (o dono do job, ou admin);
 *  - sem token: só jobs da ROTINA AGENDADA (criado_por_id nulo e método
 *    'sincronizacao_automatica'), com a service role — não há usuário num cron.
 *    Chamar sem token não dá acesso a mais nada: só processa um job que a
 *    própria rotina deixou na fila.
 */
const { requireUser } = require('./_lib/config/authGuard');
const { getServiceRoleKey } = require('./_lib/config/supabaseServiceRole');
const { rest } = require('./_lib/supabaseRest');
const pipeline = require('./_lib/captacao/pipeline');
const { criarDeps } = require('./_lib/captacao/deps');
const { ehUuid } = require('./_lib/captacao/acesso');
const logger = require('./_lib/logger');

async function processar(jobId, credencial, { soAgendado = false } = {}) {
  const filtroAgendado = soAgendado ? '&criado_por_id=is.null&metodo_captacao=eq.sincronizacao_automatica' : '';
  const { data } = await rest(credencial, `admin_prospeccao_buscas?id=eq.${jobId}&status=eq.na_fila&tipo=eq.pesquisa${filtroAgendado}`, {
    method: 'PATCH', prefer: 'return=representation', body: { status: 'em_andamento', etapa: 'coleta', updated_at: new Date().toISOString() },
  });
  const job = data && data[0];
  if (!job) return { ignorado: true };
  const deps = criarDeps(credencial);
  try {
    const r = await pipeline.executarPesquisa(job, deps);
    const m = r.metricas || {};
    logger.info('captacao-worker', 'Captação concluída', {
      evento: 'capture_job', jobId, status: r.status, encontrados: r.encontrados, gravados: r.gravados,
      total_ms: m.total_ms, coleta_ms: m.coleta_ms, dedup_ms: m.dedup_ms, gravacao_ms: m.gravacao_ms, enriquecimento_ms: m.enriquecimento_ms,
      providers: m.providers ? Object.fromEntries(Object.entries(m.providers).map(([k, v]) => [k, { duration_ms: v.duration_ms, resultados: v.resultados, erros: v.erros, cache: v.cache }])) : undefined,
    });
    return r;
  } catch (err) {
    if (err instanceof pipeline.JobCancelado) {
      logger.info('captacao-worker', 'Captação cancelada', { jobId });
      return { cancelado: true };
    }
    logger.error('captacao-worker', 'Falha na captação', { jobId, message: err.message });
    await deps.atualizarJob(jobId, { status: 'erro', etapa: null, mensagem_erro: String(err.message).slice(0, 500), finalizado_em: new Date().toISOString() }).catch(() => {});
    return { erro: err.message };
  }
}

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: '' };
  let body = {};
  try { body = JSON.parse(event.body || '{}'); } catch { return { statusCode: 400, body: '' }; }
  if (!ehUuid(body.jobId)) return { statusCode: 400, body: '' };

  const temToken = Boolean((event.headers.authorization || event.headers.Authorization || '').startsWith('Bearer '));
  if (temToken) {
    const { token, error } = await requireUser(event);
    if (error) return { statusCode: error.statusCode, body: '' };
    await processar(body.jobId, token);
  } else {
    const chave = getServiceRoleKey();
    if (!chave) return { statusCode: 200, body: '' };
    await processar(body.jobId, chave, { soAgendado: true });
  }
  return { statusCode: 200, body: '' };
};

exports._internos = { processar };
