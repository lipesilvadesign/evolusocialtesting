/**
 * Function PÚBLICA (sem login) — recebe a submissão do formulário de
 * /consultas, valida, gera o diagnóstico (ETAPA 3, motor determinístico,
 * nunca no navegador — assim o resultado salvo não pode ser adulterado
 * pelo visitante) e grava o lead no Supabase.
 *
 * Usa a MESMA chave anônima/publicável já usada em todo o projeto — nunca a
 * service role key (ver netlify/functions/_lib/config/supabaseServiceRole.js:
 * "NUNCA importar isto em código que atende requisição do frontend", e esta
 * Function atende exatamente isso). A tabela consultas_leads tem uma política
 * RLS específica que permite INSERT para o papel "anon" com os campos
 * administrativos travados no valor inicial — ver SQL_PENDENTE_consultas.sql.
 */

const { randomUUID } = require('crypto');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./_lib/config/supabase');
const { checkRateLimit } = require('./_lib/rateLimiter');
const { gerarDiagnostico, SEGMENTOS, OBJETIVOS } = require('./_lib/diagnosticoEngine');
const atividadesService = require('./_lib/services/consultasAtividadesService');
const logger = require('./_lib/logger');

const TABLE = 'consultas_leads';
const RATE_LIMIT = { max: 5, windowMs: 15 * 60 * 1000 }; // 5 envios / 15 min por IP

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}

function getClientIp(event) {
  const headers = event.headers || {};
  return (
    headers['x-nf-client-connection-ip'] ||
    (headers['x-forwarded-for'] || '').split(',')[0].trim() ||
    'desconhecido'
  );
}

function onlyDigits(str) {
  return String(str || '').replace(/\D/g, '');
}

function normalizarInstagram(raw) {
  return String(raw || '')
    .trim()
    .replace(/^@/, '')
    .replace(/^https?:\/\/(www\.)?instagram\.com\//i, '')
    .replace(/\/.*/, '')
    .trim();
}

function normalizarOrigem(raw) {
  const v = String(raw || '').trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
  return v ? v.slice(0, 60) : 'consultas_site';
}

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'JSON inválido.' });
  }

  // Honeypot: campo escondido no formulário (nenhuma pessoa real preenche;
  // um bot preenchendo automaticamente qualquer campo, sim). Resposta
  // "sucesso" silenciosa, sem gravar nada — mesmo padrão do campo "company"
  // escondido no formulário de contato da home (assets/js/site.bdacb7b1a8.js).
  if (payload.website) {
    return json(201, { leadId: null, resultado: null });
  }

  const ip = getClientIp(event);
  const { allowed, retryAfterMs } = checkRateLimit(`consultas-criar:${ip}`, RATE_LIMIT);
  if (!allowed) {
    return json(429, {
      error: 'Muitas solicitações em pouco tempo. Aguarde alguns minutos e tente novamente.',
      retryAfterMs,
    });
  }

  const nome = String(payload.nome || '').trim().slice(0, 120);
  const instagram = normalizarInstagram(payload.instagram).slice(0, 60);
  const whatsappDigits = onlyDigits(payload.whatsapp);
  const email = String(payload.email || '').trim().slice(0, 180);
  const segmento = Object.prototype.hasOwnProperty.call(SEGMENTOS, payload.segmento) ? payload.segmento : null;
  const objetivo = Object.prototype.hasOwnProperty.call(OBJETIVOS, payload.objetivo) ? payload.objetivo : null;
  const origem = normalizarOrigem(payload.origem);

  const erros = {};
  if (nome.length < 2) erros.nome = 'Digite seu nome.';
  if (!/^[a-zA-Z0-9._]{1,30}$/.test(instagram)) erros.instagram = 'Digite um @ do Instagram válido.';
  if (whatsappDigits.length < 10) erros.whatsapp = 'Digite um WhatsApp válido, com DDD.';
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) erros.email = 'Digite um e-mail válido ou deixe em branco.';
  if (!segmento) erros.segmento = 'Selecione o segmento do seu negócio.';
  if (!objetivo) erros.objetivo = 'Selecione o objetivo principal.';

  if (Object.keys(erros).length) return json(400, { error: 'Alguns campos precisam de atenção.', campos: erros });

  const resultado = gerarDiagnostico({ nome, instagram, segmento, objetivo });
  const agora = new Date().toISOString();

  // Gera o id aqui (em vez de deixar o Postgres gerar e pedir o registro de
  // volta com "Prefer: return=representation") de propósito: o visitante
  // anônimo não tem — nem deveria ter — política de SELECT em
  // consultas_leads (ele nunca deve conseguir ler consultorias de outras
  // pessoas). Só que um RETURNING/"return=representation" depois de um
  // INSERT também exige visibilidade via política de SELECT, mesmo já
  // tendo passado pela política de INSERT — comportamento documentado do
  // Postgres RLS, não um bug do Supabase. Sem uma política de SELECT pra
  // anon, isso derruba a gravação com o mesmo erro genérico de "violates
  // row-level security policy", mesmo com a política de INSERT 100%
  // correta (foi exatamente o que aconteceu na primeira consultoria real).
  // Gerando o id aqui e usando "return=minimal", a gravação nunca precisa
  // dessa leitura de volta — não precisamos abrir uma política de SELECT
  // só pra isso.
  const leadId = randomUUID();

  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        Prefer: 'return=minimal',
      },
      body: JSON.stringify({
        id: leadId,
        nome,
        instagram,
        whatsapp: whatsappDigits,
        email: email || null,
        segmento,
        objetivo,
        origem,
        resultado_analise: resultado,
        resultado_gerado_em: agora,
        consultoria_concluida_em: agora,
      }),
    });

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      logger.error('consultas-criar', 'Falha ao inserir lead', { status: res.status });
      logger.error('consultas-criar', 'Detalhe do banco', { detalhe: text.slice(0, 300) }); // CORREÇÃO 29/09: detalhe só no log, nunca para o visitante
      return json(502, { error: 'Não foi possível salvar sua consultoria agora. Tente novamente em instantes.' });
    }

    // Registro de atividade não deve derrubar a resposta principal caso falhe.
    try {
      await atividadesService.criar(SUPABASE_ANON_KEY, { leadId, tipo: 'analise_concluida', descricao: 'Diagnóstico gerado automaticamente na submissão do formulário.' });
    } catch (err) {
      logger.warn('consultas-criar', 'Falha ao registrar atividade analise_concluida', { message: err.message });
    }

    return json(201, { leadId, resultado });
  } catch (err) {
    logger.error('consultas-criar', 'Erro inesperado', { message: err.message });
    return json(500, { error: 'Erro inesperado ao salvar sua consultoria. Tente novamente em instantes.' });
  }
};
