/**
 * Function PÚBLICA (sem login) — registra, no MESMO lead que o visitante
 * acabou de criar em /consultas, o clique num dos 3 CTAs da tela de
 * resultado (ETAPA 4: Falar com Felipe / Agendar uma conversa / Ver
 * Instagram). Nunca lê e nunca altera nenhum outro campo — proteção dupla
 * (GRANT de coluna + RLS) documentada em SQL_PENDENTE_consultas.sql, política
 * anon_update_evento_consultas_leads.
 *
 * Chamada em "fire-and-forget" pelo navegador no instante do clique — o link
 * (wa.me/instagram.com/agenda) já abre em paralelo, o registro do evento
 * nunca atrasa nem bloqueia a navegação do visitante.
 */

const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./_lib/config/supabase');
const { checkRateLimit } = require('./_lib/rateLimiter');
const atividadesService = require('./_lib/services/consultasAtividadesService');
const logger = require('./_lib/logger');

const TABLE = 'consultas_leads';
const RATE_LIMIT = { max: 30, windowMs: 10 * 60 * 1000 };

const EVENTO_PARA_CTA = {
  cta_whatsapp: 'whatsapp',
  cta_agendamento: 'agendamento',
  cta_instagram: 'instagram',
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}

function getClientIp(event) {
  const headers = event.headers || {};
  return (
    headers['x-nf-client-connection-ip'] ||
    (headers['x-forwarded-for'] || '').split(',')[0].trim() ||
    'desconhecido'
  );
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'JSON inválido.' });
  }

  const { leadId, evento } = payload;
  if (!leadId || !UUID_RE.test(leadId)) return json(400, { error: 'leadId inválido.' });
  if (!Object.prototype.hasOwnProperty.call(EVENTO_PARA_CTA, evento)) return json(400, { error: 'evento inválido.' });

  const ip = getClientIp(event);
  const { allowed } = checkRateLimit(`consultas-evento:${ip}`, RATE_LIMIT);
  if (!allowed) return json(429, { error: 'Muitas requisições — tente novamente em instantes.' });

  // CORREÇÃO 29/09: antes era um PATCH com ?id=eq. usando a chave anon — como
  // anon não tem política de SELECT, o Postgres filtrava 0 linhas e o clique
  // NUNCA era gravado no lead (resposta 204 mesmo assim). Agora chama a
  // função consulta_registrar_cta (SQL_CORRECAO_SEGURANCA_29_09.sql), que só
  // altera as colunas de CTA daquela linha.
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/consulta_registrar_cta`, {
      method: 'POST',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ p_lead_id: leadId, p_evento: evento }),
    });
    if (!res.ok) {
      logger.warn('consultas-evento', 'Falha ao registrar evento de CTA', { status: res.status, evento });
      return json(200, { ok: false }); // nunca quebra a navegação do visitante por causa de telemetria
    }
    const registrado = await res.json().catch(() => false);
    if (registrado !== true) {
      logger.warn('consultas-evento', 'Lead não encontrado (ou antigo demais) para registrar CTA', { evento });
      return json(200, { ok: false });
    }
  } catch (err) {
    logger.warn('consultas-evento', 'Erro ao registrar evento de CTA', { message: err.message });
    return json(200, { ok: false });
  }

  try {
    await atividadesService.criar(SUPABASE_ANON_KEY, { leadId, tipo: evento, descricao: null });
  } catch (err) {
    logger.warn('consultas-evento', 'Falha ao registrar atividade de evento', { message: err.message });
  }

  return json(200, { ok: true });
};
