/**
 * Gerenciamento de contas (pedido do Felipe, 13/09) — ações administrativas
 * que "atualizar()" em funcionariosService.js não cobre porque exigem
 * privilégio de admin do Supabase Auth (não dá pra fazer com RLS/token
 * normal). Mesmo padrão de segurança de funcionarios-convidar.js:
 *
 * 1. requireUser() — sessão válida.
 * 2. Confirma que quem chamou é admin, usando o TOKEN NORMAL dele (RLS de
 *    verdade em admin_funcionarios) — antes de tocar na service role key.
 * 3. Só então a service role key age.
 *
 * Duas ações (body.acao):
 * - 'resetar_senha': gera uma nova senha temporária pra conta já existente
 *   e devolve na resposta desta chamada, uma única vez (mesmíssima regra
 *   de "gerar_senha" em funcionarios-convidar.js — nunca fica salva em
 *   lugar nenhum).
 * - 'excluir': apaga a conta de verdade do Supabase Auth. admin_funcionarios
 *   tem "references auth.users(id) on delete cascade" — a linha do
 *   funcionário (e tudo que referencia ela) some junto, sem precisar
 *   apagar em duas etapas.
 *
 * Nenhuma das duas ações permite alvo = o próprio chamador — evita um
 * admin se travar fora da própria conta sem querer.
 */

const { requireUser } = require('./_lib/config/authGuard');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./_lib/config/supabase');
const { getServiceRoleKey } = require('./_lib/config/supabaseServiceRole');
const { gerarSenhaTemporaria } = require('./_lib/util/senha');
const auditLog = require('./_lib/services/auditLogService');
const logger = require('./_lib/logger');

// CORREÇÃO 29/09: filtra pela PRÓPRIA linha e exige ativo=true. Antes, um admin
// DESATIVADO ainda enxergava a própria linha role=admin e passava por aqui.
async function chamadorEhAdmin(token, userId) {
  if (!userId) return false;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/admin_funcionarios?select=role&id=eq.${encodeURIComponent(userId)}&role=eq.admin&ativo=eq.true`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
  });
  if (!res.ok) return false;
  const rows = await res.json();
  return rows.length > 0;
}

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });

  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const souAdmin = await chamadorEhAdmin(token, user && user.id);
  if (!souAdmin) {
    logger.warn('funcionarios-conta', 'Tentativa de gerenciar conta por não-admin', { actor: user.email });
    return json(403, { error: 'Só administradores podem gerenciar contas.' });
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Corpo da requisição inválido.' });
  }
  const { acao, funcionarioId } = payload;
  if (!funcionarioId) return json(400, { error: 'Informe "funcionarioId".' });
  if (!['resetar_senha', 'excluir'].includes(acao)) return json(400, { error: `Ação inválida: ${acao}` });
  if (funcionarioId === user.id) {
    return json(400, { error: 'Você não pode fazer isso na própria conta.' });
  }

  const serviceRoleKey = getServiceRoleKey();
  if (!serviceRoleKey) {
    return json(500, { error: 'SUPABASE_SERVICE_ROLE_KEY não configurada. Ver Netlify → Site settings → Environment variables.' });
  }

  try {
    if (acao === 'resetar_senha') {
      const senhaGerada = gerarSenhaTemporaria();
      const res = await fetch(`${SUPABASE_URL}/auth/v1/admin/users/${encodeURIComponent(funcionarioId)}`, {
        method: 'PUT',
        headers: { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: senhaGerada }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) return json(res.status, { error: body.msg || body.error_description || 'Falha ao redefinir senha.' });

      await auditLog.record(token, {
        actorId: user.email,
        action: 'permission_change',
        targetType: 'funcionario',
        targetId: funcionarioId,
        metadata: { acao: 'senha_redefinida' },
      });
      return json(200, { senhaGerada });
    }

    // acao === 'excluir'
    const res = await fetch(`${SUPABASE_URL}/auth/v1/admin/users/${encodeURIComponent(funcionarioId)}`, {
      method: 'DELETE',
      headers: { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` },
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      return json(res.status, { error: body.msg || body.error_description || 'Falha ao excluir conta.' });
    }

    await auditLog.record(token, {
      actorId: user.email,
      action: 'permission_change',
      targetType: 'funcionario',
      targetId: funcionarioId,
      metadata: { acao: 'conta_excluida' },
    });
    return json(200, { ok: true });
  } catch (err) {
    logger.error('funcionarios-conta', 'Falha ao gerenciar conta', { message: err.message, acao });
    return json(502, { error: err.message || 'Falha ao processar.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
