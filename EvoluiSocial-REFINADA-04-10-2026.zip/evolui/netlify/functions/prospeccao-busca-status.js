/**
 * Consulta o progresso de uma busca manual em andamento (aba Prospecção,
 * botão "Atualizar"). Function síncrona normal — só lê uma linha, é rápido.
 * O painel chama isto a cada ~2s enquanto o popup de busca está aberto.
 */

const { requireUser } = require('./_lib/config/authGuard');
const buscaStatusService = require('./_lib/services/buscaStatusService');

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Método não permitido.' });

  const { token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const id = (event.queryStringParameters || {}).id;
  if (!id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });

  try {
    const busca = await buscaStatusService.buscarPorId(token, id);
    // null é uma resposta válida aqui: a Background Function pode ainda não
    // ter criado a linha (race condition normal, a interface tenta de novo).
    return json(200, { busca });
  } catch (err) {
    return json(502, { error: err.message || 'Falha ao consultar progresso.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
