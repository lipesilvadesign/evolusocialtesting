/**
 * Ponto (Início) — GET retorna os registros + resumo (dias/horas) do
 * período pedido; POST registra um evento novo (entrada/saída) da PRÓPRIA
 * pessoa logada.
 *
 * ?funcionarioId= é opcional e só tem efeito de verdade quando quem chama é
 * admin (RLS de admin_ponto_registros barra qualquer outro papel de ver
 * ponto alheio — isto aqui só repassa o parâmetro, a barreira real está no
 * banco).
 */
const { requireUser } = require('./_lib/config/authGuard');
const pontoService = require('./_lib/services/pontoService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      if (!query.inicio || !query.fim) return json(400, { error: 'Informe "inicio" e "fim" (ISO 8601).' });
      const registros = await pontoService.listar(token, { funcionarioId: query.funcionarioId, inicio: query.inicio, fim: query.fim });
      const resumo = pontoService.calcularResumo(registros);
      return json(200, { registros, resumo });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      if (!payload.tipo) return json(400, { error: 'Informe "tipo" ("entrada" ou "saida").' });
      const registro = await pontoService.registrar(token, user.id, payload.tipo);
      return json(201, { registro });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('ponto', 'Falha na operação de ponto', { message: err.message });
    return json(502, { error: err.message || 'Falha ao processar ponto.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
