const { requireUser } = require('./_lib/config/authGuard');
const notificationsService = require('./_lib/services/notificationsService');

exports.handler = async function handler(event) {
  const { token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      const notifications = await notificationsService.list(token, { onlyUnread: query.unread === 'true' });
      return json(200, { notifications });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await notificationsService.markRead(token, query.id);
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return json(500, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
