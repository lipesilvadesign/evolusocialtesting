const { requireUser } = require('./_lib/config/authGuard');
const contratosService = require('./_lib/services/financeiroContratosService');
const parcelasService = require('./_lib/services/financeiroParcelasService');
const auditLog = require('./_lib/services/auditLogService');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });
  // Sem checagem de papel aqui (mesmo padrão de tasks.js/funcionarios.js) —
  // quem decide de verdade é a RLS (admin_eh_admin(), ver
  // SQL_PENDENTE_financeiro.sql): o papel real vive em admin_funcionarios,
  // não no JWT, então checar "de novo" aqui só duplicaria a mesma regra sem
  // poder aplicá-la corretamente. Um não-admin recebe erro do Postgres
  // (capturado abaixo) em vez de dado nenhum.

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      const contratos = await contratosService.list(token);
      return json(200, { contratos });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      const contrato = await contratosService.create(token, { ...payload, criadoPor: user.email });
      const parcelas = await parcelasService.gerarParaContrato(token, contrato);
      await auditLog.record(token, {
        actorId: user.email,
        action: 'create',
        targetType: 'contrato_financeiro',
        targetId: contrato.id,
        metadata: { leadId: contrato.lead_id, valorTotal: contrato.valor_total, numeroParcelas: parcelas.length },
      });
      return json(201, { contrato, parcelas });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const payload = JSON.parse(event.body || '{}');
      const contrato = await contratosService.update(token, query.id, payload);
      await auditLog.record(token, {
        actorId: user.email,
        action: 'status_change',
        targetType: 'contrato_financeiro',
        targetId: query.id,
        metadata: payload,
      });
      return json(200, { contrato });
    }

    if (event.httpMethod === 'DELETE') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await contratosService.remove(token, query.id);
      await auditLog.record(token, { actorId: user.email, action: 'delete', targetType: 'contrato_financeiro', targetId: query.id });
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return json(err.message && err.message.startsWith('Falha') ? 502 : 400, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
