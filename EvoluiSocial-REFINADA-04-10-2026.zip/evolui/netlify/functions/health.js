const { requireUser } = require('./_lib/config/authGuard');
const { SUPABASE_URL, SUPABASE_ANON_KEY } = require('./_lib/config/supabase');
const { env } = require('./_lib/config/env');
const logger = require('./_lib/logger');

const TIMEOUT_MS = 8000;

async function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error('timeout')), ms);
  });
  try {
    return await Promise.race([promise, timeout]);
  } finally {
    clearTimeout(timer);
  }
}

async function checkSupabase() {
  const start = Date.now();
  try {
    const res = await withTimeout(
      fetch(`${SUPABASE_URL}/rest/v1/site_content?select=id&limit=1`, {
        headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` },
      }),
      TIMEOUT_MS
    );
    return { name: 'Supabase', ok: res.ok, latencyMs: Date.now() - start, detail: res.ok ? null : `HTTP ${res.status}` };
  } catch (err) {
    return { name: 'Supabase', ok: false, latencyMs: Date.now() - start, detail: err.message };
  }
}

/** Não chama a API da Anthropic (custaria dinheiro a cada health check) — só confirma que a credencial existe. */
function checkAiCredentials() {
  const hasKey = Boolean(env.ai.apiKey());
  return {
    name: 'IA (Anthropic)',
    ok: hasKey,
    latencyMs: 0,
    detail: hasKey
      ? 'Credencial presente (não testada em tempo real — evita custo a cada check).'
      : 'AI_API_KEY não configurada.',
  };
}

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Método não permitido.' });

  const { error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const supabase = await checkSupabase();
  const ai = checkAiCredentials();
  const services = [supabase, ai];
  const allOk = services.every((s) => s.ok);

  services.filter((s) => !s.ok).forEach((s) => logger.warn('health', `Serviço com problema: ${s.name}`, { detail: s.detail }));

  return json(200, { status: allOk ? 'ok' : 'degraded', checkedAt: new Date().toISOString(), services });
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
