const { requireUser } = require('./_lib/config/authGuard');
const settingsService = require('./_lib/services/settingsService');
const auditLog = require('./_lib/services/auditLogService');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  try {
    if (event.httpMethod === 'GET') {
      const settings = await settingsService.get(token);
      return json(200, { settings });
    }

    if (event.httpMethod === 'PUT') {
      const partial = JSON.parse(event.body || '{}');
      const settings = await settingsService.update(token, partial);
      await auditLog.record(token, {
        actorId: user.email,
        action: 'settings_change',
        targetType: 'settings',
        metadata: { sections: Object.keys(partial) },
      });
      return json(200, { settings });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return json(500, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
