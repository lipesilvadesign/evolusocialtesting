/**
 * Leitura PÚBLICA de uma apresentação, por slug — SEM autenticação, usada
 * pela página /apresentacao/[slug] (apresentacao.html).
 *
 * Isolamento de segurança deliberado:
 * - Não importa authGuard.js (não exige nem valida sessão) — é pública por
 *   natureza, igual a consultas-criar.js.
 * - Nunca consulta admin_prospeccao_leads, admin_briefings, admin_metricas
 *   ou admin_diagnosticos diretamente — só admin_apresentacoes, que guarda
 *   um SNAPSHOT já curado (ver SQL_PENDENTE_apresentacoes.sql). Mesmo que
 *   esta Function tivesse um bug, o pior caso é vazar o conteúdo de uma
 *   apresentação JÁ PUBLICADA — nunca dado interno/rascunho de outro cliente.
 * - Só devolve status='publicado' (reforçado tanto aqui quanto na RLS da
 *   tabela — dupla camada, mesmo padrão usado no resto do projeto).
 */

const apresentacoesService = require('./_lib/services/apresentacoesService');
const logger = require('./_lib/logger');
const flags = require('./_lib/captacao/flags');

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Método não permitido.' });

  const slug = String((event.queryStringParameters || {}).slug || '').trim();
  // slug só com o formato que o painel gera (slugify) — evita consulta com lixo
  if (!slug) return json(400, { error: 'Parâmetro "slug" é obrigatório.' }, { cache: false });
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 120) return json(404, { error: 'Apresentação não encontrada.' }, { cache: false });

  try {
    const apresentacao = await apresentacoesService.obterPublicaPorSlug(slug);
    // 404 sem cache: um link publicado logo depois de alguém abrir não fica "não encontrado" por 30 s
    if (!apresentacao) return json(404, { error: 'Apresentação não encontrada.' }, { cache: false });
    return json(200, { apresentacao, recursos: { novoPdf: flags.ligada('ENABLE_NEW_PDF_ENGINE') } });
  } catch (err) {
    logger.error('apresentacao-publica', 'Falha ao buscar apresentação pública', { message: err.message });
    return json(502, { error: 'Falha ao carregar a apresentação.' }, { cache: false });
  }
};

function json(statusCode, body, { cache = true } = {}) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      // Cacheável por pouco tempo no CDN — reduz carga sem atrasar a
      // publicação de uma nova versão por mais que alguns segundos.
      'Cache-Control': cache ? 'public, max-age=30' : 'no-store',
      'X-Robots-Tag': 'noindex, nofollow',
    },
    body: JSON.stringify(body),
  };
}
