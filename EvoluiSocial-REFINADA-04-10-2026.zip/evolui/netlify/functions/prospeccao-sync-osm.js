/**
 * Captação semanal automática (Netlify Scheduled Function, @weekly).
 *
 * 30/09 (Lead Capture Engine): NÃO insere mais nada direto no CRM. Cria um
 * job de captação (tipo pesquisa, método 'sincronizacao_automatica', fonte
 * OpenStreetMap) para os setores estratégicos em Petrolina e Juazeiro (raio
 * 30 km) e dispara o worker. O resultado fica na CAPTURA, deduplicado
 * (inclusive contra leads arquivados), com opt-out aplicado, esperando
 * revisão humana em Prospecção → Captação. Nunca apaga nada.
 *
 * Service role: não existe usuário num cron. Usada só para criar o job e
 * notificar; o worker grava apenas na captura.
 * Se a URL do site não estiver disponível no ambiente (process.env.URL), o
 * job fica "na fila" e um admin processa pelo painel.
 */
const crypto = require('crypto');
const { getServiceRoleKey } = require('./_lib/config/supabaseServiceRole');
const { rest } = require('./_lib/supabaseRest');
const taxonomia = require('./_lib/captacao/taxonomia');
const notificationsService = require('./_lib/services/notificationsService');
const logger = require('./_lib/logger');

const CIDADES = ['Petrolina, PE', 'Juazeiro, BA'];
const RAIO_KM = 30;

function montarJob(agora = new Date()) {
  const setores = taxonomia.SETORES.filter((s) => s.estrategico).map((s) => s.id);
  return {
    id: crypto.randomUUID(), tipo: 'pesquisa', status: 'na_fila', metodo_captacao: 'sincronizacao_automatica', fonte: 'osm',
    providers: ['overpass'], cidades: CIDADES, ramo: 'Setores estratégicos (automático)', criado_por: 'sistema', criado_por_id: null,
    campanha: `sync_semanal_${agora.toISOString().slice(0, 10).replace(/-/g, '')}`,
    parametros: { setor: setores[0], setores, cidades: CIDADES, raioKm: RAIO_KM }, progresso: [],
  };
}

exports.handler = async function handler() {
  const chave = getServiceRoleKey();
  if (!chave) {
    logger.warn('prospeccao-sync-osm', 'SUPABASE_SERVICE_ROLE_KEY ausente — captação semanal não executada.');
    return { statusCode: 200, body: 'skipped' };
  }
  try {
    const job = montarJob();
    await rest(chave, 'admin_prospeccao_buscas', { method: 'POST', body: job, prefer: 'return=minimal' });
    const base = process.env.URL || process.env.DEPLOY_PRIME_URL || process.env.DEPLOY_URL;
    let disparado = false;
    if (base) {
      const res = await fetch(`${base}/.netlify/functions/captacao-worker-background`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jobId: job.id }),
      }).catch((err) => ({ ok: false, status: err.message }));
      disparado = Boolean(res && (res.ok || res.status === 202));
    }
    await notificationsService.create(chave, {
      tipo: 'oportunidade',
      titulo: 'Captação semanal iniciada',
      mensagem: disparado
        ? 'A busca semanal (OpenStreetMap, setores estratégicos, Petrolina e Juazeiro) está rodando. Os resultados aparecem em Prospecção → Captação para revisão — nada entra no CRM sem aprovação.'
        : 'A captação semanal foi criada mas ficou na fila (não foi possível disparar o processamento automaticamente). Abra Prospecção → Captação e clique em "Processar".',
      severidade: 'baixa',
      metadata: { jobId: job.id, rota: `#/prospeccao/captacao/${job.id}` },
    });
    return { statusCode: 200, body: `ok: job ${job.id}${disparado ? '' : ' (na fila)'}` };
  } catch (err) {
    logger.error('prospeccao-sync-osm', 'Falha ao criar captação semanal', { message: err.message });
    return { statusCode: 200, body: 'error handled' };
  }
};

exports._internos = { montarJob };
