/**
 * Function PÚBLICA (sem login) — recebe o formulário "Vamos conversar" da
 * home, grava em site_contatos e manda o aviso por e-mail para
 * CONTATO_EMAIL_DESTINO, ou a própria caixa do UMBLER_SMTP_USER (marketing@).
 *
 * Ordem pensada para NUNCA perder um contato:
 *   1. grava no banco (o trigger já cria a notificação no sino do painel);
 *   2. tenta o e-mail (limite de 6 s — a Function síncrona tem 10 s);
 *   3. registra o resultado; se falhou, o job de hora em hora tenta de novo.
 * Se o passo 2 ou 3 falhar, o visitante recebe sucesso do mesmo jeito — o
 * contato já está salvo no painel.
 *
 * Usa só a chave anônima (mesmo padrão de consultas-criar.js); nunca a
 * service role key.
 */

const { randomUUID } = require('crypto');
const { checkRateLimit } = require('./_lib/rateLimiter');
const contatos = require('./_lib/services/siteContatosService');
const logger = require('./_lib/logger');

const RATE_LIMIT = { max: 5, windowMs: 15 * 60 * 1000 }; // 5 envios / 15 min por IP
const EMAIL_TIMEOUT_MS = 6000;

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}

function getClientIp(event) {
  const h = event.headers || {};
  return h['x-nf-client-connection-ip'] || (h['x-forwarded-for'] || '').split(',')[0].trim() || 'desconhecido';
}

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'JSON inválido.' });
  }
  if (!payload || typeof payload !== 'object') return json(400, { error: 'JSON inválido.' });

  // Honeypot (campo escondido fb_hp_campo_vazio na home): sucesso silencioso.
  if (payload.fb_hp_campo_vazio) return json(201, { ok: true });

  const { allowed, retryAfterMs } = checkRateLimit(`contato-criar:${getClientIp(event)}`, RATE_LIMIT);
  if (!allowed) {
    return json(429, { error: 'Muitas mensagens em pouco tempo. Aguarde alguns minutos ou fale pelo WhatsApp.', retryAfterMs });
  }

  const { dados, erros } = contatos.validar(payload);
  if (erros) return json(400, { error: 'Alguns campos precisam de atenção.', campos: erros });

  const id = randomUUID();
  try {
    await contatos.criarPublico(id, dados);
  } catch (err) {
    logger.error('contato-criar', 'Falha ao gravar contato', { message: err.message, detalhe: err.detalhe });
    return json(502, { error: 'Não conseguimos registrar sua mensagem agora. Continue pelo WhatsApp que a gente responde por lá.' });
  }

  const resultado = await contatos.enviarAviso({ ...dados, created_at: new Date().toISOString() }, { timeoutMs: EMAIL_TIMEOUT_MS });
  if (resultado.status !== 'enviado') {
    logger.warn('contato-criar', 'Aviso por e-mail não saiu — o job agendado vai tentar de novo', { status: resultado.status, erro: resultado.erro });
  }
  try {
    await contatos.registrarAvisoInicial(id, resultado);
  } catch (err) {
    logger.warn('contato-criar', 'Falha ao registrar resultado do e-mail', { message: err.message });
  }

  return json(201, { ok: true });
};
