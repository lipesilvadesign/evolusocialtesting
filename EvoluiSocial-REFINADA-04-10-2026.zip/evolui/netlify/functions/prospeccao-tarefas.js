/**
 * Próxima ação / tarefas de um lead + histórico de score (Fase 3, migration 013).
 *
 *   GET   ?leadId=          → { tarefas, historico }   (RLS: só quem vê o lead)
 *   POST  { leadId, tipo, descricao, data, responsavelId? }   cria tarefa (aberta)
 *   PATCH ?id=  { status: 'concluida' | 'cancelada' | 'aberta' }
 *
 * Regras críticas ficam no BANCO (não aqui): responsável válido, prospecção só
 * cria/edita tarefa própria, lead/criador imutáveis, "próxima ação" do lead
 * recalculada por trigger. Tarefa não é apagada: é cancelada (histórico).
 */
const { exigirOperador, json, lerCorpo, ehUuid, respostaErro } = require('./_lib/captacao/acesso');
const { rest } = require('./_lib/supabaseRest');

const TIPOS = ['ligar', 'whatsapp', 'email', 'reuniao', 'enviar_diagnostico', 'enviar_proposta', 'follow_up', 'outro'];

exports.handler = async function handler(event) {
  const ctx = await exigirOperador(event, { chave: 'prospeccao-tarefas', limite: { max: 60, windowMs: 60 * 1000 } });
  if (ctx.resposta) return ctx.resposta;
  const { user, token, ehAdmin } = ctx;
  const q = event.queryStringParameters || {};
  try {
    if (event.httpMethod === 'GET') {
      if (!ehUuid(q.leadId)) return json(400, { error: 'Lead inválido.' });
      const [t, h] = await Promise.all([
        rest(token, `admin_prospeccao_tarefas?lead_id=eq.${q.leadId}&select=id,tipo,descricao,data,status,responsavel_id,created_at,completed_at&order=status.asc,data.asc&limit=50`),
        rest(token, `admin_prospeccao_score_historico?lead_id=eq.${q.leadId}&select=score_anterior,score_novo,entrou,saiu,origem,criado_em&order=criado_em.desc&limit=10`),
      ]);
      return json(200, { tarefas: t.data || [], historico: h.data || [] });
    }
    if (event.httpMethod === 'POST') {
      const b = lerCorpo(event);
      if (!b || !ehUuid(b.leadId)) return json(400, { error: 'Lead inválido.' });
      if (!TIPOS.includes(b.tipo)) return json(400, { error: 'Escolha o tipo da ação.' });
      const descricao = String(b.descricao || '').trim().slice(0, 300);
      if (descricao.length < 2) return json(400, { error: 'Descreva a próxima ação.' });
      const data = new Date(b.data);
      if (!b.data || Number.isNaN(data.getTime())) return json(400, { error: 'Informe a data da ação.' });
      // responsável: o banco valida; prospecção não escolhe outra pessoa (nem adianta mandar)
      const responsavelId = ehAdmin && ehUuid(b.responsavelId) ? b.responsavelId : (ehAdmin ? undefined : user.id);
      const { data: rows } = await rest(token, 'admin_prospeccao_tarefas', {
        method: 'POST', prefer: 'return=representation',
        body: { lead_id: b.leadId, tipo: b.tipo, descricao, data: data.toISOString(), ...(responsavelId ? { responsavel_id: responsavelId } : {}) },
      });
      return json(201, { tarefa: rows && rows[0] });
    }
    if (event.httpMethod === 'PATCH') {
      const b = lerCorpo(event);
      if (!ehUuid(q.id)) return json(400, { error: 'Tarefa inválida.' });
      if (!b || !['aberta', 'concluida', 'cancelada'].includes(b.status)) return json(400, { error: 'Situação inválida.' });
      const { data: rows } = await rest(token, `admin_prospeccao_tarefas?id=eq.${q.id}`, { method: 'PATCH', prefer: 'return=representation', body: { status: b.status } });
      if (!rows || !rows.length) return json(404, { error: 'Tarefa não encontrada.' });
      return json(200, { tarefa: rows[0] });
    }
    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return respostaErro(err);
  }
};
