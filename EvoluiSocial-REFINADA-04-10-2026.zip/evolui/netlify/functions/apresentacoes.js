/**
 * Apresentação do cliente — versionada, gerenciada pelo painel (autenticado).
 * GET ?leadId=                lista todas as versões
 * POST ?leadId=&nome=Empresa  cria nova versão (rascunho)
 * PATCH ?id=                  atualiza conteúdo/tema de uma versão em rascunho
 * PATCH ?id=&acao=publicar    publica a versão
 *
 * A leitura PÚBLICA (sem login, pela página /apresentacao/[slug]) é outra
 * Function: apresentacao-publica.js — nunca esta aqui.
 */

const { requireUser } = require('./_lib/config/authGuard');
const apresentacoesService = require('./_lib/services/apresentacoesService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      if (!query.leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });
      const apresentacoes = await apresentacoesService.listarPorLead(token, query.leadId);
      return json(200, { apresentacoes });
    }

    if (event.httpMethod === 'POST') {
      if (!query.leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });
      const payload = JSON.parse(event.body || '{}');
      const apresentacao = await apresentacoesService.criarNovaVersao(
        token,
        query.leadId,
        query.nome || '',
        payload,
        user.email
      );
      return json(201, { apresentacao });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      if (query.acao === 'publicar') {
        const apresentacao = await apresentacoesService.publicar(token, query.id);
        return json(200, { apresentacao });
      }
      const payload = JSON.parse(event.body || '{}');
      const apresentacao = await apresentacoesService.atualizar(token, query.id, payload);
      return json(200, { apresentacao });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('apresentacoes', 'Falha na operação de apresentação', { message: err.message });
    return json(502, { error: err.message || 'Falha ao processar apresentação.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
