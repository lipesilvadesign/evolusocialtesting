/**
 * Mural/comunicação da equipe — GET lista (RLS: só quem é funcionário
 * ativo vê), POST envia (RLS exige autor_id = quem está autenticado), DELETE
 * ?id= apaga (RLS só permite pra admin — moderação).
 */
const { requireUser } = require('./_lib/config/authGuard');
const equipeMensagensService = require('./_lib/services/equipeMensagensService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      const mensagens = await equipeMensagensService.listar(token);
      return json(200, { mensagens });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      const mensagem = await equipeMensagensService.enviar(token, user.id, payload.mensagem, payload.leadId || null);
      return json(201, { mensagem });
    }

    if (event.httpMethod === 'DELETE') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await equipeMensagensService.excluir(token, query.id);
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('equipe-mensagens', 'Falha na operação de mural da equipe', { message: err.message });
    let statusCode = 502;
    if (err.message.includes('Escreva') || err.message.includes('longa')) statusCode = 400;
    else if (err.message.includes('permissão')) statusCode = 403;
    return json(statusCode, { error: err.message || 'Falha ao processar.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
