/**
 * Lead Capture Engine — API síncrona (validação, jobs, prévia, decisões).
 *
 *   GET                              → { jobs } (seus últimos 20; admin vê todos)
 *   GET ?id=                         → { job }
 *   GET ?id=&itens=1&status=&pagina= → { itens, total } (captura, ordenada por score previsto)
 *   POST ?acao=iniciar               { setor, termo?, cidades[], raioKm, providers[], campanha?,
 *                                      area?: { latitude, longitude, raio_metros, rotulo? } } → { job }
 *                                    (area = minimapa, ENABLE_MAP_SELECTION; substitui cidades/raio)
 *                                    (valida TUDO e cria o job 'na_fila' ANTES do worker; o painel então
 *                                    chama captacao-worker-background com o jobId)
 *   POST ?acao=importar-previa       { arquivoBase64, delimitador? } → cabeçalhos, 5 linhas, mapeamento sugerido
 *   POST ?acao=importar              { arquivoBase64, delimitador?, mapeamento, modo: criar|atualizar|mesclar,
 *                                      campanha?, aplicar? } → criar: { job } · atualizar/mesclar: prévia ou resultado
 *   POST ?acao=aprovar               { ids[], responsavelId?, prioridade?, campanha?, forcarNovo? }
 *   POST ?acao=descartar             { ids[], motivo }
 *   POST ?acao=marcar-duplicado      { id, leadId }
 *   POST ?acao=mesclar               { id, leadId }   (preenche só campos vazios do lead)
 *   POST ?acao=cancelar              { id }
 *   POST ?acao=inbound               { } → cria job com os contatos do site ainda não convertidos (revisão em lote)
 * Limites (no banco): 1 job ativo e 10 jobs/dia por usuário; 6 cidades; 30 km.
 */
const crypto = require('crypto');
const { exigirOperador, json, lerCorpo, ehUuid, respostaErro } = require('./_lib/captacao/acesso');
const { rest, rpc } = require('./_lib/supabaseRest');
const taxonomia = require('./_lib/captacao/taxonomia');
const csv = require('./_lib/captacao/providers/csv');
const inbound = require('./_lib/captacao/providers/inbound');
const pipeline = require('./_lib/captacao/pipeline');
const { criarDeps } = require('./_lib/captacao/deps');
const prospeccaoService = require('./_lib/services/prospeccaoService');
const auditLog = require('./_lib/services/auditLogService');
const { emLotes } = require('./_lib/captacao/enriquecer');
const flags = require('./_lib/captacao/flags');
const cache = require('./_lib/captacao/cache');
const saude = require('./_lib/captacao/saude');
const diagnostico = require('./_lib/captacao/diagnostico');
const logger = require('./_lib/logger');

const L = taxonomia.LIMITES;
// 30/09: colunas explícitas (antes select=*); job por id é lido a cada 2–3 s durante a busca.
const CAMPOS_JOB = 'id,tipo,status,etapa,ramo,cidades,parametros,providers,campanha,fonte,metodo_captacao,progresso,erros,mensagem_erro,metricas,'
  + 'created_at,updated_at,iniciado_em,finalizado_em,qtd_encontrados,qtd_normalizados,qtd_duplicados,qtd_possiveis_duplicados,qtd_descartados,qtd_bloqueados,qtd_aprovados,criado_por,criado_por_id';
const JOB_TRAVADO_MIN = 20; // job "em andamento" há mais que isso = worker morreu

function inicioDoDiaRecife(agora = new Date()) {
  // Recife = UTC-3 o ano todo (sem horário de verão desde 2019)
  const local = new Date(agora.getTime() - 3 * 3600 * 1000);
  local.setUTCHours(0, 0, 0, 0);
  return new Date(local.getTime() + 3 * 3600 * 1000);
}

/** Geocodificação para o minimapa, com o mesmo cache (30 dias) que o worker usa. */
async function geocodificarComCache(token, cidade) {
  const deps = criarDeps(token);
  const ch = cache.chave('geocodificacao', { cidade });
  try { const c = await deps.lerCache(ch); if (c && c.registros && Number.isFinite(Number(c.registros.lat))) return c.registros; } catch { /* segue */ }
  const coords = await deps.geocodificar(cidade);
  if (coords) await deps.gravarCache(ch, 'geocodificacao', { cidade }, coords, cache.TTL_GEO_HORAS).catch(() => {});
  return coords;
}

/** Erro do banco na aprovação → frase para quem aprova (o detalhe técnico vai só para o log). */
function motivoAprovacao(err) {
  const m = String((err && (err.detalhe || err.message)) || '');
  if (/violates check constraint "admin_audit_log/i.test(m)) return 'o registro de auditoria foi recusado pelo banco (configuração pendente — avise o administrador).';
  if (/violates check constraint/i.test(m)) return 'um dos dados não passou nas regras do banco (valor fora do permitido).';
  if (/duplicate key|unique/i.test(m)) return 'a empresa já existe no CRM (registro duplicado).';
  if (/42501|permission|permiss|só pode|Somente|apenas/i.test(m)) return m.replace(/^Falha no banco \(\d+\): /, '').slice(0, 200) || 'sem permissão para esta aprovação.';
  if (/timeout|não respondeu/i.test(m)) return 'o banco demorou a responder. Tente de novo em instantes.';
  if (/Falha no banco \(\d+\): (.+)/.test(m)) return `${m.replace(/^Falha no banco \(\d+\): /, '').slice(0, 200)}.`;
  return 'falha inesperada ao gravar (detalhe registrado no log do servidor).';
}

/** Validação do pedido de pesquisa. @returns {{ erro?: string, dados?: object }} */
function validarPesquisa(b) {
  const setor = String(b.setor || '').trim();
  if (!taxonomia.SETOR_IDS.includes(setor)) return { erro: 'Escolha um setor da lista.' };
  const termo = String(b.termo || '').trim().slice(0, 60);
  if (setor === 'Outro' && !termo) return { erro: 'Para "Outro", informe o termo a buscar.' };
  const providersArea = Array.isArray(b.providers) ? [...new Set(b.providers.filter((p) => p === 'geoapify' || p === 'overpass'))] : [];
  const campanhaArea = b.campanha ? String(b.campanha).trim() : null;
  if (b.area !== undefined && b.area !== null) {
    if (!flags.ligada('ENABLE_MAP_SELECTION')) return { erro: 'A seleção no mapa está desativada. Escolha as cidades.' };
    const area = pipeline.areaValida(b.area);
    if (!area) return { erro: 'Área do mapa inválida: escolha um ponto no Brasil, raio entre 0,5 e 30 km e, na área personalizada, de 3 a 20 cantos dentro desse raio.' };
    if (!providersArea.length) return { erro: 'Escolha ao menos uma fonte.' };
    if (campanhaArea && !/^[a-z0-9_]{1,60}$/.test(campanhaArea)) return { erro: 'Campanha: letras minúsculas, números e _ (até 60).' };
    const raioM = Math.round(area.raioKm * 1000);
    return { dados: {
      setor, termo: termo || null, cidades: [area.rotulo], raioKm: area.raioKm, providers: providersArea, campanha: campanhaArea,
      area: { latitude: Number(area.lat.toFixed(6)), longitude: Number(area.lon.toFixed(6)), raio_metros: raioM, rotulo: area.rotulo, ...(area.geometry ? { geometry: area.geometry } : {}) },
    } };
  }
  const cidades = Array.isArray(b.cidades) ? [...new Set(b.cidades.map((c) => String(c || '').trim()).filter(Boolean))] : [];
  if (!cidades.length) return { erro: 'Selecione ao menos uma cidade.' };
  if (cidades.length > L.cidadesPorJob) return { erro: `No máximo ${L.cidadesPorJob} cidades por captação.` };
  if (cidades.some((c) => c.length > 80)) return { erro: 'Nome de cidade muito longo.' };
  const raioKm = Number(b.raioKm);
  if (!L.raiosKm.includes(raioKm)) return { erro: `Raio inválido (use ${L.raiosKm.join(', ')} km).` };
  const providers = Array.isArray(b.providers) ? [...new Set(b.providers.filter((p) => p === 'geoapify' || p === 'overpass'))] : [];
  if (!providers.length) return { erro: 'Escolha ao menos uma fonte.' };
  const campanha = b.campanha ? String(b.campanha).trim() : null;
  if (campanha && !/^[a-z0-9_]{1,60}$/.test(campanha)) return { erro: 'Campanha: letras minúsculas, números e _ (até 60).' };
  return { dados: { setor, termo: termo || null, cidades, raioKm, providers, campanha } };
}

async function conferirLimites(token, userId) {
  const { data: ativos } = await rest(token,
    `admin_prospeccao_buscas?select=id,status,updated_at,created_at&criado_por_id=eq.${userId}&status=in.(na_fila,em_andamento)`);
  const limiteTravado = Date.now() - JOB_TRAVADO_MIN * 60 * 1000;
  for (const j of ativos || []) {
    const ref = new Date(j.updated_at || j.created_at).getTime();
    if (ref < limiteTravado) {
      await rest(token, `admin_prospeccao_buscas?id=eq.${j.id}`, {
        method: 'PATCH', prefer: 'return=minimal',
        body: { status: 'erro', etapa: null, mensagem_erro: 'Tempo esgotado: o processamento parou sem concluir.', finalizado_em: new Date().toISOString() },
      });
    } else {
      return 'Você já tem uma captação em andamento. Aguarde terminar (ou cancele) antes de iniciar outra.';
    }
  }
  const { total } = await rest(token,
    `admin_prospeccao_buscas?select=id&criado_por_id=eq.${userId}&tipo=in.(pesquisa,importacao)&created_at=gte.${inicioDoDiaRecife().toISOString()}&limit=1`,
    { prefer: 'count=exact' });
  if ((total || 0) >= L.jobsPorDia) return `Limite de ${L.jobsPorDia} captações por dia atingido. Tente amanhã.`;
  return null;
}

const CAMPOS_ITEM = 'id,job_id,provider,external_id,empresa,telefone,telefone_norm,email,site,dominio,instagram,cnpj,endereco,cidade,uf,setor,subsetor,categoria_origem,sinais,score_previsto,score_motivos,avisos,status,match_lead_id,match_tipo,match_confianca,match_empresa,motivo_descarte,lead_id,decidido_em,site_http_status,site_https,enriquecimento_status,enriquecimento,created_at';

// ---------------------------------------------------------------------------
// Importação: atualizar / mesclar leads existentes
// ---------------------------------------------------------------------------
const CSV_PARA_CAMPO = { empresa: 'empresa', telefone: 'telefone', email: 'email', site: 'site', instagram: 'instagram', cnpj: 'cnpj', endereco: 'endereco', cidade: 'cidade', uf: 'uf', setor: 'setor', observacoes: 'observacoes' };
const CAMPO_PARA_COLUNA = prospeccaoService.CAMPOS_EDITAVEIS;

async function planejarAtualizacao(token, leitura, mapa, modo) {
  const linhas = [];
  leitura.linhas.forEach((linha, i) => {
    const r = csv.paraRegistro(linha, mapa, leitura.hash, i + 2);
    if (r) linhas.push(r);
  });
  // correspondência: coluna id (export do painel) ou chave exata (CNPJ / domínio+nome)
  const semId = linhas.filter((l) => !ehUuid(l.leadId));
  if (semId.length) {
    const normalizar = require('./_lib/captacao/normalizar');
    const entrada = semId.map((l, idx) => {
      const n = normalizar.registro(l.registro);
      return { idx, cnpj: n.cnpj, dominio: n.dominio, empresa_norm: n.empresa_norm };
    });
    for (let i = 0; i < entrada.length; i += 200) {
      const achados = (await rpc(token, 'prospeccao_dedup_candidatos', { p_registros: entrada.slice(i, i + 200) })) || [];
      for (const m of achados) if (['cnpj', 'dominio_nome'].includes(m.match_tipo)) semId[m.idx].leadId = m.lead_id;
    }
  }
  const comLead = linhas.filter((l) => ehUuid(l.leadId)).slice(0, 300);
  const ids = [...new Set(comLead.map((l) => l.leadId))];
  const atuais = new Map();
  for (let i = 0; i < ids.length; i += 100) {
    const { data } = await rest(token, `admin_prospeccao_leads?select=id,empresa,telefone,email,site,instagram,cnpj,endereco,cidade,uf,setor,observacoes&id=in.(${ids.slice(i, i + 100).join(',')})`);
    for (const l of data || []) atuais.set(l.id, l);
  }
  const alteracoes = [];
  let semCorrespondencia = linhas.length - comLead.length;
  let semAlteracao = 0;
  for (const l of comLead) {
    const atual = atuais.get(l.leadId);
    if (!atual) { semCorrespondencia += 1; continue; }
    const novos = { ...l.registro, setor: l.registro.setor_sugerido, observacoes: l.observacoes };
    const campos = {};
    for (const [campoCsv, campo] of Object.entries(CSV_PARA_CAMPO)) {
      if (mapa[campoCsv] === undefined || campoCsv === 'empresa') continue;
      const novo = novos[campoCsv];
      if (novo === null || novo === undefined || novo === '') continue;
      const antes = atual[CAMPO_PARA_COLUNA[campo]];
      if (modo === 'mesclar' && antes) continue;
      if (String(antes || '') === String(novo)) continue;
      campos[campo] = [antes || null, novo];
    }
    if (Object.keys(campos).length) alteracoes.push({ leadId: l.leadId, empresa: atual.empresa, campos });
    else semAlteracao += 1;
  }
  return { alteracoes, semAlteracao, semCorrespondencia, totalLinhas: linhas.length, limitado: linhas.filter((l) => ehUuid(l.leadId)).length > 300 };
}

// ---------------------------------------------------------------------------
exports.handler = async function handler(event) {
  const ctx = await exigirOperador(event, { chave: 'captacao', limite: { max: 90, windowMs: 60 * 1000 } });
  if (ctx.resposta) return ctx.resposta;
  const { user, token, ehAdmin } = ctx;
  const q = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      if (q.diagnostico !== undefined) {
        // Painel técnico (Fase 3): só admin. Telemetria real dos jobs + saúde dos hosts. Nada disso vai ao cliente.
        if (!ehAdmin) return json(403, { error: 'Somente admin vê o diagnóstico técnico.' });
        const [{ data: jobs }, saudeR] = await Promise.all([
          rest(token, 'admin_prospeccao_buscas?tipo=eq.pesquisa&select=id,status,etapa,ramo,cidades,parametros,providers,created_at,finalizado_em,qtd_encontrados,qtd_duplicados,qtd_possiveis_duplicados,qtd_aprovados,qtd_descartados,qtd_bloqueados,qtd_enriquecidos,metricas,erros,mensagem_erro&order=created_at.desc&limit=30'),
          rest(token, 'admin_prospeccao_provider_saude?select=*&order=provider.asc,host.asc').catch(() => ({ data: [] })),
        ]);
        return json(200, { jobs: jobs || [], saude: (saudeR.data || []).map(saude.resumo), agregado: diagnostico.agregar(jobs || []) });
      }
      if (q.geocodificar !== undefined) {
        const cidade = String(q.geocodificar || '').trim().slice(0, 80);
        if (cidade.length < 2) return json(400, { error: 'Informe a cidade.' });
        const coords = await geocodificarComCache(token, cidade);
        return coords ? json(200, { coords }) : json(404, { error: `Não encontrei "${cidade}" no mapa. Confira o nome (ex.: Petrolina, PE).` });
      }
      if (q.id) {
        if (!ehUuid(q.id)) return json(400, { error: 'id inválido.' });
        if (q.itens) {
          const status = q.status && taxonomia.STATUS_CAPTURA.includes(q.status) ? `&status=eq.${q.status}` : '';
          const porPagina = Math.min(Math.max(Number(q.por_pagina) || L.paginaPadrao, 1), L.paginaMaxima);
          const pagina = Math.max(Number(q.pagina) || 1, 1);
          const { data, total } = await rest(token,
            `admin_prospeccao_captura?select=${CAMPOS_ITEM}&job_id=eq.${q.id}${status}&order=score_previsto.desc.nullslast,id.asc&limit=${porPagina}&offset=${(pagina - 1) * porPagina}`,
            { prefer: 'count=exact' });
          return json(200, { itens: data || [], total, pagina, porPagina });
        }
        const { data } = await rest(token, `admin_prospeccao_buscas?id=eq.${q.id}&select=${CAMPOS_JOB}`);
        return data && data[0] ? json(200, { job: data[0] }) : json(404, { error: 'Captação não encontrada.' });
      }
      const { data } = await rest(token, `admin_prospeccao_buscas?select=id,tipo,status,etapa,ramo,cidades,parametros,providers,campanha,created_at,finalizado_em,qtd_encontrados,qtd_duplicados,qtd_possiveis_duplicados,qtd_descartados,qtd_bloqueados,qtd_aprovados,metricas,criado_por&order=created_at.desc&limit=20`);
      return json(200, { jobs: data || [] });
    }

    if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });
    const b = lerCorpo(event);
    if (b === null) return json(400, { error: 'Corpo da requisição inválido.' });

    switch (q.acao) {
      case 'iniciar': {
        const v = validarPesquisa(b);
        if (v.erro) return json(400, { error: v.erro });
        const limite = await conferirLimites(token, user.id);
        if (limite) return json(429, { error: limite });
        const d = v.dados;
        const job = {
          id: crypto.randomUUID(), tipo: 'pesquisa', status: 'na_fila', metodo_captacao: 'pesquisa_local',
          fonte: d.providers.length === 1 ? (d.providers[0] === 'overpass' ? 'osm' : 'geoapify') : null,
          campanha: d.campanha, providers: d.providers, cidades: d.cidades,
          ramo: d.termo ? `${d.setor} · ${d.termo}` : d.setor,
          parametros: { setor: d.setor, termo: d.termo, cidades: d.cidades, raioKm: d.raioKm, ...(d.area ? { area: d.area } : {}) },
          progresso: [], criado_por: user.email, criado_por_id: user.id,
        };
        const { data } = await rest(token, 'admin_prospeccao_buscas', { method: 'POST', body: job, prefer: 'return=representation' });
        await auditLog.record(token, { actorId: user.email, action: 'captacao_iniciar', targetType: 'captacao', targetId: job.id, metadata: { setor: d.setor, cidades: d.cidades, providers: d.providers, area: d.area ? { raio_metros: d.area.raio_metros } : undefined } });
        return json(201, { job: data[0] });
      }

      case 'importar-previa': {
        const leitura = csv.ler(b.arquivoBase64, { delimitador: b.delimitador });
        return json(200, {
          hash: leitura.hash, codificacao: leitura.codificacao, delimitador: leitura.delimitador, cabecalhos: leitura.cabecalhos,
          amostra: leitura.amostra, totalLinhas: leitura.totalLinhas, mapeamentoSugerido: leitura.mapeamentoSugerido, avisos: leitura.avisos,
        });
      }

      case 'importar': {
        const leitura = csv.ler(b.arquivoBase64, { delimitador: b.delimitador });
        const mapa = {};
        for (const [campo, idx] of Object.entries(b.mapeamento || {})) {
          if (campo in csv.SINONIMOS && Number.isInteger(idx) && idx >= 0 && idx < leitura.cabecalhos.length) mapa[campo] = idx;
        }
        const modo = ['criar', 'atualizar', 'mesclar'].includes(b.modo) ? b.modo : 'criar';
        if (modo === 'criar' && mapa.empresa === undefined) return json(400, { error: 'Diga qual coluna tem o nome da empresa.' });

        if (modo !== 'criar') {
          const plano = await planejarAtualizacao(token, leitura, mapa, modo);
          if (!b.aplicar) return json(200, { modo, previa: { ...plano, alteracoes: plano.alteracoes.slice(0, 50), totalAlteracoes: plano.alteracoes.length } });
          let ok = 0; const falhas = [];
          await emLotes(plano.alteracoes, 4, async (a) => {
            const payload = Object.fromEntries(Object.entries(a.campos).map(([campo, [, novo]]) => [campo, novo]));
            try { await prospeccaoService.update(token, a.leadId, payload, { ehAdmin, userId: user.id }); ok += 1; } catch (err) { falhas.push({ empresa: a.empresa, erro: err.message }); }
          });
          await auditLog.record(token, { actorId: user.email, action: `importar_${modo}`, targetType: 'lead_prospeccao', metadata: { arquivo: leitura.hash, atualizados: ok, falhas: falhas.length } });
          return json(200, { modo, atualizados: ok, falhas: falhas.slice(0, 20) });
        }

        const limite = await conferirLimites(token, user.id);
        if (limite) return json(429, { error: limite });
        const campanha = b.campanha && /^[a-z0-9_]{1,60}$/.test(b.campanha) ? b.campanha : null;
        const jobId = crypto.randomUUID();
        await rest(token, 'admin_prospeccao_buscas', {
          method: 'POST', prefer: 'return=minimal',
          body: { id: jobId, tipo: 'importacao', status: 'em_andamento', etapa: 'normalizacao', fonte: 'csv', metodo_captacao: 'importacao', campanha,
            providers: ['csv'], ramo: 'Importação CSV', iniciado_em: new Date().toISOString(),
            parametros: { arquivo: leitura.hash, codificacao: leitura.codificacao, delimitador: leitura.delimitador, mapeamento: mapa, linhas: leitura.totalLinhas },
            criado_por: user.email, criado_por_id: user.id },
        });
        const registros = [];
        leitura.linhas.forEach((linha, i) => { const r = csv.paraRegistro(linha, mapa, leitura.hash, i + 2); if (r) registros.push(r.registro); });
        const deps = criarDeps(token);
        deps.verificarCancelamento = async () => {};
        const siteMapeado = mapa.site !== undefined;
        const resumo = await pipeline.processarRegistros(registros, {
          jobId, deps, enriquecerSites: false,
          fontesConsultadas: siteMapeado ? ['planilha importada'] : [], semSiteConfianca: 'baixa',
        });
        await deps.atualizarJob(jobId, { status: resumo.gravados ? 'em_revisao' : 'concluido', etapa: null, ...(resumo.gravados ? {} : { finalizado_em: new Date().toISOString() }),
          erros: resumo.invalidos ? [{ provider: 'csv', mensagem: `${resumo.invalidos} linha(s) sem nome de empresa foram ignoradas`, em: new Date().toISOString() }] : [] });
        await auditLog.record(token, { actorId: user.email, action: 'importar_csv', targetType: 'captacao', targetId: jobId, metadata: { arquivo: leitura.hash, ...resumo } });
        const { data } = await rest(token, `admin_prospeccao_buscas?id=eq.${jobId}&select=${CAMPOS_JOB}`);
        return json(201, { job: data[0], resumo, avisos: leitura.avisos });
      }

      case 'aprovar': {
        const ids = Array.isArray(b.ids) ? b.ids.filter(ehUuid).slice(0, 200) : [];
        if (!ids.length) return json(400, { error: 'Selecione ao menos um registro.' });
        if (b.responsavelId && !ehUuid(b.responsavelId)) return json(400, { error: 'Responsável inválido.' });
        if (!ehAdmin && b.responsavelId && b.responsavelId !== user.id) return json(403, { error: 'Você só pode aprovar leads para você mesmo.' });
        const inicio = Date.now();
        let resultado;
        try {
          resultado = await rpc(token, 'aprovar_captura', {
            p_ids: ids, p_responsavel: b.responsavelId || user.id, p_prioridade: ['alta', 'media', 'baixa'].includes(b.prioridade) ? b.prioridade : 'media',
            p_campanha: b.campanha || null, p_forcar_novo: Boolean(b.forcarNovo),
          });
        } catch (err) {
          // A RPC é uma transação só: se falhou, NADA foi gravado (nenhum lead parcial).
          logger.error('captacao', 'Aprovação falhou', { evento: 'aprovacao', quantidade: ids.length, status: err.status, detalhe: String(err.detalhe || err.message).slice(0, 300) });
          return json(err.status === 403 || /42501|permission|permiss/i.test(err.message) ? 403 : 422, {
            error: `A aprovação não foi concluída. Motivo: ${motivoAprovacao(err)} Nenhum lead foi criado.`,
          });
        }
        const cont = {};
        for (const r of resultado || []) cont[r.resultado] = (cont[r.resultado] || 0) + 1;
        logger.info('captacao', 'Aprovação concluída', { evento: 'aprovacao', quantidade: ids.length, resumo: cont, duracao_ms: Date.now() - inicio });
        return json(200, { resultado, resumo: cont });
      }

      case 'descartar': {
        const ids = Array.isArray(b.ids) ? b.ids.filter(ehUuid).slice(0, 200) : [];
        if (!ids.length) return json(400, { error: 'Selecione ao menos um registro.' });
        if (!taxonomia.MOTIVOS_DESCARTE.includes(b.motivo)) return json(400, { error: 'Escolha o motivo do descarte.' });
        const { data } = await rest(token, `admin_prospeccao_captura?id=in.(${ids.join(',')})&status=in.(pendente,possivel_duplicado,duplicado,erro)&lead_id=is.null`, {
          method: 'PATCH', prefer: 'return=representation',
          body: { status: 'descartado', motivo_descarte: b.motivo, decidido_por: user.id, decidido_em: new Date().toISOString() },
        });
        return json(200, { descartados: (data || []).length });
      }

      case 'marcar-duplicado': {
        if (!ehUuid(b.id) || !ehUuid(b.leadId)) return json(400, { error: 'Informe o registro e o lead.' });
        const { data } = await rest(token, `admin_prospeccao_captura?id=eq.${b.id}&lead_id=is.null&status=neq.aprovado`, {
          method: 'PATCH', prefer: 'return=representation',
          body: { status: 'duplicado', match_lead_id: b.leadId, match_tipo: 'mesmo_job', decidido_por: user.id, decidido_em: new Date().toISOString() },
        });
        return (data || []).length ? json(200, { ok: true }) : json(404, { error: 'Registro não encontrado ou já decidido.' });
      }

      case 'mesclar': {
        if (!ehUuid(b.id) || !ehUuid(b.leadId)) return json(400, { error: 'Informe o registro e o lead.' });
        return json(200, { resultado: await rpc(token, 'prospeccao_mesclar_captura', { p_captura: b.id, p_lead: b.leadId }) });
      }

      case 'cancelar': {
        if (!ehUuid(b.id)) return json(400, { error: 'id inválido.' });
        const { data } = await rest(token, `admin_prospeccao_buscas?id=eq.${b.id}&status=in.(na_fila,em_andamento)`, {
          method: 'PATCH', prefer: 'return=representation', body: { status: 'cancelado', etapa: null, finalizado_em: new Date().toISOString() },
        });
        return (data || []).length ? json(200, { ok: true }) : json(409, { error: 'Esta captação já terminou.' });
      }

      case 'inbound': {
        // Contatos do site ainda não convertidos → captura para revisão em lote (a conversão individual
        // continua pelo botão "Converter em lead" em Contatos do site / Consultas).
        const { data: contatos } = await rest(token, 'site_contatos?select=id,nome,email,whatsapp,servico,orcamento,created_at&convertido_lead_id=is.null&order=created_at.desc&limit=200');
        let consultas = [];
        if (ehAdmin) {
          const r = await rest(token, 'consultas_leads?select=id,nome,email,whatsapp,instagram,segmento,objetivo,created_at&convertido_lead_id=is.null&order=created_at.desc&limit=200');
          consultas = r.data || [];
        }
        const registros = [...(contatos || []).map(inbound.siteContato.paraRegistro), ...consultas.map(inbound.consultoria.paraRegistro)];
        if (!registros.length) return json(200, { job: null, mensagem: 'Nenhum contato do site aguardando conversão.' });
        const jobId = crypto.randomUUID();
        await rest(token, 'admin_prospeccao_buscas', {
          method: 'POST', prefer: 'return=minimal',
          body: { id: jobId, tipo: 'inbound', status: 'em_andamento', etapa: 'deduplicacao', fonte: 'site', metodo_captacao: 'formulario',
            providers: [...new Set(registros.map((r) => r.provider))], ramo: 'Formulários do site', iniciado_em: new Date().toISOString(),
            parametros: { origem: 'lote' }, criado_por: user.email, criado_por_id: user.id },
        });
        const deps = criarDeps(token);
        deps.verificarCancelamento = async () => {};
        const resumo = await pipeline.processarRegistros(registros, { jobId, deps, enriquecerSites: false, fontesConsultadas: [] });
        await deps.atualizarJob(jobId, { status: 'em_revisao', etapa: null });
        const { data } = await rest(token, `admin_prospeccao_buscas?id=eq.${jobId}&select=${CAMPOS_JOB}`);
        return json(201, { job: data[0], resumo });
      }

      default:
        return json(400, { error: 'Ação desconhecida.' });
    }
  } catch (err) {
    return respostaErro(err);
  }
};

exports._internos = { validarPesquisa, inicioDoDiaRecife, planejarAtualizacao, motivoAprovacao };
