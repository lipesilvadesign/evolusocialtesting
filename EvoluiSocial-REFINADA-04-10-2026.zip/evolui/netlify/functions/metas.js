/**
 * Metas de prospecção (Início) — GET lista (RLS decide o que volta: admin
 * vê de todo mundo, os demais só as próprias); POST define/redefine uma
 * meta (RLS só permite pra admin — ver SQL_PENDENTE_ponto_metas.sql).
 */
const { requireUser } = require('./_lib/config/authGuard');
const metasService = require('./_lib/services/metasService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  try {
    if (event.httpMethod === 'GET') {
      const metas = await metasService.listar(token);
      return json(200, { metas });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      const meta = await metasService.definir(token, { ...payload, criadoPor: user.email });
      return json(201, { meta });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('metas', 'Falha na operação de meta', { message: err.message });
    return json(err.message.includes('inválid') || err.message.includes('Informe') ? 400 : 502, { error: err.message || 'Falha ao processar meta.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
