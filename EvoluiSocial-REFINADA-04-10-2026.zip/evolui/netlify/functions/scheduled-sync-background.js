/**
 * Sincronização agendada (etapa "Operação, Automação e Escala").
 *
 * Netlify Background Function — nome termina em "-background" de
 * propósito (Netlify reconhece isso e roda até 15 minutos, respondendo
 * 202 imediato pro agendador). Disparada por cron via netlify.toml
 * ([functions."scheduled-sync-background"] schedule = "@hourly").
 *
 * Não tem usuário logado disponível (é um job, não uma requisição de
 * alguém) — por isso usa a SUPABASE_SERVICE_ROLE_KEY (ver
 * _lib/config/supabaseServiceRole.js), não o token de ninguém. Se essa
 * variável não estiver configurada, a função loga o problema e encerra
 * sem quebrar (nunca lança exceção não tratada — é um cron, não pode
 * ficar reexplodindo).
 *
 * Checagem de anomalias de tráfego (GA4) e geração de relatório semanal/
 * mensal foram removidas em 13/09 — as duas dependiam 100% do motor de
 * Insights, que é GA4 (mesma dependência que o Felipe decidiu abandonar
 * neste painel). Ficaram só os dois jobs de PROSPECÇÃO, que são os que
 * importam agora.
 */

const { getServiceRoleKey, SUPABASE_URL } = require('./_lib/config/supabaseServiceRole');
const notificationsService = require('./_lib/services/notificationsService');
const siteContatos = require('./_lib/services/siteContatosService');
const logger = require('./_lib/logger');

/**
 * PROMPT 5, item 6 — alerta interno quando um follow-up de prospecção/
 * cliente vence. Só notifica uma vez por data marcada (follow_up_notificado_em
 * evita repetir o alerta toda hora que o job roda); se o responsável mudar a
 * data pra uma nova no futuro, o campo de "já notificado" naturalmente para
 * de bater com a nova data e o alerta volta a valer quando ela vencer.
 */
async function runFollowUpAlerts(serviceRoleKey) {
  const agora = new Date().toISOString();
  // Correção: filtrava por status_lead=not.in.(cliente,perdido), mas
  // 'cliente'/'perdido' nunca foram valores válidos de status_lead (essa
  // coluna só aceita novo/pesquisando/qualificado/nao_qualificado/
  // duplicado/bloqueado — ver SQL_PENDENTE_prospeccao.sql) — o filtro era
  // sempre verdadeiro pra qualquer linha, ou seja, não filtrava nada.
  // O campo certo pra "já fechado" é `status` (estágio da oportunidade).
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_prospeccao_leads?select=id,empresa,responsavel_id,proxima_atividade_em,follow_up_notificado_em,status` +
      `&proxima_atividade_em=lte.${agora}&status=not.in.(cliente,nao_convertido)&arquivado_em=is.null`,
    { headers: { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` } }
  );
  if (!res.ok) throw new Error(`Falha ao consultar follow-ups vencidos (${res.status}).`);
  const leads = await res.json();

  const vencidos = leads.filter((l) => l.follow_up_notificado_em !== l.proxima_atividade_em);
  for (const lead of vencidos) {
    await notificationsService.create(serviceRoleKey, {
      tipo: 'oportunidade', // reaproveita um tipo já existente/validado, em vez de arriscar um enum novo não confirmado no banco
      titulo: `Follow-up vencido: ${lead.empresa}`,
      mensagem: `O follow-up combinado com ${lead.empresa} venceu (${new Date(lead.proxima_atividade_em).toLocaleDateString('pt-BR')}) e ainda não foi registrado um novo contato.`,
      severidade: 'media',
      metadata: { leadId: lead.id, proximaAtividadeEm: lead.proxima_atividade_em },
    });
    await fetch(`${SUPABASE_URL}/rest/v1/admin_prospeccao_leads?id=eq.${lead.id}`, {
      method: 'PATCH',
      headers: { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ follow_up_notificado_em: lead.proxima_atividade_em }),
    });
  }
  return vencidos.length;
}

/**
 * Leads parados → ARQUIVAMENTO (30/09, Lead Capture Engine).
 *
 * Até 30/09 esta rotina APAGAVA leads (decisão de 13/09). Nova regra do
 * dono: nenhuma rotina automática destrói um lead. Agora ela só ARQUIVA:
 * arquivado_em = agora, motivo 'inatividade_automatica', arquivado_por
 * 'sistema'. O lead sai da lista padrão e do funil, continua valendo para a
 * deduplicação (a busca semanal não o reimporta) e um admin pode restaurar.
 * O banco também recusa DELETE vindo de rotina (migration 001).
 *
 * Critério (igual ao antigo, com prazo configurável): status 'novo_lead' ou
 * 'contatado', sem próxima ação agendada no futuro e sem atividade há
 * PROSPECCAO_ARQUIVAR_DIAS dias (padrão 30 — antes eram 7; decisão de
 * negócio documentada em docs/LEAD_CAPTURE_ENGINE.md).
 */
const STALE_DIAS = Math.max(7, Number(process.env.PROSPECCAO_ARQUIVAR_DIAS) || 30);
const STALE_STATUS = ['novo_lead', 'contatado'];
const MAX_ARQUIVAR_POR_EXECUCAO = 200;

function selecionarParados(candidatos, agora = new Date(), dias = STALE_DIAS) {
  const limite = new Date(agora.getTime() - dias * 24 * 60 * 60 * 1000).toISOString();
  return candidatos.filter((l) => {
    if (l.arquivado_em) return false;
    if (l.proxima_atividade_em && new Date(l.proxima_atividade_em) > agora) return false; // tem próximo passo agendado
    const referencia = l.ultima_atividade_em || l.created_at;
    if (!referencia) return false;
    return new Date(referencia).toISOString() < limite;
  });
}

async function runStaleLeadCleanup(serviceRoleKey) {
  const auth = { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` };
  const limite = new Date(Date.now() - STALE_DIAS * 24 * 60 * 60 * 1000).toISOString();
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_prospeccao_leads?select=id,empresa,status,created_at,ultima_atividade_em,proxima_atividade_em,arquivado_em` +
      `&status=in.(${STALE_STATUS.join(',')})&arquivado_em=is.null&created_at=lt.${limite}&limit=${MAX_ARQUIVAR_POR_EXECUCAO}`,
    { headers: auth }
  );
  if (!res.ok) throw new Error(`Falha ao consultar leads parados (${res.status}).`);
  const parados = selecionarParados(await res.json());
  if (parados.length === 0) return 0;

  const ids = parados.map((l) => l.id);
  const upd = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_prospeccao_leads?id=in.(${ids.join(',')})&arquivado_em=is.null`,
    {
      method: 'PATCH',
      headers: { ...auth, 'Content-Type': 'application/json', Prefer: 'return=representation' },
      body: JSON.stringify({ arquivado_em: new Date().toISOString(), motivo_arquivamento: 'inatividade_automatica', arquivado_por: 'sistema' }),
    }
  );
  if (!upd.ok) throw new Error(`Falha ao arquivar leads parados (${upd.status}).`);
  const arquivados = await upd.json();
  if (!arquivados.length) return 0;

  await notificationsService.create(serviceRoleKey, {
    tipo: 'sistema',
    titulo: `${arquivados.length} lead(s) parado(s) arquivado(s)`,
    mensagem: `Sem atividade há mais de ${STALE_DIAS} dias e ainda em estágio inicial (novo lead/contatado): ${arquivados.map((l) => l.empresa).join(', ')}. Nada foi apagado — um admin pode restaurar em Prospecção → Arquivados.`,
    severidade: 'baixa',
    metadata: { leadIds: arquivados.map((l) => l.id), staleDias: STALE_DIAS, rota: '#/prospeccao?arquivados=so' },
  });
  return arquivados.length;
}

/**
 * Recalcula score/temperatura de todos os leads uma vez por dia (a
 * temperatura depende da data: um lead "quente" esfria sozinho com o tempo).
 * Roda na primeira execução depois das 6h de Recife (9h UTC).
 */
async function runRecalculoDiario(serviceRoleKey, agora = new Date()) {
  if (agora.getUTCHours() !== 9) return null;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/prospeccao_recalcular_todos`, {
    method: 'POST',
    headers: { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}`, 'Content-Type': 'application/json' },
    body: '{}',
  });
  if (res.status === 404) return null; // migration 008 ainda não aplicada
  if (!res.ok) throw new Error(`Falha no recálculo diário (${res.status}).`);
  return res.json();
}

/**
 * Verificação dos avisos por e-mail dos contatos da home (29/09).
 * O contato já está salvo e já gerou notificação no sino; aqui só
 * garantimos que o e-mail também chegou. Reenvia os que ficaram
 * 'pendente'/'falhou'/'sem_smtp' (até MAX_TENTATIVAS, últimos 7 dias) e,
 * se o SMTP não estiver configurado ou um aviso desistir, avisa no sino.
 */
const MAX_TENTATIVAS_EMAIL = 5;

async function jaAlertouHoje(serviceRoleKey, chave) {
  const desde = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/admin_notificacoes?select=id&created_at=gte.${desde}&metadata->>alerta=eq.${chave}&limit=1`,
    { headers: { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` } }
  );
  if (!res.ok) return false;
  return (await res.json()).length > 0;
}

async function runVerificacaoEmailsContatos(serviceRoleKey) {
  const auth = { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` };
  const seteDias = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const tresMin = new Date(Date.now() - 3 * 60 * 1000).toISOString(); // dá tempo da Function pública registrar o 1º envio
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/${siteContatos.TABLE}?select=*&email_status=neq.enviado&email_tentativas=lt.${MAX_TENTATIVAS_EMAIL}` +
      `&created_at=gte.${seteDias}&created_at=lte.${tresMin}&order=created_at.asc&limit=20`,
    { headers: auth }
  );
  if (res.status === 404) return { pendentes: 0 }; // tabela ainda não criada
  if (!res.ok) throw new Error(`Falha ao consultar contatos pendentes (${res.status}).`);
  const pendentes = await res.json();
  if (pendentes.length === 0) return { pendentes: 0 };

  if (!siteContatos.smtpConfigurado()) {
    if (!(await jaAlertouHoje(serviceRoleKey, 'contatos_sem_smtp'))) {
      await notificationsService.create(serviceRoleKey, {
        tipo: 'sistema',
        titulo: 'Avisos por e-mail dos contatos do site não estão saindo',
        mensagem: `${pendentes.length} contato(s) do site estão salvos no painel, mas o e-mail de aviso não foi enviado: faltam UMBLER_SMTP_USER/UMBLER_SMTP_PASS no Netlify.`,
        severidade: 'alta',
        metadata: { alerta: 'contatos_sem_smtp', rota: '#/contatos-site' },
      });
    }
    return { pendentes: pendentes.length, enviados: 0, semSmtp: true };
  }

  let enviados = 0;
  const desistidos = [];
  for (const contato of pendentes) {
    const resultado = await siteContatos.enviarAviso(contato);
    const tentativas = (contato.email_tentativas || 0) + 1;
    await fetch(`${SUPABASE_URL}/rest/v1/${siteContatos.TABLE}?id=eq.${contato.id}`, {
      method: 'PATCH',
      headers: { ...auth, 'Content-Type': 'application/json', Prefer: 'return=minimal' },
      body: JSON.stringify({
        email_status: resultado.status,
        email_tentativas: tentativas,
        email_ultimo_erro: resultado.status === 'enviado' ? null : resultado.erro || null,
        email_enviado_em: resultado.status === 'enviado' ? new Date().toISOString() : null,
      }),
    });
    if (resultado.status === 'enviado') enviados += 1;
    else if (tentativas >= MAX_TENTATIVAS_EMAIL) desistidos.push(contato);
    await new Promise((r) => setTimeout(r, 1500)); // um de cada vez (regra da Umbler, ver umblerSmtp.js)
  }

  if (desistidos.length) {
    await notificationsService.create(serviceRoleKey, {
      tipo: 'erro',
      titulo: `${desistidos.length} aviso(s) de contato do site não chegaram por e-mail`,
      mensagem: `Tentamos ${MAX_TENTATIVAS_EMAIL} vezes: ${desistidos.map((c) => c.nome).join(', ')}. Os contatos estão no painel em "Contatos do site" — responda por lá.`,
      severidade: 'alta',
      metadata: { alerta: 'contatos_email_desistido', ids: desistidos.map((c) => c.id), rota: '#/contatos-site' },
    });
  }
  return { pendentes: pendentes.length, enviados, desistidos: desistidos.length };
}

exports._internos = { runVerificacaoEmailsContatos, runStaleLeadCleanup, selecionarParados, runRecalculoDiario, STALE_DIAS };

exports.handler = async function handler() {
  const serviceRoleKey = getServiceRoleKey();
  if (!serviceRoleKey) {
    logger.warn('scheduled-sync', 'SUPABASE_SERVICE_ROLE_KEY ausente — job encerrado sem executar.');
    return { statusCode: 200, body: 'skipped: missing service role key' };
  }

  try {
    const alertados = await runFollowUpAlerts(serviceRoleKey);
    if (alertados) logger.info('scheduled-sync', 'Alertas de follow-up enviados', { alertados });
  } catch (err) {
    logger.error('scheduled-sync', 'Falha ao checar follow-ups vencidos', { message: err.message });
  }

  try {
    const r = await runVerificacaoEmailsContatos(serviceRoleKey);
    if (r.pendentes) logger.info('scheduled-sync', 'Verificação de e-mails dos contatos do site', r);
  } catch (err) {
    logger.error('scheduled-sync', 'Falha na verificação de e-mails dos contatos do site', { message: err.message });
  }

  try {
    const arquivados = await runStaleLeadCleanup(serviceRoleKey);
    if (arquivados) logger.info('scheduled-sync', 'Leads parados arquivados automaticamente', { arquivados });
  } catch (err) {
    logger.error('scheduled-sync', 'Falha no arquivamento de leads parados', { message: err.message });
  }

  try {
    const recalculados = await runRecalculoDiario(serviceRoleKey);
    if (recalculados !== null) logger.info('scheduled-sync', 'Recálculo diário de score/temperatura', { recalculados });
  } catch (err) {
    logger.error('scheduled-sync', 'Falha no recálculo diário', { message: err.message });
  }

  return { statusCode: 200, body: 'ok' };
};
