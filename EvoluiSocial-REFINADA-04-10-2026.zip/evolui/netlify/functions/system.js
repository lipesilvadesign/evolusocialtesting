const { requireUser } = require('./_lib/config/authGuard');
const auditLogService = require('./_lib/services/auditLogService');

// "Controle de uso de IA" (resource=ai-usage) foi removido da interface a
// pedido do Felipe — o registro em si (aiHistoryService) continua rodando
// por trás, usado por diagnosticoIaService/aiInsightsService; só a tela que
// expunha esse número pra visualização foi tirada.
exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Método não permitido.' });

  const { token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const resource = (event.queryStringParameters || {}).resource;

  try {
    if (resource === 'audit') {
      const entries = await auditLogService.list(token);
      return json(200, { entries });
    }
    return json(400, { error: 'Parâmetro "resource" inválido. Use "audit".' });
  } catch (err) {
    return json(500, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
