/**
 * Atividades (histórico + próxima ação) de um lead — GET ?leadId= lista,
 * POST cria (e já atualiza ultima_atividade_em/proxima_atividade_em no lead).
 */

const { requireUser } = require('./_lib/config/authGuard');
const atividadesService = require('./_lib/services/atividadesService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  try {
    if (event.httpMethod === 'GET') {
      const leadId = (event.queryStringParameters || {}).leadId;
      if (!leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });
      const atividades = await atividadesService.listarPorLead(token, leadId);
      return json(200, { atividades });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      if (!payload.leadId || !payload.tipo) return json(400, { error: 'Informe "leadId" e "tipo".' });
      const atividade = await atividadesService.criar(token, { ...payload, criadoPor: user.email });
      return json(201, { atividade });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('prospeccao-atividades', 'Falha na operação de atividade', { message: err.message });
    return json(502, { error: err.message || 'Falha ao processar atividade.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
