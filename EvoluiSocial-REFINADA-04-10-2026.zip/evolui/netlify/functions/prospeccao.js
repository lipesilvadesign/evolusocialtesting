/**
 * CRM de prospecção.
 *
 *   GET                       → { leads, total, pagina, porPagina } com filtros no servidor
 *                               (q, setor, subsetor, cidade, uf, fonte, metodo, campanha, score_min,
 *                               score_max, faixa, temperatura, prioridade, status, responsavel,
 *                               criado_de, criado_ate, atividade_de, atividade_ate, oportunidade,
 *                               tem_site, tem_instagram, tem_telefone, tem_email, arquivados,
 *                               ordem, pagina, por_pagina)
 *   GET ?id=                  → { lead } (com oportunidades)
 *   POST                      → cria (manual) — score/temperatura calculados pelo banco
 *   PATCH ?id=                → edita
 *   POST ?acao=arquivar       { ids[], motivo, obs? }   dono ou admin
 *   POST ?acao=restaurar      { ids[] }                 só admin
 *   POST ?acao=mesclar        { manterId, absorverId }  só admin
 *   POST ?acao=converter      { tipo: consulta|site_contato, id }
 *   POST ?acao=recalcular     só admin (recalcula score/temperatura de todos)
 *   DELETE ?id=               exclusão DEFINITIVA — só admin e só lead já arquivado
 * Autorização: papel admin/prospecção aqui + RLS/RPC no banco.
 */
const { exigirOperador, json, lerCorpo, ehUuid, respostaErro } = require('./_lib/captacao/acesso');
const prospeccaoService = require('./_lib/services/prospeccaoService');
const auditLog = require('./_lib/services/auditLogService');
const { rpc } = require('./_lib/supabaseRest');
const normalizar = require('./_lib/captacao/normalizar');
const manual = require('./_lib/captacao/providers/manual');

/** Cadastro manual também passa pela deduplicação: avisa antes de criar um lead repetido. */
async function possiveisDuplicados(token, payload) {
  const n = normalizar.registro(manual.paraRegistro(payload));
  const achados = await rpc(token, 'prospeccao_dedup_candidatos', { p_registros: [{
    idx: 0, cnpj: n.cnpj, dominio: n.dominio, empresa_norm: n.empresa_norm, telefone_norm: n.telefone_norm,
    instagram_handle: n.instagram_handle, email: n.email, cidade_norm: n.cidade_norm, endereco: n.endereco,
  }] });
  return (achados || []).map((m) => ({ leadId: m.lead_id, empresa: m.empresa, cidade: m.cidade, motivo: m.match_tipo, confianca: m.confianca }));
}

const MOTIVOS_ARQUIVAR = new Set(['sem_interesse', 'dados_invalidos', 'duplicado', 'optout', 'outro']);

exports.handler = async function handler(event) {
  const ctx = await exigirOperador(event);
  if (ctx.resposta) return ctx.resposta;
  const { user, token, ehAdmin } = ctx;
  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      if (query.id) {
        if (!ehUuid(query.id)) return json(400, { error: 'id inválido.' });
        const lead = await prospeccaoService.buscarPorId(token, query.id);
        return lead ? json(200, { lead }) : json(404, { error: 'Lead não encontrado.' });
      }
      const r = await prospeccaoService.listar(token, query, user.id);
      return json(200, { leads: r.itens, total: r.total, pagina: r.pagina, porPagina: r.porPagina });
    }

    const payload = lerCorpo(event);
    if (payload === null) return json(400, { error: 'Corpo da requisição inválido.' });

    if (event.httpMethod === 'POST' && query.acao) {
      const ids = Array.isArray(payload.ids) ? payload.ids.filter(ehUuid).slice(0, 200) : [];
      if (query.acao === 'arquivar') {
        if (!ids.length) return json(400, { error: 'Selecione ao menos um lead.' });
        if (!MOTIVOS_ARQUIVAR.has(payload.motivo)) return json(400, { error: 'Motivo de arquivamento inválido.' });
        const n = await prospeccaoService.arquivar(token, ids, payload.motivo, String(payload.obs || '').slice(0, 500));
        return json(200, { arquivados: n });
      }
      if (query.acao === 'restaurar') {
        if (!ehAdmin) return json(403, { error: 'Somente admin restaura leads arquivados.' });
        if (!ids.length) return json(400, { error: 'Selecione ao menos um lead.' });
        return json(200, { restaurados: await prospeccaoService.restaurar(token, ids) });
      }
      if (query.acao === 'mesclar') {
        if (!ehAdmin) return json(403, { error: 'Somente admin mescla leads.' });
        if (!ehUuid(payload.manterId) || !ehUuid(payload.absorverId)) return json(400, { error: 'Informe os dois leads.' });
        return json(200, { resultado: await prospeccaoService.mesclar(token, payload.manterId, payload.absorverId) });
      }
      if (query.acao === 'converter') {
        if (!['consulta', 'site_contato'].includes(payload.tipo) || !ehUuid(payload.id)) return json(400, { error: 'Informe tipo e id.' });
        return json(200, { resultado: await prospeccaoService.converterInbound(token, payload.tipo, payload.id) });
      }
      if (query.acao === 'recalcular') {
        if (!ehAdmin) return json(403, { error: 'Somente admin.' });
        return json(200, { recalculados: await rpc(token, 'prospeccao_recalcular_todos', {}) });
      }
      return json(400, { error: 'Ação desconhecida.' });
    }

    if (event.httpMethod === 'POST') {
      if (!payload.confirmarDuplicado) {
        const dup = await possiveisDuplicados(token, payload);
        if (dup.length) return json(409, { error: 'Já existe um lead parecido. Confira antes de criar outro.', duplicados: dup });
      }
      const lead = await prospeccaoService.create(
        token,
        { ...payload, criadoPor: user.email, responsavelId: payload.responsavelId || user.id },
        { ehAdmin, userId: user.id }
      );
      await auditLog.record(token, { actorId: user.email, action: 'create', targetType: 'lead_prospeccao', targetId: lead.id });
      return json(201, { lead });
    }

    if (event.httpMethod === 'PATCH') {
      if (!ehUuid(query.id)) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const lead = await prospeccaoService.update(token, query.id, payload, { ehAdmin, userId: user.id });
      const campos = Object.keys(payload).filter((k) => Object.prototype.hasOwnProperty.call(prospeccaoService.CAMPOS_EDITAVEIS, k));
      await auditLog.record(token, { actorId: user.email, action: 'update', targetType: 'lead_prospeccao', targetId: query.id, metadata: { campos } });
      return json(200, { lead });
    }

    if (event.httpMethod === 'DELETE') {
      if (!ehUuid(query.id)) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      if (!ehAdmin) return json(403, { error: 'Somente admin exclui definitivamente.' });
      // Auditoria ANTES (o registro some depois)
      const lead = await prospeccaoService.buscarPorId(token, query.id);
      if (!lead) return json(404, { error: 'Lead não encontrado.' });
      if (!lead.arquivado_em) return json(409, { error: 'Arquive o lead antes de excluir definitivamente.' });
      await auditLog.record(token, {
        actorId: user.email, action: 'delete', targetType: 'lead_prospeccao', targetId: query.id,
        metadata: { empresa: lead.empresa, motivo_arquivamento: lead.motivo_arquivamento, origem_id: lead.origem_id },
      });
      await prospeccaoService.remove(token, query.id);
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return respostaErro(err);
  }
};
