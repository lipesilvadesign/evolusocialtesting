/**
 * Atividades (linha do tempo) de um lead da Consultoria de Instagram, do
 * lado administrativo — GET ?leadId= lista, POST cria (observação, contato
 * realizado, mudança de status registrada como nota). Mesmo padrão de
 * netlify/functions/prospeccao-atividades.js. Os eventos automáticos
 * (analise_concluida, cta_*) são gravados pelo visitante sem login — ver
 * consultas-criar.js / consultas-evento.js — nunca por aqui.
 */

const { requireUser } = require('./_lib/config/authGuard');
const atividadesService = require('./_lib/services/consultasAtividadesService');
const logger = require('./_lib/logger');

const TIPOS_ADMIN = ['contato_realizado', 'mudanca_status', 'observacao'];

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  try {
    if (event.httpMethod === 'GET') {
      const leadId = (event.queryStringParameters || {}).leadId;
      if (!leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });
      const atividades = await atividadesService.listarPorLead(token, leadId);
      return json(200, { atividades });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      if (!payload.leadId || !payload.tipo) return json(400, { error: 'Informe "leadId" e "tipo".' });
      if (!TIPOS_ADMIN.includes(payload.tipo)) {
        return json(400, { error: `Tipo de atividade não permitido pelo painel: "${payload.tipo}".` });
      }
      const atividade = await atividadesService.criar(token, { ...payload, criadoPor: user.email });
      return json(201, { atividade });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('consultas-atividades', 'Falha na operação de atividade', { message: err.message });
    return json(502, { error: err.message || 'Falha ao processar atividade.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
