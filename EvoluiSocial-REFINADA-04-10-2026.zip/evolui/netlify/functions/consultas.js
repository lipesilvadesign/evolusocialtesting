/**
 * CRUD administrativo da Consultoria de Instagram (área "Consultorias" do
 * painel — ETAPA 2). Mesmo padrão de netlify/functions/prospeccao.js:
 * exige sessão real (requireUser), usa o token do PRÓPRIO usuário logado em
 * toda chamada ao Supabase (RLS aplica como ele, nunca uma chave
 * privilegiada). A criação do lead não acontece aqui — é sempre pública,
 * via consultas-criar.js (ver aquele arquivo).
 */

const { requireUser } = require('./_lib/config/authGuard');
const consultasService = require('./_lib/services/consultasService');
const auditLog = require('./_lib/services/auditLogService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      if (query.id) {
        const lead = await consultasService.getById(token, query.id);
        if (!lead) return json(404, { error: 'Consultoria não encontrada.' });
        return json(200, { lead });
      }
      const leads = await consultasService.list(token, { status: query.status });
      return json(200, { leads });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const payload = JSON.parse(event.body || '{}');
      const lead = await consultasService.update(token, query.id, { ...payload, atualizadoPor: user.email });
      await auditLog.record(token, {
        actorId: user.email,
        action: 'update',
        targetType: 'consulta_lead',
        targetId: query.id,
        metadata: payload,
      });
      return json(200, { lead });
    }

    if (event.httpMethod === 'DELETE') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await consultasService.remove(token, query.id);
      await auditLog.record(token, { actorId: user.email, action: 'delete', targetType: 'consulta_lead', targetId: query.id });
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('consultas', 'Falha na operação administrativa', { message: err.message });
    return json(500, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
