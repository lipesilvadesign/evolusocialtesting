/**
 * Envio de e-mail em lote (controlado) pra leads selecionados na aba
 * Prospecção. Cada lead recebe uma versão personalizada do mesmo modelo
 * (variáveis {{empresa}}, {{setor}}, {{cidade}}), um e-mail de cada vez, com
 * pausa entre envios — nunca simultâneo — e nunca ultrapassando o limite
 * diário (EMAIL_PROSPECCAO_LIMITE_DIARIO, padrão 25). Ver umblerSmtp.js
 * pra entender por que esse cuidado existe.
 *
 * Netlify Background Function — nome termina em "-background" de propósito
 * (mesmo padrão de scheduled-sync-background.js): com pausa de alguns
 * segundos entre cada envio, mandar 20+ e-mails facilmente passa dos ~10s de
 * limite de uma Function normal. Responde 202 vazio na hora — por isso o
 * progresso é acompanhado por polling (igual à busca de empresas), não pelo
 * retorno desta chamada.
 *
 * Progresso: grava lead por lead na tabela admin_prospeccao_envios, usando
 * um id que o PRÓPRIO NAVEGADOR gera antes de chamar (crypto.randomUUID()).
 * O painel consulta essa linha por id via prospeccao-envio-status.js
 * (polling) e mostra progresso real — não depende de admin_notificacoes
 * (que pode não estar configurada/visível, como aconteceu na busca).
 */

const { requireUser } = require('./_lib/config/authGuard');
const { env } = require('./_lib/config/env');
const { preencherModelo, leadEstaBloqueado } = require('./_lib/templateUtil');
const prospeccaoService = require('./_lib/services/prospeccaoService');
const auditLog = require('./_lib/services/auditLogService');
const envioStatusService = require('./_lib/services/envioStatusService');
const optoutService = require('./_lib/services/optoutService');
const umblerSmtp = require('./_lib/integrations/umblerSmtp');
const atividadesService = require('./_lib/services/atividadesService');
const logger = require('./_lib/logger');

const PAUSA_ENTRE_ENVIOS_MS = 4000; // evita padrão de disparo automatizado óbvio

// Descadastro (LGPD — VALIDAÇÃO JURÍDICA NECESSÁRIA do texto): todo e-mail de
// prospecção diz como parar de receber e leva o cabeçalho List-Unsubscribe.
const RODAPE_DESCADASTRO = '\n\n—\nSe não quiser receber novos contatos da Felipe Branding, responda este e-mail com "SAIR" e retiramos seu endereço da nossa lista.';

function comDescadastro(corpo) {
  return /\bSAIR\b|descadastr|não quiser receber/i.test(corpo) ? corpo : corpo + RODAPE_DESCADASTRO;
}

function aguardar(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método não permitido.' });

  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Corpo da requisição inválido.' });
  }

  const jobId = payload.jobId;
  const leadIds = Array.isArray(payload.leadIds) ? payload.leadIds.filter(Boolean) : [];
  const assuntoModelo = (payload.assunto || '').trim();
  const corpoModelo = (payload.corpo || '').trim();

  if (!jobId) return json(400, { error: 'Parâmetro "jobId" é obrigatório.' });
  if (!leadIds.length) return json(400, { error: 'Selecione ao menos um lead.' });
  if (!assuntoModelo || !corpoModelo) return json(400, { error: 'Preencha o assunto e o corpo do e-mail.' });

  try {
    await envioStatusService.iniciar(token, { id: jobId, totalSelecionado: leadIds.length, criadoPor: user.email });
  } catch (err) {
    logger.error('prospeccao-enviar-email', 'Falha ao iniciar registro de progresso', { message: err.message });
    return json(200, { error: err.message });
  }

  try {
    const limiteDiario = env.email.dailyLimit();
    const jaEnviadosHoje = await prospeccaoService.countEmailsSentToday(token);
    const vagasHoje = Math.max(0, limiteDiario - jaEnviadosHoje);

    if (vagasHoje === 0) {
      const msg = `Limite diário de ${limiteDiario} e-mails já foi atingido hoje. Tente novamente amanhã (existe pra proteger a conta de e-mail contra bloqueio pela Umbler).`;
      await envioStatusService.marcarErro(token, jobId, msg);
      return json(200, { error: msg });
    }

    const leads = await prospeccaoService.listByIds(token, leadIds);
    const bloqueios = await optoutService.carregarBloqueios(token);
    const bloqueado = (l) => leadEstaBloqueado({ statusContato: l.status_contato, origemId: l.origem_id, email: l.email, telefone: l.telefone }, bloqueios);

    const naoBloqueados = leads.filter((l) => !bloqueado(l));
    const bloqueadosCount = leads.length - naoBloqueados.length;
    const comEmail = naoBloqueados.filter((l) => l.email);
    const semEmail = naoBloqueados.length - comEmail.length;
    const aEnviar = comEmail.slice(0, vagasHoje);
    const adiados = comEmail.length - aEnviar.length;

    let progresso = [];
    let enviados = 0;
    let falhas = 0;

    let naoMarcados = 0;
    for (const lead of aEnviar) {
      let entrada;
      let enviou = false;
      try {
        await umblerSmtp.enviarEmail({
          para: lead.email,
          assunto: preencherModelo(assuntoModelo, lead),
          corpo: comDescadastro(preencherModelo(corpoModelo, lead)),
          listaDescadastro: `mailto:${env.email.smtpUser() || 'marketing@felipebranding.com.br'}?subject=SAIR`,
        });
        enviou = true;
        enviados += 1;
        entrada = { empresa: lead.empresa, ok: true };
      } catch (err) {
        logger.error('prospeccao-enviar-email', 'Falha ao enviar pra um lead', { message: err.message });
        entrada = { empresa: lead.empresa, ok: false, erro: err.message };
        falhas += 1;
        try {
          await prospeccaoService.markEmailSent(token, lead.id, { ok: false, erro: err.message });
        } catch (marcaErr) {
          logger.warn('prospeccao-enviar-email', 'Falha ao registrar erro de envio no lead', { message: marcaErr.message });
        }
      }

      // Envio e registro são coisas diferentes: se o e-mail SAIU e só o
      // registro falhou, NÃO conta como falha (nem pode ser reenviado).
      if (enviou) {
        try {
          await prospeccaoService.markEmailSent(token, lead.id, { ok: true });
          await atividadesService.criar(token, { leadId: lead.id, tipo: 'email_enviado', descricao: `E-mail: ${preencherModelo(assuntoModelo, lead).slice(0, 180)}`, criadoPor: user.email });
        } catch (marcaErr) {
          naoMarcados += 1;
          entrada.aviso = 'Enviado, mas não foi possível registrar no lead';
          logger.warn('prospeccao-enviar-email', 'E-mail enviado, mas o registro no lead falhou', { message: marcaErr.message });
        }
      }

      try {
        progresso = await envioStatusService.atualizarProgresso(token, jobId, progresso, entrada);
      } catch (err) {
        logger.warn('prospeccao-enviar-email', 'Falha ao gravar progresso de um envio', { message: err.message });
      }

      await aguardar(PAUSA_ENTRE_ENVIOS_MS);
    }

    await auditLog.record(token, {
      actorId: user.email,
      action: 'enviar_email_prospeccao',
      targetType: 'lead_prospeccao',
      metadata: { solicitados: leadIds.length, enviados, falhas, naoMarcados, semEmail, adiadosPorLimite: adiados, bloqueadosPorOptout: bloqueadosCount },
    });

    await envioStatusService.concluir(token, jobId, { enviados, falhas, semEmail, adiados, bloqueados: bloqueadosCount });
    return json(200, { ok: true });
  } catch (err) {
    logger.error('prospeccao-enviar-email', 'Falha geral no envio', { message: err.message });
    try {
      await envioStatusService.marcarErro(token, jobId, err.message);
    } catch (statusErr) {
      logger.error('prospeccao-enviar-email', 'Falha ao marcar erro no status', { message: statusErr.message });
    }
    return json(200, { error: err.message });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
