/**
 * Consulta o progresso de um envio de e-mail em andamento (aba Prospecção,
 * botão "Enviar e-mail para selecionados"). Function síncrona normal — só
 * lê uma linha, é rápido. O painel chama isto a cada ~2s.
 */

const { requireUser } = require('./_lib/config/authGuard');
const envioStatusService = require('./_lib/services/envioStatusService');

exports.handler = async function handler(event) {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Método não permitido.' });

  const { token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const id = (event.queryStringParameters || {}).id;
  if (!id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });

  try {
    const envio = await envioStatusService.buscarPorId(token, id);
    return json(200, { envio });
  } catch (err) {
    return json(502, { error: err.message || 'Falha ao consultar progresso.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
