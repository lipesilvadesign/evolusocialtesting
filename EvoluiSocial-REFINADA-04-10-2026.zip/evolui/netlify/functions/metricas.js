/**
 * Métricas do cliente/lead — GET ?leadId= lista, POST cria, DELETE ?id= remove.
 */

const { requireUser } = require('./_lib/config/authGuard');
const metricasService = require('./_lib/services/metricasService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  try {
    if (event.httpMethod === 'GET') {
      const leadId = (event.queryStringParameters || {}).leadId;
      if (!leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });
      const metricas = await metricasService.listarPorLead(token, leadId);
      return json(200, { metricas });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      if (!payload.leadId || !payload.nome) return json(400, { error: 'Informe "leadId" e "nome".' });
      const metrica = await metricasService.criar(token, { ...payload, criadoPor: user.email });
      return json(201, { metrica });
    }

    if (event.httpMethod === 'DELETE') {
      const id = (event.queryStringParameters || {}).id;
      if (!id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await metricasService.remover(token, id);
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('metricas', 'Falha na operação de métrica', { message: err.message });
    return json(502, { error: err.message || 'Falha ao processar métrica.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
