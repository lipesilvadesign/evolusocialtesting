/**
 * CRUD de contatos (pessoas) de um lead — GET ?leadId= lista, POST cria,
 * DELETE ?id= remove. Uma empresa pode ter vários contatos (proprietário,
 * marketing, comercial...).
 */

const { requireUser } = require('./_lib/config/authGuard');
const contatosService = require('./_lib/services/contatosService');
const logger = require('./_lib/logger');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  try {
    if (event.httpMethod === 'GET') {
      const leadId = (event.queryStringParameters || {}).leadId;
      if (!leadId) return json(400, { error: 'Parâmetro "leadId" é obrigatório.' });
      const contatos = await contatosService.listarPorLead(token, leadId);
      return json(200, { contatos });
    }

    if (event.httpMethod === 'POST') {
      const payload = JSON.parse(event.body || '{}');
      if (!payload.leadId || !payload.nome) return json(400, { error: 'Informe "leadId" e "nome".' });
      const contato = await contatosService.criar(token, { ...payload, criadoPor: user.email });
      return json(201, { contato });
    }

    if (event.httpMethod === 'DELETE') {
      const id = (event.queryStringParameters || {}).id;
      if (!id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      await contatosService.remover(token, id);
      return json(200, { ok: true });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    logger.error('prospeccao-contatos', 'Falha na operação de contato', { message: err.message });
    return json(502, { error: err.message || 'Falha ao processar contato.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
