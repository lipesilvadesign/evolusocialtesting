const { requireUser } = require('./_lib/config/authGuard');
const intelligenceService = require('./_lib/services/intelligenceService');
const intelligenceHistoryService = require('./_lib/services/intelligenceHistoryService');
const { AnalyticsError, toHttpStatus } = require('./_lib/errors/analyticsErrors');

const VALID_STATUS = new Set(['novo', 'em_andamento', 'concluido', 'descartado']);

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  try {
    if (event.httpMethod === 'GET') {
      const query = event.queryStringParameters || {};
      const intelligence = await intelligenceService.computeAdvancedIntelligence(token, query);
      return json(200, { intelligence });
    }

    if (event.httpMethod === 'PATCH') {
      const query = event.queryStringParameters || {};
      const { status } = JSON.parse(event.body || '{}');
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      if (!VALID_STATUS.has(status)) {
        return json(400, { error: `"status" inválido. Use um de: ${[...VALID_STATUS].join(', ')}.` });
      }
      const updated = await intelligenceHistoryService.updateStatus(token, query.id, status);
      return json(200, { item: updated });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    if (err instanceof AnalyticsError) {
      console.error('[intelligence] AnalyticsError:', err.code, err.detail);
      return json(toHttpStatus(err.code), { error: err.message, code: err.code });
    }
    console.error('[intelligence] erro inesperado:', err.message);
    return json(500, { error: 'Não foi possível calcular a inteligência avançada.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
