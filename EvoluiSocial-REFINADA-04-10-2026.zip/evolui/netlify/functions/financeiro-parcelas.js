const { requireUser } = require('./_lib/config/authGuard');
const parcelasService = require('./_lib/services/financeiroParcelasService');
const auditLog = require('./_lib/services/auditLogService');

exports.handler = async function handler(event) {
  const { user, token, error } = await requireUser(event);
  if (error) return json(error.statusCode, { error: error.message });

  const query = event.queryStringParameters || {};

  try {
    if (event.httpMethod === 'GET') {
      // Sem contratoId: lista todas (dashboard/"Próximos vencimentos").
      // Com contratoId: só as parcelas daquele contrato (aba do cliente).
      const parcelas = await parcelasService.list(token, query.contratoId || null);
      return json(200, { parcelas });
    }

    if (event.httpMethod === 'PATCH') {
      if (!query.id) return json(400, { error: 'Parâmetro "id" é obrigatório.' });
      const payload = JSON.parse(event.body || '{}');
      const parcela = await parcelasService.updateStatus(token, query.id, payload);
      await auditLog.record(token, {
        actorId: user.email,
        action: 'status_change',
        targetType: 'parcela_financeiro',
        targetId: query.id,
        metadata: { status: payload.status },
      });
      return json(200, { parcela });
    }

    return json(405, { error: 'Método não permitido.' });
  } catch (err) {
    return json(err.message && err.message.startsWith('Falha') ? 502 : 400, { error: err.message || 'Erro inesperado.' });
  }
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}
