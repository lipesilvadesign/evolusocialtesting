/**
 * Mesma URL e chave PÚBLICA (anon/publishable) já usadas em todo o projeto
 * (assets/js/admin.1b9240a4b5.js, assets/js/site.bdacb7b1a8.js). Não é um
 * segredo — é a chave feita pra ser pública. Nenhuma chave privada/service
 * role é usada em nenhuma Function deste projeto.
 */
const SUPABASE_URL = 'https://aligftypgtzlymmditeo.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_lLKYguXwi6isaw1C4X5uiA_25-MT7ym';

module.exports = { SUPABASE_URL, SUPABASE_ANON_KEY };
