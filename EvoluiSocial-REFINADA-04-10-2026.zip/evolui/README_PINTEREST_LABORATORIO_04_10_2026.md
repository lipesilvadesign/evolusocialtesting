# Pinterest no Laboratório — Evolui Social

## O que foi integrado

- Provedor Pinterest no motor de referências do Laboratório, usando o gateway autenticado `evolui-api` (sem função paralela inexistente).
- Uso da API oficial Pinterest Trends, sem scraping.
- Consulta da Evolui continua sendo construída pelo algoritmo interno, considerando tema, ramo, formato, objetivo e contexto disponível.
- Os sinais do Pinterest passam pelo ranking interno das referências, com corte mínimo de relevância para evitar poluição do Laboratório.
- Crescimento WoW do Pinterest adiciona peso ao ranking, sem substituir a relevância contextual.
- Cards com cantos arredondados, identidade visual Evolui e motion leve.
- Botão abre a busca correspondente no Pinterest. Como o endpoint oficial de Trends não é uma busca pública de Pins, o card representa o sinal/tendência e usa a busca nativa do Pinterest como próxima etapa.
- Eventos de seleção/descarte continuam usando o mecanismo existente do Laboratório.

## Limitação importante

A API oficial de Trends fornece palavras-chave e sinais de crescimento; ela não equivale a uma busca pública irrestrita de Pins com miniaturas. Por isso, nesta camada os cards representam **inspirações/tendências do Pinterest** e levam o usuário para a busca correspondente no Pinterest.

A API oficial também restringe o acesso a dados de Pinners/Pins conforme o nível de acesso e aprovações do aplicativo. Não foi usado scraping.

## Secret necessário

Na Edge Function `evolui-api`, configurar:

`PINTEREST_ACCESS_TOKEN`

O token nunca é colocado no frontend nem no GitHub.

## Fallback

Se o secret não existir ou o Pinterest responder com erro/permissão insuficiente, o provedor se desliga e o Laboratório continua funcionando com as demais fontes.

## Correção de arquitetura v3

A versão v3 remove a dependência do endpoint inexistente `evolui-referencias` no navegador. Pinterest e YouTube agora usam a mesma chamada autenticada para `evolui-api`, onde estão suas ações reais. O backend aplica cache de 15 minutos para o ranking de Trends, disjuntor de fonte e timeout de 3,5 s, sem expor o token ao navegador.
