# Auditoria, Arquitetura e Preparação do Sistema
### Resposta ao PROMPT 1 — Felipe Branding

Nenhum arquivo foi alterado nesta etapa. Isto é só levantamento + proposta,
como pedido.

---

## 1. Arquitetura atual

**Stack:** site 100% estático — HTML/CSS/JS puro (vanilla), sem React, sem
bundler, sem passo de build. Hospedagem e backend leve via **Netlify**
(hosting + Functions + Scheduled Functions). Banco/autenticação via
**Supabase** (projeto `aligftypgtzlymmditeo`), acessado por `fetch` direto
ao PostgREST — não usa o SDK do Supabase no backend (só no frontend, para
login).

**Páginas/rotas existentes:**
| Rota | Arquivo | Função |
|---|---|---|
| `/` | `index.html` | Site institucional público |
| `/painel` | `painel/index.html` | Central administrativa nova (SPA, roteamento client-side por hash) |
| `/admin` | `admin.html` | Editor de conteúdo legado — **ainda ativo, não foi substituído** |
| `/consultas` | `consultas.html` | Landing pública standalone (Consultoria Gratuita de Perfil) |

**Estrutura de pastas relevante:**
```
/
├── index.html, admin.html, consultas.html
├── assets/{css,js,img}          # site público
├── painel/assets/js/
│   ├── app.js                   # router (hash-based)
│   ├── views/                   # 1 arquivo por tela do painel
│   ├── components/               # UI reutilizável (Toast, Drawer, TaskBoard...)
│   ├── services/                # clients HTTP (1 por domínio)
│   └── content-schemas.js       # schema genérico de conteúdo (ver §1.4)
└── netlify/functions/
    ├── _lib/services/           # 1 service por tabela/domínio
    ├── _lib/config/             # auth, env, supabase, supabaseServiceRole
    ├── _lib/integrations/       # GA4, IA, Geoapify, SMTP, OSM
    └── *.js                     # 1 Function por endpoint
```

**Componentes reutilizáveis já existentes** (`painel/assets/js/components/`):
`Toast`, `Drawer`, `ConfirmDialog`, `EmptyState`/`LoadingState`/`ErrorState`,
`StatusBadge`, `ContentEditor` (formulário genérico com upload de imagem
embutido em base64), `TaskBoard`, `NotificationsList`, `HealthStatusCard`,
`InsightCard`, `IntelligenceBoard`, `AiAnalysisCard`, `DateRangeSelector`.

**Autenticação:** Supabase Auth (e-mail/senha), uma única conta/organização
— não há multiusuário real hoje. `painel/index.html` e `admin.html` usam o
**mesmo** projeto Supabase e as mesmas contas (login único). Dupla camada de
segurança: o front esconde/mostra UI (`rbac.js`), mas cada Netlify Function
valida o token de sessão de verdade contra o Supabase Auth
(`_lib/config/authGuard.js`) antes de fazer qualquer coisa — a interface
nunca é a única barreira.

**RBAC:** a arquitetura já foi deixada preparada (comentários em `auth.js` e
`rbac.js` citam Administrator/Editor/Analyst/Viewer), mas **não existe
ainda** tabela `profiles`/coluna `role` — toda conta autenticada tem acesso
total. Isto é relevante direto pro módulo `funcionarios` que este prompt
pede.

**Tabelas Supabase existentes** (via `information_schema` já confirmado em
`admin_prospeccao_leads`; as demais eu levantei por referência no código —
ver risco R1 abaixo):

| Tabela | Usada por | Observação |
|---|---|---|
| `site_content` | conteúdo do site público | 1 linha só (`id=1`), JSON com `portfolio`, `services`, `partners`, hero/founder/about/etc. |
| `admin_posts`, `admin_pages` | Conteúdo (Posts/Páginas) | tabelas próprias (não são array dentro de `site_content`) |
| `admin_tarefas` | módulo Tarefas | — |
| `admin_notificacoes` | notificações do painel | — |
| `admin_settings` | Configurações | 1 linha, JSON |
| `admin_audit_log` | trilha de auditoria (quem fez o quê) | já existe! reaproveitável pro módulo `funcionarios`/permissões |
| `admin_ai_usage` | uso da IA (custo/quota) | — |
| `admin_insights_historico` | histórico de insights gerados por IA | — |
| `admin_relatorios` | relatórios agendados (semanal/mensal) | — |
| `admin_prospeccao_leads` | **CRM de prospecção B2B** — já tem `score`, `cnpj`, `status_lead`, `status_contato`, `prioridade`, sinais (`sinal_site_desatualizado` etc.), `problema_identificado`, `oferta_recomendada` | **isto já É um proto-CRM** — ver §2 |
| `admin_prospeccao_contatos` | contatos vinculados a um lead | — |
| `admin_prospeccao_atividades` | histórico de atividades por lead | — |
| `admin_prospeccao_buscas` | status de buscas automáticas de empresas | — |
| `admin_prospeccao_envios` | status de envio de e-mail em massa | — |
| `admin_prospeccao_optouts` | opt-out de e-mail (LGPD) | — |
| `consultas_leads` | leads do formulário público `/consultas` (diagnóstico de Instagram) | tem policy especial pra `anon` inserir |
| `consultas_atividades` | atividades por lead de consultoria | — |

**RLS observado:** padrão em todas as tabelas administrativas é
`auth.role() = 'authenticated'` pode ler/escrever tudo (sem diferenciação
de dono/role). Exceção: `consultas_leads`/`consultas_atividades` têm
policies extras liberando `insert` para `anon` (necessário pro formulário
público funcionar sem login).

**Funções (Netlify Functions), por domínio:**
- **Conteúdo:** `content-array.js` (genérico: projetos/serviços/**parceiros**
  dentro de `site_content`), `content-collection.js` (posts/páginas, tabela
  própria), `content-overview.js`.
- **Prospecção/CRM:** `prospeccao.js` (CRUD leads), `prospeccao-contatos.js`,
  `prospeccao-atividades.js`, `prospeccao-buscar-empresas.js` +
  `-background.js` (Geoapify, sob demanda), `prospeccao-sync-osm.js`
  (OpenStreetMap, `@weekly`), `prospeccao-busca-status.js`,
  `prospeccao-enviar-email-background.js`, `prospeccao-envio-status.js`,
  `prospeccao-optout.js`, `prospeccao-relatorio.js`.
- **Consultorias:** `consultas.js`, `consultas-criar.js` (pública),
  `consultas-atividades.js`, `consultas-evento.js`.
- **Analytics/IA:** `analytics-overview.js`, `analytics-ga.js` (Google
  Analytics Data API, service account), `analytics-insights.js`,
  `ai-insights.js`, `intelligence.js`.
- **Operação:** `tasks.js`, `notifications.js`, `settings.js`, `system.js`
  (auditoria + uso de IA), `health.js` (healthcheck), `reports.js`,
  `scheduled-sync-background.js` (`@hourly`).

**Integrações externas configuradas:**
| Integração | Uso | Chave (env var) |
|---|---|---|
| Google Analytics Data API | Analytics do painel | `GA_SERVICE_ACCOUNT_JSON`, `GA_PROPERTY_ID` |
| Anthropic API | Insights por IA | `AI_API_KEY` |
| Geoapify | Busca manual de empresas (Prospecção) | `GEOAPIFY_API_KEY` |
| Google Places | código existe, **não usado** (Geoapify escolhido no lugar) | `GOOGLE_PLACES_API_KEY` |
| OpenStreetMap/Overpass | Busca automática semanal, gratuita | nenhuma |
| SMTP Umbler (raw, sem lib) | Envio de e-mail da Prospecção | `UMBLER_SMTP_USER/PASS` |
| Notion | **mencionada em sessões anteriores, arquivos de sync entregues, mas não estão neste código** — ver risco R2 | — |

**Sistema atual de usuários:** não existe módulo de equipe/funcionários.
Todas as contas Supabase Auth têm acesso idêntico e total. `admin_audit_log`
já registra `actorId` (e-mail) por ação — dá pra construir cima disso.

**Módulos já existentes no painel (equivalente ao `/admin` pedido):**
Visão Geral, Analytics, Insights (IA), Conteúdo (Posts/Projetos/Serviços/
**Marcas Parceiras**/Páginas), **Prospecção** (CRM de leads B2B — já com
score, CNPJ, sinais, pipeline de status), **Consultorias** (leads do
diagnóstico de Instagram, com pipeline próprio), Configurações, Sistema
(auditoria + uso de IA + relatórios).

---

## 2. Diagnóstico central antes de propor qualquer coisa

**A estrutura pedida no prompt já existe parcialmente — com outros nomes.**
Isto muda a proposta:

| Pedido no prompt | Já existe como | O que fazer |
|---|---|---|
| `/admin/leads` | `admin_prospeccao_leads` + tela **Prospecção** | **reaproveitar**, não recriar |
| `/admin/prospeccao` | idem — busca automática (OSM/Geoapify) já embutida na mesma tela | **é a mesma coisa**, não um módulo separado |
| `/admin/diagnosticos` | `consultas_leads` (diagnóstico de Instagram) + campos `problema_identificado`/`sinal_*` já em `admin_prospeccao_leads` | **unificar conceito**, não duplicar |
| `/admin/clientes` | **não existe** — hoje um lead "convertido" (`status_lead = 'cliente'`) continua na mesma tabela de leads, sem virar outra entidade | **criar** (ver §4) |
| `/admin/briefings` | **não existe** | **criar** |
| `/admin/apresentacoes` + `/apresentacao/[cliente]` | **não existe** | **criar** |
| `/admin/funcionarios` | **não existe** (auth é single-tenant) | **criar**, com cautela (ver riscos) |
| `/admin/configuracoes` | já existe (`admin_settings`) | **reaproveitar** |
| `/admin/dashboard` | já existe (`Visão Geral`) | **reaproveitar** |

---

## 3. Arquitetura proposta

Não uma reestruturação de pastas (o padrão atual — 1 view + 1 client + 1
Function + 1 service por domínio — já é modular e está funcionando bem, os
últimos módulos entregues seguiram exatamente ele). A proposta é **estender
o mesmo padrão** para os módulos que faltam, e **ligar** os que já existem
em vez de duplicá-los:

```
painel/                                  (sem mudança de nome/URL — é o /admin conceitual)
├── views/
│   ├── overview.js            [existe]  → dashboard
│   ├── prospeccao.js          [existe]  → leads (é o módulo "leads")
│   ├── consultorias.js        [existe]  → um dos tipos de "diagnóstico"
│   ├── clientes.js            [NOVO]
│   ├── briefings.js           [NOVO]
│   ├── apresentacoes.js       [NOVO]
│   ├── funcionarios.js        [NOVO]
│   └── configuracoes.js       [existe]
/apresentacao/[slug]/                    [NOVO] página pública, fora do painel,
                                          renderizada a partir de admin_apresentacoes
```

**Fluxo conceitual proposto** (reaproveitando o que já existe):

```
admin_prospeccao_leads (existe)
        │  status_lead = 'cliente'
        ▼
admin_clientes (NOVO) ── 1:N ── admin_briefings (NOVO)
        │                              │
        │                              ▼
        │                    admin_apresentacoes (NOVO) ──► /apresentacao/[slug] (público)
        ▼                                                          │
  admin_prospeccao_contatos/atividades (existe, reaproveitado)     ▼
                                                              export PDF (client-side,
                                                              sem lib nova — ver §6)
```

---

## 4. Tabelas existentes que serão reaproveitadas (sem alteração de schema)

- `admin_prospeccao_leads` — continua sendo a fonte única de leads/prospecção.
  Ganha 1 coluna nova (`cliente_id`, nullable) só quando o lead vira cliente
  — não duplica dado.
- `admin_prospeccao_contatos`, `admin_prospeccao_atividades` — reaproveitadas
  como histórico de contato tanto de leads quanto (depois) de clientes.
- `admin_audit_log` — base pronta pra log de ações por usuário, essencial
  pro módulo `funcionarios`/permissões.
- `admin_settings` — configurações gerais continuam aqui.
- `consultas_leads` — não precisa virar outra coisa; um diagnóstico de
  Instagram pode simplesmente **gerar** um registro em `admin_briefings`
  quando fizer sentido, via referência (`origem_tipo`/`origem_id`), sem
  mexer na tabela.

## 5. Tabelas que realmente precisam ser criadas

| Tabela | Por quê não dá pra reaproveitar algo existente |
|---|---|
| `admin_clientes` | Não existe conceito de "cliente" separado de "lead" hoje — sem isso, converter um lead perde a distinção entre prospecção e relação ativa (contrato, recorrência, dados de faturamento não pertencem à tabela de leads). |
| `admin_briefings` | Estrutura de formulário (perguntas/respostas) não tem equivalente — os campos de diagnóstico do lead são sinais automáticos, não briefing preenchido pelo cliente. |
| `admin_apresentacoes` | Precisa de um `slug` público, controle de o que fica visível na página `/apresentacao/[slug]`, e não pode ficar dentro de `site_content` (isso é conteúdo do site institucional, não de clientes individuais). |
| `admin_funcionarios` (ou `profiles`) | RBAC real exige ligar `auth.users.id` a um papel — hoje isso não existe em lugar nenhum, é o pré-requisito de tudo que envolve "equipe/permissões". |

Todas as quatro seguem o mesmo padrão das últimas (RLS com
`authenticated` + service, `id uuid default gen_random_uuid()`, `created_at`/
`updated_at`) — nenhuma novidade arquitetural, só extensão do que já roda.

## 6. Riscos

- **R1 — Verificação de schema incompleta.** Eu não tenho acesso direto ao
  banco nesta sessão (o Supabase conectado aqui é de outro projeto). As
  colunas exatas de `admin_tarefas`, `admin_notificacoes`, `admin_settings`,
  `admin_audit_log`, `admin_ai_usage`, `admin_insights_historico`,
  `admin_relatorios`, `admin_posts`, `admin_pages` foram inferidas pelo
  código, **não confirmadas** via `information_schema` (só fiz isso, com
  sucesso, para `admin_prospeccao_leads` numa etapa anterior). Recomendo
  rodar a mesma consulta pras tabelas centrais antes da Etapa 2, pra eu não
  propor uma coluna que já existe com outro nome.
- **R2 — Integração com Notion mencionada, mas ausente do código.** Existem
  registros de um SQL (`notion_page_id` + trigger `pg_net`) e uma Function
  (`sync-lead-notion.js`) terem sido **entregues** em sessão anterior, mas
  **nenhum dos dois está neste `Site.zip`** — ou não foram aplicados, ou
  foram perdidos. Preciso de confirmação antes de assumir que essa
  integração está ativa.
- **R3 — `package.json` inconsistente.** Ainda lista `nodemailer` como
  dependência, mas o código já usa um cliente SMTP próprio
  (`_lib/integrations/rawSmtp.js`) sem essa lib. Não quebra nada (o
  `nodemailer` só fica instalado sem uso), mas é sujeira que vale limpar
  numa etapa de manutenção.
- **R4 — RBAC real é um risco de segurança, não só de produto.** Criar
  `admin_funcionarios` sem também **mudar as policies de RLS** das outras
  tabelas dá uma falsa sensação de controle de acesso — hoje QUALQUER conta
  autenticada já pode tudo em QUALQUER tabela; adicionar uma tela de
  "funcionários" sem revisar isso não restringe nada de verdade.
- **R5 — Volume de dados de prospecção já é grande.** `admin_prospeccao_leads`
  já passou por 4 rodadas de expansão nesta conversa (~180+ leads,
  múltiplos setores/cidades). Migrar/filtrar quem vira `admin_clientes`
  precisa de um critério explícito (ex.: só `status_lead = 'cliente'`) pra
  não converter lead em massa por engano.

## 7. Ordem recomendada de implementação

1. **Confirmar schema real** das tabelas centrais (R1) — uma consulta
   `information_schema`, como já fizemos antes. Base de tudo que vem depois.
2. **`admin_clientes`** — é o elo que falta entre o que já existe
   (prospecção) e os módulos novos (briefing/apresentação dependem de "pra
   qual cliente").
3. **`admin_briefings`** — depende só de `admin_clientes` existir.
4. **`admin_apresentacoes` + rota pública `/apresentacao/[slug]`** — depende
   de briefing existir (é o que alimenta a apresentação).
5. **Exportação em PDF** da apresentação — client-side (`window.print()` com
   CSS de impressão dedicado, ou biblioteca leve tipo jsPDF via CDN) para
   **não** introduzir dependência de build/servidor nova, mantendo a
   filosofia atual de site estático.
6. **`admin_funcionarios`/RBAC real** por último, de propósito — é a
   mudança de maior risco (R4) e a que mais se beneficia de todo o resto já
   estar estável, porque exige revisar RLS de **todas** as tabelas listadas
   no §1, não só criar uma tabela nova.

---

**Não implementei nada disso ainda** — este documento é a especificação
pedida pelo PROMPT 1. Me diga se quer que eu comece pela etapa 1 (confirmar
schema) ou se já quer seguir direto pra `admin_clientes`.
