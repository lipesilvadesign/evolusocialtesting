# Equipe, Permissões e Segurança
### Resposta ao PROMPT 4

## Princípio seguido

**Negar por padrão, liberar o necessário.** Antes desta etapa, qualquer
conta autenticada no Supabase tinha acesso total a tudo — a partir de
agora, só ter login não significa mais nada: o que a pessoa pode fazer
depende inteiramente da linha dela em `admin_funcionarios` (papel + estar
ativa).

**A barreira real é o RLS do Postgres, não a interface.** Todas as Netlify
Functions deste projeto já usavam o token da própria sessão do usuário para
falar com o Supabase (nunca uma chave privilegiada) — isso significa que o
RLS escrito nesta etapa vale mesmo que alguém pule a interface inteira e
chame a Function, ou o Supabase REST, diretamente com um token válido de
uma conta com papel restrito. A única exceção documentada é o convite de
novo funcionário (explicado abaixo), que precisa de privilégio elevado por
natureza (criar conta no Supabase Auth) — e mesmo essa exceção confere se
quem está pedindo já é admin, usando o token normal dele, **antes** de
tocar na chave privilegiada.

---

## 1. Roles

| Role | O que é |
|---|---|
| `admin` | Acesso total — a mesma coisa que "estar logado" significava antes desta etapa. |
| `prospeccao` | Cuida de leads/clientes atribuídos a ela: contatos, atividades, briefing, métricas. |
| `design` | Cuida do lado visual dos clientes atribuídos a ela: briefing (leitura/escrita) e apresentação (rascunho — não publica). |

Cada conta do Supabase Auth tem **no máximo uma** linha em
`admin_funcionarios`, e portanto um único papel. Não há papéis compostos
nesta etapa (ex.: "prospecção + design" para a mesma pessoa) — se isso for
necessário no futuro, é uma extensão de schema, não uma mudança de
filosofia.

Toda conta que já existia antes desta migração foi automaticamente
cadastrada como `admin` (ver `SQL_PENDENTE_equipe_permissoes.sql`, passo 1)
— ninguém perde acesso ao rodar o script.

---

## 2. Tabelas afetadas

| Tabela | O que mudou |
|---|---|
| `admin_funcionarios` | **Nova.** `id` é o mesmo `auth.users.id` — é isso que permite toda policy comparar direto com `auth.uid()`. |
| `admin_prospeccao_leads` | Nova coluna `responsavel_id` (uuid → `admin_funcionarios`). É essa coluna, não a antiga `responsavel_interno` (texto livre), que decide quem enxerga o quê. RLS reescrita. |
| `admin_prospeccao_contatos`, `admin_prospeccao_atividades` | RLS reescrita — segue o lead pai (`admin_pode_ver_lead`). |
| `admin_briefings` | RLS reescrita — leitura de quem enxerga o lead; escrita de admin + prospecção + design. |
| `admin_metricas` | RLS reescrita — leitura de quem enxerga o lead; escrita de admin + prospecção só. |
| `admin_diagnosticos` | RLS reescrita — só admin cria/edita/publica; prospecção/design só leem versões **publicadas** de um lead deles. |
| `admin_apresentacoes` | RLS reescrita — design monta/edita **rascunho** de um lead atribuído; só admin publica. A policy pública (`anon`, `status='publicado'`) continua intocada. |
| `admin_settings`, `admin_posts`, `admin_pages`, `site_content`, `admin_tarefas`, `admin_relatorios`, `admin_ai_usage`, `admin_insights_historico` | Restritas a `admin` — nenhum outro papel tem qualquer acesso (nem leitura). |
| `consultas_leads`, `consultas_atividades` | Leitura/escrita autenticada restrita a `admin`; as policies **públicas** (`anon`, formulário `/consultas`) foram recriadas idênticas às originais. |
| `admin_audit_log` | Qualquer funcionário ativo pode **inserir** (registrar a própria ação); **ler** a trilha completa é só admin. |
| `admin_notificacoes` | Não alterada nesta etapa (não tem dono individual hoje). |

Duas funções auxiliares novas no Postgres (`admin_funcionario_role()`,
`admin_eh_admin()`, `admin_pode_ver_lead(uuid)`) — são `security definer`
de propósito, pra decidir RLS sem cair em recursão ao consultar a própria
`admin_funcionarios`.

---

## 3. Matriz de permissões

| Ação | admin | prospecção | design |
|---|---|---|---|
| Visualizar cliente | Todos | Só atribuído | Só atribuído |
| Criar cliente | Sim | Sim, já atribuído a si mesmo | Não |
| Editar cliente | Sim | Só atribuído | Não |
| Excluir cliente | Sim | **Não** | **Não** |
| Ver contatos/atividades | Sim | Só atribuído | **Não** |
| Ver métricas | Sim | Só atribuído | **Não** |
| Registrar métrica | Sim | Só atribuído | **Não** |
| Ver briefing | Sim | Só atribuído | Só atribuído |
| Editar briefing | Sim | Só atribuído | Só atribuído |
| Criar/editar diagnóstico | Sim | **Não** | **Não** |
| Ver diagnóstico | Sim (rascunho e publicado) | Só publicado, de lead atribuído | Só publicado, de lead atribuído |
| Criar/editar apresentação (rascunho) | Sim | **Não** | Só atribuído |
| Publicar apresentação | Sim | **Não** | **Não** |
| Gerar PDF | Sim | Só de cliente atribuído | Só de cliente atribuído |
| Gerenciar usuários (convidar/revogar/mudar papel) | Sim | **Não** | **Não** |
| Gerenciar configurações | Sim | **Não** | **Não** |
| Ver conteúdo do site/CMS | Sim | **Não** | **Não** |
| Ler trilha de auditoria completa | Sim | **Não** (só a própria ação é registrada) | **Não** |

---

## 4. Fluxo de autorização

```
Usuário faz login (Supabase Auth)
        │
        ▼
auth.js busca admin_funcionarios WHERE id = auth.uid()
   (mesma RLS de sempre — não é uma chamada especial)
        │
        ├─ sem linha, ou ativo=false  →  role = 'sem_acesso'
        │        │
        │        ▼
        │   app.js mostra "Acesso não configurado" — nunca entra no painel
        │
        └─ linha ativa encontrada  →  role = 'admin' | 'prospeccao' | 'design'
                 │
                 ▼
        app.js decide o que MOSTRAR (nav, rotas) com base no papel
        (rbac.js — só UX, pode ser "enganado" pelo navegador)
                 │
                 ▼
        Toda ação de dado passa por uma Netlify Function, que usa o
        TOKEN DA PRÓPRIA SESSÃO (nunca uma chave privilegiada) pra falar
        com o Supabase REST
                 │
                 ▼
        O Postgres aplica RLS como aquele usuário de verdade — mesmo que
        a Function/frontend "deixasse passar" algo por engano, o banco
        recusa a linha que a pessoa não deveria tocar
```

A única rota que foge desse fluxo é `funcionarios-convidar.js` (criar uma
conta nova exige privilégio de admin do Supabase Auth, não tem como fazer
isso com RLS comum) — e mesmo essa Function confere, com o token normal do
chamador, se ele é admin **antes** de usar a chave privilegiada. Ver
comentário no topo daquele arquivo.

---

## 5. Cenários de teste pedidos pelo prompt

| Cenário | O que deveria acontecer | Onde isso é garantido |
|---|---|---|
| Funcionário de prospecção tenta abrir cliente não atribuído | A lista de Clientes nem mostra a linha (RLS filtra no SELECT); acessando `#/clientes/<id>` direto, `fetchLeads()` não traz aquele registro → tela mostra "Cliente não encontrado" | Policy `select_leads` |
| Funcionário tenta consultar dados de outro funcionário | `listarFuncionarios()` só devolve a própria linha (quem não é admin não vê a lista da equipe) | Policy `select_propria_linha_ou_admin` em `admin_funcionarios` |
| Funcionário tenta alterar configuração | Tela `/configuracoes` nem carrega pra quem não é admin (rota protegida em `app.js`); mesmo chamando a Function direto, `admin_settings` só aceita escrita de admin | Rota `somenteAdmin` em `app.js` + policies de `admin_settings` |
| Funcionário tenta excluir cliente | Botão "Excluir" nem aparece pra quem não é admin (`prospeccao.js`); mesmo chamando a Function direto, o `DELETE` em `admin_prospeccao_leads` não afeta nenhuma linha pra quem não é admin | Policy `delete_leads` |
| Funcionário tenta acessar informações internas (ex.: diagnóstico em rascunho) | `admin_diagnosticos` só libera leitura de versão `publicado` pra quem não é admin | Policy `select_diagnosticos` |
| Funcionário autorizado acessa cliente atribuído | Funciona normalmente — vê a linha na lista, abre a página, edita o que o papel dele permite | Mesmas policies acima, condição `responsavel_id = auth.uid()` satisfeita |

**Não testei isso rodando de verdade** (não tenho como criar uma segunda
conta de teste e logar como ela nesta sessão) — testei a **lógica** das
policies linha a linha, mas recomendo fortemente criar uma conta de teste
com papel `prospeccao`, atribuir um cliente a ela e a ela mesma tentar
esses 6 cenários manualmente antes de confiar cegamente nisto em produção.

---

## 6. O que ficou de fora, de propósito

- **Papéis compostos** (uma pessoa com mais de um papel) — não pedido, não implementado.
- **Auditoria com diff de antes/depois** — `admin_audit_log` já registra `metadata`, mas não captura automaticamente o valor anterior de cada campo alterado.
- **Reset de senha assistido pelo admin** — hoje quem perde a senha usa o fluxo padrão do Supabase Auth (não construí uma tela própria pra isso).
- **Papel `design` não foi detalhado no prompt** — o escopo que dei a ele (ver matriz) é minha interpretação razoável a partir do nome e do contexto (mexe em briefing/apresentação, não em prospecção/dado comercial). Ajustável com uma edição pontual de policy, se não for o que você tinha em mente.
