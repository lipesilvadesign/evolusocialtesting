-- ============================================================
-- Reformulação do fluxo de Prospecção — estados rápidos + registro
-- automático honesto (WhatsApp) + histórico consolidado
-- ============================================================
-- ADITIVO e não-destrutivo: nenhuma coluna, linha ou tabela existente é
-- removida ou reescrita. Só amplia os valores permitidos em duas colunas
-- que já existem, para os novos botões de ação rápida do painel.
-- Ainda NÃO foi aplicado em produção (mesmo padrão dos demais
-- SQL_PENDENTE_*.sql deste projeto) — precisa ser rodado no Supabase antes
-- de "Interessado" e o registro automático de WhatsApp funcionarem de
-- verdade contra o banco real.

-- 1) Novo estágio "interessado" no funil de prospecção, entre "respondeu" e
-- "reuniao_marcada". Não afeta nenhuma linha existente (só adiciona um valor
-- a mais à lista permitida).
alter table admin_prospeccao_leads
  drop constraint if exists admin_prospeccao_leads_status_check;
alter table admin_prospeccao_leads
  add constraint admin_prospeccao_leads_status_check
  check (status in (
    'novo_lead','contatado','respondeu','interessado',
    'reuniao_marcada','proposta_enviada','cliente','nao_convertido'
  ));

-- 2) Tipo de atividade genérico "mudanca_status", usado pelas ações rápidas
-- que não têm um tipo mais específico já existente (ex.: marcar como
-- Interessado ou Convertido). Aproveitado também para corrigir uma
-- divergência encontrada na auditoria: o código
-- (netlify/functions/_lib/services/atividadesService.js) já permite há mais
-- tempo os tipos "briefing_atualizado", "diagnostico_criado",
-- "diagnostico_publicado" e "apresentacao_enviada", mas esta tabela nunca
-- havia sido migrada para aceitá-los — qualquer tentativa de gravar um
-- desses tipos estaria falhando silenciosamente contra a constraint antiga.
-- Esta migração corrige isso, sem remover nenhum valor que já era aceito.
alter table admin_prospeccao_atividades
  drop constraint if exists admin_prospeccao_atividades_tipo_check;
alter table admin_prospeccao_atividades
  add constraint admin_prospeccao_atividades_tipo_check
  check (tipo in (
    'email_enviado','whatsapp_enviado','ligacao','follow_up','resposta_recebida',
    'reuniao_marcada','reuniao_realizada','proposta_enviada','negociacao','nota',
    'mudanca_status',
    'briefing_atualizado','diagnostico_criado','diagnostico_publicado','apresentacao_enviada'
  ));

-- 3) Guarda o estado anterior/novo quando a atividade é uma mudança de
-- status — aditivo, colunas novas e opcionais, nada quebra para atividades
-- antigas (ficam null). É o que permite montar a timeline "status alterado
-- de X para Y" sem precisar adivinhar a partir da descrição em texto livre.
alter table admin_prospeccao_atividades
  add column if not exists status_anterior text,
  add column if not exists status_novo text;

comment on column admin_prospeccao_atividades.status_anterior is 'Preenchido só em atividades tipo=mudanca_status (ou tipos que também mudam o status, como resposta_recebida/reuniao_marcada) — estágio do lead antes da ação.';
comment on column admin_prospeccao_atividades.status_novo is 'Preenchido só em atividades tipo=mudanca_status (ou tipos que também mudam o status) — estágio do lead depois da ação.';
