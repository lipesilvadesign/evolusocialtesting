-- ================================================================
-- Evolui Social — pacote aditivo consolidado EKE + Inteligência
-- comportamental agregada + EVI Video Intelligence
-- Data: 04/10/2026
--
-- EXECUTAR UMA ÚNICA VEZ no Supabase SQL Editor.
-- Não contém tokens, chaves de API ou dados pessoais novos.
-- ================================================================

create extension if not exists pgcrypto;

-- ----------------------------------------------------------------
-- 1) EKE — Evolui Knowledge Engine
-- ----------------------------------------------------------------
create table if not exists public.evolui_conhecimento (
  id uuid primary key default gen_random_uuid(),
  termo text not null,
  entidade text not null,
  tipo text not null default 'conceito',
  significados jsonb not null default '[]'::jsonb,
  termos_relacionados text[] not null default '{}',
  contexto text,
  confianca numeric(5,4) not null default 0.5 check (confianca between 0 and 1),
  status text not null default 'provisorio'
    check (status in ('provisorio','validado','desambiguacao')),
  fontes jsonb not null default '[]'::jsonb,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now(),
  unique (termo, entidade)
);

create index if not exists evolui_conhecimento_termo_idx
  on public.evolui_conhecimento
  using gin (to_tsvector('simple', termo || ' ' || entidade || ' ' || coalesce(contexto,'')));

create index if not exists evolui_conhecimento_tipo_idx
  on public.evolui_conhecimento (tipo, atualizado_em desc);

alter table public.evolui_conhecimento enable row level security;
revoke all on public.evolui_conhecimento from anon, authenticated;
grant all on public.evolui_conhecimento to service_role;

-- ----------------------------------------------------------------
-- 2) Inteligência comportamental agregada
-- ----------------------------------------------------------------
create table if not exists public.evolui_comportamento_agregado (
  id bigint generated always as identity primary key,
  dia date not null default current_date,
  tema text not null,
  ramo text not null default '',
  origem text not null default 'pesquisa',
  volume integer not null default 0 check (volume >= 0),
  criado_em timestamptz not null default now(),
  unique (dia, tema, ramo, origem)
);

create index if not exists idx_evolui_comportamento_agregado_tema_dia
  on public.evolui_comportamento_agregado (tema, dia desc);

alter table public.evolui_comportamento_agregado enable row level security;
drop policy if exists evolui_comportamento_agregado_deny_all on public.evolui_comportamento_agregado;
create policy evolui_comportamento_agregado_deny_all
  on public.evolui_comportamento_agregado
  for all using (false) with check (false);

revoke all on public.evolui_comportamento_agregado from anon, authenticated;
grant all on public.evolui_comportamento_agregado to service_role;

create or replace function public.evolui_registrar_sinal_agregado(
  p_tema text,
  p_ramo text default null,
  p_origem text default 'pesquisa'
) returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if nullif(trim(p_tema), '') is null then
    return;
  end if;
  insert into public.evolui_comportamento_agregado (dia, tema, ramo, origem, volume)
  values (
    current_date,
    left(trim(p_tema), 160),
    left(trim(coalesce(p_ramo,'')), 120),
    left(trim(coalesce(p_origem,'pesquisa')), 40),
    1
  )
  on conflict (dia, tema, ramo, origem)
  do update set volume = public.evolui_comportamento_agregado.volume + 1;
end;
$$;

create or replace function public.evolui_obter_sinais_agregados(
  p_tema text,
  p_ramo text default null,
  p_dias integer default 30
) returns table (
  tema text,
  ramo text,
  periodo text,
  volume_atual integer,
  volume_anterior integer,
  crescimento numeric,
  confianca numeric
)
language sql
security definer
set search_path = public
as $$
  with atual as (
    select
      lower(trim(tema)) as tema,
      max(ramo) as ramo,
      coalesce(sum(volume) filter (where dia >= current_date - 6),0)::int as v_atual,
      coalesce(sum(volume) filter (where dia between current_date - 13 and current_date - 7),0)::int as v_ant
    from public.evolui_comportamento_agregado
    where lower(trim(tema)) = lower(trim(p_tema))
      and (p_ramo is null or lower(coalesce(ramo,'')) = lower(trim(p_ramo)))
      and dia >= current_date - greatest(7, least(coalesce(p_dias,30), 90))
    group by lower(trim(tema))
  )
  select
    tema,
    ramo,
    '7d_vs_7d'::text,
    v_atual,
    v_ant,
    case when v_ant > 0 then round(((v_atual - v_ant)::numeric / v_ant) * 100, 2) else null end,
    case when v_atual >= 10 then 0.9 when v_atual >= 5 then 0.8 else 0.7 end
  from atual
  where v_atual >= 3;
$$;

revoke all on function public.evolui_registrar_sinal_agregado(text,text,text) from public;
revoke all on function public.evolui_obter_sinais_agregados(text,text,integer) from public;
grant execute on function public.evolui_registrar_sinal_agregado(text,text,text) to service_role;
grant execute on function public.evolui_obter_sinais_agregados(text,text,integer) to service_role;

-- ----------------------------------------------------------------
-- 3) EVI — Evolui Video Intelligence
-- ----------------------------------------------------------------
create table if not exists public.evolui_video_analises (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  url text not null,
  plataforma text not null default 'video',
  algoritmo text not null default 'evi-video-v1',
  titulo text,
  tema text,
  formato text,
  transcricao text,
  transcricao_meta jsonb not null default '{}'::jsonb,
  estrutura jsonb not null default '[]'::jsonb,
  retorica jsonb not null default '{}'::jsonb,
  ritmo jsonb not null default '{}'::jsonb,
  cenas jsonb not null default '[]'::jsonb,
  sinais_visuais jsonb not null default '{}'::jsonb,
  dna jsonb not null default '{}'::jsonb,
  lacunas jsonb not null default '[]'::jsonb,
  oportunidades jsonb not null default '[]'::jsonb,
  evi_score jsonb not null default '{}'::jsonb,
  impressao_digital text,
  ajuste_contextual_observavel jsonb not null default '{}'::jsonb,
  proveniencia jsonb not null default '{}'::jsonb,
  criado_em timestamptz not null default now()
);

alter table public.evolui_video_analises
  add column if not exists impressao_digital text,
  add column if not exists ajuste_contextual_observavel jsonb not null default '{}'::jsonb,
  add column if not exists transcricao_meta jsonb not null default '{}'::jsonb,
  add column if not exists proveniencia jsonb not null default '{}'::jsonb;

create index if not exists idx_evi_video_analises_user_data
  on public.evolui_video_analises(user_id, criado_em desc);
create index if not exists idx_evi_video_analises_tema
  on public.evolui_video_analises(tema);
create index if not exists idx_evi_video_analises_algoritmo
  on public.evolui_video_analises(algoritmo, criado_em desc);

alter table public.evolui_video_analises enable row level security;
drop policy if exists evi_video_select_own on public.evolui_video_analises;
create policy evi_video_select_own
  on public.evolui_video_analises
  for select to authenticated
  using (auth.uid() = user_id);

drop policy if exists evi_video_delete_own on public.evolui_video_analises;
create policy evi_video_delete_own
  on public.evolui_video_analises
  for delete to authenticated
  using (auth.uid() = user_id);

revoke all on public.evolui_video_analises from anon;
revoke insert, update, delete on public.evolui_video_analises from authenticated;
grant select, delete on public.evolui_video_analises to authenticated;
grant all on public.evolui_video_analises to service_role;

comment on table public.evolui_conhecimento is
  'EKE: conhecimento adquirido com proveniência; sem acesso direto do cliente.';
comment on table public.evolui_comportamento_agregado is
  'Volumes agregados de uso para inteligência do produto; não armazena user_id.';
comment on table public.evolui_video_analises is
  'EVI: memória estruturada de análises de vídeo por usuário. Não é base agregada de comportamento.';

-- Fim. Não contém segredos.
