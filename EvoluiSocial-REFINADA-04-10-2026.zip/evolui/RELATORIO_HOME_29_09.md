# Página inicial (index) — auditoria, correção e refatoração

**Data:** 29/09/2026

**Escopo:** `index.html` e tudo o que ele carrega: CSS principal, JS do site, esteira de parceiras e tema. O `consultas.html` só teve a referência ao CSS atualizada.

## Como foi testado

Não fiz só um "teste mental". Todo o site rodou num Chromium real, em 8 larguras: 320, 375, 414, 768, 1024, 1280, 1440 e 1920 px. Os cenários automatizados estão em `robo/lib/sondaHome.js`:

- menu com ESC e com o celular girado;
- modal com foco e teclado;
- TAB passando pela página inteira;
- formulário com campos vazios, com autopreenchimento do navegador e válido;
- filtros e busca do portfólio;
- FAQ pelo teclado;
- conexão lenta, com o Supabase demorando 12 s;
- conteúdo do painel chegando com valores maliciosos (`javascript:`, `<img onerror>`).

Os 197 testes do projeto continuam passando.

| Verificação | Antes | Depois |
|---|---|---|
| Rolagem lateral em 320 px | 78 px sobrando | 0 |
| Rolagem lateral em 375 px | 24 px | 0 |
| Filtros e busca do portfólio clicáveis | **não, em nenhuma largura** | sim, nas 8 larguras |
| Rede lenta: o menu abre | não | sim |
| Rede lenta: enviar o formulário | recarregava a página com nome, e-mail e WhatsApp no endereço | não sai da página |
| Buscas ao Supabase por visita | 2 idênticas, sem limite de tempo | 1, com limite de 8 s |
| ESC fecha o menu | não | sim |
| Girar o celular com o menu aberto | a página ficava sem rolar | normal |
| Modal: foco entra, fica preso e volta | não | sim |
| Elementos invisíveis recebendo foco no TAB | 5 | 0 |
| Formulário com autopreenchimento de "empresa" | não fazia nada, em silêncio | funciona |
| Faixa de investimento e e-mail na mensagem do WhatsApp | perdidos | incluídos |
| Erros no console | 0 | 0 |

## BUGS ENCONTRADOS

| Sev. | Problema | Causa | Correção |
|---|---|---|---|
| P0 | Filtros e busca do portfólio não respondiam ao clique, em nenhum aparelho | O `input range` invisível do comparador tinha `position:absolute; inset:0`, mas estava fora do slider. Como o pai não era posicionado, ele esticava sobre a seção `#portfolio` inteira. | O range foi para dentro do `.compare-slider`, com 1 px de altura e `pointer-events:none`. Ele fica só para o teclado; o arraste é feito no slider, com captura de ponteiro. |
| P0 | Com rede lenta, a home ficava morta: menu, tema, modal, FAQ e portfólio não funcionavam. Enviar o formulário recarregava a página com os dados no endereço (`?name=…&email=…&whatsapp=…`) | Todo o JavaScript só era ligado dentro do `.then()` da busca ao Supabase, e essa busca não tinha limite de tempo | A interface é ligada na hora. O conteúdo espera até 1,2 s pelo painel; se demorar, mostra o texto padrão e troca quando o do painel chegar. A busca tem limite de 8 s. |
| P1 | O formulário não fazia nada para quem usa autopreenchimento | A armadilha anti-robô se chamava `company` (empresa). O navegador preenchia o campo e o código descartava o envio em silêncio. | Campo renomeado (`fb_hp_campo_vazio`), escondido também de leitores de tela |
| P1 | Na mensagem do WhatsApp, a faixa de investimento e o e-mail se perdiam | A mensagem montada só usava nome, serviço e texto | A mensagem inclui serviço, faixa, e-mail e texto |
| P1 | O modal ficava invisível para leitores de tela mesmo aberto | `aria-hidden="true"` fixo no HTML | `aria-hidden` e `inert` são trocados ao abrir e fechar. O foco entra no modal, fica preso nele e volta ao botão que o abriu. |
| P2 | Girar o celular com o menu aberto deixava a página sem rolagem | `body.style.overflow='hidden'` nunca era desfeito quando o menu sumia pelo CSS | O menu fecha ao passar de 1080 px. Menu e modal usam a mesma trava de rolagem (antes, fechar um destravava o outro). |
| P2 | ESC fechava o modal, mas não o menu. Qualquer ESC destravava a rolagem, mesmo com o menu aberto | Um único listener global chamava `be()` sempre | Cada componente trata o ESC só quando está aberto |
| P2 | Rolagem lateral no celular | A coluna de contato não encolhia: grid sem `min-width:0` e e-mail sem quebra de linha. A grade de valores tinha 2 colunas fixas em 320 px. | `min-width:0`, `overflow-wrap:anywhere` e grade de 1 coluna abaixo de 380 px |
| P2 | Nome e E-mail desalinhados no computador (rótulo numa coluna, campo na outra) | `.field-row`, que serve para pôr 2 campos lado a lado, estava aplicado em cada campo | Nome e E-mail ficam dentro de um único `.field-row` |
| P2 | Ícone do menu com 9 riscos | 3 `<span>` e o CSS desenha 3 riscos por span | 1 `<span>` |
| P2 | Rótulos "Antes/Depois" do comparador sumiam | `innerHTML = svg` apagava o rótulo que estava dentro do quadro | O desenho é inserido sem apagar o rótulo, e o rótulo ganhou estilo |
| P2 | Seção "Parcerias" aparecia e sumia a cada visita (salto na página) | O título vinha visível no HTML e o JS escondia depois | A seção começa escondida e só aparece se houver parceira publicada |
| P2 | Duas buscas idênticas ao Supabase por visita | `partners-marquee.js` chamava `loadContent()` de novo | A busca é compartilhada por uma promessa única |
| P2 | A resposta aberta do FAQ podia ficar cortada ao girar a tela | `max-height` calculado uma vez só | Recalcula no `resize` |
| P2 | O tema claro piscava escuro a cada carregamento | O tema salvo só era aplicado depois da resposta do Supabase | `theme-init.js` no `<head>` aplica o tema antes de a página aparecer |
| P3 | A grade de valores ficava espremida numa moldura 4:5 com espaço vazio | Wrapper `.about-visual` com `aspect-ratio` | Wrapper removido |
| P3 | Tabela de diferenciais sem destaque e confusa no celular | O CSS usava `.diff-row.head` e `.diff-cell.yes`, mas o HTML tem `.diff-cell.head` e `.highlight`, então nenhum estilo pegava | Coluna "Com a Felipe Branding" destacada. No celular, cada célula mostra de qual coluna é. |
| P3 | Faixa do CTA com cantos arredondados colados na borda da tela | O estilo de cartão estava na `<section>` de largura total | O cartão fica dentro do `.container` |
| P3 | O relógio da estrela do cursor rodava a 60 fps para sempre, mesmo fora do hero | `requestAnimationFrame` sem parada | Só anima com o mouse no hero |
| P3 | Barra de progresso recalculava o layout a cada evento de rolagem | Leitura de `scrollHeight` e escrita de `width` no `scroll` | Uma leitura por frame (`requestAnimationFrame`) e `transform: scaleX` |

## UX MELHORADA

| Problema | Mudança | Impacto |
|---|---|---|
| Botão principal cinza com texto escuro (contraste 3,1:1), com cara de desativado | Token `--cta` no dourado da marca (`#C9A667`), contraste 7,4:1. Vale também para filtro ativo, faixa de investimento, FAQ aberto, comparador e link de pular. | Os CTAs de venda passam a chamar atenção |
| "Recebemos sua mensagem!" era falso: nada é enviado antes do WhatsApp | Botão "Continuar para o WhatsApp". A tela seguinte diz "Sua mensagem está pronta — ela só chega até nós depois que você enviar no WhatsApp" e oferece "Editar mensagem". | O cliente não acha que já falou com vocês quando não falou |
| Erros do formulário só apareciam no envio e o foco não ia até eles | O foco vai ao primeiro campo com erro, e o erro some ao corrigir. Campos com `autocomplete` e `inputmode`; limites de tamanho. | Menos desistência no formulário |
| A busca não achava "Vídeo" digitando "video" | A busca ignora acentos | A busca funciona como a pessoa digita |
| Depoimentos trocavam sozinhos com o foco do teclado dentro, ou com a aba em segundo plano | Pausa com mouse em cima, com foco dentro e com a aba oculta. Os controles somem se houver só 1 depoimento. | Cumpre o WCAG 2.2.2 e economiza bateria |
| Dois botões flutuantes sobre o conteúdo no celular | "Voltar ao topo" flutuante escondido abaixo de 560 px; o do rodapé continua | Menos coisa cobrindo o texto |
| O menu móvel cortava itens com o celular deitado | O menu rola e respeita a área segura (notch) | Todos os itens acessíveis |
| Cards do portfólio com cursor de clique, sem serem clicáveis | Cursor normal | Não promete um clique que não existe |

## RESPONSIVIDADE

| Largura | Problema | Correção |
|---|---|---|
| 320–414 | Rolagem lateral: contato e grade de valores | Colunas com `min-width:0`, quebra do e-mail, 1 coluna abaixo de 380 px |
| 320–414 | Números do hero apertados e botão do WhatsApp sobre o "%" | Grid `minmax(0, max-content)` com espaçamento menor; cabeçalho de 68 px |
| < 560 | O "Solicitar orçamento" do cabeçalho não cabia ao rolar | Esse botão aparece só a partir de 560 px (o do hero continua) |
| < 640 | Tabela de diferenciais sem contexto | Cada célula traz o nome da coluna |
| Celular deitado | Menu cortado | `overflow-y:auto` e `justify-content: safe center` |
| Todas | Barra de notch e home indicator (iPhone) | `viewport-fit=cover` e `env(safe-area-inset-*)` no cabeçalho, menu, botões flutuantes e rodapé |
| Todas | Âncoras paravam atrás do cabeçalho fixo | `scroll-padding-top` |

## PERFORMANCE

| Problema | Otimização |
|---|---|
| 2 buscas iguais ao Supabase por visita, sem limite de tempo | 1 busca compartilhada, limite de 8 s, `preconnect` para o Supabase |
| Animação da estrela do cursor rodando sempre | Só com o mouse no hero |
| Barra de progresso com reflow a cada rolagem | `transform` e 1 leitura por frame |
| Depoimentos trocando com a aba oculta | Pausam em `visibilitychange` |
| CSS e JS sem hash ficavam 1 ano em cache (`/assets/*` imutável), então correções não chegavam | Todos os arquivos alterados agora têm hash no nome: `site.097b651b6f.js`, `main.20503ed9c4.css`, `theme-init.f747534842.js`, `partners-marquee.892e5c2466.js`, `partners-marquee.9d0870bf07.css` |
| CSS morto | Removidos `.hero-scroll-cue`, `.compare-label`, `.rot-up`, `.about-visual`, `.diff-cell.yes`, `.stagger`, `.wa-float .pulse` e 2 `@keyframes` (conferido que nada usa, nem o `/consultas`) |

## ACESSIBILIDADE

| Problema | Correção |
|---|---|
| Modal invisível para leitor de tela; foco não entrava nem voltava | `aria-hidden` e `inert` dinâmicos, foco preso no modal e devolvido ao botão |
| Links do modal fechado e do "voltar ao topo" recebiam foco com TAB (5 elementos invisíveis) | `visibility:hidden` quando fechados, com transição que não atrasa o foco na abertura |
| `role="tablist"` com botões sem `role="tab"` (ARIA inválido) | Grupo de botões com `aria-pressed` |
| Cabeçalhos pulando de H2 para H4 (valores) | H3 |
| Perguntas do FAQ sem cabeçalho nem `aria-controls` | `<h3><button aria-controls>` e respostas com `id` |
| "Faixa de investimento" era um `<label>` sem campo | `<fieldset>` com `<legend>` e "(opcional)" |
| Rádios da faixa sem foco visível | `:focus-within` na pílula |
| Pontos dos depoimentos com 8 px de área de toque | 24 × 24 px (WCAG 2.5.8); setas e fechar do modal com 44 px |
| Erros do formulário não ligados ao campo | `aria-describedby`, `aria-invalid` e foco no primeiro erro |
| Resultado vazio do portfólio não era anunciado | `role="status"` |
| Contraste abaixo de 4,5:1 (rótulos cinza em fundo elevado; textos de 10–11 px) | `--star` passou de `#8C8C8C` para `#939393`; rótulos pequenos com no mínimo 12 px |
| Botão de tema sem estado | `aria-pressed` e rótulo que diz a ação ("Mudar para o tema claro") |
| Comparador sem foco visível no teclado | Contorno no slider quando o controle tem foco |

## SEGURANÇA

| Problema | Correção |
|---|---|
| O vídeo do hero aceitava qualquer URL do painel dentro de um `<iframe>`, inclusive `javascript:` | Só YouTube (via `youtube-nocookie`), Vimeo e arquivos `.mp4/.webm/.ogg` |
| Foto do fundador, imagens do portfólio, antes/depois, redes sociais e logos e links de parceiras sem validação de protocolo | `safeUrl`: só `https`, caminhos do próprio site e `data:image` |
| Ícone de serviço entrava no `href` do SVG sem lista fechada | Lista fechada de ícones |
| Dados pessoais no endereço da página ao enviar com a rede lenta | O envio nativo nunca acontece |
| O tema salvo aceitava qualquer valor | Só `light` ou `dark` |

Testei com conteúdo malicioso vindo do "painel" (`javascript:` em 4 campos e `<img onerror>` em 3). Nenhum script rodou e nenhum link perigoso foi criado. A CSP em modo observação agora inclui `youtube-nocookie.com`.

## REGRESSÕES PREVENIDAS

Fluxos refeitos depois das mudanças:

- abrir o site, navegar pelas âncoras, abrir e fechar o menu (clique, link, ESC, girar a tela), alternar o tema e recarregar mantendo o tema;
- abrir o modal, fazer TAB, SHIFT+TAB e ESC, clicar no fundo, escolher uma opção;
- filtrar e buscar no portfólio;
- arrastar o comparador e usar as setas do teclado;
- depoimentos: setas, pontos e troca automática;
- FAQ pelo teclado;
- formulário vazio, inválido, válido, "editar mensagem" e clique duplo;
- conteúdo do painel chegando em 0,3 s e em 3 s (troca sem erro);
- Supabase fora do ar;
- `/consultas` inteiro no desktop e no celular, porque usa o mesmo CSS: 5 de 5 passos.

Contratos mantidos: `window.FBContent` com a mesma API (`loadContent`, `DEFAULT_CONTENT`, `mergeDeep`, `escapeHtml`, `get`, `deepClone`), além do novo `loadContentResult`. Também ficaram iguais todos os IDs usados pelo painel e pelo `/consultas`, a chave `fb_theme` e a tabela `site_content`.

## Arquivos

**Novos:**

- `assets/js/site.097b651b6f.js`
- `assets/js/theme-init.f747534842.js`
- `assets/js/partners-marquee.892e5c2466.js`
- `assets/css/main.20503ed9c4.css`
- `assets/css/partners-marquee.9d0870bf07.css`

**Alterados:**

- `index.html`
- `consultas.html` (só o link do CSS)
- `_headers` (CSP)

**Removidos** (nada mais aponta para eles):

- `assets/js/site.bdacb7b1a8.js`
- `assets/css/main.a7ad8bfa81.css`
- `assets/js/partners-marquee.js`
- `assets/css/partners-marquee.css`

## Fica para decisão de negócio (não mexi por ser conteúdo ou regra comercial)

1. **Textos do painel que prometem o que não existe.** "Baixe o guia gratuito… você recebe o material na hora" (CTA) e "retornamos em até 1 dia útil" (contato) vêm do banco (`site_content`). Ajuste em `/admin`.
2. **Página `/privacidade`.** Não existe. O formulário agora diz para que os dados servem, mas o texto da política precisa ser escrito por vocês ou pelo advogado.
3. **Salvar o lead antes do WhatsApp.** Hoje o formulário só monta a mensagem. Gravar o contato exige uma Function nova, e isso é uma funcionalidade nova, fora do escopo de correção.
4. **Link para a consultoria gratuita no hero.** Hoje ela está só no rodapé.
5. **Portfólio e depoimentos com conteúdo real,** e uma imagem para `og:image`.
