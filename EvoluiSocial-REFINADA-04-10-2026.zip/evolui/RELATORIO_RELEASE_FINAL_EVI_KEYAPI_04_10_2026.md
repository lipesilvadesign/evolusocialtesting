# Relatório técnico — Release final EVI + KeyAPI + EKE

Data: 04/10/2026
Versão: `evi-keyapi-final-2026-10-04`

## Arquitetura

```text
USUÁRIO
  ↓
Evolui frontend
  ↓
evolui-api (Supabase Edge Function)
  ├── EIE / pesquisa / ranking
  ├── EKE / aquisição de conhecimento
  ├── Pinterest oficial
  ├── EVI Video Intelligence
  └── KeyAPI provider (isolado; não ativo automaticamente)
             │
             └── EVI Video Worker
                    ├── yt-dlp
                    ├── FFmpeg
                    ├── faster-whisper
                    ├── PySceneDetect
                    └── OpenCV
```

## Retrieval

O motor atual mantém as fontes web existentes. KeyAPI foi construída como provider complementar e não como substituição. O benchmark mede se sinais sociais adicionam cobertura útil antes de habilitar consumo recorrente.

## Ranking

O EvoluiScore permanece o ranking proprietário de adequação contextual. KeyAPI não define ranking nem pesos.

O EVI possui score estrutural separado e explícito como não-preditivo de viralização.

## EVI

IMPLEMENTADO:

- aquisição de vídeo público;
- extração de áudio;
- transcrição local;
- timestamps;
- cenas básicas;
- sinais visuais básicos;
- EVI-DNA;
- impressão digital estrutural;
- estrutura/retórica/ritmo;
- lacunas/oportunidades;
- score estrutural;
- integração com `analisar_video_pro`;
- persistência protegida.

PREPARADO:

- OCR;
- WhisperX;
- pyannote;
- análise multimodal profunda;
- corpus comparativo;
- Opportunity Gap em escala;
- aprendizagem por métricas reais.

AINDA NÃO IMPLEMENTADO:

- modelo proprietário de áudio/visão;
- previsão de viralização;
- treinamento automático de pesos com dados de rede;
- fila distribuída de vídeos longos.

## EKE

O EKE pesquisa lacunas de conhecimento, estrutura significados e termos relacionados com proveniência e grava o resultado em `evolui_conhecimento`.

## Inteligência comportamental

`evolui_comportamento_agregado` não armazena `user_id`. A camada compara períodos e suprime sinais com volume atual abaixo do mínimo definido.

## KeyAPI

Provider em:

```text
supabase/functions/evolui-api/eie/pesquisa/keyapi.ts
```

Endpoints testados no benchmark:

- TikTok hashtags/captions;
- Instagram Reels/comments/shortcode;
- YouTube search/video info;
- Pinterest search/info.

Cota controlada:

```text
limite absoluto = 98 créditos
reserva = 8
plano inicial = 56
```

A execução LIVE não foi realizada porque a chave privada não está disponível neste ambiente. Isso é a única parte externa que depende de uma credencial do usuário.

## Dados / SQL

Pacote consolidado:

```text
SQL_EVOLUI_INTELIGENCIA_CONSOLIDADO_04_10_2026.sql
```

As tabelas novas mantêm acesso direto bloqueado para `anon` quando apropriado e usam `service_role` para operações internas.

## Segurança

- nenhum segredo foi incluído no pacote;
- `KEYAPI_API_KEY` só é lida do ambiente;
- `EVI_WORKER_TOKEN` é interno ao worker;
- o frontend nunca recebe tokens;
- EVI aceita somente hosts de vídeo públicos permitidos;
- persistência EVI usa o cliente `adm` para respeitar a política de banco definida.

## Open Source

| Dependência | Uso | Versão | Licença / observação |
|---|---|---|---|
| faster-whisper | ASR local | 1.2.1 | MIT |
| yt-dlp | aquisição de vídeo | 2026.08.19 | conforme licença do projeto |
| yt-dlp-ejs | desafios JS do yt-dlp | 0.8.0 | Unlicense + componentes MIT/ISC |
| PySceneDetect | cenas/transições | 0.7.1 | BSD-3-Clause |
| OpenCV | sinais visuais | faixa 4.10+ | Apache-2.0 |

Para YouTube, a distribuição do worker inclui `yt-dlp-ejs` e Deno 2.9.6, conforme os requisitos atuais publicados pelo projeto yt-dlp/EJS. citeturn173407search0turn173407search5turn484169search0

## Testes

Suíte completa do projeto executada em 04/10/2026:

```text
337 testes
336 passaram
0 falharam
1 skipped
```

O único `skipped` depende de PostgreSQL local com migrations, que não está disponível neste ambiente.

Validações adicionais:

```text
KeyAPI Provider       9/9
KeyAPI Benchmark      5/5
Pinterest             1/1
Inteligência Dados    3/3
Vídeo Intelligence    6/6
Python compileall     OK
TypeScript syntax     OK
JavaScript syntax     OK
varredura de segredos OK
```

## Algoritmos / versões

```text
EIE: eie-v1
Pesquisa avançada: pesquisa-avancada-v2
EKE: eke-v1
EVI: evi-video-v1
EVI-DNA: evi-dna-v1
KeyAPI provider: keyapi-provider-v1
Benchmark: keyapi-benchmark-v1
```

## Latência

O worker EVI executa em processo separado porque ASR/FFmpeg são tarefas de CPU e modelo. A Edge Function apenas orquestra e normaliza o resultado.

## Correções realizadas nesta release

1. Persistência EVI alterada para `adm.from(...)`, compatível com a RLS da tabela.
2. `yt-dlp` corrigido para a versão estável atual verificada.
3. `yt-dlp-ejs` incluído.
4. runtime JS Deno incluído no container.
5. modo `shadow` do orquestrador preservado no contrato quando explicitamente selecionado.
6. erro de conexão SMTP `AggregateError` normalizado para preservar códigos de rede em Node 22.
7. `tests/run-all.js` atualizado para carregar a suíte TypeScript sem falsos negativos por extensão `.ts`.

## Conclusão

Esta release está preparada para uma única rodada de implantação. Não há necessidade de novo deploy para corrigir os pontos acima.
