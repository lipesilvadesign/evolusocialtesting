-- =====================================================================
-- Otimização do banco (29/09) — sem mudar NENHUMA regra de acesso.
-- 1) Índices nas chaves estrangeiras que o Supabase apontou (listas por
--    lead, mural, métricas e "meus leads" ficam rápidas com muitos dados).
-- 2) Políticas RLS: auth.uid() → (select auth.uid()). Mesmo resultado,
--    mas o Postgres calcula uma vez por consulta em vez de uma vez por
--    linha (recomendação oficial do Supabase, lint 0003).
-- Idempotente.
-- =====================================================================
create index if not exists admin_equipe_mensagens_autor_idx on admin_equipe_mensagens (autor_id);
create index if not exists admin_equipe_mensagens_lead_idx on admin_equipe_mensagens (lead_id);
create index if not exists admin_metricas_lead_idx on admin_metricas (lead_id);
create index if not exists admin_prospeccao_atividades_lead_idx on admin_prospeccao_atividades (lead_id);
create index if not exists admin_prospeccao_contatos_lead_idx on admin_prospeccao_contatos (lead_id);
create index if not exists admin_prospeccao_leads_responsavel_idx on admin_prospeccao_leads (responsavel_id);

do $$
declare
  p record;
  novo_using text;
  novo_check text;
begin
  for p in
    select schemaname, tablename, policyname, qual, with_check
    from pg_policies
    where schemaname = 'public'
      and (coalesce(qual, '') ~* '(?<!select )auth\.uid\(\)' or coalesce(with_check, '') ~* '(?<!select )auth\.uid\(\)')
  loop
    novo_using := regexp_replace(p.qual, '(?<!select )auth\.uid\(\)', '(select auth.uid())', 'gi');
    novo_check := regexp_replace(p.with_check, '(?<!select )auth\.uid\(\)', '(select auth.uid())', 'gi');
    if p.qual is not null and p.with_check is not null then
      execute format('alter policy %I on %I.%I using (%s) with check (%s)', p.policyname, p.schemaname, p.tablename, novo_using, novo_check);
    elsif p.qual is not null then
      execute format('alter policy %I on %I.%I using (%s)', p.policyname, p.schemaname, p.tablename, novo_using);
    else
      execute format('alter policy %I on %I.%I with check (%s)', p.policyname, p.schemaname, p.tablename, novo_check);
    end if;
  end loop;
end $$;
