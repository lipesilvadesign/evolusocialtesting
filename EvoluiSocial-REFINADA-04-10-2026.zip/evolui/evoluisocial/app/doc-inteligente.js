// EvoluiSocial — DOC INTELIGENTE (Fase 3). ES5, funções puras, sem rede, sem IA externa.
// Tudo é regra interna, determinística e explicável em português. O texto do documento nunca sai do navegador:
// este módulo não faz nenhuma chamada de rede. O ponto de extensão para IA futura (IA.ativo) vem DESLIGADO.
// Princípio: prefira não sugerir a sugerir errado. Correções automáticas só para casos sem ambiguidade.
(function (raiz) {
  'use strict';
  var VERSAO = 'doc-v1';
  // Ponto de extensão para IA futura. Desligado: nada é chamado, nada é enviado. Ligar exige decisão do dono,
  // provedor aprovado e consentimento do usuário (arquitetura 8.5). Hoje só existe a bandeira.
  var IA = { ativo: false };
  var PALAVRAS_POR_SEG = 2.6;
  var MAX_VISIVEIS = 5;
  var LIMITE_FRASE = 28;
  var LET = 'A-Za-zÀ-ÖØ-öø-ÿ';
  var RE_LETRA = new RegExp('[' + LET + ']');
  var RE_MAIUSC = /[A-ZÀ-ÖØ-Þ]/;
  var RE_MINUSC = /[a-zß-öø-ÿ]/;

  // ------------------------------------------------------------ utilidades
  function semAcento(s) { return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function ehLetra(c) { return !!c && RE_LETRA.test(c); }
  function ehDigito(c) { return !!c && /[0-9]/.test(c); }
  function hash(s) { var h = 5381, i; s = String(s); for (i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(36); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function maiuscula1(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  function casar(modelo, novo) {
    if (modelo.length > 1 && modelo === modelo.toUpperCase() && modelo !== modelo.toLowerCase()) return novo.toUpperCase();
    if (RE_MAIUSC.test(modelo.charAt(0))) return maiuscula1(novo);
    return novo;
  }
  function escRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  function palavrasDe(texto) {
    var t = String(texto || '').split(/\s+/), n = 0, i;
    for (i = 0; i < t.length; i++) if (/[A-Za-zÀ-ÿ0-9]/.test(t[i])) n++;
    return n;
  }
  function rotuloTempo(seg) {
    if (seg < 60) return '≈ ' + seg + ' s';
    var m = Math.floor(seg / 60), s = seg % 60;
    return '≈ ' + m + ' min' + (s ? ' ' + (s < 10 ? '0' : '') + s + ' s' : '');
  }
  // estima o tempo de fala a ~2,6 palavras por segundo (ritmo de fala animado); é estimativa, não medição
  function estimarDuracao(texto) {
    var p = palavrasDe(texto), seg = p ? Math.max(1, Math.round(p / PALAVRAS_POR_SEG)) : 0;
    return { palavras: p, segundos: seg, rotulo: p ? rotuloTempo(seg) : '0 s' };
  }
  function palavrasParaSegundos(seg) { return Math.round(seg * PALAVRAS_POR_SEG); }
  // "20 segundos", "1 minuto", "30s", "1min30" -> segundos (0 quando não entende)
  function lerDuracao(v) {
    if (typeof v === 'number') return v > 0 && v <= 3600 ? Math.round(v) : 0;
    var s = semAcento(v), m = s.match(/(\d+)\s*(?:min|m\b)\w*\s*(?:e\s*)?(\d+)?/);
    if (m && /min|\dm/.test(s)) return (+m[1]) * 60 + (+m[2] || 0);
    m = s.match(/(\d+)\s*(?:s|seg)\w*/) || s.match(/^\s*(\d+)\s*$/);
    return m ? Math.min(3600, +m[1]) : 0;
  }
  function formatoCanon(f) {
    var s = semAcento(f);
    if (/reel/.test(s)) return 'reel'; if (/stor/.test(s)) return 'stories'; if (/carrossel|carousel/.test(s)) return 'carrossel';
    if (/bio/.test(s)) return 'bio'; if (/legenda/.test(s)) return 'legenda'; if (/roteiro|video|tiktok|shorts/.test(s)) return 'roteiro';
    return '';
  }
  function tomCanon(t) {
    var s = semAcento(t);
    if (/formal|profission|serio|institucional|corporativ/.test(s) && !/informal/.test(s)) return 'formal';
    if (/descontra|divertid|informal|leve|jovem|bem humorad/.test(s)) return 'informal';
    return '';
  }
  var RAMO_ROTULO = { doces: 'confeitaria', alimentacao: 'restaurantes', beleza: 'beleza e estética', moda: 'moda', saude: 'saúde e bem-estar', fitness: 'academia e fitness', pet: 'pets', casa: 'casa e decoração', educacao: 'educação', servicos: 'serviços profissionais', criador: 'criação de conteúdo' };

  // ------------------------------------------------------------ trechos protegidos (links, @, #, e-mails)
  function protegidos(texto) {
    var re = new RegExp('https?:\\/\\/\\S+|www\\.\\S+|[A-Za-z0-9._+-]+@[A-Za-z0-9-]+(?:\\.[A-Za-z0-9-]+)+|[@#][' + LET + '0-9_]+', 'g'), r = [], m;
    while ((m = re.exec(texto))) r.push({ i: m.index, f: m.index + m[0].length });
    return r;
  }
  function emProt(r, a, b) { for (var i = 0; i < r.length; i++) if (r[i].i < b && a < r[i].f) return true; return false; }

  // acha expressão (sem diferenciar maiúsculas) com limite de palavra. Devolve [{inicio,fim}].
  function acharExpr(texto, expr) {
    var lo = String(texto).toLowerCase(), out = [], p = 0, i, ini, fim;
    if (lo.length !== texto.length) return out;
    expr = expr.toLowerCase();
    while ((i = lo.indexOf(expr, p)) >= 0) {
      ini = i; fim = i + expr.length; p = fim;
      if (ehLetra(texto.charAt(ini - 1)) || ehDigito(texto.charAt(ini - 1)) || ehLetra(texto.charAt(fim)) || ehDigito(texto.charAt(fim))) continue;
      out.push({ inicio: ini, fim: fim });
    }
    return out;
  }

  // ------------------------------------------------------------ frases
  // Quebra em frases por . ! ? seguidos de espaço/fim e por quebra de linha. Devolve [{inicio,fim,texto}] sem espaços nas pontas.
  function dividirFrases(texto) {
    texto = String(texto || '');
    var out = [], ini = 0, i = 0, n = texto.length, c;
    function fecha(fim) {
      var a = ini, b = fim;
      while (a < b && /\s/.test(texto.charAt(a))) a++;
      while (b > a && /\s/.test(texto.charAt(b - 1))) b--;
      if (b > a) out.push({ inicio: a, fim: b, texto: texto.slice(a, b) });
    }
    while (i < n) {
      c = texto.charAt(i);
      if (c === '\n') { fecha(i); ini = i + 1; i++; continue; }
      if (c === '.' || c === '!' || c === '?') {
        var j = i; while (j < n && /[.!?]/.test(texto.charAt(j))) j++;
        if (j >= n || /\s/.test(texto.charAt(j))) { fecha(j); ini = j; i = j; continue; }
        i = j; continue;
      }
      i++;
    }
    fecha(n);
    return out;
  }

  // ------------------------------------------------------------ correções seguras
  var ABREV = {}; ('etc dr dra sr sra srta ex av tel pag pág obs vs ltda prof cia ref min seg hr hrs aprox max máx tb numero n').split(' ').forEach(function (w) { ABREV[w] = 1; });
  var REPETIVEIS = {}; ('de da do dos das em no na nos nas um uma uns umas o os as e para pra com por se ao aos ou').split(' ').forEach(function (w) { REPETIVEIS[w] = 1; });
  // Só entram palavras sem ambiguidade: a forma sem acento/errada não existe como outra palavra.
  var ERROS = {
    nao: 'não', voce: 'você', voces: 'vocês', tambem: 'também', entao: 'então', porem: 'porém', ola: 'olá', alem: 'além', ninguem: 'ninguém', alguem: 'alguém',
    ja: 'já', otimo: 'ótimo', otima: 'ótima', gratis: 'grátis', facil: 'fácil', dificil: 'difícil', rapido: 'rápido', rapida: 'rápida', unico: 'único', unica: 'única', util: 'útil',
    preco: 'preço', precos: 'preços', servico: 'serviço', servicos: 'serviços', atencao: 'atenção', promocao: 'promoção', promocoes: 'promoções', producao: 'produção',
    solucao: 'solução', solucoes: 'soluções', informacao: 'informação', informacoes: 'informações', comunicacao: 'comunicação', opcao: 'opção', opcoes: 'opções',
    educacao: 'educação', lancamento: 'lançamento', comecar: 'começar', tres: 'três', ultimo: 'último', ultimos: 'últimos', proximo: 'próximo', proximos: 'próximos',
    minimo: 'mínimo', maximo: 'máximo', tecnico: 'técnico', familia: 'família', historia: 'história', memoria: 'memória', estrategia: 'estratégia', estrategias: 'estratégias',
    pagina: 'página', paginas: 'páginas', video: 'vídeo', videos: 'vídeos', cafe: 'café', basico: 'básico',
    porisso: 'por isso', derrepente: 'de repente', concerteza: 'com certeza', menas: 'menos', 'excessão': 'exceção', atraves: 'através', 'atráves': 'através', seje: 'seja'
  };
  var PREV_AGENTE = {}; ('que se quando como onde porque pois e mas entao então ai aí hoje agora sempre nunca tudo quem quanto').split(' ').forEach(function (w) { PREV_AGENTE[w] = 1; });
  var NEXT_AGENTE = {}; ('vai vamos pode precisa quer tem faz fez foi está esta estava fica sabe gosta sempre nunca também tambem já ja não nao só so ainda acha acredita vê ve viu pensa trabalha ama adora deve tá ta seja').split(' ').forEach(function (w) { NEXT_AGENTE[w] = 1; });

  function palavraAntes(texto, i) { // palavra imediatamente antes de i (pulando espaços) ou '' se houver pontuação/início
    var k = i; while (k > 0 && /[ \t]/.test(texto.charAt(k - 1))) k--;
    if (k === i && i > 0 && !ehLetra(texto.charAt(i - 1))) return '';
    var f = k, a = k; while (a > 0 && ehLetra(texto.charAt(a - 1))) a--;
    return a === f ? '' : texto.slice(a, f).toLowerCase();
  }
  function palavraDepois(texto, i) {
    var k = i; while (k < texto.length && /[ \t]/.test(texto.charAt(k))) k++;
    var f = k; while (f < texto.length && ehLetra(texto.charAt(f))) f++;
    return texto.slice(k, f).toLowerCase();
  }

  // opt.meio = true: o trecho é um pedaço do meio do texto (não maiusculizar o começo)
  function correcoes(texto, opt) {
    texto = String(texto || ''); opt = opt || {};
    var out = [], prot = protegidos(texto), m, re, i, c;
    function add(regra, ini, fim, novo, mensagem, motivo) {
      if (emProt(prot, ini, fim)) return;
      out.push({ regra: regra, inicio: ini, fim: fim, esperado: texto.slice(ini, fim), novo: novo, mensagem: mensagem, motivo: motivo });
    }
    // 1) espaço duplo no meio da linha
    re = /[ \t]{2,}/g;
    while ((m = re.exec(texto))) {
      i = m.index; c = texto.charAt(i + m[0].length);
      if (i === 0 || texto.charAt(i - 1) === '\n' || !c || c === '\n') continue;
      add('espaco_duplo', i, i + m[0].length, ' ', 'Espaço duplo.', 'Dois ou mais espaços seguidos viram um só.');
    }
    // 2) espaço antes de vírgula, ponto, ! ? : ;
    re = /[ \t]+(?=[,;:.!?])/g;
    while ((m = re.exec(texto))) {
      i = m.index; var fimE = i + m[0].length, p = texto.charAt(fimE), nx = texto.charAt(fimE + 1);
      if (i === 0 || texto.charAt(i - 1) === '\n') continue;
      if ((p === ':' || p === ';') && nx && !/\s/.test(nx)) continue; // :) ;) e horários
      if ((p === '.' || p === '!' || p === '?' || p === ',') && nx && !/[\s.!?,"”)]/.test(nx)) continue;
      add('espaco_antes_pontuacao', i, fimE, '', 'Espaço antes de "' + p + '".', 'Em português não se deixa espaço antes da pontuação.');
    }
    // 3) falta espaço depois de vírgula/ponto e vírgula entre letras
    re = /[,;]/g;
    while ((m = re.exec(texto))) {
      i = m.index;
      if (ehLetra(texto.charAt(i - 1)) && ehLetra(texto.charAt(i - 2)) && ehLetra(texto.charAt(i + 1))) add('falta_espaco', i, i + 1, m[0] + ' ', 'Falta espaço depois de "' + m[0] + '".', 'Depois de vírgula ou ponto e vírgula vem um espaço.');
    }
    // 4) pontuação repetida (",," ";;" ".." e 4+ pontos). "!!" e "..." ficam como estão: são estilo.
    re = /,{2,}|;{2,}|\.{2,}/g;
    while ((m = re.exec(texto))) {
      var s = m[0], ch = s.charAt(0);
      if (ch === '.' && s.length === 3) continue;
      var nv = ch === '.' ? (s.length === 2 ? '.' : '...') : ch;
      add('pontuacao_dupla', m.index, m.index + s.length, nv, 'Pontuação repetida ("' + s + '").', 'Parece um toque a mais; ficaria "' + nv + '".');
    }
    // 5) início do texto em maiúscula
    if (!opt.meio) {
      i = texto.search(/\S/);
      if (i >= 0 && RE_MINUSC.test(texto.charAt(i)) && !RE_MAIUSC.test(texto.charAt(i + 1))) add('maiuscula_inicio', i, i + 1, texto.charAt(i).toUpperCase(), 'O texto começa com letra minúscula.', 'Início de texto leva letra maiúscula.');
    }
    // 6) maiúscula depois de ponto final, ! ou ?
    re = /([.!?]+)([ \t]+)([a-zß-öø-ÿ])/g;
    while ((m = re.exec(texto))) {
      var pt = m[1], iL = m.index + m[0].length - 1, antes = m.index, w;
      if (RE_MAIUSC.test(texto.charAt(iL + 1))) continue; // iPhone, eBook
      if (pt.charAt(0) === '.' && (pt.length > 1 || ehDigito(texto.charAt(antes - 1)))) continue; // reticências e "1. item"
      if (pt.charAt(0) === '.') {
        w = (texto.slice(Math.max(0, antes - 12), antes).match(/([A-Za-zÀ-ÿ]+)$/) || [])[1];
        w = (w || '').toLowerCase();
        if (w.length <= 1 || ABREV[w]) continue;
      }
      add('maiuscula_apos_ponto', iL, iL + 1, texto.charAt(iL).toUpperCase(), 'Frase nova começando com minúscula.', 'Depois de ponto final, ! ou ? a frase seguinte começa com maiúscula.');
    }
    // 7) palavra repetida (só palavras de ligação; "muito muito" e "que que" são estilo e ficam fora)
    re = new RegExp('([' + LET + ']+)([ \\t]+)\\1(?![' + LET + '])', 'gi');
    while ((m = re.exec(texto))) {
      if (ehLetra(texto.charAt(m.index - 1))) continue;
      if (!REPETIVEIS[m[1].toLowerCase()]) continue;
      add('repeticao', m.index + m[1].length, m.index + m[0].length, '', 'Palavra repetida: "' + m[1] + ' ' + m[1] + '".', 'A mesma palavra de ligação duas vezes seguidas costuma ser engano de digitação.');
    }
    // 8) erros comuns (lista curta; formas que não existem como outra palavra)
    re = new RegExp('[' + LET + ']+', 'g');
    while ((m = re.exec(texto))) {
      var tok = m[0], lo = tok.toLowerCase(), pr = texto.charAt(m.index - 1);
      if (/[@#\/_\-.]/.test(pr) || /[@\/_\-]/.test(texto.charAt(m.index + tok.length))) continue;
      if (ERROS.hasOwnProperty(lo)) {
        add('erro_comum', m.index, m.index + tok.length, casar(tok, ERROS[lo]), '"' + tok + '" costuma ser "' + casar(tok, ERROS[lo]) + '".', lo.length && ERROS[lo].indexOf(' ') < 0 && semAcento(ERROS[lo]) === lo ? 'Faltou o acento.' : 'Forma mais usada e correta.');
      } else if (lo === 'agente' && !opt.seguras) { // ambígua: só sugestão, nunca automática
        var pa = palavraAntes(texto, m.index), pd = palavraDepois(texto, m.index + tok.length);
        if ((pa === '' || PREV_AGENTE[pa]) && NEXT_AGENTE[pd]) add('a_gente', m.index, m.index + tok.length, casar(tok, 'a gente'), 'Talvez seja "a gente" (nós).', 'Aqui o sentido parece ser "nós"; "agente" é quem exerce uma função. Só aceite se for isso.');
      }
    }
    re = /(^|[^A-Za-zÀ-ÿ])(a)( muito tempo| muitos anos)(?![A-Za-zÀ-ÿ])/gi;
    while ((m = re.exec(texto))) add('ha_tempo', m.index + m[1].length, m.index + m[1].length + 1, casar(m[2], 'há'), 'Para tempo passado se usa "há".', '"Há muito tempo" indica tempo decorrido; "a" indicaria distância ou futuro.');
    re = /(^|[^A-Za-zÀ-ÿ])(para|pra)( mim )(fazer|ver|falar|dizer|mostrar|explicar|ajudar|comprar|entender)(?![A-Za-zÀ-ÿ])/gi;
    while ((m = re.exec(texto))) { var im = m.index + m[1].length + m[2].length + 1; add('para_eu', im, im + 3, 'eu', '"Para eu ' + m[4].toLowerCase() + '", não "para mim".', 'Antes de verbo, quem faz a ação pede "eu".'); }
    // ordena e remove sobreposições
    out.sort(function (a, b) { return a.inicio - b.inicio || a.fim - b.fim; });
    var ok = [], ultimo = -1;
    for (i = 0; i < out.length; i++) { if (out[i].inicio < ultimo) continue; ok.push(out[i]); ultimo = out[i].fim; }
    return ok;
  }
  function aplicarLista(texto, lista) {
    var t = String(texto), i;
    for (i = lista.length - 1; i >= 0; i--) t = t.slice(0, lista[i].inicio) + lista[i].novo + t.slice(lista[i].fim);
    return t;
  }

  // ------------------------------------------------------------ remoção com arrumação (vícios, preâmbulos)
  // Devolve {inicio,fim,novo}: troca texto[inicio,fim] por novo para remover o trecho [ini,fim) sem deixar vírgula ou maiúscula quebrada.
  function remocao(texto, ini, fim) {
    var n = texto.length, k = ini, j = fim, a = ini, b, esq, dir, inicioFrase;
    while (k > 0 && /[ \t]/.test(texto.charAt(k - 1))) k--;
    esq = k > 0 && texto.charAt(k - 1) === ',';
    while (j < n && /[ \t]/.test(texto.charAt(j))) j++;
    dir = texto.charAt(j) === ',';
    inicioFrase = k === 0 || /[.!?\n]/.test(texto.charAt(k - 1));
    if (dir) { b = j + 1; while (b < n && /[ \t]/.test(texto.charAt(b))) b++; }
    else if (j >= n || /[.!?\n;:]/.test(texto.charAt(j))) { a = esq ? k - 1 : k; b = fim; }
    else { b = j; }
    var novo = '';
    if (inicioFrase && a === ini && b < n && RE_MINUSC.test(texto.charAt(b)) && !RE_MAIUSC.test(texto.charAt(b + 1))) { novo = texto.charAt(b).toUpperCase(); b++; }
    return { inicio: a, fim: b, novo: novo };
  }
  function removerExpressoes(texto, lista) {
    var achados = [], i, j, r, t = String(texto), nomes = {}, qtd = 0;
    for (i = 0; i < lista.length; i++) { r = acharExpr(t, lista[i]); for (j = 0; j < r.length; j++) achados.push({ inicio: r[j].inicio, fim: r[j].fim, nome: lista[i] }); }
    achados.sort(function (x, y) { return y.inicio - x.inicio; });
    var ult = Infinity, prot = protegidos(t);
    for (i = 0; i < achados.length; i++) {
      if (achados[i].fim > ult || emProt(prot, achados[i].inicio, achados[i].fim)) continue;
      var rm = remocao(t, achados[i].inicio, achados[i].fim);
      t = t.slice(0, rm.inicio) + rm.novo + t.slice(rm.fim); ult = rm.inicio; nomes[achados[i].nome] = 1; qtd++;
    }
    return { texto: t, qtd: qtd, nomes: Object.keys(nomes) };
  }

  // ------------------------------------------------------------ vocabulário de clareza / tom
  var VICIOS = ['basicamente', 'tipo assim', 'meio que', 'de certa forma', 'por assim dizer', 'na verdade', 'na realidade'];
  var PREAMBULOS = ['é importante lembrar que', 'é importante destacar que', 'é importante ressaltar que', 'vale ressaltar que', 'vale lembrar que', 'vale destacar que', 'cabe destacar que', 'como já dito', 'como eu já disse', 'como já falei'];
  var REDUNDANCIAS = [['subir para cima', 'subir'], ['descer para baixo', 'descer'], ['entrar para dentro', 'entrar'], ['sair para fora', 'sair'], ['elo de ligação', 'elo'], ['repetir de novo', 'repetir'], ['outra alternativa', 'alternativa'], ['planejar antecipadamente', 'planejar'], ['surpresa inesperada', 'surpresa'], ['acabamento final', 'acabamento'], ['monopólio exclusivo', 'monopólio'], ['sobe para cima', 'sobe'], ['desce para baixo', 'desce']];
  var DIRETO = [['a fim de', 'para'], ['no sentido de', 'para'], ['com o objetivo de', 'para'], ['de forma a', 'para'], ['devido ao fato de que', 'porque'], ['em virtude do fato de que', 'porque'], ['tendo em vista que', 'como'], ['no momento atual', 'agora'], ['neste momento', 'agora'], ['nos dias de hoje', 'hoje'], ['um grande número de', 'muitos'], ['a grande maioria', 'a maioria']];
  var NATURAL = [['gostaria de', 'quero'], ['a fim de', 'pra'], ['para os', 'pros'], ['para as', 'pras'], ['para o', 'pro'], ['para a', 'pra'], ['para', 'pra'], ['no entanto', 'mas'], ['entretanto', 'mas'], ['contudo', 'mas'], ['porém', 'mas'], ['portanto', 'então'], ['utilizamos', 'usamos'], ['utilizar', 'usar'], ['utilize', 'use'], ['adquirir', 'comprar'], ['adquira', 'compre'], ['auxiliar', 'ajudar']];
  var GIRIAS = ['vc', 'vcs', 'pq', 'tbm', 'blz', 'mano', 'mana', 'galera', 'bora', 'kkk', 'kkkk', 'rsrs', 'tipo assim', 'né', 'tá', 'show de bola'];
  var SOLENES = ['prezado', 'prezada', 'prezados', 'outrossim', 'doravante', 'destarte', 'supracitado', 'venho por meio', 'vimos por meio', 'vossa'];
  var CLICHES = ['onde a magica acontece', 'gere conexao', 'humanize sua marca', 'aproxime seu publico', 'mostre o lado real', 'fortaleca sua presenca', 'conexao genuina', 'conteudo de valor', 'engaje seu publico', 'autenticidade', 'lado humano', 'conquiste seu publico'];
  var STOP = {}; ('a o as os um uma uns umas de da do das dos em no na nos nas num numa para pra pro por pelo pela com sem que e ou ao aos se me te meu minha seu sua eu tu ele ela voce como qual quem onde quando porque mais muito pouco bem sobre ate ja so tambem nao sim mas entao aqui ai la hoje agora isso esse essa este esta aquele aquela algo coisa tipo').split(' ').forEach(function (w) { STOP[w] = 1; });

  function radical(w) {
    if (w.length <= 3) return w;
    if (/(oes|aes)$/.test(w)) return w.slice(0, -3) + 'ao';
    if (/ais$/.test(w)) return w.slice(0, -3) + 'al';
    if (/ns$/.test(w)) return w.slice(0, -2) + 'm';
    if (/[rzl]es$/.test(w) && w.length > 5) return w.slice(0, -2);
    if (/s$/.test(w) && !/ss$/.test(w) && !/(is|us)$/.test(w)) return w.slice(0, -1);
    return w;
  }
  // mesma ideia de genericidadeTexto (eie/contexto.ts): 0 = específico, 1 = genérico
  function genericidade(texto) {
    var norm = semAcento(texto).replace(/[^a-z0-9#@\s-]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!norm) return 1;
    var pal = norm.split(' ').filter(function (w) { return w && !STOP[w]; }), un = {}, i;
    for (i = 0; i < pal.length; i++) un[radical(pal[i])] = 1;
    var cl = CLICHES.filter(function (c) { return norm.indexOf(c) >= 0; }).length, dens = pal.length ? Object.keys(un).length / pal.length : 0, g = cl * 0.4;
    if (pal.length < 6) g += 0.25; if (dens < 0.65) g += 0.2;
    return Math.min(1, Math.round(g * 100) / 100);
  }
  var CTA_RE = /(whats|wpp|link|chame|chama|peca|pedido|agende|agenda|compre|comprar|encomend|\bdm\b|direct|comente|salve|clique|toque|reserve|garanta|fale com|orcamento|compartilhe|siga|marque|responda|manda|mande|me chama|entre em contato|cadastre|inscreva)/;
  var FECHO_RE = /(por isso|resumindo|em resumo|fica a dica|lembre|nao esqueca|ate a proxima|ate logo|portanto|agora e com voce|conclusao|no fim das contas|e isso)/;
  var PROBLEMA_RE = /(erro|problema|cuidado|\bpare\b|nunca|ninguem|cansad|medo|duvida|dificil|perde|perdendo|chega de|por que|como |\bnao\b|\bsem\b|segredo|voce ja|voce sabia|descubra)/;
  var ABERTURA_FRACA_RE = /^(oi|ola|e ai|bom dia|boa tarde|boa noite|hoje (eu )?(vou|vamos|quero)|fala (galera|pessoal)|gente|pessoal|galera|bem[- ]vind)/;
  var NAO_GERUNDIO = ' quando segundo mundo fundo profundo redondo oriundo moribundo vagabundo nauseabundo ';

  // ------------------------------------------------------------ análise passiva do documento
  function criar(tipo, regra, prio, texto, ini, fim, mensagem, motivo, acao) {
    var t = texto.slice(ini, fim);
    var s = { id: regra + ':' + hash(t + '|' + (acao && acao.novo != null ? acao.novo : acao && acao.comando || '')), tipo: tipo, regra: regra, prioridade: prio, trecho: { inicio: ini, fim: fim, texto: t }, mensagem: mensagem, motivo: motivo };
    if (acao) s.acao = acao;
    return s;
  }
  function acaoSubstituir(texto, ini, fim, novo, rotulo) { return { tipo: 'substituir', inicio: ini, fim: fim, esperado: texto.slice(ini, fim), novo: novo, rotulo: rotulo || 'Aplicar' }; }

  function normalizarCtx(ctx) {
    ctx = ctx || {};
    var dur = ctx.duracaoSeg != null ? lerDuracao(ctx.duracaoSeg) : lerDuracao(ctx.duracao);
    return { formato: formatoCanon(ctx.formato), duracaoSeg: dur, tom: tomCanon(ctx.tom || ctx.persona), objetivo: semAcento(ctx.objetivo).replace(/[^a-z]/g, ''), ramo: String(ctx.ramo || ''), tema: String(ctx.tema || ctx.titulo || '').trim() };
  }

  // analisarDoc(texto, ctx, opcoes) -> sugestões discretas e priorizadas (no máximo opcoes.max, padrão 5).
  // opcoes.ignoradas: {id:true}. A lista devolvida tem .total (antes do corte) e .ocultas.
  function analisarTudo(texto, ctxIn) {
    texto = String(texto || '');
    var ctx = normalizarCtx(ctxIn), S = [], i, j, m, re;
    if (!texto.replace(/\s/g, '')) return S;
    var frases = dividirFrases(texto), nPal = palavrasDe(texto), plano = semAcento(texto), planoOk = plano.length === texto.length;
    var fmt = ctx.formato, ehBio = fmt === 'bio';

    // correção (segura, com ação)
    var cs = correcoes(texto), tituloCor = { espaco_duplo: 'Espaço', espaco_antes_pontuacao: 'Pontuação', falta_espaco: 'Pontuação', pontuacao_dupla: 'Pontuação', maiuscula_inicio: 'Maiúscula', maiuscula_apos_ponto: 'Maiúscula', repeticao: 'Repetição', erro_comum: 'Ortografia', a_gente: 'Ortografia', ha_tempo: 'Gramática', para_eu: 'Gramática' };
    for (i = 0; i < cs.length; i++) {
      var c = cs[i], ini = c.inicio, fim = c.fim;
      if (c.regra === 'espaco_duplo' || c.regra === 'espaco_antes_pontuacao' || c.regra === 'repeticao' || c.regra === 'pontuacao_dupla' || c.regra === 'falta_espaco') { // mostra a palavra ao redor para o trecho ser legível
        var a2 = ini, b2 = fim; while (a2 > 0 && ehLetra(texto.charAt(a2 - 1))) a2--; while (b2 < texto.length && ehLetra(texto.charAt(b2))) b2++;
        if (b2 - a2 < 40) { var rel = c; S.push(criar('correcao', c.regra, 10, texto, a2, b2, c.mensagem, c.motivo, acaoSubstituir(texto, rel.inicio, rel.fim, rel.novo, 'Corrigir'))); continue; }
      }
      S.push(criar('correcao', c.regra, 10, texto, ini, fim, c.mensagem, c.motivo, acaoSubstituir(texto, ini, fim, c.novo, 'Corrigir')));
      void tituloCor;
    }

    // clareza
    for (i = 0; i < frases.length; i++) {
      var f = frases[i], np = palavrasDe(f.texto);
      if (np > LIMITE_FRASE) S.push(criar('clareza', 'frase_longa', 40, texto, f.inicio, f.fim, 'Frase longa (' + np + ' palavras).', 'Frases acima de ~' + LIMITE_FRASE + ' palavras cansam quem lê no celular. Tente dividir em duas.'));
      var ger = (f.texto.toLowerCase().match(new RegExp('[' + LET + ']{3,}(?:ando|endo|indo|ondo)(?![' + LET + '])', 'g')) || []).filter(function (g) { return NAO_GERUNDIO.indexOf(' ' + g + ' ') < 0; });
      if (ger.length >= 2) S.push(criar('clareza', 'gerundio', 42, texto, f.inicio, f.fim, 'Dois gerúndios na mesma frase (' + ger.slice(0, 2).join(', ') + ').', 'Gerúndio em sequência deixa o texto arrastado; verbos no presente costumam soar mais diretos.'));
    }
    for (i = 0; i < VICIOS.length; i++) {
      var rv = acharExpr(texto, VICIOS[i]);
      for (j = 0; j < rv.length; j++) {
        var rm = remocao(texto, rv[j].inicio, rv[j].fim);
        S.push(criar('clareza', 'vicio', 41, texto, rv[j].inicio, rv[j].fim, 'Vício de linguagem: "' + VICIOS[i] + '".', 'Expressão de preenchimento que raramente acrescenta informação. Remover costuma deixar o texto mais firme.', acaoSubstituir(texto, rm.inicio, rm.fim, rm.novo, 'Remover')));
      }
    }
    re = new RegExp('\\b(foi|foram|é|são|era|eram|será|serão|seja)\\s+[' + LET + ']+(?:ado|ada|ados|adas|ido|ida|idos|idas)\\s+por\\b', 'gi');
    var pass = []; while ((m = re.exec(texto))) pass.push(m);
    if (pass.length >= 2) S.push(criar('clareza', 'voz_passiva', 43, texto, pass[0].index, pass[0].index + pass[0][0].length, 'Voz passiva repetida (' + pass.length + ' vezes).', 'Dizer quem faz a ação ("a equipe preparou" em vez de "foi preparado pela equipe") deixa o texto mais direto.'));
    if (planoOk) for (i = 0; i < CLICHES.length; i++) {
      var pc = plano.indexOf(CLICHES[i]);
      if (pc >= 0) S.push(criar('clareza', 'cliche', 44, texto, pc, pc + CLICHES[i].length, 'Expressão de efeito sem informação concreta.', 'Frases como esta aparecem em muitos perfis e não dizem nada sobre o seu negócio. Troque por um fato seu (produto, preço, prazo, resultado).'));
    }
    if (nPal >= 12 && genericidade(texto) >= 0.45) S.push(criar('clareza', 'generico', 45, texto, 0, texto.length, 'O texto está genérico.', 'Poucas palavras próprias do assunto ou palavras muito repetidas. Acrescente um detalhe concreto: nome do produto, número, prazo ou exemplo.'));

    // gancho (não vale para bio)
    var primeira = frases[0];
    if (!ehBio && primeira && nPal >= 8) {
      var pn = semAcento(primeira.texto), npp = palavrasDe(primeira.texto);
      var temHook = /\?/.test(primeira.texto) || /\d/.test(primeira.texto) || PROBLEMA_RE.test(pn + ' ');
      if (ABERTURA_FRACA_RE.test(pn) && !/\?/.test(primeira.texto) && !/\d/.test(primeira.texto)) S.push(criar('gancho', 'abertura_fraca', 20, texto, primeira.inicio, primeira.fim, 'A abertura é uma saudação.', 'Os primeiros segundos decidem se a pessoa continua. Começar pelo problema de quem assiste costuma prender mais (boa prática, não garantia).', { tipo: 'comando', comando: 'gancho', rotulo: 'Ver modelos de abertura' }));
      else if (!temHook) S.push(criar('gancho', 'sem_gancho', 21, texto, primeira.inicio, primeira.fim, 'A primeira frase não tem pergunta, número nem problema.', 'Abrir com uma pergunta, um número ou o problema do seu público costuma prender mais. É uma boa prática, não uma garantia.', { tipo: 'comando', comando: 'gancho', rotulo: 'Ver modelos de abertura' }));
      else if (npp > 18) S.push(criar('gancho', 'gancho_longo', 22, texto, primeira.inicio, primeira.fim, 'A primeira frase é longa (' + npp + ' palavras).', 'Um gancho curto, de até ~15 palavras, é lido ou ouvido de uma vez.'));
    }

    // estrutura e CTA (não vale para bio)
    var ultimas = frases.slice(-2).map(function (x) { return semAcento(x.texto); }).join(' ');
    var temCta = CTA_RE.test(plano);
    if (!ehBio && nPal >= 15) {
      var ult = frases[frases.length - 1];
      if (!temCta) S.push(criar('cta', 'sem_cta', 30, texto, ult.inicio, ult.fim, 'Falta uma chamada para ação.', 'Dizer o que a pessoa deve fazer (comentar, salvar, chamar no WhatsApp) deixa o próximo passo claro.', { tipo: 'comando', comando: 'cta', rotulo: 'Ver modelos de CTA' }));
      else if (nPal >= 40 && !CTA_RE.test(ultimas) && !FECHO_RE.test(ultimas)) S.push(criar('estrutura', 'sem_fecho', 32, texto, ult.inicio, ult.fim, 'O texto termina sem fechar a ideia.', 'O pedido de ação está no meio do texto. Terminar com um fecho (resumo curto ou o pedido de ação) ajuda a pessoa a saber o que fazer.'));
      else if (nPal >= 40 && !temCta && !FECHO_RE.test(ultimas)) S.push(criar('estrutura', 'sem_fecho', 32, texto, ult.inicio, ult.fim, 'O texto termina sem fechar a ideia.', 'Falta uma frase final que feche o assunto.'));
    }
    if (fmt === 'bio' && texto.length > 150) S.push(criar('estrutura', 'limite_bio', 26, texto, 150, texto.length, 'A bio passou de 150 caracteres (' + texto.length + ').', 'O Instagram corta a bio acima de 150 caracteres.'));
    if (fmt === 'legenda' && texto.length > 2200) S.push(criar('estrutura', 'limite_legenda', 26, texto, 2200, texto.length, 'A legenda passou de 2.200 caracteres (' + texto.length + ').', 'Acima disso o Instagram não publica.'));
    // duração
    if (ctx.duracaoSeg > 0 && nPal >= 5 && !ehBio) {
      var est = estimarDuracao(texto), alvo = ctx.duracaoSeg, lim = palavrasParaSegundos(alvo);
      if (est.segundos > alvo * 1.15 && est.segundos - alvo >= 3) S.push(criar('estrutura', 'duracao_longa', 25, texto, 0, texto.length, 'Leva ' + rotuloTempo(est.segundos) + ' para falar; o alvo é ' + alvo + ' s.', 'A ~2,6 palavras por segundo, ' + alvo + ' s comportam cerca de ' + lim + ' palavras; o texto tem ' + est.palavras + '. É uma estimativa, a fala real varia.', { tipo: 'comando', comando: 'tempo', segundos: alvo, rotulo: 'Reduzir para ' + alvo + ' s' }));
      else if (est.segundos < alvo * 0.55) S.push(criar('estrutura', 'duracao_curta', 27, texto, 0, texto.length, 'Curto para ' + alvo + ' s: ' + rotuloTempo(est.segundos) + '.', 'Faltam cerca de ' + (lim - est.palavras) + ' palavras para ocupar ' + alvo + ' s, ou o alvo pode ser menor.'));
    }

    // persona / tom
    if (ctx.tom) {
      var lista = ctx.tom === 'formal' ? GIRIAS : SOLENES, achou = {};
      for (i = 0; i < lista.length; i++) {
        var ra = acharExpr(texto, lista[i]);
        if (ra.length && !achou[lista[i]]) {
          achou[lista[i]] = 1;
          S.push(criar('persona', 'tom_' + ctx.tom, 50, texto, ra[0].inicio, ra[0].fim, ctx.tom === 'formal' ? '"' + texto.slice(ra[0].inicio, ra[0].fim) + '" é informal para um tom formal.' : '"' + texto.slice(ra[0].inicio, ra[0].fim) + '" soa solene para um tom descontraído.', 'Você escolheu o tom ' + (ctx.tom === 'formal' ? 'formal' : 'descontraído') + '. Esta palavra puxa para o lado oposto.'));
        }
      }
    }
    // remove duplicadas por id (mesmo erro repetido)
    var vistos = {}, U = [];
    S.sort(function (a, b) { return a.prioridade - b.prioridade || a.trecho.inicio - b.trecho.inicio; });
    for (i = 0; i < S.length; i++) { if (vistos[S[i].id]) continue; vistos[S[i].id] = 1; U.push(S[i]); }
    return U;
  }
  function analisarDoc(texto, ctx, opcoes) {
    opcoes = opcoes || {};
    var ign = opcoes.ignoradas || {}, max = opcoes.max > 0 ? opcoes.max : MAX_VISIVEIS;
    var todas = analisarTudo(texto, ctx).filter(function (s) { return !ign[s.id]; }), porTipo = {}, vis = [], resto = [], i;
    for (i = 0; i < todas.length && vis.length < max; i++) { // primeira passada: no máximo 2 por tipo, para não afogar o resto
      var t = todas[i].tipo; porTipo[t] = (porTipo[t] || 0) + 1;
      if (porTipo[t] <= 2) vis.push(todas[i]); else resto.push(todas[i]);
    }
    for (; i < todas.length; i++) resto.push(todas[i]);
    for (i = 0; i < resto.length && vis.length < max; i++) vis.push(resto[i]);
    vis.sort(function (a, b) { return a.prioridade - b.prioridade || a.trecho.inicio - b.trecho.inicio; });
    vis.total = todas.length; vis.ocultas = todas.length - vis.length;
    return vis;
  }

  // ------------------------------------------------------------ comandos sobre a seleção
  var COMANDOS = [
    { id: 'corrigir', rotulo: 'Corrigir', versaoSimples: false, grupo: 'principal', ajuda: 'Aplica só correções seguras: espaços, pontuação, maiúscula, repetição e erros comuns.' },
    { id: 'encurtar', rotulo: 'Encurtar', versaoSimples: false, grupo: 'principal', ajuda: 'Tira vícios, redundâncias, preâmbulos e orações explicativas dispensáveis.' },
    { id: 'direto', rotulo: 'Mais direto', versaoSimples: false, grupo: 'principal', ajuda: 'Troca rodeios por formas curtas ("a fim de" por "para").' },
    { id: 'gancho', rotulo: 'Criar gancho', versaoSimples: false, grupo: 'principal', ajuda: 'Três modelos de abertura com o seu assunto, sem inventar fatos.' },
    { id: 'cta', rotulo: 'Criar CTA', versaoSimples: false, grupo: 'principal', ajuda: 'Modelos de chamada para ação conforme o seu objetivo.' },
    { id: 't15', rotulo: '15 s', versaoSimples: false, grupo: 'tempo', ajuda: 'Reduz para ~39 palavras mantendo início e fecho.' },
    { id: 't30', rotulo: '30 s', versaoSimples: false, grupo: 'tempo', ajuda: 'Reduz para ~78 palavras mantendo início e fecho.' },
    { id: 'roteiro', rotulo: 'Roteiro em cenas', versaoSimples: false, grupo: 'tempo', ajuda: 'Divide o texto em cenas com tempo estimado (formato Reels).' },
    { id: 'melhorar', rotulo: 'Melhorar', versaoSimples: true, grupo: 'simples', ajuda: 'Limpeza por regras (correções + vícios + redundâncias). Não reescreve com criatividade.' },
    { id: 'expandir', rotulo: 'Expandir', versaoSimples: true, grupo: 'simples', ajuda: 'Só organiza em linhas curtas e lista perguntas para você completar. Não inventa conteúdo.' },
    { id: 'natural', rotulo: 'Mais natural', versaoSimples: true, grupo: 'simples', ajuda: 'Troca palavras formais por falas do dia a dia. Não substitui uma boa reescrita.' }
  ];
  var AVISO_SIMPLES = 'Versão simples, feita por regras, sem IA. Revise antes de usar.';
  function infoComando(id) { for (var i = 0; i < COMANDOS.length; i++) if (COMANDOS[i].id === id) return COMANDOS[i]; return null; }

  function normSel(texto, sel) {
    var n = texto.length, a = sel && sel.inicio != null ? +sel.inicio : 0, b = sel && sel.fim != null ? +sel.fim : n;
    if (!(a >= 0)) a = 0; if (!(b >= 0)) b = 0; a = Math.min(a, n); b = Math.min(b, n);
    if (b < a) { var t = a; a = b; b = t; }
    if (a === b) return { inicio: 0, fim: n, todo: true };
    return { inicio: a, fim: b, todo: a === 0 && b === n };
  }
  function aplicar(texto, sel, novo) { return texto.slice(0, sel.inicio) + novo + texto.slice(sel.fim); }
  function colapsarEspacos(t) { return t.replace(/([^\s])[ \t]{2,}(?=\S)/g, '$1 '); }

  function trocarLista(t, pares) {
    var cont = 0, i;
    for (i = 0; i < pares.length; i++) {
      var r = acharExpr(t, pares[i][0]), j;
      for (j = r.length - 1; j >= 0; j--) {
        t = t.slice(0, r[j].inicio) + casar(t.charAt(r[j].inicio), pares[i][1]) + t.slice(r[j].fim); cont++;
      }
    }
    return { texto: t, qtd: cont };
  }
  function limparSimples(t) { // vícios + redundâncias + espaços
    var rg = [], v = removerExpressoes(t, VICIOS); t = v.texto; if (v.qtd) rg.push('removidos ' + v.qtd + ' vício(s) de linguagem (' + v.nomes.join(', ') + ')');
    var r = trocarLista(t, REDUNDANCIAS); t = r.texto; if (r.qtd) rg.push('cortadas ' + r.qtd + ' redundância(s)');
    return { texto: colapsarEspacos(t), regras: rg };
  }
  function encurtarTexto(t) {
    var rg = [], p = removerExpressoes(t, PREAMBULOS); t = p.texto; if (p.qtd) rg.push('removidos ' + p.qtd + ' preâmbulo(s) ("vale ressaltar que...")');
    var l = limparSimples(t); t = l.texto; rg = rg.concat(l.regras);
    // orações explicativas entre vírgulas (", que ... ,"): dispensáveis por definição; ficam de fora as que têm número, nome próprio, @ ou #
    var qtd = 0, prot = protegidos(t);
    t = t.replace(/,\s*(que|o qual|a qual|onde)\s+([^,.;!?\n]{12,100}),(?=\s)/g, function (m0, a, cl, off) {
      var np = palavrasDe(cl);
      if (np < 3 || np > 14 || /[0-9@#$]/.test(cl) || /[A-ZÀ-ÖØ-Þ]/.test(cl) || emProt(prot, off, off + m0.length)) return m0;
      qtd++; return '';
    });
    if (qtd) rg.push('cortada(s) ' + qtd + ' oração(ões) explicativa(s) entre vírgulas');
    // frases repetidas
    var fr = dividirFrases(t), vis = {}, rep = 0, k;
    for (k = fr.length - 1; k >= 0; k--) {
      var ch = semAcento(fr[k].texto).replace(/[^a-z0-9]/g, '');
      if (ch.length < 12) continue;
      var dup = false; for (var q = 0; q < k; q++) if (semAcento(fr[q].texto).replace(/[^a-z0-9]/g, '') === ch) dup = true;
      if (dup) { t = t.slice(0, fr[k].inicio) + t.slice(fr[k].fim); rep++; }
    }
    if (rep) { rg.push('removida(s) ' + rep + ' frase(s) repetida(s)'); t = t.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/ {2,}/g, ' ').trim(); }
    void vis;
    return { texto: colapsarEspacos(t).replace(/ +([,.;!?])/g, '$1'), regras: rg };
  }
  function resultado(id, original, novo, regra, sel, extra) {
    var info = infoComando(id) || { rotulo: id, versaoSimples: false }, r = { comando: id, rotulo: info.rotulo, original: original, novo: novo, mudou: novo !== original, regra: regra, versaoSimples: !!info.versaoSimples, selecao: { inicio: sel.inicio, fim: sel.fim }, modo: 'substituir' };
    if (r.versaoSimples) r.aviso = AVISO_SIMPLES;
    if (extra) for (var k in extra) if (extra.hasOwnProperty(k)) r[k] = extra[k];
    return r;
  }

  function limitarPalavras(texto, seg) {
    var limite = palavrasParaSegundos(seg), enc = encurtarTexto(texto), t = enc.texto, regras = enc.regras.slice();
    if (palavrasDe(t) > limite) {
      var fr = dividirFrases(t), sep = /\n/.test(texto) ? '\n' : ' ';
      if (fr.length <= 2) return { texto: t, regras: regras, cabe: false, nota: 'Há só ' + fr.length + ' frase(s): reescreva à mão para caber em ' + seg + ' s.' };
      var primeira = fr[0], ult = fr[fr.length - 1], orc = limite - palavrasDe(primeira.texto) - palavrasDe(ult.texto), mid = [], i;
      for (i = 1; i < fr.length - 1; i++) mid.push({ i: i, t: fr[i].texto, n: palavrasDe(fr[i].texto), s: (/\d/.test(fr[i].texto) ? 2 : 0) + (PROBLEMA_RE.test(semAcento(fr[i].texto) + ' ') ? 1 : 0) + (CTA_RE.test(semAcento(fr[i].texto)) ? 1 : 0) });
      mid.sort(function (a, b) { return b.s - a.s || a.n - b.n; });
      var manter = {}, tira = 0;
      for (i = 0; i < mid.length; i++) { if (mid[i].n <= orc) { manter[mid[i].i] = 1; orc -= mid[i].n; } else tira++; }
      var partes = [primeira.texto]; for (i = 1; i < fr.length - 1; i++) if (manter[i]) partes.push(fr[i].texto);
      partes.push(ult.texto); t = partes.join(sep);
      regras.push('mantidos a abertura, o fecho e as frases com número, problema ou chamada; removidas ' + tira + ' frase(s) do meio (revise a ligação entre as frases)');
    }
    return { texto: t, regras: regras, cabe: palavrasDe(t) <= limite, nota: palavrasDe(t) > limite ? 'Mesmo só com início e fecho passa de ' + limite + ' palavras: reescreva à mão.' : '' };
  }

  function temaDe(ctx) { return ctx.tema.replace(/[.!?:;,\s]+$/, '').slice(0, 80); }
  function modelosGancho(ctx) {
    var tema = temaDe(ctx), ramo = RAMO_ROTULO[ctx.ramo] || '';
    if (!tema && !ramo) return null;
    var ass = tema || ramo, o = [];
    o.push({ novo: 'Você também tem dúvida quando o assunto é ' + ass + '?', regra: 'Modelo de pergunta: fala direto com a dúvida de quem assiste.' });
    o.push({ novo: 'Se ' + ass + ' é um problema para você, fique até o fim.', regra: 'Modelo de problema: começa pela dor do público, sem afirmar fatos.' });
    o.push({ novo: tema && ramo ? 'Para quem gosta de ' + ramo + ': ' + tema + ' em poucos segundos.' : 'O que você precisa saber sobre ' + ass + ', em poucos segundos.', regra: 'Modelo de promessa: diz o que a pessoa leva do vídeo, sem prometer resultado.' });
    return o;
  }
  var CTAS = {
    vender: ['Quer o seu? Chame no WhatsApp e peça agora.', 'Toque no link da bio e faça seu pedido.', 'Mande "quero" no direct e eu te respondo.'],
    crescer: ['Siga o perfil para não perder o próximo.', 'Compartilhe com quem precisa ver isso.', 'Marque um amigo que vai gostar.'],
    engajar: ['Comente aqui o que você acha.', 'Salve este post para consultar depois.', 'Responda nos comentários: qual a sua experiência?'],
    lancar: ['Chame no direct para saber do lançamento.', 'Ative as notificações para ser o primeiro a saber.', 'Compartilhe com quem esperava por isso.']
  };
  var CTA_GERAL = ['Comente aqui o que você achou.', 'Salve este post para ver depois.', 'Chame no direct se tiver dúvida.'];

  // executarComando(id, texto, selecao{inicio,fim}|null, ctx, opcoes) -> {comando, original, novo, regra, mudou, versaoSimples, aviso?, selecao, modo, opcoes?}
  // Nunca altera o texto recebido: devolve a proposta; quem chama decide aceitar (aplicar) ou descartar.
  function executarComando(id, texto, selecaoIn, ctxIn, opcoes) {
    texto = String(texto || ''); opcoes = opcoes || {};
    var ctx = normalizarCtx(ctxIn), r;
    var inserir = (id === 'gancho' || id === 'cta');
    var sel = normSel(texto, inserir ? null : selecaoIn), orig = texto.slice(sel.inicio, sel.fim);
    if (id === 'tempo') id = opcoes.segundos >= 30 ? 't30' : 't15';
    if (id === 'corrigir') {
      var lista = correcoes(orig, { meio: !(sel.inicio === 0), seguras: true }), nv = aplicarLista(orig, lista), ct = {}; lista.forEach(function (x) { ct[x.regra] = (ct[x.regra] || 0) + 1; });
      r = resultado(id, orig, nv, lista.length ? 'Aplicadas ' + lista.length + ' correção(ões) segura(s): ' + Object.keys(ct).map(function (k) { return k.replace(/_/g, ' ') + ' (' + ct[k] + ')'; }).join(', ') + '.' : 'Nenhuma correção segura encontrada. O que é ambíguo (como "mais" e "mas") fica por sua conta.', sel);
    } else if (id === 'encurtar') {
      var e = encurtarTexto(orig);
      r = resultado(id, orig, e.texto, e.regras.length ? 'Regras aplicadas: ' + e.regras.join('; ') + '.' : 'Nada para cortar com segurança. Encurtar mais exige decidir o que importa, e isso é com você.', sel);
    } else if (id === 'direto') {
      var d = trocarLista(orig, DIRETO), l = limparSimples(d.texto), p = removerExpressoes(l.texto, PREAMBULOS), rg = [];
      if (d.qtd) rg.push('trocados ' + d.qtd + ' rodeio(s) por formas curtas'); rg = rg.concat(l.regras); if (p.qtd) rg.push('removidos ' + p.qtd + ' preâmbulo(s)');
      r = resultado(id, orig, p.texto, rg.length ? 'Regras aplicadas: ' + rg.join('; ') + '.' : 'Nenhum rodeio conhecido encontrado.', sel);
    } else if (id === 't15' || id === 't30') {
      var seg = id === 't15' ? 15 : 30, ja = estimarDuracao(orig);
      if (palavrasDe(orig) <= palavrasParaSegundos(seg)) r = resultado(id, orig, orig, 'Já cabe em ' + seg + ' s (' + rotuloTempo(ja.segundos) + ', limite de ~' + palavrasParaSegundos(seg) + ' palavras).', sel);
      else { var lim = limitarPalavras(orig, seg); r = resultado(id, orig, lim.texto, 'Limite de ~' + palavrasParaSegundos(seg) + ' palavras (2,6 por segundo). ' + (lim.regras.length ? 'Regras: ' + lim.regras.join('; ') + '. ' : '') + lim.nota, sel, { cabe: lim.cabe, segundos: seg }); }
    } else if (id === 'roteiro') {
      var fr = dividirFrases(orig), cenas = [], atual = '', na = 0, k;
      for (k = 0; k < fr.length; k++) { atual += (atual ? ' ' : '') + fr[k].texto; na += palavrasDe(fr[k].texto); if (na >= 9 || k === fr.length - 1) { cenas.push({ t: atual, n: na }); atual = ''; na = 0; } }
      if (cenas.length > 1 && cenas[cenas.length - 1].n < 4) { var u = cenas.pop(); cenas[cenas.length - 1].t += ' ' + u.t; cenas[cenas.length - 1].n += u.n; }
      var acu = 0, linhas = cenas.map(function (c, ix) {
        var s = Math.max(2, Math.round(c.n / PALAVRAS_POR_SEG)), a = acu; acu += s;
        return 'CENA ' + (ix + 1) + ' · ' + a + '–' + acu + ' s' + (ix === 0 ? ' (abertura)' : ix === cenas.length - 1 && cenas.length > 1 ? ' (fecho)' : '') + '\n' + c.t;
      });
      r = resultado(id, orig, cenas.length ? linhas.join('\n\n') + '\n\nTotal estimado: ' + acu + ' s' : orig, cenas.length ? 'Texto dividido em ' + cenas.length + ' cena(s) de ~9 palavras ou mais, com tempo a 2,6 palavras por segundo. Enquadramento e imagens não são sugeridos aqui.' : 'Escreva algum texto para dividir em cenas.', sel, { formato: ctx.formato || 'reel' });
    } else if (id === 'gancho') {
      var md = modelosGancho(ctx);
      if (!md) r = resultado(id, '', '', 'Preencha o assunto do vídeo (título do documento) para eu montar os modelos de abertura. Não invento assunto.', { inicio: 0, fim: 0 }, { opcoes: [], modo: 'inserir' });
      else r = resultado(id, '', md[0].novo + '\n\n', 'Três modelos de abertura montados com o seu assunto' + (RAMO_ROTULO[ctx.ramo] ? ' e ramo' : '') + '. Nenhum fato é afirmado; confira se combina com o seu vídeo.', { inicio: 0, fim: 0 }, { modo: 'inserir', opcoes: md.map(function (x) { return { novo: x.novo + '\n\n', regra: x.regra }; }) });
    } else if (id === 'cta') {
      var base = CTAS[ctx.objetivo] || CTA_GERAL, fimT = texto.length, pre = !texto.length ? '' : (/\n\n$/.test(texto) ? '' : (/\n$/.test(texto) ? '\n' : '\n\n'));
      r = resultado(id, '', pre + base[0], 'Modelos para o objetivo "' + (CTAS[ctx.objetivo] ? ctx.objetivo : 'geral (objetivo não informado)') + '". Ajuste ao canal que você realmente usa (WhatsApp, link, direct).', { inicio: fimT, fim: fimT }, { modo: 'inserir', opcoes: base.map(function (x) { return { novo: pre + x, regra: 'Modelo fixo por objetivo.' }; }) });
    } else if (id === 'melhorar') {
      var cl = correcoes(orig, { meio: !(sel.inicio === 0), seguras: true }), t1 = aplicarLista(orig, cl), l2 = limparSimples(t1), rg2 = [];
      if (cl.length) rg2.push(cl.length + ' correção(ões) segura(s)'); rg2 = rg2.concat(l2.regras);
      r = resultado(id, orig, l2.texto, rg2.length ? 'Limpeza por regras: ' + rg2.join('; ') + '.' : 'As regras não encontraram o que limpar. Melhorar de forma criativa exige reescrever, e isso não é possível sem IA.', sel);
    } else if (id === 'expandir') {
      var f3 = dividirFrases(orig), nv3 = f3.map(function (x) { return x.texto; }).join('\n');
      r = resultado(id, orig, f3.length > 1 ? nv3 : orig, 'Cada frase foi para uma linha, para dar respiro. As regras não acrescentam conteúdo.', sel, { dicas: ['Qual é o exemplo concreto (nome do produto, cliente, situação)?', 'Qual número ou prazo sustenta o que você diz?', 'O que a pessoa faz depois de ler?'] });
    } else if (id === 'natural') {
      var nn = trocarLista(orig, NATURAL);
      r = resultado(id, orig, nn.texto, nn.qtd ? 'Trocadas ' + nn.qtd + ' palavra(s) formal(is) por fala do dia a dia (ex.: "para" por "pra", "porém" por "mas").' : 'Nenhuma palavra formal conhecida encontrada.', sel);
    } else return null;
    // ponto de extensão: IA desligada. Mesmo que alguém passe um provedor, nada é chamado enquanto IA.ativo for false.
    if (IA.ativo === true && opcoes.ia && typeof opcoes.ia.refinar === 'function') r.refinavel = true;
    return r;
  }

  // ------------------------------------------------------------ diff palavra a palavra
  function tokens(s) { return String(s == null ? '' : s).match(/\S+/g) || []; }
  function juntar(ops) {
    var out = [], i;
    for (i = 0; i < ops.length; i++) {
      if (out.length && out[out.length - 1].t === ops[i].t) out[out.length - 1].v += ' ' + ops[i].v; else out.push({ t: ops[i].t, v: ops[i].v });
    }
    return out;
  }
  // devolve [{t:'=', v}|{t:'-', v}|{t:'+', v}] (palavras unidas por espaço; as quebras de linha não entram na comparação)
  function diffAntesDepois(antes, depois) {
    var A = tokens(antes), B = tokens(depois), ini = 0, fa = A.length, fb = B.length, ops = [], i, j;
    while (ini < fa && ini < fb && A[ini] === B[ini]) ini++;
    while (fa > ini && fb > ini && A[fa - 1] === B[fb - 1]) { fa--; fb--; }
    for (i = 0; i < ini; i++) ops.push({ t: '=', v: A[i] });
    var a = A.slice(ini, fa), b = B.slice(ini, fb), n = a.length, m = b.length;
    if (n && m && n * m <= 2500000) {
      var W = m + 1, L = new Uint16Array((n + 1) * W);
      for (i = n - 1; i >= 0; i--) for (j = m - 1; j >= 0; j--) L[i * W + j] = a[i] === b[j] ? L[(i + 1) * W + j + 1] + 1 : Math.max(L[(i + 1) * W + j], L[i * W + j + 1]);
      i = 0; j = 0;
      while (i < n && j < m) {
        if (a[i] === b[j]) { ops.push({ t: '=', v: a[i] }); i++; j++; }
        else if (L[(i + 1) * W + j] >= L[i * W + j + 1]) { ops.push({ t: '-', v: a[i] }); i++; }
        else { ops.push({ t: '+', v: b[j] }); j++; }
      }
      while (i < n) ops.push({ t: '-', v: a[i++] }); while (j < m) ops.push({ t: '+', v: b[j++] });
    } else { for (i = 0; i < n; i++) ops.push({ t: '-', v: a[i] }); for (j = 0; j < m; j++) ops.push({ t: '+', v: b[j] }); }
    for (i = fa; i < A.length; i++) ops.push({ t: '=', v: A[i] });
    // dentro de cada bloco de mudança, remoções antes de inserções
    var fin = [], bl = [], k;
    function esvazia() { fin = fin.concat(bl.filter(function (o) { return o.t === '-'; }), bl.filter(function (o) { return o.t === '+'; })); bl = []; }
    for (k = 0; k < ops.length; k++) { if (ops[k].t === '=') { esvazia(); fin.push(ops[k]); } else bl.push(ops[k]); }
    esvazia();
    return juntar(fin);
  }
  function resumoDiff(ops) { var r = 0, a = 0; ops.forEach(function (o) { var n = o.v.split(' ').length; if (o.t === '-') r += n; else if (o.t === '+') a += n; }); return { removidas: r, adicionadas: a }; }
  // HTML seguro do diff: todo texto passa por esc()
  function diffHTML(ops) {
    return ops.map(function (o) { var v = esc(o.v); return o.t === '-' ? '<del>' + v + '</del>' : o.t === '+' ? '<ins>' + v + '</ins>' : '<span>' + v + '</span>'; }).join(' ');
  }

  // ------------------------------------------------------------ eventos para o aprendizado (sem o texto do usuário)
  var ACOES_EVENTO = ['aberto', 'sug_aceita', 'sug_ignorada', 'cmd_aceito', 'cmd_descartado', 'cmd_desfeito', 'versao_salva'];
  function tiposEvento() { return ACOES_EVENTO.map(function (a) { return 'doc_' + a; }); }
  function montarSinal(acao, d) {
    if (ACOES_EVENTO.indexOf(acao) < 0) return null;
    d = d || {};
    var o = {};
    if (d.tipo) o.tipo = String(d.tipo).slice(0, 20);
    if (d.regra) o.regra = String(d.regra).slice(0, 40);
    if (d.comando) o.comando = String(d.comando).slice(0, 20);
    if (d.simples != null) o.simples = !!d.simples;
    if (d.formato) o.formato = String(d.formato).slice(0, 20);
    if (d.conteudo) o.conteudo = String(d.conteudo).slice(0, 40); // id opaco do documento: só serve para contar conteúdos distintos (Fase 4)
    if (d.versao != null && isFinite(d.versao)) o.versao = Math.max(0, Math.min(9999, Math.floor(+d.versao)));
    return { tipo: 'doc_' + acao, dados: o };
  }

  var API = {
    VERSAO: VERSAO, IA: IA, MAX_VISIVEIS: MAX_VISIVEIS, LIMITE_FRASE: LIMITE_FRASE, PALAVRAS_POR_SEG: PALAVRAS_POR_SEG, COMANDOS: COMANDOS, AVISO_SIMPLES: AVISO_SIMPLES,
    analisarDoc: analisarDoc, executarComando: executarComando, aplicar: aplicar, diffAntesDepois: diffAntesDepois, diffHTML: diffHTML, resumoDiff: resumoDiff,
    estimarDuracao: estimarDuracao, palavrasDe: palavrasDe, lerDuracao: lerDuracao, correcoes: correcoes, aplicarCorrecoes: function (t, o) { o = o || {}; o.seguras = true; return aplicarLista(t, correcoes(t, o)); },
    dividirFrases: dividirFrases, genericidade: genericidade, montarSinal: montarSinal, tiposEvento: tiposEvento, infoComando: infoComando, esc: esc
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else raiz.EvoluiDoc = API;
})(typeof window !== 'undefined' ? window : this);
