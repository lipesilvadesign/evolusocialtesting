// EvoluiSocial — ESCRITOR MÍNIMO DE PDF (Fase 5B). ES5, função pura, sem rede, sem biblioteca.
// Gera um PDF 1.4 de texto: fonte padrão Helvetica (não embutida), codificação WinAnsi (acentos do português corretos),
// quebra de linha pela largura real da fonte e paginação A4. O texto nunca sai do navegador.
// Limitações honestas: só texto (sem imagem), só alfabeto latino (emoji e escritas fora do WinAnsi são omitidos ou viram "?").
(function (raiz) {
  'use strict';
  var VERSAO = 'pdf-v1';

  // Larguras da Helvetica (AFM padrão, em milésimos de em) para ASCII 32..126
  var ASCII_W = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
    556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
    1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
    667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
    333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
    556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584];
  // 0xA0..0xBF
  var LAT_A0 = [278, 333, 556, 556, 556, 556, 260, 556, 333, 737, 370, 556, 584, 333, 737, 333,
    400, 584, 333, 333, 333, 556, 537, 278, 333, 333, 365, 556, 834, 834, 834, 611];
  // 0xC0..0xFF: letra-base para herdar a largura (acento não muda a largura na Helvetica)
  var LAT_C0 = 'AAAAAAACEEEEIIIIDNOOOOO*OUUUUYPsaaaaaaaceeeeiiiidnooooo/ouuuuypy';
  var WIN = { 0x20AC: 128, 0x201A: 130, 0x0192: 131, 0x201E: 132, 0x2026: 133, 0x2020: 134, 0x2021: 135, 0x02C6: 136, 0x2030: 137, 0x0160: 138, 0x2039: 139, 0x0152: 140, 0x017D: 142,
    0x2018: 145, 0x2019: 146, 0x201C: 147, 0x201D: 148, 0x2022: 149, 0x2013: 150, 0x2014: 151, 0x02DC: 152, 0x2122: 153, 0x0161: 154, 0x203A: 155, 0x0153: 156, 0x017E: 158, 0x0178: 159 };
  var WIN_W = { 128: 556, 130: 222, 131: 556, 132: 333, 133: 1000, 134: 556, 135: 556, 136: 333, 137: 1000, 138: 667, 139: 333, 140: 1000, 142: 611, 145: 222, 146: 222, 147: 333, 148: 333, 149: 350, 150: 556, 151: 1000, 152: 333, 153: 1000, 154: 500, 155: 333, 156: 944, 158: 500, 159: 667 };
  var ESPECIAIS_C0 = { 0xC6: 1000, 0xE6: 889, 0xD0: 722, 0xF0: 556, 0xDE: 667, 0xFE: 556, 0xDF: 611, 0xD7: 584, 0xF7: 584, 0xD8: 778, 0xF8: 611 };

  var TROCAS = { 0x2248: '~', 0x2192: '->', 0x2190: '<-', 0x2212: '-', 0x2265: '>=', 0x2264: '<=', 0x2713: 'v', 0x00B7: '\xB7' }; // fora do WinAnsi: troca por equivalente simples
  function paraBytesWin(texto) { // string Unicode -> string de bytes WinAnsi (cada char 0..255)
    var t = String(texto == null ? '' : texto), out = '', i, c, b;
    try { if (t.normalize) t = t.normalize('NFC'); } catch (e) { /* sem normalize */ }
    for (i = 0; i < t.length; i++) {
      c = t.charCodeAt(i);
      if (c >= 0xD800 && c <= 0xDBFF) { i++; continue; }                 // par substituto (emoji etc.): omitido
      if (c === 0xFE0F || c === 0x200D || c === 0x200B || c === 0xFEFF) continue; // invisíveis
      if (c === 9) { out += ' '; continue; }
      if (c === 10) { out += '\n'; continue; }
      if (c === 13) continue;
      if (c === 0xA0) { out += ' '; continue; }
      if (c >= 32 && c <= 126) { out += String.fromCharCode(c); continue; }
      if (c >= 0xA1 && c <= 0xFF) { out += String.fromCharCode(c); continue; }
      b = WIN[c];
      if (b) { out += String.fromCharCode(b); continue; }
      if (c < 32) continue;
      out += TROCAS[c] || '?';
    }
    return out;
  }
  function larguraByte(b) {
    if (b >= 32 && b <= 126) return ASCII_W[b - 32];
    if (b >= 0xA0 && b <= 0xBF) return LAT_A0[b - 0xA0];
    if (b >= 0xC0 && b <= 0xFF) {
      if (ESPECIAIS_C0[b]) return ESPECIAIS_C0[b];
      var base = LAT_C0.charCodeAt(b - 0xC0);
      return base >= 32 && base <= 126 ? ASCII_W[base - 32] : 556;
    }
    return WIN_W[b] || 556;
  }
  function larguraTexto(bytes, tam, negrito) {
    var w = 0, i;
    for (i = 0; i < bytes.length; i++) w += larguraByte(bytes.charCodeAt(i));
    return w * tam / 1000 * (negrito ? 1.08 : 1); // negrito: estimativa conservadora (a quebra erra para o lado seguro)
  }
  function escapar(bytes) { // string literal de PDF
    var o = '', i, c;
    for (i = 0; i < bytes.length; i++) {
      c = bytes.charCodeAt(i);
      if (c === 40 || c === 41 || c === 92) o += '\\' + String.fromCharCode(c);
      else if (c < 32 || c > 126) o += '\\' + ('00' + c.toString(8)).slice(-3);
      else o += String.fromCharCode(c);
    }
    return o;
  }
  function quebrar(bytes, tam, negrito, larguraMax) { // quebra em linhas pela largura; palavra maior que a linha é cortada
    var palavras = bytes.split(' '), linhas = [], atual = '', i, p, cand, k;
    for (i = 0; i < palavras.length; i++) {
      p = palavras[i];
      if (p === '' && atual === '') continue;
      cand = atual ? atual + ' ' + p : p;
      if (larguraTexto(cand, tam, negrito) <= larguraMax) { atual = cand; continue; }
      if (atual) { linhas.push(atual); atual = ''; }
      while (larguraTexto(p, tam, negrito) > larguraMax && p.length > 1) { // palavra gigante (ex.: link)
        k = p.length - 1; while (k > 1 && larguraTexto(p.slice(0, k), tam, negrito) > larguraMax) k--;
        linhas.push(p.slice(0, k)); p = p.slice(k);
      }
      atual = p;
    }
    if (atual) linhas.push(atual);
    return linhas;
  }
  function hex16(texto) { // título em UTF-16BE para o dicionário Info (aceita qualquer caractere)
    var s = 'FEFF', i, h, t = String(texto == null ? '' : texto);
    for (i = 0; i < t.length; i++) { h = t.charCodeAt(i).toString(16).toUpperCase(); s += ('0000' + h).slice(-4); }
    return '<' + s + '>';
  }
  function dataPdf(d) {
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return 'D:' + d.getUTCFullYear() + z(d.getUTCMonth() + 1) + z(d.getUTCDate()) + z(d.getUTCHours()) + z(d.getUTCMinutes()) + z(d.getUTCSeconds()) + 'Z';
  }

  // doc: { titulo, meta: [[rotulo, valor], ...], secoes: [{ titulo, texto }], rodape, data: Date }
  function gerar(doc) {
    doc = doc || {};
    var LARG = 595, ALT = 842, ME = 56, MD = 56, MS = 60, MI = 64, UTIL = LARG - ME - MD;
    var itens = []; // { bytes, tam, neg, cinza, antes }
    function empurra(texto, tam, neg, cinza, antes, entre) {
      var parags = paraBytesWin(texto).split('\n'), pi, linhas, li, lead = Math.round(tam * 1.38);
      for (pi = 0; pi < parags.length; pi++) {
        if (!parags[pi].trim()) { itens.push({ bytes: '', tam: tam, lead: Math.round(lead * 0.55), antes: 0 }); continue; }
        linhas = quebrar(parags[pi], tam, neg, UTIL);
        for (li = 0; li < linhas.length; li++) itens.push({ bytes: linhas[li], tam: tam, neg: neg, cinza: cinza, lead: lead, antes: (pi === 0 && li === 0) ? (antes || 0) : 0 });
      }
      if (entre) itens.push({ bytes: '', tam: tam, lead: entre, antes: 0 });
    }
    empurra(doc.titulo || 'Documento sem título', 20, true, 0, 0, 6);
    var meta = doc.meta || [], mi;
    for (mi = 0; mi < meta.length; mi++) if (meta[mi] && meta[mi][1] != null && String(meta[mi][1]) !== '') empurra(meta[mi][0] + ': ' + meta[mi][1], 10, false, 0.38, 0, 0);
    var secs = doc.secoes || [], si;
    for (si = 0; si < secs.length; si++) {
      empurra(secs[si].titulo || '', 13, true, 0, 18, 4);
      empurra(secs[si].texto || '', 11, false, 0, 0, 0);
    }
    // paginação
    var paginas = [[]], y = ALT - MS, ii, it, cur = paginas[0];
    for (ii = 0; ii < itens.length; ii++) {
      it = itens[ii];
      var gasto = (it.antes || 0) + it.lead;
      if (y - gasto < MI) { if (!it.bytes && cur.length === 0) continue; paginas.push([]); cur = paginas[paginas.length - 1]; y = ALT - MS; if (!it.bytes) continue; gasto = it.lead; }
      y -= gasto;
      if (it.bytes) cur.push({ it: it, y: y });
    }
    var total = paginas.length, partes = [], offs = [], pos = 0;
    function emite(s) { partes.push(s); pos += s.length; }
    function objeto(n, corpo) { offs[n] = pos; emite(n + ' 0 obj\n' + corpo + '\nendobj\n'); }
    emite('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
    var nObj = 5 + total * 2, kids = [], p;
    for (p = 0; p < total; p++) kids.push((6 + p * 2) + ' 0 R');
    objeto(1, '<< /Type /Catalog /Pages 2 0 R >>');
    objeto(2, '<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + total + ' >>');
    objeto(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    objeto(4, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    objeto(5, '<< /Title ' + hex16(doc.titulo || 'Documento') + ' /Producer (EvoluiSocial) /Creator (EvoluiSocial)' + (doc.data ? ' /CreationDate (' + dataPdf(doc.data) + ')' : '') + ' >>');
    var rodape = doc.rodape || 'Gerado no EvoluiSocial', j, linhasPg, fluxo, tx;
    for (p = 0; p < total; p++) {
      linhasPg = paginas[p]; fluxo = '';
      for (j = 0; j < linhasPg.length; j++) {
        tx = linhasPg[j];
        fluxo += 'BT /' + (tx.it.neg ? 'F2' : 'F1') + ' ' + tx.it.tam + ' Tf ' + (tx.it.cinza ? tx.it.cinza + ' g ' : '0 g ') + ME + ' ' + tx.y.toFixed(1) + ' Td (' + escapar(tx.it.bytes) + ') Tj ET\n';
      }
      fluxo += 'BT /F1 8 Tf 0.45 g ' + ME + ' 32 Td (' + escapar(paraBytesWin(rodape + '  |  Página ' + (p + 1) + ' de ' + total)) + ') Tj ET\n';
      objeto(6 + p * 2, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + LARG + ' ' + ALT + '] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ' + (7 + p * 2) + ' 0 R >>');
      objeto(7 + p * 2, '<< /Length ' + fluxo.length + ' >>\nstream\n' + fluxo + 'endstream');
    }
    var xref = pos, n, tab = 'xref\n0 ' + (nObj + 1) + '\n0000000000 65535 f \n';
    for (n = 1; n <= nObj; n++) tab += ('0000000000' + offs[n]).slice(-10) + ' 00000 n \n';
    emite(tab + 'trailer\n<< /Size ' + (nObj + 1) + ' /Root 1 0 R /Info 5 0 R >>\nstartxref\n' + xref + '\n%%EOF\n');
    var binario = partes.join('');
    return { binario: binario, paginas: total, bytes: function () { return paraBytes(binario); } };
  }
  function paraBytes(bin) {
    var u = new Uint8Array(bin.length), i;
    for (i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i) & 255;
    return u;
  }

  // Texto puro (.txt) com o mesmo conteúdo do PDF
  function montarTxt(doc) {
    doc = doc || {};
    var L = [String(doc.titulo || 'Documento sem título'), ''], meta = doc.meta || [], i;
    for (i = 0; i < meta.length; i++) if (meta[i] && meta[i][1] != null && String(meta[i][1]) !== '') L.push(meta[i][0] + ': ' + meta[i][1]);
    var secs = doc.secoes || [];
    for (i = 0; i < secs.length; i++) { L.push('', '== ' + (secs[i].titulo || '') + ' ==', String(secs[i].texto || '')); }
    L.push('', '—', doc.rodape || 'Gerado no EvoluiSocial');
    return L.join('\n') + '\n';
  }
  function nomeArquivo(titulo, ext, dataIso) {
    var s = String(titulo || 'documento').toLowerCase();
    try { if (s.normalize) s = s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) { /* ok */ }
    s = s.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'documento';
    return s + (dataIso ? '-' + String(dataIso).slice(0, 10) : '') + '.' + ext;
  }

  var API = { VERSAO: VERSAO, gerar: gerar, montarTxt: montarTxt, nomeArquivo: nomeArquivo, paraBytes: paraBytes, paraBytesWin: paraBytesWin, larguraTexto: larguraTexto, quebrar: quebrar };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else raiz.EvoluiPDF = API;
})(typeof window !== 'undefined' ? window : this);
