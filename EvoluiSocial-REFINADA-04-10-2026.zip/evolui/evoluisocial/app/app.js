/* EvoluiSocial — área logada (busca, histórico, laboratório, perfil) · v2 (01/10/2026)
   Sem dependências além do supabase-js. Tudo que é sensível (limites, plano, conteúdo travado)
   é decidido no servidor; esta tela só desenha o que chegou. */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var urlSegura = function (u) { u = String(u || ''); return /^https:\/\/[^\s"<>]+$/i.test(u) ? u : ''; };
  var E = window.Evolui || {}, sb = E.sb;

  var RAMOS = [
    ['doces', 'Doces e confeitaria', '🧁'], ['alimentacao', 'Alimentação e restaurantes', '🍽️'], ['beleza', 'Beleza e estética', '💇'],
    ['moda', 'Moda e acessórios', '👗'], ['saude', 'Saúde e bem-estar', '🩺'], ['fitness', 'Academia e fitness', '💪'],
    ['pet', 'Pet', '🐶'], ['casa', 'Casa e decoração', '🛋️'], ['educacao', 'Educação e cursos', '📚'],
    ['servicos', 'Serviços profissionais', '💼'], ['criador', 'Marca pessoal / criador', '🎥'], ['outro', 'Outro', '✨']
  ];
  var RAMO = {}; RAMOS.forEach(function (r) { RAMO[r[0]] = r; });
  var OBJ = [['vender', 'Vender mais', '💰'], ['crescer', 'Ganhar seguidores', '📈'], ['engajar', 'Engajar quem já me segue', '💬'], ['lancar', 'Lançar um produto', '🚀']];
  var UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');
  var REDES = [['instagram', 'Instagram', 'IG', 'https://instagram.com/'], ['tiktok', 'TikTok', 'TT', 'https://www.tiktok.com/@'], ['youtube', 'YouTube', 'YT', 'https://www.youtube.com/@']];
  var LIMITE = { free: 20, pro: 300, master: 1000 };
  var NOME_PLANO = { free: 'Free', pro: 'Pro', master: 'Master' };
  var CORES = { 'Wikipédia': '#034FA8', 'Notícias (GDELT)': '#FF3180' };
  var ABAS = ['buscar', 'historico', 'laboratorio', 'perfil'];
  // pirâmide: primeiro o veredito, depois o que fazer, por último as provas
  var RECOMENDA = {
    em_alta: 'Poste hoje: o assunto está em alta agora no Brasil.',
    crescendo: 'Bom momento: publique nos próximos 3 dias, enquanto o interesse sobe.',
    comecando: 'Sinal inicial: teste com um post simples e veja a resposta.',
    estavel: 'Interesse constante: ótimo para conteúdo de base, que vale o ano todo.',
    caindo: 'Interesse caindo: use como gancho rápido, não como campanha.',
    pico: 'Pico passageiro: só vale a pena se você postar hoje.',
    insuficiente: 'Sinal ainda pequeno: vale ampliar o termo ou testar uma variação.'
  };

  var st = { user: null, perfil: null, redes: [], aba: 'buscar', emAlta: null, paraVoce: null, local: null, resultado: null, labEditando: null, precos: null };

  // ---------------------------------------------------------------- utilidades
  var tt;
  function toast(m) { var el = $('#toast'); el.textContent = m; el.hidden = false; clearTimeout(tt); tt = setTimeout(function () { el.hidden = true; }, 3600); }
  function data(d) { try { return new Date(d).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' }); } catch (e) { return ''; } }
  function dataHora(d) { try { return new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } }
  function pct(x) { return x == null ? '—' : (x > 0 ? '+' : '') + Math.round(x * 100) + '%'; }
  function reais(c) { return (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
  function plano() { return (st.perfil && st.perfil.plano) || 'free'; }
  // registra um evento de uso (alimenta o agente de perfil e as métricas do painel). Nunca trava a tela.
  function registrar(tipo, dados) {
    if (!sb || !st.user || (st.perfil && st.perfil.personalizar === false && tipo !== 'limite' && tipo !== 'plano_interesse')) return;
    try { sb.from('evolui_eventos').insert({ user_id: st.user.id, tipo: tipo, dados: dados || {} }).then(function () {}, function () {}); } catch (e) { /* sem rede */ }
  }
  async function copiar(texto, el, formato) {
    try { await navigator.clipboard.writeText(texto); toast('Copiado! Agora é só colar no seu post.'); }
    catch (e) { if (el) { var r = document.createRange(); r.selectNodeContents(el); var s = getSelection(); s.removeAllRanges(); s.addRange(r); } toast('Texto selecionado. Use Copiar do seu celular.'); }
    registrar('copiou_legenda', formato ? { formato: formato } : {});
  }
  function nomeCurto() { var n = (st.perfil && st.perfil.nome) || (st.user && st.user.user_metadata && (st.user.user_metadata.full_name || st.user.user_metadata.name)) || ''; return n.split(' ')[0] || 'você'; }
  function avatarHTML(cls) {
    var url = st.user && st.user.user_metadata && (st.user.user_metadata.avatar_url || st.user.user_metadata.picture);
    var ini = esc((nomeCurto()[0] || 'E').toUpperCase());
    return '<span class="avatar ' + (cls || '') + '">' + (urlSegura(url) ? '<img src="' + esc(url) + '" alt="" referrerpolicy="no-referrer">' : ini) + '</span>';
  }
  function limpaArroba(v) {
    v = String(v || '').trim();
    var m = v.match(/(?:instagram\.com|tiktok\.com|youtube\.com)\/@?([A-Za-z0-9._-]+)/i);
    if (m) v = m[1];
    return v.replace(/^@+/, '').replace(/[^A-Za-z0-9._-]/g, '').slice(0, 40);
  }
  var norm = function (s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); };
  var LOGO = '<img class="logo-img logo-azul" src="/evoluisocial/marca/evolui-horizontal.svg" alt="EvoluiSocial" width="95" height="34"><img class="logo-img logo-claro" src="/evoluisocial/marca/evolui-horizontal-claro.svg" alt="" width="95" height="34" aria-hidden="true">';
  var ICON = {
    buscar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h5v-5.5h4V20h5V9.5"/></svg>',
    historico: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 2"/></svg>',
    laboratorio: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 3h6M10 3v6L4.5 18.5A1.8 1.8 0 0 0 6 21h12a1.8 1.8 0 0 0 1.5-2.5L14 9V3"/><path d="M7 15h10"/></svg>',
    perfil: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg>',
    lupa: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    cadeado: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
    tema: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"></svg>'
  };

  // ---------------------------------------------------------------- entrar
  // Link de redefinição de senha (enviado pelo e-mail oficial): a pessoa escolhe a senha nova aqui.
  // A senha vai direto para o Supabase Auth; ninguém da equipe vê.
  function novaSenha() {
    if (document.getElementById('nsF')) return;
    var f = document.createElement('div'); f.className = 'modal-fundo';
    f.innerHTML = '<form class="modal" id="nsF" role="dialog" aria-modal="true" aria-labelledby="nsT"><h3 id="nsT">Crie sua nova senha</h3><p class="sub">Mínimo de 8 caracteres.</p>' +
      '<div class="campo"><label for="nsS">Nova senha</label><input id="nsS" type="password" minlength="8" maxlength="72" autocomplete="new-password" required></div>' +
      '<p class="muted" id="nsE" role="alert" style="margin:0"></p><div class="linha"><button class="btn cta" type="submit">Salvar senha</button></div></form>';
    document.body.appendChild(f);
    $('#nsS', f).focus();
    $('#nsF', f).onsubmit = async function (e) {
      e.preventDefault();
      var v = $('#nsS', f).value;
      if (v.length < 8) { $('#nsE', f).textContent = 'Use pelo menos 8 caracteres.'; return; }
      var r = await sb.auth.updateUser({ password: v });
      if (r.error) { $('#nsE', f).textContent = 'Não foi possível salvar. Peça um novo link e tente de novo.'; return; }
      f.remove(); toast('Senha nova salva.');
    };
  }
  function telaEntrar(msgErro) {
    $('#raiz').innerHTML =
      '<main class="entrar"><div class="caixa">' +
      '<a class="logo" href="/evoluisocial/" aria-label="EvoluiSocial, início">' + LOGO + '</a>' +
      '<h1>Entre e veja o que está <em>em alta</em> no seu ramo.</h1>' +
      '<p>Tendências com fontes reais, ideias de post e um laboratório para testar sua bio e suas legendas.</p>' +
      (msgErro ? '<div class="erro" role="alert">' + esc(msgErro) + '</div>' : '') +
      '<button class="btn-google" id="google"><span class="g">G</span>Continuar com Google</button>' +
      '<p class="fino">Usamos sua conta Google só para criar seu acesso. Nunca postamos nada por você. Ao continuar, você aceita a <a href="/privacidade">Política de privacidade</a>.</p>' +
      '<a class="fino" href="/evoluisocial/">← Voltar para o site</a>' +
      '</div></main>';
    $('#google').onclick = async function () {
      this.disabled = true; this.textContent = 'Abrindo o Google…';
      try { var r = await E.entrarGoogle(); if (r && r.error) throw r.error; }
      catch (e) { telaEntrar('Não conseguimos abrir o login do Google. Tente de novo em instantes.'); }
    };
  }

  // ---------------------------------------------------------------- dados
  async function carregarPerfil() {
    var r = await sb.from('evolui_perfis').select('*').eq('id', st.user.id).maybeSingle();
    st.perfil = r.data || null;
    var rr = await sb.from('evolui_redes').select('rede,usuario').eq('user_id', st.user.id);
    st.redes = rr.data || [];
  }
  async function usoMes() { var r = await sb.rpc('evolui_buscas_no_mes'); return r.data || 0; }

  // ---------------------------------------------------------------- estrutura
  function montarApp() {
    var nomes = { buscar: 'Início', historico: 'Histórico', laboratorio: 'Laboratório', perfil: 'Perfil' };
    var p = plano();
    $('#raiz').innerHTML =
      '<div class="app">' +
      '<header class="topo"><a class="logo" href="#buscar">' + LOGO + '</a>' +
      '<div class="topo-acoes"><button class="plano-tag' + (p !== 'free' ? ' pago' : '') + '" id="tagPlano" title="Ver planos">' + NOME_PLANO[p] + '</button>' +
      '<button class="icone" data-tema type="button" aria-label="Alternar tema">' + ICON.tema + '</button>' +
      '<button class="avatar" id="btnPerfil" aria-label="Abrir meu perfil">' + avatarHTML() + '</button></div></header>' +
      '<nav class="nav" aria-label="Menu">' + ABAS.map(function (a) {
        return '<button data-aba="' + a + '"><span class="ic">' + ICON[a] + '</span>' + nomes[a] + '</button>';
      }).join('') +
      '<div class="nav-rodape"><a href="/evoluisocial/">Site da EvoluiSocial</a><a href="/privacidade">Privacidade</a><a href="/">Felipe Branding ↗</a></div></nav>' +
      '<main class="conteudo" id="conteudo" tabindex="-1"></main></div>';
    $$('.nav button').forEach(function (b) { b.onclick = function () { ir(b.dataset.aba); }; });
    $('#btnPerfil').onclick = function () { ir('perfil'); };
    $('#tagPlano').onclick = function () { abrirPlanos('topo'); };
    if (E.pintaTema) E.pintaTema();
  }
  function ir(aba, extra) {
    if (ABAS.indexOf(aba) < 0) aba = 'buscar';
    st.aba = aba;
    if (location.hash !== '#' + aba) history.replaceState(null, '', location.pathname + location.search + '#' + aba);
    $$('.nav button').forEach(function (b) { b.setAttribute('aria-current', b.dataset.aba === aba ? 'page' : 'false'); });
    var c = $('#conteudo'); c.innerHTML = '';
    window.scrollTo(0, 0);
    ({ buscar: telaBuscar, historico: telaHistorico, laboratorio: telaLab, perfil: telaPerfil })[aba](extra);
    registrar('aba', { aba: aba });
  }

  // ---------------------------------------------------------------- onboarding (cards)
  function abrirOnboarding(editando) {
    var p = st.perfil || {};
    var redesAtuais = {}; st.redes.forEach(function (r) { redesAtuais[r.rede] = r.usuario; });
    var d = {
      nome: p.nome || (st.user.user_metadata && (st.user.user_metadata.full_name || st.user.user_metadata.name)) || ((st.user.email || '').split('@')[0]) || '',
      ramo: p.ramo || '', ramo_detalhe: p.ramo_detalhe || '', uf: p.uf || '', cidade: p.cidade || '', cidade_ibge: p.cidade_ibge || '',
      objetivo: p.objetivo || '',
      redesOn: { instagram: !!redesAtuais.instagram, tiktok: !!redesAtuais.tiktok, youtube: !!redesAtuais.youtube },
      redes: { instagram: redesAtuais.instagram || '', tiktok: redesAtuais.tiktok || '', youtube: redesAtuais.youtube || '' }
    };
    var fluxo = editando ? [0, 1, 2, 3, 4] : [1, 4]; var passo = 0, TOTAL = fluxo.length, cidades = [], listaFalhou = false;
    var el = document.createElement('div'); el.className = 'onb'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true');
    document.body.appendChild(el); document.documentElement.style.overflow = 'hidden';

    function etapa() { return fluxo[passo]; }
    function fechar() { el.remove(); document.documentElement.style.overflow = ''; }
    function render(erro) {
      var corpo = '';
      if (etapa() === 0) corpo = '<h2 id="onbT">Como podemos te chamar?</h2><p class="sub">É assim que vamos falar com você aqui dentro.</p>' +
        '<div class="campo"><label for="oNome">Seu nome</label><input id="oNome" maxlength="80" autocomplete="name" value="' + esc(d.nome) + '"></div>';
      if (etapa() === 1) corpo = '<h2 id="onbT">Qual é a sua área de atuação?</h2><p class="sub">' + (editando ? 'Usamos para sugerir buscas e ideias que façam sentido para você.' : 'São só 2 perguntas. Cidade e redes você completa depois, quando quiser.') + '</p>' +
        '<div class="opcoes">' + RAMOS.map(function (r) { return '<button class="opcao" data-ramo="' + r[0] + '" aria-pressed="' + (d.ramo === r[0]) + '"><span class="em">' + r[2] + '</span>' + esc(r[1]) + '</button>'; }).join('') + '</div>' +
        '<div class="campo"><label for="oDet">Conte em poucas palavras o que você vende <span class="muted">(opcional)</span></label><input id="oDet" maxlength="80" placeholder="ex.: bolos de festa sob encomenda" value="' + esc(d.ramo_detalhe) + '"></div>';
      if (etapa() === 2) corpo = '<h2 id="onbT">Onde fica o seu negócio?</h2><p class="sub">Para mostrar o que acontece perto de você.</p>' +
        '<div class="campo"><label for="oUF">Estado</label><select id="oUF"><option value="">Escolha</option>' + UFS.map(function (u) { return '<option' + (d.uf === u ? ' selected' : '') + '>' + u + '</option>'; }).join('') + '</select></div>' +
        '<div class="campo"><label for="oCid">Cidade</label><input id="oCid" autocomplete="off" placeholder="' + (d.uf ? 'Digite e escolha na lista' : 'Escolha o estado primeiro') + '" value="' + esc(d.cidade) + '"' + (d.uf ? '' : ' disabled') + '><div class="cidades" id="oCidL"></div><small id="oCidS">' + (d.cidade_ibge ? '✓ Cidade confirmada' : '') + '</small></div>';
      if (etapa() === 3) corpo = '<h2 id="onbT">Em quais redes você está?</h2><p class="sub">Ative as que você usa e informe só o nome do perfil. Nunca pedimos senha.</p>' +
        REDES.map(function (r) {
          var on = d.redesOn[r[0]];
          return '<div class="rede-opcao' + (on ? ' on' : '') + '" data-rede="' + r[0] + '"><button class="cab" type="button" aria-pressed="' + on + '"><span class="ico ' + r[0] + '" style="width:34px;height:34px;border-radius:50%;display:grid;place-items:center;color:#fff;font-weight:800;font-size:12px">' + r[2] + '</span>' + r[1] + '<span class="tg" aria-hidden="true"></span></button>' +
            (on ? '<label class="arroba"><span>@</span><input data-handle="' + r[0] + '" maxlength="60" autocapitalize="none" autocomplete="off" spellcheck="false" placeholder="seuperfil" value="' + esc(d.redes[r[0]]) + '" aria-label="Seu perfil no ' + r[1] + '"></label>' : '') + '</div>';
        }).join('');
      if (etapa() === 4) corpo = '<h2 id="onbT">Qual é o seu objetivo agora?</h2><p class="sub">Muda as chamadas das ideias de post. Dá para trocar depois.</p>' +
        '<div class="opcoes">' + OBJ.map(function (o) { return '<button class="opcao" data-obj="' + o[0] + '" aria-pressed="' + (d.objetivo === o[0]) + '"><span class="em">' + o[2] + '</span>' + o[1] + '</button>'; }).join('') + '</div>';

      el.innerHTML = '<div class="onb-topo"><span class="logo">' + LOGO + '</span><div class="onb-prog" aria-label="Passo ' + (passo + 1) + ' de ' + TOTAL + '">' +
        Array.from({ length: TOTAL }, function (_, i) { return '<i class="' + (i <= passo ? 'on' : '') + '"></i>'; }).join('') + '</div>' +
        (editando ? '<button class="btn ghost sm" id="oFechar">Fechar</button>' : '<span class="kicker">' + (passo + 1) + '/' + TOTAL + '</span>') + '</div>' +
        '<div class="onb-corpo"><div class="onb-card" style="display:flex;flex-direction:column;gap:16px">' + corpo + (erro ? '<p class="erro-campo" role="alert">' + esc(erro) + '</p>' : '') + '</div>' +
        '<div class="onb-acoes">' + (passo > 0 ? '<button class="btn" id="oVoltar">Voltar</button>' : '<span></span>') +
        '<button class="btn cta" id="oSeguir">' + (passo === TOTAL - 1 ? (editando ? 'Concluir' : 'Ver minha Home') : 'Continuar') + '</button></div></div>';
      el.setAttribute('aria-labelledby', 'onbT');
      ligar();
      var f = el.querySelector('input:not([disabled]),select'); if (f && etapa() !== 1 && etapa() !== 4) f.focus();
    }
    function guardar() {
      if (etapa() === 0) d.nome = $('#oNome', el).value.trim();
      if (etapa() === 1) d.ramo_detalhe = $('#oDet', el).value.trim();
      if (etapa() === 3) $$('[data-handle]', el).forEach(function (i) { d.redes[i.dataset.handle] = limpaArroba(i.value); });
    }
    function validar() {
      if (etapa() === 0 && d.nome.length < 2) return 'Digite seu nome.';
      if (etapa() === 1 && !d.ramo) return 'Escolha um ramo.';
      if (etapa() === 2 && (!d.uf || !d.cidade)) return 'Escolha o estado e a cidade.';
      // a cidade precisa vir da lista oficial do IBGE (evita cidade digitada errada); só aceita texto livre se a lista não carregou
      if (etapa() === 2 && !d.cidade_ibge && !listaFalhou) {
        var exata = cidades.filter(function (c) { return norm(c.nome) === norm(d.cidade); })[0];
        if (exata) { d.cidade = exata.nome; d.cidade_ibge = exata.id; } else return 'Escolha sua cidade na lista que aparece ao digitar.';
      }
      if (etapa() === 3) for (var k in d.redesOn) if (d.redesOn[k] && !d.redes[k]) return 'Informe o nome do perfil ou desative a rede.';
      if (etapa() === 4 && !d.objetivo) return 'Escolha um objetivo.';
      return null;
    }
    async function carregarCidades() {
      var s = $('#oCidS', el); if (!d.uf) return;
      if (s) s.textContent = 'Carregando cidades…';
      try { cidades = (await E.api('cidades', { uf: d.uf })).cidades || []; listaFalhou = false; if ($('#oCidS', el)) $('#oCidS', el).textContent = d.cidade_ibge ? '✓ Cidade confirmada' : ''; filtrar(); }
      catch (e) { cidades = []; listaFalhou = true; if ($('#oCidS', el)) $('#oCidS', el).textContent = 'Não conseguimos carregar a lista. Digite o nome da cidade.'; }
    }
    function filtrar() {
      var inp = $('#oCid', el), L = $('#oCidL', el); if (!inp || !L) return;
      var q = norm(inp.value).trim();
      if (!q || (d.cidade && inp.value === d.cidade && d.cidade_ibge)) { L.innerHTML = ''; return; }
      var m = cidades.filter(function (c) { return norm(c.nome).indexOf(q) === 0; }).concat(cidades.filter(function (c) { var n = norm(c.nome); return n.indexOf(q) > 0; })).slice(0, 6);
      L.innerHTML = m.length ? m.map(function (c) { return '<button class="item" type="button" data-ibge="' + esc(c.id) + '" data-nome="' + esc(c.nome) + '">' + esc(c.nome) + ' <span class="muted">' + esc(d.uf) + '</span></button>'; }).join('') : (cidades.length ? '<p class="muted" style="margin:0;font-size:14px">Nenhuma cidade com esse nome em ' + esc(d.uf) + '.</p>' : '');
    }
    function ligar() {
      var v = $('#oVoltar', el); if (v) v.onclick = function () { guardar(); passo--; render(); if (etapa() === 2) carregarCidades(); };
      var x = $('#oFechar', el); if (x) x.onclick = fechar;
      $('#oSeguir', el).onclick = async function () {
        guardar(); var erro = validar(); if (erro) { render(erro); if (etapa() === 2) filtrar(); return; }
        if (passo < TOTAL - 1) { passo++; render(); if (etapa() === 2) carregarCidades(); return; }
        this.disabled = true; this.textContent = 'Salvando…';
        try { await salvar(); fechar(); toast(editando ? 'Perfil atualizado.' : 'Pronto! Faça sua primeira pesquisa.'); montarApp(); ir(editando ? 'perfil' : 'buscar'); if (!editando && st.planoPendente) { var pp = st.planoPendente; st.planoPendente = null; setTimeout(function () { abrirPlanos('site', pp); }, 400); } }
        catch (e) { render('Não conseguimos salvar agora. Confira sua internet e tente de novo.'); }
      };
      $$('[data-ramo]', el).forEach(function (b) { b.onclick = function () { d.ramo = b.dataset.ramo; $$('[data-ramo]', el).forEach(function (o) { o.setAttribute('aria-pressed', o === b); }); }; });
      $$('[data-obj]', el).forEach(function (b) { b.onclick = function () { d.objetivo = b.dataset.obj; $$('[data-obj]', el).forEach(function (o) { o.setAttribute('aria-pressed', o === b); }); }; });
      $$('.rede-opcao .cab', el).forEach(function (b) { b.onclick = function () { guardar(); var k = b.parentNode.dataset.rede; d.redesOn[k] = !d.redesOn[k]; render(); var i = el.querySelector('[data-handle="' + k + '"]'); if (i) i.focus(); }; });
      var uf = $('#oUF', el); if (uf) uf.onchange = function () { d.uf = uf.value; d.cidade = ''; d.cidade_ibge = ''; render(); carregarCidades(); };
      var ci = $('#oCid', el);
      if (ci) {
        ci.oninput = function () { d.cidade = ci.value.trim(); d.cidade_ibge = ''; var s = $('#oCidS', el); if (s && !listaFalhou) s.textContent = ''; filtrar(); };
        $('#oCidL', el).onclick = function (e) { var b = e.target.closest('[data-ibge]'); if (!b) return; d.cidade = b.dataset.nome; d.cidade_ibge = b.dataset.ibge; ci.value = d.cidade; $('#oCidL', el).innerHTML = ''; $('#oCidS', el).textContent = '✓ Cidade confirmada'; };
        if (d.uf && !cidades.length) carregarCidades();
      }
    }
    async function salvar() {
      var mudouCidade = !st.perfil || st.perfil.cidade !== d.cidade || st.perfil.uf !== d.uf;
      var linha = { id: st.user.id, nome: (d.nome || '').slice(0, 80) || null, ramo: d.ramo || null, ramo_detalhe: d.ramo_detalhe.slice(0, 80) || null, uf: d.uf || null, cidade: (d.cidade || '').slice(0, 80) || null, cidade_ibge: /^\d{7}$/.test(d.cidade_ibge) ? d.cidade_ibge : null, objetivo: d.objetivo || null, onboarding_ok: true };
      if (mudouCidade) { linha.lat = null; linha.lon = null; }
      var r = st.perfil ? await sb.from('evolui_perfis').update(linha).eq('id', st.user.id) : await sb.from('evolui_perfis').insert(linha);
      if (r.error) throw r.error;
      var del = await sb.from('evolui_redes').delete().eq('user_id', st.user.id); if (del.error) throw del.error;
      var novas = REDES.filter(function (x) { return d.redesOn[x[0]] && d.redes[x[0]]; }).map(function (x) { return { user_id: st.user.id, rede: x[0], usuario: d.redes[x[0]] }; });
      if (novas.length) { var ins = await sb.from('evolui_redes').insert(novas); if (ins.error) throw ins.error; }
      if (mudouCidade) st.local = null;
      st.paraVoce = null;
      await carregarPerfil();
    }
    render();
    if (d.uf) carregarCidades();
  }

  // ---------------------------------------------------------------- buscar
  var CURTO = { doces: 'confeitaria', alimentacao: 'restaurantes', beleza: 'salão de beleza', moda: 'moda', saude: 'clínicas', fitness: 'academias', pet: 'pet shops', casa: 'decoração', educacao: 'cursos', servicos: 'serviços profissionais' };
  function exemplosZero() {
    var p = st.perfil || {}, c = CURTO[p.ramo], cid = p.cidade ? ' em ' + p.cidade : '';
    if (!c) return ['O que está em alta no Brasil hoje?', 'Quero ideias de vídeos curtos', 'O que meus concorrentes estão fazendo?', 'Tendências para o meu negócio'];
    return ['Tendências para ' + c + cid, 'O que está em alta para ' + c + '?', 'Quero ideias para ' + c, 'O que meus concorrentes estão fazendo?'].map(function (x) { return x.slice(0, 80); });
  }
  // Card Intelligence System: se cards.js não carregar, o app continua com marcação simples
  var CI = function () { return window.EvoluiCards; };
  function cartoes(lista, extra) { var C = CI(); if (!C) return '<div class="chips">' + lista.map(function (d) { return d.action ? '<button class="chip"' + Object.keys(d.attrs || {}).map(function (k) { return ' data-' + k + '="' + esc(d.attrs[k]) + '"'; }).join('') + '>' + esc(d.title) + '</button>' : ''; }).join('') + '</div>'; return C.grade(lista, extra); }
  function animar(el) { var C = CI(); if (C && el) C.ativar(el); }
  function sk(n) { var h = ''; for (var i = 0; i < (n || 2); i++) h += '<div class="sk" aria-hidden="true"></div>'; return '<div class="sk-box" role="status" aria-label="Carregando">' + h + '</div>'; }
  function falhou(msg, fn) { return '<p class="muted">' + esc(msg) + ' <button class="link-btn" data-tenta="' + fn + '">Tentar de novo</button></p>'; }
  function telaBuscar(extra) {
    var p = plano(), pf = st.perfil || {}, temRes = !!(extra && (extra.resultado || extra.termo || extra.cta));
    // Radar de Mercado: 0 pesquisa · 1 o que está acontecendo · 2 o que mudou · 3 o que significa · 4 oportunidade · 5 como explorar · 6 o que aprendemos
    $('#conteudo').innerHTML =
      '<div class="busca-grade radar"><div class="busca-principal">' +
      '<div class="home-topo"><p class="kicker"><span class="estrela"></span>Olá, ' + esc(nomeCurto()) + '</p><h1 class="tit">O que você quer <em>descobrir</em> hoje?</h1>' +
      '<p class="sub">Escreva um produto, um assunto ou a sua própria ideia. A Evolui mostra o que entendeu e por que chegou lá.</p></div>' +
      '<form class="barra-busca" id="fBusca" role="search">' + ICON.lupa + '<input id="q" maxlength="80" placeholder="Ex.: tendências para ' + esc(CURTO[pf.ramo] || 'o meu negócio') + '" autocomplete="off" aria-label="Pesquisar um assunto ou uma ideia"><button class="btn prim sm" type="submit">Buscar</button></form>' +
      '<div class="zero" id="zero"><span class="kicker">Comece por um exemplo</span><div class="chips" id="zeroC">' + exemplosZero().map(function (x) { return '<button class="chip" data-zero="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div>' +
      (pf.cidade ? '' : '<button class="link-btn" id="addCidade">Adicionar minha cidade para ver o que acontece perto de mim</button>') + '</div>' +
      '<div id="resultado"></div>' +
      '<div class="radar-blocos" id="radar">' +
      '<section class="rb" id="achados" aria-labelledby="achTit"><div class="entre"><h2 class="sec-tit" id="achTit">O que está acontecendo?</h2><span class="kicker">Seu ramo</span></div><div class="para-voce" id="paraVoce">' + sk(2) + '</div></section>' +
      '<section class="rb" id="rbMudou" aria-labelledby="mudTit"><div class="entre"><h2 class="sec-tit" id="mudTit">O que mudou?</h2><span class="kicker">Google Trends · hoje</span></div><div class="emalta" id="emalta">' + sk(3) + '</div></section>' +
      '<section class="rb" id="rbSignifica" hidden aria-labelledby="sigTit"><div class="entre"><h2 class="sec-tit" id="sigTit">O que isso significa?</h2><span class="kicker">Interpretação</span></div><div id="signif"></div></section>' +
      '<section class="rb objetivos" id="objetivos" aria-labelledby="objTit"><div id="retomar"></div><div class="entre"><h2 class="sec-tit" id="objTit">Onde existe oportunidade?</h2></div><div class="obj-grade" id="objGrade">' + sk(1) + '</div></section>' +
      '<section class="rb" id="rbExplorar" aria-labelledby="expTit"><div class="entre"><h2 class="sec-tit" id="expTit">Como posso explorar?</h2></div><section class="card cc-home" id="meusConteudos" hidden></section><div id="cardLab"></div></section>' +
      '<section class="rb" id="rbAprendemos" hidden aria-labelledby="apTit"><div class="entre"><h2 class="sec-tit" id="apTit">O que já aprendemos?</h2><span class="kicker">Confirmado por você</span></div><div id="aprendemos"></div></section>' +
      '</div>' +
      '<div class="entre uso-linha"><div class="uso" id="uso"><span>— de ' + LIMITE[p] + ' pesquisas este mês</span></div>' + (p === 'free' ? '<button class="btn ghost sm" id="verPlanos">Quero mais pesquisas</button>' : '') + '</div>' +
      '</div></div>';
    $('#fBusca').onsubmit = function (e) { e.preventDefault(); buscar($('#q').value); };
    $('#zeroC').onclick = function (e) { var b = e.target.closest('[data-zero]'); if (!b) return; registrar('home_zero_exemplo', {}); $('#q').value = b.dataset.zero; buscar(b.dataset.zero); };
    var ac = $('#addCidade'); if (ac) ac.onclick = function () { abrirOnboarding(true); };
    var vp = $('#verPlanos'); if (vp) vp.onclick = function () { abrirPlanos('uso'); };
    var cl0 = $('#cardLab'); cl0.innerHTML = cartoes([{ hero: true, type: 'ideia', title: 'Teste sua legenda, bio ou ideia antes de postar', description: 'Compare duas versões, com nota de boas práticas e resultado real.', tags: ['Legenda', 'Bio', 'Roteiro'], action: 'Criar no Lab', attrs: { irlab: '1' } }]); animar(cl0);
    cl0.onclick = function (e) { if (e.target.closest('[data-irlab]')) ir('laboratorio'); };
    $('#radar').onclick = function (e) { var t = e.target.closest('[data-tenta]'); if (!t) return; var f = t.dataset.tenta; if (f === 'pv') { st.paraVoce = null; carregarParaVoce(); } else if (f === 'ea') { st.emAlta = null; carregarEmAlta(); } else carregarObjetivos(); };
    usoMes().then(function (n) { mostrarUso(n, LIMITE[p]); }).catch(function () {});
    carregarMeusConteudos(); carregarParaVoce(); carregarEmAlta(); carregarObjetivos(); carregarAprendemos(); if (!temRes) carregarRetomar();
    if (extra && extra.cta) { renderCta(extra.cta); }
    else if (extra && extra.resultado) { $('#q').value = extra.resultado.termo; renderResultado(extra.resultado, extra.salvoEm); }
    else if (extra && extra.termo) { $('#q').value = extra.termo; buscar(extra.termo); }
  }
  async function carregarAprendemos() {
    var sec = $('#rbAprendemos'); if (!sec) return;
    var pf = st.perfil || {}; if (pf.personalizar === false) return;
    try {
      var rs = await Promise.all([memoriaHomeHtml().catch(function () { return ''; }), sb.from('evolui_buscas').select('termo').order('criado_em', { ascending: false }).limit(12)]);
      var mem = rs[0], r = rs[1];
      if (!$('#aprendemos')) return;
      var vistos = {}, termos = [];
      ((r && r.data) || []).forEach(function (x) { var k = norm(x.termo); if (k && !vistos[k] && termos.length < 4) { vistos[k] = 1; termos.push(x.termo); } });
      var linhas = [];
      if (mem) linhas.push(mem);
      if (termos.length) linhas.push('<p class="sub" style="margin:0">Você pesquisou recentemente (isso é histórico, não preferência):</p><div class="chips">' + termos.map(function (t) { return '<button class="chip" data-q="' + esc(t) + '">' + esc(t) + '</button>'; }).join('') + '</div>');
      if (!linhas.length) return;
      sec.hidden = false; var box = $('#aprendemos'); box.innerHTML = linhas.join(''); animar(box);
      box.onclick = async function (e) {
        var q = e.target.closest('[data-q]'); if (q) { $('#q').value = q.dataset.q; buscar(q.dataset.q); return; }
        var pe = e.target.closest('[data-pend]');
        if (pe && (e.target.closest('[data-hconf]') || e.target.closest('[data-hnao]'))) {
          var id = pe.dataset.pend, sim = !!e.target.closest('[data-hconf]');
          var ok = await prefSalvar(function (g) { if (sim) { g.removidas = semItem(g.removidas, id); if (g.confirmadas.indexOf(id) < 0) g.confirmadas.push(id); } else { g.confirmadas = semItem(g.confirmadas, id); if (g.removidas.indexOf(id) < 0) g.removidas.push(id); } }, sim ? 'pref_confirmada' : 'pref_removida', id);
          if (ok) { toast(sim ? 'Anotado. Vou usar isso só para ajustar a ordem das sugestões.' : 'Ok, não vou usar isso.'); carregarAprendemos(); }
          return;
        }
        var ap = e.target.closest('[data-apr]');
        if (ap) {
          var acao = e.target.closest('[data-apr-conf]') ? 'confirmar' : e.target.closest('[data-apr-apa]') ? 'apagar' : '';
          if (acao && await aprendizadoAcao(ap.dataset.apr, acao)) { toast(acao === 'apagar' ? 'Apagado.' : 'Confirmado.'); carregarAprendemos(); }
        }
      };
    } catch (e) { /* sem bloco */ }
  }

  // ---------------------------------------------------------------- objetivos e ações (CTAs)
  // O catálogo de objetivos vem do banco. A ação (CTA) é escolhida e personalizada no banco (evolui_cta_gerar),
  // que também grava o histórico. Aqui só mostramos e atualizamos o status.
  var CTA_STATUS = { novo: 'Nova', iniciado: 'Em andamento', concluido: 'Concluída', descartado: 'Descartada' };
  var DIF = { facil: 'Fácil', medio: 'Médio', avancado: 'Avançado' };
  var FORMATO_ROT = { reels: 'Vídeo curto', carrossel: 'Carrossel', stories: 'Stories', foto: 'Foto', live: 'Ao vivo', post: 'Post' };
  async function catalogoObjetivos() {
    if (st.objCat) return st.objCat;
    var r = await sb.from('evolui_objetivos_catalogo').select('chave,rotulo,subtitulo,ordem').order('ordem');
    if (r.error) throw r.error;
    st.objCat = r.data || []; return st.objCat;
  }
  function rotuloObjetivo(chave) { var o = (st.objCat || []).filter(function (x) { return x.chave === chave; })[0]; return o ? o.rotulo : ''; }
  async function carregarObjetivos() {
    var box = $('#objGrade'); if (!box) return;
    try {
      var cat = await catalogoObjetivos();
      if (!$('#objGrade')) return;
      if (!cat.length) { $('#objetivos').hidden = true; return; }
      var pf = st.perfil || {}, prin = cat.filter(function (o) { return o.chave === pf.objetivo; })[0] || cat[0];
      var bt = function (o, cl) { return '<button class="obj' + (cl || '') + '" data-objetivo="' + esc(o.chave) + '"><b>' + esc(o.rotulo) + '</b><small>' + esc(o.subtitulo || '') + '</small></button>'; };
      box.className = 'obj-uni';
      box.innerHTML = cartoes([{ hero: true, origem: 'radar', type: 'oportunidade', title: prin.rotulo, description: prin.subtitulo || 'Uma ação pensada para o seu objetivo.', tags: ['Para o seu objetivo'], action: 'Explorar', attrs: { objetivo: prin.chave } }]) + '<details class="mais"><summary>Outros objetivos</summary><div class="obj-grade">' + cat.filter(function (o) { return o !== prin; }).map(function (o) { return bt(o, ''); }).join('') + '</div></details>';
      box.onclick = function (e) { var b = e.target.closest('[data-objetivo]'); if (b) gerarCta(b.dataset.objetivo, {}, b); }; animar(box);
    } catch (e) { box.innerHTML = falhou('Não conseguimos carregar os objetivos agora. A pesquisa continua funcionando.', 'ob'); }
  }
  async function carregarRetomar() {
    var box = $('#retomar'); if (!box) return;
    try {
      await catalogoObjetivos().catch(function () {});
      var r = await sb.from('evolui_ctas').select('*').eq('status', 'iniciado').order('iniciado_em', { ascending: false }).limit(1);
      if (r.error || !r.data || !r.data.length || !$('#retomar')) return;
      var c = r.data[0];
      box.innerHTML = '<div class="retomar"><div style="min-width:0"><span class="kicker">Continue de onde parou</span><b>' + esc(c.titulo) + '</b></div><button class="btn sm cta" id="retomarBt">Abrir</button></div>';
      $('#retomarBt').onclick = function () { renderCta(c); };
    } catch (e) { /* sem retomar */ }
  }
  async function gerarCta(chave, opc, btn) {
    opc = opc || {};
    var todos = $$('[data-objetivo],[data-trocar]'); todos.forEach(function (b) { b.disabled = true; });
    var box = $('#resultado');
    if (box && !opc.trocar) box.innerHTML = '<section class="card"><p class="muted">Escolhendo a melhor ação para você…</p></section>';
    var r;
    try {
      st.objetivoFI = chave;
      var x = await E.api('cta', { objetivo: chave, tema: opc.tema || '', busca: opc.busca || '', trocar: opc.trocar || '' });
      r = { data: x && x.cta };
    } catch (e1) {
      // reserva: se o motor estiver fora do ar, o banco escolhe a ação como antes
      r = await sb.rpc('evolui_cta_gerar', { p_objetivo: chave, p_tema: opc.tema || null, p_busca: opc.busca || null, p_trocar: opc.trocar || null });
    }
    todos.forEach(function (b) { b.disabled = false; });
    if (r.error || !r.data) {
      var msg = (r.error && r.error.message) || 'Não foi possível gerar agora. Tente de novo.';
      if (box) box.innerHTML = '';
      toast(msg.length > 140 ? 'Não foi possível gerar agora. Tente de novo.' : msg); return;
    }
    registrar('objetivo_escolhido', { objetivo: chave, de: opc.busca ? 'pesquisa' : 'inicio' });
    r.data.tema_usado = opc.tema || null;
    renderCta(r.data);
    var alvo = $('#resultado'); if (alvo && alvo.scrollIntoView) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function porqueHtml(e) {
    var w = e && e.porque && e.porque.length ? e.porque.map(function (x) { return x.text; }).filter(Boolean).join(' ') : '';
    return w ? '<p class="muted porque-eie">Por que apareceu: ' + esc(w) + '</p>' : '';
  }
  function evento(tipo, cand, extra) {
    // sinal de aprendizado do motor (ver, copiar, salvar...). Nunca bloqueia a tela.
    try { sb.rpc('evolui_eie_evento', { p_tipo: tipo, p_candidato_tipo: cand.tipo, p_candidato_id: cand.id || '', p_consulta: cand.consulta || null, p_extra: extra || {} }).then(function () {}, function () {}); } catch (e) { /* sem rede */ }
  }
  function renderCta(c) {
    var box = $('#resultado'); if (!box) return;
    st.cta = c;
    var rot = c.objetivo_rotulo || rotuloObjetivo(c.objetivo_chave);
    var passos = c.instrucoes || [];
    var fechado = c.status === 'concluido' || c.status === 'descartado';
    var meta = [FORMATO_ROT[c.formato] || c.formato, c.rede, DIF[c.dificuldade], c.tempo_min ? c.tempo_min + ' min' : ''].filter(Boolean);
    var html = '<p class="nivel-rot">' + esc(rot ? rot : 'Sua ação') + ' → O que fazer agora</p>' +
      '<section class="card destaque cta-card" id="ctaCard"><div class="entre"><span class="kicker">' + esc(meta.join(' · ')) + '</span><span class="pill cta-' + esc(c.status) + '">' + esc(CTA_STATUS[c.status] || '') + '</span></div>' +
      '<h2 class="tit cta-tit">' + esc(c.titulo) + '</h2>' +
      (c.descricao ? '<p class="sub">' + esc(c.descricao) + '</p>' : '') +
      (c.personalizado ? '<span class="kicker">Ajustada ao seu negócio</span>' : '') +
      porqueHtml(c.eie) +
      (passos.length ? '<h3>Como fazer</h3><ol class="passos">' + passos.map(function (x, i) { return '<li><label><input type="checkbox" data-passo="' + i + '"' + (c.status === 'iniciado' ? '' : ' disabled') + '><span>' + esc(x) + '</span></label></li>'; }).join('') + '</ol>' : '') +
      (c.gancho ? '<div class="cta-bloco"><span class="kicker">Gancho (primeira frase)</span><div class="caixa-legenda" id="ctaGancho">' + esc(c.gancho) + '</div><button class="btn sm" data-cp="gancho">Copiar gancho</button></div>' : '') +
      (c.chamada ? '<div class="cta-bloco"><span class="kicker">Chamada para ação (final)</span><div class="caixa-legenda" id="ctaChamada">' + esc(c.chamada) + '</div><button class="btn sm" data-cp="chamada">Copiar chamada</button></div>' : '') +
      (c.publico ? '<p class="muted" style="margin:0">Para quem: ' + esc(c.publico) + '</p>' : '') +
      '<div class="linha cta-acoes">' +
        (c.status === 'novo' ? '<button class="btn cta" data-st="iniciado">Começar a criar</button>' : '') +
        (c.status === 'iniciado' ? '<button class="btn cta" data-st="concluido">Concluí</button><button class="btn" id="ctaLab">Testar a legenda no laboratório</button>' : '') +
        (!fechado ? usarBtn({ titulo: c.titulo, descricao: c.descricao || '', formato: c.formato || null, termo: c.busca_termo || '', origem: 'cta', cta_id: c.id }, 'Planejar este conteúdo') : '') +
        (!fechado ? '<button class="btn" data-trocar="1">Outra sugestão</button><button class="btn ghost" data-st="descartado" data-motivo="nao_para_mim">Não é para mim</button>' : '<button class="btn cta" data-trocar="1">Gerar outra ação</button>') +
      '</div></section>';
    box.innerHTML = html;
    $$('[data-cp]', box).forEach(function (b) { b.onclick = function () { copiar(b.dataset.cp === 'gancho' ? c.gancho : c.chamada, $(b.dataset.cp === 'gancho' ? '#ctaGancho' : '#ctaChamada'), c.formato); }; });
    $$('[data-st]', box).forEach(function (b) { b.onclick = function () { statusCta(c, b.dataset.st, b); }; });
    $$('[data-trocar]', box).forEach(function (b) { b.onclick = function () { gerarCta(c.objetivo_chave, { tema: c.tema_usado, busca: c.busca_termo, trocar: c.status === 'novo' ? c.id : null }, b); }; });
    var lab = $('#ctaLab'); if (lab) lab.onclick = function () { st.labEditando = { tipo: 'legenda', titulo: c.titulo.slice(0, 80), versao_a: [c.gancho, c.chamada].filter(Boolean).join('\n\n'), versao_b: '' }; ir('laboratorio', { novo: true }); };
  }
  async function statusCta(c, novo, btn) {
    if (btn) btn.disabled = true;
    var naoParaMim = novo === 'descartado' && btn && btn.dataset.motivo === 'nao_para_mim';
    var r = await sb.rpc('evolui_cta_status_eie', { p_id: c.id, p_status: novo, p_motivo: naoParaMim ? 'nao_para_mim' : null });
    if (r.error && /evolui_cta_status_eie/.test(r.error.message || '')) r = await sb.rpc('evolui_cta_status', { p_id: c.id, p_status: novo });
    if (r.error || !r.data) { if (btn) btn.disabled = false; toast((r.error && r.error.message && r.error.message.length < 120) ? r.error.message : 'Não foi possível atualizar agora.'); return; }
    var nova = Object.assign({}, c, r.data, { objetivo_rotulo: c.objetivo_rotulo, tema_usado: c.tema_usado });
    registrar('cta_' + novo, { objetivo: c.objetivo_chave });
    if (novo === 'iniciado') toast('Boa! Siga os passos e marque o que for fazendo.');
    else if (novo === 'concluido') toast('Ação concluída. Parabéns por postar!');
    else toast('Tudo bem. Vamos tentar outra.');
    if ($('#ctaCard')) renderCta(nova);
    else if ($('#lista')) listaAcoes();
  }
  function objetivosDaPesquisa(r) {
    var o = r.objetivos || [];
    if (!o.length) return '';
    return '<section class="card" id="porObj"><h3>Transformar em ação</h3><p class="sub">Quer saber exatamente o que fazer agora? Escolha o que você quer:</p><div class="chips">' +
      o.map(function (x) { return '<button class="chip" data-pobj="' + esc(x.chave) + '" title="' + esc(x.subtitulo || '') + '">' + esc(x.rotulo) + '</button>'; }).join('') + '</div></section>';
  }
  function mostrarUso(n, lim) {
    var u = $('#uso'); if (!u) return;
    u.innerHTML = '<span>' + n + ' de ' + lim + ' pesquisas este mês</span><span class="barra"><i style="width:' + Math.min(100, Math.round(n / lim * 100)) + '%"></i></span>';
  }
  function cliqueBusca(box) {
    box.onclick = function (e) { var b = e.target.closest('[data-q]'); if (b) { $('#q').value = b.dataset.q; buscar(b.dataset.q); } };
  }
  async function carregarParaVoce() {
    var box = $('#paraVoce'); if (!box) return;
    try {
      if (!st.paraVoce) st.paraVoce = await E.api('sugestoes');
      var it = st.paraVoce.itens || [];
      if (!$('#paraVoce')) return;
      box.className = 'para-voce';
      box.innerHTML = it.length ? cartoes(it.slice(0, 3).map(function (i, k) { return { hero: k === 0, origem: 'radar', type: 'tendencia', title: i.termo, description: i.motivo, tags: ['No seu ramo'], action: 'Ver análise', attrs: { q: i.termo } }; })) : '<p class="muted">Ainda não temos sugestões do seu ramo. Escolha um exemplo acima ou faça sua primeira pesquisa.</p>';
      cliqueBusca(box); animar(box);
      var sg = $('#rbSignifica');
      if (sg && it.length && it[0].motivo) { sg.hidden = false; $('#signif').innerHTML = cartoes([{ hero: true, origem: 'busca', area: areaDaBusca({ termo: it[0].termo }), type: 'insight', title: 'O que isso significa para ' + it[0].termo + '?', description: it[0].motivo, tags: ['Interpretação'], source: 'Regras da Evolui', action: 'Entender', attrs: { q: it[0].termo } }]); cliqueBusca($('#signif')); animar($('#signif')); }
    } catch (e) { box.innerHTML = falhou('Não conseguimos carregar agora. A pesquisa continua funcionando.', 'pv'); }
  }
  async function carregarEmAlta() {
    var box = $('#emalta'); if (!box) return;
    try {
      if (!st.emAlta) st.emAlta = await E.api('emalta');
      if (!$('#emalta')) return;
      var it = (st.emAlta.itens || []).slice(0, 3);
      if (!it.length) { box.innerHTML = '<p class="muted">' + esc(st.emAlta.aviso || 'Nada para mostrar agora.') + '</p>'; return; }
      box.className = '';
      box.innerHTML = cartoes(it.map(function (i, k) { return { hero: k === 0, type: 'movimento', title: i.termo, description: i.noticia || '', tags: i.trafego ? [i.trafego + ' buscas'] : [], source: 'Google Trends', period: 'hoje', action: 'Ver análise', attrs: { q: i.termo } }; })) +
        '<p class="muted" style="font-size:13px;margin:6px 0 0">Assuntos gerais do dia no Brasil (fato observado hoje). Toque para ver se combinam com o seu negócio.</p>';
      cliqueBusca(box); animar(box);
    } catch (e) { box.innerHTML = falhou('Não conseguimos carregar agora.', 'ea'); }
  }

  // Notícias: o navegador da própria pessoa consulta o GDELT (gratuito, sem chave). Assim o limite de uso
  // do GDELT é por pessoa, e não um só para todo o servidor. O servidor confere tudo antes de usar.
  // A consulta já vem pronta do servidor (ação "entender"): só o assunto, entre aspas quando é expressão.
  var gdeltFalhas = 0; // falhas seguidas no navegador: depois de 2, a pesquisa não espera mais por ele (o servidor tenta sozinho)
  async function noticiasGdelt(consulta) {
    if (gdeltFalhas >= 2) return null;
    var q = consulta + ' sourcelang:portuguese';
    var ctl = new AbortController(), t = setTimeout(function () { ctl.abort(); }, 4000);
    try {
      var r = await fetch('https://api.gdeltproject.org/api/v2/doc/doc?query=' + encodeURIComponent(q) + '&mode=artlist&maxrecords=250&timespan=14d&sort=datedesc&format=json', { signal: ctl.signal });
      if (!r.ok) { gdeltFalhas++; return null; }
      var j = JSON.parse(await r.text());
      var arts = (j && j.articles) || [];
      gdeltFalhas = 0;
      return {
        datas: arts.map(function (a) { return String(a.seendate || ''); }).filter(function (x) { return /^\d{8}(T\d{6}Z)?$/.test(x); }).slice(0, 250),
        artigos: arts.slice(0, 10).map(function (a) { return { titulo: String(a.title || '').slice(0, 300), url: String(a.url || ''), site: String(a.domain || '').slice(0, 100), data: String(a.seendate || '').slice(0, 8) }; }).filter(function (a) { return urlSegura(a.url) && a.titulo; })
      };
    } catch (e) { gdeltFalhas++; return null; } finally { clearTimeout(t); }
  }

  var buscando = false;
  function promoProPesquisa() {
    var p = plano();
    var tips = [
      { t: 'Pesquise com intenção', d: 'Inclua o que você quer descobrir: ideias, tendências, concorrentes, público ou oportunidades.' },
      { t: 'Dê contexto à busca', d: 'Quanto mais específico for o assunto, melhor a Evolui consegue cruzar sinais e encontrar resultados úteis.' },
      { t: 'Use o Laboratório', d: 'Salve referências, teste conteúdos e use os resultados para alimentar suas próximas decisões.' },
      { t: 'Experimente variações', d: 'Se uma busca vier vazia, tente um termo mais amplo ou descreva o problema de outro jeito.' },
      { t: 'Olhe os sinais juntos', d: 'Uma boa decisão não depende de uma única fonte. Compare tendência, notícias, repertório e contexto.' }
    ];
    var html = '<div class="dicas-pesquisa"><div class="dica-pesquisa-slides">' + tips.map(function (x, i) { return '<article class="dica-pesquisa-slide' + (i === 0 ? ' ativo' : '') + '" data-dica-slide="' + i + '"><span class="dica-pesquisa-ico">✦</span><div><span class="dica-pesquisa-kicker">Dica da Evolui</span><h4>' + esc(x.t) + '</h4><p>' + esc(x.d) + '</p></div></article>'; }).join('') + '</div><div class="dica-pesquisa-base"><span class="dica-pesquisa-dots">' + tips.map(function (_, i) { return '<i class="' + (i === 0 ? 'ativo' : '') + '" data-dica-dot="' + i + '"></i>'; }).join('') + '</span></div></div>';
    if (p === 'pro' || p === 'master') {
      var business = [
        { t: 'Pesquisa profunda', d: 'Descubra sinais que uma busca comum não encontra.' },
        { t: 'Inteligência de negócio', d: 'Cruze mercado, comportamento e tendências para decidir melhor.' },
        { t: 'Evolui Business', d: 'Uma camada avançada de inteligência para negócios.' }
      ];
      html += '<div class="promo-pro" aria-label="Evolui Business durante a pesquisa"><div class="promo-pro-slides">' + business.map(function (x, i) { return '<article class="promo-pro-slide' + (i === 0 ? ' ativo' : '') + '" data-business-slide="' + i + '"><span class="promo-pro-ico">↗</span><div><span class="promo-pro-kicker">Evolui Business</span><h4>' + esc(x.t) + '</h4><p>' + esc(x.d) + '</p></div></article>'; }).join('') + '</div><div class="promo-pro-base"><span class="promo-pro-dots">' + business.map(function (_, i) { return '<i class="' + (i === 0 ? 'ativo' : '') + '" data-business-dot="' + i + '"></i>'; }).join('') + '</span><button class="btn sm cta" data-business-cta="1">Conhecer o Business</button></div></div>';
    }
    return html;
  }
  async function buscar(termo, opc) {
    termo = String(termo || '').trim();
    if (termo.length < 2) return toast('Digite pelo menos 2 letras.');
    if (buscando) return; buscando = true;
    var box = $('#resultado');
    var passos = ['Entendendo o assunto', 'Cruzando sinais', 'Comparando o que mudou', 'Montando a leitura para você'];
    var inicioCarga = Date.now();
    box.innerHTML = '<section class="card pesquisa-loading" aria-live="polite"><div class="pesquisa-loading__top"><span class="kicker">PESQUISA EM ANDAMENTO</span><span class="pesquisa-loading__time">Leitura rápida, sem precisar acompanhar as etapas</span></div><h3>Pesquisando "' + esc(termo) + '"…</h3><p class="sub pesquisa-loading__lead">A Evolui está cruzando sinais e contexto para separar o que está apenas grande do que realmente está ganhando força.</p><div class="passos-carga">' + passos.map(function (p, i) { return '<div data-i="' + i + '"><span class="ponto' + (i === 0 ? ' vai' : '') + '"></span>' + p + '</div>'; }).join('') + '</div>' + promoProPesquisa() + '</section>';
    box.scrollIntoView({ behavior: 'smooth', block: 'start' });
    var i = 0, tm = setInterval(function () {
      var a = box.querySelector('[data-i="' + i + '"]'); if (a) { a.classList.add('feito'); a.querySelector('.ponto').className = 'ponto ok'; }
      i++; var b = box.querySelector('[data-i="' + i + '"] .ponto'); if (b) b.className = 'ponto vai'; else clearInterval(tm);
    }, 1650);
    var dicaTm = null, dicaIdx = 0, businessTm = null, businessIdx = 0;
    dicaTm = setInterval(function () {
      dicaIdx = (dicaIdx + 1) % 5;
      $$('.dica-pesquisa-slide', box).forEach(function (x, k) { x.classList.toggle('ativo', k === dicaIdx); });
      $$('.dica-pesquisa-dots i', box).forEach(function (x, k) { x.classList.toggle('ativo', k === dicaIdx); });
    }, 4800);
    if (plano() === 'pro' || plano() === 'master') {
      businessTm = setInterval(function () {
        businessIdx = (businessIdx + 1) % 3;
        $$('.promo-pro-slide', box).forEach(function (x, k) { x.classList.toggle('ativo', k === businessIdx); });
        $$('.promo-pro-dots i', box).forEach(function (x, k) { x.classList.toggle('ativo', k === businessIdx); });
      }, 5200);
      var bcb = $('[data-business-cta]', box); if (bcb) bcb.onclick = function () { toast('Evolui Business: em breve.'); registrar('business_interesse', { origem: 'pesquisa' }); };
    }
    var limparCarga = function () { clearInterval(tm); clearInterval(dicaTm); if (businessTm) clearInterval(businessTm); };
    try {
      var ent = null;
      try { ent = await E.api('entender', { termo: termo }); } catch (e) { if (e.status === 401) throw e; }
      var qn = ent ? ent.noticias : { principal: termo, ampla: null };
      var gd = qn ? await noticiasGdelt(qn.principal) : null;
      // pouca notícia com a expressão exata? amplia (o GDELT pede 5 s entre consultas)
      if (qn && qn.ampla && gd && gd.datas.length < 5) {
        var gd2 = await noticiasGdelt(qn.ampla);
        if (gd2 && (!gd || gd2.datas.length > gd.datas.length)) gd = gd2;
      }
      var ctx = (opc && opc.semCtx) ? null : contextoParaBusca(termo);
      // contexto_busca: dimensões da busca anterior, anexadas como contexto declarado (campo extra; o termo digitado segue intacto)
      var r = await E.api('buscar', { termo: termo, v: 2, gdelt: gd || undefined, contexto_busca: ctx || undefined });
      var tempoMinimo = 5200;
      var restante = Math.max(0, tempoMinimo - (Date.now() - inicioCarga));
      if (restante) await new Promise(function(resolve){ setTimeout(resolve, restante); });
      limparCarga(); r._ctx = ctx; renderResultado(r); guardarCtx(r, ctx);
      if (r.uso) mostrarUso(r.uso.mes, r.uso.limite);
      st.paraVoce = null;
    } catch (e) {
      limparCarga();
      if (e.status === 401) { telaEntrar('Sua sessão expirou. Entre de novo.'); return; }
      if (e.dados && e.dados.limite) registrar('limite', { termo: termo });
      box.innerHTML = '<div class="vazio"><h3>' + esc(e.message) + '</h3>' + (e.dados && e.dados.limite ? '<button class="btn cta" id="limPlanos">Ver planos</button>' : '<button class="btn" id="tenta">Tentar de novo</button>') + '</div>';
      var t = $('#tenta'); if (t) t.onclick = function () { buscar(termo); };
      var lp = $('#limPlanos'); if (lp) lp.onclick = function () { abrirPlanos('limite'); };
    } finally { buscando = false; }
  }

  function grafico(series) {
    var S = (series || []).map(function (s) { return { fonte: s.fonte, dias: s.dias, v: s.valores }; }).filter(function (s) { return s.v && s.v.length > 1 && s.v.some(function (x) { return x > 0; }); });
    if (!S.length) return '';
    var w = 600, h = 200, pl = 8, pr = 8, pt = 12, pb = 26;
    var linhas = S.map(function (s) {
      var mx = Math.max.apply(null, s.v) || 1;
      var pts = s.v.map(function (y, i) { return [pl + i * (w - pl - pr) / (s.v.length - 1), pt + (1 - y / mx) * (h - pt - pb)]; });
      var d = pts.map(function (p, i) { return (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join(' ');
      var cor = CORES[s.fonte] || '#8FA3C7', ult = pts[pts.length - 1];
      return '<path d="' + d + ' L' + ult[0].toFixed(1) + ' ' + (h - pb) + ' L' + pl + ' ' + (h - pb) + ' Z" fill="' + cor + '" opacity=".12"/><path d="' + d + '" fill="none" stroke="' + cor + '" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="' + ult[0].toFixed(1) + '" cy="' + ult[1].toFixed(1) + '" r="4.5" fill="' + cor + '"/>';
    }).join('');
    var dias = S.reduce(function (a, s) { return s.dias.length > a.length ? s.dias : a; }, []), f = function (x) { return x.slice(8, 10) + '/' + x.slice(5, 7); };
    var grade = [0.25, 0.5, 0.75].map(function (g) { var y = pt + g * (h - pt - pb); return '<line x1="0" x2="' + w + '" y1="' + y + '" y2="' + y + '" stroke="currentColor" stroke-opacity=".12"/>'; }).join('');
    return '<svg class="grafico" viewBox="0 0 ' + w + ' ' + (h - pb + 4) + '" role="img" aria-label="Interesse nos últimos ' + dias.length + ' dias">' + grade + linhas + '</svg>' +
      '<div class="eixo"><span>' + f(dias[0]) + '</span><span>' + f(dias[dias.length - 1]) + '</span></div>' +
      '<div class="legenda-graf">' + S.map(function (s) { return '<span><i style="background:' + (CORES[s.fonte] || '#8FA3C7') + '"></i>' + esc(s.fonte) + ' · ' + s.v.length + ' dias</span>'; }).join('') + '<span>Cada linha na própria escala (0 a 100% do máximo dela)</span></div>';
  }
  function borrado(linhas) {
    var w = [92, 78, 85, 64, 88, 70];
    return '<div class="borrado" aria-hidden="true"><b></b>' + w.slice(0, linhas || 5).map(function (x) { return '<i style="width:' + x + '%"></i>'; }).join('') + '</div>';
  }
  function travado(titulo, planoAlvo, extra) {
    return '<div class="cadeado"><span class="ico">' + ICON.cadeado + '</span><p>' + esc(titulo) + '</p><button class="btn cta sm" data-liberar="' + esc(planoAlvo) + '">Liberar no ' + NOME_PLANO[planoAlvo] + '</button>' + (extra || '') + '</div>';
  }
  // "Entendi": mostra como a busca foi lida (intenção, segmento, cidade, canal, tema) e deixa corrigir sem formulário
  var FORMATO_NOME = { reels: 'Reels', carrossel: 'Carrossel', stories: 'Stories', foto: 'Foto', live: 'Live', shorts: 'Shorts' };
  var PLAT_NOME = { instagram: 'Instagram', tiktok: 'TikTok', youtube: 'YouTube', facebook: 'Facebook', linkedin: 'LinkedIn', whatsapp: 'WhatsApp' };
  var SEG_ROT = { fitness: 'Fitness', doces: 'Doces e confeitaria', beleza: 'Beleza', saude: 'Saúde', alimentacao: 'Alimentação', pet: 'Pet', moda: 'Moda', casa: 'Casa e decoração', educacao: 'Educação' };
  var DIM_ROT = { area: 'Área', subramo: 'Subramo', tema: 'Tema', produto: 'Produto', servico: 'Serviço', negocio: 'Negócio', local: 'Local', plataforma: 'Plataforma', formato: 'Formato' };
  var DIM_ORDEM = ['area', 'subramo', 'tema', 'produto', 'servico', 'negocio', 'local', 'plataforma', 'formato'];
  // regex tolerante a acento e plural: escreva em ASCII; vogais e "c" viram classes; "@" = resto da palavra.
  // Sem lookbehind (ES5/Safari antigo): o grupo 1 é o separador, o grupo 2 é a palavra achada.
  var CLS = { a: '[aáàâãä]', e: '[eéèê]', i: '[iíì]', o: '[oóòôõ]', u: '[uúù]', c: '[cç]' };
  function rx(p) {
    return new RegExp('(^|[^A-Za-zÀ-ÿ])(' + p.replace(/[aeiouc]/g, function (c) { return CLS[c]; }).replace(/@/g, '[A-Za-zÀ-ÿ]*') + ')(?![A-Za-zÀ-ÿ])', 'i');
  }
  var SEG_CHAVES = [
    ['fitness', rx('academias?|treinos?|fitness|musculacao|crossfit|pilates|personal trainer')],
    ['doces', rx('doces?|bolos?|confeitaria|brigadeiros?|docerias?|chocolates?|cupcakes?')],
    ['beleza', rx('sal(?:ao|oes)|barbearias?|barbeiros?|cabelos?|cabeleireir@|estetica|unhas?|manicure|beleza|cosmeticos?|perfumarias?|perfumes?|maquiagem|skin ?care|cuidados com a pele|protetor(?:es)? solar|sobrancelhas?|depilacao|pele')],
    ['saude', rx('clinicas?|dentistas?|odonto@|medic@|saude|psicolog@|nutri@|fisioterapia|farmacias?')],
    ['alimentacao', rx('restaurantes?|pizzarias?|lanchonetes?|hamburguer@|hamburgueria@|comidas?|bares?|cafeterias?|padarias?|gastronomia|marmitas?|sorveterias?')],
    ['pet', rx('pet ?shops?|pets?|cachorros?|gatos?|veterin@')],
    ['moda', rx('moda|roupas?|boutiques?|acessorios?|brechos?|calcados?|joias?|semijoias?')],
    ['casa', rx('decoracao|moveis|construcao|arquitetura|imoveis|reformas?')],
    ['educacao', rx('cursos?|escolas?|aulas?|educacao|professor@')]
  ];
  var SUB_CHAVES = [['beleza', 'Skincare', rx('skin ?care|cuidados com a pele|protetor(?:es)? solar')], ['beleza', 'Cabelo', rx('cabelos?|cabeleireir@')], ['beleza', 'Unhas', rx('unhas?|manicure')],
    ['beleza', 'Barbearia', rx('barbearias?|barbeiros?')], ['beleza', 'Maquiagem', rx('maquiagem')]];
  var PLAT_RX = rx('instagram|insta|tik ?tok|youtube|facebook|linkedin|whatsapp');
  var FORM_RX = rx('reels?|stories|story|carrosse(?:l|is)|shorts|lives?|fotos?');
  var NAO_LOCAL = rx('ideias?|tendencias?|dicas?|natal|pascoa|black friday|halloween|conteudos?|posts?|videos?');
  function achaTrecho(t, s) { // trecho como aparece no texto digitado ('' se não aparece)
    var a = norm(t), i = a.indexOf(norm(s)); return (s && i >= 0 && a.length === t.length) ? t.substr(i, String(s).length) : '';
  }
  function achaSeg(t) { var res = null; SEG_CHAVES.some(function (k) { var m = t.match(k[1]); if (m) { res = { chave: k[0], trecho: m[2] }; return true; } return false; }); return res; }
  function platKey(s) { var m = String(s || '').match(PLAT_RX); if (!m) return ''; var k = norm(m[2]).replace(/\s/g, ''); return k === 'insta' ? 'instagram' : k; }
  function formKey(s) {
    var m = String(s || '').match(FORM_RX); if (!m) return ''; var k = norm(m[2]);
    return /^reel/.test(k) ? 'reels' : /^stor/.test(k) ? 'stories' : /^carr/.test(k) ? 'carrossel' : /^short/.test(k) ? 'shorts' : /^live/.test(k) ? 'live' : 'foto';
  }
  function entidadesDaBusca(r) {
    var it = r.interpretacao || {}, t = String(r.termo || ''), tn = norm(t), pf = st.perfil || {}, pers = !(pf.personalizar === false);
    var ints = (it.intencoes || []).filter(Boolean), map = {}, cad = it.cadeia || null;
    function add(dim, rot, trecho, origem, chave) {
      if (!rot) return; rot = String(rot);
      var l = map[dim] = map[dim] || []; if (l.some(function (x) { return norm(x.rot) === norm(rot); })) return;
      var tr = achaTrecho(t, trecho || rot);
      if (origem !== 'inferida' && origem !== 'perfil') origem = tr ? 'dita' : (origem === 'dita' ? 'dita' : 'inferida');
      l.push({ tipo: dim, rot: rot, trecho: tr, origem: origem, chave: chave || '' });
    }
    function tem(dim) { return !!(map[dim] && map[dim].length); }
    // 1) campos novos da API (cadeia + entidades_taxonomia)
    (it.entidades_taxonomia || []).forEach(function (e) {
      if (!e || !e.rotulo || !e.tipo) return;
      add(e.tipo, e.rotulo, e.trecho, e.origem === 'inferida' ? 'inferida' : e.origem === 'perfil' ? 'perfil' : (e.origem === 'dita' ? 'dita' : ''), e.chave);
    });
    if (cad) ['area', 'subramo', 'tema'].forEach(function (d) { if (cad[d] && cad[d].rotulo) add(d, cad[d].rotulo, '', '', cad[d].chave); });
    // 2) leitura local de reserva
    if (!tem('area')) { var sg = achaSeg(t); if (sg) add('area', SEG_ROT[sg.chave], sg.trecho, norm(sg.trecho) === norm(SEG_ROT[sg.chave]) ? 'dita' : 'inferida', sg.chave); }
    if (!tem('subramo')) SUB_CHAVES.some(function (k) { var m = t.match(k[2]); if (m && (!tem('area') || map.area.some(function (a) { return a.chave === k[0] || norm(a.rot) === norm(SEG_ROT[k[0]]); }))) { add('subramo', k[1], m[2], 'dita'); return true; } return false; });
    if (!tem('local')) {
      if (it.localizacao) add('local', it.localizacao, '', '');
      else {
        var mc = t.match(/\b(?:em|de|no|na|para)\s+([A-ZÁÉÍÓÚÂÊÔÃÕÇ][A-Za-zÀ-ÿ'-]+(?:\s+(?:de|do|da|dos|das)\s+[A-ZÁÉÍÓÚÂÊÔÃÕÇ][A-Za-zÀ-ÿ'-]+|\s+[A-ZÁÉÍÓÚÂÊÔÃÕÇ][A-Za-zÀ-ÿ'-]+)*)/);
        var ruim = mc && (PLAT_RX.test(mc[1]) || FORM_RX.test(mc[1]) || NAO_LOCAL.test(mc[1]) || !!achaSeg(mc[1]) || norm(mc[1]) === norm(pf.ramo || '#'));
        if (mc && !ruim) add('local', mc[1], mc[1], 'dita');
        else if (pf.cidade && tn.indexOf(norm(pf.cidade)) >= 0) add('local', pf.cidade, pf.cidade, 'dita');
      }
    }
    var fk = it.formato ? formKey(it.formato) : formKey(t);
    if (!tem('formato')) { var fr = it.formato ? (FORMATO_NOME[fk] || it.formato) : (fk ? FORMATO_NOME[fk] : ''); if (fr) add('formato', fr, fk ? (t.match(FORM_RX) || [0, 0, ''])[2] : '', it.formato ? '' : 'dita'); }
    if (!fk && tem('formato')) fk = formKey(map.formato[0].rot);
    if (!tem('plataforma')) {
      var pk = it.plataforma ? platKey(it.plataforma) : platKey(t);
      if (pk) add('plataforma', PLAT_NOME[pk], it.plataforma ? '' : (t.match(PLAT_RX) || [0, 0, ''])[2], it.plataforma ? '' : 'dita');
      else if (it.plataforma) add('plataforma', it.plataforma, '', '');
      else if (fk === 'reels' || fk === 'stories' || fk === 'carrossel') add('plataforma', 'Instagram', '', 'inferida'); // dedução: nunca "dita"; TikTok/YouTube só se citados
    }
    (map.plataforma || []).forEach(function (x) { if (x.origem === 'dita' && !x.trecho) x.origem = 'inferida'; });
    if (!tem('tema')) {
      var outros = [].concat.apply([], DIM_ORDEM.map(function (d) { return map[d] || []; })).map(function (x) { return norm(x.rot); });
      if (it.assunto && outros.indexOf(norm(it.assunto)) < 0) add('tema', it.assunto, '', '');
      else if (!it.assunto && it.temaDoRamo && r.topico && pers) add('tema', 'tendência do seu ramo: ' + r.topico, '', 'perfil');
    }
    if (!tem('area') && pers && pf.ramo && it.temaDoRamo) add('area', SEG_ROT[pf.ramo] || (pf.ramo.charAt(0).toUpperCase() + pf.ramo.slice(1)), '', 'perfil', pf.ramo);
    var itens = []; DIM_ORDEM.forEach(function (d) { (map[d] || []).forEach(function (x) { itens.push(x); }); });
    return { intencoes: ints, itens: itens, ambigua: !!((cad && cad.ambigua) || (map.area && map.area.length > 1)) };
  }
  function objetivoProvavel(ints) {
    var x = norm(ints.join(' '));
    if (/tend|alta|cresc/.test(x)) return 'descobrir oportunidades';
    if (/ideia|conteudo|roteiro|post/.test(x)) return 'criar conteúdo';
    if (/noticia|novidade/.test(x)) return 'acompanhar o mercado';
    if (/concorr/.test(x)) return 'entender a concorrência';
    if (/refer/.test(x)) return 'buscar inspiração';
    return '';
  }
  function chipEntendi(x) {
    var o = x.origem === 'inferida' ? '<em class="ent-o">deduzido</em>' : x.origem === 'perfil' ? '<em class="ent-o">do seu perfil</em>' : '';
    return '<span class="ent" data-dim="' + esc(x.tipo) + '"><small>' + esc(DIM_ROT[x.tipo] || x.tipo) + '</small><b>' + esc(x.rot) + '</b>' + o + '</span>';
  }
  // contexto progressivo (memória da sessão, nunca gravada): "e para Instagram", "também Reels" herdam a última cadeia
  function dimsDe(e) {
    var d = {}; e.itens.forEach(function (x) { if (!d[x.tipo] && ['area', 'subramo', 'tema', 'local', 'plataforma'].indexOf(x.tipo) >= 0) d[x.tipo] = x.tipo === 'local' || x.tipo === 'plataforma' ? x.rot : { chave: x.chave || '', rotulo: x.rot }; });
    return d;
  }
  function contextoParaBusca(termo) {
    var c = st.ctxBusca; if (!c || !c.area) return null;
    var n = norm(termo).trim(), palavras = n.split(/\s+/).filter(Boolean);
    if (!(/^(e|tambem)\s/.test(n) || palavras.length <= 3)) return null;
    if (achaSeg(termo)) return null; // já tem área própria
    return c;
  }
  function ctxTexto(c) { return ['area', 'subramo', 'tema'].filter(function (k) { return c[k]; }).map(function (k) { return c[k].rotulo; }).join(' › ') + (c.local ? ' · ' + c.local : '') + (c.plataforma ? ' · ' + c.plataforma : ''); }
  function guardarCtx(r, usado) {
    var d = dimsDe(entidadesDaBusca(r));
    if (!d.area && usado) { st.ctxBusca = usado; return; } // sem área nova: mantém o contexto herdado
    st.ctxBusca = d.area ? d : null;
  }
  function linhaEntendi(r) {
    if (!r.interpretacao && !r.termo) return '';
    var e = entidadesDaBusca(r), it = r.interpretacao || {};
    var cor = (it.correcoes || []).filter(function (c) { return c && c.de && c.para; });
    var areas = e.itens.filter(function (x) { return x.tipo === 'area'; });
    var chips = e.itens.map(chipEntendi).join('') + (e.intencoes.length
      ? '<span class="ent" data-dim="intencao"><small>Intenção</small><b>' + esc(e.intencoes.join(' · ')) + '</b></span>'
      : '<span class="ent ent-vazia" data-dim="intencao">Intenção: ainda não identificada</span>');
    var ob = objetivoProvavel(e.intencoes);
    st.entendi = e;
    return '<div class="entendi-box"><p class="entendi"><span class="kicker">Entendi</span><span class="ents">' + chips + '</span><button class="btn ghost sm" type="button" data-corrigir>Corrigir</button></p>' +
      (e.ambigua ? '<p class="muted entendi-amb">' + (areas.length > 1 ? 'Pode ser ' + esc(areas.map(function (a) { return a.rot; }).join(' ou ')) + '. ' : 'A área ficou ambígua. ') + 'Use Corrigir para escolher.</p>' : '') +
      (r._ctx ? '<p class="muted entendi-ctx">Usando o contexto da busca anterior: ' + esc(ctxTexto(r._ctx)) + ' <button class="btn ghost sm" type="button" data-semctx>Não usar</button></p>' : '') +
      (ob ? '<p class="muted entendi-obj">Objetivo provável: ' + esc(ob) + '. É uma suposição, não um fato.</p>' : '') +
      (cor.length ? '<p class="entendi"><span class="corr">Corrigimos ' + esc(cor.map(function (c) { return '"' + c.de + '" → "' + c.para + '"'; }).join(', ')) + '</span></p>' : '') +
      '<div class="corrigir" id="corrigirBox" hidden></div></div>';
  }
  function ligarEntendi(r, box) {
    var sc = $('[data-semctx]', box); if (sc) sc.onclick = function () { $('#q').value = r.termo; buscar(r.termo, { semCtx: true }); };
    var b = $('[data-corrigir]', box), c = $('#corrigirBox', box); if (!b || !c) return;
    var termo = String(r.termo || ''), removidos = [], dims = [], trocando = -1;
    function desenha() {
      var e = st.entendi || { itens: [] };
      var amb = e.ambigua;
      c.innerHTML = '<p class="muted" style="margin:0">Corrija cada item abaixo ou reescreva a pergunta. Isso ajuda a Evolui a entender melhor você.</p>' +
        '<ul class="corr-lista">' + e.itens.map(function (x, i) {
          var rot = esc(DIM_ROT[x.tipo] + ': ' + x.rot) + (x.origem === 'inferida' ? ' (deduzido)' : x.origem === 'perfil' ? ' (do seu perfil)' : '');
          if (removidos.indexOf(i) >= 0) return '';
          if (trocando === i) return '<li><span>' + esc(DIM_ROT[x.tipo]) + ' →</span> <input class="corr-novo" id="corrNovo" maxlength="40" aria-label="Trocar ' + esc(x.rot) + ' por"><button class="chip" type="button" data-trocok="' + i + '">Trocar</button></li>';
          return '<li><span>' + rot + '</span>' + (x.trecho ? '<button class="chip" type="button" data-rem="' + i + '" aria-label="Tirar ' + esc(x.rot) + '">Tirar ✕</button>' : '') +
            '<button class="chip" type="button" data-troca="' + i + '" aria-label="Trocar ' + esc(x.rot) + '">Trocar</button>' +
            (amb && x.tipo === 'area' ? '<button class="chip" type="button" data-fica="' + i + '">Ficar com esta</button>' : '') + '</li>';
        }).join('') + '</ul>' +
        '<div class="barra-busca"><input id="corrQ" maxlength="80" value="' + esc(termo) + '" aria-label="Reescrever a pesquisa"><button class="btn sm cta" type="button" id="corrGo">Buscar de novo</button></div>';
      function sai(tr, por) { var q0 = $('#corrQ', c); if (q0) termo = q0.value; termo = (tr ? termo.replace(tr, por || ' ') : (termo + ' ' + (por || ''))).replace(/\s{2,}/g, ' ').trim(); }
      $$('[data-rem]', c).forEach(function (x) { x.onclick = function () { var k = +x.dataset.rem; removidos.push(k); dims.push(e.itens[k].tipo); sai(e.itens[k].trecho, ''); desenha(); }; });
      $$('[data-troca]', c).forEach(function (x) { x.onclick = function () { var q1 = $('#corrQ', c); if (q1) termo = q1.value; trocando = +x.dataset.troca; desenha(); var n = $('#corrNovo', c); if (n) n.focus(); }; });
      $$('[data-trocok]', c).forEach(function (x) { x.onclick = function () {
        var k = +x.dataset.trocok, v = ($('#corrNovo', c).value || '').trim(); if (!v) return toast('Digite o novo valor.');
        dims.push(e.itens[k].tipo); sai(e.itens[k].trecho, v); trocando = -1; desenha(); }; });
      $$('[data-fica]', c).forEach(function (x) { x.onclick = function () {
        var k = +x.dataset.fica; e.itens.forEach(function (y, j) { if (y.tipo === 'area' && j !== k && y.trecho) { sai(y.trecho, ''); removidos.push(j); } });
        if (!e.itens[k].trecho) sai('', e.itens[k].rot); dims.push('area'); desenha(); }; });
      $('#corrGo', c).onclick = function () {
        var novo = $('#corrQ', c).value.trim(); if (novo.length < 2) return toast('Digite pelo menos 2 letras.');
        registrar('busca_corrigida', { de: String(r.termo || '').slice(0, 80), para: novo.slice(0, 80), removidos: removidos.map(function (k) { return e.itens[k].tipo; }), dimensao: dims.length ? dims[dims.length - 1] : 'texto' });
        $('#q').value = novo; buscar(novo);
      };
    }
    b.onclick = function () { c.hidden = !c.hidden; if (!c.hidden) desenha(); };
  }
  // Nível da inteligência: fato · sinal · tendência. Hipótese nunca é apresentada como fato.
  function nivelDoResultado(r) {
    if (r.estado === 'insuficiente' && !(r.conhecimento && r.conhecimento.adquirido)) return { k: 'insuf', rot: 'Evidência insuficiente' };
    if (r.conhecimento && r.conhecimento.adquirido) return { k: 'contexto', rot: 'Contexto pesquisado' };
    var f = r.fontesComSinal || 0;
    if (r.estado === 'comecando' || f < 2 || r.confianca === 'baixa') return { k: 'sinal', rot: 'Sinal' };
    return { k: 'tendencia', rot: 'Tendência' };
  }
  function quatroPerguntas(r) {
    var n = nivelDoResultado(r), ok = (r.fontes || []).filter(function (f) { return f.ok; }).map(function (f) { return f.nome; });
    var conf = { alta: 'Alta', media: 'Média', baixa: 'Baixa' }[r.confianca] || '—';
    var encontrei = (r.conhecimento && r.conhecimento.adquirido) ? 'Entendi o termo e pesquisei o contexto antes de montar as recomendações.' : (r.estado === 'insuficiente' ? 'Ainda não há evidência suficiente para afirmar uma tendência.' : (n.rot + ': ' + (r.rotulo || '') + (r.crescimento != null ? ' (' + pct(r.crescimento) + ' vs. semana anterior)' : '') + '.'));
    var porque = ok.length ? 'Houve sinal em ' + ok.join(', ') + '. Fonte sem dado não entra na conta.' : 'Nenhuma fonte trouxe sinal suficiente.';
    return '<dl class="quatro"><dt>O que encontrei</dt><dd>' + esc(encontrei) + '</dd><dt>Por que apareceu</dt><dd>' + esc(porque) + '</dd><dt>Confiança</dt><dd>' + esc(conf) + (r.confianca === 'baixa' ? ' (poucos sinais)' : '') + '</dd></dl>';
  }
  function areaDaBusca(r) { var t = String(r && r.termo || ''), a = ''; SEG_CHAVES.some(function (k) { if (k[1].test(t)) { a = k[0]; return true; } return false; }); return a; }
  function cadeiaHtml(r, abertas) {
    if (r.estado === 'insuficiente' && !(r.conhecimento && r.conhecimento.adquirido)) return '';
    var o = r.oportunidade || {}, n = nivelDoResultado(r), L = [];
    var ok = (r.fontes || []).filter(function (f) { return f.ok; }).map(function (f) { return f.nome; });
    var serie = (r.series || []).map(function (x) { return x && x.valores; }).filter(function (v) { return v && v.length > 1 && v.some(function (y) { return y > 0; }); })[0] || [];
    var conf = { alta: 'alta', media: 'média', baixa: 'baixa' }[r.confianca] || '';
    var confR = { alta: 'Alta', media: 'Média', baixa: 'Baixa' }[r.confianca] || '';
    var pontosT = (r.fontes || []).filter(function (f) { return f.ok; }).slice(0, 4).map(function (f) { return f.nome + (f.detalhe ? ' · ' + f.detalhe : ''); });
    L.push({ hero: true, area: areaDaBusca(r), origem: 'busca', type: 'tendencia', badge: n.rot, title: r.termo, description: r.rotulo, metric: r.crescimento != null ? pct(r.crescimento) : '', metricLabel: r.crescimento != null ? 'vs. semana anterior' : '', series: serie, points: pontosT, source: ok.join(', '), period: 'últimos 7 dias', confidence: confR });
    if (o.porQueImporta) L.push({ hero: true, area: areaDaBusca(r), origem: 'busca', type: 'insight', title: 'O que isso significa?', description: o.porQueImporta, tags: ['Interpretação, não fato'], points: ['Leitura feita por regras internas da Evolui', 'Vale como hipótese até você validar'] });
    if (o.oQuePodeFazer) L.push({ hero: true, area: areaDaBusca(r), origem: 'busca', type: 'oportunidade', title: 'Onde agir', description: o.oQuePodeFazer, tags: o.evidencia && o.evidencia.nivel ? [NIVEL_EVID[o.evidencia.nivel] || ''] : [], points: o.evidencia ? [o.evidencia.motivo, 'Fontes consultadas: ' + (o.evidencia.fontesConsultadas || 0)].filter(Boolean) : [], action: abertas[0] ? 'Ver ideias' : '', attrs: { rolar: 'ideias' } });
    if (abertas[0]) L.push({ hero: true, area: areaDaBusca(r), origem: 'busca', type: 'ideia', title: abertas[0].gancho, format: abertas[0].formato || '', tags: [abertas[0].formato || 'Ideia'], points: ['Sobre: ' + r.termo, 'Pronta para testar no Laboratório'], action: 'Levar para o Laboratório', attrs: { cadlab: '1' } });
    if (L.length < 2) return '';
    return '<p class="ci-rot">Do sinal ao Laboratório · Tendência → Insight → Oportunidade → Ideia</p>' + cartoes(L, 'ci-res');
  }
  // Biblioteca da EvoluiSocial: ideias, ganchos, CTAs e guias que combinam com o que a pessoa quer
  var TIPO_BIB = { ideia: 'Ideia', gancho: 'Gancho', cta: 'Chamada (CTA)', formato: 'Formato', guia: 'Guia', legenda: 'Legenda', bio: 'Bio' };

  // ---------------------------------------------------------------- Format Intelligence: transformar uma ideia em outro módulo (usa o perfil)
  var FI_MODULOS = [['mais_ideias', 'Mais ideias'], ['video_curto', 'Vídeo curto'], ['guia_texto', 'Guia de texto'], ['stories', 'Stories'], ['carrossel', 'Carrossel'], ['formato_carrossel', 'Formato do carrossel']];
  st.fiIdeias = st.fiIdeias || [];
  function fiBloco(ideia) {
    st.fiIdeias.push(ideia); var k = st.fiIdeias.length - 1;
    return '<details class="mais fi" data-fi-box="' + k + '"><summary>Transformar esta ideia</summary><div class="chips" style="margin-top:8px">' +
      FI_MODULOS.map(function (m) { return '<button class="chip" data-fi="' + m[0] + '" data-fi-k="' + k + '">' + m[1] + '</button>'; }).join('') + '</div><div class="fi-out" aria-live="polite"></div></details>';
  }
  function fiLista(itens, fn) { return '<ol class="fi-l">' + itens.map(fn).join('') + '</ol>'; }
  function fiRender(r) {
    var x = r.resultado || {}, h = '';
    if (x.cenas) h = '<p class="sub" style="margin:0">' + esc(x.duracao_aprox) + ' · ' + esc(x.ritmo) + (x.observacao ? ' · ' + esc(x.observacao) : '') + '</p>' + fiLista(x.cenas, function (c) { return '<li><b>' + esc(c.tempo) + ' · ' + esc(c.funcao) + '</b><br>Ação visual: ' + esc(c.acao_visual) + '<br>Fala: ' + esc(c.fala) + (c.texto_na_tela ? '<br>Texto na tela: ' + esc(c.texto_na_tela) : '') + '</li>'; });
    else if (x.secoes) h = fiLista(x.secoes, function (c) { return '<li><b>' + esc(c.secao) + '</b><br>' + esc(c.orientacao) + '<br><i>' + esc(c.exemplo) + '</i></li>'; }) + '<p class="sub" style="margin:0">Tamanho: ' + esc(x.tamanho_sugerido) + '</p>';
    else if (x.sequencia) h = fiLista(x.sequencia, function (c) { return '<li><b>Story ' + c.story + ' · ' + esc(c.funcao) + '</b><br>' + esc(c.conteudo) + (c.recurso ? '<br><i>Recurso: ' + esc(c.recurso) + '</i>' : '') + '</li>'; });
    else if (x.slides) h = fiLista(x.slides, function (c) { return '<li><b>Slide ' + c.slide + ' · ' + esc(c.papel) + ': ' + esc(c.titulo) + '</b><br>' + esc(c.texto) + '<br><i>' + esc(c.visual) + '</i></li>'; });
    else if (x.estrutura_escolhida) h = '<p style="margin:0"><b>' + esc(x.estrutura_escolhida.rotulo) + '</b> — ' + esc(x.estrutura_escolhida.porque) + '</p>' + fiLista(x.esqueleto, function (c) { return '<li>' + esc(c.conteudo) + '</li>'; }) + '<p class="sub" style="margin:0">Outras estruturas possíveis: ' + x.alternativas.map(function (a) { return esc(a.rotulo); }).join(', ') + '.</p>';
    else if (x.ideias) h = fiLista(x.ideias, function (c) { return '<li><b>' + esc(c.angulo) + ': ' + esc(c.titulo) + '</b><br>' + esc(c.descricao) + '</li>'; });
    return '<div class="fi-res">' + h + '<p class="sub" style="font-size:13px;margin:0">' + esc((r.perfil && r.perfil.aviso) || '') + '</p></div>';
  }
  async function fiGerar(btn) {
    var box = btn.closest('.fi'), out = $('.fi-out', box), ideia = st.fiIdeias[+btn.dataset.fiK];
    $$('[data-fi]', box).forEach(function (b) { b.setAttribute('aria-pressed', b === btn); });
    out.innerHTML = '<p class="muted">Adaptando ao seu perfil…</p>';
    try {
      var r = await E.api('', { modulo: btn.dataset.fi, ideia: ideia, objetivo: st.objetivoFI || undefined, termo: ideia.termo || '' }, 'evolui-criar');
      out.innerHTML = fiRender(r);
    } catch (e) { out.innerHTML = '<p class="muted">' + esc((e && e.message) || 'Não foi possível adaptar agora.') + '</p>'; }
  }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-fi]'); if (b) fiGerar(b); });
  function itemBib(x, k) {
    return '<article class="ideia"><span class="kicker">' + esc(TIPO_BIB[x.tipo] || x.tipo || 'Ideia') + (x.formato ? ' · ' + esc(FORMATO_NOME[x.formato] || x.formato) : '') + '</span>' +
      '<h4>' + esc(x.titulo) + '</h4>' + (x.descricao ? '<p class="sub" style="margin:0">' + esc(x.descricao) + '</p>' : '') +
      (x.execucao && x.execucao.length ? '<ol class="passos-lib">' + x.execucao.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ol>' : '') +
      (x.motivo ? '<p class="porque">' + esc(x.motivo) + '</p>' : '') +
      (x.tipo === 'ideia' || x.tipo === 'gancho' ? '<div class="linha">' + usarBtn({ titulo: x.titulo, descricao: x.descricao || '', formato: x.formato || null, termo: (st.bib && st.bib.termo) || '', origem: 'biblioteca' }) + '</div>' + fiBloco({ titulo: x.titulo, descricao: x.descricao || '', formato: x.formato || null, termo: (st.bib && st.bib.termo) || '' }) : '') +
      (x.texto ? '<details class="mais"><summary>Ver modelo</summary><div style="display:flex;flex-direction:column;gap:10px;margin-top:6px"><div class="caixa-legenda" id="bib' + k + '">' + esc(x.texto) + '</div>' +
        '<div class="linha"><button class="btn sm cta" data-bib-copiar="' + k + '">Copiar</button><button class="btn sm" data-bib-salvar="' + k + '">Salvar</button></div></div></details>' : '') + '</article>';
  }
  function bibliotecaHTML(r) {
    var b = r.biblioteca;
    st.bib = { itens: (b && b.itens) || [], termo: r.termo, total: (b && (b.totalReal || b.total)) || 0 };
    if (!st.bib.itens.length) return '';
    return (r.estado === 'insuficiente' ? '<p class="nivel-rot">2 · O que postar</p>' : '') +
      '<section class="card"><div class="entre"><h3>Mais ideias para isso</h3><span class="kicker">' + st.bib.total + ' na biblioteca</span></div>' +
      (b.ampliada ? '<p class="sub" style="margin:0">Achamos pouco sobre exatamente isso, então incluímos ideias ligadas ao seu ramo.</p>' : '') +
      '<div class="acao-grade" id="bibLista">' + st.bib.itens.map(itemBib).join('') + '</div><div id="bibMais"></div></section>';
  }
  function ligarBiblioteca(r, box) {
    var lista = $('#bibLista', box); if (!lista) return;
    function botao() {
      var m = $('#bibMais', box); if (!m) return;
      m.innerHTML = st.bib.itens.length < st.bib.total ? '<div class="linha" style="justify-content:center"><button class="btn" id="bibVer">Ver mais ideias</button></div>' : '';
      var v = $('#bibVer', box); if (v) v.onclick = async function () {
        v.disabled = true; v.textContent = 'Carregando…';
        try {
          var x = await E.api('biblioteca', { termo: st.bib.termo, offset: st.bib.itens.length, excluir: st.bib.itens.map(function (i) { return i.id; }).filter(Boolean) });
          if (x.bloqueado) { m.innerHTML = '<div class="ideia travada">' + borrado(4) + travado('Mais ' + Math.max(0, st.bib.total - st.bib.itens.length) + ' ideias da biblioteca para essa busca', x.plano || 'pro') + '</div>'; $$('[data-liberar]', m).forEach(function (b) { b.onclick = function () { abrirPlanos('biblioteca', b.dataset.liberar); }; }); registrar('bloqueado_visto', { termo: st.bib.termo, itens: 1, origem: 'biblioteca' }); return; }
          var vistos = {}; st.bib.itens.forEach(function (i) { vistos[i.id] = 1; });
          var novos = (x.itens || []).filter(function (i) { return !vistos[i.id]; });
          if (!novos.length) { st.bib.total = st.bib.itens.length; botao(); return; }
          var ini = st.bib.itens.length; st.bib.itens = st.bib.itens.concat(novos);
          lista.insertAdjacentHTML('beforeend', novos.map(function (i, j) { return itemBib(i, ini + j); }).join(''));
          botao();
        } catch (e) { v.disabled = false; v.textContent = 'Tentar de novo'; toast(e.message || 'Não foi possível carregar.'); }
      };
    }
    lista.onclick = function (e) {
      var c = e.target.closest('[data-bib-copiar]'), s2 = e.target.closest('[data-bib-salvar]');
      if (c) { var i = st.bib.itens[+c.dataset.bibCopiar]; evento('copy', { tipo: 'biblioteca', id: i.id, consulta: st.bib.termo }, { formato: i.formato || null }); copiar(i.texto, $('#bib' + c.dataset.bibCopiar), i.formato || i.tipo); }
      if (s2) { var j = st.bib.itens[+s2.dataset.bibSalvar]; evento('save', { tipo: 'biblioteca', id: j.id, consulta: st.bib.termo }, { formato: j.formato || null }); salvarItem('ideia', j.titulo, { termo: st.bib.termo, origem: 'biblioteca', biblioteca_id: j.id, ideia: { formato: j.formato || TIPO_BIB[j.tipo] || '', gancho: j.titulo, roteiro: [], legenda: j.texto || '' } }, s2); }
    };
    botao();
  }
  var NIVEL_EVID = { alta: 'Sinal forte', media: 'Sinal consistente', baixa: 'Sinal inicial' };
  var TITULOS_REPERTORIO = ['O que vale levar daqui', 'Padrões que combinam com seu tema', 'Repertório que pode destravar a ideia'];
  var TITULOS_OPORTUNIDADE = ['Onde existe espaço agora', 'A oportunidade por trás do sinal', 'O próximo movimento possível'];
  function oportunidadeHtml(r) {
    var o = r && r.oportunidade; if (!o || !o.evidencia) return '';
    var ev = o.evidencia, quando = ev.data ? dataHora(ev.data) : '';
    var vids = (r.videos || []).map(function (v) {
      var u = urlSegura(v.url); if (!u) return '';
      var m = String(u).match(/[?&]v=([^&]+)/); var id = m ? m[1] : '';
      var thumb = id && /^[\w-]{6,20}$/.test(id) ? '<img class="op-video-thumb" src="https://i.ytimg.com/vi/' + esc(id) + '/hqdefault.jpg" alt="" loading="lazy">' : '';
      return '<li class="op-video-item">' + thumb + '<div><a href="' + esc(u) + '" target="_blank" rel="noopener">' + esc(v.titulo) + '</a><span class="muted">' + esc(v.canal || '') + '</span></div></li>';
    }).join('');
    var titulo = TITULOS_OPORTUNIDADE[Math.abs(String(r.termo || '').length) % TITULOS_OPORTUNIDADE.length];
    var fonteInfo = '<button class="info-btn" type="button" aria-label="Ver fontes desta leitura" title="Ver fontes">i</button>';
    return '<section class="card oportunidade"><div class="entre"><h3>' + titulo + '</h3><div class="op-badges"><span class="pill nv-op">Ação possível</span><span class="pill ev-' + esc(ev.nivel) + '">' + esc(NIVEL_EVID[ev.nivel] || '') + '</span></div></div>' +
      '<p class="op-lead">' + esc(o.oQuePodeFazer || o.porQueImporta || '') + '</p>' +
      '<div class="op-insight"><span class="kicker">O sinal</span><p>' + esc(o.oQueEstaAcontecendo || '') + '</p></div>' +
      '<p class="op-why"><b>Por que olhar agora:</b> ' + esc(o.porQueImporta || '') + '</p>' +
      '<div class="op-source-row">' + fonteInfo + '<span>Como chegamos aqui</span><span class="muted">' + esc(ev.motivo || '') + '</span></div>' +
      '<details class="op-fontes"><summary>Ver fontes e data da leitura</summary><div class="op-fontes__body"><b>' + (ev.fontesConsultadas || 0) + '</b> fonte(s) consultada(s)' + (quando ? ' · ' + esc(quando) : '') + '</div></details>' +
      (vids ? '<details class="mais op-videos"><summary>Ver exemplos em vídeo</summary><ul class="fontes">' + vids + '</ul></details>' : '') + '</section>';
  }
  function repertorioHtml(r) {
    var b = r && r.repertorio; if (!b || !(b.itens || []).length) return '';
    var rot = b.rotulos || {}, itens = b.itens.slice(0, 3);
    var gan = (b.ganchos || []).slice(0, 4);
    var ins = (b.insights || []).slice(0, 2);
    var titulo = TITULOS_REPERTORIO[Math.abs(String(r.termo || '').length) % TITULOS_REPERTORIO.length];
    var fonteInfo = '<button class="info-btn" type="button" aria-label="Ver origem do repertório" title="Ver origem">i</button>';
    var itensHtml = itens.map(function (i, k) {
      return '<article class="rep-item"><span class="rep-index">0' + (k + 1) + '</span><div><b>' + esc(i.titulo) + '</b>' +
        '<p>' + esc((i.aplicacoes && i.aplicacoes.length ? i.aplicacoes.slice(0,2).join(' · ') : i.motivo || 'Padrão útil para pensar o conteúdo.')) + '</p></div></article>';
    }).join('');
    var ganHtml = gan.map(function(g){ return '<li><b>' + esc(g.texto) + '</b><span>' + esc(g.estrutura || 'estrutura adaptada') + '</span></li>'; }).join('');
    var insHtml = ins.map(function(i){ return '<li>' + esc(i.texto) + '</li>'; }).join('');
    return '<section class="card repertorio"><div class="entre"><div><span class="kicker">REPERTÓRIO</span><h3>' + titulo + '</h3></div>' + fonteInfo + '</div>' +
      '<p class="rep-intro">O Evolui encontrou padrões que podem enriquecer sua criação sem copiar a fonte.</p>' +
      '<div class="rep-items">' + itensHtml + '</div>' +
      (ganHtml ? '<details class="rep-more" open><summary>Transforme o padrão em conteúdo</summary><ul>' + ganHtml + '</ul></details>' : '') +
      (insHtml ? '<details class="rep-more"><summary>Uma hipótese para testar</summary><ul>' + insHtml + '</ul></details>' : '') +
      '<div class="rep-origin"><span class="info-dot">i</span><span>Fonte e origem ficam disponíveis aqui, sem ocupar a leitura principal.</span><span class="muted">' + esc(rot.referencia || 'Repertório interno da Evolui') + '</span></div></section>';
  }
  function renderResultado(r, salvoEm) {
    var box = $('#resultado'); if (!box) return;
    st.resultado = r;
    var conf = { alta: 'Alta', media: 'Média', baixa: 'Baixa' }[r.confianca] || '—';
    var ideias = r.ideias || [];
    var abertas = ideias.filter(function (d) { return !d.bloqueado; });
    var ctxMem = '';
    try {
      var cf = ((st.copInf && st.copInf.ativas) || []).filter(function (p) { return p.origem === 'confirmada' && String(p.id).indexOf('formato:') === 0; })[0];
      if (cf && abertas.length > 1) {
        var fv = norm(String(cf.id).slice(8)), idx = function (d) { return norm(d.formato || '').indexOf(fv) >= 0 ? 0 : 1; };
        var ord = abertas.map(function (d, k) { return [d, k]; }).sort(function (a, b) { return idx(a[0]) - idx(b[0]) || a[1] - b[1]; }).map(function (x) { return x[0]; });
        if (ord.some(function (d, k) { return d !== abertas[k]; })) { abertas = ord; ctxMem = '<p class="muted ctx-mem">Usando como contexto: você confirmou que ' + esc(cf.rotulo.toLowerCase()) + '. Isso só muda a ordem das ideias; nada foi escondido.</p>'; }
      }
    } catch (e) { /* sem contexto */ }
    var travadas = ideias.filter(function (d) { return d.bloqueado; });
    // 1) VEREDITO
    var html = '<p class="nivel-rot">1 · O veredito</p><section class="card destaque veredito"><div class="entre"><span class="kicker">' + (salvoEm ? 'Pesquisa de ' + dataHora(salvoEm) : 'Resultado de agora') + '</span><span class="pill e-' + esc(r.estado) + '">' + esc((r.conhecimento && r.conhecimento.adquirido) ? 'Contexto pesquisado' : r.rotulo) + '</span></div>' +
      '<h2 class="tit">' + esc(r.termo) + '</h2>' + linhaEntendi(r) +
      quatroPerguntas(r) + '<p class="recomenda"><span class="estrela"></span><span>' + esc(RECOMENDA[r.estado] || '') + '</span></p>' +
      '<div class="resumo-tend"><div><b>' + pct(r.crescimento) + '</b><span>vs. semana anterior</span></div><div><b>' + (r.fontesComSinal || 0) + '</b><span>fontes com sinal</span></div><div><b>' + conf + '</b><span>confiança</span></div></div>' +
      (r.personalizado ? '<span class="kicker">Ideias ajustadas às suas respostas do dia</span>' : '') + '</section>';
    html += ctxMem ? '<section class="card">' + ctxMem + '</section>' : '';
    html += cadeiaHtml(r, abertas);
    if (r.conhecimento && r.conhecimento.adquirido) {
      var kc = r.conhecimento;
      html += '<section class="card"><div class="entre"><div><span class="kicker">Evolui Knowledge Engine</span><h3 style="margin-top:3px">Entendimento ampliado</h3></div><span class="pill">' + esc(Math.round((kc.confianca || 0) * 100)) + '% de confiança</span></div><p class="sub">A Evolui pesquisou o termo antes de montar as ideias. Ela encontrou contexto, significados e relações para não depender apenas da palavra digitada.</p>' + ((kc.significados || []).length ? '<div class="chips">' + kc.significados.slice(0,4).map(function(x){return '<span class="chip">'+esc(x)+'</span>';}).join('') + '</div>' : '') + '</section>';
    }
    html += repertorioHtml(r);
    html += oportunidadeHtml(r);
    if (r.estado === 'insuficiente' && !(r.conhecimento && r.conhecimento.adquirido)) {
      html += '<section class="card"><h3>Ainda não há sinal claro sobre "' + esc(r.topico || r.termo) + '"</h3><p class="sub">O assunto pode ser novo, específico ou ainda pequeno nas fontes consultadas. Isso não significa que não exista oportunidade. Tente uma variação mais ampla' + (r.relacionados && r.relacionados.length ? ' ou um dos assuntos abaixo' : '') + '.</p>' +
        (r.relacionados && r.relacionados.length ? '<div class="chips" data-rel>' + r.relacionados.map(function (x) { return '<button class="chip" data-q="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div>' : '') + '</section>';
    } else {
      // 2) O QUE FAZER
      html += '<p class="nivel-rot">2 · O que postar</p>';
      if (r.emAltaHoje && r.emAltaHoje.length) html += '<section class="card" style="border-color:rgba(255,49,128,.45)"><h3>Está entre as buscas em alta no Google hoje</h3>' + r.emAltaHoje.map(function (i) { return '<p class="sub">' + esc(i.termo) + (i.trafego ? ' · ' + esc(i.trafego) + ' buscas' : '') + (i.noticia ? ' · ' + esc(i.noticia) : '') + '</p>'; }).join('') + '</section>';
      html += '<div class="acao-grade">' + abertas.map(function (d, i) {
        return '<article class="ideia"><span class="kicker">' + esc(d.formato) + '</span><h4>' + esc(d.gancho) + '</h4><p class="porque">' + esc(d.porque) + '</p>' +
          '<div class="linha">' + usarBtn({ titulo: d.gancho, descricao: d.porque || '', formato: d.formato || null, termo: r.termo }) + '</div>' +
          '<details class="mais"><summary>Ver roteiro e legenda</summary><div style="display:flex;flex-direction:column;gap:10px;margin-top:6px"><ol>' + (d.roteiro || []).map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ol>' +
          '<div class="caixa-legenda" id="leg' + i + '">' + esc(d.legenda) + '</div><div class="linha"><button class="btn sm cta" data-copiar="' + i + '">Copiar legenda</button><button class="btn sm" data-salvar-ideia="' + i + '">Salvar ideia</button><button class="btn sm ghost" data-lab="' + i + '">Testar no laboratório</button></div></div></details>' + fiBloco({ titulo: d.gancho, descricao: d.porque || '', formato: d.formato || null, termo: r.termo }) + '</article>';
      }).join('') + travadas.map(function (d, i) {
        return '<article class="ideia travada' + (i ? ' extra' : '') + '"><span class="kicker">' + esc(d.formato) + '</span>' + borrado(5) + travado('Mais uma ideia pronta, com roteiro e legenda', d.plano) + '</article>';
      }).join('') + (travadas.length > 1 ? '<div class="mais-travado so-celular">' + ICON.cadeado + '<span>Mais ' + (travadas.length - 1) + ' ideia(s): ' + travadas.slice(1).map(function (d) { return esc(d.formato.split(' ')[0]); }).join(', ') + '</span><button class="btn ghost sm" data-liberar="' + esc(travadas[travadas.length - 1].plano) + '" style="margin-left:auto">Ver planos</button></div>' : '');
      if (r.bio) html += '<article class="ideia"><span class="kicker">Bio sugerida · até 150 caracteres</span><div class="caixa-legenda" id="bioS">' + esc(r.bio) + '</div><div class="linha"><button class="btn sm cta" id="copiaBio">Copiar bio</button><button class="btn sm ghost" id="labBio">Testar no laboratório</button></div></article>';
      else if (r.bioBloqueada) html += '<article class="ideia travada"><span class="kicker">Bio sugerida para o seu negócio</span>' + borrado(4) + travado('Uma bio pronta, feita a partir do seu perfil', 'pro') + '</article>';
      html += '</div>';
    }
    html += objetivosDaPesquisa(r);
    html += bibliotecaHTML(r);
    // 3) AS PROVAS
    html += '<p class="nivel-rot">3 · De onde vem</p><div class="provas-grade"><div style="display:flex;flex-direction:column;gap:18px;min-width:0">';
    var g = r.estado !== 'insuficiente' ? grafico(r.series) : '';
    if (g) html += '<section class="card"><div class="entre"><h3>Interesse nos últimos dias</h3>' + (plano() === 'free' ? '<button class="btn ghost sm" data-liberar="pro">Ver 28 dias no Pro</button>' : '') + '</div>' + g + '</section>';
    html += '<section class="card"><h3>Por que estamos mostrando isso?</h3><ul class="fontes">' + (r.fontes || []).map(function (f) {
      var link = urlSegura(f.link);
      return '<li><span class="st ' + (f.ok ? 'ok' : 'nao') + '">' + (f.ok ? '✓' : '–') + '</span><span><b>' + esc(f.nome) + '</b> · ' + esc(f.detalhe) + (link ? ' · <a href="' + esc(link) + '" target="_blank" rel="noopener">abrir</a>' : '') + '</span></li>';
    }).join('') + '</ul><p class="muted" style="font-size:13px;margin:0">Comparamos os últimos 7 dias com os 7 anteriores em cada fonte. Fonte sem dado não entra na conta: nada é estimado.</p></section></div>';
    html += '<div style="display:flex;flex-direction:column;gap:18px;min-width:0">';
    if (r.pesquisa_avancada && r.pesquisa_avancada.resultados && r.pesquisa_avancada.resultados.length) {
      var pp = r.pesquisa_avancada.provedores || [];
      html += '<section class="card web-descoberta"><div class="entre"><div><span class="kicker">Descoberta web</span><h3 style="margin-top:3px">A pesquisa foi além da consulta inicial</h3></div><span class="pill">' + esc(pp.filter(function (x) { return x.ativo; }).map(function (x) { return x.nome; }).join(' + ')) + '</span></div><p class="sub" style="margin:0">Os mecanismos de pesquisa avançada entram na descoberta e na expansão de assuntos. Eles não são tratados sozinhos como prova de tendência.</p><ul class="noticias">' + r.pesquisa_avancada.resultados.slice(0, 4).map(function (n) { var u = urlSegura(n.url); return u ? '<li><a href="' + esc(u) + '" target="_blank" rel="noopener">' + esc(n.titulo) + '<small>' + esc(n.dominio || '') + (n.provedor ? ' · ' + esc(n.provedor) : '') + '</small></a></li>' : ''; }).join('') + '</ul></section>';
    }
    if ((r.noticias && r.noticias.length) || r.noticiasBloqueadas) html += '<section class="card"><div class="entre"><h3>Notícias recentes</h3><span class="pill nv-fato" title="Notícias publicadas, com fonte e data">Fato</span></div><ul class="noticias">' + (r.noticias || []).map(function (n) {
      var d = n.data ? n.data.slice(6, 8) + '/' + n.data.slice(4, 6) : '', u = urlSegura(n.url);
      return u ? '<li><a href="' + esc(u) + '" target="_blank" rel="noopener">' + esc(n.titulo) + '<small>' + esc(n.site) + (d ? ' · ' + d : '') + '</small></a></li>' : '';
    }).join('') + '</ul>' + (r.noticiasBloqueadas ? '<div class="mais-travado">' + ICON.cadeado + '<span>Mais ' + r.noticiasBloqueadas + ' notícia(s) no plano Pro</span><button class="btn ghost sm" data-liberar="pro" style="margin-left:auto">Ver planos</button></div>' : '') + '</section>';
    if (r.estado !== 'insuficiente' && r.relacionados && r.relacionados.length) html += '<section class="card"><h3>Assuntos relacionados</h3><div class="chips" data-rel>' + r.relacionados.map(function (x) { return '<button class="chip" data-q="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div></section>';
    html += '<div class="linha"><button class="btn" id="salvarTend">Salvar tendência</button></div></div></div>';
    box.innerHTML = html;
    $$('[data-rel]', box).forEach(function (c) { c.onclick = function (e) { var b = e.target.closest('[data-q]'); if (b) { $('#q').value = b.dataset.q; buscar(b.dataset.q); } }; });
    $$('[data-pobj]', box).forEach(function (b) { b.onclick = function () { gerarCta(b.dataset.pobj, { tema: (r.interpretacao && r.interpretacao.assunto) || '', busca: r.termo }, b); }; });
    $$('[data-copiar]', box).forEach(function (b) { b.onclick = function () { var d = abertas[+b.dataset.copiar]; copiar(d.legenda, $('#leg' + b.dataset.copiar), d.formato); }; });
    $$('[data-salvar-ideia]', box).forEach(function (b) { b.onclick = function () { var d = abertas[+b.dataset.salvarIdeia]; salvarItem('ideia', d.gancho, { termo: r.termo, ideia: d }, b); }; });
    $$('[data-lab]', box).forEach(function (b) { b.onclick = function () { var d = abertas[+b.dataset.lab]; st.labEditando = { tipo: 'legenda', titulo: r.termo, versao_a: d.legenda, versao_b: '' }; ir('laboratorio', { novo: true }); }; });
    $$('[data-liberar]', box).forEach(function (b) { b.onclick = function () { abrirPlanos('resultado', b.dataset.liberar); }; });
    var cb = $('#copiaBio'); if (cb) cb.onclick = function () { copiar(r.bio, $('#bioS'), 'bio'); };
    var lb = $('#labBio'); if (lb) lb.onclick = function () { st.labEditando = { tipo: 'bio', titulo: 'Bio sugerida × minha bio', versao_a: r.bio, versao_b: '' }; ir('laboratorio', { novo: true }); };
    $('#salvarTend').onclick = function () { salvarItem('tendencia', r.termo, { termo: r.termo, estado: r.estado, rotulo: r.rotulo, crescimento: r.crescimento, em: r.atualizadoEm }, this); };
    ligarBiblioteca(r, box);
    ligarEntendi(r, box);
    animar(box);
    $$('[data-rolar]', box).forEach(function (b) { b.onclick = function () { var a = $('.acao-grade', box); if (a && a.scrollIntoView) a.scrollIntoView({ behavior: 'smooth', block: 'start' }); }; });
    var cl = $('[data-cadlab]', box); if (cl && abertas[0]) cl.onclick = function () { st.labEditando = { tipo: 'legenda', titulo: String(r.termo).slice(0, 80), versao_a: abertas[0].legenda || abertas[0].gancho, versao_b: '' }; ir('laboratorio', { novo: true }); };
    if (travadas.length || r.bioBloqueada) registrar('bloqueado_visto', { termo: r.termo, itens: travadas.length + (r.bioBloqueada ? 1 : 0) });
  }
  async function salvarItem(tipo, titulo, dados, btn) {
    if (btn) btn.disabled = true;
    var x = await sb.from('evolui_salvos').insert({ user_id: st.user.id, tipo: tipo, titulo: String(titulo).slice(0, 140), dados: dados });
    if (btn) { btn.disabled = false; if (!x.error) btn.textContent = 'Salvo ✓'; }
    toast(x.error ? 'Não foi possível salvar agora.' : 'Salvo! Está no Histórico › Salvos.');
    if (!x.error) registrar('salvou', { tipo: tipo, formato: dados && dados.ideia && dados.ideia.formato });
  }

  // ---------------------------------------------------------------- planos (upgrade)
  async function abrirPlanos(origem, foco) {
    registrar('plano_interesse', { origem: origem || '', foco: foco || '' });
    if (!st.precos) {
      var c = await sb.from('evolui_config').select('chave,valor').in('chave', ['precos', 'pagamento_ativo']);
      var m = {}; (c.data || []).forEach(function (x) { m[x.chave] = x.valor; });
      st.precos = { tabela: m.precos || { pro: { mensal: 2990, anual: 29880 }, master: { mensal: 5990, anual: 59880 } }, ativo: m.pagamento_ativo === true };
    }
    var T = st.precos.tabela, ciclo = 'mensal';
    var f = document.createElement('div'); f.className = 'modal-fundo';
    function desenha() {
      var item = function (k, feat, beneficios) {
        var v = T[k] && T[k][ciclo];
        return '<div class="plano-app' + (feat ? ' feat' : '') + '"><h3>' + NOME_PLANO[k] + '</h3><div class="preco">' + (v ? reais(ciclo === 'anual' ? Math.round(v / 12) : v) : '—') + ' <small>por mês' + (ciclo === 'anual' && v ? ' · ' + reais(v) + ' por ano' : '') + '</small></div>' +
          '<ul>' + beneficios.map(function (b) { return '<li>' + b + '</li>'; }).join('') + '</ul>' +
          (plano() === k ? '<span class="pill e-crescendo" style="align-self:flex-start">Seu plano atual</span>' : '<button class="btn ' + (feat ? 'cta' : '') + '" data-assinar="' + k + '">Quero o ' + NOME_PLANO[k] + '</button>') + '</div>';
      };
      f.innerHTML = '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="mpT"><div class="entre"><h3 id="mpT" style="font-size:26px">Escolha seu plano</h3><button class="btn ghost sm" id="mpX">Fechar</button></div>' +
        '<div class="segmentos" role="group" aria-label="Forma de cobrança"><button data-ciclo="mensal" aria-pressed="' + (ciclo === 'mensal') + '">Mensal</button><button data-ciclo="anual" aria-pressed="' + (ciclo === 'anual') + '">Anual · 2 meses grátis</button></div>' +
        '<div class="planos-app">' + item('pro', foco !== 'master', ['300 pesquisas por mês', '3 ideias completas por pesquisa', 'Bio sugerida e 28 dias de gráfico', 'Seu mercado no mapa da cidade']) +
        item('master', foco === 'master', ['1.000 pesquisas por mês', '5 ideias completas por pesquisa', 'Tudo do Pro', 'Notícias e relacionados sem limite']) + '</div>' +
        '<p class="muted" style="font-size:13px;margin:0">Pagamento seguro pelo Mercado Pago (Pix, cartão ou boleto). Seus dados de cartão ficam só no Mercado Pago. ' + (T.status === 'proposta' ? 'Preços em fase de lançamento.' : '') + '</p><p class="erro-campo" id="mpErro" role="alert"></p></div>';
      $('#mpX', f).onclick = function () { f.remove(); };
      $$('[data-ciclo]', f).forEach(function (b) { b.onclick = function () { ciclo = b.dataset.ciclo; desenha(); }; });
      $$('[data-assinar]', f).forEach(function (b) {
        b.onclick = async function () {
          b.disabled = true; b.textContent = 'Abrindo o pagamento…';
          try { var r = await E.api('checkout', { plano: b.dataset.assinar, ciclo: ciclo }, 'evolui-pagamentos'); if (r.url && /^https:\/\/([a-z0-9-]+\.)*mercadopago\.com(\.br)?\//i.test(r.url)) location.href = r.url; else throw new Error('Não conseguimos abrir o pagamento.'); }
          catch (e) { $('#mpErro', f).textContent = e.message; b.disabled = false; b.textContent = 'Quero o ' + NOME_PLANO[b.dataset.assinar]; }
        };
      });
    }
    desenha();
    f.onclick = function (e) { if (e.target === f) f.remove(); };
    document.body.appendChild(f);
  }

  // ---------------------------------------------------------------- histórico
  function telaHistorico(extra) {
    var seg = (extra && extra.seg) || 'buscas';
    $('#conteudo').innerHTML = '<div><h1 class="tit">Histórico</h1><p class="sub">Suas pesquisas e o que você guardou.</p></div>' +
      '<div class="segmentos" role="group"><button data-seg="buscas" aria-pressed="' + (seg === 'buscas') + '">Pesquisas</button><button data-seg="acoes" aria-pressed="' + (seg === 'acoes') + '">Ações</button><button data-seg="salvos" aria-pressed="' + (seg === 'salvos') + '">Salvos</button><button data-seg="conteudos" aria-pressed="' + (seg === 'conteudos') + '">Conteúdos</button></div><div class="lista-grade" id="lista"><p class="muted">Carregando…</p></div>';
    $$('[data-seg]').forEach(function (b) { b.onclick = function () { telaHistorico({ seg: b.dataset.seg }); }; });
    seg === 'buscas' ? listaBuscas() : seg === 'acoes' ? listaAcoes() : seg === 'conteudos' ? listaConteudos() : listaSalvos();
  }
  var POR_PAG_HIST = 30;
  async function listaBuscas() {
    var L = $('#lista');
    if (!$('#histQ')) {
      L.insertAdjacentHTML('beforebegin', '<form class="barra-busca hist-busca" id="fHist" role="search">' + ICON.lupa + '<input id="histQ" type="search" placeholder="Procurar nas suas pesquisas" aria-label="Procurar nas suas pesquisas" maxlength="80" autocomplete="off"></form>');
      var tq; $('#histQ').oninput = function () { clearTimeout(tq); tq = setTimeout(listaBuscas, 300); };
      $('#fHist').onsubmit = function (e) { e.preventDefault(); listaBuscas(); };
    }
    var q = $('#histQ').value.trim();
    var r = await sb.rpc('evolui_meu_historico', { p_q: q, p_limite: POR_PAG_HIST, p_offset: 0 });
    if (!$('#lista')) return;
    if (r.error) { L.innerHTML = '<p class="muted">Não foi possível carregar.</p>'; return; }
    r = { data: (r.data && r.data.itens) || [], total: (r.data && r.data.total) || 0 };
    if (!r.data.length && q) { L.innerHTML = '<div class="vazio"><h3>Nada encontrado</h3><p>Nenhuma pesquisa sua parecida com "' + esc(q) + '".</p></div>'; return; }
    if (!r.data.length) { L.innerHTML = '<div class="vazio"><h3>Nenhuma pesquisa ainda</h3><p>Faça sua primeira busca e ela aparece aqui.</p><button class="btn cta" id="ir1">Pesquisar agora</button></div>'; $('#ir1').onclick = function () { ir('buscar'); }; return; }
    var ROT = { em_alta: 'Em alta', crescendo: 'Crescendo', comecando: 'Começando', estavel: 'Estável', caindo: 'Caindo', pico: 'Pico passageiro', insuficiente: 'Dados insuficientes' };
    var linha = function (b) {
      return '<div class="item"><div style="min-width:0"><div class="t">' + esc(b.termo) + '</div><div class="d">' + dataHora(b.criado_em) + ' <span class="pill e-' + esc(b.estado_tendencia || 'insuficiente') + '">' + esc(ROT[b.estado_tendencia] || '—') + '</span></div></div>' +
        '<div class="acoes"><button class="btn sm" data-abrir="' + esc(b.id) + '">Abrir</button><button class="btn sm ghost perigo" data-apagar="' + esc(b.id) + '" aria-label="Apagar">✕</button></div></div>';
    };
    var mostrados = r.data.length;
    var mais = function () { return mostrados < r.total ? '<div class="linha" id="histMais" style="justify-content:center"><button class="btn" data-mais="1">Carregar mais</button></div>' : ''; };
    L.innerHTML = r.data.map(linha).join('') + mais();
    L.onclick = async function (e) {
      var a = e.target.closest('[data-abrir]'), d = e.target.closest('[data-apagar]'), m = e.target.closest('[data-mais]');
      if (m) {
        m.disabled = true;
        var p = await sb.rpc('evolui_meu_historico', { p_q: q, p_limite: POR_PAG_HIST, p_offset: mostrados });
        var hm = $('#histMais'); if (hm) hm.remove();
        var novos = (p.data && p.data.itens) || [];
        mostrados += novos.length; if (!novos.length) r.total = mostrados;
        L.insertAdjacentHTML('beforeend', novos.map(linha).join('') + mais());
        return;
      }
      if (a) { var x = await sb.from('evolui_buscas').select('resultado,criado_em,termo').eq('id', a.dataset.abrir).maybeSingle(); if (x.data && x.data.resultado) ir('buscar', { resultado: x.data.resultado, salvoEm: x.data.criado_em }); else if (x.data) ir('buscar', { termo: x.data.termo }); }
      if (d) { var y = await sb.from('evolui_buscas').delete().eq('id', d.dataset.apagar); if (!y.error) { d.closest('.item').remove(); toast('Pesquisa apagada do histórico.'); } }
    };
  }
  async function listaAcoes() {
    var L = $('#lista');
    await catalogoObjetivos().catch(function () {});
    var r = await sb.from('evolui_ctas').select('*').order('criado_em', { ascending: false }).limit(60);
    if (!$('#lista')) return;
    if (r.error) { L.innerHTML = '<p class="muted">Não foi possível carregar.</p>'; return; }
    if (!r.data.length) { L.innerHTML = '<div class="vazio"><h3>Nenhuma ação ainda</h3><p>Escolha um objetivo na tela inicial e receba o que fazer agora.</p><button class="btn cta" id="ir2">Escolher objetivo</button></div>'; $('#ir2').onclick = function () { ir('buscar'); }; return; }
    var lista = r.data;
    L.innerHTML = lista.map(function (c) {
      var fechado = c.status === 'concluido' || c.status === 'descartado';
      return '<div class="item" data-id="' + esc(c.id) + '"><div style="min-width:0"><div class="t">' + esc(c.titulo) + '</div><div class="d">' + esc(rotuloObjetivo(c.objetivo_chave)) + ' · ' + dataHora(c.criado_em) + ' <span class="pill cta-' + esc(c.status) + '">' + esc(CTA_STATUS[c.status] || '') + '</span></div></div>' +
        '<div class="acoes"><button class="btn sm" data-abrir-cta="' + esc(c.id) + '">Abrir</button>' + (fechado ? '' : '<button class="btn sm cta" data-concluir="' + esc(c.id) + '">Concluí</button><button class="btn sm ghost" data-descartar="' + esc(c.id) + '">Descartar</button>') + '</div></div>';
    }).join('');
    L.onclick = function (e) {
      var a = e.target.closest('[data-abrir-cta]'), k = e.target.closest('[data-concluir]'), d = e.target.closest('[data-descartar]');
      var achar = function (id) { return lista.filter(function (x) { return x.id === id; })[0]; };
      if (a) ir('buscar', { cta: achar(a.dataset.abrirCta) });
      if (k) statusCta(achar(k.dataset.concluir), 'concluido', k);
      if (d) statusCta(achar(d.dataset.descartar), 'descartado', d);
    };
  }
  async function listaSalvos() {
    var L = $('#lista');
    var r = await sb.from('evolui_salvos').select('*').order('criado_em', { ascending: false }).limit(100);
    if (!$('#lista')) return;
    if (r.error) { L.innerHTML = '<p class="muted">Não foi possível carregar.</p>'; return; }
    if (!r.data.length) { L.innerHTML = '<div class="vazio"><h3>Nada salvo ainda</h3><p>Nas pesquisas, toque em "Salvar ideia" ou "Salvar tendência".</p></div>'; return; }
    L.innerHTML = r.data.map(function (s) {
      var ideia = s.tipo === 'ideia' && s.dados && s.dados.ideia;
      return '<div class="card" style="gap:10px"><div class="entre"><span class="kicker">' + (s.tipo === 'ideia' ? 'Ideia · ' + esc((s.dados && s.dados.termo) || '') : 'Tendência') + ' · ' + data(s.criado_em) + '</span><button class="btn sm ghost perigo" data-apagar="' + esc(s.id) + '" aria-label="Apagar">✕</button></div>' +
        '<b>' + esc(s.titulo) + '</b>' + (ideia ? '<div class="caixa-legenda" id="s' + esc(s.id) + '">' + esc(ideia.legenda) + '</div><div class="linha"><button class="btn sm cta" data-copiar="' + esc(s.id) + '">Copiar legenda</button></div>' : (s.dados && s.dados.rotulo ? '<span class="pill e-' + esc(s.dados.estado) + '" style="align-self:flex-start">' + esc(s.dados.rotulo) + '</span><button class="btn sm" data-ver="' + esc(s.titulo) + '" style="align-self:flex-start">Pesquisar de novo</button>' : '')) + '</div>';
    }).join('');
    L.onclick = async function (e) {
      var c = e.target.closest('[data-copiar]'), d = e.target.closest('[data-apagar]'), v = e.target.closest('[data-ver]');
      if (c) { var it = r.data.find(function (x) { return x.id === c.dataset.copiar; }); copiar(it.dados.ideia.legenda, $('#s' + it.id), it.dados.ideia.formato); }
      if (v) ir('buscar', { termo: v.dataset.ver });
      if (d) { var y = await sb.from('evolui_salvos').delete().eq('id', d.dataset.apagar); if (!y.error) { d.closest('.card').remove(); toast('Removido.'); } }
    };
  }

  // ---------------------------------------------------------------- laboratório A/B
  var CTA_RE = /(whats|wpp|link|chame|chama|peça|peca|pedido|agende|agenda|compre|comprar|encomend|dm|direct|comente|salve|clique|toque|reserve|garanta|fale|orçamento|orcamento)/i;
  var EMOJI_RE = /\p{Extended_Pictographic}/gu;
  function analisar(tipo, texto) {
    texto = String(texto || ''); var t = texto.trim();
    var p = st.perfil || {}, chaves = [];
    if (p.cidade) chaves.push(p.cidade); if (p.ramo_detalhe) chaves = chaves.concat(p.ramo_detalhe.split(/\s+/).filter(function (w) { return w.length > 4; }));
    if (p.ramo && RAMO[p.ramo]) chaves = chaves.concat(RAMO[p.ramo][1].split(/\s+/).filter(function (w) { return w.length > 4; }));
    var temChave = chaves.some(function (k) { return norm(t).indexOf(norm(k).slice(0, Math.max(4, k.length - 1))) >= 0; });
    var emojis = (t.match(EMOJI_RE) || []).length, hashtags = (t.match(/#[\wÀ-ú]+/g) || []).length, linhas = t.split(/\n/).filter(Boolean);
    var palavras = t.split(/\s+/).filter(Boolean), media = palavras.length ? palavras.join('').length / palavras.length : 0;
    var R = [];
    if (tipo === 'bio') {
      R.push([t.length > 0 && t.length <= 150, 20, t.length > 150 ? 'Passou de 150 caracteres: o Instagram corta (' + t.length + ').' : 'Até 150 caracteres (' + t.length + ').']);
      R.push([t.length >= 40, 10, 'Tem informação suficiente (mínimo de 40 caracteres).']);
      R.push([CTA_RE.test(t), 20, 'Diz como comprar ou falar com você (WhatsApp, link, agende…).']);
      R.push([temChave, 20, 'Fala o seu ramo ou a sua cidade, para quem chega entender na hora.']);
      R.push([linhas.length >= 2 || /[·|•]/.test(t), 10, 'Organizada em linhas ou separadores.']);
      R.push([emojis >= 1 && emojis <= 4, 10, 'Usa de 1 a 4 emojis como marcadores.']);
      R.push([media <= 7.5, 10, 'Palavras simples e curtas.']);
    } else {
      var l1 = (linhas[0] || '');
      R.push([l1.length > 0 && l1.length <= 90, 20, 'A primeira linha é curta (gancho de até 90 caracteres).']);
      R.push([/[?!]/.test(l1) || /^(\d|como|por que|pare|nunca|segredo|3|5)/i.test(l1.trim()), 10, 'A primeira linha provoca curiosidade (pergunta, número ou exclamação).']);
      R.push([CTA_RE.test(t), 20, 'Termina com uma chamada para ação (comente, salve, peça…).']);
      R.push([t.length >= 80 && t.length <= 1200, 15, 'Tamanho bom para ler no celular (80 a 1.200 caracteres).']);
      R.push([linhas.length >= 3, 10, 'Tem respiros: pelo menos 3 linhas.']);
      R.push([hashtags === 0 || (hashtags >= 3 && hashtags <= 8), 10, hashtags ? 'De 3 a 8 hashtags (' + hashtags + ').' : 'Sem hashtags (tudo bem, mas 3 a 8 do seu nicho ajudam a ser achado).']);
      R.push([emojis <= 6, 5, 'Emojis com moderação (até 6).']);
      R.push([temChave, 10, 'Cita o seu ramo ou a sua cidade.']);
    }
    var nota = R.reduce(function (s, x) { return s + (x[0] ? x[1] : 0); }, 0);
    return { nota: t ? Math.min(100, nota) : 0, itens: R.map(function (x) { return { ok: !!x[0], txt: x[2] }; }) };
  }
  function blocoAnalise(a) {
    return '<div class="nota"><span class="num">' + a.nota + '</span><span class="medidor"><i style="width:' + a.nota + '%"></i></span></div><ul class="check">' + a.itens.map(function (i) { return '<li class="' + (i.ok ? '' : 'nao') + '">' + esc(i.txt) + '</li>'; }).join('') + '</ul>';
  }
  // ---------------------------------------------------------------- Video Intelligence Pro/Master
  function videoProBloco(box) {
    if (!box) return;
    var pl = plano();
    if (pl !== 'pro' && pl !== 'master') {
      box.innerHTML = '<section class="card lab-video-card lab-video-locked"><div class="lab-video-head"><div><span class="kicker">PRO · MASTER</span><h2 style="margin:4px 0 0">Entenda o seu vídeo</h2><p class="sub">Cole um link e a Evolui transforma o conteúdo em descrição, sinais e novas ideias para o Laboratório.</p></div><span class="lab-video-orb">✦</span></div><button class="btn cta" type="button" id="labVideoUpgrade">Liberar análise de vídeo</button></section>';
      $('#labVideoUpgrade', box).onclick = function () { abrirPlanos('laboratorio_video', 'pro'); };
      return;
    }
    box.innerHTML = '<section class="card lab-video-card"><div class="lab-video-head"><div><span class="kicker">INTELIGÊNCIA DE VÍDEO</span><h2 style="margin:4px 0 0">Analise um vídeo</h2><p class="sub">A Evolui identifica o tema, gancho, estrutura e elementos visuais e usa isso para sugerir o próximo conteúdo.</p></div><span class="lab-video-orb" aria-hidden="true">✦</span></div>' +
      '<div class="linha lab-video-input"><input id="labVideoUrl" type="url" maxlength="600" placeholder="Cole o link do YouTube, TikTok ou Instagram" aria-label="Link do vídeo"><button class="btn cta" type="button" id="labVideoGo">Analisar vídeo</button></div>' +
      '<p class="muted" id="labVideoStatus" style="font-size:13px;margin:0">Disponível no Pro e Master. A Evolui lê fala, cenas, ritmo e estrutura com o seu próprio motor de inteligência de vídeo.</p>' +
      '<div id="labVideoResult"></div></section>';
    async function analisar() {
      var url = $('#labVideoUrl', box).value.trim(), btn = $('#labVideoGo', box), stt = $('#labVideoStatus', box), out = $('#labVideoResult', box);
      if (!url) return toast('Cole o link do vídeo primeiro.');
      btn.disabled = true; btn.textContent = 'Analisando…'; stt.textContent = 'Lendo o vídeo e cruzando o conteúdo com o contexto da Evolui…'; out.innerHTML = '<div class="lab-video-loading"><i></i><span>Interpretando conteúdo</span><i></i><span>Extraindo sinais</span><i></i><span>Gerando ideias</span></div>';
      try {
        var r = await E.api('analisar_video_pro', { url: url });
        if (r.configuracao_pendente) throw new Error('A ferramenta de análise de vídeo ainda não foi conectada ao servidor de inferência.');
        if (!r.analise) throw new Error(r.erro || 'Não foi possível analisar este vídeo.');
        var a = r.analise, ideias = Array.isArray(r.ideias) ? r.ideias : [];
        out.innerHTML = '<div class="lab-video-analysis"><div class="lab-video-summary"><span class="ref-source-pill">' + esc(a.plataforma || 'Vídeo') + '</span><span class="ref-growth">confiança ' + Math.round((a.confianca || 0) * 100) + '%</span><h3>' + esc(a.titulo || a.tema || 'Leitura do vídeo') + '</h3><p>' + esc(a.descricao) + '</p></div>' +
          '<div class="lab-video-grid"><div><span class="kicker">TEMA</span><b>' + esc(a.tema || 'Não identificado') + '</b></div><div><span class="kicker">GANCHO</span><b>' + esc(a.gancho || 'Não identificado') + '</b></div><div><span class="kicker">CTA</span><b>' + esc(a.cta || 'Não identificado') + '</b></div></div>' +
          (a.elementosVisuais && a.elementosVisuais.length ? '<div class="lab-video-list"><span class="kicker">ELEMENTOS VISUAIS</span><div class="lab-video-tags">' + a.elementosVisuais.map(function (x) { return '<span>' + esc(x) + '</span>'; }).join('') + '</div></div>' : '') +
          (a.dna && a.dna.formato_estrutural ? '<div class="lab-video-list evi-video-dna"><div class="entre"><div><span class="kicker">EVI · DNA DO CONTEÚDO</span><h3 style="margin:3px 0 0">Estrutura identificada</h3></div><span class="pill">evi-dna-v1</span></div><p class="muted" style="margin:8px 0 0;line-height:1.6">' + esc(a.dna.formato_estrutural) + '</p><div class="lab-video-tags">' + [a.ritmo && a.ritmo.classificacao ? 'ritmo: ' + a.ritmo.classificacao : '', a.eviScore && a.eviScore.score != null ? 'adequação estrutural: ' + a.eviScore.score : '', a.impressaoDigital ? 'impressão: ' + a.impressaoDigital : '', a.ajusteContextualObservavel && a.ajusteContextualObservavel.nivel ? 'contexto: ' + a.ajusteContextualObservavel.nivel : '', a.transcricao ? 'transcrição contextual' : 'sem transcrição'].filter(Boolean).map(function (x) { return '<span>' + esc(x) + '</span>'; }).join('') + '</div></div>' : '') +
          (a.lacunas && a.lacunas.length ? '<div class="lab-video-list"><span class="kicker">LACUNAS OBSERVADAS</span><div class="lab-video-tags">' + a.lacunas.slice(0, 5).map(function (x) { return '<span>' + esc(x.descricao || x.tipo || '') + '</span>'; }).join('') + '</div></div>' : '') +
          (a.transcricao ? '<details class="lab-video-list"><summary><span class="kicker">TRANSCRIÇÃO</span></summary><p class="muted" style="margin:10px 0 0;line-height:1.65">' + esc(a.transcricao) + '</p></details>' : '') +
          '<div class="lab-video-ideas"><div class="entre"><div><span class="kicker">A PARTIR DESTE VÍDEO</span><h3 style="margin:3px 0 0">Ideias para continuar</h3></div><span class="pill">EVI + EIE + contexto</span></div>' +
          (ideias.length ? ideias.map(function (x, i) { return '<article class="lab-video-idea" data-video-idea="' + i + '"><div><span class="lab-video-rank">' + (i + 1) + '</span><div><b>' + esc(x.titulo) + '</b><p>' + esc(x.angulo) + ' · ' + esc(x.motivo) + '</p></div></div><button class="btn sm ghost" type="button" data-video-doc="' + i + '">Levar ao documento</button></article>'; }).join('') : '<p class="muted">Nenhuma ideia foi gerada a partir dos sinais disponíveis.</p>') + '</div></div>';
        stt.textContent = a.modo === 'video' ? 'Análise de vídeo concluída. As ideias foram contextualizadas pelo motor da Evolui.' : 'Leitura básica do link concluída.';
        $$('[data-video-doc]', box).forEach(function (b) { b.onclick = function () { var x = ideias[+b.dataset.videoDoc]; if (!x) return; docLab({ titulo: x.titulo, texto: x.titulo + '\n\nÂngulo: ' + x.angulo + '\n\nPor que explorar: ' + x.motivo, formato: x.formato || 'reel' }); }; });
      } catch (e) { out.innerHTML = ''; stt.textContent = ''; toast((e && e.message) || 'Não foi possível analisar agora.'); }
      btn.disabled = false; btn.textContent = 'Analisar vídeo';
    }
    $('#labVideoGo', box).onclick = analisar;
    $('#labVideoUrl', box).onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); analisar(); } };
  }

  function telaLab(extra) {
    if (extra && extra.novo) return formLab(st.labEditando || {});
    if (extra && extra.id) return detalheLab(extra.id);
    if (extra && extra.doc) return docLab(extra.doc === true ? { texto: (st.labEditando && (st.labEditando.versao_a || '')) || '', titulo: (st.labEditando && st.labEditando.titulo) || '', tipo: st.labEditando && st.labEditando.tipo } : extra.doc);
    $('#conteudo').innerHTML = '<div class="entre"><div><h1 class="tit">Laboratório</h1><p class="sub">Teste, analise e desenvolva conteúdo a partir do que você já publica.</p></div><div class="linha"><button class="btn" id="novoDoc">Novo documento</button><button class="btn cta" id="novo">Novo teste</button></div></div><div id="labVideoBox"></div><div id="labConta"></div><div class="lista-grade" id="labL"><p class="muted">Carregando…</p></div><h2 class="sec-tit" style="font-size:20px;margin-top:10px">Seus documentos</h2><div class="lista-grade" id="labDocs"><p class="muted">Carregando…</p></div>';
    $('#novo').onclick = function () { st.labEditando = null; formLab({}); };
    videoProBloco($('#labVideoBox'));
    $('#novoDoc').onclick = function () { docLab({}); };
    listaDocs($('#labDocs')); painelConta($('#labConta'));
    sb.from('evolui_lab_testes').select('id,tipo,titulo,nota_a,nota_b,vencedora,status,criado_em').order('criado_em', { ascending: false }).limit(50).then(function (r) {
      var L = $('#labL'); if (!L) return;
      if (r.error) { L.innerHTML = '<p class="muted">Não foi possível carregar.</p>'; return; }
      if (!r.data.length) { L.innerHTML = '<div class="vazio"><h3>Seu primeiro experimento</h3><p>Escreva duas versões da sua bio, veja a nota de cada uma e depois registre qual trouxe mais resultado.</p><button class="btn cta" id="novo2">Criar teste</button></div>'; $('#novo2').onclick = function () { formLab({ tipo: 'bio' }); }; return; }
      var STS = { rascunho: 'Rascunho', testando: 'Testando', concluido: 'Concluído' };
      L.innerHTML = r.data.map(function (x) {
        return '<button class="item" data-id="' + esc(x.id) + '" style="text-align:left;width:100%"><div style="min-width:0"><div class="t">' + esc(x.titulo || (x.tipo === 'bio' ? 'Teste de bio' : 'Teste de legenda')) + '</div><div class="d">' + (x.tipo === 'bio' ? 'Bio' : 'Legenda') + ' · ' + STS[x.status] + ' · A ' + (x.nota_a == null ? '—' : x.nota_a) + ' × B ' + (x.nota_b == null ? '—' : x.nota_b) + (x.vencedora ? ' · venceu ' + x.vencedora.toUpperCase() : '') + '</div></div><span class="muted">›</span></button>';
      }).join('');
      L.onclick = function (e) { var b = e.target.closest('[data-id]'); if (b) detalheLab(b.dataset.id); };
    });
  }
  // ---------------------------------------------------------------- referências do laboratório (Fase 2)
  // Consultas e ranking são algoritmo interno (referencias.js). Sem IA externa e sem raspagem: a pessoa cola o link,
  // a leitura usa oEmbed oficial. YouTube/Pinterest são fontes opcionais e passam pelo mesmo gateway seguro da evolui-api.
  var REF_ROT = { vista: 'Vista', selecionada: 'Selecionada', descartada: 'Descartada' };
  function refPersonaliza() { return !(st.perfil && st.perfil.personalizar === false); }
  function refSinal(estado, item, consulta) {
    var R = window.EvoluiReferencias; if (!R) return;
    var s = R.montarSinal(estado, item, consulta); if (s) registrar(s.tipo, s.dados); // registrar() já respeita personalizar
  }
  // monta o bloco "Referências" dentro do formulário. Devolve { vincular(testeId) } para ligar as referências ao teste salvo.
  function refBloco(box, lerCtx) {
    var R = window.EvoluiReferencias;
    if (!R) { box.innerHTML = '<p class="muted">As referências não carregaram. Atualize a página.</p>'; return { vincular: function () { return Promise.resolve(); } }; }
    R.limparProvedores(); R.registrarProvedor(R.provedorLink(function (acao, d) { return E.api(acao, d); }));
    R.registrarProvedor(R.provedorYoutube(function (acao, d) { return E.api(acao, d); }, true)); R.registrarProvedor(R.provedorPinterest(function (acao, d) { return E.api(acao, d); }, true)); // Pinterest usa Trends API oficial pelo mesmo gateway autenticado; indisponibilidade não derruba o Laboratório
    var refs = [], hist = [], carregou = false, consulta = null, aviso = '', autoStatus = '';
    function ctx() {
      var c = lerCtx(), p = st.perfil || {};
      return { perfil: { ramo: p.ramo, ramo_detalhe: p.ramo_detalhe, cidade: p.cidade, objetivo: p.objetivo, tipo_usuario: p.tipo_usuario, interesses: p.interesses, personalizar: p.personalizar },
        tema: c.tema, formato: c.formato, duracao: c.duracao, roteiro: c.roteiro, persona: p.tom || p.persona || '', preferencias: '' };
    }
    function desenhar() {
      var cons = R.construirConsultas(ctx()), cur = consulta && cons.some(function (q) { return q.texto === consulta.texto; }) ? consulta : (cons[0] || null);
      consulta = cur;
      var h = '<p class="sub" style="font-size:14px">Ache exemplos para se inspirar. Usamos só o que você informou aqui, sem IA externa. Os links abaixo abrem o site em outra aba.</p>' +
        '<div class="grade2"><div class="campo"><label for="rTema">Assunto do vídeo</label><input id="rTema" maxlength="120" value="' + esc(lerCtx().tema) + '"></div>' +
        '<div class="campo"><label for="rFmt">Formato</label><select id="rFmt">' + [['', 'Não sei'], ['reel', 'Reel'], ['stories', 'Stories'], ['carrossel', 'Carrossel']].map(function (o) { return '<option value="' + o[0] + '"' + (lerCtx().formato === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></div>' +
        '<div class="campo"><label for="rDur">Duração <span class="muted">(opcional)</span></label><input id="rDur" maxlength="20" placeholder="ex.: 20 segundos" value="' + esc(lerCtx().duracao) + '"></div></div>';
      h += '<h3 style="font-size:17px">Consultas sugeridas</h3>';
      if (!cons.length) h += '<div class="vazio"><p>Escreva o assunto do vídeo para ver consultas de busca.</p></div>';
      else h += '<ul class="check" style="gap:10px">' + cons.map(function (q, i) {
        var qs = encodeURIComponent(q.texto), qy = encodeURIComponent(q.texto + (q.enfase ? ' ' + q.enfase : ''));
        return '<li><div><b>' + esc(q.rotulo) + '</b><div class="muted" style="font-size:13px">Por que a Evolui sugere isso: ' + esc(q.porque) + '</div><div class="muted" style="font-size:13px">Busca: ' + esc(q.texto) + '</div>' +
          '<div class="linha" style="margin-top:6px"><button class="btn sm" type="button" data-rcons="' + i + '" aria-pressed="' + (cur && cur.texto === q.texto) + '">Usar para ordenar</button><button class="btn sm ghost" type="button" data-rcopia="' + i + '">Copiar</button>' +
          '<a class="btn sm ghost" target="_blank" rel="noopener noreferrer" href="https://www.youtube.com/results?search_query=' + qy + '">Ver exemplos no YouTube</a>' +
          '<a class="btn sm ghost" target="_blank" rel="noopener noreferrer" href="https://br.pinterest.com/search/pins/?q=' + qs + '">Procurar ideias no Pinterest</a></div></div></li>';
      }).join('') + '</ul>';
      h += '<h3 style="font-size:17px">Adicionar uma referência</h3><div class="linha"><input id="rUrl" type="url" maxlength="600" placeholder="Cole o link de um vídeo (YouTube ou TikTok)" aria-label="Link da referência" style="flex:1;min-width:220px"><button class="btn" type="button" id="rAdd">Adicionar</button></div>' +
        '<small class="erro-campo" id="rErro" role="status">' + esc(aviso) + '</small>';
      var sel = refs.filter(function (r) { return r.estado === 'selecionada'; }).map(function (r) { return { fonte: r.item.fonte, id_externo: r.item.id_externo, url: r.item.url, autor: r.item.autor, estado: 'selecionada' }; });
      var lista = R.ranquear(refs.filter(function (r) { return r.estado !== 'descartada'; }).map(function (r) { return r.item; }), cur, hist.filter(function (x) { return refs.every(function (r) { return R.chaveItem(r.item) !== R.chaveItem(x); }); }).concat(sel));
      var descartadas = refs.filter(function (r) { return r.estado === 'descartada'; }).length;
      h += '<h3 style="font-size:17px">Suas referências</h3>';
      if (autoStatus) h += '<div class="ref-auto-status" role="status"><span class="ref-auto-dot" aria-hidden="true"></span><span>' + esc(autoStatus) + '</span></div>';
      if (!lista.length && !descartadas) h += '<div class="vazio"><p>Nenhuma referência ainda. Cole um link acima para guardar.</p></div>';
      else if (!lista.length) h += '<p class="muted">Todas as referências foram descartadas.</p>';
      else h += '<div class="lista-grade ref-insp-grade">' + lista.map(function (it) {
        var r = refs.filter(function (x) { return R.chaveItem(x.item) === R.chaveItem(it); })[0]; if (!r) return '';
        var pin = it.fonte === 'pinterest';
        var crescimento = pin && it.crescimento_wow != null ? (it.crescimento_wow > 0 ? '+' : '') + it.crescimento_wow + '% WoW' : '';
        var porquePin = pin ? ('Sinal do Pinterest' + (crescimento ? ' · ' + crescimento : '') + (it.afinidade_termos && it.afinidade_termos.length ? ' · combina com ' + it.afinidade_termos.join(', ') : '')) : '';
        return '<article class="item ref-insp-card' + (pin ? ' ref-pin-card' : '') + '" style="align-items:flex-start;gap:12px">' +
          (pin ? '<div class="ref-pin-visual" aria-hidden="true"><span class="ref-pin-p">P</span><i></i><b></b></div>' : (urlSegura(it.miniatura_url) ? '<img src="' + esc(it.miniatura_url) + '" alt="" width="96" height="54" loading="lazy" referrerpolicy="no-referrer" style="border-radius:14px;object-fit:cover;flex:none">' : '')) +
          '<div style="min-width:0;flex:1"><div class="ref-insp-top"><span class="ref-source-pill' + (pin ? ' pinterest' : '') + '">' + (pin ? 'Pinterest' : esc(it.fonte || 'Referência')) + '</span>' + (crescimento ? '<span class="ref-growth">' + esc(crescimento) + '</span>' : '') + '</div>' +
          '<div class="t">' + esc(it.titulo || it.url) + '</div><div class="d">' + esc(it.autor || 'Autor não informado') + ' · <span class="pill">' + esc(REF_ROT[r.estado]) + '</span> · afinidade ' + it.score + '</div>' +
          '<div class="muted ref-insp-why">' + esc(pin ? porquePin : (it.porque || []).join(' ')) + '</div>' +
          (pin ? '<div class="ref-score-wrap"><div class="ref-score-line"><span>Relevância contextual</span><b>' + Math.max(0, Math.min(100, Number(it.score) || 0)) + '/100</b></div><div class="ref-score-track" aria-hidden="true"><i style="--ref-score:' + Math.max(0, Math.min(100, Number(it.score) || 0)) + '%"></i></div></div>' : '') +
          (it.aviso ? '<div class="muted" style="font-size:13px">' + esc(it.aviso) + '</div>' : '') +
          '<div class="linha" style="margin-top:8px"><a class="btn sm' + (pin ? ' cta' : ' ghost') + '" target="_blank" rel="noopener noreferrer" href="' + esc(urlSegura(it.url) || '#') + '">' + (pin ? 'Ver inspiração' : 'Abrir') + '</a>'
          '<button class="btn sm" type="button" data-rest="selecionada" data-ridx="' + refs.indexOf(r) + '"' + (r.estado === 'selecionada' ? ' disabled' : '') + '>Selecionar</button>' +
          '<button class="btn sm ghost perigo" type="button" data-rest="descartada" data-ridx="' + refs.indexOf(r) + '">Descartar</button></div></div></article>';
      }).join('') + '</div>' + (descartadas ? '<p class="muted" style="font-size:13px">' + descartadas + ' descartada(s) escondida(s).</p>' : '');
      box.innerHTML = h; ligar(cons);
    }
    function reler() { var c = lerCtx(); c.tema = $('#rTema', box).value; c.formato = $('#rFmt', box).value; c.duracao = $('#rDur', box).value; return c; }
    function ligar(cons) {
      ['#rTema', '#rFmt', '#rDur'].forEach(function (id) { $(id, box).onchange = function () { box.dispatchEvent(new CustomEvent('refctx', { detail: reler() })); }; });
      $$('[data-rcons]', box).forEach(function (b) { b.onclick = function () { consulta = cons[+b.dataset.rcons]; desenhar(); buscarAutomaticas(); }; });
      $$('[data-rcopia]', box).forEach(function (b) { b.onclick = function () { copiar(cons[+b.dataset.rcopia].rotulo, null); }; });
      $('#rAdd', box).onclick = adicionar;
      $('#rUrl', box).onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); adicionar(); } };
      $$('[data-rest]', box).forEach(function (b) { b.onclick = function () { mudar(refs[+b.dataset.ridx], b.dataset.rest); }; });
    }
    async function persistir(r, estado) {
      var linha = R.montarLinha(r.item, estado, { client_id: null, teste_id: r.teste_id || null }, consulta && consulta.texto);
      if (r.id) { var u = await sb.from('evolui_lab_referencias').update({ estado: estado }).eq('id', r.id); return !u.error; }
      linha.user_id = st.user.id;
      var i = await sb.from('evolui_lab_referencias').insert(linha).select('id').single();
      if (i.error) return false; r.id = i.data.id; return true;
    }
    async function mudar(r, estado) {
      if (!r || r.estado === estado) return;
      if (!(await persistir(r, estado))) { toast('Não foi possível salvar a referência.'); return; }
      r.estado = estado; refSinal(estado, r.item, consulta); desenhar(); box.dispatchEvent(new CustomEvent('refestado'));
    }
    async function adicionar() {
      var url = $('#rUrl', box).value.trim(), btn = $('#rAdd', box);
      if (!url) { aviso = 'Cole um link primeiro.'; return desenhar(); }
      btn.disabled = true; aviso = '';
      try {
        var its = await R.obterProvedor('link').buscar({ url: url });
        if (!its.length) aviso = 'Não consegui ler esse link. Use um link https de vídeo (YouTube ou TikTok).';
        else {
          var it = its[0], k = R.chaveItem(it);
          if (refs.some(function (r) { return R.chaveItem(r.item) === k; })) aviso = 'Essa referência já está na lista.';
          else {
            var antiga = hist.filter(function (h) { return R.chaveItem(h) === k; })[0];
            var novo = { item: it, estado: 'vista', id: null, teste_id: null };
            if (!(await persistir(novo, 'vista'))) aviso = 'Não foi possível salvar a referência agora.';
            else { refs.push(novo); refSinal('vista', it, consulta); if (antiga && antiga.estado === 'descartada') aviso = 'Você já tinha descartado esta referência antes.'; }
          }
        }
      } catch (e) { aviso = (e && e.message) || 'Não foi possível ler o link agora.'; }
      desenhar(); box.dispatchEvent(new CustomEvent('refestado'));
    }
    var buscaAutoSeq = 0;
    async function buscarAutomaticas() {
      var seq = ++buscaAutoSeq, cons = R.construirConsultas(ctx()), cur = consulta && cons.some(function (q) { return q.texto === consulta.texto; }) ? consulta : (cons[0] || null);
      consulta = cur;
      if (!cur) { autoStatus = ''; return; }
      var ativos = R.provedoresAtivos().filter(function (p) { return p.id === 'pinterest' || p.id === 'youtube'; });
      var pinAtivo = ativos.some(function (p) { return p.id === 'pinterest'; });
      if (!ativos.length) { autoStatus = ''; return; }
      autoStatus = pinAtivo ? 'Cruzando sua busca com sinais recentes do Pinterest e referências em vídeo…' : 'Buscando referências complementares…';
      desenhar();
      try {
        var its = await R.buscarReferencias(cur, { provedores: ativos, limites: { maxItens: 6, timeoutMs: 7000, cacheSeg: 900 } });
        if (seq !== buscaAutoSeq) return;
        its.forEach(function (it) {
          var k = R.chaveItem(it);
          if (!refs.some(function (r) { return R.chaveItem(r.item) === k; })) refs.push({ item: it, estado: 'vista', id: null, teste_id: null, automatico: true });
        });
        var pins = its.filter(function (it) { return it.fonte === 'pinterest'; }).length;
        autoStatus = pinAtivo ? (pins ? 'A Evolui encontrou ' + pins + (pins === 1 ? ' sinal do Pinterest' : ' sinais do Pinterest') + ' relevante(s) para esta busca.' : 'Nenhum sinal do Pinterest passou pelo corte de relevância desta busca.') : (its.length ? 'Referências complementares encontradas.' : 'Nenhuma referência complementar encontrada agora.');
        desenhar();
      } catch (e) {
        if (seq !== buscaAutoSeq) return;
        autoStatus = 'As fontes opcionais estão indisponíveis neste momento. Suas referências manuais continuam funcionando.';
        desenhar();
      }
    }
    async function iniciar() {
      if (!carregou) {
        carregou = true; box.innerHTML = '<p class="muted">Carregando…</p>';
        var r = await sb.from('evolui_lab_referencias').select('fonte,id_externo,url,autor,estado').order('criado_em', { ascending: false }).limit(200);
        hist = r.error ? [] : (r.data || []);
      }
      desenhar();
      buscarAutomaticas();
    }
    return {
      abrir: iniciar,
      contexto: function () { return ctx(); },
      estados: function () { return refs.map(function (r) { return r.estado; }); },
      vincular: async function (testeId) {
        var ids = refs.filter(function (r) { return r.id; }).map(function (r) { return r.id; });
        if (ids.length) await sb.from('evolui_lab_referencias').update({ teste_id: testeId }).in('id', ids);
      }
    };
  }
  // ---------------------------------------------------------------- Memória visível (Prompt 03)
  // Três níveis: observada (peso baixo, meia-vida 30 dias) · hipótese (a Evolui pergunta) · confirmada pelo usuário (peso maior).
  // Aprendizados de experimentos ficam em evolui_aprendizados: nivel 'hipotese' (regra) até o usuário confirmar ('conclusao', usuario).
  async function prefSalvar(mut, tipo, id) {
    var cfg = copCfg(); mut(cfg);
    var prefs = Object.assign({}, st.perfil.preferencias || {}, { copiloto: { confirmadas: cfg.confirmadas, removidas: cfg.removidas } });
    var x = await sb.from('evolui_perfis').update({ preferencias: prefs }).eq('id', st.user.id);
    if (x.error) { toast('Não foi possível salvar.'); return false; }
    st.perfil.preferencias = prefs; st.copInf = null; copSinal(tipo, { pref: id }); return true;
  }
  function semItem(l, id) { return l.filter(function (v) { return v !== id; }); }
  async function aprendizadosAtivos(lim) {
    try { var r = await sb.from('evolui_aprendizados').select('id,nivel,padrao,resultado,observacao,criado_em').eq('ativo', true).not('padrao', 'is', null).order('criado_em', { ascending: false }).limit(lim || 20); return r.error ? [] : (r.data || []); }
    catch (e) { return []; }
  }
  async function aprendizadoAcao(id, acao, texto) {
    var x;
    if (acao === 'apagar') x = await sb.from('evolui_aprendizados').delete().eq('id', id);
    else if (acao === 'confirmar') x = await sb.from('evolui_aprendizados').update({ nivel: 'conclusao', gerado_por: 'usuario', atualizado_em: new Date().toISOString() }).eq('id', id);
    else x = await sb.from('evolui_aprendizados').update({ padrao: String(texto || '').slice(0, 300), nivel: 'conclusao', gerado_por: 'usuario', atualizado_em: new Date().toISOString() }).eq('id', id);
    if (x.error) { toast('Não foi possível salvar.'); return false; }
    registrar(acao === 'apagar' ? 'pref_removida' : 'pref_confirmada', { tipo: 'aprendizado' });
    return true;
  }
  var NIVEL_APR = { hipotese: 'Hipótese (ainda não confirmada)', conclusao: 'Confirmado por você', sinal: 'Sinal', fato: 'Fato', correlacao: 'Padrão observado' };
  async function painelMemoria(box) {
    if (!box) return;
    var p = st.perfil || {}, ramo = RAMO[p.ramo], obj = (OBJ.filter(function (o) { return o[0] === p.objetivo; })[0] || [])[1];
    var decl = [];
    if (ramo) decl.push('Você trabalha com <b>' + esc(ramo[1].toLowerCase()) + '</b>.');
    if (p.cidade) decl.push('Seu negócio fica em <b>' + esc(p.cidade) + (p.uf ? '/' + esc(p.uf) : '') + '</b>.');
    if (obj) decl.push('Seu objetivo agora é <b>' + esc(obj.toLowerCase()) + '</b>.');
    var apr = (p.personalizar === false) ? [] : await aprendizadosAtivos(20);
    if (!$('#memBox')) return;
    box.innerHTML = '<p class="sub" style="font-size:14px">Tudo aqui é visível, editável e apagável. Um clique ou uma pesquisa isolada nunca vira preferência: primeiro é observação, depois hipótese, e só vale com peso maior quando você confirma.</p>' +
      '<div class="aprendi"><h4 style="margin:0">O que você nos contou</h4>' + (decl.length ? decl.map(function (d) { return '<div class="aprendi-item"><p>' + d + '</p></div>'; }).join('') : '<p class="muted">Ainda não temos o seu ramo. <button class="link-btn" data-mem-perfil>Completar perfil</button></p>') +
      (decl.length ? '<div><button class="btn sm ghost" type="button" data-mem-perfil>Corrigir meu perfil</button></div>' : '') +
      '<h4 style="margin:8px 0 0">O que aprendemos com os seus experimentos</h4>' +
      (p.personalizar === false ? '<p class="muted">A personalização está desligada: não guardamos aprendizados.</p>' :
        apr.length ? apr.map(function (a) {
          return '<div class="aprendi-item' + (a.nivel === 'hipotese' ? ' hip' : '') + '" data-apr="' + esc(a.id) + '"><div style="flex:1;min-width:200px"><span class="pill">' + esc(NIVEL_APR[a.nivel] || a.nivel) + '</span><p style="margin:6px 0 0">' + esc(a.padrao) + '</p></div><div class="linha">' +
            (a.nivel === 'hipotese' ? '<button class="btn sm" type="button" data-apr-conf>Confirmar</button>' : '') + '<button class="btn sm ghost" type="button" data-apr-corr>Corrigir</button><button class="btn sm ghost" type="button" data-apr-apa>Apagar</button></div></div>';
        }).join('') : '<p class="muted">Ainda não há aprendizados. Eles aparecem quando você conclui um teste A/B e escolhe guardar o que observou.</p>') + '</div>';
    box.onclick = async function (e) {
      if (e.target.closest('[data-mem-perfil]')) { abrirOnboarding(true); return; }
      var it = e.target.closest('[data-apr]'); if (!it) return; var id = it.dataset.apr;
      if (e.target.closest('[data-apr-apa]')) { if (await aprendizadoAcao(id, 'apagar')) { toast('Apagado.'); painelMemoria(box); } }
      else if (e.target.closest('[data-apr-conf]')) { if (await aprendizadoAcao(id, 'confirmar')) { toast('Confirmado. Agora pesa mais nas sugestões.'); painelMemoria(box); } }
      else if (e.target.closest('[data-apr-corr]')) {
        var a = apr.filter(function (x) { return x.id === id; })[0]; if (!a) return;
        it.innerHTML = '<div class="campo" style="flex:1"><label>Corrija com as suas palavras</label><textarea maxlength="300" id="aprTxt">' + esc(a.padrao) + '</textarea></div><div class="linha"><button class="btn sm cta" type="button" data-apr-sv>Salvar</button></div>';
        $('[data-apr-sv]', it).onclick = async function () { var t = $('#aprTxt', it).value.trim(); if (t.length < 5) return toast('Escreva um pouco mais.'); if (await aprendizadoAcao(id, 'corrigir', t)) { toast('Corrigido e confirmado por você.'); painelMemoria(box); } };
      }
    };
  }
  // Home: o que já aprendemos (só o que foi confirmado, mais uma pergunta de confirmação por vez)
  async function memoriaHomeHtml() {
    var r = null; try { r = await copPrefs(); } catch (e) { r = null; }
    var apr = await aprendizadosAtivos(6), h = [];
    var conf = r ? (r.ativas || []).filter(function (p) { return p.origem === 'confirmada'; }) : [];
    var pend = r ? (r.ativas || []).filter(function (p) { return p.origem !== 'confirmada'; })[0] : null;
    apr.filter(function (a) { return a.nivel === 'conclusao'; }).slice(0, 2).forEach(function (a) { conf.push({ rotulo: a.padrao, aprendizado: true }); });
    if (conf.length) h.push(cartoes(conf.slice(0, 3).map(function (p) { return { type: 'aprendizado', title: p.aprendizado ? 'Aprendizado confirmado' : 'Você confirmou', description: p.rotulo, tags: ['Confirmado por você'] }; })));
    if (pend) h.push('<div class="aprendi-item hip" data-pend="' + esc(pend.id) + '"><p>Observei: <b>' + esc(pend.rotulo) + '</b>. <span class="muted">' + esc(pend.porque) + '</span> Faz sentido?</p><div class="linha"><button class="btn sm cta" type="button" data-hconf>Faz sentido</button><button class="btn sm ghost" type="button" data-hnao>Não é isso</button></div></div>');
    var hip = apr.filter(function (a) { return a.nivel === 'hipotese'; })[0];
    if (hip) h.push('<div class="aprendi-item hip" data-apr="' + esc(hip.id) + '"><p>Do seu último experimento (hipótese, não é certeza): <b>' + esc(hip.padrao) + '</b></p><div class="linha"><button class="btn sm" type="button" data-apr-conf>Confirmar</button><button class="btn sm ghost" type="button" data-apr-apa>Apagar</button></div></div>');
    return h.join('');
  }

  function formLab(v) {
    var tipo = v.tipo || 'bio';
    $('#conteudo').innerHTML = '<div><button class="btn ghost sm" id="voltar">‹ Voltar</button><h1 class="tit">Novo teste</h1><p class="sub">A nota é uma checagem de boas práticas, não uma previsão. Quem decide é o resultado real.</p></div>' +
      '<div id="cop"></div><div id="labVideoFormBox"></div><div class="segmentos" role="group" aria-label="Tipo"><button data-tipo="bio" aria-pressed="' + (tipo === 'bio') + '">Bio</button><button data-tipo="legenda" aria-pressed="' + (tipo === 'legenda') + '">Legenda</button></div>' +
      '<div class="campo" style="max-width:720px"><label for="lTit">Nome do teste</label><input id="lTit" maxlength="80" placeholder="ex.: Bio com WhatsApp × bio com link" value="' + esc(v.titulo || '') + '"></div>' +
      '<div class="campo" style="max-width:720px"><label for="lHip">Hipótese <span class="muted">(opcional)</span></label><input id="lHip" maxlength="200" placeholder="ex.: um gancho mais específico pode aumentar a retenção" value="' + esc(v.hipotese || '') + '"></div>' +
      '<div class="ab"><div class="card ab-card ab-card-a"><div class="ab-card-head"><span class="kicker">CAMINHO A</span><b>Primeira abordagem</b><small>Use a versão mais natural para você.</small></div><div class="campo"><label for="lA">Versão A</label><textarea id="lA" maxlength="2200">' + esc(v.versao_a || '') + '</textarea></div><div><button class="btn sm ghost" type="button" data-doc="lA">Editar no Documento</button></div><div id="aA"></div></div>' +
      '<div class="card ab-card ab-card-b"><div class="ab-card-head"><span class="kicker">CAMINHO B</span><b>Outra hipótese</b><small>Mude uma variável para descobrir o que responde melhor.</small></div><div class="campo"><label for="lB">Versão B</label><textarea id="lB" maxlength="2200">' + esc(v.versao_b || '') + '</textarea></div><div><button class="btn sm ghost" type="button" data-doc="lB">Editar no Documento</button></div><div id="aB"></div></div></div>' +
      '<details class="card mais" id="refDet"><summary>Referências para inspirar este teste</summary><div id="refBox" style="display:flex;flex-direction:column;gap:12px;margin-top:8px"></div></details>' +
      '<div class="linha"><button class="btn cta" id="lSalvar">Salvar e começar o teste</button><span class="erro-campo" id="lErro"></span></div>';
    var cur = tipo, cop = null;
    videoProBloco($('#labVideoFormBox'));
    function atual() { $('#aA').innerHTML = blocoAnalise(analisar(cur, $('#lA').value)); $('#aB').innerHTML = blocoAnalise(analisar(cur, $('#lB').value)); if (cop) cop.agendar(); }
    $$('[data-tipo]').forEach(function (b) { b.onclick = function () { cur = b.dataset.tipo; $$('[data-tipo]').forEach(function (o) { o.setAttribute('aria-pressed', o === b); }); atual(); }; });
    $('#lA').oninput = atual; $('#lB').oninput = atual; $('#lTit').addEventListener('input', function () { if (cop) cop.agendar(); }); atual();
    var refCtx = { formato: v.formato || '', duracao: v.duracao || '', tema: null };
    var refs = null;
    function lerRefCtx() { return { tema: refCtx.tema != null ? refCtx.tema : ($('#lTit').value || '').trim(), formato: refCtx.formato, duracao: refCtx.duracao, roteiro: ($('#lA').value || '') + ' ' + ($('#lB').value || '') }; }
    $('#refBox').addEventListener('refctx', function (e) { refCtx.tema = e.detail.tema; refCtx.formato = e.detail.formato; refCtx.duracao = e.detail.duracao; if (refs) refs.abrir(); });
    $('#refDet').addEventListener('toggle', function () { if (this.open && !refs) { refs = refBloco($('#refBox'), lerRefCtx); refs.abrir(); } });
    $('#refBox').addEventListener('refestado', function () { if (cop) cop.agendar(0); });
    if (v.abrirRef) $('#refDet').open = true; // veio do copiloto do Documento
    cop = copFaixa($('#cop'), { tela: 'lab_form', conteudo: 'form', entrada: function () {
      var pp = st.perfil || {};
      return { perfil: pp, tom: pp.tom || pp.persona || '', objetivo: pp.objetivo || '', formato: cur === 'bio' ? 'bio' : 'legenda', tema: ($('#lTit').value || '').trim(), doc: { texto: $('#lA').value },
        referencias: refs ? refs.estados() : [], teste: { rascunho: { a: $('#lA').value, b: $('#lB').value } } };
    }, fazer: function (a) {
      if (a.tipo === 'focar') { var el = $('#' + a.alvo); if (el) copRolar(el); }
      else if (a.tipo === 'abrir_doc') { var bt = $('[data-doc="' + a.alvo + '"]'); if (bt) bt.click(); }
      else if (a.tipo === 'abrir_referencias') { $('#refDet').open = true; copRolar($('#refDet')); }
      else if (a.tipo === 'salvar_teste') copRolar($('#lSalvar'));
    } });
    $$('[data-doc]').forEach(function (b) { b.onclick = function () { // contrato st.labEditando preservado; o Documento recebe o texto da versão escolhida
      var txt = $('#' + b.dataset.doc).value;
      st.labEditando = { tipo: cur, titulo: $('#lTit').value.trim().slice(0, 80), versao_a: $('#lA').value, versao_b: $('#lB').value };
      ir('laboratorio', { doc: { texto: txt, titulo: st.labEditando.titulo, tipo: cur } }); }; });
    $('#voltar').onclick = function () { ir('laboratorio'); };
    $('#lSalvar').onclick = async function () {
      var a = $('#lA').value.trim(), b = $('#lB').value.trim();
      if (!a || !b) { $('#lErro').textContent = 'Escreva as duas versões.'; return; }
      this.disabled = true;
      var r = await sb.from('evolui_lab_testes').insert({ user_id: st.user.id, tipo: cur, titulo: $('#lTit').value.trim().slice(0, 80) || null, versao_a: a, versao_b: b, nota_a: analisar(cur, a).nota, nota_b: analisar(cur, b).nota, hipotese: ($('#lHip').value || '').trim().slice(0, 200) || null, status: 'testando' }).select('id').single();
      if (r.error) { this.disabled = false; $('#lErro').textContent = 'Não foi possível salvar.'; return; }
      if (refs) { try { await refs.vincular(r.data.id); } catch (e) { /* referências ficam salvas sem vínculo */ } }
      st.labEditando = null; toast('Teste criado!'); registrar('lab_criou', { tipo: cur }); detalheLab(r.data.id);
    };
  }
  // Resultado observado, nunca causalidade: "observamos uma diferença", não "causou".
  async function aprendeuDoTeste(t, taxa) {
    var box = $('#aprendeu'); if (!box || !t.vencedora) return;
    var vA = taxa(t.resultado_a), vB = taxa(t.resultado_b); if (vA == null || vB == null) return;
    var L = t.vencedora.toUpperCase(), w = L === 'A' ? vA : vB, l = L === 'A' ? vB : vA, f = function (x) { return x.toFixed(1).replace('.', ',') + '%'; };
    var obs = 'Observamos uma diferença entre as versões: a versão ' + L + ' teve engajamento ponderado de ' + f(w) + ' contra ' + f(l) + '.';
    var padrao = ((t.hipotese ? 'Hipótese testada: ' + t.hipotese.replace(/[.\s]+$/, '') + '. ' : '') + 'No teste "' + (t.titulo || (t.tipo === 'bio' ? 'bio' : 'legenda')) + '", a versão ' + L + ' apresentou desempenho observado superior ao comparado, em uma medição.').slice(0, 300);
    var ja = null;
    try { var q = await sb.from('evolui_aprendizados').select('id,nivel').like('observacao', 'teste:' + t.id + '%').limit(1); ja = q.data && q.data[0]; } catch (e) { /* sem consulta */ }
    var pers = !(st.perfil && st.perfil.personalizar === false);
    var cardApr = cartoes([{ hero: true, type: 'aprendizado', title: 'O que aprendemos com esse experimento?', description: 'Observamos uma diferença entre as versões.', steps: [{ label: 'Experimento', value: t.titulo || (t.tipo === 'bio' ? 'Teste de bio' : 'Teste de legenda') }, { label: 'Resultado', value: 'B ' + f(vB) + ' · A ' + f(vA) }, { label: 'Aprendizado', value: ja ? (ja.nivel === 'conclusao' ? 'confirmado' : 'hipótese') : 'a guardar' }], tags: ['Resultado observado'] }]);
    box.innerHTML = cardApr + '<section class="card aprendeu-card"><h3>O que aprendemos com esse experimento?</h3><p class="sub" style="margin:0">' + esc(obs) + '</p>' +
      '<p class="muted" style="margin:6px 0 0">Isso é um resultado observado numa única medição. Não prova que o texto causou a diferença: horário, assunto e sorte também influenciam.</p>' +
      (ja ? '<p class="muted">Guardado como ' + (ja.nivel === 'conclusao' ? 'aprendizado confirmado por você' : 'hipótese') + '. Veja e controle em Perfil › Memória.</p>'
        : pers ? '<div class="linha"><button class="btn cta" type="button" id="guardaApr">Guardar como hipótese</button><span class="muted">Não vira verdade universal: fica como hipótese até você confirmar.</span></div>'
        : '<p class="muted">A personalização está desligada, então este aprendizado não será guardado.</p>') + '</section>';
    var g = $('#guardaApr'); if (g) g.onclick = async function () {
      g.disabled = true;
      var x = await sb.from('evolui_aprendizados').insert({ user_id: st.user.id, nivel: 'hipotese', gerado_por: 'regra', resultado: 'acima', padrao: padrao, amostra: 1, ativo: true, pontuacao: Math.round((w - l) * 10) / 10, observacao: ('teste:' + t.id + ' · ' + obs).slice(0, 600) });
      if (x.error) { g.disabled = false; return toast('Não foi possível guardar agora.'); }
      registrar('lab_concluiu', { tipo: t.tipo, aprendizado: true });
      toast('Guardado como hipótese. Você pode confirmar no Perfil ou na Home.'); aprendeuDoTeste(t, taxa);
    };
    animar(box);
  }
  async function detalheLab(id) {
    var r = await sb.from('evolui_lab_testes').select('*').eq('id', id).maybeSingle();
    if (!r.data) { ir('laboratorio'); return; }
    var t = r.data, A = analisar(t.tipo, t.versao_a), B = analisar(t.tipo, t.versao_b);
    var campos = [['alcance', 'Alcance (contas alcançadas)'], ['curtidas', 'Curtidas'], ['comentarios', 'Comentários'], ['mensagens', t.tipo === 'bio' ? 'Mensagens ou cliques no link' : 'Mensagens e compartilhamentos']];
    function taxa(x) { x = x || {}; var al = +x.alcance || 0; if (!al) return null; return ((+x.curtidas || 0) + 2 * (+x.comentarios || 0) + 3 * (+x.mensagens || 0)) / al * 100; }
    function lado(L, txt, an, res) {
      var tx = taxa(res);
      return '<div class="card' + (t.vencedora === L.toLowerCase() ? ' vencedora' : '') + '"><div class="entre"><h3>Versão ' + L + '</h3>' + (t.vencedora === L.toLowerCase() ? '<span class="selo">Vencedora</span>' : '') + '</div>' +
        '<div class="caixa-legenda" id="t' + L + '">' + esc(txt) + '</div><div class="linha"><button class="btn sm" data-copiar="' + L + '">Copiar</button><button class="btn sm ghost" data-doc="' + L + '">Editar no Documento</button></div>' + blocoAnalise(an) +
        '<h3 style="font-size:17px;margin-top:6px">Resultado real</h3><div class="grade2">' + campos.map(function (c) { var v = (res || {})[c[0]]; return '<div class="campo"><label for="r' + L + c[0] + '">' + c[1] + '</label><input id="r' + L + c[0] + '" inputmode="numeric" pattern="[0-9]*" value="' + esc(v == null ? '' : v) + '"></div>'; }).join('') + '</div>' +
        (tx != null ? '<p class="sub">Engajamento ponderado: <b>' + tx.toFixed(1).replace('.', ',') + '%</b></p>' : '') + '</div>';
    }
    $('#conteudo').innerHTML = '<div><button class="btn ghost sm" id="voltar">‹ Laboratório</button><h1 class="tit">' + esc(t.titulo || (t.tipo === 'bio' ? 'Teste de bio' : 'Teste de legenda')) + '</h1>' + (t.hipotese ? '<p class="sub"><b>Hipótese:</b> ' + esc(t.hipotese) + '</p>' : '') + '</div>' +
      '<details class="card mais"><summary>Como fazer o teste do jeito certo</summary><p class="sub" style="margin-top:6px">' + (t.tipo === 'bio'
        ? 'Use a versão A na sua bio por 7 dias e anote os números do Instagram (Painel profissional › Visão geral). Depois troque para a versão B por mais 7 dias, nos mesmos dias da semana, e anote de novo.'
        : 'Publique dois posts parecidos (mesmo formato e assunto), um com cada legenda, no mesmo dia da semana e horário, com uma semana de diferença. Anote os números de cada post depois de 48 horas.') + '</p></details>' +
      '<div class="ab">' + lado('A', t.versao_a, A, t.resultado_a) + lado('B', t.versao_b, B, t.resultado_b) + '</div>' +
      '<div id="aprendeu"></div><div class="linha"><button class="btn cta" id="calc">Salvar resultados e ver a vencedora</button><button class="btn ghost perigo" id="apagar">Apagar teste</button></div><p class="muted" style="font-size:13px">Engajamento ponderado = (curtidas + 2 × comentários + 3 × mensagens) ÷ alcance. Comentário e mensagem valem mais porque mostram intenção.</p>';
    $('#voltar').onclick = function () { ir('laboratorio'); };
    aprendeuDoTeste(t, taxa);
    $$('[data-copiar]').forEach(function (b) { b.onclick = function () { copiar(b.dataset.copiar === 'A' ? t.versao_a : t.versao_b, $('#t' + b.dataset.copiar)); }; });
    $$('[data-doc]').forEach(function (b) { b.onclick = function () { ir('laboratorio', { doc: { texto: b.dataset.doc === 'A' ? t.versao_a : t.versao_b, titulo: t.titulo || '', tipo: t.tipo, teste_id: t.id, teste_titulo: t.titulo || (t.tipo === 'bio' ? 'Teste de bio' : 'Teste de legenda') } }); }; });
    $('#apagar').onclick = async function () { var x = await sb.from('evolui_lab_testes').delete().eq('id', t.id); if (!x.error) { toast('Teste apagado.'); ir('laboratorio'); } };
    $('#calc').onclick = async function () {
      function ler(L) { var o = {}; campos.forEach(function (c) { var v = $('#r' + L + c[0]).value.replace(/\D/g, ''); if (v !== '') o[c[0]] = Math.min(1e9, +v); }); return o; }
      var ra = ler('A'), rb = ler('B'), ta = taxa(ra), tb = taxa(rb), venc = null;
      if (ta != null && tb != null && ta !== tb) venc = ta > tb ? 'a' : 'b';
      var x = await sb.from('evolui_lab_testes').update({ resultado_a: ra, resultado_b: rb, vencedora: venc, status: venc ? 'concluido' : 'testando' }).eq('id', t.id);
      if (x.error) return toast('Não foi possível salvar.');
      toast(venc ? 'A versão ' + venc.toUpperCase() + ' venceu!' : (ta == null || tb == null ? 'Resultados salvos. Preencha o alcance das duas versões para comparar.' : 'Empate técnico.'));
      if (venc) registrar('lab_concluiu', { tipo: t.tipo });
      detalheLab(t.id);
    };
  }

  // ---------------------------------------------------------------- Copiloto contextual (Fase 4)
  // Faixa discreta que olha o ESTÁGIO do conteúdo e oferece UMA próxima ação por vez, com o motivo. Tudo por regras locais
  // (copiloto.js): sem IA, sem rede, sem enviar texto a ninguém. Nada muda no texto sem passar pelo antes/depois do Documento.
  // Memória: sessão (st.copSes, só em memória) e preferências (calculadas dos eventos; confirmadas/removidas em evolui_perfis.preferencias.copiloto).
  var COP_ESTADO = { ok: 'Em ordem', falta: 'Falta', atencao: 'Atenção', na: 'Não se aplica', indefinido: 'Ainda não dá para avaliar' };
  var COP_BTN = { focar: 'Ir para o campo', comando: 'Ver o antes e depois', ver_sugestao: 'Ver no texto', abrir_ab: 'Abrir o teste A/B', abrir_referencias: 'Ver referências', abrir_teste: 'Abrir o teste', abrir_aba: 'Ir para o início', abrir_doc: 'Abrir no Documento', salvar_teste: 'Ir para salvar' };
  st.copSes = st.copSes || {};
  function copPers() { return !(st.perfil && st.perfil.personalizar === false); }
  function copCfg() {
    var c = ((st.perfil && st.perfil.preferencias) || {}).copiloto || {};
    function l(x) { return Array.isArray(x) ? x.filter(function (v) { return typeof v === 'string' && v.length < 80; }).slice(0, 200) : []; }
    return { confirmadas: l(c.confirmadas), removidas: l(c.removidas) };
  }
  function copSessao(tela, id) { var k = tela + ':' + id; return st.copSes[k] || (st.copSes[k] = window.EvoluiCopiloto.novaSessao(tela, id)); }
  function copConta(tela, id, campo) { if (!window.EvoluiCopiloto) return; var s0 = copSessao(tela, id); s0[campo] = (s0[campo] || 0) + 1; }
  function copSinal(tipo, d) { var C = window.EvoluiCopiloto, x = C && C.montarSinal(tipo, d); if (x) registrar(x.tipo, x.dados); } // só categorias; registrar() respeita personalizar
  // preferências inferidas: UMA consulta por sessão (cache em st.copInf). Desligado se personalizar=false.
  async function copPrefs(forcar) {
    var C = window.EvoluiCopiloto, cfg = copCfg();
    if (!C || !copPers()) return { ativas: [], hipoteses: [], removidas: [], personalizar: false };
    if (st.copInf && !forcar) return st.copInf;
    var ev = [];
    try { var r = await sb.from('evolui_eventos').select('tipo,dados,criado_em').in('tipo', C.TIPOS_LEITURA).order('criado_em', { ascending: false }).limit(1000); if (!r.error) ev = r.data || []; } catch (e) { /* sem rede: sem preferências */ }
    st.copInf = C.inferirPreferencias(ev, { confirmadas: cfg.confirmadas, removidas: cfg.removidas });
    return st.copInf;
  }
  // o.tela, o.conteudo, o.entrada() -> entrada de montarContextoLab, o.fazer(acao). Devolve { agendar, atualizar }.
  function copFaixa(box, o) {
    var C = window.EvoluiCopiloto, tm = null, ult = '', prefs = [], pqId = '', ckAberto = false, K = o.tela + ':' + o.conteudo;
    if (!C || !box) return { agendar: function () {}, atualizar: function () {} };
    function S() { return copSessao(o.tela, o.conteudo); }
    function montar() { var e = o.entrada(); e.sessao = Object.assign({}, S(), { tela: o.tela, conteudo: o.conteudo }); e.preferencias = prefs; return C.montarContextoLab(e); }
    function atualizar(forcar) {
      if (!document.body.contains(box)) return;
      var ctx = montar(), a = C.proximaAcao(ctx), ck = C.checklistDeProntidao(ctx);
      var sig = (a ? a.id : '-') + '|' + ck.itens.map(function (i) { return i.estado; }).join(',') + '|' + ctx.preferencias.length + '|' + ctx.sessao.comandos + '|' + ctx.sessao.sugestoesAceitas;
      if (!forcar && sig === ult) return; ult = sig;
      var pers = ctx.tom && ctx.doc.palavras >= 5 ? C.adequacaoPersona(ctx.doc.texto, ctx.tom) : null, res = C.resumoSessao(ctx);
      var h = '<div class="cop" role="region" aria-label="Copiloto"><span class="kicker">Copiloto · ' + esc(C.ESTAGIO_ROTULO[C.estagio(ctx)]) + '</span>';
      if (a) {
        h += '<p class="cop-t">' + esc(a.titulo) + '</p><div class="linha"><button class="btn sm cta" type="button" data-cfaz>' + esc(COP_BTN[a.acao.tipo] || 'Fazer isso') + '</button><button class="btn sm ghost" type="button" data-cnao>Agora não</button></div>' +
          '<details class="cop-pq" data-cpq="' + esc(a.id) + '"' + (pqId === a.id ? ' open' : '') + '><summary>Por que isso?</summary><p>' + esc(a.porque) + '</p><p class="muted">Regra: ' + esc(a.regra) + '. Feito por regras no seu navegador, sem IA. Nada muda no texto sem o seu aceite.' + (a.preferencia ? ' ' + esc(a.preferencia) : '') + '</p></details>';
        var m = C.marcarSugerida(S(), a.id); if (m.novo) { st.copSes[K] = m.sessao; copSinal('copiloto_sugeriu', { acao: a.id, estagio: a.estagio, tela: o.tela, conteudo: o.conteudo }); }
      } else h += '<p class="cop-t muted">Nada pendente por aqui. Siga no seu ritmo.</p>';
      h += '<details class="cop-ck" id="copCk"' + (ckAberto ? ' open' : '') + '><summary>Checklist de prontidão · ' + esc(ck.resumo) + '</summary><ul class="cop-lista">' + ck.itens.map(function (i) {
        return '<li><b>' + esc(i.rotulo) + '</b> <span class="pill cop-e-' + i.estado + '">' + esc(COP_ESTADO[i.estado]) + '</span><div class="muted">' + esc(i.explicacao) + '</div></li>';
      }).join('') + (pers ? '<li><b>Tom</b> <span class="pill cop-e-' + (pers.adequado === true ? 'ok' : pers.adequado === false ? 'atencao' : 'indefinido') + '">' + (pers.adequado === true ? 'Em ordem' : pers.adequado === false ? 'Atenção' : 'Ainda não dá para avaliar') + '</span><div class="muted">' + esc(pers.explicacao) + '</div></li>' : '') +
        '</ul><p class="muted">' + esc(ck.explicacao) + '</p><p class="muted">' + esc(res.texto) + ' ' + esc(res.aviso) + '</p><p class="muted">Sem IA e sem enviar o seu texto. ' + (copPers() ? 'Suas escolhas aqui (aceitar, dispensar) ajudam a Evolui a aprender o seu jeito; veja e controle no Perfil.' : 'A personalização está desligada: nada é registrado.') + '</p></details></div>';
      box.innerHTML = h;
      var ck0 = $('#copCk', box); if (ck0) ck0.addEventListener('toggle', function () { ckAberto = ck0.open; });
      var pq0 = $('[data-cpq]', box); if (pq0) pq0.addEventListener('toggle', function () { pqId = pq0.open ? pq0.dataset.cpq : ''; });
      var fz = $('[data-cfaz]', box), nao = $('[data-cnao]', box);
      if (fz) fz.onclick = function () { copSinal('copiloto_aceitou', { acao: a.id, estagio: a.estagio, tela: o.tela, conteudo: o.conteudo }); st.copSes[K] = C.aceitar(S(), a.id); o.fazer(a.acao, a); };
      if (nao) nao.onclick = function () { copSinal('copiloto_dispensou', { acao: a.id, estagio: a.estagio, tela: o.tela, conteudo: o.conteudo }); st.copSes[K] = C.dispensar(S(), a.id); atualizar(true); };
    }
    function agendar(ms) { clearTimeout(tm); tm = setTimeout(function () { atualizar(); }, ms == null ? 700 : ms); }
    atualizar(true);
    copPrefs().then(function (r) { prefs = r.ativas || []; atualizar(true); }, function () {});
    return { agendar: agendar, atualizar: atualizar };
  }
  function copRolar(el) { try { el.focus(); if (el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { /* ok */ } }
  // cartão do Perfil: o que foi aprendido, com a evidência, e controle total do usuário
  async function copCartao() {
    var box = $('#copCartao'), C = window.EvoluiCopiloto; if (!box) return;
    var aviso = '<p class="sub" style="font-size:14px">O que usamos: só as suas ações aqui dentro, como categorias (formato escolhido, comandos aceitos, avisos ignorados, sugestões do copiloto aceitas ou dispensadas, tipo de teste, de onde vêm as referências que você escolhe). Nunca o texto dos seus documentos. Nada é enviado a terceiros e não usamos IA externa. Se você desligar a personalização, paramos de registrar e de usar. Tudo isso entra em “Baixar meus dados” e é apagado em “Apagar tudo”.</p>';
    if (!C) { box.innerHTML = '<p class="muted">Não carregou. Atualize a página.</p>'; return; }
    if (!copPers()) { box.innerHTML = aviso + '<p class="muted"><b>A personalização está desligada:</b> não registramos nem usamos nada disso. Ligue em “Personalização” para voltar a aprender.</p>'; return; }
    var r = await copPrefs(true); if ($('#copCartao') !== box) return;
    function item(p, conf) {
      return '<li class="cop-pref"><div style="min-width:0"><b>' + esc(p.rotulo) + '</b> <span class="pill">' + (p.origem === 'confirmada' ? 'Confirmada por você' : p.origem === 'hipotese' ? 'Em observação' : 'Observada') + '</span><div class="muted">' + esc(p.porque) + '</div><div class="muted">' + (p.origem === 'hipotese' ? 'Ainda não uso isso para nada.' : 'Como uso: ' + esc(p.efeito)) + '</div></div><div class="linha">' +
        (p.origem !== 'confirmada' ? '<button class="btn sm" type="button" data-pconf="' + esc(p.id) + '">Confirmar</button>' : '') + '<button class="btn sm ghost" type="button" data-prem="' + esc(p.id) + '">Não é isso</button></div></li>';
    }
    box.innerHTML = aviso +
      (r.ativas.length ? '<ul class="cop-prefs">' + r.ativas.map(item).join('') + '</ul>' : '<p class="muted">Ainda não aprendi nada firme sobre o seu jeito. Uma preferência só aparece depois de se repetir (3 vezes em 2 conteúdos diferentes) ou quando você confirma. Uma correção isolada nunca conta.</p>') +
      (r.hipoteses.length ? '<details class="mais"><summary>Ainda estou observando (' + r.hipoteses.length + ')</summary><ul class="cop-prefs">' + r.hipoteses.map(item).join('') + '</ul></details>' : '') +
      (r.removidas.length ? '<details class="mais"><summary>Você disse “não é isso” (' + r.removidas.length + ')</summary><ul class="cop-prefs">' + r.removidas.map(function (p) { return '<li class="cop-pref"><div style="min-width:0"><b>' + esc(p.rotulo) + '</b><div class="muted">Ignorada. Não volta sozinha.</div></div><div class="linha"><button class="btn sm ghost" type="button" data-prev="' + esc(p.id) + '">Voltar a observar</button></div></li>'; }).join('') + '</ul></details>' : '');
    async function salvar(mut, tipo, id) {
      var cfg = copCfg(); mut(cfg);
      var prefs = Object.assign({}, st.perfil.preferencias || {}, { copiloto: { confirmadas: cfg.confirmadas, removidas: cfg.removidas } });
      var x = await sb.from('evolui_perfis').update({ preferencias: prefs }).eq('id', st.user.id);
      if (x.error) { toast('Não foi possível salvar.'); return; }
      st.perfil.preferencias = prefs; st.copInf = null; copSinal(tipo, { pref: id }); copCartao();
    }
    function sem(l, id) { return l.filter(function (v) { return v !== id; }); }
    box.onclick = function (e) {
      var c = e.target.closest('[data-pconf]'), n = e.target.closest('[data-prem]'), v = e.target.closest('[data-prev]');
      if (c) { var i1 = c.dataset.pconf; salvar(function (g) { g.removidas = sem(g.removidas, i1); if (g.confirmadas.indexOf(i1) < 0) g.confirmadas.push(i1); }, 'pref_confirmada', i1); }
      if (n) { var i2 = n.dataset.prem; salvar(function (g) { g.confirmadas = sem(g.confirmadas, i2); if (g.removidas.indexOf(i2) < 0) g.removidas.push(i2); }, 'pref_removida', i2); }
      if (v) { var i3 = v.dataset.prev; salvar(function (g) { g.removidas = sem(g.removidas, i3); }, 'pref_reativada', i3); }
    };
  }


  // ---------------------------------------------------------------- Doc Inteligente (Fase 3)
  // Editor simples ligado ao Laboratório. Sugestões e comandos vêm de regras internas (doc-inteligente.js), no navegador:
  // o texto só vai para o Supabase do próprio usuário (evolui_lab_docs) e nunca para IA ou terceiros. IA fica desligada (flag).
  // Versões: 0 = original (nunca sobrescrito), 1 = texto atual (autosave), 2+ = versões salvas/antes de aplicar algo.
  var DOC_MAX_VERSOES = 60;
  var DOC_TIPOS = { correcao: 'Correção', clareza: 'Clareza', gancho: 'Gancho', estrutura: 'Estrutura', cta: 'Chamada para ação', persona: 'Tom' };
  var DOC_ORIGEM = { original: 'Original (nunca é alterado)', manual: 'Versão salva por você', sugestao: 'Antes de aceitar uma sugestão', comando: 'Antes de um comando', restauracao: 'Antes de restaurar', autosave: 'Texto atual' };
  var DOC_FMT = [['', 'Não informado'], ['legenda', 'Legenda'], ['reel', 'Reel / roteiro'], ['stories', 'Stories'], ['carrossel', 'Carrossel'], ['bio', 'Bio']];
  var DOC_DUR = [[0, 'Sem alvo'], [15, '15 s'], [30, '30 s'], [45, '45 s'], [60, '60 s']];
  st.docIgn = st.docIgn || {}; // sugestões ignoradas nesta sessão, por documento (não voltam até recarregar a página)
  function uuid() {
    try { if (window.crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) { /* navegador antigo */ }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) { var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); });
  }
  function docSinal(acao, d) { var D = window.EvoluiDoc, s = D && D.montarSinal(acao, Object.assign({ conteudo: st.docAtual || '' }, d)); if (s) registrar(s.tipo, s.dados); } // só categorias, nunca o texto; registrar() respeita personalizar
  function docSemTabela(e) { return !!e && (e.code === '42P01' || e.code === 'PGRST205' || /does not exist|schema cache/i.test(String(e.message || ''))); }
  function horaCurta() { try { return new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } }

  async function docLab(o) {
    var D = window.EvoluiDoc, c = $('#conteudo');
    if (!D) { c.innerHTML = '<p class="muted">O editor não carregou. Atualize a página.</p>'; return; }
    o = o || {};
    var cop = null;
    var S = { id: o.doc_id || uuid(), texto: String(o.texto || ''), titulo: String(o.titulo || '').slice(0, 80), formato: o.formato || (o.tipo === 'bio' ? 'bio' : (o.tipo === 'legenda' ? 'legenda' : '')), dur: +o.duracao_seg || 0,
      teste_id: o.teste_id || null, testeTitulo: o.teste_titulo || '', original: null, temOriginal: false, linhaAtual: false, maxV: 1, versoes: [], undo: [], prev: null, cmp: null, sugs: [],
      sujo: false, salvando: false, pendente: false, indisp: false, ultSnapSug: 0, avisouLimite: false, tSave: null, tAn: null };
    S.ign = st.docIgn[S.id] || (st.docIgn[S.id] = {}); st.docAtual = S.id; S.refs = []; S.teste = null;
    if (o.doc_id) {
      c.innerHTML = '<p class="muted">Carregando…</p>';
      var q = await sb.from('evolui_lab_docs').select('versao,origem,titulo,corpo,formato,duracao_seg,teste_id,palavras,criado_em').eq('doc_id', o.doc_id).order('versao', { ascending: false }).limit(DOC_MAX_VERSOES + 2);
      if (q.error || !q.data || !q.data.length) { toast('Não foi possível abrir o documento.'); return ir('laboratorio'); }
      q.data.forEach(function (r) {
        if (r.versao === 0) { S.temOriginal = true; S.original = r.corpo; }
        if (r.versao === 1) { S.linhaAtual = true; S.texto = r.corpo; S.titulo = r.titulo || ''; S.formato = r.formato || ''; S.dur = r.duracao_seg || 0; S.teste_id = r.teste_id; }
        if (r.versao > S.maxV) S.maxV = r.versao;
        S.versoes.push(r);
      });
    } else if (S.texto.trim()) S.original = S.texto; // texto que chegou de fora vira o original no primeiro salvamento
    var p = st.perfil || {};
    function ctx() { return { formato: S.formato, duracaoSeg: S.dur, tom: p.tom || p.persona || '', objetivo: p.objetivo || '', ramo: p.ramo || '', tema: S.titulo }; }
    function opts(lista, atual) { return lista.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (String(x[0]) === String(atual) ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join(''); }

    c.innerHTML = '<div><button class="btn ghost sm" id="dVoltar">‹ Laboratório</button><h1 class="tit">Documento</h1>' +
      '<p class="sub">Escreva ou cole seu texto. As sugestões vêm de regras que rodam aqui no seu navegador, sem IA e sem enviar o texto a ninguém. ' + (S.testeTitulo ? 'Ligado ao teste: <b>' + esc(S.testeTitulo) + '</b>.' : '') + '</p></div>' +
      '<div id="dCop"></div><div class="doc-grade"><div class="card doc-ed">' +
      '<div class="grade3"><div class="campo"><label for="dTit">Título do documento</label><input id="dTit" maxlength="80" placeholder="ex.: bolo de pote para vender mais" value="' + esc(S.titulo) + '"></div>' +
      '<div class="campo"><label for="dFmt">Formato</label><select id="dFmt">' + opts(DOC_FMT, S.formato) + '</select></div>' +
      '<div class="campo"><label for="dDur">Duração alvo</label><select id="dDur">' + opts(DOC_DUR, S.dur) + '</select></div></div>' +
      '<div class="campo"><label for="dTxt">Texto</label><textarea id="dTxt" class="doc-txt" maxlength="12000" spellcheck="true" lang="pt-BR" placeholder="Cole ou escreva aqui o roteiro, a legenda ou a bio.">' + esc(S.texto) + '</textarea></div>' +
      '<div class="doc-stat"><span id="dCont"></span><span id="dSalvo" role="status" aria-live="polite"></span></div><div id="dAcoes" class="doc-acoes"></div>' +
      '<div class="doc-cmds" role="group" aria-label="Comandos sobre o texto ou a seleção">' + D.COMANDOS.filter(function (x) { return !x.versaoSimples; }).map(function (x) { return '<button class="btn sm" type="button" data-cmd="' + esc(x.id) + '" title="' + esc(x.ajuda) + '">' + esc(x.rotulo) + '</button>'; }).join('') + '</div>' +
      '<details class="mais"><summary>Versão simples, sem IA</summary><p class="muted" style="font-size:13px;margin:4px 0 8px">Estas três são só trocas por regras. Não equivalem a reescrever com inteligência: sempre confira o antes e depois.</p><div class="doc-cmds">' +
      D.COMANDOS.filter(function (x) { return x.versaoSimples; }).map(function (x) { return '<button class="btn sm" type="button" data-cmd="' + esc(x.id) + '" title="' + esc(x.ajuda) + '">' + esc(x.rotulo) + ' (simples)</button>'; }).join('') + '</div></details>' +
      '<div class="muted" id="dEscopo" style="font-size:13px"></div><div id="dPrev"></div>' +
      '<div class="linha"><button class="btn sm" type="button" id="dDesfazer" disabled>Desfazer</button><button class="btn sm" type="button" id="dVersao">Salvar versão</button><button class="btn sm" type="button" id="dCopiar">Copiar</button><button class="btn sm" type="button" id="dAB">Testar original × editado</button></div>' +
      '</div><details class="card doc-lado" id="dLado"><summary><b id="dSumSug">Sugestões</b></summary><div id="dSug" style="display:flex;flex-direction:column;gap:10px;margin-top:10px"></div>' +
      '<details class="mais" style="margin-top:12px"><summary>Versões</summary><div id="dVers" style="display:flex;flex-direction:column;gap:8px;margin-top:8px"></div></details>' +
      '<p class="muted" style="font-size:12px;margin:10px 0 0">Nada é enviado a IA externa. Ignorar uma sugestão a esconde até você recarregar a página.</p></details></div><div id="dVideo"></div>';
    if (window.innerWidth >= 980) $('#dLado').open = true;

    // ---- persistência
    function status(t) { var e = $('#dSalvo'); if (e) e.textContent = t; }
    function marcaIndisp(e) { if (docSemTabela(e)) { S.indisp = true; status('Salvar no sistema ainda não está disponível nesta conta. Baixe o texto ou copie antes de sair.'); return true; } return false; }
    function agendarSalvar(ms) { clearTimeout(S.tSave); S.sujo = true; if (!S.indisp) status('Alterações ainda não salvas…'); S.tSave = setTimeout(salvar, ms == null ? 1500 : ms); }
    async function gravarOriginal() {
      if (S.temOriginal || !S.original || !S.original.trim()) return;
      var r = await sb.from('evolui_lab_docs').insert({ user_id: st.user.id, doc_id: S.id, versao: 0, origem: 'original', titulo: S.titulo || null, corpo: S.original, formato: S.formato || null, duracao_seg: S.dur || null, palavras: D.palavrasDe(S.original), teste_id: S.teste_id });
      if (r.error && r.error.code !== '23505') throw r.error; // 23505: já existe (outra aba)
      S.temOriginal = true;
    }
    async function salvar() {
      clearTimeout(S.tSave);
      if (S.indisp) return;
      if (S.salvando) { S.pendente = true; return; }
      if (!S.linhaAtual && !S.texto.trim() && !S.titulo.trim()) { S.sujo = false; status(''); return; } // não cria documento vazio
      S.salvando = true; S.pendente = false; status('Salvando…');
      var enviado = S.texto;
      try {
        await gravarOriginal();
        var r = await sb.from('evolui_lab_docs').upsert({ user_id: st.user.id, doc_id: S.id, versao: 1, origem: 'autosave', titulo: S.titulo.trim().slice(0, 80) || null, corpo: enviado, formato: S.formato || null, duracao_seg: S.dur || null, palavras: D.palavrasDe(enviado), teste_id: S.teste_id }, { onConflict: 'user_id,doc_id,versao' });
        if (r.error) throw r.error;
        S.linhaAtual = true; S.sujo = S.texto !== enviado; if (!S.sujo) { S.ultSalvo = horaCurta(); status('Salvo no sistema às ' + S.ultSalvo); }
      } catch (e) {
        if (!marcaIndisp(e)) { status('Não foi possível salvar agora. O texto continua aqui; use Baixar texto para guardar uma cópia. Vou tentar de novo.'); S.pendente = true; }
      }
      S.salvando = false;
      if (!S.indisp && (S.pendente || S.sujo)) S.tSave = setTimeout(salvar, S.pendente && !S.sujo ? 8000 : 800);
    }
    async function snapshot(origem, corpo) {
      if (S.indisp) return false;
      if (S.maxV >= DOC_MAX_VERSOES) { if (!S.avisouLimite) { S.avisouLimite = true; toast('Limite de ' + DOC_MAX_VERSOES + ' versões neste documento. O Desfazer continua funcionando.'); } return false; }
      var ult = S.versoes.filter(function (v) { return v.versao >= 2; })[0];
      if (ult && ult.corpo === corpo) return true;
      var v = S.maxV + 1;
      var r = await sb.from('evolui_lab_docs').insert({ user_id: st.user.id, doc_id: S.id, versao: v, origem: origem, titulo: S.titulo.trim().slice(0, 80) || null, corpo: corpo, formato: S.formato || null, duracao_seg: S.dur || null, palavras: D.palavrasDe(corpo), teste_id: S.teste_id });
      if (r.error) { marcaIndisp(r.error); return false; }
      S.maxV = v; S.versoes.unshift({ versao: v, origem: origem, corpo: corpo, palavras: D.palavrasDe(corpo), criado_em: new Date().toISOString() }); desenharVersoes();
      return true;
    }

    // ---- texto
    function contagem() {
      var d = D.estimarDuracao(S.texto), e = $('#dCont'); if (!e) return;
      e.textContent = d.palavras + ' palavra(s) · ' + S.texto.length + ' caracteres · ' + d.rotulo + ' de fala' + (S.dur ? ' (alvo ' + S.dur + ' s)' : '');
      var des = $('#dDesfazer'); if (des) des.disabled = !S.undo.length;
    }
    function definirTexto(t, sel) {
      var ta = $('#dTxt'); S.texto = t; ta.value = t;
      if (sel) { try { ta.focus(); ta.setSelectionRange(sel.inicio, sel.fim); } catch (e) { /* sem seleção */ } }
      contagem(); escopo(); agendarAnalise(0); agendarSalvar();
    }
    async function mudar(novoTexto, origem, selNova, snap) {
      var antes = S.texto;
      if (!S.temOriginal && !S.original && antes.trim()) S.original = antes; // o original é o texto de antes da primeira ajuda automática
      try { await gravarOriginal(); } catch (e) { marcaIndisp(e); }
      if (snap) await snapshot(origem, antes);
      S.undo.push({ texto: antes, id: origem }); if (S.undo.length > 50) S.undo.shift();
      definirTexto(novoTexto, selNova);
    }
    function escopo() {
      var ta = $('#dTxt'), e = $('#dEscopo'); if (!ta || !e) return;
      var a = ta.selectionStart, b = ta.selectionEnd;
      e.textContent = b > a ? 'Os comandos valem para a seleção (' + D.palavrasDe(ta.value.slice(a, b)) + ' palavra(s)). Gancho e CTA não usam a seleção.' : 'Sem seleção: os comandos valem para o texto todo. Selecione um trecho para agir só nele.';
    }

    // ---- sugestões (painel discreto)
    function curto(s) { s = String(s).replace(/\s+/g, ' '); return s.length > 70 ? s.slice(0, 67) + '…' : s; }
    function desenharSug() {
      var box = $('#dSug'); if (!box) return;
      var n = D.palavrasDe(S.texto), sum = $('#dSumSug');
      if (!S.texto.trim()) { S.sugs = []; box.innerHTML = '<p class="muted">Escreva ou cole um texto para ver sugestões. As regras olham correção segura, clareza, gancho, chamada para ação, duração e tom.</p>'; sum.textContent = 'Sugestões'; return; }
      if (n < 5) { S.sugs = []; box.innerHTML = '<p class="muted">Escreva um pouco mais para eu poder analisar.</p>'; sum.textContent = 'Sugestões'; return; }
      S.sugs = D.analisarDoc(S.texto, ctx(), { ignoradas: S.ign });
      sum.textContent = S.sugs.length ? 'Sugestões (' + (S.sugs.total) + ')' : 'Sugestões';
      if (!S.sugs.length) { box.innerHTML = '<p class="muted">Nenhuma sugestão agora. Isso não quer dizer que o texto está ótimo: as regras só apontam o que é seguro apontar.</p>'; return; }
      box.innerHTML = S.sugs.map(function (s, i) {
        return '<div class="sug"><span class="kicker">' + esc(DOC_TIPOS[s.tipo] || s.tipo) + '</span><p class="sug-m">' + esc(s.mensagem) + '</p>' +
          (s.trecho.texto && s.trecho.fim - s.trecho.inicio < S.texto.length ? '<p class="muted sug-t">“' + esc(curto(s.trecho.texto)) + '”</p>' : '') +
          '<details><summary class="muted" style="cursor:pointer;font-size:13px">Por quê?</summary><p class="muted" style="font-size:13px;margin:4px 0 0">' + esc(s.motivo) + '</p></details>' +
          '<div class="linha">' + (s.acao ? '<button class="btn sm" type="button" data-sap="' + i + '">' + esc(s.acao.rotulo || 'Aplicar') + '</button>' : '') +
          '<button class="btn sm ghost" type="button" data-sver="' + i + '">Ver no texto</button><button class="btn sm ghost" type="button" data-sig="' + i + '">Ignorar</button></div></div>';
      }).join('') + (S.sugs.ocultas ? '<p class="muted" style="font-size:13px">+' + S.sugs.ocultas + ' sugestão(ões) menor(es) escondida(s). Resolva as de cima para ver as próximas.</p>' : '');
    }
    function agendarAnalise(ms) { clearTimeout(S.tAn); S.tAn = setTimeout(desenharSug, ms == null ? 500 : ms); if (cop) cop.agendar(ms === 0 ? 0 : 900); } // regras locais: sem rede, o debounce só poupa CPU
    async function aplicarSug(s) {
      var a = s.acao; if (!a) return;
      if (a.tipo === 'comando') { rodar(a.comando, { segundos: a.segundos }, true, s); return; }
      if (S.texto.slice(a.inicio, a.fim) !== a.esperado) { toast('O texto mudou. Atualizei as sugestões.'); desenharSug(); return; }
      var agora = Date.now(), snap = agora - S.ultSnapSug > 120000; // no máximo uma versão a cada 2 min para correções miúdas
      await mudar(S.texto.slice(0, a.inicio) + a.novo + S.texto.slice(a.fim), 'sugestao', null, snap);
      if (snap) S.ultSnapSug = agora;
      docSinal('sug_aceita', { tipo: s.tipo, regra: s.regra }); copConta('doc', S.id, 'sugestoesAceitas');
    }

    // ---- comandos com antes/depois
    function rodar(id, extra, inteiro, deSug) {
      var ta = $('#dTxt'), sel = inteiro ? null : { inicio: ta.selectionStart, fim: ta.selectionEnd };
      var r = D.executarComando(id, S.texto, sel, ctx(), extra);
      if (!r) return;
      S.cmp = null; S.prev = { r: r, base: S.texto, escolha: 0, deSug: deSug || null }; desenharPrev();
      var pv = $('#dPrev'); if (pv && pv.scrollIntoView) { try { pv.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) { /* ok */ } }
    }
    function novoDe(p) { return p.r.opcoes && p.r.opcoes.length ? p.r.opcoes[p.escolha].novo : p.r.novo; }
    function desenharPrev() {
      var box = $('#dPrev'); if (!box) return;
      if (S.cmp) {
        box.innerHTML = '<div class="doc-prev"><div class="entre"><b>' + esc(S.cmp.rotulo) + ' → texto atual</b><button class="btn sm ghost" type="button" id="dFecha">Fechar</button></div><div class="doc-diff" aria-label="Comparação">' + D.diffHTML(D.diffAntesDepois(S.cmp.corpo, S.texto)) + '</div></div>';
        $('#dFecha').onclick = function () { S.cmp = null; desenharPrev(); }; return;
      }
      var p = S.prev; if (!p) { box.innerHTML = ''; return; }
      var r = p.r, tem = r.opcoes && r.opcoes.length, novo = novoDe(p), h = '<div class="doc-prev"><div class="entre"><b>' + esc(r.rotulo) + '</b>' + (r.versaoSimples ? '<span class="pill">versão simples</span>' : '') + '</div>';
      h += '<p class="muted" style="margin:0;font-size:14px">' + esc(r.regra) + '</p>' + (r.aviso ? '<p class="muted" style="margin:0;font-size:13px">' + esc(r.aviso) + '</p>' : '');
      if (r.opcoes && !r.opcoes.length) { box.innerHTML = h + '<div class="linha"><button class="btn sm" type="button" id="dDescarta">Fechar</button></div></div>'; $('#dDescarta').onclick = function () { S.prev = null; desenharPrev(); var t = $('#dTit'); if (t) t.focus(); }; return; }
      if (tem) h += '<div class="doc-opcoes" role="radiogroup" aria-label="Modelos">' + r.opcoes.map(function (x, i) { return '<button type="button" class="btn sm' + (i === p.escolha ? ' prim' : '') + '" role="radio" aria-checked="' + (i === p.escolha) + '" data-opc="' + i + '">' + esc(curto(x.novo)) + '</button>'; }).join('') + '<p class="muted" style="font-size:13px;margin:0">' + esc(r.opcoes[p.escolha].regra) + '</p></div>';
      if (!tem && !r.mudou) { box.innerHTML = h + '<div class="linha"><button class="btn sm" type="button" id="dDescarta">Fechar</button></div></div>'; $('#dDescarta').onclick = function () { S.prev = null; desenharPrev(); }; return; }
      var ops = D.diffAntesDepois(r.original, novo), res = D.resumoDiff(ops);
      h += '<div class="doc-diff" aria-label="Antes e depois">' + D.diffHTML(ops) + '</div><p class="muted" style="font-size:13px;margin:0">' + res.removidas + ' palavra(s) removida(s), ' + res.adicionadas + ' adicionada(s). O original continua guardado.</p>' +
        (r.dicas ? '<p class="muted" style="font-size:13px;margin:0">Para expandir de verdade, responda: ' + r.dicas.map(esc).join(' · ') + '</p>' : '') +
        '<details><summary class="muted" style="cursor:pointer;font-size:13px">Ver antes e depois lado a lado</summary><div class="ab" style="margin-top:8px"><div class="caixa-legenda">' + esc(r.original || '(nada)') + '</div><div class="caixa-legenda">' + esc(novo) + '</div></div></details>' +
        '<div class="linha"><button class="btn sm cta" type="button" id="dAceita">Aceitar</button><button class="btn sm" type="button" id="dDescarta">Descartar</button></div></div>';
      box.innerHTML = h;
      $$('[data-opc]', box).forEach(function (b) { b.onclick = function () { p.escolha = +b.dataset.opc; desenharPrev(); }; });
      $('#dAceita').onclick = async function () {
        if (S.texto !== p.base) { toast('O texto mudou depois do comando. Refaça o comando.'); S.prev = null; desenharPrev(); return; }
        var nv = D.aplicar(S.texto, r.selecao, novo);
        S.prev = null; desenharPrev();
        await mudar(nv, 'comando', { inicio: r.selecao.inicio, fim: r.selecao.inicio + novo.length }, true);
        docSinal('cmd_aceito', { comando: r.comando, simples: r.versaoSimples, formato: S.formato }); copConta('doc', S.id, 'comandos');
        if (p.deSug) docSinal('sug_aceita', { tipo: p.deSug.tipo, regra: p.deSug.regra });
        toast('Aplicado. Dá para desfazer.');
      };
      $('#dDescarta').onclick = function () { docSinal('cmd_descartado', { comando: r.comando, simples: r.versaoSimples }); S.prev = null; desenharPrev(); };
    }

    // ---- versões
    function desenharVersoes() {
      var box = $('#dVers'); if (!box) return;
      var L = S.versoes.filter(function (v) { return v.versao !== 1; }).sort(function (a, b) { return b.versao - a.versao; });
      if (!L.length) { box.innerHTML = '<p class="muted" style="font-size:13px;margin:0">Ainda sem versões. Elas aparecem ao salvar uma versão ou antes de aplicar um comando.</p>'; return; }
      box.innerHTML = L.map(function (v) {
        return '<div class="sug"><b style="font-size:14px">' + (v.versao === 0 ? 'Original' : 'Versão ' + v.versao) + '</b><span class="muted" style="font-size:13px">' + esc(DOC_ORIGEM[v.origem] || '') + ' · ' + dataHora(v.criado_em) + ' · ' + (v.palavras != null ? v.palavras : D.palavrasDe(v.corpo)) + ' palavra(s)</span>' +
          '<div class="linha"><button class="btn sm ghost" type="button" data-vcmp="' + v.versao + '">Comparar</button><button class="btn sm ghost" type="button" data-vres="' + v.versao + '">Restaurar</button></div></div>';
      }).join('');
    }
    function achaV(n) { return S.versoes.filter(function (v) { return v.versao === n; })[0]; }

    // ---- eventos de tela
    var ta = $('#dTxt');
    ta.oninput = function () { S.texto = ta.value; if (S.prev) { S.prev = null; desenharPrev(); } contagem(); agendarAnalise(500); agendarSalvar(); };
    ['select', 'keyup', 'mouseup', 'touchend', 'focus'].forEach(function (ev) { ta.addEventListener(ev, escopo); });
    $('#dTit').oninput = function () { S.titulo = this.value; agendarAnalise(500); agendarSalvar(); };
    $('#dFmt').onchange = function () { S.formato = this.value; agendarAnalise(0); agendarSalvar(); };
    $('#dDur').onchange = function () { S.dur = +this.value; contagem(); agendarAnalise(0); agendarSalvar(); };
    $$('[data-cmd]', c).forEach(function (b) { b.onclick = function () { rodar(b.dataset.cmd); }; });
    $('#dSug').onclick = function (e) {
      var ap = e.target.closest('[data-sap]'), ver = e.target.closest('[data-sver]'), ig = e.target.closest('[data-sig]');
      if (ap) aplicarSug(S.sugs[+ap.dataset.sap]);
      if (ver) { var s = S.sugs[+ver.dataset.sver]; try { ta.focus(); ta.setSelectionRange(s.trecho.inicio, s.trecho.fim); } catch (x) { /* ok */ } }
      if (ig) { var g = S.sugs[+ig.dataset.sig]; S.ign[g.id] = true; docSinal('sug_ignorada', { tipo: g.tipo, regra: g.regra }); desenharSug(); }
    };
    $('#dVers').onclick = function (e) {
      var cp = e.target.closest('[data-vcmp]'), rs = e.target.closest('[data-vres]');
      if (cp) { var v = achaV(+cp.dataset.vcmp); if (v) { S.prev = null; S.cmp = { corpo: v.corpo, rotulo: v.versao === 0 ? 'Original' : 'Versão ' + v.versao }; desenharPrev(); } }
      if (rs) { var w = achaV(+rs.dataset.vres); if (w) { S.cmp = null; mudar(w.corpo, 'restauracao', null, true).then(function () { toast('Versão restaurada. Dá para desfazer.'); }); } }
    };
    $('#dDesfazer').onclick = function () {
      var u = S.undo.pop(); if (!u) return;
      S.prev = null; S.cmp = null; desenharPrev(); definirTexto(u.texto); docSinal('cmd_desfeito', { comando: u.id }); toast('Desfeito.');
    };
    $('#dVersao').onclick = async function () {
      this.disabled = true; try { await salvar(); var ok = await snapshot('manual', S.texto); if (ok) { docSinal('versao_salva', { versao: S.maxV }); toast('Versão ' + S.maxV + ' salva.'); } else if (!S.indisp && S.maxV < DOC_MAX_VERSOES) toast('Não foi possível salvar a versão.'); } finally { this.disabled = false; }
    };
    $('#dCopiar').onclick = function () { copiar(S.texto, ta, S.formato || undefined); };
    $('#dAB').onclick = function () {
      var orig = S.original || ''; // preserva o contrato st.labEditando: A = original, B = editado
      if (!orig.trim() || orig === S.texto) { toast('Para comparar, aplique algum comando ou sugestão: assim existe um original diferente do editado.'); return; }
      st.labEditando = { tipo: S.formato === 'bio' ? 'bio' : 'legenda', titulo: S.titulo.slice(0, 80), versao_a: orig, versao_b: S.texto };
      salvar().then(function () { ir('laboratorio', { novo: true }); });
    };
    $('#dVoltar').onclick = async function () { await salvar(); ir('laboratorio'); };
    function sair() { if (!$('#dTxt') || $('#dTxt') !== ta) { document.removeEventListener('visibilitychange', oculta); return false; } return true; }
    function oculta() { if (!sair()) return; if (document.visibilityState === 'hidden' && S.sujo) salvar(); }
    document.addEventListener('visibilitychange', oculta);
    contagem(); escopo(); desenharSug(); desenharVersoes();
    docSinal('aberto', { formato: S.formato });
    docAcoes(S, { salvar: salvar, status: status, D: D, ctx: ctx }); docVideo(S, { salvar: salvar }); // Fase 5B: salvar/PDF/txt e "Virou vídeo?"
    // ---- copiloto (Fase 4): uma sugestão por vez, regras locais
    function abrirAB() { // A = original e B = editado; sem original diferente, A = texto atual e B em branco para escrever a variação
      var orig = S.original || '', difere = !!orig.trim() && orig !== S.texto;
      st.labEditando = { tipo: S.formato === 'bio' ? 'bio' : 'legenda', titulo: S.titulo.slice(0, 80), versao_a: difere ? orig : S.texto, versao_b: difere ? S.texto : '' };
      salvar().then(function () { ir('laboratorio', { novo: true }); });
    }
    function copFazer(a) {
      if (a.tipo === 'focar') { var el = $('#' + a.alvo); if (el) copRolar(el); }
      else if (a.tipo === 'comando') rodar(a.comando, undefined, true);
      else if (a.tipo === 'ver_sugestao') {
        var dl = $('#dLado'); if (dl) dl.open = true;
        var sg = S.sugs.filter(function (x) { return x.tipo === a.tipoSug; })[0];
        if (sg) { try { ta.focus(); ta.setSelectionRange(sg.trecho.inicio, sg.trecho.fim); } catch (x) { /* ok */ } } else toast('Veja o painel de sugestões ao lado.');
      }
      else if (a.tipo === 'abrir_ab') abrirAB();
      else if (a.tipo === 'abrir_referencias') {
        st.labEditando = { tipo: S.formato === 'bio' ? 'bio' : 'legenda', titulo: S.titulo.slice(0, 80), versao_a: S.texto, versao_b: '', abrirRef: true, formato: /^(reel|stories|carrossel)$/.test(S.formato) ? S.formato : '', duracao: S.dur ? S.dur + ' segundos' : '' };
        salvar().then(function () { ir('laboratorio', { novo: true }); });
      }
      else if (a.tipo === 'abrir_teste' && a.id) salvar().then(function () { detalheLab(a.id); });
      else if (a.tipo === 'abrir_aba') salvar().then(function () { ir(a.aba || 'buscar'); });
    }
    cop = copFaixa($('#dCop'), { tela: 'doc', conteudo: S.id, fazer: copFazer, entrada: function () {
      var pp = st.perfil || {};
      return { perfil: pp, tom: pp.tom || pp.persona || '', objetivo: pp.objetivo || '', formato: S.formato, duracaoSeg: S.dur, tema: S.titulo,
        doc: { texto: S.texto, original: S.original || '', versoes: S.versoes.filter(function (v) { return v.versao >= 2; }).length }, referencias: S.refs, teste: S.teste };
    } });
    // contexto leve: referências recentes (1 consulta) e o teste ligado (se houver). Falhou? o copiloto segue sem isso.
    sb.from('evolui_lab_referencias').select('estado,teste_id,criado_em').order('criado_em', { ascending: false }).limit(100).then(function (r) {
      if (r.error) return; var lim = Date.now() - 864e5;
      S.refs = (r.data || []).filter(function (x) { return (S.teste_id && x.teste_id === S.teste_id) || (!x.teste_id && Date.parse(x.criado_em) > lim); }).map(function (x) { return { estado: x.estado }; });
      if (cop) cop.agendar(0);
    }, function () {});
    if (S.teste_id) sb.from('evolui_lab_testes').select('id,status,vencedora,resultado_a,resultado_b').eq('id', S.teste_id).maybeSingle().then(function (r) {
      if (r.error || !r.data) return; var t0 = r.data;
      S.teste = { id: t0.id, status: t0.status, vencedora: t0.vencedora, resultados: { a: +(t0.resultado_a || {}).alcance || 0, b: +(t0.resultado_b || {}).alcance || 0 } };
      if (cop) cop.agendar(0);
    }, function () {});
  }
  // ---------------------------------------------------------------- Fase 5B: salvar e baixar, "Virou vídeo?", resultados e "Sua conta"
  // Tudo manual e privado (RLS do dono). Sem IA e sem rede social conectada: os números são digitados por quem usa.
  // Eventos só com categorias (nunca texto, link ou números). Cálculos e textos vêm de lab-resultados.js e lab-conta.js.
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function hojeIso() { var d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function confirmarModal(titulo, texto, rotuloOk) {
    return new Promise(function (res) {
      var f = document.createElement('div'); f.className = 'modal-fundo';
      f.innerHTML = '<div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="cmT"><h3 id="cmT">' + esc(titulo) + '</h3><p class="sub">' + esc(texto) + '</p><div class="linha"><button class="btn" type="button" id="cmNao">Cancelar</button><button class="btn perigo" type="button" id="cmSim" style="border-color:var(--bad)">' + esc(rotuloOk || 'Confirmar') + '</button></div></div>';
      document.body.appendChild(f); $('#cmNao').focus();
      function fim(v) { f.remove(); document.removeEventListener('keydown', tecla); res(v); }
      function tecla(e) { if (e.key === 'Escape') fim(false); }
      document.addEventListener('keydown', tecla);
      $('#cmNao').onclick = function () { fim(false); }; $('#cmSim').onclick = function () { fim(true); };
      f.addEventListener('click', function (e) { if (e.target === f) fim(false); });
    });
  }
  function baixarArquivo(conteudo, nome, mime) {
    var url = URL.createObjectURL(new Blob([conteudo], { type: mime })), a = document.createElement('a');
    a.href = url; a.download = nome; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
  }
  function optsHtml(lista, atual) { return lista.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (x[0] === atual ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join(''); }
  function numCampo(id, rot, dica) { return '<div class="campo"><label for="' + id + '">' + esc(rot) + '</label><input id="' + id + '" inputmode="numeric" autocomplete="off" maxlength="12"' + (dica ? ' placeholder="' + esc(dica) + '"' : '') + '></div>'; }

  // Botões Salvar / Baixar PDF / Baixar texto dentro da tela Documento. S = estado do editor; A = ponte (salvar, status, D, ctx)
  function docAcoes(S, A) {
    var box = $('#dAcoes'), P = window.EvoluiPDF; if (!box) return;
    box.innerHTML = '<div class="linha"><button class="btn sm cta" type="button" id="dSalvarAgora">Salvar</button><button class="btn sm" type="button" id="dPdf">Baixar PDF</button><button class="btn sm" type="button" id="dTxtBaixar">Baixar texto (.txt)</button></div>' +
      '<label class="chk"><input type="checkbox" id="dComRoteiro"' + (S.formato === 'reel' ? ' checked' : '') + '> Incluir o roteiro por cenas no arquivo</label>' +
      '<p class="muted" style="font-size:13px;margin:0">O documento fica guardado no sistema, na lista “Seus documentos” do Laboratório: dá para voltar a ele depois. O PDF é gerado aqui no seu navegador; nada é enviado.</p>';
    if (S.linhaAtual && !$('#dSalvo').textContent) A.status('Guardado no sistema.');
    function esperar() { return new Promise(function (ok) { var n = 0; (function t() { if (!S.salvando || n++ > 50) ok(); else setTimeout(t, 100); })(); }); }
    $('#dSalvarAgora').onclick = async function () {
      if (!S.texto.trim() && !S.titulo.trim()) { toast('Escreva algo antes de salvar.'); return; }
      var b = this; b.disabled = true; b.textContent = 'Salvando…';
      try { await A.salvar(); await esperar(); } finally { b.disabled = false; b.textContent = 'Salvar'; }
      if (S.indisp) toast('Salvar ainda não está disponível. Baixe o texto para não perder.');
      else if (S.sujo || S.pendente) toast('Não foi possível salvar agora. Seu texto continua na tela; baixe uma cópia para garantir.');
      else { toast('Salvo no sistema às ' + horaCurta() + '.'); registrar('doc_salvo', { origem: 'botao' }); }
    };
    function montar() {
      var com = $('#dComRoteiro').checked && S.texto.trim(), cenas = null, est = S.texto.trim() ? A.D.estimarDuracao(S.texto) : null;
      if (com) { var r = A.D.executarComando('roteiro', S.texto, null, A.ctx()); if (r && r.novo && r.novo.trim()) cenas = r.novo; }
      var fmt = DOC_FMT.filter(function (x) { return x[0] === S.formato; })[0];
      var secoes = [{ titulo: 'Texto atual', texto: S.texto.trim() ? S.texto : '(documento ainda sem texto)' }];
      if (cenas) secoes.push({ titulo: 'Roteiro por cenas', texto: cenas });
      return { roteiro: !!cenas, doc: { titulo: S.titulo.trim() || 'Documento sem título', data: new Date(), rodape: 'Gerado no EvoluiSocial',
        meta: [['Data', data(new Date())], ['Formato', fmt && fmt[0] ? fmt[1] : ''], ['Duração alvo', S.dur ? S.dur + ' s' : ''], ['Duração estimada de fala', est ? est.rotulo : ''], ['Palavras', est ? String(est.palavras) : '']], secoes: secoes } };
    }
    $('#dPdf').onclick = function () {
      if (!P) { toast('O gerador de PDF não carregou. Atualize a página.'); return; }
      try { var m = montar(); baixarArquivo(P.gerar(m.doc).bytes(), P.nomeArquivo(S.titulo, 'pdf', hojeIso()), 'application/pdf'); toast('PDF gerado no seu navegador.'); registrar('doc_pdf_baixado', { roteiro: m.roteiro }); }
      catch (e) { toast('Não foi possível gerar o PDF. Use “Baixar texto” ou imprima a página.'); }
    };
    $('#dTxtBaixar').onclick = function () {
      if (!P) { toast('O gerador não carregou. Atualize a página.'); return; }
      try { var m = montar(); baixarArquivo(P.montarTxt(m.doc), P.nomeArquivo(S.titulo, 'txt', hojeIso()), 'text/plain;charset=utf-8'); toast('Texto baixado.'); registrar('doc_txt_baixado', { roteiro: m.roteiro }); }
      catch (e) { toast('Não foi possível baixar agora.'); }
    };
  }

  // "Virou vídeo?" + publicação + resultados manuais + padrões observados
  async function docVideo(S, A) {
    var box = $('#dVideo'), R = window.EvoluiResultados; if (!box) return;
    if (!R) { box.innerHTML = ''; return; }
    var V = { estado: null, med: [], aberto: null, padroes: null, indisp: false };
    box.innerHTML = '<section class="card virou"><h2 class="tit-sec">Virou vídeo?</h2><p class="muted">Carregando…</p></section>';
    var q = await Promise.all([sb.from('evolui_lab_doc_estado').select('*').eq('doc_id', S.id).maybeSingle(), sb.from('evolui_lab_doc_medicoes').select('*').eq('doc_id', S.id).order('medido_em', { ascending: true })]);
    if (!$('#dVideo') || $('#dVideo') !== box) return;
    if ((q[0].error && docSemTabela(q[0].error)) || (q[1].error && docSemTabela(q[1].error))) { V.indisp = true; }
    else { V.estado = q[0].data || null; V.med = q[1].data || []; }
    function fatoresAgora() { return R.fatoresDoc(S.texto, { formato: S.formato }); }
    async function garantirSalvo() { await A.salvar(); if (!S.linhaAtual) { toast('Escreva algo no documento antes de marcar o andamento.'); return false; } return true; }
    async function gravarEstado(campos) {
      var linha = Object.assign({ user_id: st.user.id, doc_id: S.id, status: (V.estado && V.estado.status) || 'ideia' }, campos);
      var r = await sb.from('evolui_lab_doc_estado').upsert(linha, { onConflict: 'user_id,doc_id' }).select('*').single();
      if (r.error) throw r.error; V.estado = r.data; return r.data;
    }
    async function mudarStatus(novo) {
      if (novo === 'publicado') { V.aberto = 'pub'; desenhar(); var f = $('#vRede'); if (f) f.focus(); return; }
      if (!(await garantirSalvo())) return;
      try {
        var c = { status: novo }; if (/^(pronto_gravar|gravado)$/.test(novo)) c.fatores = fatoresAgora();
        await gravarEstado(c); V.aberto = null; V.padroes = null; registrar('doc_status_mudou', { status: novo }); toast('Andamento guardado.'); desenhar();
      } catch (e) { toast(docSemTabela(e) ? 'Esse recurso ainda não está disponível nesta conta.' : 'Não foi possível guardar agora. Tente de novo.'); }
    }
    async function salvarPub() {
      var v = R.validarPublicacao({ rede: $('#vRede').value, url: $('#vUrl').value, publicado_em: $('#vData').value }), er = $('#vErroPub');
      if (!v.ok) { er.textContent = v.erros.join(' '); return; }
      er.textContent = ''; if (!(await garantirSalvo())) return;
      var b = $('#vPubOk'); b.disabled = true;
      try {
        await gravarEstado({ status: 'publicado', rede: v.valores.rede, url: v.valores.url, publicado_em: v.valores.publicado_em, fatores: fatoresAgora() });
        V.aberto = null; V.padroes = null; registrar('doc_status_mudou', { status: 'publicado' }); registrar('pub_registrada', { rede: v.valores.rede }); toast('Publicação registrada. Agora você pode registrar os resultados.'); desenhar();
      } catch (e) { b.disabled = false; er.textContent = docSemTabela(e) ? 'Esse recurso ainda não está disponível nesta conta.' : 'Não foi possível guardar agora. Tente de novo.'; }
    }
    async function salvarMed() {
      var raw = { medido_em: $('#mData').value, janela: $('#mJan').value, retencao_pct: $('#mRet').value, duracao_video_seg: $('#mDur').value };
      R.CAMPOS_INT.forEach(function (c) { raw[c[0]] = $('#m_' + c[0]).value; });
      var v = R.validarMedicao(raw), er = $('#mErro');
      if (!v.ok) { er.textContent = v.erros.join(' '); return; }
      er.textContent = ''; var b = $('#mOk'); b.disabled = true;
      var linha = Object.assign({ user_id: st.user.id, doc_id: S.id, fonte: 'manual' }, v.valores);
      var r = await sb.from('evolui_lab_doc_medicoes').insert(linha).select('*').single();
      if (r.error) { b.disabled = false; er.textContent = 'Não foi possível guardar a medição agora.'; return; }
      V.med.push(r.data); V.aberto = null; V.padroes = null; registrar('metrica_registrada', { origem: 'manual', janela: v.valores.janela });
      toast(v.avisos.length ? 'Medição guardada. ' + v.avisos[0] : 'Medição guardada.'); desenhar();
    }
    async function apagarMed(id) {
      if (!(await confirmarModal('Apagar esta medição?', 'Só esta linha de números sai da lista. O documento e as outras medições continuam.', 'Apagar'))) return;
      var r = await sb.from('evolui_lab_doc_medicoes').delete().eq('id', id);
      if (r.error) { toast('Não foi possível apagar.'); return; }
      V.med = V.med.filter(function (m) { return m.id !== id; }); V.padroes = null; desenhar();
    }
    async function carregarPadroes() {
      var el = $('#vPad'); if (!el) return;
      el.innerHTML = '<p class="muted">Calculando…</p>';
      var z = await Promise.all([sb.from('evolui_lab_doc_estado').select('doc_id,status,fatores').eq('status', 'publicado').limit(500), sb.from('evolui_lab_doc_medicoes').select('*').limit(2000)]);
      if (z[0].error || z[1].error) { el.innerHTML = '<p class="muted">Não foi possível calcular agora.</p>'; return; }
      V.padroes = R.padroes(R.itensParaPadroes(z[0].data, z[1].data)); pintarPadroes();
    }
    function pintarPadroes() {
      var el = $('#vPad'), p = V.padroes; if (!el || !p) return;
      el.innerHTML = '<p class="muted" style="margin:0">Conteúdos seus com resultado registrado: <b>' + p.amostra + '</b></p>' +
        (p.observacoes.length ? '<ul class="leitura">' + p.observacoes.map(function (o) { return '<li>' + esc(o.texto) + '</li>'; }).join('') + '</ul>' : '') + '<p class="muted" style="font-size:13px;margin:0">' + esc(p.aviso) + '</p>';
    }
    function tabela() {
      var ev = R.evolucao(V.med), melhor = R.melhorMedicao(V.med);
      if (!ev.length) return '';
      return '<div class="tab-rolagem"><table class="tab"><caption class="so-leitor">Medições registradas</caption><thead><tr><th scope="col">Quando</th><th scope="col">Visualizações</th><th scope="col">Alcance</th><th scope="col">Curtidas</th><th scope="col">Comentários</th><th scope="col">Compart.</th><th scope="col">Salvam.</th><th scope="col">Taxa de engajamento</th><th scope="col">Desde a anterior</th><th scope="col"><span class="so-leitor">Apagar</span></th></tr></thead><tbody>' + ev.map(function (e) {
        var m = e.m, ant = e.difVisualizacoes == null ? '—' : (e.difVisualizacoes >= 0 ? '+' : '−') + R.fmtInt(Math.abs(e.difVisualizacoes)) + ' vis.' + (e.difTaxaPontos != null ? ', taxa ' + (e.difTaxaPontos >= 0 ? '+' : '−') + Math.abs(e.difTaxaPontos).toFixed(1).replace('.', ',') + ' p.p.' : '');
        return '<tr><th scope="row">' + esc(m.janela !== 'avulsa' ? R.rotulo(R.JANELAS, m.janela) + ' · ' : '') + esc(R.dataBR(m.medido_em)) + '</th><td>' + R.fmtInt(m.visualizacoes) + '</td><td>' + R.fmtInt(m.alcance) + '</td><td>' + R.fmtInt(m.curtidas) + '</td><td>' + R.fmtInt(m.comentarios) + '</td><td>' + R.fmtInt(m.compartilhamentos) + '</td><td>' + R.fmtInt(m.salvamentos) + '</td><td>' + R.fmtPct(e.taxa) + (melhor && melhor.m === m && ev.length > 1 ? ' <span class="pill">maior taxa</span>' : '') + '</td><td>' + esc(ant) + '</td><td><button class="btn ghost sm" type="button" data-vdel="' + esc(m.id) + '" aria-label="Apagar medição de ' + esc(R.dataBR(m.medido_em)) + '">Apagar</button></td></tr>';
      }).join('') + '</tbody></table></div>';
    }
    function desenhar() {
      if (!$('#dVideo') || $('#dVideo') !== box) return;
      if (V.indisp) { box.innerHTML = '<section class="card virou"><h2 class="tit-sec">Virou vídeo?</h2><p class="muted">O acompanhamento de resultados ainda não está disponível nesta conta.</p></section>'; return; }
      var e = V.estado, atual = e && e.status, pub = atual === 'publicado';
      var h = '<section class="card virou" aria-labelledby="vTit"><h2 class="tit-sec" id="vTit">Virou vídeo?</h2><p class="muted" style="margin:0">Marque em que ponto este documento está. O andamento fica guardado no sistema junto com o documento.</p>' +
        '<div class="chips" role="group" aria-label="Andamento do documento">' + R.STATUS.map(function (s) { return '<button type="button" class="chip" data-vst="' + s[0] + '" aria-pressed="' + (atual === s[0]) + '">' + esc(s[1]) + '</button>'; }).join('') + '</div>';
      if (!e) h += '<p class="muted" style="font-size:13px;margin:0">Ainda sem andamento marcado.</p>';
      if (pub && V.aberto !== 'pub') h += '<p style="margin:0">Publicado' + (e.rede ? ' no <b>' + esc(R.rotulo(R.REDES_PUB, e.rede)) + '</b>' : '') + (e.publicado_em ? ' em ' + esc(R.dataBR(e.publicado_em)) : '') + '. ' + (urlSegura(e.url) ? '<a href="' + esc(urlSegura(e.url)) + '" target="_blank" rel="noopener noreferrer">Abrir o post</a> · ' : '') + '<button class="btn ghost sm" type="button" id="vEditaPub">Editar</button></p>';
      if (V.aberto === 'pub') h += '<div class="vform" role="group" aria-label="Dados da publicação"><div class="grade3"><div class="campo"><label for="vRede">Rede</label><select id="vRede">' + optsHtml(R.REDES_PUB, (e && e.rede) || (st.redes[0] && st.redes[0].rede) || 'instagram') + '</select></div>' +
        '<div class="campo"><label for="vUrl">Link do post (opcional)</label><input id="vUrl" type="url" inputmode="url" autocomplete="off" placeholder="https://" value="' + esc((e && e.url) || '') + '"></div>' +
        '<div class="campo"><label for="vData">Data de publicação</label><input id="vData" type="date" max="' + hojeIso() + '" value="' + esc((e && e.publicado_em) || hojeIso()) + '"></div></div>' +
        '<div class="linha"><button class="btn sm cta" type="button" id="vPubOk">Guardar publicação</button><button class="btn sm" type="button" id="vPubNao">Cancelar</button><span class="erro-campo" id="vErroPub" role="alert"></span></div></div>';
      if (pub) {
        var fat = R.descreverFatores(e.fatores && e.fatores.gancho ? e.fatores : fatoresAgora());
        h += '<h3 class="tit-sub">Resultados</h3><p class="muted" style="margin:0;font-size:14px">Digite os números que o app da rede mostra. Dá para registrar várias vezes (por exemplo, 24 horas e 7 dias depois). A Evolui não lê sua conta e não promete resultado.</p>';
        h += '<div class="linha"><button class="btn sm cta" type="button" id="mNova">Registrar medição</button></div>';
        if (V.aberto === 'med') {
          var jan = V.med.length === 0 ? '24h' : V.med.length === 1 ? '7d' : 'avulsa';
          h += '<div class="vform" role="group" aria-label="Nova medição"><div class="grade3"><div class="campo"><label for="mData">Data da medição</label><input id="mData" type="date" max="' + hojeIso() + '" value="' + hojeIso() + '"></div><div class="campo"><label for="mJan">Momento</label><select id="mJan">' + optsHtml(R.JANELAS, jan) + '</select></div></div>' +
            '<div class="grade3">' + R.CAMPOS_INT.map(function (c) { return numCampo('m_' + c[0], c[1]); }).join('') + numCampo('mRet', 'Retenção média % (opcional)', 'ex.: 42,5') + numCampo('mDur', 'Duração do vídeo em segundos (opcional)', 'ex.: 30') + '</div>' +
            '<div class="linha"><button class="btn sm cta" type="button" id="mOk">Guardar medição</button><button class="btn sm" type="button" id="mNao">Cancelar</button><span class="erro-campo" id="mErro" role="alert"></span></div></div>';
        }
        h += tabela();
        if (V.med.length) h += '<div class="leitura-box"><h3 class="tit-sub">Leitura dos números</h3><ul class="leitura">' + R.leitura(V.med).map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul><p class="muted" style="font-size:13px;margin:0">Taxa de engajamento = (curtidas + comentários + compartilhamentos + salvamentos) ÷ visualizações. É uma descrição dos números, não uma explicação do porquê, e não serve de previsão.</p></div>';
        else if (V.aberto !== 'med') h += '<p class="muted" style="margin:0">Ainda sem medições. Quando tiver os números, registre aqui.</p>';
        h += '<div class="leitura-box"><h3 class="tit-sub">O que este documento tinha</h3><ul class="leitura">' + fat.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul><p class="muted" style="font-size:13px;margin:0">' + (e.fatores && e.fatores.gancho ? 'Registrado quando você marcou a publicação.' : 'Lido do texto atual.') + ' Serve para você comparar com os resultados depois, sem concluir nada sozinho.</p></div>';
        h += '<details class="mais" id="vPadDet"' + (V.padroes ? ' open' : '') + '><summary>Padrões observados nos seus conteúdos</summary><div id="vPad" style="display:flex;flex-direction:column;gap:8px;margin-top:8px"></div></details>';
      } else if (atual) h += '<p class="muted" style="font-size:13px;margin:0">Os resultados aparecem aqui depois que você marcar “Publicado”.</p>';
      box.innerHTML = h + '</section>';
      $$('[data-vst]', box).forEach(function (b) { b.onclick = function () { mudarStatus(b.dataset.vst); }; });
      var x;
      if ((x = $('#vEditaPub'))) x.onclick = function () { V.aberto = 'pub'; desenhar(); };
      if ((x = $('#vPubOk'))) x.onclick = salvarPub;
      if ((x = $('#vPubNao'))) x.onclick = function () { V.aberto = null; desenhar(); };
      if ((x = $('#mNova'))) x.onclick = function () { V.aberto = 'med'; desenhar(); var d = $('#m_visualizacoes'); if (d) d.focus(); };
      if ((x = $('#mOk'))) x.onclick = salvarMed;
      if ((x = $('#mNao'))) x.onclick = function () { V.aberto = null; desenhar(); };
      $$('[data-vdel]', box).forEach(function (b) { b.onclick = function () { apagarMed(b.dataset.vdel); }; });
      if ((x = $('#vPadDet'))) { x.addEventListener('toggle', function () { if (x.open && !V.padroes) carregarPadroes(); }); if (V.padroes) pintarPadroes(); }
    }
    desenhar();
  }

  // Lista "Seus documentos": busca, ordenação, abrir, duplicar e apagar com confirmação
  var DOC_STATUS_ROT = { ideia: 'Ideia', escrevendo: 'Escrevendo', pronto_gravar: 'Pronto para gravar', gravado: 'Gravado', publicado: 'Publicado', nao_virou: 'Não virou vídeo' };
  async function listaDocs(box) {
    var z = await Promise.all([sb.from('evolui_lab_docs').select('doc_id,titulo,palavras,formato,atualizado_em').eq('versao', 1).order('atualizado_em', { ascending: false }).limit(300), sb.from('evolui_lab_doc_estado').select('doc_id,status').limit(500)]);
    if (!$('#labDocs')) return;
    var r = z[0], stMap = {}; if (!z[1].error) (z[1].data || []).forEach(function (x) { stMap[x.doc_id] = x.status; });
    if (r.error) { box.innerHTML = '<p class="muted">' + (docSemTabela(r.error) ? 'Os documentos ainda não estão disponíveis nesta conta.' : 'Não foi possível carregar os documentos.') + '</p>'; return; }
    if (!r.data.length) { box.innerHTML = '<div class="vazio" style="grid-column:1/-1"><h3>Nenhum documento ainda</h3><p>Abra um documento para escrever com sugestões por regras, comparar antes e depois, guardar versões e baixar em PDF.</p></div>'; return; }
    var dados = r.data, busca = '', ordem = 'recentes';
    box.innerHTML = '<div class="doc-ctrl" style="grid-column:1/-1"><div class="campo"><label for="docBusca">Buscar</label><input id="docBusca" type="search" placeholder="Título do documento" autocomplete="off"></div>' +
      '<div class="campo"><label for="docOrdem">Ordenar por</label><select id="docOrdem"><option value="recentes">Mais recentes</option><option value="antigos">Mais antigos</option><option value="titulo">Título (A–Z)</option><option value="palavras">Mais palavras</option></select></div></div><div class="lista-grade" id="docItens" style="grid-column:1/-1"></div>';
    function lista() {
      var q = norm(busca), L = dados.filter(function (x) { return !q || norm(x.titulo || 'documento sem título').indexOf(q) >= 0; });
      L.sort(function (a, b) {
        if (ordem === 'antigos') return String(a.atualizado_em).localeCompare(String(b.atualizado_em));
        if (ordem === 'titulo') return norm(a.titulo || 'zzz').localeCompare(norm(b.titulo || 'zzz'));
        if (ordem === 'palavras') return (b.palavras || 0) - (a.palavras || 0);
        return String(b.atualizado_em).localeCompare(String(a.atualizado_em));
      });
      $('#docItens').innerHTML = L.length ? L.map(function (x) {
        var sx = stMap[x.doc_id];
        return '<div class="item"><div style="min-width:0"><div class="t">' + esc(x.titulo || 'Documento sem título') + '</div><div class="d">' + esc(x.palavras) + ' palavra(s) · ' + dataHora(x.atualizado_em) + (sx ? ' <span class="pill">' + esc(DOC_STATUS_ROT[sx] || sx) + '</span>' : '') + '</div></div><div class="acoes"><button class="btn sm" data-abrir="' + esc(x.doc_id) + '">Abrir</button><button class="btn sm ghost" data-dup="' + esc(x.doc_id) + '">Duplicar</button><button class="btn sm ghost perigo" data-apagar-doc="' + esc(x.doc_id) + '">Apagar</button></div></div>';
      }).join('') : '<p class="muted">Nenhum documento com esse título.</p>';
    }
    lista();
    $('#docBusca').oninput = function () { busca = this.value; lista(); };
    $('#docOrdem').onchange = function () { ordem = this.value; lista(); };
    box.onclick = async function (e) {
      var a = e.target.closest('[data-abrir]'), d = e.target.closest('[data-apagar-doc]'), u = e.target.closest('[data-dup]');
      if (a) ir('laboratorio', { doc: { doc_id: a.dataset.abrir } });
      if (u) {
        u.disabled = true;
        var o = await sb.from('evolui_lab_docs').select('titulo,corpo,formato,duracao_seg,palavras').eq('doc_id', u.dataset.dup).eq('versao', 1).maybeSingle();
        if (o.error || !o.data) { u.disabled = false; toast('Não foi possível duplicar.'); return; }
        var nid = uuid(), base = { user_id: st.user.id, doc_id: nid, titulo: ('Cópia de ' + (o.data.titulo || 'documento')).slice(0, 80), corpo: o.data.corpo, formato: o.data.formato, duracao_seg: o.data.duracao_seg, palavras: o.data.palavras || 0 };
        var i0 = await sb.from('evolui_lab_docs').insert(Object.assign({ versao: 0, origem: 'original' }, base));
        var i1 = i0.error ? i0 : await sb.from('evolui_lab_docs').insert(Object.assign({ versao: 1, origem: 'autosave' }, base));
        if (i1.error) { u.disabled = false; if (!i0.error) await sb.from('evolui_lab_docs').delete().eq('doc_id', nid); toast('Não foi possível duplicar.'); return; }
        registrar('doc_duplicado', {}); toast('Documento duplicado. A cópia começa sem andamento nem resultados.'); listaDocs(box);
      }
      if (d) {
        var id = d.dataset.apagarDoc;
        if (!(await confirmarModal('Apagar este documento?', 'Ele sai da sua lista junto com todas as versões (inclusive o original), o andamento e os resultados registrados. Isso não pode ser desfeito.', 'Apagar documento'))) return;
        await sb.from('evolui_lab_doc_estado').delete().eq('doc_id', id); // apaga também as medições (cascata); ignora se a tabela ainda não existir
        var x = await sb.from('evolui_lab_docs').delete().eq('doc_id', id);
        if (x.error) toast('Não foi possível apagar.'); else { registrar('doc_apagado', {}); toast('Documento apagado.'); listaDocs(box); }
      }
    };
  }

  // Painel "Sua conta" (topo do Laboratório): números do perfil digitados por quem usa, com histórico por rede
  async function painelConta(box) {
    var C = window.EvoluiConta; if (!C || !box) return;
    var pl = plano(), p = st.perfil || {};
    box.innerHTML = '<section class="card conta"><h2 class="tit-sec">Sua conta</h2><p class="muted">Carregando…</p></section>';
    var z = await Promise.all([sb.from('evolui_redes').select('id,rede,usuario,criado_em').eq('user_id', st.user.id), sb.from('evolui_rede_medicoes').select('*').eq('user_id', st.user.id).order('medido_em', { ascending: false }).limit(800)]);
    if (!$('#labConta')) return;
    var redes = z[0].data || [], semTabela = !!z[1].error && docSemTabela(z[1].error), med = z[1].error ? [] : (z[1].data || []), abertaRede = null, histRede = {};
    var pr = C.planoRedes(pl, redes);
    function porRede(rede) { return med.filter(function (m) { return m.rede === rede; }); }
    function cab() {
      var ramo = RAMO[p.ramo], obj = OBJ.filter(function (o) { return o[0] === p.objetivo; })[0];
      return '<div class="entre"><div><h2 class="tit-sec" id="contaT">Sua conta</h2><p class="muted" style="margin:2px 0 0;font-size:14px">' + esc([nomeCurto(), ramo ? ramo[1] : '', obj ? 'Objetivo: ' + obj[1] : ''].filter(Boolean).join(' · ')) + '</p></div><span class="pill">Plano ' + esc(NOME_PLANO[pl]) + '</span></div>';
    }
    function cartao(r) {
      var lista = porRede(r.rede), res = C.resumoRede(lista), nome = (REDES.filter(function (x) { return x[0] === r.rede; })[0] || [])[1] || r.rede, base = (REDES.filter(function (x) { return x[0] === r.rede; })[0] || [])[3] || '';
      var h = '<article class="rede-card" aria-label="' + esc(nome) + '"><div class="entre"><div><b>' + esc(nome) + '</b> <a href="' + esc(base + r.usuario) + '" target="_blank" rel="noopener noreferrer">@' + esc(r.usuario) + '</a></div>' +
        '<button class="btn sm" type="button" data-conta-nova="' + esc(r.rede) + '">' + (res.vazio ? 'Digitar números' : 'Atualizar números') + '</button></div>';
      if (res.vazio) h += '<p class="muted" style="margin:0">' + esc(res.texto) + '</p>';
      else {
        var a = res.atual;
        h += '<div class="conta-nums"><div><span class="conta-n">' + C.fmtInt(a.seguidores) + '</span><span class="conta-l">seguidores</span></div><div><span class="conta-n sm">' + C.fmtInt(a.seguindo) + '</span><span class="conta-l">seguindo</span></div><div><span class="conta-n sm">' + C.fmtInt(a.publicacoes) + '</span><span class="conta-l">publicações</span></div></div>' +
          '<p style="margin:0">' + esc(res.texto) + '</p><p class="muted" style="margin:0;font-size:13px">Números de ' + esc(C.dataBR(a.medido_em)) + ', digitados por você.</p>';
        if (pr.historico) {
          var per = C.variacaoPeriodo(lista, 30), sp = C.sparkline(lista, { titulo: 'Evolução de seguidores no ' + nome, id: r.rede });
          if (per) h += '<p style="margin:0">Últimos 30 dias: ' + esc(per.texto) + '</p>';
          if (sp) h += '<div class="spark-box">' + sp + '</div>'; else h += '<p class="muted" style="margin:0;font-size:13px">O gráfico aparece a partir da segunda medição.</p>';
          h += '<details class="mais"><summary>Histórico (' + lista.length + ')</summary><div class="tab-rolagem"><table class="tab"><thead><tr><th scope="col">Data</th><th scope="col">Seguidores</th><th scope="col">Seguindo</th><th scope="col">Publicações</th><th scope="col"><span class="so-leitor">Apagar</span></th></tr></thead><tbody>' +
            C.ordenar(lista).reverse().slice(0, 60).map(function (m) { return '<tr><th scope="row">' + esc(C.dataBR(m.medido_em)) + '</th><td>' + C.fmtInt(m.seguidores) + '</td><td>' + C.fmtInt(m.seguindo) + '</td><td>' + C.fmtInt(m.publicacoes) + '</td><td><button class="btn ghost sm" type="button" data-conta-del="' + esc(m.id) + '" aria-label="Apagar medição de ' + esc(C.dataBR(m.medido_em)) + '">Apagar</button></td></tr>'; }).join('') + '</tbody></table></div></details>';
        }
      }
      if (abertaRede === r.rede) {
        var u = res.atual || {};
        h += '<div class="vform" role="group" aria-label="Números do perfil no ' + esc(nome) + '"><div class="campo"><label for="cData">Data</label><input id="cData" type="date" max="' + hojeIso() + '" value="' + hojeIso() + '"></div><div class="grade3">' + numCampo('cSeg', 'Seguidores', u.seguidores != null ? 'último: ' + u.seguidores : '') + numCampo('cSgd', 'Seguindo (opcional)', u.seguindo != null ? 'último: ' + u.seguindo : '') + numCampo('cPub', 'Publicações (opcional)', u.publicacoes != null ? 'último: ' + u.publicacoes : '') + '</div>' +
          '<div class="linha"><button class="btn sm cta" type="button" id="cOk">Guardar</button><button class="btn sm" type="button" id="cNao">Cancelar</button><span class="erro-campo" id="cErro" role="alert"></span></div></div>';
      }
      return h + '</article>';
    }
    function desenhar() {
      if (!$('#labConta')) return;
      var h = '<section class="card conta" aria-labelledby="contaT">' + cab();
      h += '<p class="muted conta-aviso">' + esc(C.AVISO_MANUAL) + '</p>';
      if (semTabela) h += '<p class="muted">O acompanhamento de números ainda não está disponível nesta conta.</p>';
      if (!redes.length) h += '<div class="vazio"><h3>Nenhuma rede cadastrada</h3><p>Cadastre o seu perfil no Instagram, TikTok ou YouTube para acompanhar seguidores e a evolução da conta.</p><button class="btn cta" type="button" id="contaCad">Cadastrar minha rede</button></div>';
      else if (!semTabela) h += '<div class="redes-grade">' + pr.visiveis.map(cartao).join('') + '</div>';
      else h += '<div class="redes-grade">' + pr.visiveis.map(function (r) { return '<article class="rede-card"><b>' + esc(r.rede) + '</b> @' + esc(r.usuario) + '</article>'; }).join('') + '</div>';
      if (redes.some(function (r) { return r.rede === 'youtube'; })) h += '<p class="muted conta-aviso">' + esc(C.AVISO_YOUTUBE) + '</p>';
      if (!pr.historico) {
        h += '<div class="conta-trava"><b>No Pro você acompanha mais</b><ul>' + C.GANHOS_PRO.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>' +
          (pr.bloqueadas.length ? '<p class="muted" style="margin:0;font-size:13px">Também cadastradas e liberadas no Pro: ' + pr.bloqueadas.map(function (r) { return esc((C.REDES[r.rede]) || r.rede); }).join(', ') + '.</p>' : '') +
          '<button class="btn sm cta" type="button" id="contaPlano">Ver planos</button></div>';
      }
      box.innerHTML = h + '</section>';
      var x;
      if ((x = $('#contaCad'))) x.onclick = function () { abrirOnboarding(true); };
      if ((x = $('#contaPlano'))) x.onclick = function () { abrirPlanos('conta', 'pro'); registrar('bloqueado_visto', { origem: 'conta' }); };
      $$('[data-conta-nova]', box).forEach(function (b) { b.onclick = function () { abertaRede = b.dataset.contaNova; desenhar(); var i = $('#cSeg'); if (i) i.focus(); }; });
      if ((x = $('#cNao'))) x.onclick = function () { abertaRede = null; desenhar(); };
      if ((x = $('#cOk'))) x.onclick = async function () {
        var v = C.validarMedicaoRede({ medido_em: $('#cData').value, seguidores: $('#cSeg').value, seguindo: $('#cSgd').value, publicacoes: $('#cPub').value }, hojeIso()), er = $('#cErro');
        if (!v.ok) { er.textContent = v.erros.join(' '); return; }
        er.textContent = ''; this.disabled = true;
        var r = await sb.from('evolui_rede_medicoes').upsert(Object.assign({ user_id: st.user.id, rede: abertaRede, fonte: 'manual' }, v.valores), { onConflict: 'user_id,rede,medido_em' }).select('*').single();
        if (r.error) { this.disabled = false; er.textContent = docSemTabela(r.error) ? 'Esse recurso ainda não está disponível nesta conta.' : 'Não foi possível guardar agora.'; return; }
        med = med.filter(function (m) { return m.id !== r.data.id; }); med.push(r.data); registrar('rede_medida', { rede: abertaRede, origem: 'manual' });
        abertaRede = null; toast('Números guardados.'); desenhar();
      };
      $$('[data-conta-del]', box).forEach(function (b) { b.onclick = async function () {
        if (!(await confirmarModal('Apagar esta medição?', 'Só esta linha do histórico sai. As outras continuam.', 'Apagar'))) return;
        var r = await sb.from('evolui_rede_medicoes').delete().eq('id', b.dataset.contaDel);
        if (r.error) { toast('Não foi possível apagar.'); return; }
        med = med.filter(function (m) { return m.id !== b.dataset.contaDel; }); desenhar();
      }; });
    }
    desenhar();
  }

  // ---------------------------------------------------------------- perfil
  async function telaPerfil() {
    var p = st.perfil || {}, pl = plano(), ramo = RAMO[p.ramo];
    var c = $('#conteudo');
    c.innerHTML = '<section class="card destaque"><div class="entre"><div class="perfil-topo">' + avatarHTML() + '<div style="min-width:0"><h1 class="tit" style="color:var(--gelo);font-size:clamp(24px,2.6vw,32px)">' + esc(p.nome || nomeCurto()) + '</h1><p class="muted" style="margin:0">' + esc(ramo ? ramo[1] : 'Ramo não informado') + (p.cidade ? ' · ' + esc(p.cidade) + '/' + esc(p.uf) : '') + '</p></div></div>' +
      '<button class="btn sm" id="planoBtn" >Plano ' + NOME_PLANO[pl] + (p.plano_ate ? ' · até ' + data(p.plano_ate) : '') + (pl === 'free' ? ' · fazer upgrade' : '') + '</button></div>' +
      '<div class="nivel" id="nivel"><div class="entre"><b id="nivelNome">Calculando seu avanço…</b><span class="muted" id="nivelTxt"></span></div><div class="barra"><i id="nivelBarra" style="width:0"></i></div></div></section>' +
      '<section class="numeros" id="nums"><div><b>—</b><span>pesquisas este mês</span></div><div><b>—</b><span>pesquisas no total</span></div><div><b>—</b><span>itens salvos</span></div><div><b>—</b><span>testes no laboratório</span></div></section>' +
      '<section class="card" id="meuPerfil"><h3>Meu perfil</h3><p class="muted">Carregando…</p></section>' +
      '<div class="perfil-grade"><div style="display:flex;flex-direction:column;gap:18px;min-width:0">' +
      '<section class="card"><h3>Próximos passos</h3><ul class="metas" id="metas"></ul></section>' +
      '<section class="card' + (pl === 'free' ? ' travada' : '') + '" id="cardLocal"><div class="entre"><h3>Seu mercado no mapa</h3><span class="kicker">OpenStreetMap</span></div><div id="local"><p class="muted">Carregando…</p></div></section>' +
      '<section class="card"><h3>Pagamentos</h3><div id="pags"><p class="muted">Carregando…</p></div></section></div>' +
      '<div style="display:flex;flex-direction:column;gap:18px;min-width:0">' +
      '<section class="card"><div class="entre"><h3>Suas redes</h3><button class="btn sm ghost" id="editar1">Editar</button></div><div class="redes">' + (st.redes.length ? st.redes.map(function (r) {
        var R = REDES.find(function (x) { return x[0] === r.rede; }); return '<a class="rede" href="' + R[3] + encodeURIComponent(r.usuario) + '" target="_blank" rel="noopener"><span class="ico ' + r.rede + '">' + R[2] + '</span><span class="h">' + R[1] + ' · @' + esc(r.usuario) + '</span></a>';
      }).join('') : '<p class="muted">Nenhuma rede informada.</p>') + '</div></section>' +
      '<section class="card" id="cardImportar"><h3>Trazer dados do TikTok e do YouTube</h3><p class="sub">Sem senha e sem ligar sua conta: baixe o relatório (CSV) na própria rede e envie aqui. O arquivo é lido no seu navegador; guardamos só título, link, data e os números de cada vídeo.</p>' +
      '<div class="linha"><select id="impRede" aria-label="Rede do relatório"><option value="youtube">YouTube</option><option value="tiktok">TikTok</option></select><input type="file" id="impArq" accept=".csv,text/csv" aria-label="Arquivo CSV do relatório"></div><div id="impPrevia" aria-live="polite"></div>' +
      '<details class="mais"><summary>Como baixar o relatório</summary><p class="sub" style="font-size:14px">No YouTube Studio, abra Analytics e procure a opção de exportar os dados (CSV). No TikTok Studio, abra Analytics e procure a opção de baixar os dados. Os nomes dos menus mudam com o tempo. O arquivo precisa ter uma coluna com o link (ou o ID, no YouTube) e ao menos uma coluna de números, como visualizações.</p></details>' +
      '<p class="sub" style="font-size:13px;margin:0">Ainda não lemos seu canal automaticamente: isso depende de aprovação do TikTok e do Google. Quando houver, esta tela continua valendo como alternativa.</p><div id="impResumo"></div></section>' +
      '<section class="card" id="cardMem"><h3>Memória</h3><div id="memBox"><p class="muted">Carregando…</p></div></section>' +
      '<section class="card" id="cardCop"><h3>O que a Evolui aprendeu sobre seu jeito de criar</h3><div id="copCartao"><p class="muted">Carregando…</p></div></section>' +
      '<section class="card"><h3>Personalização</h3><button class="interruptor" id="persBtn" role="switch" aria-checked="' + (p.personalizar !== false) + '"><span>Usar meu uso e minhas respostas do dia para ajustar as ideias</span><span class="tg" aria-hidden="true"></span></button><p class="sub" style="font-size:14px">Usamos só o que você faz aqui dentro (buscas, ideias salvas, respostas). Nada é vendido nem compartilhado. Desligando, paramos de registrar e as ideias voltam ao padrão.</p></section>' +
      '<section class="card"><h3>Conta e dados</h3><p class="sub">Seus dados ficam só com você. Você pode baixar ou apagar tudo quando quiser.</p><div class="linha"><button class="btn" id="editar2">Editar perfil</button><button class="btn" id="baixar">Baixar meus dados</button><button class="btn ghost perigo" id="excluir">Apagar meus dados</button><button class="btn ghost" id="sair">Sair</button></div></section>' +
      '</div></div>';
    $('#editar1').onclick = $('#editar2').onclick = function () { abrirOnboarding(true); };
    $('#planoBtn').onclick = function () { abrirPlanos('perfil'); };
    $('#sair').onclick = async function () { await sb.auth.signOut(); location.href = '/evoluisocial/'; };
    $('#baixar').onclick = baixarDados;
    $('#excluir').onclick = confirmarExclusao;
    importarDados();
    copCartao(); painelMemoria($('#memBox'));
    $('#persBtn').onclick = async function () {
      var novo = this.getAttribute('aria-checked') !== 'true', b = this;
      var x = await sb.from('evolui_perfis').update({ personalizar: novo }).eq('id', st.user.id);
      if (x.error) return toast('Não foi possível salvar.');
      st.perfil.personalizar = novo; st.paraVoce = null; st.copInf = null; b.setAttribute('aria-checked', String(novo)); copCartao(); painelMemoria($('#memBox'));
      toast(novo ? 'Personalização ligada.' : 'Personalização desligada.');
    };

    meuPerfil();
    var q = await Promise.all([
      usoMes(),
      sb.from('evolui_uso').select('buscas'),
      sb.from('evolui_salvos').select('id', { count: 'exact', head: true }),
      sb.from('evolui_lab_testes').select('id', { count: 'exact', head: true }),
      sb.from('evolui_lab_testes').select('id', { count: 'exact', head: true }).eq('status', 'concluido'),
      sb.from('evolui_salvos').select('id', { count: 'exact', head: true }).eq('tipo', 'ideia'),
      sb.from('evolui_respostas').select('id', { count: 'exact', head: true }),
      sb.from('evolui_pagamentos').select('plano,ciclo,valor_centavos,status,metodo,pago_em,criado_em').order('criado_em', { ascending: false }).limit(12)
    ]);
    if (!$('#nums')) return;
    var mes = q[0] || 0, total = ((q[1].data) || []).reduce(function (s, x) { return s + (x.buscas || 0); }, 0);
    var n = [mes, total, q[2].count || 0, q[3].count || 0, q[4].count || 0, q[5].count || 0, q[6].count || 0];
    $('#nums').innerHTML = '<div><b>' + n[0] + '<small style="font-size:14px;color:var(--muted)">/' + LIMITE[pl] + '</small></b><span>pesquisas este mês</span></div><div><b>' + n[1] + '</b><span>pesquisas no total</span></div><div><b>' + n[2] + '</b><span>itens salvos</span></div><div><b>' + n[3] + '</b><span>testes no laboratório</span></div>';
    var metas = [
      [!!(p.onboarding_ok && st.redes.length), 'Completar o perfil com pelo menos 1 rede', function () { abrirOnboarding(true); }],
      [n[1] >= 1, 'Fazer a primeira pesquisa', function () { ir('buscar'); }],
      [n[5] >= 1, 'Salvar uma ideia de post', function () { ir('buscar'); }],
      [n[6] >= 3, 'Responder 3 perguntas do dia', function () { perguntaDoDia(true); }],
      [n[3] >= 1, 'Criar um teste no laboratório', function () { ir('laboratorio'); }],
      [n[1] >= 10, 'Chegar a 10 pesquisas', function () { ir('buscar'); }],
      [n[4] >= 1, 'Concluir um teste com resultado real', function () { ir('laboratorio'); }]
    ];
    var feitas = metas.filter(function (m) { return m[0]; }).length;
    var NIVEIS = ['Começando', 'Começando', 'Em evolução', 'Em evolução', 'Constante', 'Constante', 'Estrategista', 'Estrategista'];
    $('#nivelNome').textContent = 'Nível: ' + NIVEIS[feitas];
    $('#nivelTxt').textContent = feitas + ' de ' + metas.length + ' passos concluídos';
    requestAnimationFrame(function () { var b = $('#nivelBarra'); if (b) b.style.width = Math.round(feitas / metas.length * 100) + '%'; });
    $('#metas').innerHTML = metas.map(function (m, i) { return '<li class="' + (m[0] ? 'ok' : '') + '"><span class="m">' + (m[0] ? '✓' : i + 1) + '</span>' + (m[0] ? esc(m[1]) : '<button class="btn ghost sm" data-meta="' + i + '" style="padding:0;min-height:34px">' + esc(m[1]) + ' ›</button>') + '</li>'; }).join('');
    $('#metas').onclick = function (e) { var b = e.target.closest('[data-meta]'); if (b) metas[+b.dataset.meta][2](); };
    var pg = q[7].data || [], STP = { aprovado: 'Aprovado', pendente: 'Pendente', em_analise: 'Em análise', recusado: 'Recusado', reembolsado: 'Reembolsado', cancelado: 'Cancelado', estornado: 'Estornado' };
    $('#pags').innerHTML = pg.length ? '<div class="lista">' + pg.map(function (x) { return '<div class="item"><div style="min-width:0"><div class="t">' + NOME_PLANO[x.plano] + ' ' + esc(x.ciclo) + ' · ' + reais(x.valor_centavos) + '</div><div class="d">' + data(x.pago_em || x.criado_em) + ' · ' + esc(x.metodo || '') + '</div></div><span class="pill ' + (x.status === 'aprovado' ? 'e-crescendo' : 'e-estavel') + '">' + esc(STP[x.status] || x.status) + '</span></div>'; }).join('') + '</div>'
      : '<p class="muted" style="margin:0">Nenhum pagamento ainda.' + (pl === 'free' ? ' Você está no plano Free.' : '') + '</p>';
    carregarLocal();
  }
  var PREF_CONTEUDO = [['video', 'Vídeos curtos'], ['carrossel', 'Carrosséis'], ['stories', 'Stories'], ['foto', 'Posts com foto'], ['humor', 'Humor e memes'], ['educativo', 'Conteúdo que ensina'], ['bastidores', 'Bastidores'], ['vendas', 'Vendas diretas']];
  var TIPO_NOME = { empreendedor: 'Empreendedor', social_media: 'Social Media', agencia: 'Agência' };
  // "Meu perfil": tipo de usuário, ramo, objetivo, interesses e preferências. Tudo isso fica guardado para personalizar no futuro.
  async function meuPerfil() {
    var box = $('#meuPerfil'); if (!box) return;
    var p = st.perfil || {}, tipo = TIPO_NOME[p.tipo_usuario] ? p.tipo_usuario : 'empreendedor';
    var perm = [], sol = [], okAcesso = true;
    try {
      var r = await Promise.all([sb.from('evolui_permissoes').select('recurso,ativo').eq('user_id', st.user.id), sb.from('evolui_solicitacoes_acesso').select('recurso,status,resposta,criado_em').eq('user_id', st.user.id).order('criado_em', { ascending: false }).limit(5)]);
      if (r[0].error || r[1].error) okAcesso = false; else { perm = r[0].data || []; sol = r[1].data || []; }
    } catch (e) { okAcesso = false; }
    if (!$('#meuPerfil')) return;
    var smOk = perm.some(function (x) { return x.recurso === 'social_media' && x.ativo; });
    var ult = sol.filter(function (x) { return x.recurso === 'social_media'; })[0];
    var ramo = RAMO[p.ramo], obj = OBJ.filter(function (o) { return o[0] === p.objetivo; })[0];
    var sel = ((p.preferencias || {}).conteudo || []).filter(function (x) { return typeof x === 'string'; });
    var acesso = '';
    if (smOk) acesso = '<p class="sub" style="margin:8px 0 0"><b>Acesso de Social Media liberado.</b> As ferramentas extras aparecem aqui assim que forem lançadas.</p>';
    else if (!okAcesso) acesso = '';
    else if (ult && ult.status === 'pendente') acesso = '<p class="sub" style="margin:8px 0 0"><b>Pedido enviado.</b> Estamos analisando seu acesso de Social Media e você será avisado aqui.</p>';
    else acesso = (ult && ult.status === 'recusada' ? '<p class="sub" style="margin:8px 0 0">Seu último pedido não foi aprovado' + (ult.resposta ? ': ' + esc(ult.resposta) : '') + '. Você pode pedir de novo.</p>' : '') +
      '<details class="mais" style="margin-top:8px"><summary>Quero usar a Evolui como Social Media</summary><div style="display:flex;flex-direction:column;gap:8px;margin-top:8px"><p class="sub" style="margin:0">Social Media tem ferramentas extras e libera depois de uma aprovação da nossa equipe.</p>' +
      '<label class="muted" for="smMsg" style="font-size:14px">Conte rapidamente como você trabalha (opcional)</label><textarea id="smMsg" maxlength="500" rows="2" placeholder="Ex.: cuido do Instagram de 4 clientes"></textarea>' +
      '<div><button class="btn prim sm" type="button" id="smPedir">Solicitar acesso de Social Media</button></div></div></details>';
    box.innerHTML = '<div class="entre"><h3>Meu perfil</h3><button class="btn sm ghost" id="mpEditar">Alterar ramo e objetivo</button></div>' +
      '<p class="sub" style="margin:0"><b>Ramo:</b> ' + esc(ramo ? ramo[1] : 'não informado') + (p.ramo_detalhe ? ' · ' + esc(p.ramo_detalhe) : '') + '<br><b>Objetivo:</b> ' + esc(obj ? obj[1] : 'não informado') + '</p>' +
      '<p class="muted" style="margin:14px 0 6px;font-size:14px">Como você usa a Evolui</p><div class="chips"><span class="chip" aria-pressed="' + (tipo === 'empreendedor') + '">Empreendedor</span><span class="chip" aria-pressed="' + (tipo === 'social_media') + '">Social Media</span><span class="chip" aria-disabled="true" style="opacity:.55">Agência · em breve</span></div>' + acesso +
      '<label class="muted" for="mpInter" style="display:block;margin:14px 0 6px;font-size:14px">Seus interesses (separe por vírgula)</label><input id="mpInter" maxlength="300" placeholder="Ex.: promoções, humor, tendências do setor" value="' + esc((p.interesses || []).join(', ')) + '">' +
      '<p class="muted" style="margin:14px 0 6px;font-size:14px">Que tipo de conteúdo você prefere?</p><div class="chips" id="mpPref">' + PREF_CONTEUDO.map(function (x) { return '<button type="button" class="chip" data-pref="' + x[0] + '" aria-pressed="' + (sel.indexOf(x[0]) >= 0) + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<div style="margin-top:14px"><button class="btn sm" type="button" id="mpSalvar">Salvar</button></div>';
    $('#mpEditar').onclick = function () { abrirOnboarding(true); };
    $('#mpPref').onclick = function (e) { var b = e.target.closest('[data-pref]'); if (b) b.setAttribute('aria-pressed', String(b.getAttribute('aria-pressed') !== 'true')); };
    $('#mpSalvar').onclick = async function () {
      var b = this; b.disabled = true;
      var inter = [], vistos = {};
      $('#mpInter').value.split(',').forEach(function (t) { t = t.replace(/[<>"{}]/g, '').replace(/\s+/g, ' ').trim().slice(0, 40); if (t && !vistos[t.toLowerCase()]) { vistos[t.toLowerCase()] = 1; inter.push(t); } });
      inter = inter.slice(0, 12);
      var conteudo = $$('[data-pref]', $('#mpPref')).filter(function (x) { return x.getAttribute('aria-pressed') === 'true'; }).map(function (x) { return x.dataset.pref; });
      var prefs = Object.assign({}, p.preferencias || {}, { conteudo: conteudo });
      var x = await sb.from('evolui_perfis').update({ interesses: inter, preferencias: prefs }).eq('id', st.user.id);
      b.disabled = false;
      if (x.error) return toast('Não foi possível salvar agora.');
      st.perfil.interesses = inter; st.perfil.preferencias = prefs; $('#mpInter').value = inter.join(', ');
      toast('Perfil salvo.');
    };
    var ped = $('#smPedir');
    if (ped) ped.onclick = async function () {
      ped.disabled = true;
      var x = await sb.rpc('evolui_solicitar_acesso', { p_recurso: 'social_media', p_mensagem: ($('#smMsg').value || '').trim() || null });
      if (x.error) { ped.disabled = false; return toast(/demais/.test(x.error.message || '') ? 'Você já enviou pedidos demais hoje. Tente amanhã.' : 'Não foi possível enviar agora.'); }
      toast('Pedido enviado. Vamos analisar.'); meuPerfil();
    };
  }
  async function carregarLocal() {
    var box = $('#local'); if (!box) return;
    try {
      if (!st.local) st.local = await E.api('local');
      if (!$('#local')) return;
      if (st.local.bloqueado) {
        box.innerHTML = borrado(3) + travado('Quantos negócios do seu ramo existem perto de você', 'pro');
        $$('[data-liberar]', box).forEach(function (b) { b.onclick = function () { abrirPlanos('local', b.dataset.liberar); }; });
        $('#cardLocal').style.minHeight = '220px'; st.local = null; return;
      }
      var L = st.local.local;
      if (!L || L.total == null) { box.innerHTML = '<p class="muted">' + esc(st.local.aviso || 'Sem dados agora.') + '</p>'; if (st.local.aviso && /ocupado/.test(st.local.aviso)) st.local = null; return; }
      box.innerHTML = '<div class="linha" style="align-items:baseline"><b style="font-family:var(--f-display);font-size:44px;line-height:1;font-weight:600">' + (L.limitado ? 'até ' : '') + L.total + '</b><span>negócios de ' + esc(String(L.ramo).toLowerCase()) + ' num raio de ' + L.raioKm + ' km do centro de ' + esc(L.cidade) + '</span></div>' +
        '<p class="muted" style="font-size:13px;margin:0">' + (L.fonte === 'Geoapify' ? 'Contagem do Geoapify' + (L.limitado ? ' (a consulta mostra no máximo 100, então o número real pode ser maior)' : '') + ': pode não incluir todos os negócios.' : 'Contagem do OpenStreetMap, um mapa feito por voluntários: pode não ter todos os negócios.') + ' Serve como termômetro da concorrência, não como número exato.</p>';
    } catch (e) { box.innerHTML = '<p class="muted">Não foi possível consultar o mapa agora.</p>'; }
  }
  // ---------------------------------------------------------------- importar dados do TikTok / YouTube (CSV baixado pela pessoa)
  // Lê o arquivo no navegador (EvoluiImportar), mostra uma prévia e só então grava: conteúdo (link) + publicação + métrica manual.
  // Nenhuma API de rede social, nenhuma senha. A métrica entra como fonte 'manual', janela 'avulsa'.
  async function clienteDaConta() {
    if (st.clienteId) return st.clienteId;
    var r = await sb.from('evolui_clientes').select('id').eq('user_id', st.user.id).order('criado_em', { ascending: true }).limit(2);
    if (r.error || !r.data || r.data.length !== 1) return null; // com mais de um cliente a pessoa precisará escolher (fase do multi-cliente)
    return (st.clienteId = r.data[0].id);
  }
  function importarDados() {
    var arq = $('#impArq'), rede = $('#impRede'), box = $('#impPrevia');
    if (!arq) return;
    resumoImportados();
    var lido = null;
    async function ler() {
      box.innerHTML = ''; lido = null;
      var f = arq.files && arq.files[0]; if (!f) return;
      if (!window.EvoluiImportar) { box.innerHTML = '<p class="muted">Não foi possível carregar o leitor de arquivos. Recarregue a página.</p>'; return; }
      if (f.size > EvoluiImportar.MAX_BYTES) { box.innerHTML = '<p class="muted">Arquivo grande demais (máximo 1 MB).</p>'; return; }
      var txt; try { txt = await f.text(); } catch (e) { box.innerHTML = '<p class="muted">Não consegui ler o arquivo.</p>'; return; }
      var r = EvoluiImportar.analisar(txt, rede.value);
      if (r.erro) { box.innerHTML = '<p class="muted">' + esc(r.erro) + '</p>'; return; }
      lido = r;
      var ig = r.ignoradas, avisos = [];
      if (ig.semLink) avisos.push(ig.semLink + ' linha(s) sem link válido');
      if (ig.linkDeOutraRede) avisos.push(ig.linkDeOutraRede + ' de outra rede');
      if (ig.duplicada) avisos.push(ig.duplicada + ' repetida(s)');
      if (ig.semNumero) avisos.push(ig.semNumero + ' sem números');
      if (r.truncado) avisos.push('só os primeiros ' + EvoluiImportar.MAX_LINHAS + ' vídeos serão trazidos');
      box.innerHTML = '<p><b>' + r.linhas.length + ' vídeo(s)</b> prontos para trazer.' + (avisos.length ? ' Ignorados: ' + esc(avisos.join(', ')) + '.' : '') + '</p><ul class="fontes">' +
        r.linhas.slice(0, 5).map(function (l) { return '<li>' + esc(l.titulo || l.url) + ' · ' + esc(Object.keys(l.metricas).map(function (k) { return k + ' ' + l.metricas[k]; }).join(', ')) + '</li>'; }).join('') + '</ul>' +
        (r.linhas.length > 5 ? '<p class="muted" style="font-size:13px">e mais ' + (r.linhas.length - 5) + '…</p>' : '') +
        '<div class="linha"><button class="btn" id="impOk">Trazer ' + r.linhas.length + ' vídeo(s)</button><button class="btn ghost" id="impNao">Cancelar</button></div>';
      $('#impNao').onclick = function () { arq.value = ''; box.innerHTML = ''; lido = null; };
      $('#impOk').onclick = salvar;
    }
    async function salvar() {
      if (!lido) return; var b = this; b.disabled = true;
      try {
        var res = await gravarImportacao(lido.linhas);
        arq.value = ''; box.innerHTML = '<p>Pronto: ' + res.novos + ' novo(s), ' + res.atualizados + ' com números novos, ' + res.iguais + ' sem mudança.</p>';
        lido = null; toast('Dados trazidos.'); resumoImportados();
      } catch (e) { b.disabled = false; box.insertAdjacentHTML('beforeend', '<p class="muted">Não foi possível salvar tudo agora. O que já entrou não se repete se você tentar de novo.</p>'); }
    }
    arq.onchange = ler; rede.onchange = ler;
  }
  async function resumoImportados() {
    var el = $('#impResumo'); if (!el) return;
    var r = await sb.from('evolui_metricas').select('id', { count: 'exact', head: true }).eq('user_id', st.user.id).eq('fonte', 'manual');
    if (!r.error && r.count) el.innerHTML = '<p class="muted" style="font-size:13px;margin:8px 0 0">Você tem ' + r.count + ' registro(s) de números guardados. Eles aparecem em "Baixar meus dados" e somem em "Apagar meus dados".</p>';
  }
  async function gravarImportacao(linhas) {
    var u = st.user.id, cid = await clienteDaConta(), novos = 0, atualizados = 0, iguais = 0;
    if (!cid) throw new Error('cliente');
    var lotes = function (a, n) { var o = []; for (var i = 0; i < a.length; i += n) o.push(a.slice(i, i + n)); return o; };
    // 1) conteúdos que já existem (pelo link normalizado)
    var porUrl = {};
    for (var L of lotes(linhas, 50)) {
      var e = await sb.from('evolui_conteudos').select('id,url_normalizada').eq('user_id', u).in('url_normalizada', L.map(function (x) { return x.normalizada; }));
      if (e.error) throw e.error; (e.data || []).forEach(function (c) { porUrl[c.url_normalizada] = c.id; });
    }
    // 2) cria os que faltam
    var faltam = linhas.filter(function (l) { return !porUrl[l.normalizada]; });
    for (var F of lotes(faltam, 50)) {
      var ins = await sb.from('evolui_conteudos').insert(F.map(function (l) {
        return { user_id: u, client_id: cid, origem: 'link', plataforma: l.plataforma, url: l.url, url_normalizada: l.normalizada, id_externo: l.id, titulo: l.titulo, publicado_em: l.publicado_em ? l.publicado_em + 'T12:00:00Z' : null, status: 'publicado', metadados: { importado: 'csv' } };
      })).select('id,url_normalizada');
      if (ins.error) throw ins.error; (ins.data || []).forEach(function (c) { porUrl[c.url_normalizada] = c.id; });
    }
    // 3) publicação de cada conteúdo (a métrica aponta para ela)
    var ids = linhas.map(function (l) { return porUrl[l.normalizada]; }).filter(Boolean), pubPorConteudo = {};
    for (var I of lotes(ids, 50)) {
      var pe = await sb.from('evolui_publicacoes').select('id,conteudo_id').eq('user_id', u).in('conteudo_id', I);
      if (pe.error) throw pe.error; (pe.data || []).forEach(function (p) { pubPorConteudo[p.conteudo_id] = p.id; });
    }
    var semPub = linhas.filter(function (l) { return porUrl[l.normalizada] && !pubPorConteudo[porUrl[l.normalizada]]; });
    for (var S of lotes(semPub, 50)) {
      var pi = await sb.from('evolui_publicacoes').insert(S.map(function (l) {
        return { user_id: u, client_id: cid, conteudo_id: porUrl[l.normalizada], rede: l.plataforma, url: l.url, id_externo: l.id, publicado_em: l.publicado_em ? l.publicado_em + 'T12:00:00Z' : null };
      })).select('id,conteudo_id');
      if (pi.error) throw pi.error; (pi.data || []).forEach(function (p) { pubPorConteudo[p.conteudo_id] = p.id; });
    }
    // 4) métricas: um registro novo só quando os números mudaram desde o último importado
    var pubIds = Object.keys(pubPorConteudo).map(function (k) { return pubPorConteudo[k]; }), ultimo = {};
    for (var P of lotes(pubIds, 50)) {
      var me = await sb.from('evolui_metricas').select('publicacao_id,coletado_em,visualizacoes,curtidas,comentarios,compartilhamentos,salvamentos,alcance').eq('user_id', u).eq('fonte', 'manual').in('publicacao_id', P).order('coletado_em', { ascending: false });
      if (me.error) throw me.error; (me.data || []).forEach(function (m) { if (!ultimo[m.publicacao_id]) ultimo[m.publicacao_id] = m; });
    }
    var agora = new Date().toISOString(), paraInserir = [];
    linhas.forEach(function (l) {
      var pid = pubPorConteudo[porUrl[l.normalizada]]; if (!pid) return;
      var ant = ultimo[pid], igual = ant && EvoluiImportar.CAMPOS_METRICA.every(function (k) { return (l.metricas[k] == null ? null : l.metricas[k]) === (ant[k] == null ? null : ant[k]); });
      if (igual) { iguais++; return; }
      if (ant) atualizados++; else novos++;
      var row = { user_id: u, client_id: cid, publicacao_id: pid, coletado_em: agora, fonte: 'manual', janela: 'avulsa' };
      EvoluiImportar.CAMPOS_METRICA.forEach(function (k) { if (l.metricas[k] != null) row[k] = l.metricas[k]; });
      paraInserir.push(row);
    });
    for (var M of lotes(paraInserir, 50)) { var mi = await sb.from('evolui_metricas').insert(M); if (mi.error) throw mi.error; }
    return { novos: novos, atualizados: atualizados, iguais: iguais };
  }
  // preferências do copiloto para exportar: confirmadas/removidas (já estão em perfil.preferencias.copiloto) + o que foi inferido, com a evidência
  function copExportar(eventos) {
    var C = window.EvoluiCopiloto, cfg = copCfg(); if (!C) return { confirmadas: cfg.confirmadas, removidas: cfg.removidas };
    var r = C.inferirPreferencias(eventos || [], { confirmadas: cfg.confirmadas, removidas: cfg.removidas, personalizar: copPers() });
    function f(p) { return { id: p.id, preferencia: p.rotulo, porque: p.porque, origem: p.origem, ocorrencias: p.ocorrencias, conteudos: p.conteudos }; }
    return { confirmadas: cfg.confirmadas, removidas: cfg.removidas, inferidas: r.ativas.map(f), em_observacao: r.hipoteses.map(f) };
  }
  async function baixarDados() {
    var t = await Promise.all([sb.from('evolui_perfis').select('*'), sb.from('evolui_redes').select('*'), sb.from('evolui_buscas').select('termo,estado_tendencia,criado_em'), sb.from('evolui_salvos').select('*'), sb.from('evolui_lab_testes').select('*'), sb.from('evolui_respostas').select('pergunta_id,resposta,dia'), sb.from('evolui_eventos').select('tipo,dados,criado_em').limit(1000), sb.from('evolui_pagamentos').select('plano,ciclo,valor_centavos,status,metodo,pago_em'), sb.from('evolui_ctas').select('objetivo_chave,titulo,descricao,formato,instrucoes,gancho,chamada,publico,rede,dificuldade,tempo_min,status,criado_em,iniciado_em,concluido_em'), sb.from('evolui_objetivos').select('*'), sb.from('evolui_eie_eventos').select('tipo,candidato_tipo,candidato_id,consulta,formato,algoritmo,criado_em').limit(1000), sb.from('evolui_eie_recomendacoes').select('origem,consulta,algoritmo,config_versao,itens,criado_em').limit(500), sb.from('evolui_planejamentos').select('*'), sb.from('evolui_conteudos').select('plataforma,url,titulo,publicado_em,status,criado_em'), sb.from('evolui_publicacoes').select('rede,url,publicado_em,criado_em'), sb.from('evolui_metricas').select('publicacao_id,coletado_em,fonte,janela,alcance,visualizacoes,curtidas,comentarios,compartilhamentos,salvamentos,mensagens,seguidores_ganhos,cliques_link,vendas'), sb.from('evolui_lab_referencias').select('fonte,url,id_externo,titulo,autor,miniatura_url,consulta,estado,nota,metadados,teste_id,criado_em'), sb.from('evolui_lab_docs').select('doc_id,versao,origem,titulo,corpo,formato,duracao_seg,palavras,teste_id,criado_em,atualizado_em').order('doc_id').order('versao').limit(2000), sb.from('evolui_lab_doc_estado').select('doc_id,status,rede,url,publicado_em,fatores,criado_em,atualizado_em'), sb.from('evolui_lab_doc_medicoes').select('doc_id,medido_em,janela,visualizacoes,alcance,curtidas,comentarios,compartilhamentos,salvamentos,retencao_pct,duracao_video_seg,fonte,criado_em'), sb.from('evolui_rede_medicoes').select('rede,medido_em,seguidores,seguindo,publicacoes,fonte,criado_em')]);
    var dados = { exportado_em: new Date().toISOString(), conta: { email: st.user.email }, perfil: t[0].data, redes: t[1].data, pesquisas: t[2].data, salvos: t[3].data, laboratorio: t[4].data, respostas_do_dia: t[5].data, uso: t[6].data, pagamentos: t[7].data, acoes_sugeridas: t[8].data, objetivos: t[9].data, sinais_do_motor: t[10].data, recomendacoes_do_motor: t[11].data, planejamentos_de_conteudo: t[12].data, conteudos_publicados: t[13].data, publicacoes: t[14].data, metricas: t[15].data, referencias_do_laboratorio: t[16].data, documentos_do_laboratorio: t[17].data, andamento_dos_documentos: t[18].data, resultados_dos_documentos: t[19].data, numeros_das_redes: t[20].data, preferencias_do_copiloto: copExportar(t[6].data) };
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(dados, null, 2)], { type: 'application/json' }));
    a.download = 'meus-dados-evoluisocial.json'; document.body.appendChild(a); a.click(); a.remove();
    toast('Arquivo gerado.');
  }
  function confirmarExclusao() {
    var f = document.createElement('div'); f.className = 'modal-fundo';
    f.innerHTML = '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="mx"><h3 id="mx">Apagar todos os seus dados?</h3><p class="sub">Perfil, redes, histórico, ações e objetivos, salvos, testes do laboratório, respostas do dia, documentos (com andamento e resultados), números das suas redes, preferências aprendidas pelo copiloto e registros de uso serão apagados para sempre. Sua conta de login continua existindo; para encerrá-la, escreva para contato@felipebranding.com.br.</p><div class="linha"><button class="btn" id="mxNao">Cancelar</button><button class="btn perigo" id="mxSim" style="border-color:var(--bad)">Apagar tudo</button></div></div>';
    document.body.appendChild(f);
    $('#mxNao').focus();
    $('#mxNao').onclick = function () { f.remove(); };
    $('#mxSim').onclick = async function () {
      this.disabled = true; var u = st.user.id;
      await Promise.all([sb.from('evolui_ctas').delete().eq('user_id', u), sb.from('evolui_objetivos').delete().eq('user_id', u), sb.from('evolui_lab_testes').delete().eq('user_id', u), sb.from('evolui_lab_referencias').delete().eq('user_id', u), sb.from('evolui_lab_doc_estado').delete().eq('user_id', u), sb.from('evolui_lab_docs').delete().eq('user_id', u), sb.from('evolui_rede_medicoes').delete().eq('user_id', u), sb.from('evolui_salvos').delete().eq('user_id', u), sb.from('evolui_buscas').delete().eq('user_id', u),
        sb.from('evolui_redes').delete().eq('user_id', u), sb.from('evolui_respostas').delete().eq('user_id', u), sb.from('evolui_eventos').delete().eq('user_id', u), sb.from('evolui_eie_eventos').delete().eq('user_id', u), sb.from('evolui_eie_recomendacoes').delete().eq('user_id', u), sb.from('evolui_planejamento_eventos').delete().eq('user_id', u), sb.from('evolui_planejamentos').delete().eq('user_id', u), sb.from('evolui_aprendizados').delete().eq('user_id', u), sb.from('evolui_metricas').delete().eq('user_id', u)]);
      await sb.from('evolui_publicacoes').delete().eq('user_id', u); await sb.from('evolui_conteudos').delete().eq('user_id', u);
      await sb.from('evolui_perfis').delete().eq('id', u);
      await sb.auth.signOut(); location.href = '/evoluisocial/';
    };
  }

  // ---------------------------------------------------------------- pergunta do dia (alimenta o agente de perfil)
  async function perguntaDoDia(forcar) {
    if (!st.perfil || !st.perfil.onboarding_ok || $('.pdia') || $('.onb')) return;
    if (st.perfil.personalizar === false && !forcar) return;
    var hoje = new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Sao_Paulo' });
    try { if (!forcar && sessionStorage.getItem('evolui_pdia') === hoje) return; } catch (e) { /* sem armazenamento */ }
    var resp = await sb.from('evolui_respostas').select('pergunta_id,dia').order('criado_em', { ascending: false }).limit(60);
    var lista = resp.data || [];
    if (lista.some(function (r) { return r.dia === hoje; })) { if (forcar) toast('Você já respondeu a pergunta de hoje. Volte amanhã!'); return; }
    var pergs = await sb.from('evolui_perguntas').select('id,chave,texto,opcoes').order('id');
    var P = pergs.data || []; if (!P.length) return;
    var feitas = {}; lista.forEach(function (r) { feitas[r.pergunta_id] = true; });
    var q = P.filter(function (x) { return !feitas[x.id]; })[0] || P[(Math.floor(Date.now() / 864e5)) % P.length];
    var el = document.createElement('div'); el.className = 'pdia'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-labelledby', 'pdT');
    el.innerHTML = '<button class="fechar" aria-label="Agora não">×</button><span class="kicker"><span class="estrela"></span>Pergunta do dia</span><h3 id="pdT">' + esc(q.texto) + '</h3>' +
      '<div class="opcoes">' + (q.opcoes || []).map(function (o) { return '<button class="opcao" data-r="' + esc(o) + '">' + esc(o) + '</button>'; }).join('') + '</div>' +
      '<p class="muted" style="font-size:12px;margin:0">Uma pergunta por dia. Suas respostas deixam as ideias mais a sua cara.</p>';
    document.body.appendChild(el);
    var fechar = function () { el.remove(); try { sessionStorage.setItem('evolui_pdia', hoje); } catch (e) { /* ok */ } };
    $('.fechar', el).onclick = fechar;
    el.onclick = async function (e) {
      var b = e.target.closest('[data-r]'); if (!b) return;
      $$('[data-r]', el).forEach(function (x) { x.disabled = true; });
      b.setAttribute('aria-pressed', 'true');
      var x = await sb.from('evolui_respostas').insert({ user_id: st.user.id, pergunta_id: q.id, resposta: b.dataset.r });
      fechar();
      if (x.error) return toast('Não foi possível salvar sua resposta.');
      registrar('pergunta', { chave: q.chave });
      st.paraVoce = null;
      toast('Obrigado! Suas próximas ideias vão levar isso em conta.');
    };
  }

  // ---------------------------------------------------------------- Central de Conteúdo (02/10/2026)
  // DESCOBERTA → "Usar esta ideia" → planejamento salvo (evolui_planejamentos) → publicação registrada (evolui_conteudos).
  // A geração do plano roda no evolui-criar (acao "planejar"); aqui só a jornada. Privado por padrão.
  var CC_STATUS = [['ideia', 'Ideia'], ['planejando', 'Planejando'], ['pronto_gravar', 'Pronto para gravar'], ['gravado', 'Gravado'], ['publicado', 'Publicado'], ['analisando', 'Analisando'], ['concluido', 'Concluído']];
  var CC_FORMATOS = [['reels', 'Reels'], ['tiktok', 'TikTok'], ['short', 'Short'], ['carrossel', 'Carrossel'], ['imagem', 'Imagem'], ['meme', 'Meme'], ['stories', 'Stories'], ['outro', 'Outro']];
  // objetivo do conteúdo → chave do catálogo que o servidor entende (vazio = sem ênfase especial)
  var CC_OBJ = [['atencao', 'Chamar atenção', 'visualizacoes'], ['comentarios', 'Gerar comentários', 'ideia_video'], ['compartilhamentos', 'Ser compartilhado', 'visualizacoes'], ['salvamentos', 'Ser salvo', ''], ['mensagens', 'Gerar mensagens', 'divulgar'], ['orcamento', 'Gerar orçamentos', 'divulgar'], ['visitas', 'Gerar visitas', 'apresentar'], ['autoridade', 'Fortalecer autoridade', 'ideia_video'], ['apresentar', 'Apresentar um produto', 'apresentar'], ['educar', 'Educar', '']];
  var CC_OBJ_PERFIL = { vender: 'mensagens', crescer: 'atencao', engajar: 'comentarios', lancar: 'apresentar' };
  var HOOK_ROT = { pergunta: 'Pergunta', contraste: 'Contraste', erro_comum: 'Erro comum', promessa: 'Promessa', dado: 'Dado', demonstracao: 'Demonstração', historia: 'História', curiosidade: 'Curiosidade', provocacao: 'Provocação' };
  var CC_PROXIMO = { planejando: ['pronto_gravar', 'Está pronto para gravar'], pronto_gravar: ['gravado', 'Já gravei'], publicado: ['analisando', 'Acompanhar o resultado'], analisando: ['concluido', 'Concluir'] };
  var CC_VIDEO = { reels: 1, tiktok: 1, short: 1 };
  st.ccIdeias = [];

  function ccFormatoDe(txt) { var t = String(txt || '').toLowerCase(); if (/carross/.test(t)) return 'carrossel'; if (/(^|[^a-z])stor(y|ies)([^a-z]|$)/.test(t)) return 'stories'; if (/meme/.test(t)) return 'meme'; if (/foto|imagem|parceria/.test(t)) return 'imagem'; if (/tiktok/.test(t)) return 'tiktok'; return 'reels'; }
  function ccRotStatus(s) { var x = CC_STATUS.filter(function (a) { return a[0] === s; })[0]; return x ? x[1] : s; }
  function ccIdx(s) { for (var i = 0; i < CC_STATUS.length; i++) if (CC_STATUS[i][0] === s) return i; return 0; }
  function ccEv(tipo, id, dados) {
    if (!sb || !st.user || (st.perfil && st.perfil.personalizar === false)) return;
    try { sb.from('evolui_planejamento_eventos').insert({ user_id: st.user.id, planejamento_id: id || null, tipo: tipo, dados: dados || {} }).then(function () {}, function () {}); } catch (e) { /* sem rede */ }
  }
  // botão "Usar esta ideia" (guarda a ideia em memória; o clique é tratado por delegação)
  function usarBtn(ideia, rotulo) { st.ccIdeias.push(ideia); return '<button class="btn sm cta" data-usar="' + (st.ccIdeias.length - 1) + '">' + esc(rotulo || 'Usar esta ideia') + '</button>'; }
  function ccMesmoTermo(r, termo) { return !!(r && r.termo && termo && String(r.termo).toLowerCase() === String(termo).toLowerCase()); }
  function ccFato(r, termo) {
    if (!ccMesmoTermo(r, termo) || !r.estado || r.estado === 'insuficiente' || typeof r.crescimento !== 'number') return '';
    return 'As buscas por "' + r.termo + '" estão ' + String(r.rotulo || r.estado).toLowerCase() + ' (' + pct(r.crescimento) + ' em relação à semana anterior).';
  }
  function ccFontes(r, termo) {
    if (!ccMesmoTermo(r, termo)) return [];
    var agora = new Date().toISOString(), out = [];
    (r.fontes || []).forEach(function (f) { if (f && f.ok && /^https:\/\//.test(f.link || '')) out.push({ nome: String(f.nome || '').slice(0, 60), url: f.link.slice(0, 300), titulo: String(f.detalhe || '').slice(0, 140), tipo: 'tendencia', coletado_em: agora }); });
    (r.noticias || []).slice(0, 3).forEach(function (n) { if (n && /^https:\/\//.test(n.url || '')) out.push({ nome: String(n.site || 'Notícia').slice(0, 60), url: n.url.slice(0, 300), titulo: String(n.titulo || '').slice(0, 140), data: n.data || null, tipo: 'noticia', coletado_em: agora }); });
    return out.slice(0, 6);
  }
  async function usarIdeia(ideia, btn) {
    if (!ideia) return;
    if (btn) btn.disabled = true;
    try {
      var termo = String(ideia.termo || '').replace(/[<>]/g, '').slice(0, 120);
      var titulo = String(ideia.titulo || '').replace(/^["“”\s]+|["“”\s]+$/g, '').replace(/[<>]/g, '').slice(0, 200);
      if (titulo.length < 4) throw new Error('sem título');
      var ex = await sb.from('evolui_planejamentos').select('slug').eq('titulo', titulo).eq('termo', termo).neq('status', 'concluido').limit(1);
      if (!ex.error && ex.data && ex.data.length) { abrirConteudo(ex.data[0].slug); return; }
      var fato = ccFato(st.resultado, termo);
      var row = {
        user_id: st.user.id, titulo: titulo, termo: termo, status: 'ideia', formato: ccFormatoDe(ideia.formato),
        objetivo: CC_OBJ_PERFIL[(st.perfil || {}).objetivo] || null,
        origem: { termo: termo, fonte_tipo: ideia.origem || 'busca', cta_id: ideia.cta_id || null, ideia: { titulo: titulo, descricao: String(ideia.descricao || '').slice(0, 400), formato: ideia.formato || null } },
        insight: fato ? { fato: { texto: fato, tipo: 'pesquisa' } } : {}, fontes: ccFontes(st.resultado, termo)
      };
      var x = await sb.from('evolui_planejamentos').insert(row).select('id,slug').single();
      if (x.error) throw x.error;
      ccEv('usar_ideia', x.data.id, { formato: row.formato, origem: row.origem.fonte_tipo });
      abrirConteudo(x.data.slug, { novo: true });
    } catch (e) { toast('Não foi possível abrir o planejamento agora.'); if (btn) btn.disabled = false; }
  }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-usar]'); if (b) usarIdeia(st.ccIdeias[+b.dataset.usar], b); });

  async function abrirConteudo(slug, opc) {
    st.aba = 'c';
    if (location.hash !== '#c/' + slug) history.pushState(null, '', location.pathname + location.search + '#c/' + slug);
    $$('.nav button').forEach(function (b) { b.setAttribute('aria-current', b.dataset.aba === 'historico' ? 'page' : 'false'); });
    var c = $('#conteudo'); c.innerHTML = '<p class="muted">Carregando…</p>'; window.scrollTo(0, 0);
    var r = await sb.from('evolui_planejamentos').select('*').eq('slug', slug).maybeSingle();
    if (r.error || !r.data) {
      c.innerHTML = '<section class="card"><h3>Conteúdo não encontrado</h3><p class="sub">Ele pode ter sido apagado.</p><button class="btn" id="ccVoltar">Voltar</button></section>';
      $('#ccVoltar').onclick = function () { ir('historico'); }; return;
    }
    st.cc = r.data; st.ccEditou = false;
    if (!(opc && opc.novo)) ccEv('plano_reaberto', r.data.id, { status: r.data.status });
    ccRender();
  }
  async function ccSalvar(campos) {
    var x = await sb.from('evolui_planejamentos').update(campos).eq('id', st.cc.id);
    if (x.error) { toast('Não foi possível salvar agora.'); return false; }
    Object.assign(st.cc, campos); return true;
  }
  function ccChips(lista, atual, attr) { return '<div class="chips">' + lista.map(function (a) { return '<button type="button" class="chip" data-' + attr + '="' + a[0] + '" aria-pressed="' + (atual === a[0]) + '">' + esc(a[1]) + '</button>'; }).join('') + '</div>'; }
  function ccSec(titulo, corpo, aberto) { var ab = st.ccEstado && titulo in st.ccEstado ? st.ccEstado[titulo] : aberto; return '<details class="cc-sec card"' + (ab ? ' open' : '') + '><summary><h3>' + esc(titulo) + '</h3></summary><div class="cc-corpo">' + corpo + '</div></details>'; }
  function ccNiveis(p) {
    var ins = p.insight || {}, tem = !!(p.plano && p.plano.hook);
    var fato = ins.fato && ins.fato.texto ? esc(ins.fato.texto) : 'Sem dado de pesquisa para esta ideia.';
    return '<div class="cc-niveis"><div class="cc-nivel"><span class="cc-tag fato">Fato · vem da pesquisa</span><p>' + fato + '</p></div>' +
      (tem ? '<div class="cc-nivel"><span class="cc-tag">Interpretação · criada pela Evolui</span><p>' + esc(ins.interpretacao || '') + '</p></div><div class="cc-nivel"><span class="cc-tag">Sugestão · criada pela Evolui</span><p>' + esc(ins.sugestao || '') + '</p></div>' : '') +
      (tem && ins.aviso ? '<p class="muted" style="font-size:13px;margin:0">' + esc(ins.aviso) + '</p>' : '') + '</div>';
  }
  function ccRender() {
    // guarda quais seções estavam abertas/fechadas para não "pular" quando a tela é refeita
    if ($('.cc')) { st.ccEstado = {}; $$('.cc-sec').forEach(function (d) { st.ccEstado[$('summary h3', d).textContent] = d.open; }); } else st.ccEstado = null;
    var p = st.cc, pl = p.plano || {}, tem = !!pl.hook, idx = ccIdx(p.status), video = !!CC_VIDEO[p.formato];
    var objRot = (CC_OBJ.filter(function (o) { return o[0] === p.objetivo; })[0] || [, 'Sem objetivo definido'])[1];
    var fmtRot = (CC_FORMATOS.filter(function (o) { return o[0] === p.formato; })[0] || [, 'Reels'])[1];
    var h = '<div class="cc"><button class="btn ghost sm" id="ccVoltar">‹ Seus conteúdos</button>' +
      '<header class="cc-topo"><span class="kicker">' + esc(ccRotStatus(p.status)) + ' · etapa ' + (idx + 1) + ' de ' + CC_STATUS.length + '</span><h1 class="tit cc-tit">' + esc(p.titulo) + '</h1>' +
      '<ol class="cc-passos" aria-label="Etapas do conteúdo">' + CC_STATUS.map(function (s, i) { return '<li class="' + (i < idx ? 'feito' : i === idx ? 'atual' : '') + '"' + (i === idx ? ' aria-current="step"' : '') + '><span>' + esc(s[1]) + '</span></li>'; }).join('') + '</ol></header>';
    h += '<section class="card"><h3>1 · A ideia e por que importa</h3>' + (p.termo ? '<p class="muted" style="margin:0">Veio da pesquisa por "' + esc(p.termo) + '".</p>' : '') + ccNiveis(p) + '</section>';
    if (!tem) {
      h += '<section class="card"><h3>2 · Objetivo e formato</h3><p class="sub" style="margin:0">Escolha para o que este conteúdo serve e onde vai ser publicado. A Evolui monta o resto.</p>' +
        '<p class="muted" style="margin:10px 0 6px;font-size:14px">Objetivo</p>' + ccChips(CC_OBJ, p.objetivo, 'ccobj') +
        '<p class="muted" style="margin:14px 0 6px;font-size:14px">Formato</p>' + ccChips(CC_FORMATOS, p.formato, 'ccfmt') +
        '<div style="margin-top:16px"><button class="btn cta" id="ccGerar">Montar planejamento</button></div><div id="ccGerarMsg" aria-live="polite"></div></section>';
    } else {
      h += '<p class="cc-resumo muted">Objetivo: <b>' + esc(objRot) + '</b> · Formato: <b>' + esc(fmtRot) + '</b> · ' + esc(pl.duracao || '') + '</p>';
      h += ccSec('2 · Hook e promessa', '<p class="cc-hook" id="ccHookTxt">' + esc(pl.hook.texto) + '</p><p class="muted" style="margin:0;font-size:13px">Tipo de hook: <b>' + esc(HOOK_ROT[pl.hook.tipo] || pl.hook.tipo) + '</b>. Troque se quiser outro jeito de abrir:</p>' +
        '<div class="chips" id="ccHooks">' + (pl.hooks || []).map(function (x, i) { return '<button type="button" class="chip" data-cchook="' + i + '" aria-pressed="' + (x.tipo === pl.hook.tipo) + '">' + esc(HOOK_ROT[x.tipo] || x.tipo) + '</button>'; }).join('') + '</div>' +
        '<p style="margin:6px 0 0"><b>Promessa:</b> ' + esc(pl.promessa || '') + '</p><div class="linha"><button class="btn sm" data-cccp="hook">Copiar hook</button></div>', true);
      h += ccSec('3 · Roteiro', '<ol class="fi-l">' + (pl.roteiro || []).map(function (r) {
        return '<li><b>' + esc(r.etapa) + (r.tempo ? ' · ' + esc(r.tempo) : '') + '</b>' + (r.fazer ? '<br>Fazer: ' + esc(r.fazer) : '') + (r.falar ? '<br>Falar: ' + esc(r.falar) : '') + (r.texto ? '<br>Texto: ' + esc(r.texto) : '') + '</li>';
      }).join('') + '</ol>', true);
      h += ccSec(video ? '4 · Como gravar' : '4 · Como produzir', '<ul class="cc-guia">' + (pl.guia_gravacao || []).map(function (g) { return '<li><b>' + esc(g.titulo) + '</b><span>' + esc(g.texto) + '</span></li>'; }).join('') + '</ul>', true);
      if ((pl.texto_tela || []).length) h += ccSec('5 · Texto na tela', '<ul class="cc-guia">' + pl.texto_tela.map(function (t) { return '<li><b>' + esc(t.momento) + '</b><span>"' + esc(t.texto) + '" · ' + esc(t.onde) + '</span></li>'; }).join('') + '</ul>');
      h += ccSec('6 · Legenda', '<textarea id="ccLeg" rows="7" maxlength="2200" aria-label="Legenda">' + esc(pl.legenda || '') + '</textarea><p class="muted" style="font-size:13px;margin:0">Troque os [campos entre colchetes] por detalhes reais do seu trabalho. Suas edições ficam salvas.</p><div class="linha"><button class="btn sm cta" data-cccp="legenda">Copiar legenda</button></div>', true);
      var tags = (pl.hashtags && pl.hashtags.lista) || [];
      h += ccSec('7 · Hashtags', '<div class="chips">' + tags.map(function (t) { return '<span class="chip" title="' + esc(t.motivo) + '">#' + esc(t.tag) + '</span>'; }).join('') + '</div><p class="muted" style="font-size:13px;margin:0">' + esc((pl.hashtags && pl.hashtags.observacao) || '') + '</p><div class="linha"><button class="btn sm" data-cccp="tags">Copiar hashtags</button></div>');
      h += ccSec('8 · Chamada para ação (CTA)', '<div class="caixa-legenda">' + esc(pl.cta || '') + '</div><div class="linha"><button class="btn sm" data-cccp="cta">Copiar CTA</button></div>');
    }
    // referências (sempre disponíveis: cadastro manual; a Evolui não inventa perfis)
    var refs = p.referencias || [];
    h += ccSec('Perfis de referência', (refs.length ? '<ul class="cc-guia">' + refs.map(function (x, i) { return '<li><b>' + esc(x.nome) + ' · ' + esc(x.plataforma) + '</b><span>' + (x.url ? '<a href="' + esc(x.url) + '" target="_blank" rel="noopener noreferrer">' + esc(x.url) + '</a> · ' : '') + esc(x.motivo || '') + ' <button class="btn ghost sm" data-ccref-del="' + i + '">Remover</button></span></li>'; }).join('') + '</ul>'
      : '<p class="muted" style="margin:0">Ainda não há perfis de referência. Adicione os que você admira: a Evolui guarda aqui e lembra o que aprender com cada um (a estrutura, não copiar).</p>') +
      (refs.length < 5 ? '<details class="mais"><summary>Adicionar perfil de referência</summary><div class="cc-form"><input id="refNome" maxlength="60" placeholder="Nome ou @ do perfil"><select id="refPlat" aria-label="Plataforma"><option value="Instagram">Instagram</option><option value="TikTok">TikTok</option><option value="YouTube">YouTube</option><option value="Outra">Outra</option></select><input id="refUrl" maxlength="300" placeholder="Link do perfil (https://…)" inputmode="url"><input id="refMotivo" maxlength="140" placeholder="O que você quer aprender com ele?"><button class="btn sm" id="refAdd">Adicionar</button></div></details>' : ''));
    // origem e fontes (proveniência)
    var fs = p.fontes || [];
    h += ccSec('De onde veio', '<ol class="cc-escada"><li><b>Origem</b><span>' + (fs.length ? fs.map(function (f) { return '<a href="' + esc(f.url) + '" target="_blank" rel="noopener noreferrer">' + esc(f.nome) + (f.titulo ? ': ' + esc(f.titulo) : '') + '</a>'; }).join('<br>') + '<br><small>Coletado em ' + dataHora(fs[0].coletado_em) + '</small>' : 'Nenhuma fonte externa: a ideia saiu do seu perfil.') + '</span></li>' +
      '<li><b>Informação extraída</b><span>' + esc((p.insight && p.insight.fato && p.insight.fato.texto) || 'Nada foi extraído de fonte externa.') + '</span></li>' +
      '<li><b>Interpretação</b><span>' + esc((p.insight && p.insight.interpretacao) || 'Disponível depois de montar o planejamento.') + '</span></li>' +
      '<li><b>Ideia criada pela Evolui</b><span>' + esc(p.titulo) + '</span></li></ol>');
    // status e publicação
    h += '<section class="card cc-status"><h3>' + (idx < 4 ? 'Andamento' : 'Publicação') + '</h3>';
    if (p.status === 'publicado' || p.status === 'analisando' || p.status === 'concluido') h += ccPub(p);
    else if (tem) h += '<details class="mais"' + (p.status === 'gravado' ? ' open' : '') + '><summary>Já publicou? Registre o link</summary><div class="cc-form"><input id="pubUrl" maxlength="300" placeholder="Cole o link da publicação (https://…)" inputmode="url"><input id="pubData" type="date" value="' + new Date().toISOString().slice(0, 10) + '" aria-label="Data de publicação"><button class="btn sm cta" id="pubReg">Registrar publicação</button></div></details>';
    var prox = CC_PROXIMO[p.status];
    h += '<div class="linha">' + (prox && tem ? '<button class="btn cta" id="ccProx">' + esc(prox[1]) + '</button>' : '') + (tem && idx >= 2 && idx <= 3 ? '<button class="btn ghost sm" id="ccVolta">Voltar uma etapa</button>' : '') +
      (tem ? '<button class="btn ghost sm" id="ccRefazer">Mudar objetivo ou formato</button>' : '') + '<button class="btn ghost sm perigo" id="ccApagar">Apagar</button></div><div id="ccMsg" aria-live="polite"></div></section></div>';
    $('#conteudo').innerHTML = h;
    ccLigar();
  }
  function ccPub(p) {
    var pub = p.publicacao || {}, emb = pub.embed || null;
    var ROT = { instagram: 'Instagram', tiktok: 'TikTok', youtube: 'YouTube', outra: 'Publicação' };
    var corpo = '<p class="sub" style="margin:0">' + esc(ROT[pub.plataforma] || 'Publicação') + (pub.data ? ' · publicado em ' + data(pub.data) : '') + '</p>';
    if (emb && emb.tipo === 'youtube' && /^[\w-]{11}$/.test(emb.id)) corpo += '<div class="cc-embed"><iframe src="https://www.youtube-nocookie.com/embed/' + emb.id + '" title="Vídeo publicado" loading="lazy" allowfullscreen referrerpolicy="strict-origin-when-cross-origin" sandbox="allow-scripts allow-same-origin allow-presentation"></iframe></div>';
    else corpo += '<div class="cc-link-card"><b>' + esc(ROT[pub.plataforma] || 'Publicação') + '</b><span>O player dentro da Evolui só aparece quando a rede permite o embed oficial. Por enquanto, abra pela rede.</span></div>';
    if (/^https:\/\//.test(pub.url || '')) corpo += '<a class="btn" href="' + esc(pub.url) + '" target="_blank" rel="noopener noreferrer">Ver publicação</a>';
    return corpo;
  }
  // identifica a rede e o ID do vídeo a partir do link colado. Só rede e ID: nada é baixado nem raspado.
  function ccLerUrl(txt) {
    var u; try { u = new URL(String(txt || '').trim()); } catch (e) { return null; }
    if (u.protocol !== 'https:' || u.href.length > 300) return null;
    var host = u.hostname.replace(/^www\.|^m\./, ''), plataforma = 'outra', id = null;
    if (/(^|\.)instagram\.com$/.test(host)) plataforma = 'instagram';
    else if (/(^|\.)tiktok\.com$/.test(host)) plataforma = 'tiktok';
    else if (host === 'youtu.be' || /(^|\.)youtube\.com$/.test(host)) {
      plataforma = 'youtube';
      var m = host === 'youtu.be' ? u.pathname.match(/^\/([\w-]{11})/) : (u.searchParams.get('v') || '').match(/^([\w-]{11})$/) || u.pathname.match(/^\/(?:shorts|embed)\/([\w-]{11})/);
      id = m ? m[1] : null;
    }
    var norm = 'https://' + host + (plataforma === 'youtube' && id ? '/watch?v=' + id : u.pathname.replace(/\/+$/, ''));
    return { url: u.href, plataforma: plataforma, id: id, normalizada: norm.slice(0, 300) };
  }
  async function ccMudarStatus(novo, extra) {
    var antigo = st.cc.status;
    if (!(await ccSalvar(Object.assign({ status: novo }, extra || {})))) return false;
    ccEv('status_mudou', st.cc.id, { de: antigo, para: novo }); return true;
  }
  function ccLigar() {
    var p = st.cc, box = $('#conteudo');
    $('#ccVoltar').onclick = function () { ir('historico'); };
    // objetivo e formato (antes de montar)
    $$('[data-ccobj]', box).forEach(function (b) { b.onclick = function () { p.objetivo = b.dataset.ccobj; $$('[data-ccobj]', box).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); }); }; });
    $$('[data-ccfmt]', box).forEach(function (b) { b.onclick = function () { p.formato = b.dataset.ccfmt; $$('[data-ccfmt]', box).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); }); }; });
    var g = $('#ccGerar'); if (g) g.onclick = function () { ccGerar(g, false); };
    var rf = $('#ccRefazer'); if (rf) rf.onclick = function () { st.cc.plano_antigo_hooks = ((p.plano || {}).hooks || []).map(function (h) { return h.tipo; }); p.plano = {}; ccRender(); };
    // hook
    $$('[data-cchook]', box).forEach(function (b) {
      b.onclick = async function () {
        var i = +b.dataset.cchook, pl = JSON.parse(JSON.stringify(p.plano)), x = pl.hooks[i]; if (!x || x.tipo === pl.hook.tipo) return;
        pl.hook = x;
        var r0 = pl.roteiro && pl.roteiro[0];
        if (r0) { if (r0.falar != null) r0.falar = x.texto; else if (r0.texto != null) r0.texto = x.texto; }
        if (pl.texto_tela && pl.texto_tela[0]) pl.texto_tela[0].texto = x.texto.replace(/[.\s]+$/, '').slice(0, 48);
        if (await ccSalvar({ plano: pl })) { ccEv('hook_regerado', p.id, { tipo: x.tipo }); ccRender(); }
      };
    });
    // copiar
    $$('[data-cccp]', box).forEach(function (b) {
      b.onclick = function () {
        var pl = p.plano || {}, k = b.dataset.cccp;
        var t = k === 'hook' ? pl.hook.texto : k === 'legenda' ? ($('#ccLeg') ? $('#ccLeg').value : pl.legenda) : k === 'tags' ? ((pl.hashtags && pl.hashtags.lista) || []).map(function (x) { return '#' + x.tag; }).join(' ') : pl.cta;
        copiar(t || '', null, k); ccEv('plano_salvo', p.id, { copiou: k });
      };
    });
    // legenda editável
    var leg = $('#ccLeg');
    if (leg) leg.onchange = async function () {
      var pl = JSON.parse(JSON.stringify(p.plano)); pl.legenda = leg.value.slice(0, 2200);
      if (await ccSalvar({ plano: pl })) { toast('Legenda salva.'); if (!st.ccEditou) { st.ccEditou = true; ccEv('plano_editado', p.id, { campo: 'legenda' }); } }
    };
    // referências
    var add = $('#refAdd');
    if (add) add.onclick = async function () {
      var nome = $('#refNome').value.replace(/[<>]/g, '').trim().slice(0, 60), url = $('#refUrl').value.trim(), motivo = $('#refMotivo').value.replace(/[<>]/g, '').trim().slice(0, 140);
      if (nome.length < 2) return toast('Informe o nome ou @ do perfil.');
      if (url && !/^https:\/\/[^\s]+$/.test(url)) return toast('O link precisa começar com https://');
      var refs = (p.referencias || []).concat([{ nome: nome, plataforma: $('#refPlat').value, url: url || null, motivo: motivo }]);
      if (await ccSalvar({ referencias: refs })) { ccEv('plano_editado', p.id, { campo: 'referencia' }); ccRender(); }
    };
    $$('[data-ccref-del]', box).forEach(function (b) { b.onclick = async function () { var refs = (p.referencias || []).filter(function (_, i) { return i !== +b.dataset.ccrefDel; }); if (await ccSalvar({ referencias: refs })) ccRender(); }; });
    // status
    var prox = $('#ccProx'); if (prox) prox.onclick = async function () { prox.disabled = true; if (await ccMudarStatus(CC_PROXIMO[p.status][0])) ccRender(); else prox.disabled = false; };
    var vol = $('#ccVolta'); if (vol) vol.onclick = async function () { if (await ccMudarStatus(CC_STATUS[ccIdx(p.status) - 1][0])) ccRender(); };
    // publicação
    var reg = $('#pubReg');
    if (reg) reg.onclick = async function () {
      var l = ccLerUrl($('#pubUrl').value); if (!l) return toast('Cole o link completo da publicação, começando com https://');
      var dia = $('#pubData').value || new Date().toISOString().slice(0, 10);
      reg.disabled = true;
      try {
        var c = await sb.from('evolui_conteudos').insert({ user_id: st.user.id, origem: 'link', plataforma: l.plataforma, url: l.url, url_normalizada: l.normalizada, id_externo: l.id, titulo: p.titulo.slice(0, 200), publicado_em: dia + 'T12:00:00Z', status: 'publicado', metadados: { planejamento_id: p.id, slug: p.slug } }).select('id').single();
        if (c.error) { toast(/duplicate|unique|23505/.test(c.error.message + (c.error.code || '')) ? 'Este link já está registrado em outro conteúdo.' : 'Não foi possível registrar agora.'); reg.disabled = false; return; }
        // publicação oficial (base para as métricas futuras: evolui_metricas aponta para esta linha)
        var pb = await sb.from('evolui_publicacoes').insert({ user_id: st.user.id, conteudo_id: c.data.id, rede: l.plataforma, url: l.url, id_externo: l.id, publicado_em: dia + 'T12:00:00Z' }).select('id').single();
        var ok = await ccMudarStatus('publicado', { conteudo_id: c.data.id, publicacao: { plataforma: l.plataforma, url: l.url, data: dia, publicacao_id: pb.error ? null : pb.data.id, embed: l.plataforma === 'youtube' && l.id ? { tipo: 'youtube', id: l.id } : null } });
        if (ok) { ccEv('publicacao_registrada', p.id, { plataforma: l.plataforma, embed: !!(l.plataforma === 'youtube' && l.id) }); toast('Publicação registrada.'); ccRender(); } else reg.disabled = false;
      } catch (e) { toast('Não foi possível registrar agora.'); reg.disabled = false; }
    };
    $('#ccApagar').onclick = async function () {
      if (!window.confirm('Apagar este planejamento? Isso não pode ser desfeito.')) return;
      ccEv('descartou', p.id, { status: p.status });
      var x = await sb.from('evolui_planejamentos').delete().eq('id', p.id);
      if (x.error) return toast('Não foi possível apagar agora.');
      if (p.conteudo_id) { await sb.from('evolui_publicacoes').delete().eq('conteudo_id', p.conteudo_id); await sb.from('evolui_conteudos').delete().eq('id', p.conteudo_id); }
      toast('Planejamento apagado.'); ir('historico');
    };
  }
  async function ccGerar(btn, refazer) {
    var p = st.cc, msg = $('#ccGerarMsg');
    var oc = CC_OBJ.filter(function (o) { return o[0] === p.objetivo; })[0];
    btn.disabled = true; msg.innerHTML = '<p class="muted">Montando o planejamento para o seu ramo…</p>';
    var origem = p.origem || {}, ideia = origem.ideia || {};
    try {
      var r = await E.api('planejar', {
        ideia: { titulo: p.titulo, descricao: ideia.descricao || '', formato: ideia.formato || null }, formato: p.formato || 'reels',
        objetivo: oc && oc[2] ? oc[2] : undefined, termo: p.termo || '', tema: p.termo || '',
        fato: (p.insight && p.insight.fato && p.insight.fato.texto) || '', evitar_hooks: p.plano_antigo_hooks || []
      }, 'evolui-criar');
      if (!r || !r.hook || !r.roteiro) throw new Error('Resposta incompleta.');
      var plano = { hook: r.hook, hooks: r.hooks, promessa: r.promessa, roteiro: r.roteiro, duracao: r.duracao, guia_gravacao: r.guia_gravacao, texto_tela: r.texto_tela, legenda: r.legenda, hashtags: r.hashtags, cta: r.cta, versao: r.algorithm_version };
      var ins = Object.assign({}, p.insight || {}, { interpretacao: r.insight.interpretacao, sugestao: r.insight.sugestao, aviso: r.insight.aviso });
      var novoStatus = ccIdx(p.status) < 1 ? 'planejando' : p.status;
      if (await ccSalvar({ plano: plano, insight: ins, status: novoStatus, objetivo: p.objetivo || null, formato: p.formato || 'reels' })) {
        ccEv('plano_gerado', p.id, { formato: p.formato, objetivo: p.objetivo || null, hook: r.hook.tipo, refez: !!p.plano_antigo_hooks });
        p.plano_antigo_hooks = null; ccRender();
      } else btn.disabled = false;
    } catch (e) { var m0 = (e && e.message) || ''; msg.innerHTML = '<p class="muted">' + (/Módulo inválido/.test(m0) ? 'O planejamento está sendo ativado. Tente de novo em alguns minutos.' : esc(m0 || 'Não foi possível montar agora.') + ' Tente de novo em instantes.') + '</p>'; btn.disabled = false; }
  }
  // lista "Seus conteúdos" (Home: até 3; Histórico: todos)
  function ccItemLista(x) {
    return '<button class="cc-item" data-cc-abrir="' + esc(x.slug) + '"><span class="cc-item-t">' + esc(x.titulo) + '</span><span class="cc-item-m"><span class="pill">' + esc(ccRotStatus(x.status)) + '</span>' + esc((CC_FORMATOS.filter(function (f) { return f[0] === x.formato; })[0] || [, ''])[1]) + ' · ' + data(x.atualizado_em) + '</span></button>';
  }
  async function ccListar(limite) {
    var r = await sb.from('evolui_planejamentos').select('slug,titulo,status,formato,atualizado_em').order('atualizado_em', { ascending: false }).limit(limite);
    return r.error ? [] : (r.data || []);
  }
  async function carregarMeusConteudos() {
    var box = $('#meusConteudos'); if (!box) return;
    try {
      var l = await ccListar(3); if (!l.length || !$('#meusConteudos')) return;
      box.innerHTML = '<div class="entre"><h3>Seus conteúdos</h3><button class="btn ghost sm" id="ccTodos">Ver todos</button></div><div class="cc-lista">' + l.map(ccItemLista).join('') + '</div>';
      box.hidden = false; $('#ccTodos').onclick = function () { ir('historico', { seg: 'conteudos' }); };
    } catch (e) { /* sem lista */ }
  }
  async function listaConteudos() {
    var L = $('#lista'); if (!L) return;
    L.innerHTML = '<p class="muted">Carregando…</p>';
    var l = await ccListar(60);
    if (!$('#lista')) return;
    L.innerHTML = l.length ? '<div class="cc-lista">' + l.map(ccItemLista).join('') + '</div>' : '<div class="vazio"><p class="muted">Você ainda não planejou nenhum conteúdo. Em qualquer ideia, toque em "Usar esta ideia".</p><button class="btn" id="irBuscar">Buscar ideias</button></div>';
    var ib = $('#irBuscar'); if (ib) ib.onclick = function () { ir('buscar'); };
  }
  document.addEventListener('click', function (e) { var b = e.target.closest && e.target.closest('[data-cc-abrir]'); if (b) abrirConteudo(b.dataset.ccAbrir); });

  // ---------------------------------------------------------------- início
  async function iniciar() {
    if (!sb) { $('#raiz').innerHTML = '<div class="carregando-tela"><p>Não foi possível carregar. Recarregue a página.</p></div>'; return; }
    var q = new URLSearchParams(location.hash.slice(1) || location.search.slice(1));
    var erroOauth = q.get('error_description');
    var s = await E.sessao();
    if (!s && /access_token=/.test(location.hash)) { await new Promise(function (r) { setTimeout(r, 900); }); s = await E.sessao(); }
    if (!s) { telaEntrar(erroOauth ? 'O Google não autorizou o acesso: ' + erroOauth.replace(/\+/g, ' ') : null); return; }
    st.user = s.user;
    try { await carregarPerfil(); } catch (e) { /* segue: onboarding cria o perfil */ }
    montarApp();
    // fonte das imagens dos cards: acervo administrado no painel Felipe Branding (RPC evolui_imagem_para_card); falha = card sem foto
    if (CI() && CI().Banco && CI().Banco.fonte) CI().Banco.fonte(function (q) {
      var area = q.area || (q.origem === 'radar' && st.perfil && st.perfil.ramo) || '';
      return sb.rpc('evolui_imagem_para_card', { p: { area: area, subramo: q.subramo || '', tema: q.tema || '', tags: q.tags || [], plataforma: q.plataforma || '', formato: q.formato || '', tipo_card: q.tipo_card || '', evitar: q.evitar || [] } }).then(function (r) {
        var d = r && r.data; if (!d || !d.arquivo) return null;
        var u = sb.storage.from('evolui-imagens').getPublicUrl(d.arquivo); u = u && u.data && u.data.publicUrl;
        return u ? { src: u, alt: d.alt || '', id: d.id || d.arquivo } : null;
      });
    });
    var aba = (location.hash || '').replace('#', ''), mc = aba.match(/^c\/([a-f0-9]{10})$/);
    if (mc) abrirConteudo(mc[1], { novo: true }); else ir(ABAS.indexOf(aba) >= 0 ? aba : 'buscar');
    var pag = new URLSearchParams(location.search).get('pagamento');
    if (pag) {
      toast(pag === 'ok' ? 'Pagamento recebido! Seu plano é liberado em instantes.' : pag === 'pendente' ? 'Pagamento em análise. Avisamos quando for aprovado.' : 'O pagamento não foi concluído. Você pode tentar de novo.');
      history.replaceState(null, '', location.pathname + location.hash);
      if (pag === 'ok') setTimeout(async function () { await carregarPerfil(); montarApp(); ir(st.aba); }, 6000);
    }
    // veio do site querendo um plano (botão "Quero o Pro/Master")
    var desejado = new URLSearchParams(location.search).get('planos');
    try { desejado = desejado || sessionStorage.getItem('evolui_plano_desejado'); sessionStorage.removeItem('evolui_plano_desejado'); } catch (e) { /* ok */ }
    if (desejado && /^(pro|master)$/.test(desejado)) history.replaceState(null, '', location.pathname + location.hash);
    else desejado = null;
    if (!st.perfil || !st.perfil.onboarding_ok) { if (desejado) st.planoPendente = desejado; abrirOnboarding(false); }
    else if (desejado) abrirPlanos('site', desejado);
    else setTimeout(function () { perguntaDoDia(false); }, 2500);
    registrar('abriu_app', {});
    sb.auth.onAuthStateChange(function (ev) { if (ev === 'SIGNED_OUT') telaEntrar(); if (ev === 'PASSWORD_RECOVERY') novaSenha(); });
  }
  window.addEventListener('hashchange', function () {
    var a = location.hash.replace('#', ''), mc = a.match(/^c\/([a-f0-9]{10})$/);
    if (!st.user) return;
    if (mc) { if (!st.cc || st.cc.slug !== mc[1] || st.aba !== 'c') abrirConteudo(mc[1], { novo: true }); return; }
    if (a !== st.aba && ABAS.indexOf(a) >= 0) ir(a);
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
  // Fontes ficam fora da leitura principal; o ícone i abre o detalhe contextual.
  document.addEventListener('click', function(e){
    var b=e.target.closest && e.target.closest('.info-btn');
    if(!b) return;
    var card=b.closest('.card');
    var d=card && card.querySelector('.op-fontes');
    if(d){ d.open=true; d.scrollIntoView({behavior:'smooth',block:'nearest'}); }
    else { var origin=card && card.querySelector('.rep-origin'); if(origin) origin.classList.toggle('is-expanded'); }
  });
})();
