// EvoluiSocial — SUA CONTA NO LABORATÓRIO (Fase 5B). ES5, funções puras, sem rede.
// Números do perfil (seguidores, seguindo, publicações) digitados pela pessoa, com histórico e variação.
// A Evolui NÃO tem integração aprovada com Instagram nem TikTok: nada aqui é lido da rede. YouTube é ponto de extensão futuro.
(function (raiz) {
  'use strict';
  var VERSAO = 'conta-v1';
  var AVISO_MANUAL = 'A EvoluiSocial ainda não tem integração oficial aprovada com Instagram nem TikTok. Os números abaixo são os que você digita, a partir do que o app da rede mostra. Eles não são lidos da sua conta.';
  var AVISO_YOUTUBE = 'YouTube: no futuro dá para buscar os inscritos automaticamente pelo canal público. Em breve; por enquanto, digite o número.';
  var REDES = { instagram: 'Instagram', tiktok: 'TikTok', youtube: 'YouTube' };
  var CAMPOS = [['seguidores', 'Seguidores'], ['seguindo', 'Seguindo'], ['publicacoes', 'Publicações']];
  var GANHOS_PRO = ['Todas as suas redes lado a lado', 'Histórico completo e gráfico de evolução de cada rede', 'Variação por período (últimos 30 dias)'];

  function fmtInt(n) { return n == null || !isFinite(n) ? '—' : String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
  function dataBR(iso) { var p = String(iso || '').slice(0, 10).split('-'); return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : ''; }
  function utc(iso) { var p = String(iso).slice(0, 10).split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); }
  function dias(a, b) { return Math.round((utc(b) - utc(a)) / 864e5); }
  function pctTxt(x) { var v = Math.abs(x * 100); return (x < 0 ? '−' : x > 0 ? '+' : '') + v.toFixed(v < 10 ? 1 : 0).replace('.', ',') + '%'; }
  function lerInt(v) {
    if (v == null) return null; var t = String(v).trim(); if (t === '') return null;
    if (/^\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, '');
    if (!/^\d+$/.test(t)) return NaN; return parseInt(t, 10);
  }

  // Plano real do perfil: free vê a rede principal (a mais antiga cadastrada); pro e master veem todas e o histórico.
  function planoRedes(plano, redes) {
    var pl = plano === 'pro' || plano === 'master' ? plano : 'free';
    var ord = (redes || []).slice().sort(function (a, b) { return String(a.criado_em || '').localeCompare(String(b.criado_em || '')) || String(a.rede).localeCompare(String(b.rede)); });
    var pago = pl !== 'free';
    return { plano: pl, principal: ord[0] || null, visiveis: pago ? ord : ord.slice(0, 1), bloqueadas: pago ? [] : ord.slice(1), historico: pago, variacaoPeriodo: pago };
  }

  function validarMedicaoRede(raw, hojeIso) {
    raw = raw || {}; var erros = [], v = {}, i, n, algum = false;
    var d = String(raw.medido_em || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || isNaN(new Date(d + 'T12:00:00').getTime())) erros.push('Informe a data da medição.');
    else if (hojeIso && d > hojeIso) erros.push('A data não pode estar no futuro.');
    v.medido_em = d;
    for (i = 0; i < CAMPOS.length; i++) {
      n = lerInt(raw[CAMPOS[i][0]]);
      if (n !== null && (isNaN(n) || n > 2000000000)) { erros.push(CAMPOS[i][1] + ': use um número inteiro, sem negativos.'); n = null; }
      v[CAMPOS[i][0]] = n; if (n !== null) algum = true;
    }
    if (v.seguidores == null && !erros.length) erros.push('Informe o número de seguidores.');
    return { ok: !erros.length, erros: erros, valores: v };
  }

  function ordenar(lista) { return (lista || []).slice().sort(function (a, b) { return String(a.medido_em).localeCompare(String(b.medido_em)); }); }
  // resumo da rede: atual, anterior e variação. Texto só descreve; não explica o motivo.
  function resumoRede(lista) {
    var o = ordenar(lista), n = o.length;
    if (!n) return { vazio: true, texto: 'Sem números ainda. Digite os de hoje para começar a acompanhar.' };
    var atual = o[n - 1], ant = n > 1 ? o[n - 2] : null, r = { vazio: false, atual: atual, anterior: ant, medicoes: n };
    if (!ant) { r.texto = 'Primeira medição. A comparação aparece a partir da próxima.'; return r; }
    r.dias = dias(ant.medido_em, atual.medido_em);
    r.dif = atual.seguidores != null && ant.seguidores != null ? atual.seguidores - ant.seguidores : null;
    r.pct = r.dif != null && ant.seguidores > 0 ? r.dif / ant.seguidores : null;
    if (r.dif == null) r.texto = 'Sem seguidores na medição anterior para comparar.';
    else if (r.dif === 0) r.texto = 'Mesmo número de seguidores da medição de ' + dataBR(ant.medido_em) + '.';
    else r.texto = (r.dif > 0 ? '+' : '−') + fmtInt(Math.abs(r.dif)) + ' seguidores' + (r.pct != null ? ' (' + pctTxt(r.pct) + ')' : '') + ' desde ' + dataBR(ant.medido_em) + (r.dias > 0 ? ' (' + r.dias + (r.dias === 1 ? ' dia' : ' dias') + ')' : '') + '.';
    return r;
  }
  // variação dentro de uma janela de N dias terminando na última medição (plano pago)
  function variacaoPeriodo(lista, janelaDias) {
    var o = ordenar(lista), n = o.length; if (n < 2) return null;
    var fim = o[n - 1], i, ini = null;
    for (i = 0; i < n - 1; i++) if (dias(o[i].medido_em, fim.medido_em) <= janelaDias) { ini = o[i]; break; }
    if (!ini || ini.seguidores == null || fim.seguidores == null) return null;
    var dif = fim.seguidores - ini.seguidores;
    return { de: ini.medido_em, ate: fim.medido_em, dias: dias(ini.medido_em, fim.medido_em), dif: dif, pct: ini.seguidores > 0 ? dif / ini.seguidores : null,
      texto: (dif === 0 ? 'Sem mudança' : (dif > 0 ? '+' : '−') + fmtInt(Math.abs(dif)) + ' seguidores' + (ini.seguidores > 0 ? ' (' + pctTxt(dif / ini.seguidores) + ')' : '')) + ' entre ' + dataBR(ini.medido_em) + ' e ' + dataBR(fim.medido_em) + '.' };
  }

  // Sparkline em SVG inline, acessível (role=img + título + descrição em texto). Sem biblioteca.
  function sparkline(lista, opc) {
    opc = opc || {}; var o = ordenar(lista).filter(function (m) { return m.seguidores != null; }), n = o.length;
    if (n < 2) return '';
    var W = opc.largura || 240, H = opc.altura || 56, P = 6, min = Infinity, max = -Infinity, i, pts = [], v;
    for (i = 0; i < n; i++) { v = o[i].seguidores; if (v < min) min = v; if (v > max) max = v; }
    var faixa = max - min || 1;
    for (i = 0; i < n; i++) pts.push([P + (W - 2 * P) * (i / (n - 1)), (H - P) - (H - 2 * P) * ((o[i].seguidores - min) / faixa)]);
    var d = pts.map(function (p, k) { return (k ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join(' '), ult = pts[n - 1];
    var desc = 'Seguidores de ' + fmtInt(o[0].seguidores) + ' em ' + dataBR(o[0].medido_em) + ' para ' + fmtInt(o[n - 1].seguidores) + ' em ' + dataBR(o[n - 1].medido_em) + ', em ' + n + ' medições. Mínimo ' + fmtInt(min) + ', máximo ' + fmtInt(max) + '.';
    var id = 'sp' + (opc.id || Math.abs(hash(desc)).toString(36));
    return '<svg class="spark" role="img" viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '" preserveAspectRatio="none" aria-labelledby="' + id + 't ' + id + 'd"><title id="' + id + 't">' + esc(opc.titulo || 'Evolução de seguidores') + '</title><desc id="' + id + 'd">' + esc(desc) + '</desc>' +
      '<path d="' + d + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/><circle cx="' + ult[0].toFixed(1) + '" cy="' + ult[1].toFixed(1) + '" r="3.5" fill="currentColor"/></svg>';
  }
  function hash(s) { var h = 5381, i; for (i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) | 0; return h; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  var API = { VERSAO: VERSAO, AVISO_MANUAL: AVISO_MANUAL, AVISO_YOUTUBE: AVISO_YOUTUBE, REDES: REDES, CAMPOS: CAMPOS, GANHOS_PRO: GANHOS_PRO, fmtInt: fmtInt, dataBR: dataBR, lerInt: lerInt,
    planoRedes: planoRedes, validarMedicaoRede: validarMedicaoRede, resumoRede: resumoRede, variacaoPeriodo: variacaoPeriodo, sparkline: sparkline, ordenar: ordenar };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else raiz.EvoluiConta = API;
})(typeof window !== 'undefined' ? window : this);
