// EvoluiSocial — RESULTADOS DO DOCUMENTO (Fase 5B). ES5, funções puras, sem rede, sem IA.
// Registro manual de medições, leitura honesta dos números e "padrões observados" com amostra mínima.
// Regra de redação: a Evolui descreve o que os números mostram. Nunca afirma causa, nunca prevê curtidas ou alcance.
(function (raiz) {
  'use strict';
  var VERSAO = 'res-v1';
  var MIN_CONTEUDOS = 3;       // mínimo de conteúdos COM resultado para falar de padrão
  var MIN_GRUPO = 3;           // mínimo de conteúdos no grupo comparado
  var VIS_ESTAVEL = 100;       // abaixo disso a taxa varia demais para ser lida com confiança
  var DIF_RELEVANTE = 0.15;    // diferença relativa mínima entre medianas para dizer "maior" ou "menor"
  var PALAVRAS_POR_SEG = 2.6;

  var STATUS = [['ideia', 'Ideia'], ['escrevendo', 'Escrevendo'], ['pronto_gravar', 'Pronto para gravar'], ['gravado', 'Gravado'], ['publicado', 'Publicado'], ['nao_virou', 'Não virou vídeo']];
  var JANELAS = [['24h', '24 horas'], ['48h', '48 horas'], ['7d', '7 dias'], ['30d', '30 dias'], ['avulsa', 'Outra data']];
  var REDES_PUB = [['instagram', 'Instagram'], ['tiktok', 'TikTok'], ['youtube', 'YouTube'], ['outra', 'Outra']];
  function rotulo(lista, chave) { for (var i = 0; i < lista.length; i++) if (lista[i][0] === chave) return lista[i][1]; return chave; }
  function statusValido(s) { for (var i = 0; i < STATUS.length; i++) if (STATUS[i][0] === s) return true; return false; }

  // ---------- números e formatação (pt-BR)
  function fmtInt(n) { return n == null || !isFinite(n) ? '—' : String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
  function fmtPct(x, casas) { return x == null || !isFinite(x) ? '—' : (x * 100).toFixed(casas == null ? 1 : casas).replace('.', ',') + '%'; }
  function fmtPctSinal(x) { if (x == null || !isFinite(x)) return '—'; var v = Math.round(x * 100); return (v > 0 ? '+' : '') + v + '%'; }
  function lerNumero(v) { // aceita "1.240", "1240", "4,5", vazio -> null; inválido -> NaN
    if (v == null) return null;
    var t = String(v).trim(); if (t === '') return null;
    if (/^\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, '');
    t = t.replace(',', '.');
    if (!/^\d+(\.\d+)?$/.test(t)) return NaN;
    return parseFloat(t);
  }

  // ---------- validação do registro manual
  var CAMPOS_INT = [['visualizacoes', 'Visualizações'], ['alcance', 'Alcance'], ['curtidas', 'Curtidas'], ['comentarios', 'Comentários'], ['compartilhamentos', 'Compartilhamentos'], ['salvamentos', 'Salvamentos']];
  function validarMedicao(raw) {
    raw = raw || {};
    var erros = [], avisos = [], v = {}, i, k, n, algum = false;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(raw.medido_em || ''))) erros.push('Informe a data da medição.');
    else { var d = new Date(raw.medido_em + 'T12:00:00'); if (isNaN(d.getTime())) erros.push('A data da medição não é válida.'); }
    v.medido_em = raw.medido_em;
    v.janela = raw.janela || 'avulsa';
    if (!rotuloExiste(JANELAS, v.janela)) { erros.push('Escolha o momento da medição.'); }
    for (i = 0; i < CAMPOS_INT.length; i++) {
      k = CAMPOS_INT[i][0]; n = lerNumero(raw[k]);
      if (n !== null && (isNaN(n) || n < 0 || Math.floor(n) !== n || n > 2000000000)) { erros.push(CAMPOS_INT[i][1] + ': use um número inteiro, sem negativos.'); v[k] = null; continue; }
      v[k] = n; if (n !== null) algum = true;
    }
    n = lerNumero(raw.retencao_pct);
    if (n !== null && (isNaN(n) || n < 0 || n > 100)) { erros.push('Retenção: use um valor entre 0 e 100.'); v.retencao_pct = null; } else v.retencao_pct = n === null ? null : Math.round(n * 100) / 100;
    n = lerNumero(raw.duracao_video_seg);
    if (n !== null && (isNaN(n) || Math.floor(n) !== n || n < 1 || n > 3600)) { erros.push('Duração do vídeo: informe de 1 a 3600 segundos.'); v.duracao_video_seg = null; } else v.duracao_video_seg = n;
    if (!algum && !erros.length) erros.push('Preencha pelo menos um número (visualizações, curtidas…).');
    if (!erros.length) {
      if (v.visualizacoes != null && v.curtidas != null && v.curtidas > v.visualizacoes) avisos.push('Há mais curtidas do que visualizações. Confira se não trocou os campos.');
      if (v.visualizacoes != null && v.alcance != null && v.alcance > v.visualizacoes) avisos.push('O alcance está maior que as visualizações. Pode acontecer em algumas redes; confira os números.');
    }
    return { ok: !erros.length, erros: erros, avisos: avisos, valores: v };
  }
  function rotuloExiste(lista, chave) { for (var i = 0; i < lista.length; i++) if (lista[i][0] === chave) return true; return false; }
  function validarPublicacao(raw) {
    raw = raw || {}; var erros = [], v = {};
    if (!rotuloExiste(REDES_PUB, raw.rede)) erros.push('Escolha a rede.'); v.rede = raw.rede;
    var u = String(raw.url || '').trim();
    if (u && !/^https:\/\/[^\s"<>]{3,590}$/i.test(u)) erros.push('O link precisa começar com https://');
    v.url = u || null;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(raw.publicado_em || '')) || isNaN(new Date(raw.publicado_em + 'T12:00:00').getTime())) erros.push('Informe a data de publicação.'); v.publicado_em = raw.publicado_em;
    return { ok: !erros.length, erros: erros, valores: v };
  }

  // ---------- cálculos
  function soma(m) { return (m.curtidas || 0) + (m.comentarios || 0) + (m.compartilhamentos || 0) + (m.salvamentos || 0); }
  function temInteracao(m) { return m.curtidas != null || m.comentarios != null || m.compartilhamentos != null || m.salvamentos != null; }
  // taxa de engajamento por visualização = (curtidas + comentários + compartilhamentos + salvamentos) ÷ visualizações
  function taxaEngajamento(m) {
    if (!m || !(m.visualizacoes > 0) || !temInteracao(m)) return null;
    return soma(m) / m.visualizacoes;
  }
  function ordenar(lista) {
    return (lista || []).slice().sort(function (a, b) { return String(a.medido_em).localeCompare(String(b.medido_em)) || String(a.criado_em || '').localeCompare(String(b.criado_em || '')); });
  }
  function relativa(novo, velho) { return velho > 0 && novo != null && velho != null ? (novo - velho) / velho : null; }
  function evolucao(lista) {
    var o = ordenar(lista), saida = [], i, m, ant;
    for (i = 0; i < o.length; i++) {
      m = o[i]; ant = i > 0 ? o[i - 1] : null;
      saida.push({ m: m, taxa: taxaEngajamento(m), taxaAnterior: ant ? taxaEngajamento(ant) : null, varVisualizacoes: ant ? relativa(m.visualizacoes, ant.visualizacoes) : null,
        difVisualizacoes: ant && m.visualizacoes != null && ant.visualizacoes != null ? m.visualizacoes - ant.visualizacoes : null,
        difTaxaPontos: ant && taxaEngajamento(m) != null && taxaEngajamento(ant) != null ? (taxaEngajamento(m) - taxaEngajamento(ant)) * 100 : null });
    }
    return saida;
  }
  function melhorMedicao(lista) {
    var ev = evolucao(lista), melhor = null, i;
    for (i = 0; i < ev.length; i++) if (ev[i].taxa != null && (!melhor || ev[i].taxa > melhor.taxa)) melhor = ev[i];
    return melhor;
  }
  function ultimaComTaxa(lista) {
    var ev = evolucao(lista), i; for (i = ev.length - 1; i >= 0; i--) if (ev[i].taxa != null) return ev[i];
    return null;
  }
  function nomeMed(m) { return m.janela && m.janela !== 'avulsa' ? rotulo(JANELAS, m.janela) : 'a de ' + dataBR(m.medido_em); }
  function dataBR(iso) { var p = String(iso || '').slice(0, 10).split('-'); return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : ''; }

  // Leitura honesta: frases curtas, só descrição. Retorna lista de strings.
  function leitura(lista) {
    var ev = evolucao(lista), L = [], ult, melhor, prim, i;
    if (!ev.length) return ['Ainda não há medições. Registre os números da rede social para ver a leitura aqui.'];
    ult = ev[ev.length - 1];
    L.push('Última medição (' + nomeMed(ult.m) + '): ' + fmtInt(ult.m.visualizacoes) + ' visualizações' + (ult.taxa != null ? ', taxa de engajamento de ' + fmtPct(ult.taxa) + ' (interações ÷ visualizações).' : '. Sem visualizações e interações juntas não dá para calcular a taxa.'));
    if (ev.length >= 2) {
      prim = ev[0];
      if (ult.m.visualizacoes != null && prim.m.visualizacoes != null) L.push('Entre ' + nomeMed(prim.m) + ' e ' + nomeMed(ult.m) + ', as visualizações foram de ' + fmtInt(prim.m.visualizacoes) + ' para ' + fmtInt(ult.m.visualizacoes) + (prim.m.visualizacoes > 0 ? ' (' + fmtPctSinal(relativa(ult.m.visualizacoes, prim.m.visualizacoes)) + ')' : '') + '.');
      if (prim.taxa != null && ult.taxa != null) L.push('A taxa de engajamento foi de ' + fmtPct(prim.taxa) + ' para ' + fmtPct(ult.taxa) + '. A taxa costuma oscilar entre uma medição e outra.');
      melhor = melhorMedicao(lista);
      if (melhor && ev.length >= 2) L.push('A medição com maior taxa foi ' + nomeMed(melhor.m) + ' (' + fmtPct(melhor.taxa) + '). Taxa maior não quer dizer vídeo melhor: público, horário e tema também mudam o número.');
    }
    var pequenas = 0; for (i = 0; i < ev.length; i++) if (ev[i].m.visualizacoes != null && ev[i].m.visualizacoes < VIS_ESTAVEL) pequenas++;
    if (pequenas) L.push('Com menos de ' + VIS_ESTAVEL + ' visualizações, a taxa muda muito de uma medição para outra. Leia com cautela.');
    if (ult.m.retencao_pct != null) L.push('Retenção informada: ' + fmtPct(ult.m.retencao_pct / 100, 0) + (ult.m.duracao_video_seg ? ' em um vídeo de ' + ult.m.duracao_video_seg + ' s.' : '.'));
    return L;
  }

  // ---------- fatores do documento (o que o texto tinha) — descrição, não nota
  var CTA_RE = /(whats|wpp|link|chame|chama|peca|pedido|agende|agenda|compre|comprar|encomend|\bdm\b|direct|comente|salve|clique|toque|reserve|garanta|fale com|orcamento|compartilhe|siga|marque|responda|manda|mande|entre em contato|cadastre|inscreva)/;
  function semAcento(s) { s = String(s == null ? '' : s).toLowerCase(); try { return s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) { return s; } }
  function palavras(t) { var p = String(t || '').split(/\s+/), n = 0, i; for (i = 0; i < p.length; i++) if (/[A-Za-zÀ-ÿ0-9]/.test(p[i])) n++; return n; }
  function faixaDuracao(seg) { return seg == null ? null : seg <= 30 ? 'ate30' : seg <= 60 ? '31a60' : 'mais60'; }
  function fatoresDoc(texto, ctx) {
    ctx = ctx || {}; var t = String(texto || '').trim(), pal = palavras(t), primeira, gancho = 'nenhum_detectado', seg;
    if (!t) gancho = 'sem_texto';
    else {
      var m = t.match(/^[^.!?\n]*[.!?]?/); primeira = m ? m[0] : t;
      if (primeira.indexOf('?') >= 0) gancho = 'pergunta'; else if (/\d/.test(primeira)) gancho = 'numero';
    }
    seg = pal ? Math.max(1, Math.round(pal / PALAVRAS_POR_SEG)) : null;
    return { gancho: gancho, cta: !!t && CTA_RE.test(semAcento(t)), dur_seg: seg, faixa: faixaDuracao(seg), formato: ctx.formato || null, palavras: pal };
  }
  var ROT_GANCHO = { pergunta: 'abertura em pergunta', numero: 'abertura com número', nenhum_detectado: 'abertura sem pergunta nem número' };
  var ROT_FAIXA = { ate30: 'duração estimada de até 30 s', '31a60': 'duração estimada de 31 a 60 s', mais60: 'duração estimada acima de 60 s' };
  var ROT_FORMATO = { reel: 'formato reel/roteiro', stories: 'formato stories', carrossel: 'formato carrossel', legenda: 'formato legenda', bio: 'formato bio' };
  function descreverFatores(f) { // lista para mostrar "o que o documento tinha"
    if (!f) return [];
    var L = [];
    if (f.gancho === 'pergunta') L.push('Abertura em pergunta'); else if (f.gancho === 'numero') L.push('Abertura com número'); else if (f.gancho === 'nenhum_detectado') L.push('Abertura sem pergunta nem número');
    L.push(f.cta ? 'Tinha chamada para ação' : 'Sem chamada para ação detectada');
    if (f.dur_seg) L.push('Duração estimada de fala: ≈ ' + f.dur_seg + ' s');
    if (f.formato && ROT_FORMATO[f.formato]) L.push(ROT_FORMATO[f.formato].charAt(0).toUpperCase() + ROT_FORMATO[f.formato].slice(1));
    return L;
  }

  // ---------- padrões observados (só com amostra mínima)
  function mediana(v) { var a = v.slice().sort(function (x, y) { return x - y; }), n = a.length; return n ? (n % 2 ? a[(n - 1) / 2] : (a[n / 2 - 1] + a[n / 2]) / 2) : null; }
  function taxas(L) { return L.map(function (x) { return x.taxa; }); }
  function fraseGrupo(rot, g, resto) {
    var mg = mediana(taxas(g)), base = 'Nos seus ' + g.length + ' conteúdos com ' + rot + ', a taxa de engajamento mediana foi ' + fmtPct(mg) + '.';
    if (resto.length >= MIN_GRUPO) {
      var mr = mediana(taxas(resto)), dif = mr > 0 ? (mg - mr) / mr : null, cmp;
      if (dif == null || Math.abs(dif) < DIF_RELEVANTE) cmp = 'Nos outros ' + resto.length + ', foi ' + fmtPct(mr) + ': sem diferença clara.';
      else cmp = 'Nos outros ' + resto.length + ', foi ' + fmtPct(mr) + ': ' + (dif > 0 ? 'um pouco acima' : 'um pouco abaixo') + ' do grupo.';
      return base + ' ' + cmp;
    }
    return base + ' Ainda não há outros ' + MIN_GRUPO + ' conteúdos para comparar.';
  }
  // itens: [{ fatores, taxa }]  (taxa null = sem resultado, ignorado)
  function padroes(itens) {
    var c = (itens || []).filter(function (x) { return x && x.taxa != null && x.fatores; }), n = c.length, obs = [];
    if (n < MIN_CONTEUDOS) return { amostra: n, minimo: MIN_CONTEUDOS, suficiente: false, observacoes: [], aviso: n === 0 ? 'Registre resultados de pelo menos ' + MIN_CONTEUDOS + ' conteúdos para a Evolui mostrar padrões dos seus números.' : 'Você tem resultado de ' + n + ' conteúdo(s). Com ' + MIN_CONTEUDOS + ' ou mais, a Evolui passa a mostrar padrões dos seus números.' };
    function grupo(pred) { var g = [], r = []; c.forEach(function (x) { (pred(x.fatores) ? g : r).push(x); }); return { g: g, r: r }; }
    function tenta(id, rot, pred) { var s = grupo(pred); if (s.g.length >= MIN_GRUPO) obs.push({ id: id, n: s.g.length, comparados: s.r.length, texto: fraseGrupo(rot, s.g, s.r) }); }
    ['pergunta', 'numero', 'nenhum_detectado'].forEach(function (k) { tenta('gancho_' + k, ROT_GANCHO[k], function (f) { return f.gancho === k; }); });
    tenta('cta_sim', 'chamada para ação', function (f) { return f.cta === true; });
    tenta('cta_nao', 'nenhuma chamada para ação detectada', function (f) { return f.cta === false; });
    ['ate30', '31a60', 'mais60'].forEach(function (k) { tenta('dur_' + k, ROT_FAIXA[k], function (f) { return f.faixa === k; }); });
    ['reel', 'stories', 'carrossel', 'legenda'].forEach(function (k) { tenta('fmt_' + k, ROT_FORMATO[k], function (f) { return f.formato === k; }); });
    return { amostra: n, minimo: MIN_CONTEUDOS, suficiente: true, observacoes: obs,
      aviso: obs.length ? 'Cada conteúdo entra com a medição mais recente. São observações sobre os seus números, com amostra pequena: tema, horário e público também pesam. Repita antes de tratar como regra.' : 'Com ' + n + ' conteúdos ainda não há um grupo com ' + MIN_GRUPO + ' ou mais para comparar. Continue registrando.' };
  }
  // junta estados (documentos publicados) e medições -> itens para padroes()
  function itensParaPadroes(estados, medicoes) {
    var por = {}; (medicoes || []).forEach(function (m) { (por[m.doc_id] = por[m.doc_id] || []).push(m); });
    return (estados || []).filter(function (e) { return e.status === 'publicado' && e.fatores; }).map(function (e) {
      var u = ultimaComTaxa(por[e.doc_id] || []); return { doc_id: e.doc_id, fatores: e.fatores, taxa: u ? u.taxa : null };
    });
  }

  // ---------- regra de redação: nada de causalidade nem previsão
  var PROIBIDAS = [/\bcaus(a|as|ou|aram|ando|ar)\b/i, /por isso/i, /gra[çc]as a/i, /fez com que/i, /\bprov(a|ou|am) que/i, /comprova/i, /garant(e|iu|ia|imos)\b/i, /\bdevido a\b/i,
    /vai (bombar|performar|viralizar|render|funcionar|ter|dar)/i, /\bvir(al|alizar)\b/i, /\b(ir[áa]|ser[áa]|ter[áa]) (curtidas|alcance|resultado)/i, /com certeza/i, /certamente/i, /o segredo/i, /funciona para voc[êe]/i, /\bpor conta d[oa]/i];
  function redacaoSegura(texto) {
    var achados = [], i, t = String(texto || '');
    for (i = 0; i < PROIBIDAS.length; i++) if (PROIBIDAS[i].test(t)) achados.push(PROIBIDAS[i].source);
    return { ok: !achados.length, achados: achados };
  }

  var API = { VERSAO: VERSAO, MIN_CONTEUDOS: MIN_CONTEUDOS, MIN_GRUPO: MIN_GRUPO, VIS_ESTAVEL: VIS_ESTAVEL, STATUS: STATUS, JANELAS: JANELAS, REDES_PUB: REDES_PUB, CAMPOS_INT: CAMPOS_INT,
    rotulo: rotulo, statusValido: statusValido, fmtInt: fmtInt, fmtPct: fmtPct, fmtPctSinal: fmtPctSinal, lerNumero: lerNumero, dataBR: dataBR,
    validarMedicao: validarMedicao, validarPublicacao: validarPublicacao, taxaEngajamento: taxaEngajamento, evolucao: evolucao, melhorMedicao: melhorMedicao, ultimaComTaxa: ultimaComTaxa, leitura: leitura,
    fatoresDoc: fatoresDoc, descreverFatores: descreverFatores, padroes: padroes, itensParaPadroes: itensParaPadroes, mediana: mediana, redacaoSegura: redacaoSegura };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else raiz.EvoluiResultados = API;
})(typeof window !== 'undefined' ? window : this);
