// EvoluiSocial — importar dados do TikTok e do YouTube a partir do relatório (CSV) que a própria pessoa baixa.
// Funções PURAS (sem rede, sem banco, sem DOM): o arquivo é lido no navegador; só título, link, data e números seguem adiante.
// Não usa API de rede social nem pede senha. Os nomes das colunas mudam de idioma e de versão, então a leitura é por
// sinônimos e a pessoa confere uma prévia antes de salvar.
(function (raiz) {
  'use strict';
  var MAX_BYTES = 1024 * 1024, MAX_LINHAS = 200, MAX_INT = 2147483647;

  function semAcento(s) { return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim(); }

  // CSV: aceita vírgula, ponto e vírgula ou tab; aspas duplas; BOM; quebras CRLF.
  function lerCSV(texto) {
    var t = String(texto || '').replace(/^﻿/, '');
    var primeira = t.split(/\r?\n/, 1)[0] || '';
    var cand = [',', ';', '\t'], sep = ',', melhor = -1;
    cand.forEach(function (c) { var n = primeira.split(c).length; if (n > melhor) { melhor = n; sep = c; } });
    var linhas = [], campo = '', linha = [], aspas = false;
    for (var i = 0; i < t.length; i++) {
      var ch = t[i];
      if (aspas) {
        if (ch === '"') { if (t[i + 1] === '"') { campo += '"'; i++; } else aspas = false; } else campo += ch;
      } else if (ch === '"') aspas = true;
      else if (ch === sep) { linha.push(campo); campo = ''; }
      else if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && t[i + 1] === '\n') i++;
        linha.push(campo); campo = '';
        if (linha.some(function (x) { return x !== ''; })) linhas.push(linha);
        linha = [];
      } else campo += ch;
    }
    linha.push(campo); if (linha.some(function (x) { return x !== ''; })) linhas.push(linha);
    return linhas;
  }

  var SINONIMOS = {
    url: ['video link', 'link do video', 'url do video', 'video url', 'link da publicacao', 'post url', 'permalink', 'link', 'url'],
    id: ['video id', 'id do video', 'conteudo', 'content', 'video'],
    titulo: ['titulo do video', 'video title', 'titulo', 'title', 'video description', 'descricao do video', 'descricao', 'description'],
    data: ['horario de publicacao do video', 'video publish time', 'data de publicacao', 'publish date', 'post time', 'date posted', 'horario da publicacao', 'create time', 'data'],
    visualizacoes: ['visualizacoes', 'total de visualizacoes', 'video views', 'total views', 'views'],
    curtidas: ['curtidas', 'total de curtidas', 'total likes', 'likes'],
    comentarios: ['comentarios', 'total de comentarios', 'total comments', 'comments added', 'comments'],
    compartilhamentos: ['compartilhamentos', 'total de compartilhamentos', 'total shares', 'shares'],
    salvamentos: ['salvamentos', 'adicionados aos favoritos', 'total favorites', 'favorites', 'saves', 'bookmarks'],
    alcance: ['espectadores unicos', 'alcance', 'reach', 'unique viewers']
  };
  var CAMPOS_METRICA = ['visualizacoes', 'curtidas', 'comentarios', 'compartilhamentos', 'salvamentos', 'alcance'];

  // devolve { campo: indiceDaColuna } — o primeiro sinônimo (mais específico) que existir vence.
  function detectarColunas(cabecalho) {
    var norm = cabecalho.map(semAcento), mapa = {};
    Object.keys(SINONIMOS).forEach(function (campo) {
      for (var i = 0; i < SINONIMOS[campo].length; i++) {
        var ix = norm.indexOf(SINONIMOS[campo][i]);
        if (ix >= 0 && Object.keys(mapa).every(function (k) { return mapa[k] !== ix; })) { mapa[campo] = ix; break; }
      }
    });
    return mapa;
  }

  // inteiro >= 0 ou null. Aceita "1.234", "1,234", "1 234", "12,5 mil" não (ambíguo): vira null.
  function numero(v) {
    var s = String(v == null ? '' : v).trim();
    if (!s || /^[-–—]+$/.test(s) || /^n\/?a$/i.test(s)) return null;
    s = s.replace(/\s/g, '');
    if (!/^\d[\d.,]*$/.test(s)) return null;
    var pts = (s.match(/\./g) || []).length, vgs = (s.match(/,/g) || []).length;
    if (pts && vgs) { var ult = Math.max(s.lastIndexOf('.'), s.lastIndexOf(',')); s = s.slice(0, ult).replace(/[.,]/g, '') + '.' + s.slice(ult + 1); }
    else if (pts + vgs > 1) s = s.replace(/[.,]/g, '');
    else if (pts + vgs === 1) { var d = s.split(/[.,]/)[1]; s = d.length === 3 ? s.replace(/[.,]/, '') : s.replace(',', '.'); }
    var n = Math.round(Number(s));
    return isFinite(n) && n >= 0 && n <= MAX_INT ? n : null;
  }

  // data -> 'AAAA-MM-DD' ou null. Aceita ISO, dd/mm/aaaa (padrão do Brasil) e textos que o Date entende.
  function dia(v) {
    var s = String(v == null ? '' : v).trim(), m;
    if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})/))) return ok(+m[1], +m[2], +m[3]);
    if ((m = s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})/))) return ok(+m[3], +m[2], +m[1]);
    var t = Date.parse(s); if (isFinite(t)) { var d = new Date(t); return ok(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate()); }
    return null;
    function ok(a, me, di) {
      if (a < 2005 || a > 2100 || me < 1 || me > 12 || di < 1 || di > 31) return null;
      var dt = new Date(Date.UTC(a, me - 1, di)); if (dt.getUTCMonth() !== me - 1) return null;
      if (dt.getTime() > Date.now() + 864e5) return null;
      return a + '-' + String(me).padStart(2, '0') + '-' + String(di).padStart(2, '0');
    }
  }

  // link de vídeo -> { plataforma, url, normalizada, id } ou null. Só https e só TikTok/YouTube; tira parâmetros de rastreio.
  function lerLink(txt, plataformaEsperada) {
    var u; try { u = new URL(String(txt || '').trim()); } catch (e) { return null; }
    if (u.protocol !== 'https:') return null;
    var host = u.hostname.replace(/^www\.|^m\./, ''), id = null, plat = null, m;
    if (host === 'youtu.be' || /(^|\.)youtube\.com$/.test(host)) {
      plat = 'youtube';
      m = host === 'youtu.be' ? u.pathname.match(/^\/([\w-]{11})/) : (u.searchParams.get('v') || '').match(/^([\w-]{11})$/) || u.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]{11})/);
      id = m ? m[1] : null; if (!id) return null;
      var base = 'https://www.youtube.com/watch?v=' + id; return { plataforma: plat, url: base, normalizada: base, id: id };
    }
    if (/(^|\.)tiktok\.com$/.test(host)) {
      plat = 'tiktok'; m = u.pathname.match(/^\/(@[A-Za-z0-9._-]{1,40})\/video\/(\d{6,25})/);
      if (!m) return null;
      var url = 'https://www.tiktok.com/' + m[1] + '/video/' + m[2]; return { plataforma: plat, url: url, normalizada: url, id: m[2] };
    }
    return null;
  }

  function linkDoId(id) { return /^[\w-]{11}$/.test(id) ? lerLink('https://www.youtube.com/watch?v=' + id) : null; }

  // monta as linhas prontas para salvar. plataforma: 'youtube' | 'tiktok' (o que a pessoa escolheu).
  function analisar(texto, plataforma) {
    var r = { colunas: {}, linhas: [], ignoradas: { semLink: 0, linkDeOutraRede: 0, duplicada: 0, semNumero: 0 }, truncado: false, erro: null };
    if (plataforma !== 'youtube' && plataforma !== 'tiktok') { r.erro = 'Escolha YouTube ou TikTok.'; return r; }
    if (String(texto || '').length > MAX_BYTES) { r.erro = 'Arquivo grande demais (máximo 1 MB).'; return r; }
    var tab = lerCSV(texto);
    if (tab.length < 2) { r.erro = 'Não encontrei linhas de dados nesse arquivo.'; return r; }
    var mapa = detectarColunas(tab[0]); r.colunas = mapa;
    if (mapa.url == null && mapa.id == null) { r.erro = 'Não achei a coluna com o link ou o ID do vídeo. Sem ela não dá para ligar os números ao vídeo.'; return r; }
    if (!CAMPOS_METRICA.some(function (c) { return mapa[c] != null; })) { r.erro = 'Não achei nenhuma coluna de números (visualizações, curtidas…).'; return r; }
    var vistos = {};
    for (var i = 1; i < tab.length; i++) {
      var l = tab[i], get = function (c) { return mapa[c] != null ? l[mapa[c]] : ''; }, lk = null;
      if (mapa.url != null && String(get('url')).trim()) lk = lerLink(get('url'));
      else if (mapa.id != null && plataforma === 'youtube') lk = linkDoId(String(get('id')).trim());
      if (!lk) { r.ignoradas.semLink++; continue; }
      if (lk.plataforma !== plataforma) { r.ignoradas.linkDeOutraRede++; continue; }
      if (vistos[lk.normalizada]) { r.ignoradas.duplicada++; continue; }
      var met = {}, tem = false;
      CAMPOS_METRICA.forEach(function (c) { var n = numero(get(c)); if (n != null) { met[c] = n; tem = true; } });
      if (!tem) { r.ignoradas.semNumero++; continue; }
      if (r.linhas.length >= MAX_LINHAS) { r.truncado = true; break; }
      vistos[lk.normalizada] = 1;
      r.linhas.push({ plataforma: lk.plataforma, url: lk.url, normalizada: lk.normalizada, id: lk.id, titulo: String(get('titulo')).replace(/\s+/g, ' ').trim().slice(0, 200) || null, publicado_em: dia(get('data')), metricas: met });
    }
    if (!r.linhas.length) r.erro = 'Nenhum vídeo com link e números foi encontrado. Confira se escolheu a rede certa.';
    return r;
  }

  var API = { analisar: analisar, lerCSV: lerCSV, detectarColunas: detectarColunas, numero: numero, dia: dia, lerLink: lerLink, CAMPOS_METRICA: CAMPOS_METRICA, MAX_LINHAS: MAX_LINHAS, MAX_BYTES: MAX_BYTES };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else raiz.EvoluiImportar = API;
})(typeof window !== 'undefined' ? window : this);
