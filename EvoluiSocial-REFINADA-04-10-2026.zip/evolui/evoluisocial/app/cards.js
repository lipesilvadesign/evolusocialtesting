/* Evolui · Card Intelligence System
 * Dados estruturados -> Card Engine (normaliza) -> Layout Engine (escolhe a composição) -> Visual Engine (SVG/HTML)
 * -> Motion Engine (IN, OUT e STAND; count-up, gráficos). Sem hover, sem parallax. Sem rede, sem dependências.
 * Regra de ouro: o card só mostra o que o dado traz. Nada é inventado: sem métrica, sem gráfico; sem série, sem linha.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EvoluiCards = factory();
})(typeof window !== 'undefined' ? window : this, function () {
  'use strict';

  // ---------- tokens de movimento (espelham as variáveis --ci-* do CSS; nada de valores soltos pelo código)
  var MOTION = { fast: 160, normal: 320, slow: 640, chart: 900, number: 900, stagger: 70 };
  var EASE = { standard: 'cubic-bezier(.2,.8,.2,1)', emphasized: 'cubic-bezier(.16,1,.3,1)', enter: 'cubic-bezier(0,0,.2,1)', exit: 'cubic-bezier(.4,0,1,1)' };

  // ---------- cor como código semântico da informação
  var TIPOS = {
    tendencia: { cor: 'ciano', rot: 'Tendência' }, movimento: { cor: 'azul', rot: 'Movimento' }, sinal: { cor: 'azul', rot: 'Sinal' },
    insight: { cor: 'lilas', rot: 'Insight' }, oportunidade: { cor: 'rosa', rot: 'Oportunidade' }, ideia: { cor: 'azulrosa', rot: 'Ideia' },
    aprendizado: { cor: 'lilas', rot: 'Aprendizado' }, resultado: { cor: 'azul', rot: 'Resultado' }, desempenho: { cor: 'azul', rot: 'Desempenho' },
    mercado: { cor: 'azul', rot: 'Mercado' }, alerta: { cor: 'alerta', rot: 'Atenção' }
  };
  var ALIAS = { trend: 'tendencia', movement: 'movimento', news: 'movimento', noticia: 'movimento', signal: 'sinal', opportunity: 'oportunidade', idea: 'ideia',
    learning: 'aprendizado', experiment: 'aprendizado', result: 'resultado', performance: 'desempenho', market: 'mercado', competitor: 'mercado', concorrente: 'mercado', alert: 'alerta' };

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(x) { return typeof x === 'number' && isFinite(x); }
  function txt(x, n) { x = String(x == null ? '' : x).trim(); return x.length > n ? x.slice(0, n - 1) + '…' : x; }
  function urlHttps(u) { try { var p = new URL(String(u)); return p.protocol === 'https:' ? p.href : ''; } catch (e) { return ''; } }
  function hash(s) { var h = 2166136261; s = String(s); for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } h ^= h >>> 16; h = Math.imul(h, 0x85ebca6b); h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35); h ^= h >>> 16; return h >>> 0; }

  // ---------- CARD ENGINE: valida e normaliza. Sem título, sem card.
  function normalizar(d) {
    if (!d || typeof d !== 'object') return null;
    var tipo = String(d.type || d.tipo || '').toLowerCase(); tipo = ALIAS[tipo] || tipo;
    if (!TIPOS[tipo]) tipo = 'sinal';
    var title = txt(d.title || d.titulo, 120); if (!title) return null;
    var serie = (d.series || d.serie || []).filter(num).slice(0, 60);
    var barras = (d.bars || d.barras || []).filter(function (b) { return b && num(b.value) && b.label; }).slice(0, 6).map(function (b) { return { label: txt(b.label, 18), value: b.value }; });
    var steps = (d.steps || []).filter(function (s) { return s && s.label; }).slice(0, 3).map(function (s) { return { label: txt(s.label, 20), value: txt(s.value, 60) }; });
    var acao = d.action || d.acao;
    return {
      tipo: tipo, cor: TIPOS[tipo].cor, rot: TIPOS[tipo].rot, title: title, desc: txt(d.description || d.desc || d.descricao, 220),
      metric: d.metric == null ? '' : txt(d.metric, 14), metricLabel: txt(d.metricLabel || d.rotuloMetrica, 40), period: txt(d.period || d.periodo, 40),
      source: txt(d.source || d.fonte, 80), confidence: txt(d.confidence || d.confianca, 20), badge: txt(d.badge, 24),
      action: acao ? txt(acao, 28) : '', attrs: d.attrs && typeof d.attrs === 'object' ? d.attrs : {},
      tags: (d.tags || []).slice(0, 4).map(function (t) { return txt(t, 24); }).filter(Boolean),
      image: urlHttps(d.image || d.imagem), series: serie.length >= 2 ? serie : [], bars: barras.length >= 2 ? barras : [], steps: steps,
      duration: txt(d.duration || d.duracao, 8), format: txt(d.format || d.formato, 24), audience: txt(d.audience || d.publico, 40), theme: txt(d.theme || d.tema, 40),
      area: txt(d.area, 40), subramo: txt(d.subramo, 40), platform: txt(d.platform || d.plataforma, 24), origem: txt(d.origem, 16),
      hero: !!d.hero, points: (d.points || []).slice(0, 4).map(function (p) { return txt(p, 72); }).filter(Boolean),
      direction: d.direction || (num(d.delta) ? (d.delta >= 0 ? 'up' : 'down') : '')
    };
  }

  // ---------- LAYOUT ENGINE: cada informação ganha a composição que a favorece
  function escolher(n) {
    if (n.tipo === 'aprendizado') return n.steps.length >= 2 ? 'fluxo' : 'abstrato';
    if (n.tipo === 'insight') return 'abstrato';
    if (n.tipo === 'oportunidade') return 'caminho';
    if (n.tipo === 'ideia') return 'miniatura';
    if (n.image) return 'imagem';
    if (n.bars.length) return 'comparacao';
    if (n.series.length) return 'grafico';
    if (n.metric) return 'dados';
    return 'tipografico';
  }

  // ---------- VISUAL ENGINE (SVG leve; elementos decorativos ficam aria-hidden)
  function linha(serie, W, H) {
    var min = Math.min.apply(null, serie), max = Math.max.apply(null, serie), r = max - min || 1, w = W || 220, h = H || 70, p = 6;
    var pts = serie.map(function (v, i) { return [p + i * (w - 2 * p) / (serie.length - 1), p + (1 - (v - min) / r) * (h - 2 * p)]; });
    var d = pts.map(function (q, i) { return (i ? 'L' : 'M') + q[0].toFixed(1) + ' ' + q[1].toFixed(1); }).join(' '), u = pts[pts.length - 1];
    return '<svg class="ci-svg ci-linha" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="Gráfico de linha com ' + serie.length + ' pontos">' +
      '<path class="ci-area" d="' + d + ' L' + u[0].toFixed(1) + ' ' + h + ' L' + p + ' ' + h + ' Z"/><path class="ci-draw" pathLength="1" d="' + d + '"/>' +
      '<circle class="ci-dot" cx="' + u[0].toFixed(1) + '" cy="' + u[1].toFixed(1) + '" r="3.2"/></svg>';
  }
  function barras(itens, W, H) {
    var max = Math.max.apply(null, itens.map(function (b) { return Math.abs(b.value); })) || 1, w = W || 220, h = (H || 94) - 16, gap = 12, bw = (w - gap * (itens.length + 1)) / itens.length;
    return '<svg class="ci-svg ci-barras" viewBox="0 0 ' + w + ' ' + (h + 16) + '" role="img" aria-label="Comparação entre ' + itens.length + ' itens">' + itens.map(function (b, i) {
      var bh = Math.max(3, Math.abs(b.value) / max * h), x = gap + i * (bw + gap);
      return '<rect class="ci-bar" style="--k:' + i + '" x="' + x.toFixed(1) + '" y="' + (h - bh).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + bh.toFixed(1) + '" rx="5"/>' +
        '<text x="' + (x + bw / 2).toFixed(1) + '" y="' + (h + 12) + '" text-anchor="middle" class="ci-bl">' + esc(b.label) + '</text>';
    }).join('') + '</svg>';
  }
  function rede(seed, W, H) {
    var w = W || 220, h = H || 80, N = W ? 10 : 7, h0 = hash(seed), pts = [], i;
    for (i = 0; i < N; i++) { var k = hash(seed + ':' + i); pts.push([14 + (k % (w - 28)), 10 + ((k >>> 11) % (h - 20)), (W ? 3.4 : 2.4) + (k % 3)]); }
    var ln = '';
    for (i = 1; i < pts.length; i++) { var j = (h0 + i) % i; ln += '<line class="ci-ln" style="--k:' + i + '" x1="' + pts[i][0] + '" y1="' + pts[i][1] + '" x2="' + pts[j][0] + '" y2="' + pts[j][1] + '"/>'; }
    return '<svg class="ci-svg ci-rede" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true">' + ln + pts.map(function (q, n) { return '<circle class="ci-no" style="--k:' + n + '" cx="' + q[0] + '" cy="' + q[1] + '" r="' + q[2] + '"/>'; }).join('') + '</svg>';
  }
  function caminho(tall) {
    if (tall) return '<svg class="ci-svg ci-caminho" viewBox="0 0 160 210" aria-hidden="true"><path class="ci-draw" pathLength="1" d="M22 192 C22 130 120 150 100 96 S60 52 128 22"/><circle class="ci-no" style="--k:0" cx="22" cy="192" r="6"/><circle class="ci-no" style="--k:2" cx="100" cy="96" r="6"/><path class="ci-seta" d="M114 20 L130 21 L126 36"/></svg>';
    return '<svg class="ci-svg ci-caminho" viewBox="0 0 220 80" aria-hidden="true"><path class="ci-draw" pathLength="1" d="M10 66 C60 66 70 22 110 34 S170 52 206 16"/>' +
      '<circle class="ci-no" style="--k:0" cx="10" cy="66" r="4"/><circle class="ci-no" style="--k:2" cx="110" cy="34" r="4"/><path class="ci-seta" d="M196 14 L208 15 L204 26"/></svg>';
  }
  function fluxo(steps) {
    var n = steps.length, w = 220, xs = steps.map(function (_, i) { return 24 + i * (w - 48) / (n - 1); });
    return '<svg class="ci-svg ci-fluxo" viewBox="0 0 220 34" aria-hidden="true">' + xs.slice(1).map(function (x, i) { return '<line class="ci-ln" style="--k:' + i + '" x1="' + xs[i] + '" y1="14" x2="' + x + '" y2="14"/>'; }).join('') +
      xs.map(function (x, i) { return '<circle class="ci-no" style="--k:' + i + '" cx="' + x + '" cy="14" r="6"/>'; }).join('') + '</svg>';
  }
  function fluxoV(steps) {
    var n = steps.length, h = 200, ys = steps.map(function (_, i) { return 24 + i * (h - 48) / (n - 1); });
    return '<svg class="ci-svg ci-fluxo" viewBox="0 0 60 ' + h + '" aria-hidden="true">' + ys.slice(1).map(function (y, i) { return '<line class="ci-ln" style="--k:' + i + '" x1="30" y1="' + ys[i] + '" x2="30" y2="' + y + '"/>'; }).join('') + ys.map(function (y, i) { return '<circle class="ci-no" style="--k:' + i + '" cx="30" cy="' + y + '" r="9"/>'; }).join('') + '</svg>';
  }
  function miniatura(n) {
    return '<div class="ci-reel" aria-hidden="true"><span class="ci-play"></span>' + (n.duration ? '<span class="ci-dur">' + esc(n.duration) + '</span>' : '') + '<i></i><i></i></div>';
  }
  function contagem(m) {
    var x = String(m).match(/^([+\-−]?)(\d+(?:[.,]\d+)?)(.*)$/); if (!x) return '';
    var dec = (x[2].split(/[.,]/)[1] || '').length;
    return ' data-count="' + esc(x[2].replace(',', '.')) + '" data-dec="' + dec + '" data-pre="' + esc(x[1]) + '" data-suf="' + esc(x[3]) + '"';
  }
  function seta(dir) { return dir ? '<svg class="ci-seta-m ci-' + dir + '" viewBox="0 0 16 16" aria-hidden="true"><path d="' + (dir === 'down' ? 'M3 5l5 6 5-6' : 'M3 11l5-6 5 6') + '"/></svg>' : ''; }
  function dataAttrs(a) { return Object.keys(a).filter(function (k) { return /^[a-z][a-z0-9-]{0,24}$/.test(k); }).map(function (k) { return ' data-' + k + '="' + esc(a[k]) + '"'; }).join(''); }


  // ---------- FORMAS (geometria Memphis do pacote de vetores, redesenhada na paleta Evolui; cores via --fa/--fb/--fc/--fd)
  var FORMAS = {
    elipses: '<ellipse class="fa" cx="50" cy="50" rx="48" ry="31"/><ellipse class="fc" cx="50" cy="50" rx="34" ry="21"/><ellipse class="fa" cx="50" cy="50" rx="20" ry="12"/>',
    asterisco: '<g class="fs fb"><path d="M50 8v84M8 50h84M20 20l60 60M80 20L20 80"/></g>',
    brilho: '<path class="fc" d="M50 4C54 34 66 46 96 50 66 54 54 66 50 96 46 66 34 54 4 50 34 46 46 34 50 4Z"/>',
    quarto: '<path class="fa" d="M0 0H100A100 100 0 0 1 0 100Z"/>',
    xadrez: '<rect class="fa" width="50" height="50"/><rect class="fb" x="50" width="50" height="50"/><rect class="fc" y="50" width="50" height="50"/><rect class="fa" x="50" y="50" width="50" height="50"/>',
    losangos: '<path class="fb" d="M25 2 48 25 25 48 2 25Z"/><path class="fa" d="M75 2 98 25 75 48 52 25Z"/><path class="fc" d="M25 52 48 75 25 98 2 75Z"/><path class="fb" d="M75 52 98 75 75 98 52 75Z"/>',
    laco: '<path class="fs fb" d="M6 74C30 8 86 8 72 50 62 82 22 70 40 38 54 14 96 40 94 84"/>',
    quadrados: '<rect class="fa" width="48" height="48"/><rect class="fd" x="52" width="48" height="48" rx="24"/><rect class="fb" y="52" width="48" height="48" rx="24"/><rect class="fc" x="52" y="52" width="48" height="48"/>',
    meia: '<path class="fd" d="M0 100A50 50 0 0 1 100 100Z"/><path class="fc" d="M22 100A28 28 0 0 1 78 100Z"/>'
  };
  var ORDEM = ['elipses', 'asterisco', 'brilho', 'quarto', 'xadrez', 'losangos', 'laco', 'quadrados', 'meia'];
  function forma(nome, cls, k) {
    return '<span class="ci-forma ' + cls + '" style="--k:' + k + '" aria-hidden="true"><svg viewBox="0 0 100 100" focusable="false">' + FORMAS[nome] + '</svg></span>';
  }
  function trio(sem) {
    var h = hash(sem), a = h % ORDEM.length, b = (a + 2 + (h >>> 5) % 3) % ORDEM.length, c = (b + 3 + (h >>> 9) % 2) % ORDEM.length;
    if (c === a) c = (c + 1) % ORDEM.length;
    return [ORDEM[a], ORDEM[b], ORDEM[c]];
  }
  var DECO = { tendencia: 'elipses', movimento: 'quarto', sinal: 'quarto', insight: 'brilho', oportunidade: 'asterisco', ideia: 'quadrados', aprendizado: 'brilho', resultado: 'xadrez', desempenho: 'xadrez', mercado: 'losangos', alerta: 'meia' };

  // ---------- HTML do card (estático e acessível; o movimento é só realce)
  function html(dado, ordem) {
    var n = normalizar(dado); if (!n) return '';
    var lay = escolher(n), dir = n.direction || (n.metric && /^\+/.test(n.metric) ? 'up' : (n.metric && /^[-−]/.test(n.metric) ? 'down' : ''));
    if (n.hero) return heroHtml(n, lay, dir, ordem);
    var vis = '';
    if (lay === 'grafico') vis = linha(n.series); else if (lay === 'comparacao') vis = barras(n.bars); else if (lay === 'abstrato') vis = rede(n.title);
    else if (lay === 'caminho') vis = caminho(); else if (lay === 'fluxo') vis = fluxo(n.steps); else if (lay === 'miniatura') vis = miniatura(n);
    else if (lay === 'imagem') vis = '<div class="ci-img"><img src="' + esc(n.image) + '" alt="" loading="lazy" referrerpolicy="no-referrer"></div>';
    var cabeca = '<div class="ci-top"><span class="ci-badge">' + esc(n.badge || n.rot) + '</span>' + (n.confidence ? '<span class="ci-conf">Confiança ' + esc(n.confidence) + '</span>' : '') + '</div>';
    var metrica = n.metric ? '<div class="ci-metric"><b' + contagem(n.metric) + '>' + esc(n.metric) + '</b>' + seta(dir) + (n.metricLabel ? '<small>' + esc(n.metricLabel) + '</small>' : '') + '</div>' : '';
    var passos = n.steps.length ? '<ol class="ci-steps">' + n.steps.map(function (s, i) { return '<li style="--k:' + i + '"><small>' + esc(s.label) + '</small><span>' + esc(s.value) + '</span></li>'; }).join('') + '</ol>' : '';
    var tags = n.tags.length ? '<ul class="ci-tags">' + n.tags.map(function (t, i) { return '<li style="--k:' + i + '">' + esc(t) + '</li>'; }).join('') + '</ul>' : '';
    var meta = [n.format, n.audience, n.theme].filter(Boolean).concat([n.source, n.period].filter(Boolean));
    var rodape = meta.length ? '<p class="ci-meta">' + meta.map(esc).join(' · ') + '</p>' : '';
    var cta = n.action ? '<button class="ci-cta" type="button"' + dataAttrs(n.attrs) + '>' + esc(n.action) + '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h9M8 4l4 4-4 4"/></svg></button>' : '';
    return '<article class="ci ci--' + n.tipo + ' ci--' + n.cor + ' ci--' + lay + '" data-ci data-layout="' + lay + '" style="--i:' + (ordem || 0) + '">' +
      '<span class="ci-deco" aria-hidden="true"><svg viewBox="0 0 100 100" focusable="false">' + FORMAS[DECO[n.tipo] || 'elipses'] + '</svg></span>' + cabeca + '<h3 class="ci-t">' + esc(n.title) + '</h3>' + metrica +
      (n.desc ? '<p class="ci-d">' + esc(n.desc) + '</p>' : '') + (vis ? '<div class="ci-vis">' + vis + '</div>' : '') + passos + tags + rodape + cta + '</article>';
  }

  // ---------- HERO: composição editorial (texto + palco com painel, cartões flutuantes e formas)
  function palco(n, lay) {
    if (n.image) return '<div class="ci-ph"><img src="' + esc(n.image) + '" alt="" loading="lazy" referrerpolicy="no-referrer"></div>';
    if (n.bars.length) return barras(n.bars, 200, 230);
    if (n.series.length) return linha(n.series, 170, 200);
    if (lay === 'caminho') return caminho(true);
    if (lay === 'miniatura') return miniatura(n);
    if (lay === 'fluxo') return fluxoV(n.steps);
    return rede(n.title, 150, 200);
  }
  function heroHtml(n, lay, dir, ordem) {
    var c1 = '<span class="ci-chip ci-c1"><span class="ci-chip-in">' + esc(n.badge || n.rot) + '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 3v10M3 8h10"/></svg></span></span>';
    var c2 = '';
    if (n.metric) c2 = '<span class="ci-chip ci-c2"><span class="ci-chip-in"><small>' + esc(n.metricLabel || n.rot) + '</small><b' + contagem(n.metric) + '>' + esc(n.metric) + '</b></span></span>';
    else if (n.tags[0]) c2 = '<span class="ci-chip ci-c2"><span class="ci-chip-in"><small>' + esc(n.rot) + '</small><strong>' + esc(n.tags[0]) + '</strong></span></span>';
    var v3 = n.confidence ? ['Confiança', n.confidence] : (n.period ? [n.source || 'Período', n.period] : (n.source ? ['Fonte', n.source] : null));
    var c3 = v3 ? '<span class="ci-chip ci-c3"><span class="ci-chip-in"><span class="ci-ppl" aria-hidden="true"><i></i><i></i><i></i></span><span class="ci-c3t"><b>' + esc(v3[1]) + '</b><small>' + esc(v3[0]) + '</small></span></span></span>' : '';
    var cta = n.action ? '<button class="ci-cta ci-h-cta" type="button"' + dataAttrs(n.attrs) + '>' + esc(n.action) + '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h9M8 4l4 4-4 4"/></svg></button>' : '';
    var lista = n.points.length ? '<ul class="ci-h-list">' + n.points.map(function (p, i) { return '<li style="--k:' + i + '"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="8.5"/><path d="M6.2 10.4l2.6 2.6 5-5.4"/></svg><span>' + esc(p) + '</span></li>'; }).join('') + '</ul>' : '';
    var meta = [n.format, n.audience, n.theme, n.source, n.period].filter(Boolean);
    return '<article class="ci ci-hero ci--' + n.tipo + ' ci--' + n.cor + ' ci--' + lay + '" data-ci data-layout="hero:' + lay + '" data-q="' + esc([n.title, n.theme, n.tags.join(' ')].join(' ')) + '"' +
      [['area', n.area], ['subramo', n.subramo], ['tema', n.theme], ['tags', n.tags.join('|')], ['tipo', n.tipo], ['formato', n.format], ['plataforma', n.platform], ['origem', n.origem]].map(function (p) { return p[1] ? ' data-' + p[0] + '="' + esc(p[1]) + '"' : ''; }).join('') + ' style="--i:' + (ordem || 0) + '">' +
      '<div class="ci-h-txt"><h3 class="ci-h-t">' + esc(n.title) + '</h3>' + (n.desc ? '<p class="ci-h-d">' + esc(n.desc) + '</p>' : '') + (n.metric && !c2 ? '' : '') + lista + cta +
      (meta.length ? '<p class="ci-meta">' + meta.map(esc).join(' · ') + '</p>' : '') + '</div>' +
      '<div class="ci-stage"><span class="ci-frame" aria-hidden="true"></span><div class="ci-panel">' + palco(n, lay) + '</div>' + c1 + c2 + c3 +
      (function (t) { return forma(t[0], 'ci-f1', 0) + forma(t[1], 'ci-f2', 1) + forma(t[2], 'ci-f3', 2); })(trio(n.title + n.tipo)) + '</div></article>';
  }
  function grade(lista, extra) {
    var h = (lista || []).map(function (d, i) { return html(d, i); }).filter(Boolean).join('');
    return h ? '<div class="ci-grid' + (extra ? ' ' + extra : '') + '">' + h + '</div>' : '';
  }


  // ---------- IMAGENS DOS CARDS: o acervo é administrado no painel Felipe Branding; o app só registra uma fonte (Banco.fonte)
  // que, dada a consulta montada dos data-* do card hero, devolve {src, alt} ou null. Sem fonte/sem retorno: o card segue com gráfico/formas.
  // Só https (URL pública do Storage). A foto é decorativa (alt vazio) e nunca substitui dado.
  var Banco = (function () {
    var fonteFn = null, cache = new Map(), MAX_CHAMADAS = 6;
    function srcOk(u) { u = String(u || ''); return /^https:\/\/[^\s"'<>]+$/.test(u); }
    function fonte(fn) { fonteFn = typeof fn === 'function' ? fn : null; }
    function consulta(c) {
      var g = function (k) { return c.getAttribute('data-' + k) || ''; };
      return { area: g('area'), subramo: g('subramo'), tema: g('tema'), tags: g('tags') ? g('tags').split('|').filter(Boolean) : [], tipo_card: g('tipo'), formato: g('formato'), plataforma: g('plataforma'), origem: g('origem'), q: g('q') };
    }
    function chave(q, evitar) { return JSON.stringify([q.area, q.subramo, q.tema, q.tags, q.tipo_card, q.formato, q.plataforma, q.origem, q.q, evitar.slice().sort()]); }
    function aplicar(raiz) {
      if (!fonteFn || !raiz || !raiz.querySelectorAll || typeof document === 'undefined') return;
      var alvos = Array.prototype.filter.call(raiz.querySelectorAll('.ci-hero:not([data-foto])'), function (c) { return !c.querySelector('.ci-ph') && !c.hasAttribute('data-foto-tentada'); });
      if (!alvos.length) return;
      var fn = fonteFn, usados = [], chamadas = 0;
      function por(c) {
        c.setAttribute('data-foto-tentada', '1');
        var p = c.querySelector('.ci-panel'); if (!p) return Promise.resolve();
        var q = consulta(c), k = chave(q, usados), pronto;
        if (cache.has(k)) pronto = Promise.resolve(cache.get(k));
        else if (chamadas >= MAX_CHAMADAS) { c.removeAttribute('data-foto-tentada'); return Promise.resolve(); }
        else {
          chamadas++;
          pronto = Promise.resolve().then(function () { q.evitar = usados.slice(); return fn(q); }).then(function (r) {
            r = r && srcOk(r.src) ? { src: r.src, alt: '', id: String(r.id || r.src) } : null; cache.set(k, r); return r;
          });
        }
        return pronto.then(function (r) {
          if (!r) return;
          usados.push(r.id);
          var ph = document.createElement('div'), im = document.createElement('img');
          ph.className = 'ci-ph'; im.alt = ''; im.loading = 'lazy'; im.referrerPolicy = 'no-referrer'; im.src = r.src;
          im.onerror = function () { c.removeAttribute('data-foto'); c.classList.remove('ci-foto'); ph.remove(); };
          ph.appendChild(im); p.appendChild(ph); c.setAttribute('data-foto', 'acervo'); c.classList.add('ci-foto');
        }, function () { /* falha de rede: silêncio, o card segue sem foto */ });
      }
      alvos.reduce(function (pr, c) { return pr.then(function () { return por(c); }); }, Promise.resolve());
    }
    return { fonte: fonte, aplicar: aplicar };
  })();

  // ---------- MOTION ENGINE
  function reduzido() { try { return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; } }
  function fmt(v, dec) { return v.toFixed(dec).replace('.', dec ? ',' : '.'); }
  function contar(el, imediato) {
    var to = parseFloat(el.dataset.count), dec = +el.dataset.dec || 0, pre = el.dataset.pre || '', suf = el.dataset.suf || '';
    var final = pre + fmt(to, dec) + suf;
    if (imediato || isNaN(to)) { el.textContent = final; return; }
    var t0 = null, dur = MOTION.number;
    function passo(t) {
      if (t0 == null) t0 = t; var k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      el.textContent = k < 1 ? pre + fmt(to * e, dec) + suf : final;
      if (k < 1) window.requestAnimationFrame(passo);
    }
    window.requestAnimationFrame(passo);
  }
  function entrar(card, imediato) {
    if (card.classList.contains('ci-in')) return;
    card.classList.add('ci-in');
    Array.prototype.forEach.call(card.querySelectorAll('[data-count]'), function (el) { contar(el, imediato); });
  }
  var io = null;
  function sair(card, depois) {
    // OUT: animação de saída com a curva de saída; opcionalmente remove o card ao terminar
    if (!card) return;
    if (reduzido()) { if (depois) depois(card); return; }
    card.classList.remove('ci-in'); card.classList.add('ci-out');
    var feito = false;
    function fim() { if (feito) return; feito = true; if (depois) depois(card); }
    card.addEventListener('animationend', function (e) { if (e.target === card) fim(); });
    window.setTimeout(fim, MOTION.normal + 80);
  }
  function reentrar(card) {
    card.classList.remove('ci-out', 'ci-in'); void card.offsetWidth; card.classList.add('ci-in');
  }
  function ativar(raiz) {
    if (!raiz || !raiz.querySelectorAll) return;
    var cards = Array.prototype.filter.call(raiz.querySelectorAll('.ci'), function (c) { return !c.dataset.ciOn; });
    if (cards.length) {
      var red = reduzido();
      if (red || typeof IntersectionObserver === 'undefined') { cards.forEach(function (c) { c.dataset.ciOn = '1'; entrar(c, true); }); }
      else {
        // IN ao entrar na tela; OUT só quando o card sai pelo topo (nunca esconde conteúdo no fim da página)
        if (!io) io = new IntersectionObserver(function (es) {
          es.forEach(function (e) {
            var c = e.target;
            if (e.isIntersecting) { if (c.classList.contains('ci-out')) reentrar(c); else entrar(c, false); }
            else if (c.classList.contains('ci-in') && e.rootBounds && e.boundingClientRect.bottom < e.rootBounds.top) { sair(c); }
          });
        }, { rootMargin: '-5% 0px 0px 0px', threshold: 0 });
        cards.forEach(function (c) { c.dataset.ciOn = '1'; io.observe(c); });
      }
    }
    Banco.aplicar(raiz);
  }
  function montar(container, lista, extra) { if (!container) return; container.innerHTML = grade(lista, extra); ativar(container); }

  return { MOTION: MOTION, EASE: EASE, TIPOS: TIPOS, normalizar: normalizar, escolher: escolher, html: html, grade: grade, ativar: ativar, montar: montar, sair: sair, Banco: Banco, FORMAS: FORMAS, esc: esc };
});
