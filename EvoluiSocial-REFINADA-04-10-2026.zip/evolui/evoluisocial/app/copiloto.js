// EvoluiSocial — COPILOTO CONTEXTUAL (Fase 4). ES5, funções puras, sem rede, sem IA externa.
// O copiloto não conversa: olha o ESTÁGIO do conteúdo e oferece UMA próxima ação útil por vez, com o motivo em português.
// Tudo é regra determinística e explicável. Nada do texto do usuário sai do navegador. O ponto de extensão para IA futura
// (IA.ativo) vem DESLIGADO: nenhum código deste arquivo faz chamada de rede.
// Memória: nível 1 (sessão, resumoSessao, nunca grava) e nível 2 (inferirPreferencias, só com evidência ou confirmação).
(function (raiz) {
  'use strict';
  var VERSAO = 'cop-v1';
  var IA = { ativo: false };
  var LIM = { minOcorrencias: 3, minConteudos: 2, minHipotese: 2, janelaDias: 90 };
  var ESTAGIOS = ['ideia', 'referencias', 'escrita', 'revisao', 'gravacao', 'experimento', 'publicado'];
  var ESTAGIO_ROTULO = { ideia: 'Ideia', referencias: 'Referências', escrita: 'Escrita', revisao: 'Revisão', gravacao: 'Pronto para gravar ou publicar', experimento: 'Experimento', publicado: 'Resultado' };
  var TIPOS_EVENTO = ['copiloto_sugeriu', 'copiloto_aceitou', 'copiloto_dispensou', 'pref_confirmada', 'pref_removida', 'pref_reativada'];
  var TIPOS_LEITURA = ['copiou_legenda', 'lab_criou', 'lab_concluiu', 'ref_selecionada', 'ref_descartada', 'doc_aberto', 'doc_sug_aceita', 'doc_sug_ignorada', 'doc_cmd_aceito', 'doc_cmd_descartado', 'copiloto_sugeriu', 'copiloto_aceitou', 'copiloto_dispensou'];

  // ------------------------------------------------------------ utilidades
  function semAcento(s) { return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function Doc() { // reaproveita o módulo da Fase 3 (navegador ou node). Se não existir, o copiloto degrada para "indefinido".
    if (raiz && raiz.EvoluiDoc) return raiz.EvoluiDoc;
    try { if (typeof require === 'function') return require('./doc-inteligente.js'); } catch (e) { /* sem módulo */ }
    return null;
  }
  function formatoCanon(f) {
    var s = semAcento(f);
    if (/reel/.test(s)) return 'reel'; if (/stor/.test(s)) return 'stories'; if (/carrossel|carousel/.test(s)) return 'carrossel';
    if (/bio/.test(s)) return 'bio'; if (/legenda/.test(s)) return 'legenda'; if (/roteiro|video|tiktok|shorts/.test(s)) return 'roteiro';
    return '';
  }
  function tomCanon(t) {
    var s = semAcento(t);
    if (/formal|profission|serio|institucional|corporativ/.test(s) && !/informal/.test(s)) return 'formal';
    if (/descontra|divertid|informal|leve|jovem|bem humorad/.test(s)) return 'informal';
    return '';
  }
  function ehVideo(f) { return f === 'reel' || f === 'stories' || f === 'roteiro'; }
  function npal(t) { return (String(t == null ? '' : t).match(/\S+/g) || []).length; }
  function num(v) { v = +v; return isFinite(v) && v > 0 ? Math.floor(v) : 0; }
  function copia(o) { var r = {}, k; for (k in o) if (Object.prototype.hasOwnProperty.call(o, k)) r[k] = o[k]; return r; }
  function inclui(l, x) { return (l || []).indexOf(x) >= 0; }

  // ------------------------------------------------------------ análise reaproveitada da Fase 3
  // analise = { disponivel, palavras, regras:{regra:n}, tipos:{tipo:n}, persona:[sugestões de tom] }
  function analisar(texto, dctx) {
    var a = { disponivel: false, palavras: npal(texto), regras: {}, tipos: {}, persona: [] }, D = Doc();
    if (!D || a.palavras < 5) return a;
    try {
      var lista = D.analisarDoc(texto, dctx, { max: 200 });
      a.disponivel = true;
      lista.forEach(function (s) {
        a.regras[s.regra] = (a.regras[s.regra] || 0) + 1; a.tipos[s.tipo] = (a.tipos[s.tipo] || 0) + 1;
        if (s.tipo === 'persona') a.persona.push({ trecho: s.trecho.texto, mensagem: s.mensagem, motivo: s.motivo });
      });
    } catch (e) { a.disponivel = false; }
    return a;
  }

  // ------------------------------------------------------------ contexto compartilhado (ContextoLab no navegador)
  // Entrada: {perfil, persona|tom, objetivo, formato, duracao|duracaoSeg, tema, doc:(texto|{texto,original,versoes}),
  //   referencias:[{estado}]|{selecionadas,total}, teste:{id,status,vencedora,resultados,rascunho:{a,b}}, sessao, preferencias}
  function montarContextoLab(e) {
    e = e || {};
    var perfil = e.perfil || {}, doc = typeof e.doc === 'string' ? { texto: e.doc } : (e.doc || {});
    var texto = String(doc.texto == null ? '' : doc.texto);
    var formato = formatoCanon(e.formato || doc.formato), tom = tomCanon(e.tom || e.persona || perfil.tom || perfil.persona);
    var dur = num(e.duracaoSeg != null ? e.duracaoSeg : e.duracao);
    var tema = String(e.tema || '').trim().slice(0, 80);
    var dctx = { formato: formato, duracaoSeg: dur, tom: tom, objetivo: e.objetivo || perfil.objetivo || '', ramo: perfil.ramo || '', tema: tema };
    var refs = e.referencias, rs = { total: 0, selecionadas: 0, descartadas: 0, vistas: 0 };
    if (Array.isArray(refs)) refs.forEach(function (r) {
      var s = typeof r === 'string' ? r : (r && r.estado); rs.total++;
      if (s === 'selecionada') rs.selecionadas++; else if (s === 'descartada') rs.descartadas++; else rs.vistas++;
    });
    else if (refs && typeof refs === 'object') { rs.total = num(refs.total); rs.selecionadas = num(refs.selecionadas); rs.descartadas = num(refs.descartadas); rs.vistas = num(refs.vistas); if (rs.total < rs.selecionadas) rs.total = rs.selecionadas; }
    var t = e.teste || null, teste = null;
    if (t) {
      var ras = t.rascunho || null;
      teste = { id: t.id || null, existe: !!t.id || !!t.status, status: t.status || (t.id ? 'testando' : ''), vencedora: t.vencedora || null,
        temResultados: !!(t.resultados && (num(t.resultados.a) || num(t.resultados.b))) || !!t.temResultados,
        rascunho: ras ? { a: String(ras.a || ''), b: String(ras.b || '') } : null };
      if (!teste.existe && !teste.rascunho) teste = null;
    }
    var ses = e.sessao || {};
    var original = doc.original == null ? '' : String(doc.original);
    var ctx = {
      versao: VERSAO, ia: IA.ativo,
      perfil: { ramo: perfil.ramo || '', objetivo: perfil.objetivo || '', tipo_usuario: perfil.tipo_usuario || '', personalizar: perfil.personalizar !== false },
      tom: tom, objetivo: dctx.objetivo, formato: formato, duracaoSeg: dur, tema: tema,
      doc: { texto: texto, palavras: npal(texto), versoes: num(doc.versoes), temOriginal: !!original.trim(), alteradoDoOriginal: !!original.trim() && original !== texto, analise: analisar(texto, dctx) },
      referencias: rs, teste: teste,
      sessao: { tela: ses.tela || 'doc', conteudo: ses.conteudo || '', dispensadas: (ses.dispensadas || []).slice(), aceitas: (ses.aceitas || []).slice(), sugeridas: copia(ses.sugeridas || {}), comandos: num(ses.comandos), sugestoesAceitas: num(ses.sugestoesAceitas), publicado: !!ses.publicado },
      preferencias: perfil.personalizar === false ? [] : (e.preferencias || []).filter(function (p) { return p && p.uso !== false; }).map(function (p) { return typeof p === 'string' ? p : p.id; }),
      dctx: dctx
    };
    if (teste && teste.rascunho && teste.rascunho.b.trim()) ctx.analiseB = analisar(teste.rascunho.b, dctx);
    return ctx;
  }

  // ------------------------------------------------------------ checklist de prontidão
  // estado: ok | falta | atencao | na (não se aplica) | indefinido (texto curto demais para decidir)
  function itemGancho(ctx, a) {
    if (ctx.formato === 'bio') return { estado: 'na', explicacao: 'Bio não precisa de gancho: ela já é lida inteira.' };
    if (a.palavras < 8) return { estado: 'indefinido', explicacao: 'O texto ainda é curto (menos de 8 palavras) para eu avaliar a abertura.' };
    if (a.regras.abertura_fraca) return { estado: 'falta', explicacao: 'A abertura é uma saudação. Os primeiros segundos decidem se a pessoa continua.' };
    if (a.regras.sem_gancho) return { estado: 'falta', explicacao: 'A primeira frase não tem pergunta, número nem o problema do seu público.' };
    if (a.regras.gancho_longo) return { estado: 'atencao', explicacao: 'Há gancho, mas a primeira frase é longa (mais de 18 palavras).' };
    return { estado: 'ok', explicacao: 'A primeira frase tem pergunta, número ou problema do público.' };
  }
  function itemEstrutura(ctx, a) {
    if (a.regras.limite_bio || a.regras.limite_legenda) return { estado: 'falta', explicacao: a.regras.limite_bio ? 'A bio passou de 150 caracteres.' : 'A legenda passou de 2.200 caracteres.' };
    if (ctx.formato === 'bio') return { estado: a.palavras < 3 ? 'indefinido' : 'ok', explicacao: a.palavras < 3 ? 'Escreva a bio para eu checar o tamanho.' : 'Dentro do limite de 150 caracteres.' };
    if (a.palavras < 15) return { estado: 'indefinido', explicacao: 'Com menos de 15 palavras não dá para avaliar começo, meio e fim.' };
    if (a.regras.sem_fecho) return { estado: 'falta', explicacao: 'O texto termina sem fechar a ideia (falta uma frase final).' };
    return { estado: 'ok', explicacao: 'O texto tem fecho.' };
  }
  function itemCta(ctx, a) {
    if (ctx.formato === 'bio') return { estado: 'na', explicacao: 'Na bio, a chamada para ação é conferida pela nota do teste, não aqui.' };
    if (a.palavras < 15) return { estado: 'indefinido', explicacao: 'Com menos de 15 palavras ainda não dá para saber se falta o pedido de ação.' };
    if (a.regras.sem_cta) return { estado: 'falta', explicacao: 'Não encontrei um pedido de ação (comentar, salvar, chamar no WhatsApp).' };
    return { estado: 'ok', explicacao: 'Há um pedido de ação.' };
  }
  function itemDuracao(ctx, a) {
    if (ctx.formato === 'bio' || ctx.formato === 'legenda' || ctx.formato === 'carrossel') return { estado: 'na', explicacao: 'Duração só importa para vídeo (Reel, Stories, roteiro).' };
    if (!ctx.duracaoSeg) return { estado: ehVideo(ctx.formato) ? 'falta' : 'indefinido', explicacao: ehVideo(ctx.formato) ? 'Defina a duração alvo (15 s, 30 s...) para eu conferir o tamanho do roteiro.' : 'Sem formato e sem duração alvo, não consigo conferir o tamanho.' };
    if (a.regras.duracao_longa) return { estado: 'atencao', explicacao: 'O texto leva mais tempo para falar do que o alvo de ' + ctx.duracaoSeg + ' s.' };
    if (a.regras.duracao_curta) return { estado: 'atencao', explicacao: 'O texto é bem mais curto que o alvo de ' + ctx.duracaoSeg + ' s.' };
    return { estado: a.palavras < 5 ? 'indefinido' : 'ok', explicacao: a.palavras < 5 ? 'Escreva o texto para eu conferir a duração.' : 'O tamanho cabe no alvo de ' + ctx.duracaoSeg + ' s (estimativa de ~2,6 palavras por segundo).' };
  }
  function itemReferencia(ctx) {
    if (ctx.referencias.selecionadas > 0) return { estado: 'ok', explicacao: ctx.referencias.selecionadas + ' referência(s) selecionada(s).' };
    return { estado: 'falta', explicacao: 'Nenhuma referência selecionada. Não é obrigatória, mas um exemplo bom ajuda a decidir o ângulo.' };
  }
  function checklistDeProntidao(ctx) {
    var a = ctx.doc.analise, defs = [['gancho', 'Gancho', itemGancho(ctx, a), true], ['estrutura', 'Estrutura', itemEstrutura(ctx, a), true], ['cta', 'Chamada para ação', itemCta(ctx, a), true], ['duracao', 'Duração', itemDuracao(ctx, a), false], ['referencia', 'Referência escolhida', itemReferencia(ctx), false]];
    if (!a.disponivel && a.palavras >= 5) defs.forEach(function (d) { if (d[0] !== 'referencia' && d[0] !== 'duracao') d[2] = { estado: 'indefinido', explicacao: 'A análise do texto não está disponível agora.' }; });
    var itens = defs.map(function (d) { return { id: d[0], rotulo: d[1], estado: d[2].estado, ok: d[2].estado === 'ok' ? true : (d[2].estado === 'na' || d[2].estado === 'indefinido' ? null : false), explicacao: d[2].explicacao, obrigatorio: d[3] }; });
    var aplic = itens.filter(function (i) { return i.estado !== 'na'; }), oks = aplic.filter(function (i) { return i.estado === 'ok'; }).length;
    var pend = itens.filter(function (i) { return i.estado === 'falta' || i.estado === 'atencao'; }).map(function (i) { return i.id; });
    var obrigPend = itens.filter(function (i) { return i.obrigatorio && i.estado !== 'ok' && i.estado !== 'na'; });
    return { itens: itens, resumo: oks + ' de ' + aplic.length + ' itens em ordem', pendentes: pend, pronto: ctx.doc.palavras >= 5 && obrigPend.length === 0 && a.disponivel,
      explicacao: 'Checklist de boas práticas feito por regras. É um guia, não uma previsão de desempenho. Itens "não se aplica" ou "indefinido" não entram na conta.' };
  }

  // ------------------------------------------------------------ persona / tom (reaproveita as regras de tom da Fase 3)
  function adequacaoPersona(texto, tom) {
    var t = tomCanon(tom), a = analisar(texto, { tom: t });
    if (!t) return { tom: '', adequado: null, ocorrencias: [], explicacao: 'Você ainda não definiu um tom (formal ou descontraído) no perfil, então não avalio.' };
    if (!a.disponivel) return { tom: t, adequado: null, ocorrencias: [], explicacao: 'Texto curto demais (menos de 5 palavras) ou análise indisponível.' };
    if (a.persona.length) return { tom: t, adequado: false, ocorrencias: a.persona, explicacao: 'Encontrei ' + a.persona.length + ' trecho(s) que destoam do tom ' + (t === 'formal' ? 'formal' : 'descontraído') + ' que você escolheu. É uma checagem por lista de expressões, não um julgamento de estilo.' };
    return { tom: t, adequado: true, ocorrencias: [], explicacao: 'Não achei expressões que destoem do tom ' + (t === 'formal' ? 'formal' : 'descontraído') + '. Isso não garante que o texto tenha a sua voz.' };
  }

  // ------------------------------------------------------------ estágio
  function pendRevisao(ctx) {
    var a = ctx.doc.analise;
    return (a.tipos.correcao || 0) > 0 || a.persona.length > 0 || !!a.regras.duracao_longa || !!a.regras.duracao_curta || !!a.regras.generico || !!a.regras.frase_longa;
  }
  function estagio(ctx) {
    var t = ctx.teste, d = ctx.doc;
    if (ctx.sessao.publicado || (t && t.existe && t.status === 'concluido')) return 'publicado';
    if (t && t.existe) return 'experimento';
    if (d.palavras < 5) return ctx.referencias.selecionadas > 0 ? 'escrita' : (ctx.referencias.total > 0 ? 'referencias' : 'ideia');
    var ck = checklistDeProntidao(ctx), estrut = ck.itens.filter(function (i) { return (i.id === 'gancho' || i.id === 'estrutura' || i.id === 'cta') && i.estado === 'falta'; }).length;
    if (estrut > 0 || d.palavras < 15) return 'escrita';
    return pendRevisao(ctx) ? 'revisao' : 'gravacao';
  }

  // ------------------------------------------------------------ próxima ação (UMA por vez)
  // Preferências do nível 2 só refinam: 'evitar:<id>' e 'ignora_tipo:<tipo>' escondem uma ação; 'prefere_curto' liga 'enxugar'.
  var ACAO_TIPO = { criar_gancho: 'gancho', criar_cta: 'cta', ajustar_tom: 'persona', corrigir: 'correcao', fechar_texto: 'estrutura' };
  function evita(ctx, id) { return inclui(ctx.preferencias, 'evitar:' + id) || (ACAO_TIPO[id] && inclui(ctx.preferencias, 'ignora_tipo:' + ACAO_TIPO[id])); }
  function cand(id, titulo, porque, acao, regra) { return { id: id, titulo: titulo, porque: porque, acao: acao, regra: regra }; }

  function candidatosForm(ctx, ck) {
    var r = ctx.teste && ctx.teste.rascunho ? ctx.teste.rascunho : { a: '', b: '' }, a = r.a.trim(), b = r.b.trim(), L = [];
    if (!a) L.push(cand('escrever_a', 'Escreva a versão A', 'O teste compara duas versões. Comece pela que você usa hoje ou pela sua melhor ideia.', { tipo: 'focar', alvo: 'lA' }, 'form_sem_a'));
    else if (!b) L.push(cand('escrever_b', 'Escreva a versão B', 'Para o teste valer, a B deve mudar uma coisa só em relação à A (o gancho, a chamada para ação ou o tamanho).', { tipo: 'focar', alvo: 'lB' }, 'form_sem_b'));
    else if (a === b) L.push(cand('versoes_iguais', 'As duas versões estão iguais', 'Sem diferença não há o que comparar. Mude o gancho, a chamada para ação ou o tamanho da B.', { tipo: 'focar', alvo: 'lB' }, 'form_iguais'));
    if (a && ck.pendentes.length && !evita(ctx, 'abrir_doc')) {
      var nomes = ck.itens.filter(function (i) { return i.estado === 'falta' || i.estado === 'atencao'; }).map(function (i) { return i.rotulo.toLowerCase(); });
      if (nomes.length && (ck.itens[0].estado === 'falta' || ck.itens[1].estado === 'falta' || ck.itens[2].estado === 'falta')) L.push(cand('abrir_doc', 'Ajuste a versão A no Documento', 'Pendências na A: ' + nomes.join(', ') + '. O Documento tem comandos para isso e guarda o original.', { tipo: 'abrir_doc', alvo: 'lA' }, 'form_pendencias'));
    }
    if (a && ctx.referencias.selecionadas === 0 && ctx.referencias.total === 0) L.push(cand('ver_referencias', 'Veja referências antes de decidir a versão B', 'Um exemplo de outro criador ajuda a escolher o que mudar. É uma boa prática, não uma regra.', { tipo: 'abrir_referencias' }, 'form_sem_refs'));
    if (a && b && a !== b) L.push(cand('salvar_teste', 'Salvar e começar o teste', 'As duas versões estão preenchidas e são diferentes. Publique uma por semana, nos mesmos dias e horários, e anote os números.', { tipo: 'salvar_teste' }, 'form_pronto'));
    return L;
  }
  function candidatos(ctx) {
    var ck = checklistDeProntidao(ctx), st = estagio(ctx), d = ctx.doc, t = ctx.teste, L = [], idx = {}, i;
    for (i = 0; i < ck.itens.length; i++) idx[ck.itens[i].id] = ck.itens[i];
    if (ctx.sessao.tela === 'lab_form') return candidatosForm(ctx, ck);
    if (st === 'publicado') L.push(cand('proxima_ideia', 'Escolher a próxima ideia', 'O teste terminou' + (t && t.vencedora ? ' (venceu a versão ' + String(t.vencedora).toUpperCase() + ')' : '') + '. Use o que aprendeu na próxima peça.', { tipo: 'abrir_aba', aba: 'buscar' }, 'publicado'));
    if (st === 'experimento' && t) {
      if (!t.temResultados) L.push(cand('registrar_resultados', 'Registrar os números do teste', 'O teste só diz algo quando você anota alcance, curtidas, comentários e mensagens das duas versões.', { tipo: 'abrir_teste', id: t.id }, 'exp_sem_resultados'));
      else if (!t.vencedora) L.push(cand('completar_resultados', 'Completar os números das duas versões', 'Há números, mas faltam dados de uma das versões (o alcance é obrigatório) para apontar a vencedora.', { tipo: 'abrir_teste', id: t.id }, 'exp_sem_vencedora'));
    }
    if (!t || !t.existe) {
      if (d.palavras < 5) {
        if (!ctx.tema && ctx.referencias.selecionadas === 0) L.push(cand('definir_tema', 'Diga o assunto do conteúdo', 'Com o assunto definido, as consultas de referência e os modelos de gancho saem mais certeiros.', { tipo: 'focar', alvo: 'dTit' }, 'sem_tema'));
        if (ctx.referencias.selecionadas === 0 && ctx.referencias.total === 0) L.push(cand('ver_referencias', 'Ver referências antes de escrever', 'Ainda não há texto nem referência. Ver 2 ou 3 exemplos do seu assunto ajuda a escolher um ângulo. É uma boa prática, não uma obrigação.', { tipo: 'abrir_referencias' }, 'vazio_sem_refs'));
        if (ctx.referencias.selecionadas === 0 && ctx.referencias.total > 0) L.push(cand('escolher_referencia', 'Escolher uma referência', 'Você já viu ' + ctx.referencias.total + ' referência(s), mas nenhuma está selecionada. Selecionar a melhor registra o que te inspirou.', { tipo: 'abrir_referencias' }, 'refs_sem_selecao'));
        L.push(cand('comecar_escrita', 'Comece pelo gancho, mesmo que rascunho', 'O Documento guarda o original e permite desfazer. Escrever primeiro e melhorar depois costuma ser mais rápido.', { tipo: 'focar', alvo: 'dTxt' }, 'vazio'));
      } else {
        if (!ctx.formato && d.palavras >= 8) {
          var fp = '';
          for (i = 0; i < ctx.preferencias.length; i++) if (ctx.preferencias[i].indexOf('formato:') === 0) { fp = ctx.preferencias[i].slice(8); break; }
          L.push(cand('definir_formato', 'Escolha o formato', 'Sem formato eu não sei quais regras aplicar (bio e legenda têm limites; vídeo tem duração).' + (fp ? ' Você costuma criar ' + fp + '.' : ''), { tipo: 'focar', alvo: 'dFmt' }, 'sem_formato'));
        }
        if (idx.gancho.estado === 'falta') L.push(cand('criar_gancho', 'Criar um gancho', idx.gancho.explicacao + ' Abro três modelos com o seu assunto para você escolher; nada muda sem o seu aceite.', { tipo: 'comando', comando: 'gancho' }, 'gancho_falta'));
        if (idx.cta.estado === 'falta') L.push(cand('criar_cta', 'Criar uma chamada para ação', idx.cta.explicacao + ' Abro modelos conforme o seu objetivo; você decide.', { tipo: 'comando', comando: 'cta' }, 'cta_falta'));
        if (idx.estrutura.estado === 'falta') L.push(cand('fechar_texto', 'Fechar o texto', idx.estrutura.explicacao, { tipo: 'ver_sugestao', tipoSug: 'estrutura' }, 'estrutura_falta'));
        if (d.palavras < 15 && ctx.formato !== 'bio') L.push(cand('completar_texto', 'Desenvolva um pouco mais o texto', 'Com menos de 15 palavras não consigo avaliar estrutura nem chamada para ação.', { tipo: 'focar', alvo: 'dTxt' }, 'texto_curto'));
        if ((d.analise.tipos.correcao || 0) > 0) L.push(cand('corrigir', 'Aplicar as correções seguras', 'Há ' + d.analise.tipos.correcao + ' correção(ões) sem ambiguidade (espaço, pontuação, maiúscula, erros comuns). Mostro o antes e depois antes de aplicar.', { tipo: 'comando', comando: 'corrigir' }, 'correcoes'));
        if (d.analise.regras.duracao_longa) L.push(cand('ajustar_duracao', 'Enxugar para caber em ' + ctx.duracaoSeg + ' s', idx.duracao.explicacao, { tipo: 'comando', comando: ctx.duracaoSeg <= 20 ? 't15' : 't30' }, 'duracao_longa'));
        else if (d.analise.regras.duracao_curta) L.push(cand('ajustar_duracao', 'Revisar a duração alvo', idx.duracao.explicacao, { tipo: 'ver_sugestao', tipoSug: 'estrutura' }, 'duracao_curta'));
        if (d.analise.persona.length) L.push(cand('ajustar_tom', 'Ajustar o tom', 'Há ' + d.analise.persona.length + ' trecho(s) que destoam do tom que você escolheu.', { tipo: 'ver_sugestao', tipoSug: 'persona' }, 'tom'));
        if (inclui(ctx.preferencias, 'prefere_curto') && d.palavras > 80 && !ctx.duracaoSeg && ctx.formato !== 'bio') L.push(cand('enxugar', 'Encurtar o texto', 'Você costuma aceitar versões mais curtas e este texto tem ' + d.palavras + ' palavras.', { tipo: 'comando', comando: 'encurtar' }, 'pref_curto'));
        if (ehVideo(ctx.formato) && idx.duracao.estado === 'falta' && d.palavras >= 15) L.push(cand('definir_duracao', 'Defina a duração alvo', idx.duracao.explicacao, { tipo: 'focar', alvo: 'dDur' }, 'sem_duracao'));
        L.push(cand('comparar_ab', d.alteradoDoOriginal ? 'Comparar as versões no teste A/B' : 'Testar esta versão contra uma variação', d.alteradoDoOriginal ? 'O texto está em ordem e é diferente do original. Testar original (A) contra editado (B) mostra com números qual funciona melhor para o seu público.' : 'O texto está em ordem. Escreva uma variação (mudando só o gancho ou a chamada para ação) e compare com números reais.', { tipo: 'abrir_ab' }, 'pronto_sem_teste'));
      }
    }
    return L;
  }
  function escolher(ctx) {
    var L = candidatos(ctx), i;
    for (i = 0; i < L.length; i++) {
      if (inclui(ctx.sessao.dispensadas, L[i].id)) continue;
      if (evita(ctx, L[i].id)) continue;
      return L[i];
    }
    return null;
  }
  function proximaAcao(ctx) {
    var a = escolher(ctx);
    if (!a) return null;
    a.estagio = estagio(ctx); a.estagioRotulo = ESTAGIO_ROTULO[a.estagio]; a.preferencia = '';
    if (ctx.preferencias.length) { // só avisa quando a preferência realmente mudou a escolha
      var sem = copia(ctx); sem.preferencias = [];
      var base = escolher(sem);
      if (!base || base.id !== a.id) a.preferencia = 'Esta escolha levou em conta uma preferência sua (veja em Perfil, “O que a Evolui aprendeu”).';
    }
    return a;
  }

  // ------------------------------------------------------------ sessão (nível 1: só em memória, nunca grava)
  function novaSessao(tela, conteudo) { return { tela: tela || 'doc', conteudo: conteudo || '', dispensadas: [], aceitas: [], sugeridas: {}, comandos: 0, sugestoesAceitas: 0 }; }
  function dispensar(sessao, id) { var s = copia(sessao || novaSessao()); s.dispensadas = (s.dispensadas || []).slice(); if (!inclui(s.dispensadas, id)) s.dispensadas.push(id); return s; }
  function aceitar(sessao, id) { var s = copia(sessao || novaSessao()); s.aceitas = (s.aceitas || []).slice(); if (!inclui(s.aceitas, id)) s.aceitas.push(id); return s; }
  // evita registrar a mesma sugestão várias vezes na sessão (orçamento de eventos): devolve {novo, sessao}
  function marcarSugerida(sessao, id) { var s = copia(sessao || novaSessao()); s.sugeridas = copia(s.sugeridas || {}); var novo = !s.sugeridas[id]; s.sugeridas[id] = 1; return { novo: novo, sessao: s }; }
  function resumoSessao(ctx) {
    var st = estagio(ctx), ck = checklistDeProntidao(ctx), d = ctx.doc, l = [];
    l.push(d.palavras + ' palavra(s) no texto' + (ctx.formato ? ', formato ' + ctx.formato : ''));
    if (ctx.duracaoSeg) l.push('duração alvo ' + ctx.duracaoSeg + ' s');
    l.push(ctx.referencias.selecionadas + ' referência(s) selecionada(s) de ' + ctx.referencias.total);
    if (d.alteradoDoOriginal) l.push('texto diferente do original (o original continua guardado)');
    if (ctx.sessao.comandos) l.push(ctx.sessao.comandos + ' comando(s) aplicado(s)');
    if (ctx.sessao.sugestoesAceitas) l.push(ctx.sessao.sugestoesAceitas + ' sugestão(ões) aceita(s)');
    if (ctx.sessao.dispensadas.length) l.push(ctx.sessao.dispensadas.length + ' sugestão(ões) do copiloto dispensada(s)');
    l.push(ck.resumo);
    return { estagio: st, rotulo: ESTAGIO_ROTULO[st], linhas: l, texto: 'Estágio: ' + ESTAGIO_ROTULO[st] + '. ' + l.join('; ') + '.', gravado: false, aviso: 'Este resumo vive só nesta sessão. Nada é gravado por ele.' };
  }

  // ------------------------------------------------------------ preferências de longo prazo (nível 2)
  var CURTO = { t15: 1, t30: 1, encurtar: 1, direto: 1 };
  var CMD_ROT = { gancho: 'Costuma pedir modelos de gancho', cta: 'Costuma pedir modelos de chamada para ação', corrigir: 'Costuma aplicar as correções automáticas', roteiro: 'Costuma dividir o texto em cenas', melhorar: 'Costuma usar o "melhorar" simples', natural: 'Costuma usar o "mais natural"' };
  var TIPO_SUG_ROT = { correcao: 'correções', clareza: 'avisos de clareza', gancho: 'avisos de gancho', estrutura: 'avisos de estrutura', cta: 'avisos de chamada para ação', persona: 'avisos de tom' };
  var ACAO_ROT = { ver_referencias: 'ver referências', escolher_referencia: 'escolher referência', criar_gancho: 'criar gancho', criar_cta: 'criar chamada para ação', ajustar_tom: 'ajustar o tom', corrigir: 'aplicar correções', comparar_ab: 'comparar no teste A/B', definir_formato: 'definir o formato', definir_duracao: 'definir a duração', enxugar: 'encurtar', ajustar_duracao: 'ajustar a duração', fechar_texto: 'fechar o texto', comecar_escrita: 'começar a escrever', definir_tema: 'definir o assunto', completar_texto: 'desenvolver o texto', abrir_doc: 'ajustar no Documento', proxima_ideia: 'escolher a próxima ideia', registrar_resultados: 'registrar resultados', completar_resultados: 'completar resultados' };
  // devolve [{chave, modo}] ('raw' conta cada ocorrência; 'unico' conta conteúdos distintos, para sinais de "abriu")
  function sinaisDe(ev) {
    var d = ev.dados || {}, t = ev.tipo, o = [];
    if (t === 'doc_cmd_aceito' && d.comando) { if (CURTO[d.comando]) o.push({ chave: 'prefere_curto', modo: 'raw' }); if (CMD_ROT[d.comando]) o.push({ chave: 'cmd:' + d.comando, modo: 'raw' }); }
    else if (t === 'doc_aberto' && d.formato) o.push({ chave: 'formato:' + d.formato, modo: 'unico' });
    else if (t === 'doc_sug_ignorada' && d.tipo) o.push({ chave: 'ignora_tipo:' + d.tipo, modo: 'raw' });
    else if (t === 'copiloto_dispensou' && d.acao) o.push({ chave: 'evitar:' + d.acao, modo: 'raw' });
    else if (t === 'lab_criou' && d.tipo) o.push({ chave: 'testa:' + d.tipo, modo: 'unico' });
    else if (t === 'ref_selecionada' && d.fonte) o.push({ chave: 'fonte_ref:' + d.fonte, modo: 'raw' });
    else if (t === 'ref_descartada' && d.fonte) o.push({ chave: 'descarta_fonte:' + d.fonte, modo: 'raw' });
    else if (t === 'copiou_legenda' && d.formato) o.push({ chave: 'copia:' + d.formato, modo: 'unico' });
    else if (t === 'aba' && d.aba === 'laboratorio') o.push({ chave: 'usa_lab', modo: 'unico' });
    return o;
  }
  function descrever(chave, n, m) {
    var ev = n + ' vez' + (n === 1 ? '' : 'es') + ' em ' + m + ' conteúdo' + (m === 1 ? '' : 's') + ' diferente' + (m === 1 ? '' : 's'), p = chave.indexOf(':'), k = p < 0 ? chave : chave.slice(0, p), v = p < 0 ? '' : chave.slice(p + 1);
    var INFO = 'Informativa: por enquanto não muda nenhuma sugestão.';
    if (chave === 'prefere_curto') return { rotulo: 'Prefere textos e vídeos curtos', porque: 'Você aceitou comandos de encurtar ou reduzir para 15/30 s ' + ev + '.', efeito: 'Se o texto passar de 80 palavras sem duração alvo, o copiloto sugere encurtar.', uso: true };
    if (chave === 'usa_lab') return { rotulo: 'Usa o Laboratório com frequência', porque: 'Você abriu o Laboratório em ' + n + ' dias diferentes.', efeito: INFO, uso: false };
    if (k === 'cmd') return { rotulo: CMD_ROT[v] || 'Usa o comando ' + v, porque: 'Você aceitou o comando "' + v + '" ' + ev + '.', efeito: INFO, uso: false };
    if (k === 'formato') return { rotulo: 'Cria mais ' + v, porque: 'Você abriu documentos de formato "' + v + '" em ' + m + ' conteúdos diferentes.', efeito: 'Quando você não escolhe o formato, o copiloto lembra qual costuma usar.', uso: true };
    if (k === 'ignora_tipo') return { rotulo: 'Costuma ignorar ' + (TIPO_SUG_ROT[v] || 'avisos do tipo ' + v), porque: 'Você ignorou ' + (TIPO_SUG_ROT[v] || 'avisos desse tipo') + ' ' + ev + '.', efeito: 'O copiloto deixa de escolher esse tipo de aviso como próxima ação. O painel de sugestões do Documento continua mostrando tudo.', uso: true };
    if (k === 'evitar') return { rotulo: 'Costuma dispensar "' + (ACAO_ROT[v] || v) + '"', porque: 'Você dispensou a sugestão "' + (ACAO_ROT[v] || v) + '" do copiloto ' + ev + '.', efeito: 'O copiloto não oferece mais essa ação como próxima ação.', uso: true };
    if (k === 'testa') return { rotulo: 'Testa mais ' + (v === 'bio' ? 'bios' : 'legendas'), porque: 'Você criou testes de ' + (v === 'bio' ? 'bio' : 'legenda') + ' ' + ev + '.', efeito: INFO, uso: false };
    if (k === 'fonte_ref') return { rotulo: 'Prefere referências de ' + v, porque: 'Você selecionou referências de ' + v + ' ' + ev + '.', efeito: INFO, uso: false };
    if (k === 'descarta_fonte') return { rotulo: 'Costuma descartar referências de ' + v, porque: 'Você descartou referências de ' + v + ' ' + ev + '.', efeito: INFO, uso: false };
    if (k === 'copia') return { rotulo: 'Copia mais ' + v, porque: 'Você copiou textos de formato "' + v + '" em ' + m + ' ocasiões diferentes.', efeito: INFO, uso: false };
    return { rotulo: chave, porque: 'Observado ' + ev + '.', efeito: INFO, uso: false };
  }
  // inferirPreferencias(eventos, opts) -> { ativas, hipoteses, removidas, personalizar }
  //  - ativa: >= 3 ocorrências em >= 2 conteúdos distintos (eventos de "abertura" contam conteúdos, não aberturas) OU confirmada pelo usuário.
  //  - hipótese: >= 2 ocorrências, mas sem a evidência exigida. Aparece para o usuário confirmar; NÃO influencia nada.
  //  - uma correção isolada nunca vira preferência. 'removidas' (o usuário disse "não é isso") nunca voltam sozinhas.
  //  - eventos sem 'conteudo' no payload usam o dia como proxy de conteúdo (mais fraco; declarado em 'porque').
  function inferirPreferencias(eventos, opts) {
    opts = opts || {};
    var out = { ativas: [], hipoteses: [], removidas: [], personalizar: opts.personalizar !== false };
    var conf = opts.confirmadas || [], rem = opts.removidas || [];
    if (!out.personalizar) return out;
    var minO = num(opts.minOcorrencias) || LIM.minOcorrencias, minC = num(opts.minConteudos) || LIM.minConteudos, minH = LIM.minHipotese;
    var agora = opts.agora != null ? +opts.agora : Date.now(), corte = agora - (num(opts.janelaDias) || LIM.janelaDias) * 864e5;
    var G = {}, i, j;
    (eventos || []).forEach(function (ev) {
      if (!ev || !ev.tipo) return;
      var ts = ev.criado_em ? Date.parse(ev.criado_em) : agora;
      if (isFinite(ts) && ts < corte) return;
      var s = sinaisDe(ev), cont = (ev.dados && ev.dados.conteudo) || ('dia:' + String(ev.criado_em || '').slice(0, 10));
      for (j = 0; j < s.length; j++) {
        var g = G[s[j].chave] || (G[s[j].chave] = { raw: 0, conts: {}, ult: 0, modo: s[j].modo, proxy: true });
        g.raw++; g.conts[cont] = 1; if (isFinite(ts) && ts > g.ult) g.ult = ts;
        if (ev.dados && ev.dados.conteudo) g.proxy = false;
      }
    });
    var chaves = Object.keys(G);
    function montar(chave, origem, g) {
      var m = g ? Object.keys(g.conts).length : 0, n = g ? (g.modo === 'unico' ? m : g.raw) : 0, d = descrever(chave, n, m);
      return { id: chave, rotulo: d.rotulo, porque: d.porque + (g && g.proxy ? ' (sem identificar o conteúdo, contei por dia)' : ''), efeito: d.efeito, uso: d.uso && origem !== 'hipotese', origem: origem, ocorrencias: n, conteudos: m, ultima: g && g.ult ? new Date(g.ult).toISOString() : null };
    }
    for (i = 0; i < chaves.length; i++) {
      var c = chaves[i], g = G[c], m = Object.keys(g.conts).length, n = g.modo === 'unico' ? m : g.raw;
      if (inclui(rem, c)) { out.removidas.push(montar(c, 'removida', g)); continue; }
      if (inclui(conf, c)) { out.ativas.push(montar(c, 'confirmada', g)); continue; }
      if (n >= minO && m >= minC) out.ativas.push(montar(c, 'inferida', g));
      else if (n >= minH) out.hipoteses.push(montar(c, 'hipotese', g));
    }
    conf.forEach(function (c) { // confirmada sem evidência recente continua valendo, até o usuário remover
      if (!G[c] && !inclui(rem, c)) out.ativas.push(montar(c, 'confirmada', null));
    });
    rem.forEach(function (c) { if (!G[c]) out.removidas.push(montar(c, 'removida', null)); });
    function ord(a, b) { return b.ocorrencias - a.ocorrencias || (a.id < b.id ? -1 : 1); }
    out.ativas.sort(ord); out.hipoteses.sort(ord);
    return out;
  }

  // ------------------------------------------------------------ eventos (só categorias, nunca o texto)
  function montarSinal(tipo, d) {
    if (TIPOS_EVENTO.indexOf(tipo) < 0) return null;
    d = d || {}; var o = {};
    if (d.acao) o.acao = String(d.acao).slice(0, 40);
    if (d.estagio && ESTAGIOS.indexOf(d.estagio) >= 0) o.estagio = d.estagio;
    if (d.tela) o.tela = String(d.tela).slice(0, 20);
    if (d.conteudo) o.conteudo = String(d.conteudo).slice(0, 40);
    if (d.regra) o.regra = String(d.regra).slice(0, 40);
    if (d.pref) o.pref = String(d.pref).slice(0, 60);
    return { tipo: tipo, dados: o };
  }

  var API = { VERSAO: VERSAO, IA: IA, LIM: LIM, ESTAGIOS: ESTAGIOS, ESTAGIO_ROTULO: ESTAGIO_ROTULO, TIPOS_EVENTO: TIPOS_EVENTO, TIPOS_LEITURA: TIPOS_LEITURA,
    montarContextoLab: montarContextoLab, estagio: estagio, proximaAcao: proximaAcao, candidatos: candidatos, checklistDeProntidao: checklistDeProntidao, adequacaoPersona: adequacaoPersona,
    resumoSessao: resumoSessao, novaSessao: novaSessao, dispensar: dispensar, aceitar: aceitar, marcarSugerida: marcarSugerida,
    inferirPreferencias: inferirPreferencias, descrever: descrever, montarSinal: montarSinal };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else raiz.EvoluiCopiloto = API;
})(typeof window !== 'undefined' ? window : this);
