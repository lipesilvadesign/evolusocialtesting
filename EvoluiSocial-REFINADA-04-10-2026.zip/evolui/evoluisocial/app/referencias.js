// EvoluiSocial — REFERENCES ENGINE (versão do navegador, ES5, funções puras, sem rede).
// Mesma lógica de supabase/functions/evolui-api/eie/referencias.ts (mantenha as duas em sincronia; os testes usam os mesmos casos).
// Sem IA externa: consultas e ranking são algoritmo interno. O campo de IA existe, mas vem DESLIGADO e nada é enviado a terceiros.
(function (raiz) {
  'use strict';
  var VERSAO = 'ref-v3-pinterest';
  var IA = { ativo: false }; // espelha eie/config llm.ativo=false. Ligar exige decisão do dono + provedor aprovado.

  var STOP = ('a o as os um uma uns umas de do da dos das em no na nos nas por para pra com sem sob sobre ate entre e ou mas que se como quando onde ' +
    'qual quais quem ja mais menos muito muita muitos muitas pouco tao tambem so apenas ainda isso isto esse essa esses essas este esta estes estas aquele aquela ' +
    'meu minha meus minhas seu sua seus suas nosso nossa ele ela eles elas eu voce voces nos ser estar ter foi sao era vai vou fazer faz fiz tem ha ao aos aquilo ' +
    'ex eg etc video videos post posts conteudo coisa coisas jeito forma parte algo alguem todo toda todos todas cada outro outra').split(' ');
  var STOPSET = {}; STOP.forEach(function (w) { STOPSET[w] = 1; });

  function semAcento(s) { return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim(); }
  // [{n: 'mudanca', o: 'mudança'}], sem stopwords, sem repetição, só palavras com 3+ letras (ou números)
  function termos(s) {
    var orig = String(s == null ? '' : s).toLowerCase().split(/[^0-9a-zà-ÿ]+/), vistos = {}, out = [];
    for (var i = 0; i < orig.length; i++) {
      var o = orig[i]; if (!o) continue;
      var n = semAcento(o);
      if (STOPSET[n] || (n.length < 3 && !/^\d+$/.test(n)) || vistos[n]) continue;
      vistos[n] = 1; out.push({ n: n, o: o });
    }
    return out;
  }
  var FORMATOS = { reel: 'reels', reels: 'reels', stories: 'stories', story: 'stories', carrossel: 'carrossel', carousel: 'carrossel' };
  function formatoCanon(f) { return FORMATOS[semAcento(f)] || null; }
  var FMT_ROTULO = { reels: 'Reels', stories: 'Stories', carrossel: 'Carrossel' };
  // palavras de busca por ramo (termos enviados à busca) e nome do ramo para exibir. Sempre com acento.
  var RAMO_ROTULO = { doces: 'confeitaria', alimentacao: 'restaurante', beleza: 'beleza estética', moda: 'moda', saude: 'saúde', fitness: 'academia fitness', pet: 'pet', casa: 'decoração', educacao: 'educação', servicos: 'serviços profissionais', criador: 'marca pessoal' };
  var RAMO_NOME = { doces: 'confeitaria', alimentacao: 'restaurante', beleza: 'beleza e estética', moda: 'moda', saude: 'saúde e bem-estar', fitness: 'academia e fitness', pet: 'pet', casa: 'decoração', educacao: 'educação e cursos', servicos: 'serviços profissionais', criador: 'marca pessoal' };
  var OBJ_ROTULO = { vender: 'vender', crescer: 'crescer seguidores', engajar: 'engajamento', lancar: 'lançamento' };
  var OBJ_FRASE = { vender: 'Para vender', crescer: 'Para ganhar seguidores', engajar: 'Para gerar engajamento', lancar: 'Para um lançamento' };
  var MAX_TERMOS = 8;
  // Palavras que atraem resultado pirata/spam: saem do termo de busca e do texto exibido, mesmo se a pessoa digitar.
  var SPAM = {}; ('download downloads baixar baixe baixando gratis gratuito gratuita torrent torrents completo completa completos completas dublado dublada dublados legendado legendada ' +
    'hack hacks hacker hackeado hackeada crack crackeado crackeada cracked pirata pirateado pirateada apk mod mega mediafire filme filmes assistir full hd 4k 1080p 720p').split(' ').forEach(function (w) { SPAM[w] = 1; });
  function limparFrase(s) { // tira palavras de spam e pontuação solta; mantém acentos e a escrita da pessoa
    var t = String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
    if (t.length > 3 && t === t.toUpperCase() && t !== t.toLowerCase()) t = t.toLowerCase(); // GRITO vira frase normal
    t = t.split(' ').filter(function (w) { return !SPAM[semAcento(w.replace(/[^0-9a-zA-Zà-ÿÀ-ß]/g, ''))]; }).map(function (w) { return w.length >= 6 && w === w.toUpperCase() && w !== w.toLowerCase() ? w.toLowerCase() : w; }).join(' '); // GRITO em palavra longa vira minúscula (siglas curtas como CLT, INSS ficam)
    t = t.replace(/^[\s.,;:!?\-–—]+|[\s.,;:!?\-–—]+$/g, '').slice(0, 80).trim();
    return t;
  }
  function termosBusca(s) { return termos(limparFrase(s)); }
  function maius1(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
  function minus1(s) { var p = s.split(' ')[0]; return s && !/[A-ZÀ-Þ].*[A-ZÀ-Þ]/.test(p) ? s.charAt(0).toLowerCase() + s.slice(1) : s; } // mantém siglas (CLT, MEI)
  function ligar(a, b) { return a && b ? a + ' e ' + b : a || b; }
  function duracaoSeg(d) { var n = parseInt(String(d == null ? '' : d).replace(/\D/g, ''), 10); return n > 0 && n <= 3600 ? n : null; }
  // une listas de termos sem repetir, respeitando o máximo. Devolve também o texto de busca; lista marcada com q vira expressão entre aspas.
  function juntar(listas) {
    var vistos = {}, ts = [], partes = [];
    listas.forEach(function (l) {
      var pedaco = []; (l || []).forEach(function (t) { if (!vistos[t.n] && ts.length < MAX_TERMOS) { vistos[t.n] = 1; ts.push(t); pedaco.push(t.o); } });
      if (pedaco.length) partes.push(l.q && pedaco.length >= 2 && pedaco.length === l.length ? '"' + pedaco.join(' ') + '"' : pedaco.join(' '));
    });
    ts.busca = partes.join(' ');
    return ts;
  }
  function chave(ts) { return ts.map(function (t) { return t.n; }).sort().join(' '); }
  function topRoteiro(txt, excluir) {
    var cont = {}, ordem = [];
    limparFrase(String(txt || '').slice(0, 5000).replace(/\s+/g, ' ')).toLowerCase().split(/[^0-9a-zà-ÿ]+/).forEach(function (o) {
      var n = semAcento(o); if (o.length < 5 || STOPSET[n] || excluir[n]) return;
      if (!cont[n]) { cont[n] = { n: n, o: o, c: 0 }; ordem.push(n); } cont[n].c++;
    });
    return ordem.map(function (n, i) { return { t: cont[n], i: i }; }).sort(function (a, b) { return b.t.c - a.t.c || a.i - b.i; }).slice(0, 3).map(function (x) { return { n: x.t.n, o: x.t.o }; });
  }

  // ctx: { perfil:{ramo,ramo_detalhe,cidade,objetivo,tipo_usuario,interesses,personalizar}, persona, tema, formato, duracao, objetivo, roteiro, preferencias }
  // retorna até 5 consultas: [{ texto, rotulo, porque, peso, termos, enfase }].
  //   rotulo = texto exibido (frase natural, com acento); texto = termo enviado à busca (enxuto, com acento, sem spam, sem formato colado);
  //   enfase = 'shorts' quando o formato é Reels curto: o front só a acrescenta na busca do YouTube. Nunca inventa fato: só reorganiza o que a pessoa informou.
  function construirConsultas(ctx, opc) {
    ctx = ctx || {}; opc = opc || {};
    var p = ctx.perfil || {}, pers = p.personalizar !== false;
    var temaF = limparFrase(ctx.tema), tema = termos(temaF), fmt = formatoCanon(ctx.formato);
    var seg = duracaoSeg(ctx.duracao), enfase = fmt === 'reels' && (!seg || seg <= 60) ? 'shorts' : null;
    var F = fmt ? FMT_ROTULO[fmt] : '', Fd = F && seg && fmt !== 'carrossel' ? F + ' de ' + seg + (seg === 1 ? ' segundo' : ' segundos') : F;
    var T = minus1(temaF), C = [];
    function add(ts, peso, porque, rotulo, env) { if (ts.length >= 2 || (ts.length === 1 && fmt)) C.push({ ts: ts, peso: peso, porque: porque, rotulo: rotulo, enfase: env === undefined ? enfase : env }); }
    function sobre(corpo) { return Fd ? Fd + ' sobre ' + corpo : 'Ideias sobre ' + corpo; }

    if (!pers) { // sem personalização: só tema e formato
      add(juntar([tema]), 100, 'Usa só o assunto e o formato que você informou, porque a personalização está desligada.', sobre(T));
      add(juntar([tema]), 60, 'Procura exemplos do mesmo assunto, sem filtrar pelo formato.', 'Exemplos de ' + T, null);
    } else {
      var detF = limparFrase(p.ramo_detalhe), det = termos(detF), ramo = det.length ? det : termos(RAMO_ROTULO[p.ramo] || '');
      if (det.length) ramo.q = true;
      var R = det.length ? minus1(detF) : (RAMO_NOME[p.ramo] || '');
      var cidF = limparFrase(p.cidade), cid = termos(cidF), objK = semAcento(ctx.objetivo || p.objetivo), obj = termos(OBJ_ROTULO[objK] || ''), pes = termosBusca(ctx.persona);
      var inter = [], interF = []; (p.interesses || []).slice(0, 3).forEach(function (i) { var f = limparFrase(i); if (f) { interF.push(minus1(f)); inter = inter.concat(termos(f).slice(0, 2)); } });
      var pref = termosBusca(ctx.preferencias).slice(0, 2);
      var corpo = ligar(R, T), dur = seg && Fd !== F ? ', de olho nos seus ' + seg + ' segundos' : '';
      add(juntar([ramo, tema]), 100, 'Junta o que você faz com o assunto do vídeo: é a busca mais parecida com o seu conteúdo' + dur + '.', Fd ? Fd + ': ' + corpo : maius1(corpo));
      add(juntar([tema]), 85, 'Tira o seu ramo da busca para ver como outras áreas tratam o assunto.', sobre(T));
      if (obj.length) add(juntar([obj, ramo, tema.slice(0, 2)]), 70, 'Procura vídeos que cumprem o mesmo objetivo que o seu.', (OBJ_FRASE[objK] || 'Para o seu objetivo') + ': ' + ligar(R, T));
      var ex = {}; juntar([ramo, tema]).forEach(function (t) { ex[t.n] = 1; });
      var top = topRoteiro(ctx.roteiro, ex);
      if (top.length) add(juntar([top, ramo.slice(0, 2)]), 65, 'Usa as palavras que mais aparecem no seu roteiro: ' + top.map(function (t) { return t.o; }).join(', ') + '.', 'Ideias com as palavras do seu roteiro: ' + top.map(function (t) { return t.o; }).join(', '));
      if (pes.length || pref.length) add(juntar([ramo.slice(0, 2), tema.slice(0, 2), pes.slice(0, 2), pref]), 55, 'Leva em conta o tom e as preferências que você indicou.', maius1(ligar(R, T)) + ' (tom: ' + pes.concat(pref).map(function (t) { return t.o; }).join(', ') + ')');
      if (cid.length && ramo.length) add(juntar([ramo, cid, tema.slice(0, 2)]), 50, 'Inclui a sua cidade para achar exemplos mais perto de você.', maius1(R) + ' em ' + cidF + (T ? ': ' + T : ''));
      if (inter.length) add(juntar([inter, tema.slice(0, 2)]), 40, 'Mistura os seus interesses com o assunto do vídeo.', 'Ideias de ' + interF.join(', ') + (T ? ' sobre ' + T : ''));
    }
    var vistos = {}, out = [];
    C.sort(function (a, b) { return b.peso - a.peso; }).forEach(function (c) {
      var k = chave(c.ts) + '|' + (c.enfase || ''); if (vistos[k]) return; vistos[k] = 1;
      if (out.length >= 5) return;
      out.push({ texto: c.ts.busca, rotulo: c.rotulo, porque: c.porque, peso: c.peso, termos: c.ts.map(function (t) { return t.n; }), enfase: c.enfase });
    });
    return refinarComIA(out, opc.ia);
  }
  // Gancho de IA: desligado. Mesmo que alguém passe um provedor, só age se IA.ativo === true (decisão do dono, não do código).
  function refinarComIA(consultas, provedorIA) { if (!IA.ativo || !provedorIA || typeof provedorIA.refinar !== 'function') return consultas; return consultas; }

  // ---------------- provedores plugáveis
  // Provedor: { id, ativo():bool, licenca:{...}, buscar(consulta, limites) -> Promise<Item[]> }
  // Item: { fonte, url, id_externo, titulo, autor, miniatura_url }
  var LIMITES_PADRAO = { maxItens: 10, timeoutMs: 8000, cacheSeg: 900 };
  var registro = {};
  function registrarProvedor(p) { if (!p || !p.id || typeof p.buscar !== 'function' || typeof p.ativo !== 'function') throw new Error('provedor inválido'); registro[p.id] = p; return p; }
  function obterProvedor(id) { return registro[id] || null; }
  function provedoresAtivos() { return Object.keys(registro).map(function (k) { return registro[k]; }).filter(function (p) { var a = false; try { a = !!p.ativo(); } catch (e) {} return a; }); }
  function limparProvedores() { registro = {}; }
  function httpsOuNull(u) { u = String(u == null ? '' : u); return /^https:\/\/[^\s"<>]+$/i.test(u) && u.length <= 600 ? u : null; }
  function normalizarItem(fonte, b) {
    b = b || {}; var url = httpsOuNull(b.url); if (!url) return null;
    var t = function (v, n) { return typeof v === 'string' && v.trim() ? v.trim().slice(0, n) : null; };
    return { fonte: fonte, url: url, id_externo: t(b.id_externo, 80), titulo: t(b.titulo, 200), autor: t(b.autor, 120), miniatura_url: httpsOuNull(b.miniatura_url), crescimento_wow: b.crescimento_wow == null ? null : Number(b.crescimento_wow), crescimento_mom: b.crescimento_mom == null ? null : Number(b.crescimento_mom), crescimento_yoy: b.crescimento_yoy == null ? null : Number(b.crescimento_yoy), afinidade_termos: Array.isArray(b.afinidade_termos) ? b.afinidade_termos.slice(0, 8) : [], porque: t(b.porque, 500) };
  }
  // Cache em memória com validade. Evita repetir a mesma chamada autorizada (e respeita limites das fontes).
  function criarCache(agora) {
    var m = {}; agora = agora || function () { return Date.now(); };
    return {
      obter: function (k) { var e = m[k]; if (!e) return null; if (e.ate < agora()) { delete m[k]; return null; } return e.v; },
      guardar: function (k, v, seg) { m[k] = { v: v, ate: agora() + (seg || LIMITES_PADRAO.cacheSeg) * 1000 }; },
      tamanho: function () { return Object.keys(m).length; }
    };
  }
  // Provedor 'link': reaproveita a ação analisar_link (já existe em evolui-api). A pessoa cola o link; só dados públicos via oEmbed oficial.
  function provedorLink(chamar) {
    return {
      id: 'link', pendente: null,
      licenca: { base: 'oEmbed oficial (YouTube, TikTok) via evolui-api/analisar_link', autorizacao: 'link colado pela própria pessoa', raspagem: false },
      ativo: function () { return typeof chamar === 'function'; },
      buscar: function (consulta) {
        var url = consulta && consulta.url; if (!url) return Promise.resolve([]);
        return Promise.resolve(chamar('analisar_link', { url: String(url).slice(0, 600) })).then(function (r) {
          var l = (r && r.link) || {}, d = (r && r.dados) || {};
          var it = normalizarItem('link', { url: l.normalizada || l.url, id_externo: l.idExterno, titulo: d.titulo, autor: d.autor || l.autor, miniatura_url: d.miniatura });
          if (!it) return [];
          it.aviso = (r && r.aviso) || null; it.plataforma = l.plataforma || null;
          return [it];
        });
      }
    };
  }
  // Provedor 'youtube': chama a ação 'buscar_referencias_youtube' do evolui-api (chave no cofre do servidor, cache de 6 h e teto diário lá).
  // Fica ativo enquanto `ligado`; se o servidor responder { indisponivel: true } (sem chave, cota ou falha), desliga até recarregar a página.
  function provedorYoutube(chamar, ligado) {
    var self = {
      id: 'youtube', pendente: ligado === true ? null : 'desligado: ligue o provedor (a ação buscar_referencias_youtube precisa estar deployada e a chave YouTube no cofre)',
      licenca: { base: 'YouTube Data API v3 (termos de serviço da API), no servidor', autorizacao: 'chave do projeto, nunca no navegador', raspagem: false },
      indisponivel: false,
      ativo: function () { return ligado === true && typeof chamar === 'function' && !self.indisponivel; },
      buscar: function (consulta, limites) {
        if (!self.ativo()) return Promise.reject(new Error('provedor youtube desligado'));
        var lim = Object.assign({}, LIMITES_PADRAO, limites || {});
        return Promise.resolve(chamar('buscar_referencias_youtube', { consulta: String(consulta.texto || '').slice(0, 120), limite: Math.max(1, Math.min(8, lim.maxItens)) })).then(function (r) {
          if (r && r.indisponivel) { self.indisponivel = true; self.pendente = String(r.motivo || 'indisponível').slice(0, 120); return []; }
          return ((r && r.itens) || []).slice(0, lim.maxItens).map(function (b) { return normalizarItem('youtube', b); }).filter(Boolean);
        });
      }
    };
    return self;
  }
  // Provedor Pinterest: usa a API oficial de Trends. Não faz scraping.
  function provedorPinterest(chamar, ligado) {
    var self = {
      id: 'pinterest', pendente: ligado === true ? null : 'PINTEREST_ACCESS_TOKEN não disponível no servidor',
      licenca: { base: 'Pinterest API v5 / Trends API', autorizacao: 'token OAuth no servidor', raspagem: false },
      indisponivel: false,
      ativo: function () { return ligado === true && typeof chamar === 'function' && !self.indisponivel; },
      buscar: function (consulta, limites) {
        if (!self.ativo()) return Promise.reject(new Error('provedor pinterest desligado'));
        var lim = Object.assign({}, LIMITES_PADRAO, limites || {});
        return Promise.resolve(chamar('buscar_referencias_pinterest', { consulta: String(consulta.texto || '').slice(0, 120), termos: Array.isArray(consulta.termos) ? consulta.termos.slice(0, 8) : [], limite: Math.max(1, Math.min(8, lim.maxItens)) })).then(function (r) {
          if (r && r.indisponivel) { self.indisponivel = true; self.pendente = String(r.motivo || 'indisponível').slice(0, 160); return []; }
          return ((r && r.itens) || []).slice(0, lim.maxItens).map(function (b) { return normalizarItem('pinterest', b); }).filter(Boolean);
        });
      }
    };
    return self;
  }
  // Busca por todos os provedores ativos, com cache e limite; falha de um não derruba os outros.
  function buscarReferencias(consulta, opc) {
    opc = opc || {}; var cache = opc.cache, lim = Object.assign({}, LIMITES_PADRAO, opc.limites || {});
    var ps = (opc.provedores || provedoresAtivos());
    return Promise.all(ps.map(function (p) {
      var k = p.id + '|' + (consulta.url || consulta.texto);
      var hit = cache && cache.obter(k); if (hit) return hit;
      return Promise.resolve().then(function () { return p.buscar(consulta, lim); }).then(function (its) { its = (its || []).slice(0, lim.maxItens); if (cache) cache.guardar(k, its, lim.cacheSeg); return its; }, function () { return []; });
    })).then(function (listas) { return [].concat.apply([], listas); });
  }

  // ---------------- ranking interno (simples e explicável)
  // historico: [{ fonte, id_externo, url, autor, estado }]
  function chaveItem(i) { return i.id_externo ? (i.fonte || '') + ':' + i.id_externo : 'url:' + semAcento(i.url); }
  function ranquear(itens, consulta, historico) {
    var q = (consulta && consulta.termos) || termos(consulta && consulta.texto).map(function (t) { return t.n; });
    var est = {}, autSel = {};
    (historico || []).forEach(function (h) { est[chaveItem(h)] = h.estado; if (h.estado === 'selecionada' && h.autor) autSel[semAcento(h.autor)] = 1; });
    var vistos = {}, out = [];
    (itens || []).forEach(function (it) {
      var k = chaveItem(it); if (vistos[k]) return; vistos[k] = 1;
      var e = est[k]; if (e === 'descartada') return; // o que a pessoa descartou não volta
      var alvo = {}; termos((it.titulo || '') + ' ' + (it.autor || '')).forEach(function (t) { alvo[t.n] = 1; });
      var ach = q.filter(function (t) { return alvo[t]; });
      var score = q.length ? Math.round(ach.length / q.length * 70) : 0, porque = [];
      porque.push(ach.length ? 'Combina com a consulta em: ' + ach.join(', ') + '.' : 'Não repete palavras da consulta.');
      if (it.fonte === 'pinterest' && it.crescimento_wow != null) {
        score += Math.max(0, Math.min(30, Math.round(Number(it.crescimento_wow) / 10)));
        porque.push('Crescimento no Pinterest: ' + (Number(it.crescimento_wow) > 0 ? '+' : '') + Number(it.crescimento_wow) + '% WoW.');
      }
      if (it.autor && autSel[semAcento(it.autor)]) { score += 15; porque.push('Mesmo autor de uma referência que você já escolheu.'); }
      if (e === 'selecionada') { score += 10; porque.push('Você já escolheu esta referência.'); }
      else if (e === 'vista') { score -= 15; porque.push('Você já viu esta referência.'); }
      if (it.titulo && it.miniatura_url) score += 5;
      out.push(Object.assign({}, it, { score: Math.max(0, Math.min(100, score)), porque: porque, estado: e || null }));
    });
    return out.map(function (x, i) { return { x: x, i: i }; }).sort(function (a, b) { return b.x.score - a.x.score || a.i - b.i; }).map(function (z) { return z.x; });
  }

  // ---------------- sinais (vista, selecionada, descartada)
  var ESTADOS = ['vista', 'selecionada', 'descartada'];
  // sinal para o motor/eventos: não leva título nem URL, só identificadores e a consulta
  function montarSinal(estado, item, consulta) {
    if (ESTADOS.indexOf(estado) < 0) return null;
    return { tipo: 'ref_' + estado, dados: { fonte: item.fonte || null, id_externo: item.id_externo || null, consulta: String((consulta && (consulta.texto || consulta)) || '').slice(0, 120) } };
  }
  // linha de evolui_lab_referencias (sem user_id: o front acrescenta)
  function montarLinha(item, estado, ctxIds, consulta, nota) {
    ctxIds = ctxIds || {};
    return { client_id: ctxIds.client_id || null, teste_id: ctxIds.teste_id || null, fonte: item.fonte, url: item.url, id_externo: item.id_externo || null, titulo: item.titulo || null, autor: item.autor || null, miniatura_url: item.miniatura_url || null, consulta: consulta ? String(consulta).slice(0, 120) : null, estado: ESTADOS.indexOf(estado) >= 0 ? estado : 'vista', nota: nota ? String(nota).slice(0, 500) : null, metadados: { algoritmo: VERSAO } };
  }

  var API = { VERSAO: VERSAO, IA: IA, semAcento: semAcento, termos: termos, construirConsultas: construirConsultas, registrarProvedor: registrarProvedor, obterProvedor: obterProvedor, provedoresAtivos: provedoresAtivos, limparProvedores: limparProvedores, normalizarItem: normalizarItem, criarCache: criarCache, provedorLink: provedorLink, provedorYoutube: provedorYoutube, provedorPinterest: provedorPinterest, buscarReferencias: buscarReferencias, ranquear: ranquear, chaveItem: chaveItem, montarSinal: montarSinal, montarLinha: montarLinha, ESTADOS: ESTADOS, LIMITES_PADRAO: LIMITES_PADRAO };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else raiz.EvoluiReferencias = API;
})(typeof window !== 'undefined' ? window : this);
