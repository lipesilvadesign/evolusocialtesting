/* EvoluiSocial — cliente compartilhado (site e app).
   Usa o MESMO projeto Supabase da Felipe Branding, mas com sessão própria
   (storageKey "evolui-auth"), separada da sessão do painel da agência. */
(function () {
  var URL_SB = 'https://aligftypgtzlymmditeo.supabase.co';
  var CHAVE = 'sb_publishable_lLKYguXwi6isaw1C4X5uiA_25-MT7ym'; // chave pública (feita para ficar no navegador)
  var sb = null;
  try {
    if (window.supabase && window.supabase.createClient) {
      sb = window.supabase.createClient(URL_SB, CHAVE, {
        auth: { storageKey: 'evolui-auth', persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
      });
    }
  } catch (e) { sb = null; }

  async function sessao() {
    if (!sb) return null;
    try { var r = await sb.auth.getSession(); return (r && r.data && r.data.session) || null; } catch (e) { return null; }
  }

  var FUNCOES = { 'evolui-api': 1, 'evolui-pagamentos': 1, 'evolui-criar': 1 };
  async function api(acao, dados, funcao) {
    funcao = FUNCOES[funcao] ? funcao : 'evolui-api';
    var s = await sessao();
    if (!s) { var e1 = new Error('Entre na sua conta para continuar.'); e1.status = 401; throw e1; }
    var ctl = new AbortController();
    var t = setTimeout(function () { ctl.abort(); }, 30000);
    var r;
    try {
      r = await fetch(URL_SB + '/functions/v1/' + funcao, {
        method: 'POST', signal: ctl.signal,
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + s.access_token, apikey: CHAVE },
        body: JSON.stringify(Object.assign({ acao: acao }, dados || {}))
      });
    } catch (e) {
      var e2 = new Error(e && e.name === 'AbortError' ? 'A busca demorou demais. Tente de novo.' : 'Sem conexão. Confira sua internet e tente de novo.');
      e2.status = 0; throw e2;
    } finally { clearTimeout(t); }
    var j = {};
    try { j = await r.json(); } catch (e) { j = {}; }
    if (!r.ok) { var e3 = new Error(j.erro || 'Algo falhou. Tente de novo.'); e3.status = r.status; e3.dados = j; throw e3; }
    return j;
  }

  function entrarGoogle() {
    if (!sb) return Promise.reject(new Error('Não foi possível carregar o login. Recarregue a página.'));
    return sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: location.origin + '/evoluisocial/app/' } });
  }

  // Tema claro/escuro: chave própria da EvoluiSocial ("evolui_tema"); claro por padrão.
  var LUA = '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>';
  var SOL = '<circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>';
  function temaAtual() { return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }
  function pintaBotoes() {
    var t = temaAtual();
    Array.prototype.forEach.call(document.querySelectorAll('[data-tema]'), function (b) {
      var svg = b.querySelector('svg'); if (svg) svg.innerHTML = t === 'light' ? LUA : SOL;
      b.setAttribute('aria-label', t === 'light' ? 'Usar tema escuro' : 'Usar tema claro');
    });
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = t === 'light' ? '#F5F8FC' : '#08142C';
  }
  function trocarTema() {
    var novo = temaAtual() === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', novo);
    try { localStorage.setItem('evolui_tema', novo); } catch (e) { /* armazenamento bloqueado: vale só nesta visita */ }
    pintaBotoes();
  }
  document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('[data-tema]')) trocarTema(); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', pintaBotoes); else pintaBotoes();

  window.Evolui = { sb: sb, api: api, sessao: sessao, entrarGoogle: entrarGoogle, pintaTema: pintaBotoes };
})();
