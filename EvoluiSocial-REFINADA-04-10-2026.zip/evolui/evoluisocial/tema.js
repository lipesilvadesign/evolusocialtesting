/* Tema da EvoluiSocial: claro por padrão (identidade da marca). Chave própria "evolui_tema"; roda antes de a página desenhar. */
(function () {
  var t = 'light';
  try { var s = localStorage.getItem('evolui_tema'); if (s === 'dark' || s === 'light') t = s; } catch (e) { /* armazenamento bloqueado: segue no claro */ }
  document.documentElement.setAttribute('data-theme', t);
})();
