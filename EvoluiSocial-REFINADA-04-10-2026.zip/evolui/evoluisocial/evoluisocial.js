/* EvoluiSocial — prévia da Home (01/10/2026) */
(function(){
const DATA={
 doces:{trends:[
  {name:"Bolo no pote com recheio aparente",st:"alta",g:38,s:[12,14,15,18,20,24,28,31,36,38],reg:[["Wikipédia",86],["Notícias",64],["Trends",38]],why:"Em alta há 3 semanas em 3 fontes.",src:["Wikipédia: mais acessos à página do assunto","Google Trends: entre as buscas em alta do dia","Notícias: 3 matérias de gastronomia"],idea:"Reels de 15 s",hook:"\"Olha o que acontece quando eu corto esse pote...\"",cap:"Recheio que transborda 🍫\nBolo no pote de brigadeiro com morango, feito hoje.\nEncomendas pelo WhatsApp (link na bio)."},
  {name:"Caixas de doces para o Dia das Crianças",st:"cres",g:64,s:[3,4,5,6,7,9,12,14,18,21],reg:[["Wikipédia",78],["Notícias",71],["Trends",52]],why:"Crescendo há 2 semanas em 2 fontes. Tendência sazonal.",src:["Google Trends: entre as buscas em alta do dia","Wikipédia: mais acessos à página da data"],idea:"Carrossel de 5 imagens",hook:"\"3 caixas prontas para o dia 12\"",cap:"Dia das Crianças chegando 🎈\nMontamos 3 caixas de doces prontas para presentear.\nReserve pelo WhatsApp até dia 9."},
  {name:"Bastidores da produção com som ambiente",st:"come",g:22,s:[2,2,3,3,4,4,5,6,6,8],reg:[["Wikipédia",58],["Notícias",44],["Trends",21]],why:"Começando a crescer em 3 fontes.",src:["Wikipédia: mais acessos à página do assunto","Notícias: matérias em português nos últimos 14 dias"],idea:"Reels de 20 s, sem fala",hook:"Só o som da batedeira nos 2 primeiros segundos",cap:"Do zero ao pronto, sem cortes 🎧\nAssim nasce cada encomenda aqui.\nComente QUERO que eu mando o cardápio."}]},
 beleza:{trends:[
  {name:"Antes e depois de corte bob",st:"alta",g:29,s:[30,32,33,36,38,41,44,47,49,52],reg:[["Wikipédia",88],["Notícias",73],["Trends",61]],why:"Em alta há 5 semanas em 3 fontes.",src:["Wikipédia: mais acessos à página do assunto","Notícias: 4 matérias de beleza"],idea:"Reels de 15 s",hook:"\"Ela chegou com o cabelo na cintura...\"",cap:"Da cintura ao bob em 1 hora ✂️\nObrigada pela confiança!\nAgende pelo link da bio."},
  {name:"Spa dos pés em casa",st:"cres",g:57,s:[2,3,3,4,5,6,6,7,9,10],reg:[["Wikipédia",69],["Notícias",55],["Trends",33]],why:"Crescendo há 2 semanas em 2 fontes.",src:["Wikipédia: mais acessos à página do assunto","Google Trends: entre as buscas em alta do dia"],idea:"Reels de lançamento",hook:"\"Agora eu vou até você\"",cap:"Spa dos pés no conforto da sua casa ✨\nAtendo [seus bairros].\nChame no WhatsApp."},
  {name:"Unhas cromadas em tons de outono",st:"come",g:51,s:[1,1,2,2,3,3,4,5,6,7],reg:[["Wikipédia",47],["Notícias",39],["Trends",22]],why:"Começando a aparecer em 1 fonte. Confiança baixa.",src:["Wikipédia: mais acessos à página do assunto"],idea:"Carrossel antes e depois",hook:"\"A cor que mais pediram esta semana\"",cap:"Cromada cor de outono ✨\nTem horário esta semana.\nAgende pelo link da bio."}]},
 moda:{trends:[
  {name:"Provador: 1 peça, 3 jeitos de usar",st:"alta",g:33,s:[10,12,12,15,17,18,21,22,23,25],reg:[["Wikipédia",84],["Notícias",66],["Trends",61]],why:"Em alta há 4 semanas em 3 fontes.",src:["Wikipédia: mais acessos à página do assunto","Google Trends: entre as buscas em alta do dia","Notícias: matérias em português nos últimos 14 dias"],idea:"Reels de 20 s",hook:"\"1 calça, 3 ocasiões\"",cap:"1 peça, 3 looks 👖\nTrabalho, passeio e noite com a mesma calça.\nPeça pelo direct."},
  {name:"Moda praia para o verão nordestino",st:"cres",g:41,s:[5,6,6,7,8,9,11,13,14,16],reg:[["Wikipédia",91],["Notícias",48],["Trends",36]],why:"Crescendo há 3 semanas em 2 fontes. Tendência sazonal.",src:["Google Trends: entre as buscas em alta do dia","Notícias: matérias regionais de turismo"],idea:"Stories com enquete",hook:"\"Qual desses vai com você para a praia?\"",cap:"Verão chegando ☀️\nNova coleção praia na loja.\nVote nos stories."},
  {name:"Black Friday antecipada",st:"come",g:70,s:[1,1,2,2,3,3,4,5,6,7],reg:[["Wikipédia",62],["Notícias",49],["Trends",45]],why:"Começando a crescer em 2 fontes.",src:["Notícias: varejo antecipando a data","Google Trends: entre as buscas em alta do dia"],idea:"Stories com caixa de pergunta",hook:"\"Quer ser avisada primeiro?\"",cap:"Vem aí 🖤\nQuem entrar na lista recebe as ofertas antes de todo mundo."}]}
};
const MAP=[[/doce|bolo|brigadeiro|confeit|festa|padaria|torta|salgad|comida|aliment/,"doces"],[/sal[aã]o|beleza|cabel|unha|manicure|est[eé]tic|maqui|barbe|cilio/,"beleza"],[/roupa|moda|loja|biqu|praia|bout|cal[cç]a|vestido|acess[oó]r/,"moda"]];
const STL={alta:["Em alta","p-alta"],cres:["Crescendo","p-cres"],come:["Começando","p-come"]};
const STEPS=["Por que importa","Vídeo de referência","Ideia de post","Legenda","Próximo passo"];
const ARR='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
const RM=matchMedia("(prefers-reduced-motion: reduce)").matches;
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const norm=s=>s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"");
let cur="doces",open=-1,step=0,reached=0,typing=null,uid=0;

/* gráfico de área com gradiente e animação de subida */
function areaChart(v,{w=300,h=110,grid=true,c1="#5B8FD6",c2="#FF3180"}={}){
  const id="g"+(++uid),pad=6,mx=Math.max(...v),mn=Math.min(...v)*.8,r=mx-mn||1;
  const pts=v.map((y,i)=>[pad+i*(w-2*pad)/(v.length-1),h-pad-(y-mn)/r*(h-2*pad)]);
  let d=`M${pts[0][0]} ${pts[0][1]}`;
  for(let i=1;i<pts.length;i++){const [x0,y0]=pts[i-1],[x1,y1]=pts[i],cx=(x0+x1)/2;d+=` C${cx} ${y0},${cx} ${y1},${x1} ${y1}`}
  const last=pts[pts.length-1];
  let len=0;for(let i=1;i<pts.length;i++)len+=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);
  const gl=grid?[.25,.5,.75].map(f=>`<line x1="0" x2="${w}" y1="${h*f}" y2="${h*f}" stroke="rgba(245,248,252,.07)"/>`).join(""):"";
  return `<defs><linearGradient id="${id}a" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c1}" stop-opacity=".55"/><stop offset="1" stop-color="${c1}" stop-opacity="0"/></linearGradient><linearGradient id="${id}l" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs>${gl}
  <path class="area" d="${d} L${last[0]} ${h} L${pts[0][0]} ${h} Z" fill="url(#${id}a)"/>
  <path class="line" style="--len:${Math.ceil(len*1.3)}" d="${d}" fill="none" stroke="url(#${id}l)" stroke-width="3" stroke-linecap="round"/>
  <g class="end"><circle cx="${last[0]}" cy="${last[1]}" r="9" fill="${c2}" opacity=".25"/><circle cx="${last[0]}" cy="${last[1]}" r="4.5" fill="${c2}"/></g>`;
}
function play(svg){svg.classList.remove("go");void svg.getBoundingClientRect();svg.classList.add("go")}
function regionsHTML(reg){return reg.map(([n,v])=>`<div class="reg"><span>${n}</span><div class="track"><div class="fill" data-w="${v}"></div></div><b>${v}</b></div>`).join("")}
function growBars(root){requestAnimationFrame(()=>requestAnimationFrame(()=>root.querySelectorAll(".fill").forEach(f=>f.style.width=f.dataset.w+"%")))}
function countUp(el){const to=+el.dataset.to;if(RM){el.textContent="+"+to;return}let t0=null;const f=t=>{t0=t0||t;const p=Math.min(1,(t-t0)/1400),e=1-Math.pow(1-p,3);el.textContent="+"+Math.round(to*e);if(p<1)requestAnimationFrame(f)};requestAnimationFrame(f)}

/* resultados */
function showResults(key,label,animate){
  cur=key;open=-1;$("#panel").hidden=true;
  $("#restitle").textContent=`Encontramos 3 tendências para ${label}`;
  const c=$("#cards");c.innerHTML="";
  DATA[key].trends.forEach((t,i)=>{
    const b=document.createElement("button");b.className="tcard gdark"+(animate?" appear":"");b.setAttribute("aria-expanded","false");
    if(animate)b.style.animationDelay=(i*160)+"ms";
    b.innerHTML=`<div class="row"><span class="pill ${STL[t.st][1]}">${STL[t.st][0]}</span><span class="growth">↗ +${t.g}%</span></div><h4>${esc(t.name)}</h4><svg class="chart" viewBox="0 0 300 70" preserveAspectRatio="none" aria-hidden="true">${areaChart(t.s,{h:70,grid:false})}</svg><span class="open">Ver tendência →</span>`;
    b.onclick=()=>openTrend(i);c.appendChild(b);
    const svg=b.querySelector("svg");setTimeout(()=>play(svg),animate?i*160+150:0);
  });
}
function openTrend(i){
  open=i;step=0;reached=0;
  document.querySelectorAll(".tcard").forEach((b,j)=>b.setAttribute("aria-expanded",j===i));
  $("#panel").hidden=false;renderStep();
  $("#panel").scrollIntoView({behavior:RM?"auto":"smooth",block:"nearest"});
}
function renderStep(){
  const t=DATA[cur].trends[open];
  $("#steps").innerHTML=STEPS.map((s,i)=>`<li><button ${i>reached?"disabled":""} class="${i===step?"on":""} ${i<reached&&i!==step?"done":""}" data-s="${i}" aria-current="${i===step?"step":"false"}"><span class="n">${i<reached&&i!==step?"✓":i+1}</span><span>${s}</span></button></li>`).join("");
  let body="";
  if(step===0)body=`<h3>${esc(t.why)}</h3>
    <div class="split"><div class="ibox"><span class="kicker" style="color:rgba(255,255,255,.65)">Interesse · últimos 10 dias</span><svg class="chart" id="stchart" viewBox="0 0 300 120" role="img" aria-label="Gráfico de interesse (exemplo)">${areaChart(t.s,{h:120})}</svg></div>
    <div class="ibox"><span class="kicker" style="color:rgba(255,255,255,.65)">Força do sinal por fonte</span><div class="regions" id="streg" style="margin-top:10px">${regionsHTML(t.reg)}</div><span class="ex">Índice 0–100 por fonte · exemplo</span></div></div>
    <p class="ibox"><b>Primeiro a gente pesquisa. Depois sugere. E sempre mostra o porquê.</b></p>
    <button class="linkbtn" id="srcbtn">Ver fontes</button><ul class="srcs" id="srcs">${t.src.map(s=>`<li>${esc(s)}</li>`).join("")}</ul>`;
  if(step===1)body=`<h3>Veja um exemplo antes de gravar o seu.</h3><div class="video"><span class="play"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg></span></div><p style="color:rgba(255,255,255,.7);font-size:15px">Na plataforma, o vídeo real aparece aqui, direto do YouTube, TikTok ou Instagram.</p>`;
  if(step===2)body=`<h3>${esc(t.idea)}</h3><div class="ibox"><span class="kicker" style="color:rgba(255,255,255,.65)">Gancho</span><p style="font-weight:600;font-size:19px;margin-top:4px">${esc(t.hook)}</p></div>`;
  if(step===3)body=`<h3>Modelo de legenda</h3><div class="ibox caption" id="cap">${esc(t.cap)}</div><button class="copybtn" id="copy">Copiar legenda</button>`;
  if(step===4)body=`<h3>Agora veja as tendências do seu ramo.</h3><p style="color:rgba(255,255,255,.75)">Crie sua conta e receba tendências e ideias para o seu negócio.</p><div class="cta-wrap"><button class="cta" data-signup>Começar grátis<span class="arr">${ARR}</span></button></div>`;
  const nav=step<4?`<div class="stagenav"><button class="next" id="next">Próximo: ${STEPS[step+1]} →</button><span class="kicker" style="color:rgba(255,255,255,.6)">${step+1} de 5</span></div>`:"";
  $("#stage").innerHTML=`<div class="stage-enter" style="display:flex;flex-direction:column;gap:14px">${body}${nav}</div>`;
  const sc=$("#stchart");if(sc){play(sc);growBars($("#streg"))}
  const n=$("#next");if(n)n.onclick=()=>{step++;reached=Math.max(reached,step);renderStep()};
  const sb=$("#srcbtn");if(sb)sb.onclick=()=>{$("#srcs").classList.toggle("show");sb.textContent=$("#srcs").classList.contains("show")?"Esconder fontes":"Ver fontes"};
  const cp=$("#copy");if(cp)cp.onclick=async()=>{try{await navigator.clipboard.writeText(t.cap);toast("Legenda copiada! Agora é só colar no seu post.")}catch(e){const r=document.createRange();r.selectNodeContents($("#cap"));const s=getSelection();s.removeAllRanges();s.addRange(r);toast("Texto selecionado. Use Copiar do seu celular.")}};
}
$("#steps").addEventListener("click",e=>{const b=e.target.closest("button[data-s]");if(!b||b.disabled)return;step=+b.dataset.s;renderStep()});

function resolve(v){const n=norm(v);for(const [re,k] of MAP)if(re.test(n))return k;return null}
function runSearch(v,animate=true){v=v.trim();if(!v)return;const k=resolve(v);
  if(k)showResults(k,v,animate);else{showResults("doces","doces para festa",animate);toast(`Nesta prévia só temos exemplos de doces, beleza e moda. Na plataforma, "${v}" teria resultados próprios.`)}}
function stopTyping(){if(typing){clearInterval(typing);typing=null}}
function autoType(text,then){stopTyping();const q=$("#q");q.value="";let i=0;
  if(RM){q.value=text;then&&then();return}
  typing=setInterval(()=>{q.value=text.slice(0,++i);if(i>=text.length){stopTyping();setTimeout(()=>then&&then(),250)}},70)}
$("#sform").addEventListener("submit",e=>{e.preventDefault();stopTyping();runSearch($("#q").value)});
$("#q").addEventListener("focus",stopTyping);
document.querySelectorAll("[data-try]").forEach(b=>b.addEventListener("click",()=>autoType(b.dataset.try,()=>runSearch(b.dataset.try))));
$("#sform2").addEventListener("submit",e=>{e.preventDefault();const v=$("#q2").value.trim();if(!v)return;$("#q").value=v;runSearch(v);$("#res").scrollIntoView({behavior:RM?"auto":"smooth"})});

/* recursos */
const ICON={t:'<path d="M3 17l6-6 4 4 8-8"/><path d="M14 7h7v7"/>',v:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9l5 3-5 3z"/>',i:'<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9V16h7v-2.1A6 6 0 0 0 12 3z"/>',l:'<path d="M4 6h16M4 12h16M4 18h10"/>',b:'<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',r:'<path d="M5 19V5l7 4 7-4v14l-7-4z"/>'};
const RES=[
 ["t","Tendências","O que está crescendo no seu ramo e na sua região.",()=>`<div class="ibox"><svg class="chart" id="rchart" viewBox="0 0 300 90" aria-hidden="true">${areaChart([8,9,11,12,15,17,21,24,29,33],{h:90})}</svg></div><div class="ibox"><div class="regions" id="rreg">${regionsHTML([["Wikipédia",82],["Notícias",67],["Trends",44]])}</div></div>`],
 ["v","Vídeos","Exemplos reais para ver antes de gravar.",()=>`<div class="video" style="max-width:150px"><span class="play"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg></span></div>`],
 ["i","Ideias","Uma sugestão de post ligada a cada tendência.",()=>`<div class="ibox"><span class="kicker" style="color:rgba(255,255,255,.65)">Reels · 15 s</span><p style="font-weight:600;margin-top:4px">"Olha o que acontece quando eu corto esse pote..."</p></div>`],
 ["l","Legendas","Modelos prontos para adaptar e copiar.",()=>`<div class="ibox caption">Recheio que transborda 🍫\nEncomendas pelo WhatsApp.</div>`],
 ["b","Bio","Diga em 2 linhas o que você vende e como comprar.",()=>`<div class="ibox" style="opacity:.6;text-decoration:line-through">Amo o que faço 💕</div><div class="ibox" style="font-weight:600;border-color:#FF3180">Doces para festa em Petrolina · Encomendas pelo WhatsApp ↓</div>`],
 ["r","Trilhas","Passo a passo curto para aprender postando.",()=>`<div class="ibox"><b>Seus primeiros 9 posts</b><div class="track" style="height:10px;background:rgba(255,255,255,.12);border-radius:6px;margin-top:10px;overflow:hidden"><div class="fill" data-w="44" style="height:100%;border-radius:6px;background:linear-gradient(90deg,#5B8FD6,#FF3180);width:0;transition:width 1.2s cubic-bezier(.2,.8,.2,1)"></div></div><span style="font-size:13px;opacity:.75">4 de 9 concluídos · exemplo</span></div>`]];
function showRes(i){
  document.querySelectorAll(".rbtn").forEach((b,j)=>b.setAttribute("aria-selected",j===i));
  const r=RES[i];
  $("#device").innerHTML=`<div class="top"><span>EVOLUISOCIAL</span><span>${r[1].toUpperCase()}</span></div><h3>${r[1]}</h3><p>${r[2]}</p>${r[3]()}<a class="link" href="#recursos" data-toast="Na versão final, abre a página Recursos.">Saiba mais →</a>`;
  const rc=$("#rchart");if(rc)play(rc);growBars($("#device"));
}
$("#rlist").innerHTML=RES.map((r,i)=>`<button class="rbtn glass" role="tab" aria-selected="false" data-r="${i}"><span class="ic"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[r[0]]}</svg></span>${r[1]}</button>`).join("");
$("#rlist").addEventListener("click",e=>{const b=e.target.closest("[data-r]");if(b)showRes(+b.dataset.r)});

/* para quem */
const AUD=[["Lojistas","Ideias de vitrine, lançamento e promoção.","moda praia","Moda praia para o verão nordestino"],["Prestadores de serviço","Formatos para mostrar o seu trabalho.","corte de cabelo","Antes e depois de corte bob"],["Negócios locais","O que está em alta na sua cidade.","doceria em Petrolina","Caixas de doces para o Dia das Crianças"],["Marcas pessoais","Temas para mostrar o que você sabe.","nutricionista","Bastidores do dia a dia com som ambiente"]];
function showAud(i){
  document.querySelectorAll("#atabs button").forEach((b,j)=>b.setAttribute("aria-selected",j===i));
  const a=AUD[i];
  $("#apanel").innerHTML=`<p>${a[1]}</p><div style="display:flex;flex-direction:column;gap:10px" class="stage-enter"><div class="fakesearch glass"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>${a[2]}</div><div class="lcard glass"><span class="pill">Crescendo</span><h4>${a[3]}</h4><span style="font-size:12px;color:var(--muted)">exemplo</span></div></div>`;
}
$("#atabs").innerHTML=AUD.map((a,i)=>`<button role="tab" aria-selected="false" data-a="${i}">${a[0]}</button>`).join("");
$("#atabs").addEventListener("click",e=>{const b=e.target.closest("[data-a]");if(b)showAud(+b.dataset.a)});

/* toasts / ctas */
let tt;function toast(m){const el=$("#toast");el.textContent=m;el.hidden=false;clearTimeout(tt);tt=setTimeout(()=>el.hidden=true,3200)}
document.addEventListener("click",e=>{
  const s=e.target.closest("[data-signup]");if(s){e.preventDefault();openModal(null);return}
  const t=e.target.closest("[data-toast]");if(t){e.preventDefault();toast(t.dataset.toast)}
});

/* revelar ao rolar: só afeta o que está abaixo da dobra; tudo continua visível sem JS */
const io=("IntersectionObserver" in window)?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.remove("pre");io.unobserve(e.target)}}),{threshold:.12}):null;
if(io&&!RM)document.querySelectorAll(".rv").forEach(el=>{if(el.getBoundingClientRect().top>innerHeight){el.classList.add("pre");io.observe(el)}});
const devIO=("IntersectionObserver" in window)?new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){showRes(0);devIO.disconnect()}}),{threshold:.3}):null;
if(devIO)devIO.observe($("#device"));else showRes(0);

/* barra fixa no celular */
const sticky=$("#sticky");let heroOut=false,finalIn=false;
const upd=()=>sticky.classList.toggle("show",heroOut&&!finalIn);
if("IntersectionObserver" in window){
  new IntersectionObserver(([e])=>{heroOut=!e.isIntersecting;upd()}).observe($(".hero-actions"));
  new IntersectionObserver(([e])=>{finalIn=e.isIntersecting;upd()}).observe($("#final"));
}


/* ===== planos: mensal / anual ===== */
let bill="m";
document.querySelectorAll("[data-bill]").forEach(b=>b.addEventListener("click",()=>{
  bill=b.dataset.bill;document.querySelectorAll("[data-bill]").forEach(x=>x.setAttribute("aria-pressed",x===b));
  document.querySelectorAll(".plan [data-m]").forEach(el=>el.textContent=el.dataset[bill]);
}));
/* ===== login real (Google, via Supabase) — pagamento online ainda não ativado ===== */
const PLANS={pro:{name:"Pro",m:"R$ 29,90 por mês",a:"R$ 298,80 por ano (R$ 24,90 por mês)"},master:{name:"Master",m:"R$ 59,90 por mês",a:"R$ 598,80 por ano (R$ 49,90 por mês)"}};
let logged=false,lastFocus=null,pending=null;
const APP="/evoluisocial/app/";
(async()=>{try{if(window.Evolui&&await window.Evolui.sessao()){logged=true;document.querySelectorAll(".enter").forEach(b=>b.textContent="Minha área")}}catch(e){}})();
function dots(n,t){return `<div class="progress-dots" aria-hidden="true">${Array.from({length:t},(_,i)=>`<i class="${i<n?"on":""}"></i>`).join("")}</div>`}
function stepLogin(erro){
  const total=pending?2:1;
  $("#mbody").innerHTML=`<div class="mstep">${dots(1,total)}<h2 id="mtitle">${pending?"Primeiro, entre na sua conta":"Entre na EvoluiSocial"}</h2>
   <p>${pending?`Depois você vê como ativar o plano ${PLANS[pending].name}.`:"Comece grátis. Leva poucos segundos e não pede cartão."}</p>
   ${erro?`<p class="fine" role="alert" style="color:#FFB4AB!important">${erro}</p>`:""}
   <button class="gbtn" id="google"><span class="g">G</span>Continuar com Google</button>
   <p class="fine">Usamos sua conta Google só para criar seu acesso. Nunca postamos nada por você. Ao continuar, você aceita a <a href="/privacidade">Política de privacidade</a>.</p></div>`;
  $("#google").onclick=async()=>{
    const b=$("#google");b.disabled=true;b.textContent="Abrindo o Google…";
    try{if(pending)sessionStorage.setItem("evolui_plano_desejado",pending)}catch(e){}
    try{const r=await window.Evolui.entrarGoogle();if(r&&r.error)throw r.error}
    catch(e){stepLogin("Não conseguimos abrir o login do Google agora. Tente de novo em instantes.")}
  };
}
function stepPay(){location.href=APP+"?planos="+encodeURIComponent(pending)+"&ciclo="+(bill==="a"?"anual":"mensal")+"#perfil"}
function openModal(plan){
  if(logged&&!plan){location.href=APP;return}
  pending=plan||null;lastFocus=document.activeElement;
  $("#modal").hidden=false;document.documentElement.style.overflow="hidden";
  (pending&&logged)?stepPay():stepLogin();
  const f=$("#modal").querySelector("button:not(.mclose)");f&&f.focus();
}
function closeModal(){$("#modal").hidden=true;document.documentElement.style.overflow="";lastFocus&&lastFocus.focus&&lastFocus.focus()}
$("#mclose").onclick=closeModal;
$("#modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
document.addEventListener("keydown",e=>{
  if($("#modal").hidden)return;
  if(e.key==="Escape")closeModal();
  if(e.key==="Tab"){const f=[...$("#modal").querySelectorAll("button,a[href]")].filter(x=>x.offsetParent);if(!f.length)return;const first=f[0],last=f[f.length-1];
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
});
document.querySelectorAll("[data-plan]").forEach(b=>b.addEventListener("click",()=>openModal(b.dataset.plan)));
/* teclado do celular aberto: esconde a barra fixa para não cobrir o campo */
document.addEventListener("focusin",e=>{if(e.target.matches("input"))$("#sticky").classList.add("kb")});
document.addEventListener("focusout",e=>{if(e.target.matches("input"))$("#sticky").classList.remove("kb")});

/* estado inicial */
$("#herochart").innerHTML=areaChart([12,14,15,18,20,24,28,31,36,38],{h:110});
$("#heroreg").innerHTML=regionsHTML([["Wikipédia",86],["Notícias",64],["Trends",38]]);
setTimeout(()=>{play($("#herochart"));growBars($("#heroreg"));countUp($("#count"))},300);
showResults("doces","doces para festa",false);
showAud(0);
if(!devIO)showRes(0); else { $("#device").innerHTML='<div class="top"><span>EVOLUISOCIAL</span><span>TENDÊNCIAS</span></div><h3>Tendências</h3><p>O que está crescendo no seu ramo e na sua região.</p>'; document.querySelector('.rbtn').setAttribute('aria-selected','true'); }
/* demonstração automática: para assim que a pessoa interage, para nunca desfazer o que ela abriu */
let userActed=false;
["pointerdown","keydown","wheel","touchstart"].forEach(ev=>addEventListener(ev,()=>{userActed=true},{once:true,passive:true}));
setTimeout(()=>{if(userActed||$("#q").value||document.activeElement===$("#q"))return;
  autoType("doces para festa",()=>{if(!userActed||open<0)showResults("doces","doces para festa",true)})},1200);
document.addEventListener("pointerdown",e=>{if(typing&&!e.target.closest("[data-try]"))stopTyping()},{passive:true});
})();
