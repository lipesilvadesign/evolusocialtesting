## Format Intelligence — 02/10/2026 (eie-v1-format-intelligence-v1)

Função isolada `evolui-criar` (não altera `evolui-api`). Botão "Transformar esta ideia" nos cards de ideia, com 6 módulos de contratos distintos: Mais ideias para isso (ângulos, nunca outros formatos), Ideia vídeo curto (gancho, desenvolvimento, fechamento, CTA), Guia de texto (abertura, desenvolvimento, argumentação, encerramento, CTA), Ideia Stories (gancho, contexto, interação, desenvolvimento, CTA), Ideia carrossel (3 a 9 slides conforme a ideia) e Ideia formato carrossel (escolhe entre 11 estruturas).

- Código: `supabase/functions/evolui-api/eie/formato.ts` e `formato-dados.ts` (matriz `MODULE_INTELLIGENCE`, `profile_signals`, léxico de ofícios, quality gate com até 3 tentativas e fallback seguro). Testes: `formato.test.ts`.
- Perfil, objetivo e ideia entram como três entradas separadas. Nada é inventado: sem detalhe do negócio, usa etapas neutras e avisa.
- Limites: heurístico (sem LLM/embeddings), léxico de ofícios fixo, não grava log no banco, não consome cota.

## Central de Repertório — 02/10/2026 (REP-v1)

**Onde:** Painel → EvoluiSocial → aba **Repertório** (só administradores). "Coloque o conhecimento. O Evolui organiza."
- **Entrada:** um campo grande (artigo/texto) + detalhes opcionais (título, fonte, autor, assunto, tags, observação). Mensagens: "Analisando conteúdo..." → "Conhecimento incorporado ao repertório."
- **Análise (sem IA paga, sem API):** `supabase/functions/evolui-repertorio/analise.ts` (heurística em português): assunto, subassuntos, conceitos (35 do marketing + termos/expressões do próprio texto), aplicações/formatos, segmentos, objetivos, padrões de título, aberturas, CTAs, relações (conceito → aplicação → formato → público → objetivo), categorias múltiplas sob "Marketing", conflitos (polaridade "A aumenta/reduz B") e **insights derivados** (combinações entre conhecimentos).
- **Rede, não pastas:** o novo texto liga-se a conceitos já existentes; nada é apagado em silêncio; conflitos são registrados com as duas fontes.
- **Procedência sempre visível:** *Fonte original* (trechos literais) · *Interpretação do sistema* · *Hipótese do Evolui* (insight derivado: "não está em nenhuma fonte").
- **Administração:** totais (conhecimentos, conceitos, relações, categorias, novos, sem uso, insights, conflitos), mais usados, busca, abrir/editar (título, assunto, fonte, tags, categorias, observação, arquivar), excluir, relações, onde foi usado, insights (descartar/reativar), conflitos (resolver).
- **Uso na pesquisa:** `evolui-api` v10 consulta `evolui_rep_consultar` (tolerante a falha, 2,5 s). Seleciona por conceitos da frase + associações do formato/objetivo + ramo; devolve `repertorio` com referências (título/fonte/conceitos), **estruturas adaptadas ao tema** (nunca o texto do artigo; o original só existe no painel) e hipóteses derivadas rotuladas. Moldes variam por usuário/dia para não repetir. App: bloco "Do repertório do Evolui".
- **Memória do usuário ≠ repertório global:** só ramo, intenções e termos da busca vão ao repertório; nada pessoal.
- **Banco:** tabelas `evolui_rep_*` (RLS: só admin lê; escrita só pela função/RPC com service role). Funções: `evolui-repertorio` v1 (adicionar/excluir/ajustar), `evolui-api` v10.
- **Limites honestos:** classificação heurística (sem embeddings/LLM); vocabulário de conceitos é uma lista fechada de marketing (amplie em `VOCAB`); qualidade melhora com mais textos.


## Evolução 02/10/2026 — oportunidades, YouTube e Geoapify (opcionais)

**Pipeline:** fontes → sinais (série diária) → classificação → **oportunidade com evidência** → ideias (EIE) → ação.
- `eie/oportunidades.ts`: `rrf` (fusão de listas por posição), `parseYoutube`, `termosDeTitulos`, `evidencia` (alta/média/baixa + fontes + data + motivo), `detectarOportunidade`.
- A resposta de `buscar` ganhou `oportunidade` (o que está acontecendo / por que importa / o que fazer + evidência) e `videos` (até 3 títulos públicos).
- **YouTube (`search.list`)**: só planos pagos, só com a chave em Painel → Integrações → "YouTube Data API v3". Custa 100 pontos da cota diária (10.000 = ~100 buscas/dia): cache de 6 h por assunto e teto interno de 80 consultas/dia por instância. A API devolve no máximo 50 vídeos; se lotar, mostramos o volume mas não medimos crescimento. A chave vai no cabeçalho `X-Goog-Api-Key`, nunca em URL de log.
- **Geoapify**: opcional, chave em Painel → Integrações. Na ação `local` tenta Geocoding/Places (máx. 100 por consulta → mostrado como "até 100"); qualquer falha cai no OpenStreetMap como antes.
- **Observabilidade:** `evolui_eie_log.meta` guarda fontes usadas, fontes com falha, estado/evidência da oportunidade; `evolui_fontes_status` ganha `youtube` e `geoapify`.
- Sem novas tabelas (reaproveita `evolui_integracoes`, `evolui_fontes_status`, `evolui_eie_log`).
- Funções: `evolui-api` v9; `evolui-integracoes` v2 (código em `supabase/functions/evolui-integracoes/index.ts`).

## Identidade visual própria — 02/10/2026 (só aparência; nenhuma função alterada)

- **Marca:** logomarca oficial em `evoluisocial/marca/` (SVG horizontal, vertical e símbolo, em duas versões: azul para fundo claro, `-claro` para fundo escuro; ícones PNG do app).
- **Cores:** branco-gelo `#F5F8FC` (fundo), azul escuro `#034FA8` (estrutura/confiança), azul profundo `#0A2A5E` (superfícies de destaque) e rosa `#FF3180` (ação e destaque). Botão de ação em fundo claro usa `#D81B60` (contraste AA com texto branco).
- **Tipografia:** Montserrat (títulos, igual à logo) + Manrope (texto). Sem serifa, sem fonte mono.
- **Tema:** claro por padrão; escuro opcional. Chave própria `evolui_tema` (não depende mais da chave do site da Felipe Branding). `evoluisocial/tema.js` aplica antes de desenhar.
- **Arquivos alterados:** `app/app.css`, `evoluisocial.css` (novas variáveis no topo + bloco "IDENTIDADE EVOLUI" no fim), `app/app.js` (logo, rótulo "Início", markup da Home, cores do gráfico), `evoluisocial.js` (cores do gráfico), `comum.js` (tema), `index.html` e `app/index.html` (fontes, ícone, logo).
- **Início (Home):** 1) saudação e busca ("Escreva um produto, um assunto ou a sua própria ideia"); 2) "A Evolui encontrou para você"; 3) "O que você quer fazer?"; 4) atalho para o Laboratório (bio e legenda próprias). Os IDs e funções existentes (`#q`, `#fBusca`, `#paraVoce`, `#emalta`, `#objGrade`, `#resultado`, `#uso`) foram mantidos.
