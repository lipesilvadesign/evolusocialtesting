-- =====================================================================
-- Migration 012 — Aprovação parcial segura + contador de enriquecidos
-- 01/10/2026 · ADITIVA E IDEMPOTENTE
--
-- 1. aprovar_captura: cada registro roda num SUBBLOCO (savepoint). Um erro
--    inesperado em 1 registro (ex.: violação de índice) desfaz SÓ aquele
--    registro (lead + atividade + auditoria + status da captura juntos) e
--    devolve {resultado:'erro', mensagem}; os outros continuam aprovados.
--    Erros de VALIDAÇÃO do pedido (permissão 42501, parâmetro 22023 — ex.:
--    prospecção atribuindo a outra pessoa) continuam abortando o pedido
--    inteiro: valem para todos os registros.
--    Nunca: captura 'aprovado' sem lead (os dois estão no mesmo subbloco).
-- 2. admin_prospeccao_buscas.qtd_enriquecidos (+ recontagem).
-- Rollback: definições anteriores em backup_auditoria.objetos_01_10_012.
-- =====================================================================

alter table public.admin_prospeccao_buscas add column if not exists qtd_enriquecidos integer not null default 0;

create or replace function public.aprovar_captura(p_ids uuid[], p_responsavel uuid default null, p_prioridade text default 'media',
    p_campanha text default null, p_forcar_novo boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare i uuid; out jsonb := '[]'::jsonb; r jsonb; v_estado text; v_msg text;
begin
  if not (prospeccao_pode_operar() or prospeccao_eh_servico()) then
    raise exception 'Sem permissão para aprovar.' using errcode = '42501';
  end if;
  if p_prioridade is not null and p_prioridade not in ('alta','media','baixa') then
    raise exception 'Prioridade inválida.' using errcode = '22023';
  end if;
  if p_campanha is not null and p_campanha <> '' and p_campanha !~ '^[a-z0-9_]{1,60}$' then
    raise exception 'Campanha inválida (use letras minúsculas, números e _).' using errcode = '22023';
  end if;
  if coalesce(array_length(p_ids, 1), 0) > 200 then
    raise exception 'No máximo 200 registros por aprovação.' using errcode = '22023';
  end if;
  foreach i in array coalesce(p_ids, '{}') loop
    begin
      r := prospeccao_aprovar_um(i, p_responsavel, p_prioridade, p_campanha, p_forcar_novo);
    exception
      when insufficient_privilege or invalid_parameter_value then
        raise; -- regra do pedido inteiro (responsável/permissão): aborta tudo
      when others then
        get stacked diagnostics v_estado = returned_sqlstate, v_msg = message_text;
        r := jsonb_build_object('captura_id', i, 'resultado', 'erro', 'codigo', v_estado,
               'mensagem', case v_estado
                 when '23505' then 'Registro duplicado no CRM (índice único).'
                 when '23514' then 'Um dado não passou nas regras do banco.'
                 when '23502' then 'Campo obrigatório ausente.'
                 else 'Falha inesperada ao gravar este registro.' end);
    end;
    out := out || r;
  end loop;
  return out;
end $$;
revoke all on function public.aprovar_captura(uuid[], uuid, text, text, boolean) from public, anon;
grant execute on function public.aprovar_captura(uuid[], uuid, text, text, boolean) to authenticated, service_role;

create or replace function public.prospeccao_job_recontar(p_job uuid) returns void
language plpgsql security definer set search_path = public as $$
declare c record;
begin
  select count(*) total,
         count(*) filter (where status <> 'erro') normalizados,
         count(*) filter (where status = 'duplicado') duplicados,
         count(*) filter (where status = 'possivel_duplicado') possiveis,
         count(*) filter (where status = 'descartado') descartados,
         count(*) filter (where status = 'bloqueado_optout') bloqueados,
         count(*) filter (where status = 'aprovado') aprovados,
         count(*) filter (where enriquecimento_status in ('concluido','parcial')) enriquecidos,
         count(*) filter (where status in ('pendente','possivel_duplicado')) abertos
    into c from admin_prospeccao_captura where job_id = p_job;
  update admin_prospeccao_buscas set
    qtd_encontrados = c.total, qtd_normalizados = c.normalizados, qtd_duplicados = c.duplicados,
    qtd_possiveis_duplicados = c.possiveis, qtd_descartados = c.descartados, qtd_bloqueados = c.bloqueados,
    qtd_aprovados = c.aprovados, qtd_enriquecidos = c.enriquecidos, total_encontrado = c.total,
    status = case when status = 'em_revisao' and c.abertos = 0 then 'concluido' else status end,
    finalizado_em = case when status = 'em_revisao' and c.abertos = 0 then now() else finalizado_em end,
    updated_at = now()
   where id = p_job;
end $$;
revoke all on function public.prospeccao_job_recontar(uuid) from public, anon, authenticated;
