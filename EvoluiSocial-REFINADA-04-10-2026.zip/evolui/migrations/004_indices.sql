-- =====================================================================
-- Migration 004 — pg_trgm + índices de filtro e deduplicação
-- Lead Capture Engine · 30/09/2026
--
-- Objetivo
--   - Extensão pg_trgm (similaridade de nomes, busca por texto). O Supabase
--     disponibiliza pg_trgm na lista de extensões suportadas; fica no schema
--     "extensions" (padrão do Supabase). Se a extensão não puder ser criada,
--     o bloco abaixo avisa e segue: a deduplicação cai no fallback sem
--     similaridade (só chaves exatas + nome normalizado igual) — ver
--     prospeccao_dedup_candidatos na 009.
--   - Índices para os filtros do CRM e para as chaves de deduplicação.
--   - ÚNICO só para CNPJ válido. Telefone, domínio e Instagram NÃO são únicos
--     de propósito: grupo empresarial, franquia e coworking dividem número e
--     site — nesses casos o sistema pede revisão humana ("possível duplicado"),
--     não recusa o cadastro. (Diferença consciente em relação à especificação,
--     que previa único parcial também em telefone/domínio.)
--
-- Risco: o único de cnpj_norm falha se já houver dois leads com o mesmo CNPJ
-- válido (hoje: nenhum lead tem CNPJ). O bloco verifica antes e, se houver,
-- cria índice NÃO único e avisa.
--
-- Idempotente. Dependências: 003.
-- Rollback: drop index if exists (cada índice abaixo); a extensão pode ficar.
-- =====================================================================

create schema if not exists extensions;
do $$ begin
  begin
    create extension if not exists pg_trgm with schema extensions;
  exception when others then
    raise warning 'pg_trgm indisponível (%): deduplicação usará o fallback sem similaridade.', sqlerrm;
  end;
end $$;

create index if not exists admin_prospeccao_leads_status_idx on public.admin_prospeccao_leads (status);
create index if not exists admin_prospeccao_leads_cidade_norm_idx on public.admin_prospeccao_leads (cidade_norm);
create index if not exists admin_prospeccao_leads_uf_idx on public.admin_prospeccao_leads (uf);
create index if not exists admin_prospeccao_leads_fonte_idx on public.admin_prospeccao_leads (fonte);
create index if not exists admin_prospeccao_leads_metodo_idx on public.admin_prospeccao_leads (metodo_captacao);
create index if not exists admin_prospeccao_leads_campanha_idx on public.admin_prospeccao_leads (campanha) where campanha is not null;
create index if not exists admin_prospeccao_leads_temperatura_idx on public.admin_prospeccao_leads (temperatura) where temperatura is not null;
create index if not exists admin_prospeccao_leads_setor_idx on public.admin_prospeccao_leads (setor);
create index if not exists admin_prospeccao_leads_ultima_atividade_idx on public.admin_prospeccao_leads (ultima_atividade_em desc nulls last);
create index if not exists admin_prospeccao_leads_score_id_idx on public.admin_prospeccao_leads (score desc, id) where arquivado_em is null;
create index if not exists admin_prospeccao_leads_telefone_norm_idx on public.admin_prospeccao_leads (telefone_norm) where telefone_norm is not null;
create index if not exists admin_prospeccao_leads_dominio_idx on public.admin_prospeccao_leads (dominio) where dominio is not null;
create index if not exists admin_prospeccao_leads_instagram_idx on public.admin_prospeccao_leads (instagram_handle) where instagram_handle is not null;
create index if not exists admin_prospeccao_leads_email_lower_idx on public.admin_prospeccao_leads (lower(email)) where email is not null;
create index if not exists admin_prospeccao_leads_empresa_cidade_idx on public.admin_prospeccao_leads (empresa_norm, cidade_norm);

do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_trgm') then
    execute 'create index if not exists admin_prospeccao_leads_empresa_trgm_idx on public.admin_prospeccao_leads using gin (empresa_norm extensions.gin_trgm_ops)';
  end if;
  if not exists (select 1 from pg_class where relname = 'admin_prospeccao_leads_cnpj_norm_key') then
    if exists (select cnpj_norm from public.admin_prospeccao_leads where cnpj_norm is not null group by 1 having count(*) > 1) then
      raise warning 'Há CNPJs repetidos: índice de cnpj_norm criado SEM unicidade. Resolver duplicatas e recriar como único.';
      execute 'create index if not exists admin_prospeccao_leads_cnpj_norm_idx on public.admin_prospeccao_leads (cnpj_norm) where cnpj_norm is not null';
    else
      execute 'create unique index admin_prospeccao_leads_cnpj_norm_key on public.admin_prospeccao_leads (cnpj_norm) where cnpj_norm is not null';
    end if;
  end if;
end $$;

-- Opt-outs: consulta por chave normalizada
alter table public.admin_prospeccao_optouts add column if not exists telefone_norm text;
update public.admin_prospeccao_optouts set telefone_norm = public.prospeccao_norm_telefone(telefone) where telefone is not null and telefone_norm is null;
create or replace function public.prospeccao_optouts_normalizar() returns trigger
language plpgsql set search_path = public as $$
begin
  new.telefone_norm := public.prospeccao_norm_telefone(new.telefone);
  return new;
end $$;
drop trigger if exists prospeccao_optouts_normalizar on public.admin_prospeccao_optouts;
create trigger prospeccao_optouts_normalizar before insert or update on public.admin_prospeccao_optouts
  for each row execute function public.prospeccao_optouts_normalizar();
create index if not exists admin_prospeccao_optouts_email_idx on public.admin_prospeccao_optouts (lower(email)) where email is not null;
create index if not exists admin_prospeccao_optouts_tel_idx on public.admin_prospeccao_optouts (telefone_norm) where telefone_norm is not null;
create index if not exists admin_prospeccao_optouts_origem_idx on public.admin_prospeccao_optouts (origem_id) where origem_id is not null;

-- Atividades: temperatura consulta a última interação do lead
create index if not exists admin_prospeccao_atividades_lead_tipo_data_idx on public.admin_prospeccao_atividades (lead_id, tipo, data desc);
