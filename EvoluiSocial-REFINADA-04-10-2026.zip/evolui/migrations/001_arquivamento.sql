-- =====================================================================
-- Migration 001 — Arquivamento de leads + trava contra exclusão automática
-- Lead Capture Engine · Fase 0 · 30/09/2026
--
-- Objetivo
--   1. Colunas de arquivamento em admin_prospeccao_leads (aditivas, nulas).
--   2. Índice parcial para a lista padrão (arquivado_em IS NULL).
--   3. TRAVA NO BANCO: DELETE feito com a service role (rotinas automáticas
--      das Netlify Functions) em admin_prospeccao_leads é RECUSADO.
--      Exclusão manual pelo painel (admin autenticado, RLS delete_leads)
--      continua funcionando. SQL direto no console (postgres) também.
--      Motivo: a rotina runStaleLeadCleanup publicada até 30/09 faz DELETE
--      de leads parados; a correção de código só vale após novo deploy.
--      Com a trava, o DELETE falha (HTTP 4xx), a rotina registra erro no
--      log e nenhum lead é apagado — sem notificação enganosa no sino.
--
-- Idempotente: pode rodar mais de uma vez.
-- Dependências: nenhuma.
-- Backup: backup_auditoria.prospeccao_leads_30_09 (cópia integral antes).
-- Rollback:
--   drop trigger if exists prospeccao_leads_bloquear_delete_automatico on public.admin_prospeccao_leads;
--   drop function if exists public.prospeccao_bloquear_delete_automatico();
--   drop index if exists admin_prospeccao_leads_ativos_idx;
--   -- colunas: só remover se nenhum lead estiver arquivado
--   alter table public.admin_prospeccao_leads drop column if exists mesclado_em,
--     drop column if exists arquivado_por, drop column if exists motivo_arquivamento,
--     drop column if exists arquivado_em;
-- =====================================================================

create schema if not exists backup_auditoria;
do $$ begin
  if to_regclass('backup_auditoria.prospeccao_leads_30_09') is null then
    execute 'create table backup_auditoria.prospeccao_leads_30_09 as table public.admin_prospeccao_leads';
  end if;
end $$;

alter table public.admin_prospeccao_leads
  add column if not exists arquivado_em timestamptz,
  add column if not exists motivo_arquivamento text,
  add column if not exists arquivado_por text,
  add column if not exists mesclado_em uuid references public.admin_prospeccao_leads(id) on delete set null;

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_leads_motivo_arquivamento_check') then
    alter table public.admin_prospeccao_leads add constraint admin_prospeccao_leads_motivo_arquivamento_check
      check (motivo_arquivamento is null or motivo_arquivamento in
        ('inatividade_automatica','sem_interesse','dados_invalidos','duplicado','mesclado','optout','outro'));
  end if;
end $$;

comment on column public.admin_prospeccao_leads.arquivado_em is 'Lead arquivado (fora da lista padrão e do funil). Nunca é apagado automaticamente. Continua valendo para deduplicação.';
comment on column public.admin_prospeccao_leads.arquivado_por is 'E-mail de quem arquivou, ou ''sistema'' para a rotina automática.';
comment on column public.admin_prospeccao_leads.mesclado_em is 'Quando motivo_arquivamento = mesclado: id do lead que absorveu este.';

create index if not exists admin_prospeccao_leads_ativos_idx
  on public.admin_prospeccao_leads (created_at desc) where arquivado_em is null;

create or replace function public.prospeccao_bloquear_delete_automatico()
returns trigger language plpgsql set search_path = public as $$
begin
  if current_user = 'service_role' or coalesce(auth.role(), '') = 'service_role' then
    raise exception 'Exclusão automática de leads bloqueada: use arquivamento (arquivado_em).'
      using errcode = '42501';
  end if;
  return old;
end $$;

drop trigger if exists prospeccao_leads_bloquear_delete_automatico on public.admin_prospeccao_leads;
create trigger prospeccao_leads_bloquear_delete_automatico
  before delete on public.admin_prospeccao_leads
  for each row execute function public.prospeccao_bloquear_delete_automatico();
