-- =====================================================================
-- Migration 003 — Normalização no banco (colunas *_norm + trigger)
-- Lead Capture Engine · 30/09/2026
--
-- Objetivo
--   Colunas normalizadas usadas por deduplicação, filtros e índices:
--     empresa_norm, telefone_norm, dominio, instagram_handle, cidade_norm, cnpj_norm
--   preenchidas por TRIGGER em todo insert/update — o dado fica normalizado
--   mesmo que entre por um caminho antigo (painel publicado antes, SQL direto).
--   As funções são a versão SQL de _lib/captacao/normalizar.js
--   (tests/captacaoNormalizar.test.js compara as duas no Postgres local).
--
-- Não altera nenhum dado original (telefone, site, instagram, cidade ficam
-- como foram digitados); só preenche colunas novas. UF só é preenchida
-- quando a cidade traz "- PE" ou está na lista da região (sem inventar).
--
-- Idempotente. Dependências: 002.
-- Rollback:
--   drop trigger if exists prospeccao_leads_normalizar on public.admin_prospeccao_leads;
--   drop function if exists public.prospeccao_leads_normalizar();
--   drop function if exists public.prospeccao_norm_texto(text), public.prospeccao_norm_empresa(text),
--     public.prospeccao_norm_telefone(text, text), public.prospeccao_norm_dominio(text),
--     public.prospeccao_norm_instagram(text), public.prospeccao_norm_cnpj(text),
--     public.prospeccao_norm_cidade(text), public.prospeccao_uf_da_cidade(text), public.prospeccao_ddd_da_cidade(text);
--   alter table public.admin_prospeccao_leads drop column if exists empresa_norm, drop column if exists telefone_norm,
--     drop column if exists dominio, drop column if exists instagram_handle, drop column if exists cidade_norm,
--     drop column if exists cnpj_norm;
-- =====================================================================

create or replace function public.prospeccao_norm_texto(p text) returns text
language sql immutable parallel safe set search_path = public as $$
  select nullif(trim(regexp_replace(
    translate(lower(coalesce(p, '')), 'áàâãäåéèêëíìîïóòôõöúùûüçñý', 'aaaaaaeeeeiiiiooooouuuucny'),
    '\s+', ' ', 'g')), '')
$$;

create or replace function public.prospeccao_norm_empresa(p text) returns text
language sql immutable parallel safe set search_path = public as $$
  select nullif(trim(regexp_replace(
    regexp_replace(public.prospeccao_norm_texto(p),
      '(\s*[-–,.]?\s*\m(ltda|me|epp|eireli|mei|s/?a|s\.a|sa|cia|limitada)\.?)+\s*$', '', 'i'),
    '[^a-z0-9]+', ' ', 'g')), '')
$$;

-- Região: mesma lista de taxonomia.js (CIDADES_REGIAO)
create or replace function public.prospeccao_cidades_regiao() returns table(cidade_norm text, uf text, ddd text)
language sql immutable parallel safe set search_path = public as $$
  values ('petrolina','PE','87'), ('juazeiro','BA','74'), ('lagoa grande','PE','87'),
         ('santa maria da boa vista','PE','87'), ('casa nova','BA','74'), ('sobradinho','BA','74'),
         ('curaca','BA','74'), ('oroco','PE','87'), ('dormentes','PE','87'), ('afranio','PE','87')
$$;

create or replace function public.prospeccao_norm_cidade(p text) returns text
language sql immutable parallel safe set search_path = public as $$
  select public.prospeccao_norm_texto(regexp_replace(coalesce(p, ''), '\s*[,/\-–]\s*[A-Za-z]{2}\s*$', ''))
$$;

create or replace function public.prospeccao_uf_da_cidade(p text) returns text
language sql immutable parallel safe set search_path = public as $$
  select coalesce(
    (select upper(m[1]) from regexp_match(coalesce(p, ''), '[,/\-–]\s*([A-Za-z]{2})\s*$') m
      where upper(m[1]) = any(array['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'])),
    (select r.uf from public.prospeccao_cidades_regiao() r where r.cidade_norm = public.prospeccao_norm_cidade(p)))
$$;

create or replace function public.prospeccao_ddd_da_cidade(p text) returns text
language sql immutable parallel safe set search_path = public as $$
  select coalesce((select r.ddd from public.prospeccao_cidades_regiao() r where r.cidade_norm = public.prospeccao_norm_cidade(p)), '87')
$$;

create or replace function public.prospeccao_norm_telefone(p text, p_ddd text default '87') returns text
language plpgsql immutable parallel safe set search_path = public as $$
declare d text; num text; ddd int;
begin
  d := regexp_replace(coalesce(p, ''), '\D', '', 'g');
  if d = '' then return null; end if;
  d := regexp_replace(d, '^0+', '');
  if length(d) in (12, 13) and left(d, 2) <> '55' then d := substr(d, 3); end if;
  if length(d) in (8, 9) then
    if p_ddd is null then return null; end if;
    d := p_ddd || d;
  end if;
  if length(d) in (10, 11) then d := '55' || d; end if;
  if length(d) not in (12, 13) or left(d, 2) <> '55' then return null; end if;
  ddd := substr(d, 3, 2)::int;
  if ddd < 11 or ddd > 99 then return null; end if;
  num := substr(d, 5);
  if length(num) = 9 and left(num, 1) <> '9' then return null; end if;
  if num ~ '^0+$' then return null; end if;
  return d;
end $$;

create or replace function public.prospeccao_norm_dominio(p text) returns text
language plpgsql immutable parallel safe set search_path = public as $$
declare s text; partes text[]; i int;
  genericos text[] := array['instagram.com','facebook.com','fb.com','wa.me','whatsapp.com','api.whatsapp.com','linktr.ee','linktree.com',
    'google.com','sites.google.com','g.page','goo.gl','maps.google.com','business.site','gmail.com','hotmail.com',
    'outlook.com','yahoo.com','yahoo.com.br','bol.com.br','uol.com.br','terra.com.br','icloud.com','live.com',
    'wixsite.com','wix.com','blogspot.com','wordpress.com','youtube.com','tiktok.com','twitter.com','x.com',
    'linkedin.com','bit.ly','ifood.com.br','beacons.ai','bio.link','taplink.cc','carrd.co','negocio.site'];
begin
  s := lower(trim(coalesce(p, '')));
  if s = '' then return null; end if;
  if position('@' in s) > 0 and position('/' in s) = 0 then s := split_part(s, '@', 2); end if;
  s := regexp_replace(s, '^[a-z]+://', '');
  s := split_part(split_part(split_part(split_part(s, '/', 1), '?', 1), '#', 1), ':', 1);
  s := regexp_replace(regexp_replace(s, '^www[0-9]?\.', ''), '\.$', '');
  if s !~ '^[a-z0-9-]+(\.[a-z0-9-]+)+$' then return null; end if;
  if s = any(genericos) then return null; end if;
  partes := string_to_array(s, '.');
  for i in 2 .. array_length(partes, 1) - 1 loop
    if array_to_string(partes[i:], '.') = any(genericos) then return null; end if;
  end loop;
  return s;
end $$;

create or replace function public.prospeccao_norm_instagram(p text) returns text
language plpgsql immutable parallel safe set search_path = public as $$
declare s text;
begin
  s := lower(trim(coalesce(p, '')));
  if s = '' then return null; end if;
  s := regexp_replace(regexp_replace(s, '^https?://', ''), '^(www\.|m\.)', '');
  if s like 'instagram.com/%' or s like 'instagr.am/%' then s := split_part(s, '/', 2);
  elsif position('/' in s) > 0 then return null; end if;
  s := regexp_replace(split_part(split_part(regexp_replace(s, '^@', ''), '?', 1), '#', 1), '/+$', '');
  if s !~ '^[a-z0-9._]{1,30}$' or s ~ '^\.+$'
     or s = any(array['p','reel','reels','explore','stories','accounts','direct','tv','about','legal','share']) then
    return null;
  end if;
  return s;
end $$;

create or replace function public.prospeccao_norm_cnpj(p text) returns text
language plpgsql immutable parallel safe set search_path = public as $$
declare d text; soma int; resto int; d1 int; d2 int; i int;
  p1 int[] := array[5,4,3,2,9,8,7,6,5,4,3,2]; p2 int[] := array[6,5,4,3,2,9,8,7,6,5,4,3,2];
begin
  d := regexp_replace(coalesce(p, ''), '\D', '', 'g');
  if length(d) <> 14 or d ~ '^(\d)\1{13}$' then return null; end if;
  soma := 0; for i in 1..12 loop soma := soma + substr(d, i, 1)::int * p1[i]; end loop;
  resto := soma % 11; d1 := case when resto < 2 then 0 else 11 - resto end;
  soma := 0; for i in 1..12 loop soma := soma + substr(d, i, 1)::int * p2[i]; end loop;
  soma := soma + d1 * p2[13];
  resto := soma % 11; d2 := case when resto < 2 then 0 else 11 - resto end;
  if right(d, 2) <> d1::text || d2::text then return null; end if;
  return d;
end $$;

alter table public.admin_prospeccao_leads
  add column if not exists empresa_norm text,
  add column if not exists telefone_norm text,
  add column if not exists dominio text,
  add column if not exists instagram_handle text,
  add column if not exists cidade_norm text,
  add column if not exists cnpj_norm text;

comment on column public.admin_prospeccao_leads.cnpj_norm is 'CNPJ só dígitos e com dígitos verificadores válidos (preenchido por trigger). cnpj guarda o que foi digitado.';

create or replace function public.prospeccao_leads_normalizar() returns trigger
language plpgsql set search_path = public as $$
begin
  new.empresa_norm := public.prospeccao_norm_empresa(new.empresa);
  new.cidade_norm := public.prospeccao_norm_cidade(new.cidade);
  if new.uf is null then new.uf := public.prospeccao_uf_da_cidade(new.cidade); end if;
  new.telefone_norm := public.prospeccao_norm_telefone(new.telefone, public.prospeccao_ddd_da_cidade(new.cidade));
  new.dominio := coalesce(public.prospeccao_norm_dominio(new.site), public.prospeccao_norm_dominio(new.email));
  new.instagram_handle := public.prospeccao_norm_instagram(new.instagram);
  new.cnpj_norm := public.prospeccao_norm_cnpj(new.cnpj);
  return new;
end $$;

drop trigger if exists prospeccao_leads_normalizar on public.admin_prospeccao_leads;
create trigger prospeccao_leads_normalizar
  before insert or update on public.admin_prospeccao_leads
  for each row execute function public.prospeccao_leads_normalizar();

-- Backfill: o update dispara o trigger.
update public.admin_prospeccao_leads set empresa = empresa where empresa_norm is null;
