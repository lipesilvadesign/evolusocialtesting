-- =====================================================================
-- Migration 007 — admin_prospeccao_oportunidades
-- Lead Capture Engine · 30/09/2026
--
-- Objetivo
--   Sinais viram oportunidades comerciais com EVIDÊNCIA obrigatória
--   (evidencia not null e não vazia): tipo, evidência, fonte, data,
--   confiança, confirmação humana. O sistema só cria as automáticas
--   (SEM_SITE, SITE_FORA_DO_AR, SITE_SEM_HTTPS, EMPRESA_NOVA,
--   BAIXA_PRESENCA_DIGITAL); as de julgamento (Instagram, Google, identidade,
--   expansão, site desatualizado) só por usuário.
--   Os booleanos sinal_* antigos continuam (compatibilidade por um ciclo) e
--   são espelhados aqui por trigger — nada é removido nesta migration.
--
-- Idempotente. Dependências: 001, 006.
-- Rollback: drop trigger if exists prospeccao_leads_sinais_para_oportunidades on public.admin_prospeccao_leads;
--           drop function if exists public.prospeccao_sinais_para_oportunidades();
--           drop table if exists public.admin_prospeccao_oportunidades;
-- =====================================================================

create table if not exists public.admin_prospeccao_oportunidades (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references public.admin_prospeccao_leads(id) on delete cascade,
  captura_id uuid references public.admin_prospeccao_captura(id) on delete set null,
  tipo text not null check (tipo in ('SEM_SITE','SITE_FORA_DO_AR','SITE_SEM_HTTPS','EMPRESA_NOVA','BAIXA_PRESENCA_DIGITAL',
    'INSTAGRAM_INATIVO','INSTAGRAM_DESORGANIZADO','GOOGLE_PERFIL_FRACO','SITE_DESATUALIZADO','IDENTIDADE_INCONSISTENTE','EXPANSAO')),
  evidencia text not null check (char_length(trim(evidencia)) between 3 and 1000),
  evidencia_url text,
  fonte text not null check (fonte = 'sistema' or fonte = 'usuario' or fonte like 'provider:%'),
  confianca text not null check (confianca in ('alta','media','baixa')),
  detectado_em timestamptz not null default now(),
  confirmado boolean not null default false,
  confirmado_por uuid,
  confirmado_em timestamptz,
  descartado boolean not null default false,
  criado_por uuid default auth.uid(),
  constraint admin_prospeccao_oportunidades_alvo check (lead_id is not null or captura_id is not null),
  -- Julgamento humano nunca nasce "do sistema"
  constraint admin_prospeccao_oportunidades_manual_por_usuario check (
    tipo not in ('INSTAGRAM_INATIVO','INSTAGRAM_DESORGANIZADO','GOOGLE_PERFIL_FRACO','SITE_DESATUALIZADO','IDENTIDADE_INCONSISTENTE','EXPANSAO')
    or fonte = 'usuario')
);
comment on table public.admin_prospeccao_oportunidades is 'Oportunidades comerciais por lead, sempre com evidência. Automáticas só as medidas pelo sistema; julgamento visual só por usuário.';

create unique index if not exists admin_prospeccao_oportunidades_ativa_key
  on public.admin_prospeccao_oportunidades (lead_id, tipo) where lead_id is not null and not descartado;
create index if not exists admin_prospeccao_oportunidades_tipo_idx on public.admin_prospeccao_oportunidades (tipo, lead_id) where not descartado;
create index if not exists admin_prospeccao_oportunidades_captura_idx on public.admin_prospeccao_oportunidades (captura_id) where captura_id is not null;

alter table public.admin_prospeccao_oportunidades enable row level security;
revoke all on public.admin_prospeccao_oportunidades from anon;
grant select, insert, update on public.admin_prospeccao_oportunidades to authenticated;
grant all on public.admin_prospeccao_oportunidades to service_role;

drop policy if exists oportunidades_select on public.admin_prospeccao_oportunidades;
drop policy if exists oportunidades_insert on public.admin_prospeccao_oportunidades;
drop policy if exists oportunidades_update on public.admin_prospeccao_oportunidades;
create policy oportunidades_select on public.admin_prospeccao_oportunidades for select to authenticated
  using ((lead_id is not null and admin_pode_ver_lead(lead_id))
      or (captura_id is not null and exists (select 1 from admin_prospeccao_captura c where c.id = captura_id and prospeccao_pode_ver_job(c.job_id))));
create policy oportunidades_insert on public.admin_prospeccao_oportunidades for insert to authenticated
  with check (prospeccao_pode_operar() and lead_id is not null and admin_pode_ver_lead(lead_id) and fonte = 'usuario');
create policy oportunidades_update on public.admin_prospeccao_oportunidades for update to authenticated
  using (prospeccao_pode_operar() and lead_id is not null and admin_pode_ver_lead(lead_id))
  with check (prospeccao_pode_operar() and lead_id is not null and admin_pode_ver_lead(lead_id));
-- Sem DELETE para authenticated: descartar = descartado = true (histórico preservado).

-- Espelho dos booleanos antigos → oportunidades (um ciclo de compatibilidade)
create or replace function public.prospeccao_sinais_para_oportunidades() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  pares text[][] := array[
    array['sinal_site_desatualizado','SITE_DESATUALIZADO'],
    array['sinal_instagram_desorganizado','INSTAGRAM_DESORGANIZADO'],
    array['sinal_gbp_fraco','GOOGLE_PERFIL_FRACO']];
  i int; ligado boolean; antes boolean;
begin
  for i in 1 .. array_length(pares, 1) loop
    execute format('select ($1).%I, ($2).%I', pares[i][1], pares[i][1]) into ligado, antes using new, (case when tg_op = 'UPDATE' then old else new end);
    if tg_op = 'INSERT' then antes := false; end if;
    if coalesce(ligado, false) and not coalesce(antes, false) then
      insert into admin_prospeccao_oportunidades (lead_id, tipo, evidencia, fonte, confianca, confirmado, confirmado_por, confirmado_em, criado_por)
      values (new.id, pares[i][2], 'Marcado manualmente no cadastro do lead.', 'usuario', 'media', true, auth.uid(), now(), auth.uid())
      on conflict do nothing;
    elsif not coalesce(ligado, false) and coalesce(antes, false) then
      update admin_prospeccao_oportunidades set descartado = true
       where lead_id = new.id and tipo = pares[i][2] and not descartado;
    end if;
  end loop;
  return null;
end $$;
drop trigger if exists prospeccao_leads_sinais_para_oportunidades on public.admin_prospeccao_leads;
create trigger prospeccao_leads_sinais_para_oportunidades
  after insert or update of sinal_site_desatualizado, sinal_instagram_desorganizado, sinal_gbp_fraco on public.admin_prospeccao_leads
  for each row execute function public.prospeccao_sinais_para_oportunidades();

-- Migração dos sinais já marcados (em 30/09: nenhum)
insert into public.admin_prospeccao_oportunidades (lead_id, tipo, evidencia, fonte, confianca, confirmado, confirmado_em)
select l.id, x.tipo, 'Marcado manualmente antes de 30/09/2026.', 'usuario', 'media', true, now()
  from public.admin_prospeccao_leads l
  cross join lateral (values
    (l.sinal_site_desatualizado, 'SITE_DESATUALIZADO'),
    (l.sinal_instagram_desorganizado, 'INSTAGRAM_DESORGANIZADO'),
    (l.sinal_gbp_fraco, 'GOOGLE_PERFIL_FRACO')) as x(ligado, tipo)
 where coalesce(x.ligado, false)
on conflict do nothing;
