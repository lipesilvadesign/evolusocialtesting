-- =====================================================================
-- Migration 009 — Deduplicação, aprovação, conversão inbound, arquivar/
--                 restaurar/mesclar, regras de permissão
-- Lead Capture Engine · 30/09/2026
--
-- Objetivo
--   RPCs SECURITY DEFINER (conferem papel e dono DENTRO do banco — nunca
--   confiar só no frontend nem só na Function):
--     prospeccao_dedup_candidatos(jsonb)    chaves → lead existente (inclui arquivados)
--     aprovar_captura(uuid[], ...)          captura → CRM, idempotente, 10 passos
--     prospeccao_converter_inbound(text, uuid)  consulta / contato do site → lead (idempotente)
--     prospeccao_arquivar(uuid[], text, text)   dono ou admin
--     prospeccao_restaurar(uuid[])          só admin
--     prospeccao_mesclar_leads(uuid, uuid)  só admin
--   Regras no banco:
--     - só admin restaura (tira arquivado_em) — trigger de guarda;
--     - exclusão definitiva: só admin e só de lead JÁ arquivado (política delete);
--     - opt-outs: leitura/escrita só admin e prospecção (antes: qualquer funcionário);
--     - convertido_cliente_em preenchido quando o status vira "cliente".
--   Contadores do job recalculados por trigger de instrução na captura.
--
-- Idempotente. Dependências: 004, 005, 006, 007, 008.
-- Rollback:
--   drop function if exists public.aprovar_captura(uuid[], uuid, text, text, boolean),
--     public.prospeccao_aprovar_um(uuid, uuid, text, text, boolean), public.prospeccao_dedup_candidatos(jsonb),
--     public.prospeccao_converter_inbound(text, uuid), public.prospeccao_arquivar(uuid[], text, text),
--     public.prospeccao_restaurar(uuid[]), public.prospeccao_mesclar_leads(uuid, uuid),
--     public.prospeccao_job_recontar(uuid), public.prospeccao_captura_recontar_jobs(), public.prospeccao_leads_guardas();
--   drop trigger if exists prospeccao_leads_guardas on public.admin_prospeccao_leads;
--   drop policy delete_leads ...; create policy delete_leads on public.admin_prospeccao_leads for delete using (admin_eh_admin());
--   políticas de opt-out originais: backup_auditoria.policies_30_09_lce.
--   alter table public.consultas_leads drop column if exists convertido_lead_id, ... (idem site_contatos)
-- =====================================================================

alter table public.admin_prospeccao_leads add column if not exists convertido_cliente_em timestamptz;
update public.admin_prospeccao_leads set convertido_cliente_em = coalesce(updated_at, created_at)
 where status = 'cliente' and convertido_cliente_em is null;

alter table public.consultas_leads
  add column if not exists convertido_lead_id uuid references public.admin_prospeccao_leads(id) on delete set null,
  add column if not exists convertido_em timestamptz,
  add column if not exists convertido_por uuid;
alter table public.site_contatos
  add column if not exists convertido_lead_id uuid references public.admin_prospeccao_leads(id) on delete set null,
  add column if not exists convertido_em timestamptz,
  add column if not exists convertido_por uuid;

-- ---------------------------------------------------------------------
-- Guardas do lead: restaurar só admin; data de conversão em cliente
-- ---------------------------------------------------------------------
create or replace function public.prospeccao_leads_guardas() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'UPDATE' and old.arquivado_em is not null and new.arquivado_em is null
     and not (admin_eh_admin() or prospeccao_eh_servico()) then
    raise exception 'Somente admin pode restaurar um lead arquivado.' using errcode = '42501';
  end if;
  if new.arquivado_em is not null and (tg_op = 'INSERT' or old.arquivado_em is null) then
    new.motivo_arquivamento := coalesce(new.motivo_arquivamento, 'outro');
  end if;
  if new.arquivado_em is null then
    new.motivo_arquivamento := null; new.arquivado_por := null;
  end if;
  if new.status = 'cliente' and (tg_op = 'INSERT' or old.status is distinct from 'cliente') then
    new.convertido_cliente_em := coalesce(new.convertido_cliente_em, now());
  end if;
  return new;
end $$;
drop trigger if exists prospeccao_leads_guardas on public.admin_prospeccao_leads;
create trigger prospeccao_leads_guardas before insert or update on public.admin_prospeccao_leads
  for each row execute function public.prospeccao_leads_guardas();

drop policy if exists delete_leads on public.admin_prospeccao_leads;
create policy delete_leads on public.admin_prospeccao_leads for delete
  using (admin_eh_admin() and arquivado_em is not null);

drop policy if exists funcionario_select_optouts on public.admin_prospeccao_optouts;
drop policy if exists funcionario_insert_optouts on public.admin_prospeccao_optouts;
drop policy if exists optouts_select on public.admin_prospeccao_optouts;
drop policy if exists optouts_insert on public.admin_prospeccao_optouts;
create policy optouts_select on public.admin_prospeccao_optouts for select to authenticated using (prospeccao_pode_operar());
create policy optouts_insert on public.admin_prospeccao_optouts for insert to authenticated with check (prospeccao_pode_operar());

-- ---------------------------------------------------------------------
-- Deduplicação: chaves normalizadas → lead existente (inclui arquivados)
-- Entrada: [{idx, cnpj, external_id, dominio, empresa_norm, telefone_norm,
--            instagram_handle, email, cidade_norm, endereco}]
-- Devolve a PRIMEIRA regra que casar (ordem da especificação).
-- Sem pg_trgm: similaridade = 1 só para nome normalizado idêntico (fallback).
-- Expõe só id/empresa/cidade do lead encontrado (o mínimo para a revisão).
-- ---------------------------------------------------------------------
create or replace function public.prospeccao_similaridade(a text, b text) returns real
language plpgsql stable set search_path = public, extensions as $$
begin
  if a is null or b is null then return 0; end if;
  if exists (select 1 from pg_extension where extname = 'pg_trgm') then
    return extensions.similarity(a, b);
  end if;
  return case when a = b then 1 else 0 end;
end $$;

create or replace function public.prospeccao_dedup_candidatos(p_registros jsonb)
returns table(idx int, lead_id uuid, empresa text, cidade text, match_tipo text, confianca int)
language plpgsql stable security definer set search_path = public, extensions as $$
declare r jsonb; l record; s real;
begin
  if not (prospeccao_pode_operar() or prospeccao_eh_servico()) then
    raise exception 'Sem permissão para deduplicar.' using errcode = '42501';
  end if;
  for r in select * from jsonb_array_elements(coalesce(p_registros, '[]'::jsonb)) loop
    idx := (r->>'idx')::int; lead_id := null;
    -- 1 CNPJ
    if lead_id is null and coalesce(r->>'cnpj', '') <> '' then
      select x.id, x.empresa, x.cidade into l from admin_prospeccao_leads x where x.cnpj_norm = r->>'cnpj' limit 1;
      if found then lead_id := l.id; empresa := l.empresa; cidade := l.cidade; match_tipo := 'cnpj'; confianca := 100; end if;
    end if;
    -- 2 external_id (mesma origem)
    if lead_id is null and coalesce(r->>'external_id', '') <> '' then
      select x.id, x.empresa, x.cidade into l from admin_prospeccao_leads x
       where x.origem_id = r->>'external_id' or (r->>'external_id') = any(x.origem_ids) limit 1;
      if found then lead_id := l.id; empresa := l.empresa; cidade := l.cidade; match_tipo := 'external_id'; confianca := 100; end if;
    end if;
    -- 3/4 domínio (+ nome compatível)
    if lead_id is null and coalesce(r->>'dominio', '') <> '' then
      select x.id, x.empresa, x.cidade, prospeccao_similaridade(x.empresa_norm, r->>'empresa_norm') as sim into l
        from admin_prospeccao_leads x where x.dominio = r->>'dominio'
       order by prospeccao_similaridade(x.empresa_norm, r->>'empresa_norm') desc limit 1;
      if found then
        lead_id := l.id; empresa := l.empresa; cidade := l.cidade;
        if l.sim >= 0.5 then match_tipo := 'dominio_nome'; confianca := 95; else match_tipo := 'dominio'; confianca := 80; end if;
      end if;
    end if;
    -- 5 telefone
    if lead_id is null and coalesce(r->>'telefone_norm', '') <> '' then
      select x.id, x.empresa, x.cidade into l from admin_prospeccao_leads x where x.telefone_norm = r->>'telefone_norm' limit 1;
      if found then lead_id := l.id; empresa := l.empresa; cidade := l.cidade; match_tipo := 'telefone'; confianca := 85; end if;
    end if;
    -- 6 Instagram
    if lead_id is null and coalesce(r->>'instagram_handle', '') <> '' then
      select x.id, x.empresa, x.cidade into l from admin_prospeccao_leads x where x.instagram_handle = r->>'instagram_handle' limit 1;
      if found then lead_id := l.id; empresa := l.empresa; cidade := l.cidade; match_tipo := 'instagram'; confianca := 85; end if;
    end if;
    -- 6b e-mail
    if lead_id is null and coalesce(r->>'email', '') <> '' then
      select x.id, x.empresa, x.cidade into l from admin_prospeccao_leads x where lower(x.email) = lower(r->>'email') limit 1;
      if found then lead_id := l.id; empresa := l.empresa; cidade := l.cidade; match_tipo := 'email'; confianca := 85; end if;
    end if;
    -- 7 nome + cidade (similaridade ≥ 0,80)
    if lead_id is null and coalesce(r->>'empresa_norm', '') <> '' and coalesce(r->>'cidade_norm', '') <> '' then
      select x.id, x.empresa, x.cidade, prospeccao_similaridade(x.empresa_norm, r->>'empresa_norm') as sim into l
        from admin_prospeccao_leads x
       where x.cidade_norm = r->>'cidade_norm'
         and (x.empresa_norm = r->>'empresa_norm' or prospeccao_similaridade(x.empresa_norm, r->>'empresa_norm') >= 0.8)
       order by 4 desc limit 1;
      if found then
        lead_id := l.id; empresa := l.empresa; cidade := l.cidade; match_tipo := 'nome_cidade';
        confianca := least(90, 70 + round((l.sim - 0.8) * 100)::int);
      end if;
    end if;
    -- 8 nome ≥ 0,60 + endereço ≥ 0,70 (sem coordenadas no CRM)
    if lead_id is null and coalesce(r->>'empresa_norm', '') <> '' and coalesce(r->>'endereco', '') <> '' then
      select x.id, x.empresa, x.cidade, prospeccao_similaridade(x.empresa_norm, r->>'empresa_norm') as sim into l
        from admin_prospeccao_leads x
       where x.endereco is not null
         and prospeccao_similaridade(x.empresa_norm, r->>'empresa_norm') >= 0.6
         and prospeccao_similaridade(prospeccao_norm_texto(x.endereco), prospeccao_norm_texto(r->>'endereco')) >= 0.7
       order by 4 desc limit 1;
      if found then
        lead_id := l.id; empresa := l.empresa; cidade := l.cidade; match_tipo := 'nome_endereco';
        confianca := least(75, 60 + round((l.sim - 0.6) * 40)::int);
      end if;
    end if;
    if lead_id is not null then return next; end if;
  end loop;
end $$;
revoke all on function public.prospeccao_dedup_candidatos(jsonb) from public, anon;
grant execute on function public.prospeccao_dedup_candidatos(jsonb) to authenticated, service_role;

-- ---------------------------------------------------------------------
-- Contadores do job (recalculados a partir da captura)
-- ---------------------------------------------------------------------
create or replace function public.prospeccao_job_recontar(p_job uuid) returns void
language plpgsql security definer set search_path = public as $$
declare c record;
begin
  select count(*) total,
         count(*) filter (where status <> 'erro') normalizados,
         count(*) filter (where status = 'duplicado') duplicados,
         count(*) filter (where status = 'possivel_duplicado') possiveis,
         count(*) filter (where status = 'descartado') descartados,
         count(*) filter (where status = 'bloqueado_optout') bloqueados,
         count(*) filter (where status = 'aprovado') aprovados,
         count(*) filter (where status in ('pendente','possivel_duplicado')) abertos
    into c from admin_prospeccao_captura where job_id = p_job;
  update admin_prospeccao_buscas set
    qtd_encontrados = c.total, qtd_normalizados = c.normalizados, qtd_duplicados = c.duplicados,
    qtd_possiveis_duplicados = c.possiveis, qtd_descartados = c.descartados, qtd_bloqueados = c.bloqueados,
    qtd_aprovados = c.aprovados, total_encontrado = c.total,
    status = case when status = 'em_revisao' and c.abertos = 0 then 'concluido' else status end,
    finalizado_em = case when status = 'em_revisao' and c.abertos = 0 then now() else finalizado_em end,
    updated_at = now()
   where id = p_job;
end $$;
revoke all on function public.prospeccao_job_recontar(uuid) from public, anon, authenticated;

create or replace function public.prospeccao_captura_recontar_jobs() returns trigger
language plpgsql security definer set search_path = public as $$
declare j uuid;
begin
  for j in select distinct job_id from novos loop perform prospeccao_job_recontar(j); end loop;
  return null;
end $$;
drop trigger if exists prospeccao_captura_recontar_ins on public.admin_prospeccao_captura;
drop trigger if exists prospeccao_captura_recontar_upd on public.admin_prospeccao_captura;
create trigger prospeccao_captura_recontar_ins after insert on public.admin_prospeccao_captura
  referencing new table as novos for each statement execute function public.prospeccao_captura_recontar_jobs();
create trigger prospeccao_captura_recontar_upd after update on public.admin_prospeccao_captura
  referencing new table as novos for each statement execute function public.prospeccao_captura_recontar_jobs();

-- ---------------------------------------------------------------------
-- Aprovação: captura → CRM (10 passos, idempotente)
-- ---------------------------------------------------------------------
create or replace function public.prospeccao_aprovar_um(p_captura uuid, p_responsavel uuid, p_prioridade text, p_campanha text, p_forcar_novo boolean)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  c admin_prospeccao_captura%rowtype; j admin_prospeccao_buscas%rowtype;
  v_uid uuid := auth.uid(); v_admin boolean := admin_eh_admin(); v_servico boolean := prospeccao_eh_servico();
  v_resp uuid; v_email text; v_lead uuid; v_fonte text; v_metodo text; v_camp text; m record; s jsonb;
begin
  -- 1 validar
  select * into c from admin_prospeccao_captura where id = p_captura for update;
  if not found then return jsonb_build_object('captura_id', p_captura, 'resultado', 'nao_encontrado'); end if;
  if not (v_servico or prospeccao_pode_ver_job(c.job_id)) then
    return jsonb_build_object('captura_id', p_captura, 'resultado', 'sem_permissao');
  end if;
  if c.lead_id is not null then
    return jsonb_build_object('captura_id', p_captura, 'resultado', 'ja_aprovado', 'lead_id', c.lead_id);
  end if;
  if c.status in ('descartado','erro','duplicado','bloqueado_optout') then
    return jsonb_build_object('captura_id', p_captura, 'resultado', 'ignorado', 'status', c.status);
  end if;
  if c.status = 'possivel_duplicado' and not coalesce(p_forcar_novo, false) then
    return jsonb_build_object('captura_id', p_captura, 'resultado', 'requer_confirmacao', 'match_lead_id', c.match_lead_id);
  end if;
  if coalesce(trim(c.empresa), '') = '' then
    update admin_prospeccao_captura set status = 'erro', erro = 'Sem nome de empresa' where id = c.id;
    return jsonb_build_object('captura_id', p_captura, 'resultado', 'erro', 'mensagem', 'Sem nome de empresa');
  end if;
  select * into j from admin_prospeccao_buscas where id = c.job_id;

  -- 6 responsável (checado antes de escrever)
  v_resp := coalesce(p_responsavel, v_uid, j.criado_por_id);
  if not v_admin and not v_servico and v_resp is distinct from v_uid then
    raise exception 'Usuário de prospecção só pode atribuir leads a si mesmo.' using errcode = '42501';
  end if;
  if v_resp is not null and not exists (select 1 from admin_funcionarios f where f.id = v_resp and f.ativo and f.role in ('admin','prospeccao')) then
    raise exception 'Responsável inválido (precisa ser admin ou prospecção ativo).' using errcode = '22023';
  end if;

  -- 2 normalizar: já feito pelo trigger da captura (colunas *_norm)
  -- 3 deduplicar de novo, dentro da transação (pode ter entrado um lead igual depois da prévia)
  select * into m from prospeccao_dedup_candidatos(jsonb_build_array(jsonb_build_object(
    'idx', 0, 'cnpj', c.cnpj, 'external_id', c.external_id, 'dominio', c.dominio, 'empresa_norm', c.empresa_norm)))
   where match_tipo in ('cnpj','external_id','dominio_nome') limit 1;
  if found then
    update admin_prospeccao_captura set status = 'duplicado', match_lead_id = m.lead_id, match_tipo = m.match_tipo,
      match_confianca = m.confianca, match_empresa = m.empresa, decidido_por = v_uid, decidido_em = now() where id = c.id;
    return jsonb_build_object('captura_id', p_captura, 'resultado', 'duplicado', 'match_lead_id', m.lead_id);
  end if;

  -- 4 opt-out
  if exists (select 1 from admin_prospeccao_optouts o
              where (c.email is not null and lower(o.email) = lower(c.email))
                 or (c.telefone_norm is not null and o.telefone_norm = c.telefone_norm)
                 or (c.external_id is not null and o.origem_id = c.external_id)) then
    update admin_prospeccao_captura set status = 'bloqueado_optout', decidido_por = v_uid, decidido_em = now() where id = c.id;
    return jsonb_build_object('captura_id', p_captura, 'resultado', 'bloqueado');
  end if;

  -- 7 origem
  v_fonte := case c.provider when 'geoapify' then 'geoapify' when 'overpass' then 'osm' when 'csv' then 'csv'
    when 'xlsx' then 'xlsx' when 'consultoria' then 'site' when 'site_contato' then 'site' else 'manual' end;
  v_metodo := coalesce(j.metodo_captacao, case when c.provider in ('consultoria','site_contato') then 'formulario'
    when c.provider in ('csv','xlsx') then 'importacao' when c.provider = 'manual' then 'prospeccao_manual' else 'pesquisa_local' end);
  v_camp := coalesce(nullif(p_campanha, ''), j.campanha);
  select f.email into v_email from admin_funcionarios f where f.id = v_uid;

  -- 5 score: calculado pelo trigger do lead no insert. 9 inserir no CRM
  insert into admin_prospeccao_leads (empresa, setor, subsetor, telefone, email, site, instagram, cnpj, endereco, cidade, uf,
      fonte, metodo_captacao, campanha, origem_id, origem_ids, status, prioridade, responsavel_id, criado_por, observacoes,
      convertido_de_tipo, convertido_de_id)
  values (c.empresa, c.setor, c.subsetor, c.telefone, c.email, c.site, c.instagram, c.cnpj, c.endereco, c.cidade, c.uf,
      v_fonte, v_metodo, v_camp, c.external_id, case when c.external_id is null then '{}' else array[c.external_id] end,
      'novo_lead', coalesce(nullif(p_prioridade, ''), 'media'), v_resp, coalesce(v_email, 'sistema'),
      format('Captado por %s (captação %s em %s).', c.provider, left(c.job_id::text, 8), to_char(j.created_at at time zone 'America/Recife', 'DD/MM/YYYY')),
      case c.provider when 'consultoria' then 'consulta' when 'site_contato' then 'site_contato' end,
      case when c.provider in ('consultoria','site_contato') then nullif(split_part(c.external_id, ':', 2), '')::uuid end)
  on conflict (origem_id) where origem_id is not null do nothing
  returning id into v_lead;
  if v_lead is null then
    select id into v_lead from admin_prospeccao_leads where origem_id = c.external_id;
    update admin_prospeccao_captura set status = 'duplicado', match_lead_id = v_lead, match_tipo = 'external_id',
      match_confianca = 100, decidido_por = v_uid, decidido_em = now() where id = c.id;
    return jsonb_build_object('captura_id', p_captura, 'resultado', 'duplicado', 'match_lead_id', v_lead);
  end if;

  -- oportunidades detectadas na captura (só as automáticas com evidência)
  for s in select * from jsonb_array_elements(coalesce(c.sinais, '[]'::jsonb)) loop
    if (s->>'tipo') in ('SEM_SITE','SITE_FORA_DO_AR','SITE_SEM_HTTPS','EMPRESA_NOVA','BAIXA_PRESENCA_DIGITAL')
       and coalesce(trim(s->>'evidencia'), '') <> '' then
      insert into admin_prospeccao_oportunidades (lead_id, captura_id, tipo, evidencia, evidencia_url, fonte, confianca, detectado_em, criado_por)
      values (v_lead, c.id, s->>'tipo', s->>'evidencia', s->>'evidencia_url', coalesce(s->>'fonte', 'sistema'),
              coalesce(s->>'confianca', 'media'), coalesce((s->>'detectado_em')::timestamptz, now()), v_uid)
      on conflict do nothing;
    end if;
  end loop;

  -- 8 atividade
  insert into admin_prospeccao_atividades (lead_id, tipo, descricao, criado_por)
  values (v_lead, 'nota', format('Lead aprovado a partir da captação (%s).', c.provider), coalesce(v_email, 'sistema'));

  -- 10 auditoria + marca a captura
  insert into admin_audit_log (actor_id, action, target_type, target_id, metadata)
  values (coalesce(v_email, 'sistema'), 'aprovar_captura', 'lead_prospeccao', v_lead::text,
          jsonb_build_object('captura_id', c.id, 'job_id', c.job_id, 'provider', c.provider));
  update admin_prospeccao_captura set status = 'aprovado', lead_id = v_lead, decidido_por = v_uid, decidido_em = now() where id = c.id;
  -- Inbound aprovado em lote pela prévia: marca a origem como convertida (idempotência da conversão)
  if c.provider = 'consultoria' then
    update consultas_leads set convertido_lead_id = v_lead, convertido_em = now(), convertido_por = v_uid
     where id = nullif(split_part(c.external_id, ':', 2), '')::uuid and convertido_lead_id is null;
  elsif c.provider = 'site_contato' then
    update site_contatos set convertido_lead_id = v_lead, convertido_em = now(), convertido_por = v_uid
     where id = nullif(split_part(c.external_id, ':', 2), '')::uuid and convertido_lead_id is null;
  end if;
  return jsonb_build_object('captura_id', p_captura, 'resultado', 'aprovado', 'lead_id', v_lead);
end $$;
revoke all on function public.prospeccao_aprovar_um(uuid, uuid, text, text, boolean) from public, anon, authenticated;

create or replace function public.aprovar_captura(p_ids uuid[], p_responsavel uuid default null, p_prioridade text default 'media',
    p_campanha text default null, p_forcar_novo boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare i uuid; out jsonb := '[]'::jsonb;
begin
  if not (prospeccao_pode_operar() or prospeccao_eh_servico()) then
    raise exception 'Sem permissão para aprovar.' using errcode = '42501';
  end if;
  if p_prioridade is not null and p_prioridade not in ('alta','media','baixa') then
    raise exception 'Prioridade inválida.' using errcode = '22023';
  end if;
  if p_campanha is not null and p_campanha <> '' and p_campanha !~ '^[a-z0-9_]{1,60}$' then
    raise exception 'Campanha inválida (use letras minúsculas, números e _).' using errcode = '22023';
  end if;
  if coalesce(array_length(p_ids, 1), 0) > 200 then
    raise exception 'No máximo 200 registros por aprovação.' using errcode = '22023';
  end if;
  foreach i in array coalesce(p_ids, '{}') loop
    out := out || prospeccao_aprovar_um(i, p_responsavel, p_prioridade, p_campanha, p_forcar_novo);
  end loop;
  return out;
end $$;
revoke all on function public.aprovar_captura(uuid[], uuid, text, text, boolean) from public, anon;
grant execute on function public.aprovar_captura(uuid[], uuid, text, text, boolean) to authenticated, service_role;

-- ---------------------------------------------------------------------
-- Inbound: consulta / contato do site → lead (idempotente)
-- consultas_leads: só admin (a tabela já é só-admin). site_contatos: admin e prospecção.
-- ---------------------------------------------------------------------
create or replace function public.prospeccao_converter_inbound(p_tipo text, p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare
  v_uid uuid := auth.uid(); v_email_func text; v_job uuid; v_cap uuid; v_lead uuid; r jsonb;
  v_nome text; v_email text; v_tel text; v_insta text; v_setor text; v_msg text; v_criado timestamptz; v_conv uuid;
  v_provider text; v_empresa text; v_tel_norm text; v_insta_h text; v_diag boolean := false;
begin
  if p_tipo = 'consulta' then
    if not admin_eh_admin() then raise exception 'Somente admin converte consultas.' using errcode = '42501'; end if;
    select nome, email, whatsapp, instagram, segmento, objetivo, created_at, convertido_lead_id, resultado_analise is not null
      into v_nome, v_email, v_tel, v_insta, v_setor, v_msg, v_criado, v_conv, v_diag
      from consultas_leads where id = p_id for update;
    v_provider := 'consultoria';
  elsif p_tipo = 'site_contato' then
    if not prospeccao_pode_operar() then raise exception 'Sem permissão para converter.' using errcode = '42501'; end if;
    select nome, email, whatsapp, null, servico, mensagem, created_at, convertido_lead_id
      into v_nome, v_email, v_tel, v_insta, v_setor, v_msg, v_criado, v_conv
      from site_contatos where id = p_id for update;
    v_provider := 'site_contato';
  else
    raise exception 'Tipo inválido.' using errcode = '22023';
  end if;
  if v_criado is null then raise exception 'Registro não encontrado.' using errcode = 'P0002'; end if;
  if v_conv is not null then return jsonb_build_object('resultado', 'ja_convertido', 'lead_id', v_conv); end if;

  select email into v_email_func from admin_funcionarios where id = v_uid;
  v_tel_norm := prospeccao_norm_telefone(v_tel);
  v_insta_h := prospeccao_norm_instagram(v_insta);

  -- Já existe lead com o mesmo telefone / e-mail / Instagram? Vincula, não cria outro.
  select id into v_lead from admin_prospeccao_leads
   where (v_tel_norm is not null and telefone_norm = v_tel_norm)
      or (v_email is not null and lower(email) = lower(v_email))
      or (v_insta_h is not null and instagram_handle = v_insta_h)
   order by arquivado_em nulls first, created_at limit 1;
  if v_lead is not null then
    insert into admin_prospeccao_atividades (lead_id, tipo, descricao, criado_por)
    values (v_lead, 'resposta_recebida',
      format('Nova solicitação pelo %s em %s.', case when p_tipo = 'consulta' then 'formulário da consultoria' else 'formulário de contato do site' end,
             to_char(v_criado at time zone 'America/Recife', 'DD/MM/YYYY HH24:MI')),
      coalesce(v_email_func, 'sistema'));
    r := jsonb_build_object('resultado', 'vinculado', 'lead_id', v_lead);
  else
    -- Passa pela captura (regra: nada entra no CRM sem captura + decisão humana; clicar "Converter" É a decisão)
    select id into v_job from admin_prospeccao_buscas
     where tipo = 'inbound' and criado_por_id is not distinct from v_uid
       and created_at >= date_trunc('day', now() at time zone 'America/Recife') at time zone 'America/Recife'
     order by created_at desc limit 1;
    if v_job is null then
      insert into admin_prospeccao_buscas (id, tipo, fonte, metodo_captacao, status, etapa, providers, criado_por, criado_por_id, iniciado_em, parametros)
      values (gen_random_uuid(), 'inbound', 'site', 'formulario', 'em_revisao', null, array[v_provider], coalesce(v_email_func, 'sistema'), v_uid, now(),
              jsonb_build_object('origem', 'conversao_manual'))
      returning id into v_job;
    end if;
    v_empresa := case when v_insta_h is not null then '@' || v_insta_h else coalesce(nullif(trim(v_nome), ''), 'Contato') || ' (a identificar)' end;
    insert into admin_prospeccao_captura (job_id, provider, external_id, payload, empresa, telefone, email, instagram, setor, subsetor, status)
    values (v_job, v_provider, (case when p_tipo = 'consulta' then 'consulta:' else 'site_contato:' end) || p_id::text,
            jsonb_build_object('nome', v_nome, 'segmento_ou_servico', v_setor),
            v_empresa, v_tel, v_email, v_insta, null, v_setor, 'pendente')
    on conflict (job_id, provider, external_id) do update set updated_at = now()
    returning id into v_cap;
    r := prospeccao_aprovar_um(v_cap, v_uid, 'alta', case when p_tipo = 'consulta' then 'consultoria_site' else 'contato_site' end, true);
    v_lead := (r->>'lead_id')::uuid;
    if v_lead is null then v_lead := (r->>'match_lead_id')::uuid; end if;
    if v_lead is not null and r->>'resultado' = 'aprovado' then
      insert into admin_prospeccao_contatos (lead_id, nome, email, whatsapp, principal, criado_por)
      values (v_lead, coalesce(nullif(trim(v_nome), ''), 'Contato'), v_email, v_tel, true, coalesce(v_email_func, 'sistema'));
      if coalesce(v_msg, '') <> '' then
        insert into admin_prospeccao_atividades (lead_id, tipo, descricao, criado_por)
        values (v_lead, 'resposta_recebida', left(format('Mensagem do formulário (%s): %s', to_char(v_criado at time zone 'America/Recife', 'DD/MM/YYYY'), v_msg), 2000), coalesce(v_email_func, 'sistema'));
      end if;
      if v_diag then
        insert into admin_prospeccao_atividades (lead_id, tipo, descricao, criado_por)
        values (v_lead, 'diagnostico_criado', 'Diagnóstico gerado na consultoria gratuita (ver aba Consultas).', coalesce(v_email_func, 'sistema'));
      end if;
    end if;
  end if;

  if v_lead is not null then
    if p_tipo = 'consulta' then
      update consultas_leads set convertido_lead_id = v_lead, convertido_em = now(), convertido_por = v_uid where id = p_id;
    else
      update site_contatos set convertido_lead_id = v_lead, convertido_em = now(), convertido_por = v_uid where id = p_id;
    end if;
    insert into admin_audit_log (actor_id, action, target_type, target_id, metadata)
    values (coalesce(v_email_func, 'sistema'), 'converter_inbound', 'lead_prospeccao', v_lead::text,
            jsonb_build_object('tipo', p_tipo, 'origem_id', p_id, 'resultado', r->>'resultado'));
  end if;
  return r;
end $$;
revoke all on function public.prospeccao_converter_inbound(text, uuid) from public, anon;
grant execute on function public.prospeccao_converter_inbound(text, uuid) to authenticated;

-- ---------------------------------------------------------------------
-- Arquivar (dono ou admin) / restaurar (só admin) / mesclar (só admin)
-- ---------------------------------------------------------------------
create or replace function public.prospeccao_arquivar(p_ids uuid[], p_motivo text, p_obs text default null)
returns int language plpgsql security definer set search_path = public as $$
declare n int; v_email text;
begin
  if not prospeccao_pode_operar() then raise exception 'Sem permissão.' using errcode = '42501'; end if;
  if p_motivo not in ('sem_interesse','dados_invalidos','duplicado','optout','outro') then
    raise exception 'Motivo inválido.' using errcode = '22023';
  end if;
  select email into v_email from admin_funcionarios where id = auth.uid();
  update admin_prospeccao_leads set arquivado_em = now(), motivo_arquivamento = p_motivo, arquivado_por = coalesce(v_email, 'desconhecido'),
         observacoes = case when coalesce(p_obs, '') <> '' then concat_ws(E'\n', observacoes, 'Arquivado: ' || left(p_obs, 500)) else observacoes end
   where id = any(p_ids) and arquivado_em is null
     and (admin_eh_admin() or responsavel_id = auth.uid());
  get diagnostics n = row_count;
  insert into admin_audit_log (actor_id, action, target_type, target_id, metadata)
  values (coalesce(v_email, 'desconhecido'), 'arquivar', 'lead_prospeccao', null, jsonb_build_object('ids', p_ids, 'motivo', p_motivo, 'arquivados', n));
  return n;
end $$;

create or replace function public.prospeccao_restaurar(p_ids uuid[])
returns int language plpgsql security definer set search_path = public as $$
declare n int; v_email text;
begin
  if not admin_eh_admin() then raise exception 'Somente admin pode restaurar.' using errcode = '42501'; end if;
  select email into v_email from admin_funcionarios where id = auth.uid();
  update admin_prospeccao_leads set arquivado_em = null where id = any(p_ids) and arquivado_em is not null and mesclado_em is null;
  get diagnostics n = row_count;
  insert into admin_audit_log (actor_id, action, target_type, target_id, metadata)
  values (coalesce(v_email, 'desconhecido'), 'restaurar', 'lead_prospeccao', null, jsonb_build_object('ids', p_ids, 'restaurados', n));
  return n;
end $$;

create or replace function public.prospeccao_mesclar_leads(p_manter uuid, p_absorver uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_email text; fk record; movidos jsonb := '{}'::jsonb; n int; a admin_prospeccao_leads%rowtype;
begin
  if not admin_eh_admin() then raise exception 'Somente admin pode mesclar leads.' using errcode = '42501'; end if;
  if p_manter = p_absorver then raise exception 'Escolha dois leads diferentes.' using errcode = '22023'; end if;
  select * into a from admin_prospeccao_leads where id = p_absorver for update;
  if not found or not exists (select 1 from admin_prospeccao_leads where id = p_manter) then
    raise exception 'Lead não encontrado.' using errcode = 'P0002';
  end if;
  select email into v_email from admin_funcionarios where id = auth.uid();
  -- Move tudo que aponta para o lead absorvido (atividades, contatos, briefings, diagnósticos, métricas...)
  for fk in
    select c.conrelid::regclass::text as tabela, att.attname as coluna
      from pg_constraint c join pg_attribute att on att.attrelid = c.conrelid and att.attnum = c.conkey[1]
     where c.contype = 'f' and c.confrelid = 'public.admin_prospeccao_leads'::regclass and array_length(c.conkey, 1) = 1
       and not (c.conrelid = 'public.admin_prospeccao_leads'::regclass)
       and c.conrelid::regclass::text not in ('admin_prospeccao_captura','admin_prospeccao_oportunidades','consultas_leads','site_contatos')
  loop
    begin
      execute format('update %s set %I = $1 where %I = $2', fk.tabela, fk.coluna, fk.coluna) using p_manter, p_absorver;
      get diagnostics n = row_count;
      movidos := movidos || jsonb_build_object(fk.tabela, n);
    exception when unique_violation then
      movidos := movidos || jsonb_build_object(fk.tabela, 'conflito: mantido no lead absorvido');
    end;
  end loop;
  update admin_prospeccao_oportunidades o set lead_id = p_manter
   where o.lead_id = p_absorver and not o.descartado
     and not exists (select 1 from admin_prospeccao_oportunidades x where x.lead_id = p_manter and x.tipo = o.tipo and not x.descartado);
  update admin_prospeccao_captura set lead_id = p_manter where lead_id = p_absorver;
  update consultas_leads set convertido_lead_id = p_manter where convertido_lead_id = p_absorver;
  update site_contatos set convertido_lead_id = p_manter where convertido_lead_id = p_absorver;
  -- Preenche só os campos VAZIOS do lead mantido
  update admin_prospeccao_leads m set
    setor = coalesce(m.setor, a.setor), subsetor = coalesce(m.subsetor, a.subsetor), telefone = coalesce(m.telefone, a.telefone),
    email = coalesce(m.email, a.email), site = coalesce(m.site, a.site), instagram = coalesce(m.instagram, a.instagram),
    cnpj = coalesce(m.cnpj, a.cnpj), endereco = coalesce(m.endereco, a.endereco), cidade = coalesce(m.cidade, a.cidade),
    uf = coalesce(m.uf, a.uf), campanha = coalesce(m.campanha, a.campanha),
    origem_ids = coalesce((select array_agg(distinct x) from unnest(m.origem_ids || a.origem_ids || a.origem_id) x where x is not null), '{}')
   where m.id = p_manter;
  update admin_prospeccao_leads set arquivado_em = now(), motivo_arquivamento = 'mesclado', arquivado_por = coalesce(v_email, 'desconhecido'),
         mesclado_em = p_manter where id = p_absorver;
  insert into admin_prospeccao_atividades (lead_id, tipo, descricao, criado_por)
  values (p_manter, 'nota', format('Lead "%s" mesclado neste (histórico movido).', a.empresa), coalesce(v_email, 'sistema'));
  insert into admin_audit_log (actor_id, action, target_type, target_id, metadata)
  values (coalesce(v_email, 'desconhecido'), 'mesclar', 'lead_prospeccao', p_manter::text, jsonb_build_object('absorvido', p_absorver, 'movidos', movidos));
  return jsonb_build_object('mantido', p_manter, 'absorvido', p_absorver, 'movidos', movidos);
end $$;

-- Mesclar captura → lead existente (preenche só vazios). Admin e dono do job;
-- prospecção só em lead próprio.
create or replace function public.prospeccao_mesclar_captura(p_captura uuid, p_lead uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c admin_prospeccao_captura%rowtype; v_email text;
begin
  select * into c from admin_prospeccao_captura where id = p_captura for update;
  if not found then raise exception 'Registro não encontrado.' using errcode = 'P0002'; end if;
  if not prospeccao_pode_ver_job(c.job_id) or not admin_pode_ver_lead(p_lead) or not prospeccao_pode_operar() then
    raise exception 'Sem permissão para mesclar.' using errcode = '42501';
  end if;
  if c.lead_id is not null then return jsonb_build_object('resultado', 'ja_aprovado', 'lead_id', c.lead_id); end if;
  select email into v_email from admin_funcionarios where id = auth.uid();
  update admin_prospeccao_leads m set
    telefone = coalesce(m.telefone, c.telefone), email = coalesce(m.email, c.email), site = coalesce(m.site, c.site),
    instagram = coalesce(m.instagram, c.instagram), cnpj = coalesce(m.cnpj, c.cnpj), endereco = coalesce(m.endereco, c.endereco),
    cidade = coalesce(m.cidade, c.cidade), uf = coalesce(m.uf, c.uf), setor = coalesce(m.setor, c.setor), subsetor = coalesce(m.subsetor, c.subsetor),
    origem_ids = case when c.external_id is null or c.external_id = any(m.origem_ids) then m.origem_ids else m.origem_ids || c.external_id end
   where m.id = p_lead;
  update admin_prospeccao_captura set status = 'duplicado', match_lead_id = p_lead, match_tipo = coalesce(match_tipo, 'mesmo_job'),
         decidido_por = auth.uid(), decidido_em = now() where id = c.id;
  insert into admin_prospeccao_atividades (lead_id, tipo, descricao, criado_por)
  values (p_lead, 'nota', format('Dados da captação (%s) mesclados neste lead (só campos vazios).', c.provider), coalesce(v_email, 'sistema'));
  insert into admin_audit_log (actor_id, action, target_type, target_id, metadata)
  values (coalesce(v_email, 'desconhecido'), 'mesclar_captura', 'lead_prospeccao', p_lead::text, jsonb_build_object('captura_id', c.id));
  return jsonb_build_object('resultado', 'mesclado', 'lead_id', p_lead);
end $$;

revoke all on function public.prospeccao_arquivar(uuid[], text, text) from public, anon;
revoke all on function public.prospeccao_restaurar(uuid[]) from public, anon;
revoke all on function public.prospeccao_mesclar_leads(uuid, uuid) from public, anon;
revoke all on function public.prospeccao_mesclar_captura(uuid, uuid) from public, anon;
grant execute on function public.prospeccao_arquivar(uuid[], text, text) to authenticated;
grant execute on function public.prospeccao_restaurar(uuid[]) to authenticated;
grant execute on function public.prospeccao_mesclar_leads(uuid, uuid) to authenticated;
grant execute on function public.prospeccao_mesclar_captura(uuid, uuid) to authenticated;

-- ---------------------------------------------------------------------
-- Limite diário de e-mail: contagem GLOBAL (todos os responsáveis) desde a
-- meia-noite de America/Recife. Antes: contava só os leads visíveis ao
-- usuário (RLS) e a partir da meia-noite UTC (21h no Recife).
-- ---------------------------------------------------------------------
create or replace function public.prospeccao_emails_enviados_hoje() returns int
language sql stable security definer set search_path = public as $$
  select case when prospeccao_pode_operar() or prospeccao_eh_servico() then
    (select count(*)::int from admin_prospeccao_leads
      where email_enviado_em >= (date_trunc('day', now() at time zone 'America/Recife') at time zone 'America/Recife'))
  else null end
$$;
revoke all on function public.prospeccao_emails_enviados_hoje() from public, anon;
grant execute on function public.prospeccao_emails_enviados_hoje() to authenticated, service_role;

-- ---------------------------------------------------------------------
-- Endurecimento (linter do Supabase, 30/09): funções de TRIGGER e helpers
-- de permissão não precisam ser chamáveis pela API (/rest/v1/rpc/...).
-- As RPCs de negócio continuam liberadas a authenticated (checam papel dentro).
-- ---------------------------------------------------------------------
revoke execute on function public.prospeccao_leads_guardas(), public.prospeccao_leads_score(), public.prospeccao_tocar_lead(),
  public.prospeccao_optouts_tocar_leads(), public.prospeccao_sinais_para_oportunidades(), public.prospeccao_captura_recontar_jobs(),
  public.prospeccao_leads_normalizar(), public.prospeccao_captura_normalizar(), public.prospeccao_captura_score(),
  public.prospeccao_optouts_normalizar(), public.prospeccao_bloquear_delete_automatico()
  from public, anon, authenticated;
revoke execute on function public.prospeccao_pode_operar(), public.prospeccao_pode_ver_job(uuid) from public, anon;
grant execute on function public.prospeccao_pode_operar(), public.prospeccao_pode_ver_job(uuid) to authenticated, service_role;
