-- =====================================================================
-- Migration 008 — Score e temperatura calculados NO BANCO
-- Lead Capture Engine · 30/09/2026
--
-- Objetivo
--   O score deixa de ser calculado no navegador. Um trigger BEFORE INSERT/
--   UPDATE recalcula score, score_motivos, score_calculado_em e temperatura
--   em TODA escrita — qualquer valor de score enviado pelo navegador é
--   ignorado (sobrescrito). Assim nenhum caminho (painel antigo, API direta
--   com a chave pública, rotina) consegue gravar um score arbitrário, sem
--   precisar de REVOKE de coluna (que quebraria o painel publicado antes,
--   que ainda manda "score" no PATCH).
--   Mudanças em oportunidades, contatos, atividades e opt-outs "tocam" o
--   lead para recalcular.
--
-- Modelo (um score só, 0–100, componentes em score_motivos):
--   Encaixe (teto 35): setor estratégico ou sinal de segmento +15;
--                      cidade da região (Vale do São Francisco) +10; porte médio/grande +10
--   Oportunidade (teto 40): sem site +20; site fora do ar +15 (se tem site);
--                      max(site sem HTTPS +8, site desatualizado +10);
--                      Instagram desorganizado/inativo +10; perfil Google fraco +10;
--                      empresa nova/expansão +10
--   Contatabilidade (teto 15): telefone válido +5; e-mail +5; contato principal +5
--   Intenção (teto 30): veio por formulário +20; respondeu/interessado +10;
--                      reunião marcada/proposta/cliente +20
--   Bloqueio: opt-out, "não contatar" ou arquivado → 0 (motivo "bloqueado")
--   Faixas: >90 Prioritário · 61–90 Prospectar · 31–60 Nutrir · ≤30 Aguardar
--
-- Temperatura (nunca por julgamento; só datas e eventos objetivos). Só contam
-- atividades VINDAS DO LEAD: resposta_recebida, reuniao_marcada,
-- reuniao_realizada, proposta_enviada, negociacao. whatsapp_enviado /
-- email_enviado (ação da equipe) NÃO aquecem.
--   quente: interação do lead ≤ 14 dias; ou status interessado/reunião/proposta
--           com atividade ≤ 14 dias; ou entrada por formulário ≤ 7 dias
--   morno:  interação do lead 15–45 dias; ou formulário ≤ 30 dias; ou status
--           respondeu com atividade ≤ 30 dias
--   frio:   o resto
--   nulo:   cliente, não convertido ou arquivado
-- Parâmetros iguais a taxonomia.js (TEMPERATURA) — teste de paridade.
--
-- Idempotente. Dependências: 002, 003, 004, 007.
-- Backup: score/score_motivos antigos estão em backup_auditoria.prospeccao_leads_30_09.
-- Rollback:
--   drop trigger if exists prospeccao_leads_score on public.admin_prospeccao_leads;
--   drop trigger if exists prospeccao_captura_score on public.admin_prospeccao_captura;
--   drop trigger if exists prospeccao_tocar_lead on public.admin_prospeccao_oportunidades; (idem contatos, atividades)
--   drop trigger if exists prospeccao_optouts_tocar_leads on public.admin_prospeccao_optouts;
--   drop function if exists public.prospeccao_leads_score(), public.prospeccao_captura_score(),
--     public.prospeccao_tocar_lead(), public.prospeccao_optouts_tocar_leads(),
--     public.prospeccao_score_calcular(jsonb), public.prospeccao_recalcular_todos(),
--     public.prospeccao_setores_estrategicos();
--   update public.admin_prospeccao_leads l set score = b.score, score_motivos = b.score_motivos
--     from backup_auditoria.prospeccao_leads_30_09 b where b.id = l.id;
-- =====================================================================

-- [paridade] taxonomia.js → SETORES[].estrategico
create or replace function public.prospeccao_setores_estrategicos() returns text[]
language sql immutable parallel safe set search_path = public as $$
  select array['Arquitetura','Construção','Imobiliário','Saúde','Beleza e estética','Agronegócio','Coworking']
$$;

/**
 * Função pura: entradas (jsonb) → { score, motivos[] }.
 * Entradas: setor, sinal_segmento, cidade_norm, porte, sem_site, oportunidades (text[]),
 *           tem_telefone, tem_email, tem_contato_principal, inbound, status, bloqueado, motivo_bloqueio
 */
create or replace function public.prospeccao_score_calcular(e jsonb) returns jsonb
language plpgsql immutable parallel safe set search_path = public as $$
declare
  ops text[] := coalesce(array(select jsonb_array_elements_text(coalesce(e->'oportunidades', '[]'::jsonb))), '{}');
  mot jsonb := '[]'::jsonb;
  enc int := 0; opo int := 0; con int := 0; inte int := 0; tmp int;
  st text := coalesce(e->>'status', 'novo_lead');
begin
  if coalesce((e->>'bloqueado')::boolean, false) then
    return jsonb_build_object('score', 0, 'motivos', jsonb_build_array(jsonb_build_object(
      'componente', 'bloqueio', 'label', coalesce(e->>'motivo_bloqueio', 'Bloqueado para contato'), 'pontos', 0)));
  end if;

  -- Encaixe
  if (e->>'setor') = any(public.prospeccao_setores_estrategicos()) or coalesce((e->>'sinal_segmento')::boolean, false) then
    enc := enc + 15; mot := mot || jsonb_build_object('componente','encaixe','label','Setor estratégico','pontos',15);
  end if;
  if exists (select 1 from public.prospeccao_cidades_regiao() r where r.cidade_norm = e->>'cidade_norm') then
    enc := enc + 10; mot := mot || jsonb_build_object('componente','encaixe','label','Cidade do Vale do São Francisco','pontos',10);
  end if;
  if coalesce((e->>'porte')::boolean, false) then
    enc := enc + 10; mot := mot || jsonb_build_object('componente','encaixe','label','Porte médio/grande','pontos',10);
  end if;
  enc := least(enc, 35);

  -- Oportunidade
  if coalesce((e->>'sem_site')::boolean, false) then
    opo := opo + 20; mot := mot || jsonb_build_object('componente','oportunidade','label','Sem site','pontos',20);
  elsif 'SITE_FORA_DO_AR' = any(ops) then
    opo := opo + 15; mot := mot || jsonb_build_object('componente','oportunidade','label','Site fora do ar','pontos',15);
  end if;
  tmp := greatest(case when 'SITE_SEM_HTTPS' = any(ops) then 8 else 0 end, case when 'SITE_DESATUALIZADO' = any(ops) then 10 else 0 end);
  if tmp > 0 then
    opo := opo + tmp; mot := mot || jsonb_build_object('componente','oportunidade',
      'label', case when tmp = 10 then 'Site desatualizado' else 'Site sem HTTPS' end, 'pontos', tmp);
  end if;
  if 'INSTAGRAM_DESORGANIZADO' = any(ops) or 'INSTAGRAM_INATIVO' = any(ops) then
    opo := opo + 10; mot := mot || jsonb_build_object('componente','oportunidade','label','Instagram desorganizado ou inativo','pontos',10);
  end if;
  if 'GOOGLE_PERFIL_FRACO' = any(ops) then
    opo := opo + 10; mot := mot || jsonb_build_object('componente','oportunidade','label','Perfil do Google fraco','pontos',10);
  end if;
  if 'EMPRESA_NOVA' = any(ops) or 'EXPANSAO' = any(ops) then
    opo := opo + 10; mot := mot || jsonb_build_object('componente','oportunidade','label','Empresa nova ou em expansão','pontos',10);
  end if;
  opo := least(opo, 40);

  -- Contatabilidade
  if coalesce((e->>'tem_telefone')::boolean, false) then
    con := con + 5; mot := mot || jsonb_build_object('componente','contato','label','Telefone válido','pontos',5);
  end if;
  if coalesce((e->>'tem_email')::boolean, false) then
    con := con + 5; mot := mot || jsonb_build_object('componente','contato','label','E-mail','pontos',5);
  end if;
  if coalesce((e->>'tem_contato_principal')::boolean, false) then
    con := con + 5; mot := mot || jsonb_build_object('componente','contato','label','Contato decisor cadastrado','pontos',5);
  end if;
  con := least(con, 15);

  -- Intenção
  if coalesce((e->>'inbound')::boolean, false) then
    inte := inte + 20; mot := mot || jsonb_build_object('componente','intencao','label','Pediu contato pelo site/consultoria','pontos',20);
  end if;
  if st in ('reuniao_marcada','proposta_enviada','cliente') then
    inte := inte + 20; mot := mot || jsonb_build_object('componente','intencao','label','Reunião ou proposta','pontos',20);
  elsif st in ('respondeu','interessado') then
    inte := inte + 10; mot := mot || jsonb_build_object('componente','intencao','label',
      case when st = 'interessado' then 'Demonstrou interesse' else 'Respondeu ao contato' end,'pontos',10);
  end if;
  inte := least(inte, 30);

  return jsonb_build_object('score', least(enc + opo + con + inte, 100), 'motivos', mot);
end $$;

create or replace function public.prospeccao_leads_score() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  ops text[]; bloqueado boolean := false; motivo text; r jsonb;
  ultima_do_lead timestamptz; agora timestamptz := now(); inbound boolean;
begin
  -- Oportunidades que contam: não descartadas e (confirmadas ou medidas com confiança alta)
  select coalesce(array_agg(distinct tipo), '{}') into ops
    from admin_prospeccao_oportunidades
   where lead_id = new.id and not descartado and (confirmado or confianca = 'alta');
  -- Compatibilidade: booleanos antigos ainda valem
  if coalesce(new.sinal_site_desatualizado, false) then ops := ops || 'SITE_DESATUALIZADO'; end if;
  if coalesce(new.sinal_instagram_desorganizado, false) then ops := ops || 'INSTAGRAM_DESORGANIZADO'; end if;
  if coalesce(new.sinal_gbp_fraco, false) then ops := ops || 'GOOGLE_PERFIL_FRACO'; end if;

  if new.arquivado_em is not null then bloqueado := true; motivo := 'Lead arquivado';
  elsif new.status_contato in ('optout_solicitado','nao_contatar') then bloqueado := true; motivo := 'Pediu para não ser contatado';
  elsif exists (select 1 from admin_prospeccao_optouts o
                 where (new.email is not null and lower(o.email) = lower(new.email))
                    or (new.telefone_norm is not null and o.telefone_norm = new.telefone_norm)
                    or (new.origem_id is not null and o.origem_id = new.origem_id)) then
    bloqueado := true; motivo := 'Está na lista de opt-out';
  end if;

  inbound := coalesce(new.metodo_captacao = 'formulario', false);
  r := public.prospeccao_score_calcular(jsonb_build_object(
    'setor', new.setor, 'sinal_segmento', coalesce(new.sinal_segmento_alto_potencial, false),
    'cidade_norm', new.cidade_norm, 'porte', coalesce(new.sinal_porte_medio_grande, false),
    'sem_site', new.site is null or trim(new.site) = '',
    'oportunidades', to_jsonb(ops),
    'tem_telefone', new.telefone_norm is not null,
    'tem_email', new.email is not null and trim(new.email) <> '',
    'tem_contato_principal', exists (select 1 from admin_prospeccao_contatos c where c.lead_id = new.id and c.principal),
    'inbound', inbound, 'status', new.status, 'bloqueado', bloqueado, 'motivo_bloqueio', motivo));
  new.score := (r->>'score')::int;
  new.score_motivos := r->'motivos';
  new.score_calculado_em := agora;

  -- Temperatura
  if new.arquivado_em is not null or new.status in ('cliente','nao_convertido') then
    new.temperatura := null;
  else
    select max(a.data) into ultima_do_lead from admin_prospeccao_atividades a
     where a.lead_id = new.id
       and a.tipo in ('resposta_recebida','reuniao_marcada','reuniao_realizada','proposta_enviada','negociacao');
    new.temperatura := case
      when ultima_do_lead >= agora - interval '14 days'
        or (new.status in ('interessado','reuniao_marcada','proposta_enviada') and new.ultima_atividade_em >= agora - interval '14 days')
        or (inbound and coalesce(new.created_at, agora) >= agora - interval '7 days') then 'quente'
      when ultima_do_lead >= agora - interval '45 days'
        or (inbound and coalesce(new.created_at, agora) >= agora - interval '30 days')
        or (new.status = 'respondeu' and new.ultima_atividade_em >= agora - interval '30 days') then 'morno'
      else 'frio' end;
  end if;
  return new;
end $$;

drop trigger if exists prospeccao_leads_score on public.admin_prospeccao_leads;
create trigger prospeccao_leads_score before insert or update on public.admin_prospeccao_leads
  for each row execute function public.prospeccao_leads_score();

-- Score previsto na captura (mesma função pura; sem histórico de atividades)
create or replace function public.prospeccao_captura_score() returns trigger
language plpgsql set search_path = public as $$
declare ops text[]; r jsonb;
begin
  select coalesce(array_agg(distinct s->>'tipo'), '{}') into ops
    from jsonb_array_elements(coalesce(new.sinais, '[]'::jsonb)) s
   where coalesce(s->>'confianca', '') = 'alta' or coalesce((s->>'confirmado')::boolean, false);
  r := public.prospeccao_score_calcular(jsonb_build_object(
    'setor', new.setor, 'sinal_segmento', false, 'cidade_norm', new.cidade_norm, 'porte', false,
    'sem_site', new.site is null, 'oportunidades', to_jsonb(ops),
    'tem_telefone', new.telefone_norm is not null, 'tem_email', new.email is not null,
    'tem_contato_principal', false, 'inbound', new.provider in ('consultoria','site_contato'),
    'status', 'novo_lead', 'bloqueado', new.status = 'bloqueado_optout', 'motivo_bloqueio', 'Está na lista de opt-out'));
  new.score_previsto := (r->>'score')::int;
  new.score_motivos := r->'motivos';
  return new;
end $$;
drop trigger if exists prospeccao_captura_score on public.admin_prospeccao_captura;
create trigger prospeccao_captura_score before insert or update on public.admin_prospeccao_captura
  for each row execute function public.prospeccao_captura_score();

-- "Tocar" o lead quando algo que entra no cálculo muda
create or replace function public.prospeccao_tocar_lead() returns trigger
language plpgsql security definer set search_path = public as $$
declare alvo uuid;
begin
  alvo := case when tg_op = 'DELETE' then old.lead_id else new.lead_id end;
  if alvo is not null then
    update admin_prospeccao_leads set score_calculado_em = now() where id = alvo;
  end if;
  if tg_op = 'UPDATE' and old.lead_id is distinct from new.lead_id and old.lead_id is not null then
    update admin_prospeccao_leads set score_calculado_em = now() where id = old.lead_id;
  end if;
  return null;
end $$;
drop trigger if exists prospeccao_tocar_lead on public.admin_prospeccao_oportunidades;
create trigger prospeccao_tocar_lead after insert or update or delete on public.admin_prospeccao_oportunidades
  for each row execute function public.prospeccao_tocar_lead();
drop trigger if exists prospeccao_tocar_lead on public.admin_prospeccao_contatos;
create trigger prospeccao_tocar_lead after insert or update or delete on public.admin_prospeccao_contatos
  for each row execute function public.prospeccao_tocar_lead();
drop trigger if exists prospeccao_tocar_lead on public.admin_prospeccao_atividades;
create trigger prospeccao_tocar_lead after insert or update or delete on public.admin_prospeccao_atividades
  for each row execute function public.prospeccao_tocar_lead();

create or replace function public.prospeccao_optouts_tocar_leads() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update admin_prospeccao_leads l set score_calculado_em = now()
   where (new.email is not null and lower(l.email) = lower(new.email))
      or (new.telefone_norm is not null and l.telefone_norm = new.telefone_norm)
      or (new.origem_id is not null and l.origem_id = new.origem_id);
  return null;
end $$;
drop trigger if exists prospeccao_optouts_tocar_leads on public.admin_prospeccao_optouts;
create trigger prospeccao_optouts_tocar_leads after insert or update on public.admin_prospeccao_optouts
  for each row execute function public.prospeccao_optouts_tocar_leads();

-- Recálculo em massa (temperatura depende do relógio): rotina diária / botão admin.
create or replace function public.prospeccao_recalcular_todos() returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not (admin_eh_admin() or prospeccao_eh_servico()) then
    raise exception 'Somente admin pode recalcular todos os scores.' using errcode = '42501';
  end if;
  update admin_prospeccao_leads set score_calculado_em = now()
   where arquivado_em is null or temperatura is not null;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.prospeccao_recalcular_todos() from public, anon;
grant execute on function public.prospeccao_recalcular_todos() to authenticated, service_role;

-- Cálculo inicial
update public.admin_prospeccao_leads set score_calculado_em = now();
