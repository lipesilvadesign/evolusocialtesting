-- =====================================================================
-- Migration 006 — admin_prospeccao_captura (CAPTURE RAW)
-- Lead Capture Engine · 30/09/2026
--
-- Objetivo
--   Área de preparação: todo resultado de captação (pesquisa, importação,
--   formulário) fica aqui, normalizado e deduplicado, até uma PESSOA decidir
--   (aprovar / descartar / marcar duplicado / mesclar). Nada entra no CRM
--   (admin_prospeccao_leads) sem passar por aqui.
--   jsonb só para o que não é filtrado nem indexado: payload (resposta
--   original do provider, para auditoria/reprocessamento), sinais,
--   score_motivos, avisos. O resto são colunas normais.
--
-- Idempotência: unique (job_id, provider, external_id) — reprocessar o mesmo
-- job não duplica. lead_id preenchido = já aprovado (aprovar de novo não
-- cria outro lead).
--
-- Idempotente. Dependências: 003 (funções de normalização), 005.
-- Rollback: drop table if exists public.admin_prospeccao_captura cascade;
--           drop function if exists public.prospeccao_captura_normalizar();
-- =====================================================================

create table if not exists public.admin_prospeccao_captura (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.admin_prospeccao_buscas(id) on delete cascade,
  provider text not null check (provider in ('geoapify','overpass','csv','xlsx','consultoria','site_contato','manual')),
  external_id text,
  payload jsonb,
  empresa text not null check (char_length(empresa) between 1 and 300),
  empresa_norm text,
  telefone text,
  telefone_norm text,
  email text,
  site text,
  dominio text,
  instagram text,
  instagram_handle text,
  cnpj text,
  endereco text,
  cidade text,
  cidade_norm text,
  uf text check (uf is null or uf ~ '^[A-Z]{2}$'),
  lat double precision,
  lon double precision,
  setor text,
  subsetor text,
  categoria_origem text,
  sinais jsonb not null default '[]'::jsonb,
  score_previsto int,
  score_motivos jsonb,
  avisos jsonb not null default '[]'::jsonb,
  status text not null default 'pendente'
    check (status in ('pendente','duplicado','possivel_duplicado','descartado','bloqueado_optout','aprovado','erro')),
  match_lead_id uuid references public.admin_prospeccao_leads(id) on delete set null,
  match_tipo text check (match_tipo is null or match_tipo in ('cnpj','external_id','dominio_nome','dominio','telefone','instagram','email','nome_cidade','nome_endereco','mesmo_job')),
  match_confianca smallint check (match_confianca is null or match_confianca between 0 and 100),
  match_captura_id uuid references public.admin_prospeccao_captura(id) on delete set null,
  match_empresa text,
  motivo_descarte text,
  erro text,
  lead_id uuid references public.admin_prospeccao_leads(id) on delete set null,
  decidido_por uuid,
  decidido_em timestamptz,
  site_verificado_em timestamptz,
  site_http_status int,
  site_https boolean,
  created_at timestamptz not null default now(),
  updated_at timestamptz,
  constraint admin_prospeccao_captura_descarte_motivo check (status <> 'descartado' or motivo_descarte is not null)
);

comment on table public.admin_prospeccao_captura is 'Capture raw do Lead Capture Engine: resultados normalizados aguardando decisão humana antes do CRM.';

-- Índice único SEM predicado (NULLs continuam distintos): assim o upsert do
-- PostgREST (on_conflict=job_id,provider,external_id) consegue usá-lo.
create unique index if not exists admin_prospeccao_captura_idem_key on public.admin_prospeccao_captura (job_id, provider, external_id);
create index if not exists admin_prospeccao_captura_job_status_idx on public.admin_prospeccao_captura (job_id, status, score_previsto desc nulls last, id);
create index if not exists admin_prospeccao_captura_external_idx on public.admin_prospeccao_captura (external_id) where external_id is not null;
create index if not exists admin_prospeccao_captura_tel_idx on public.admin_prospeccao_captura (telefone_norm) where telefone_norm is not null;
create index if not exists admin_prospeccao_captura_dominio_idx on public.admin_prospeccao_captura (dominio) where dominio is not null;
create index if not exists admin_prospeccao_captura_cnpj_idx on public.admin_prospeccao_captura (cnpj) where cnpj is not null;
create index if not exists admin_prospeccao_captura_lead_idx on public.admin_prospeccao_captura (lead_id) where lead_id is not null;
do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_trgm') then
    execute 'create index if not exists admin_prospeccao_captura_empresa_trgm_idx on public.admin_prospeccao_captura using gin (empresa_norm extensions.gin_trgm_ops)';
  end if;
end $$;

-- Mesmas regras de normalização do CRM (defesa em profundidade: o pipeline
-- já manda normalizado, mas uma escrita por outro caminho também fica certa).
create or replace function public.prospeccao_captura_normalizar() returns trigger
language plpgsql set search_path = public as $$
begin
  new.empresa := trim(regexp_replace(new.empresa, '\s+', ' ', 'g'));
  new.empresa_norm := public.prospeccao_norm_empresa(new.empresa);
  new.cidade_norm := public.prospeccao_norm_cidade(new.cidade);
  if new.uf is null then new.uf := public.prospeccao_uf_da_cidade(new.cidade); end if;
  new.telefone_norm := public.prospeccao_norm_telefone(new.telefone, public.prospeccao_ddd_da_cidade(new.cidade));
  new.dominio := coalesce(public.prospeccao_norm_dominio(new.site), public.prospeccao_norm_dominio(new.email));
  new.instagram_handle := public.prospeccao_norm_instagram(new.instagram);
  new.cnpj := public.prospeccao_norm_cnpj(new.cnpj);
  if tg_op = 'UPDATE' then new.updated_at := now(); end if;
  return new;
end $$;
drop trigger if exists prospeccao_captura_normalizar on public.admin_prospeccao_captura;
create trigger prospeccao_captura_normalizar before insert or update on public.admin_prospeccao_captura
  for each row execute function public.prospeccao_captura_normalizar();

alter table public.admin_prospeccao_captura enable row level security;
revoke all on public.admin_prospeccao_captura from anon;
grant select, insert, update, delete on public.admin_prospeccao_captura to authenticated;
grant all on public.admin_prospeccao_captura to service_role;

drop policy if exists captura_select on public.admin_prospeccao_captura;
drop policy if exists captura_insert on public.admin_prospeccao_captura;
drop policy if exists captura_update on public.admin_prospeccao_captura;
drop policy if exists captura_delete on public.admin_prospeccao_captura;
create policy captura_select on public.admin_prospeccao_captura for select to authenticated using (prospeccao_pode_ver_job(job_id));
create policy captura_insert on public.admin_prospeccao_captura for insert to authenticated
  with check (prospeccao_pode_ver_job(job_id) and status in ('pendente','duplicado','possivel_duplicado','bloqueado_optout','erro') and lead_id is null);
-- Update direto só para enriquecimento/decisão simples; aprovar (lead_id/aprovado) é só pela RPC aprovar_captura.
create policy captura_update on public.admin_prospeccao_captura for update to authenticated
  using (prospeccao_pode_ver_job(job_id))
  with check (prospeccao_pode_ver_job(job_id) and status <> 'aprovado' and lead_id is null);
create policy captura_delete on public.admin_prospeccao_captura for delete to authenticated using (admin_eh_admin());
