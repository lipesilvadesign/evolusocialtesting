-- =====================================================================
-- Migration 011 — Refinamento do Lead Capture Engine + apresentação
-- 30/09/2026 · ADITIVA E IDEMPOTENTE (pode rodar de novo sem efeito)
--
-- 1. CORREÇÃO CRÍTICA — aprovação: a constraint admin_audit_log_action_check
--    (existe só em produção) aceitava 8 ações; as RPCs da captação gravam
--    'aprovar_captura', 'arquivar' etc. → erro 23514 → transação inteira
--    desfeita → nenhuma aprovação funcionava. A constraint é recriada com os
--    8 valores ANTIGOS + os usados pelo código. Nenhum valor existente passa
--    a ser recusado (superconjunto).
-- 2. Telemetria da busca: admin_prospeccao_buscas.metricas (jsonb).
-- 3. Cache de resultado por provider (TTL definido pelo código, 24 h padrão).
-- 4. Enriquecimento assíncrono: captura.enriquecimento / enriquecimento_status,
--    leads.enriquecimento; passagem para o lead SÓ preenche campo vazio.
-- 5. Novas oportunidades automáticas (com evidência medida):
--    SITE_SEM_CONTATO, SITE_SEM_FORMULARIO. Score NÃO muda (não inventar peso).
-- 6. apresentacao_publica: devolve só as métricas SELECIONADAS e só campos
--    públicos (antes devolvia todas as métricas do lead, com ids internos).
--
-- Rollback: ver docs/RELATORIO_REFINAMENTO_30_09.md (seção Rollback).
-- Nada é apagado: nenhuma tabela, coluna ou linha.
-- =====================================================================

-- 1 ------------------------------------------------------------------
do $$
begin
  if to_regclass('public.admin_audit_log') is null then return; end if;
  alter table public.admin_audit_log drop constraint if exists admin_audit_log_action_check;
  alter table public.admin_audit_log add constraint admin_audit_log_action_check check (action = any (array[
    -- valores originais (produção)
    'create','update','delete','publish','unpublish','settings_change','permission_change','status_change',
    -- Lead Capture Engine (RPCs, migration 009)
    'aprovar_captura','converter_inbound','arquivar','restaurar','mesclar','mesclar_captura',
    -- Functions (auditLogService.record)
    'captacao_iniciar','captacao_cancelar','importar_csv','importar_criar','importar_atualizar','importar_mesclar',
    'enviar_email_prospeccao','optout_prospeccao','buscar_empresas_manual','enriquecimento_aplicado'
  ]::text[])) not valid;
  alter table public.admin_audit_log validate constraint admin_audit_log_action_check;
end $$;

-- 2 ------------------------------------------------------------------
alter table public.admin_prospeccao_buscas add column if not exists metricas jsonb not null default '{}'::jsonb;
comment on column public.admin_prospeccao_buscas.metricas is
  'Telemetria da execução: {total_ms, providers:{geoapify:{duration_ms,resultados,erro,cache}}, normalizacao_ms, dedup_ms, gravacao_ms, enriquecimento_ms, encontrados, duplicados, disponiveis}';

-- 3 ------------------------------------------------------------------
create table if not exists public.admin_prospeccao_cache_provider (
  chave text primary key check (char_length(chave) between 8 and 200),
  provider text not null check (provider in ('geoapify','overpass','geocodificacao','cnpj')),
  parametros jsonb not null default '{}'::jsonb,
  registros jsonb not null default '[]'::jsonb,
  qtd integer not null default 0,
  criado_em timestamptz not null default now(),
  expira_em timestamptz not null
);
create index if not exists admin_prospeccao_cache_provider_expira on public.admin_prospeccao_cache_provider (expira_em);
alter table public.admin_prospeccao_cache_provider enable row level security;
revoke all on public.admin_prospeccao_cache_provider from anon;
grant select, insert, update on public.admin_prospeccao_cache_provider to authenticated;
grant all on public.admin_prospeccao_cache_provider to service_role;
drop policy if exists cache_provider_select on public.admin_prospeccao_cache_provider;
drop policy if exists cache_provider_insert on public.admin_prospeccao_cache_provider;
drop policy if exists cache_provider_update on public.admin_prospeccao_cache_provider;
create policy cache_provider_select on public.admin_prospeccao_cache_provider for select to authenticated using (prospeccao_pode_operar());
create policy cache_provider_insert on public.admin_prospeccao_cache_provider for insert to authenticated with check (prospeccao_pode_operar());
create policy cache_provider_update on public.admin_prospeccao_cache_provider for update to authenticated
  using (prospeccao_pode_operar()) with check (prospeccao_pode_operar());

-- 4 ------------------------------------------------------------------
alter table public.admin_prospeccao_captura add column if not exists enriquecimento jsonb;
alter table public.admin_prospeccao_captura add column if not exists enriquecimento_status text;
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_captura_enriquecimento_status_check') then
    alter table public.admin_prospeccao_captura add constraint admin_prospeccao_captura_enriquecimento_status_check
      check (enriquecimento_status is null or enriquecimento_status in ('pendente','em_andamento','concluido','parcial','erro','nao_aplicavel'));
  end if;
end $$;
create index if not exists admin_prospeccao_captura_enriq_pend on public.admin_prospeccao_captura (job_id)
  where enriquecimento_status in ('pendente','em_andamento');
alter table public.admin_prospeccao_leads add column if not exists enriquecimento jsonb;

-- 5 ------------------------------------------------------------------
alter table public.admin_prospeccao_oportunidades drop constraint if exists admin_prospeccao_oportunidades_tipo_check;
alter table public.admin_prospeccao_oportunidades add constraint admin_prospeccao_oportunidades_tipo_check check (tipo = any (array[
  'SEM_SITE','SITE_FORA_DO_AR','SITE_SEM_HTTPS','EMPRESA_NOVA','BAIXA_PRESENCA_DIGITAL',
  'INSTAGRAM_INATIVO','INSTAGRAM_DESORGANIZADO','GOOGLE_PERFIL_FRACO','SITE_DESATUALIZADO','IDENTIDADE_INCONSISTENTE','EXPANSAO',
  'SITE_SEM_CONTATO','SITE_SEM_FORMULARIO'
]::text[])) not valid;
alter table public.admin_prospeccao_oportunidades validate constraint admin_prospeccao_oportunidades_tipo_check;

-- aprovar_um passa a copiar também os dois tipos novos (troca só a lista; resto intacto)
do $$
declare d text;
begin
  d := pg_get_functiondef('public.prospeccao_aprovar_um(uuid, uuid, text, text, boolean)'::regprocedure);
  if position('SITE_SEM_CONTATO' in d) = 0 then
    d := replace(d, $x$('SEM_SITE','SITE_FORA_DO_AR','SITE_SEM_HTTPS','EMPRESA_NOVA','BAIXA_PRESENCA_DIGITAL')$x$,
                    $x$('SEM_SITE','SITE_FORA_DO_AR','SITE_SEM_HTTPS','EMPRESA_NOVA','BAIXA_PRESENCA_DIGITAL','SITE_SEM_CONTATO','SITE_SEM_FORMULARIO')$x$);
    if position('SITE_SEM_CONTATO' in d) = 0 then
      raise exception 'prospeccao_aprovar_um: lista de oportunidades não encontrada — migration não aplicada';
    end if;
    execute d;
  end if;
end $$;

-- Enriquecimento que chega DEPOIS da aprovação: leva ao lead só o que estiver vazio lá.
create or replace function public.prospeccao_captura_enriquecimento_para_lead() returns trigger
language plpgsql security definer set search_path = public as $$
declare s jsonb;
begin
  if new.lead_id is null or new.enriquecimento is not distinct from old.enriquecimento then return null; end if;
  update admin_prospeccao_leads l set
    email     = coalesce(nullif(trim(l.email), ''), new.email),
    telefone  = coalesce(nullif(trim(l.telefone), ''), new.telefone),
    instagram = coalesce(nullif(trim(l.instagram), ''), new.instagram),
    cnpj      = coalesce(nullif(trim(l.cnpj), ''), new.cnpj),
    enriquecimento = coalesce(l.enriquecimento, '{}'::jsonb) || coalesce(new.enriquecimento, '{}'::jsonb)
  where l.id = new.lead_id;
  for s in select * from jsonb_array_elements(coalesce(new.sinais, '[]'::jsonb)) loop
    if (s->>'tipo') in ('SEM_SITE','SITE_FORA_DO_AR','SITE_SEM_HTTPS','SITE_SEM_CONTATO','SITE_SEM_FORMULARIO')
       and coalesce(trim(s->>'evidencia'), '') <> ''
       and not exists (select 1 from admin_prospeccao_oportunidades o where o.lead_id = new.lead_id and o.tipo = s->>'tipo' and not o.descartado) then
      insert into admin_prospeccao_oportunidades (lead_id, captura_id, tipo, evidencia, evidencia_url, fonte, confianca, detectado_em)
      values (new.lead_id, new.id, s->>'tipo', s->>'evidencia', s->>'evidencia_url', 'sistema',
              coalesce(s->>'confianca', 'media'), coalesce((s->>'detectado_em')::timestamptz, now()));
    end if;
  end loop;
  return null;
end $$;
revoke all on function public.prospeccao_captura_enriquecimento_para_lead() from public, anon, authenticated;
drop trigger if exists prospeccao_captura_enriquecimento_para_lead on public.admin_prospeccao_captura;
create trigger prospeccao_captura_enriquecimento_para_lead after update of enriquecimento on public.admin_prospeccao_captura
  for each row execute function public.prospeccao_captura_enriquecimento_para_lead();

-- Gravação do enriquecimento: ÚNICA porta de escrita do worker de enriquecimento.
-- Regras no banco (não no JS): só preenche campo VAZIO (e-mail, telefone,
-- Instagram, CNPJ); sinais novos entram sem apagar os existentes (por tipo);
-- nunca mexe em status, lead_id, decisão. Funciona antes e depois da aprovação
-- (depois, o trigger acima leva ao lead só o que lá estiver vazio).
create or replace function public.prospeccao_gravar_enriquecimento(p_captura uuid, p_dados jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c admin_prospeccao_captura%rowtype; v_sinais jsonb; s jsonb; v_status text;
begin
  select * into c from admin_prospeccao_captura where id = p_captura for update;
  if not found then raise exception 'Registro de captação não encontrado.' using errcode = 'P0002'; end if;
  if not (prospeccao_eh_servico() or prospeccao_pode_ver_job(c.job_id)) then
    raise exception 'Sem permissão para enriquecer este registro.' using errcode = '42501';
  end if;
  v_status := coalesce(p_dados->>'status', 'concluido');
  if v_status not in ('pendente','em_andamento','concluido','parcial','erro','nao_aplicavel') then
    raise exception 'Status de enriquecimento inválido.' using errcode = '22023';
  end if;
  v_sinais := coalesce(c.sinais, '[]'::jsonb);
  for s in select * from jsonb_array_elements(case when jsonb_typeof(p_dados->'sinais') = 'array' then p_dados->'sinais' else '[]'::jsonb end) loop
    if (s->>'tipo') in ('SEM_SITE','SITE_FORA_DO_AR','SITE_SEM_HTTPS','SITE_SEM_CONTATO','SITE_SEM_FORMULARIO','EMPRESA_NOVA')
       and coalesce(trim(s->>'evidencia'), '') <> ''
       and not exists (select 1 from jsonb_array_elements(v_sinais) x where x->>'tipo' = s->>'tipo') then
      v_sinais := v_sinais || jsonb_build_array(jsonb_build_object('tipo', s->>'tipo', 'evidencia', left(s->>'evidencia', 1000),
        'evidencia_url', s->>'evidencia_url', 'confianca', case when s->>'confianca' in ('alta','media','baixa') then s->>'confianca' else 'media' end,
        'fonte', 'sistema', 'detectado_em', coalesce(s->>'detectado_em', now()::text)));
    end if;
  end loop;
  update admin_prospeccao_captura set
    email            = coalesce(nullif(trim(email), ''), nullif(left(p_dados->>'email', 200), '')),
    telefone         = coalesce(nullif(trim(telefone), ''), nullif(left(p_dados->>'telefone', 40), '')),
    instagram        = coalesce(nullif(trim(instagram), ''), nullif(left(p_dados->>'instagram', 80), '')),
    instagram_handle = coalesce(nullif(trim(instagram_handle), ''), nullif(left(p_dados->>'instagram_handle', 60), '')),
    cnpj             = coalesce(nullif(trim(cnpj), ''), nullif(left(p_dados->>'cnpj', 20), '')),
    site_verificado_em = coalesce((p_dados->>'site_verificado_em')::timestamptz, site_verificado_em),
    site_http_status   = coalesce((p_dados->>'site_http_status')::int, site_http_status),
    site_https         = coalesce((p_dados->>'site_https')::boolean, site_https),
    sinais = v_sinais,
    enriquecimento = coalesce(enriquecimento, '{}'::jsonb) || coalesce(case when jsonb_typeof(p_dados->'enriquecimento') = 'object' then p_dados->'enriquecimento' end, '{}'::jsonb),
    enriquecimento_status = v_status,
    updated_at = now()
  where id = p_captura;
  return jsonb_build_object('captura_id', p_captura, 'status', v_status, 'sinais', jsonb_array_length(v_sinais));
end $$;
revoke all on function public.prospeccao_gravar_enriquecimento(uuid, jsonb) from public, anon;
grant execute on function public.prospeccao_gravar_enriquecimento(uuid, jsonb) to authenticated, service_role;

-- 6 ------------------------------------------------------------------
do $$
begin
  if to_regclass('public.admin_apresentacoes') is null then return; end if;
  execute $f$
  create or replace function public.apresentacao_publica(p_slug text)
   returns table(slug text, versao integer, tema jsonb, conteudo jsonb, publicado_em timestamptz)
   language sql stable security definer set search_path to 'public'
  as $body$
    select a.slug, a.versao::int, a.tema::jsonb,
      case when jsonb_typeof(a.conteudo::jsonb) = 'object' then
        (a.conteudo::jsonb - 'metricasDisponiveis' - 'metricasIds')
        || jsonb_build_object(
             'metricasIds', coalesce((select jsonb_agg(m->'id') from jsonb_array_elements(
                 case when jsonb_typeof(a.conteudo::jsonb->'metricasDisponiveis') = 'array' then a.conteudo::jsonb->'metricasDisponiveis' else '[]'::jsonb end) m
               where case when jsonb_typeof(a.conteudo::jsonb->'metricasIds') = 'array' then a.conteudo::jsonb->'metricasIds' else '[]'::jsonb end ? (m->>'id')), '[]'::jsonb),
             'metricasDisponiveis', coalesce((select jsonb_agg(jsonb_strip_nulls(jsonb_build_object(
                 'id', m->'id', 'nome', m->'nome', 'valor', m->'valor', 'valor_texto', m->'valor_texto',
                 'unidade', m->'unidade', 'periodo', m->'periodo', 'origem', m->'origem')))
               from jsonb_array_elements(
                 case when jsonb_typeof(a.conteudo::jsonb->'metricasDisponiveis') = 'array' then a.conteudo::jsonb->'metricasDisponiveis' else '[]'::jsonb end) m
               where case when jsonb_typeof(a.conteudo::jsonb->'metricasIds') = 'array' then a.conteudo::jsonb->'metricasIds' else '[]'::jsonb end ? (m->>'id')), '[]'::jsonb))
      else '{}'::jsonb end,
      a.publicado_em
    from admin_apresentacoes a
    where a.slug = p_slug and a.status = 'publicado'
    order by a.versao desc limit 1;
  $body$ $f$;
  execute 'grant execute on function public.apresentacao_publica(text) to anon, authenticated';
end $$;
