-- =====================================================================
-- Migration 002 — Taxonomia: fonte × método × campanha, setor/subsetor
-- Lead Capture Engine · 30/09/2026
--
-- Objetivo
--   Separar as três dimensões que hoje estavam misturadas na coluna fonte
--   (ex.: 'osm_auto' = fonte OSM + método automático):
--     fonte            de onde o dado veio (manual, osm, geoapify, csv, xlsx, site, indicacao, evento)
--     metodo_captacao  como foi obtido (pesquisa_local, sincronizacao_automatica, importacao, formulario, ...)
--     campanha         contexto comercial (slug livre)
--   inbound/outbound NÃO é gravado: é derivado do método (taxonomia.js → direcao()).
--   Também: subsetor, uf, temperatura, origem de conversão, score_calculado_em, origem_ids.
--
-- Compatibilidade: os valores antigos de fonte (osm_auto, osm_manual,
-- geoapify_manual, busca_manual) CONTINUAM aceitos pela constraint — o
-- código publicado antes desta versão ainda grava esses valores.
-- Paridade: listas iguais às de netlify/functions/_lib/captacao/taxonomia.js
-- (tests/captacaoTaxonomia.test.js confere).
--
-- Idempotente. Dependências: 001.
-- Backup: backup_auditoria.prospeccao_leads_30_09 (criado na 001).
-- Rollback:
--   alter table public.admin_prospeccao_leads
--     drop constraint if exists admin_prospeccao_leads_fonte_check,
--     drop constraint if exists admin_prospeccao_leads_metodo_check,
--     drop constraint if exists admin_prospeccao_leads_campanha_check,
--     drop constraint if exists admin_prospeccao_leads_uf_check,
--     drop constraint if exists admin_prospeccao_leads_temperatura_check,
--     drop constraint if exists admin_prospeccao_leads_convertido_de_check;
--   -- restaurar fonte/setor originais a partir do backup:
--   update public.admin_prospeccao_leads l set fonte = b.fonte, setor = b.setor
--     from backup_auditoria.prospeccao_leads_30_09 b where b.id = l.id;
--   alter table public.admin_prospeccao_leads drop column if exists metodo_captacao, drop column if exists campanha,
--     drop column if exists subsetor, drop column if exists uf, drop column if exists temperatura,
--     drop column if exists convertido_de_tipo, drop column if exists convertido_de_id,
--     drop column if exists score_calculado_em, drop column if exists origem_ids;
-- =====================================================================

alter table public.admin_prospeccao_leads
  add column if not exists metodo_captacao text,
  add column if not exists campanha text,
  add column if not exists subsetor text,
  add column if not exists uf text,
  add column if not exists temperatura text,
  add column if not exists convertido_de_tipo text,
  add column if not exists convertido_de_id uuid,
  add column if not exists score_calculado_em timestamptz,
  add column if not exists origem_ids text[] not null default '{}';

comment on column public.admin_prospeccao_leads.fonte is 'DE ONDE o dado veio: manual, osm, geoapify, csv, xlsx, site, indicacao, evento (legados aceitos: osm_auto, osm_manual, geoapify_manual, busca_manual).';
comment on column public.admin_prospeccao_leads.metodo_captacao is 'COMO foi obtido: pesquisa_local, sincronizacao_automatica, importacao, formulario, indicacao, networking, prospeccao_manual. inbound = formulario (derivado, não gravado).';
comment on column public.admin_prospeccao_leads.campanha is 'Contexto comercial (slug [a-z0-9_], até 60). Ex.: coworkings_vale_2026.';
comment on column public.admin_prospeccao_leads.origem_ids is 'Todas as origens externas (osm:..., geoapify:..., consulta:...) que já apontaram para este lead (merge/deduplicação).';

-- Backfill (antes das constraints)
update public.admin_prospeccao_leads set metodo_captacao = case fonte
    when 'osm_auto' then 'sincronizacao_automatica'
    when 'osm_manual' then 'pesquisa_local'
    when 'geoapify_manual' then 'pesquisa_local'
    when 'busca_manual' then 'pesquisa_local'
    else 'prospeccao_manual' end
  where metodo_captacao is null and (fonte is null or fonte in ('manual','osm_auto','osm_manual','geoapify_manual','busca_manual'));
update public.admin_prospeccao_leads set fonte = case fonte
    when 'osm_auto' then 'osm' when 'osm_manual' then 'osm' when 'busca_manual' then 'osm'
    when 'geoapify_manual' then 'geoapify' end
  where fonte in ('osm_auto','osm_manual','geoapify_manual','busca_manual');
update public.admin_prospeccao_leads set fonte = 'manual' where fonte is null;
update public.admin_prospeccao_leads set origem_ids = array[origem_id]
  where origem_id is not null and not (origem_id = any(origem_ids));

-- Setor: grafias antigas de Coworking → setor 'Coworking' + subsetor (sem perder a nuance)
update public.admin_prospeccao_leads
   set subsetor = coalesce(subsetor, nullif(initcap(trim(both ' /()-' from substr(setor, 10))), '')),
       setor = 'Coworking'
 where setor ilike 'coworking%' and setor <> 'Coworking';

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_leads_fonte_check') then
    alter table public.admin_prospeccao_leads add constraint admin_prospeccao_leads_fonte_check check (fonte in
      ('manual','osm','geoapify','csv','xlsx','site','indicacao','evento',
       'osm_auto','osm_manual','geoapify_manual','busca_manual'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_leads_metodo_check') then
    alter table public.admin_prospeccao_leads add constraint admin_prospeccao_leads_metodo_check check (metodo_captacao is null or metodo_captacao in
      ('pesquisa_local','sincronizacao_automatica','importacao','formulario','indicacao','networking','prospeccao_manual'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_leads_campanha_check') then
    alter table public.admin_prospeccao_leads add constraint admin_prospeccao_leads_campanha_check
      check (campanha is null or campanha ~ '^[a-z0-9_]{1,60}$');
  end if;
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_leads_uf_check') then
    alter table public.admin_prospeccao_leads add constraint admin_prospeccao_leads_uf_check
      check (uf is null or uf ~ '^[A-Z]{2}$');
  end if;
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_leads_temperatura_check') then
    alter table public.admin_prospeccao_leads add constraint admin_prospeccao_leads_temperatura_check
      check (temperatura is null or temperatura in ('quente','morno','frio'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_leads_convertido_de_check') then
    alter table public.admin_prospeccao_leads add constraint admin_prospeccao_leads_convertido_de_check
      check (convertido_de_tipo is null or convertido_de_tipo in ('consulta','site_contato'));
  end if;
end $$;

-- Mesma taxonomia no histórico de buscas (capture jobs) — colunas criadas na 005.
