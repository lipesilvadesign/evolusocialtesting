-- =====================================================================
-- Migration 013 — Fase 3: saúde dos providers, sinais medidos novos,
-- contatabilidade, histórico de score, tarefas/próxima ação
-- 01/10/2026 · ADITIVA E IDEMPOTENTE · DOWN no fim do arquivo
--
-- 1. admin_prospeccao_provider_saude: estatística por HOST (espelhos do
--    Overpass, Geoapify) + cooldown (circuito de proteção). Escrita só pela
--    RPC prospeccao_registrar_saude (SECURITY DEFINER, operadores/serviço).
-- 2. Oportunidades medidas novas: SITE_SEM_META_DESCRIPTION, SITE_SEM_FAVICON,
--    SITE_SEM_WHATSAPP, SITE_SEM_INSTAGRAM (CHECK superconjunto; listas de
--    aprovar_um, gravar_enriquecimento e trigger pós-aprovação).
--    Score NÃO muda (pesos são decisão do dono).
-- 3. contatabilidade (coluna GERADA em leads e captura):
--    CONTATO_FORTE  = e-mail ou WhatsApp + pelo menos 2 canais
--    CONTATO_PARCIAL = algum canal (telefone sozinho cai aqui, nunca em "forte")
--    SEM_CONTATO    = nenhum canal
-- 4. admin_prospeccao_score_historico: toda mudança de score (antes → depois,
--    motivos que entraram/saíram, origem). Trigger AFTER no lead.
-- 5. admin_prospeccao_tarefas (lead_id, responsavel_id, tipo, descricao, data,
--    status, created_at, completed_at) + leads.proxima_acao: a tarefa aberta
--    mais próxima vira "próxima ação" do lead (e proxima_atividade_em, que os
--    lembretes já usam). Prospecção só cria tarefa para si; RLS = mesma
--    visibilidade do lead.
-- 6. cache_provider aceita 'site' (TTL definido no código).
-- =====================================================================

-- 1 ------------------------------------------------------------------
create table if not exists public.admin_prospeccao_provider_saude (
  host text primary key check (char_length(host) between 3 and 120),
  provider text not null check (provider in ('geoapify','overpass','nominatim','photon','brasilapi','site')),
  tentativas integer not null default 0,
  sucessos integer not null default 0,
  s429 integer not null default 0,
  s406 integer not null default 0,
  s5xx integer not null default 0,
  timeouts integer not null default 0,
  outros_erros integer not null default 0,
  latencia_media_ms integer,
  falhas_seguidas integer not null default 0,
  ultimo_status text,
  ultimo_sucesso timestamptz,
  ultima_falha timestamptz,
  cooldown_ate timestamptz,
  atualizado_em timestamptz not null default now()
);
alter table public.admin_prospeccao_provider_saude enable row level security;
revoke all on public.admin_prospeccao_provider_saude from anon;
grant select on public.admin_prospeccao_provider_saude to authenticated;
grant all on public.admin_prospeccao_provider_saude to service_role;
drop policy if exists provider_saude_select on public.admin_prospeccao_provider_saude;
create policy provider_saude_select on public.admin_prospeccao_provider_saude for select to authenticated using (prospeccao_pode_operar());

-- p_status: 'ok' | '429' | '406' | '5xx' | 'timeout' | 'erro'
create or replace function public.prospeccao_registrar_saude(p_host text, p_provider text, p_status text, p_ms integer)
returns jsonb language plpgsql security definer set search_path = public as $$
declare r admin_prospeccao_provider_saude%rowtype; v_cool interval;
begin
  if not (prospeccao_pode_operar() or prospeccao_eh_servico()) then
    raise exception 'Sem permissão.' using errcode = '42501';
  end if;
  if p_status not in ('ok','429','406','5xx','timeout','erro') then raise exception 'Status inválido.' using errcode = '22023'; end if;
  insert into admin_prospeccao_provider_saude (host, provider) values (left(p_host, 120), p_provider)
  on conflict (host) do nothing;
  select * into r from admin_prospeccao_provider_saude where host = left(p_host, 120) for update;
  r.tentativas := r.tentativas + 1;
  r.ultimo_status := p_status;
  if p_status = 'ok' then
    r.sucessos := r.sucessos + 1; r.falhas_seguidas := 0; r.ultimo_sucesso := now(); r.cooldown_ate := null;
    r.latencia_media_ms := case when r.latencia_media_ms is null then greatest(p_ms, 0)
                                else round(r.latencia_media_ms * 0.8 + greatest(p_ms, 0) * 0.2) end; -- média móvel
  else
    r.falhas_seguidas := r.falhas_seguidas + 1; r.ultima_falha := now();
    if p_status = '429' then r.s429 := r.s429 + 1;
    elsif p_status = '406' then r.s406 := r.s406 + 1;
    elsif p_status = '5xx' then r.s5xx := r.s5xx + 1;
    elsif p_status = 'timeout' then r.timeouts := r.timeouts + 1;
    else r.outros_erros := r.outros_erros + 1; end if;
    -- circuito: 3 falhas seguidas → cooldown crescente (5, 10, 20… até 60 min)
    if r.falhas_seguidas >= 3 then
      v_cool := make_interval(mins => least(60, 5 * power(2, least(r.falhas_seguidas - 3, 4))::int));
      r.cooldown_ate := now() + v_cool;
    end if;
  end if;
  r.atualizado_em := now();
  update admin_prospeccao_provider_saude set tentativas = r.tentativas, sucessos = r.sucessos, s429 = r.s429, s406 = r.s406,
    s5xx = r.s5xx, timeouts = r.timeouts, outros_erros = r.outros_erros, latencia_media_ms = r.latencia_media_ms,
    falhas_seguidas = r.falhas_seguidas, ultimo_status = r.ultimo_status, ultimo_sucesso = r.ultimo_sucesso,
    ultima_falha = r.ultima_falha, cooldown_ate = r.cooldown_ate, atualizado_em = r.atualizado_em
   where host = r.host;
  return jsonb_build_object('host', r.host, 'cooldown_ate', r.cooldown_ate, 'falhas_seguidas', r.falhas_seguidas);
end $$;
revoke all on function public.prospeccao_registrar_saude(text, text, text, integer) from public, anon;
grant execute on function public.prospeccao_registrar_saude(text, text, text, integer) to authenticated, service_role;

-- 2 ------------------------------------------------------------------
alter table public.admin_prospeccao_oportunidades drop constraint if exists admin_prospeccao_oportunidades_tipo_check;
alter table public.admin_prospeccao_oportunidades add constraint admin_prospeccao_oportunidades_tipo_check check (tipo = any (array[
  'SEM_SITE','SITE_FORA_DO_AR','SITE_SEM_HTTPS','EMPRESA_NOVA','BAIXA_PRESENCA_DIGITAL',
  'INSTAGRAM_INATIVO','INSTAGRAM_DESORGANIZADO','GOOGLE_PERFIL_FRACO','SITE_DESATUALIZADO','IDENTIDADE_INCONSISTENTE','EXPANSAO',
  'SITE_SEM_CONTATO','SITE_SEM_FORMULARIO',
  'SITE_SEM_META_DESCRIPTION','SITE_SEM_FAVICON','SITE_SEM_WHATSAPP','SITE_SEM_INSTAGRAM'
]::text[])) not valid;
alter table public.admin_prospeccao_oportunidades validate constraint admin_prospeccao_oportunidades_tipo_check;

do $$
declare d text;
begin
  d := pg_get_functiondef('public.prospeccao_aprovar_um(uuid, uuid, text, text, boolean)'::regprocedure);
  if position('SITE_SEM_META_DESCRIPTION' in d) = 0 then
    d := replace(d, $x$'SITE_SEM_CONTATO','SITE_SEM_FORMULARIO')$x$,
                    $x$'SITE_SEM_CONTATO','SITE_SEM_FORMULARIO','SITE_SEM_META_DESCRIPTION','SITE_SEM_FAVICON','SITE_SEM_WHATSAPP','SITE_SEM_INSTAGRAM')$x$);
    if position('SITE_SEM_META_DESCRIPTION' in d) = 0 then
      raise exception 'prospeccao_aprovar_um: lista não encontrada — migration não aplicada';
    end if;
    execute d;
  end if;
  d := pg_get_functiondef('public.prospeccao_gravar_enriquecimento(uuid, jsonb)'::regprocedure);
  if position('SITE_SEM_META_DESCRIPTION' in d) = 0 then
    d := replace(d, $x$'SITE_SEM_CONTATO','SITE_SEM_FORMULARIO','EMPRESA_NOVA')$x$,
                    $x$'SITE_SEM_CONTATO','SITE_SEM_FORMULARIO','EMPRESA_NOVA','SITE_SEM_META_DESCRIPTION','SITE_SEM_FAVICON','SITE_SEM_WHATSAPP','SITE_SEM_INSTAGRAM')$x$);
    if position('SITE_SEM_META_DESCRIPTION' in d) = 0 then
      raise exception 'prospeccao_gravar_enriquecimento: lista não encontrada — migration não aplicada';
    end if;
    execute d;
  end if;
  d := pg_get_functiondef('public.prospeccao_captura_enriquecimento_para_lead()'::regprocedure);
  if position('SITE_SEM_META_DESCRIPTION' in d) = 0 then
    d := replace(d, $x$'SITE_SEM_CONTATO','SITE_SEM_FORMULARIO')$x$,
                    $x$'SITE_SEM_CONTATO','SITE_SEM_FORMULARIO','SITE_SEM_META_DESCRIPTION','SITE_SEM_FAVICON','SITE_SEM_WHATSAPP','SITE_SEM_INSTAGRAM')$x$);
    if position('SITE_SEM_META_DESCRIPTION' in d) = 0 then
      raise exception 'prospeccao_captura_enriquecimento_para_lead: lista não encontrada — migration não aplicada';
    end if;
    execute d;
  end if;
end $$;

-- 3 ------------------------------------------------------------------
create or replace function public.prospeccao_contatabilidade(p_telefone text, p_email text, p_instagram text, p_site text, p_enriq jsonb)
returns text language sql immutable as $$
  with c as (
    select (nullif(trim(coalesce(p_telefone, '')), '') is not null and length(regexp_replace(p_telefone, '\D', '', 'g')) >= 10) tel,
           nullif(trim(coalesce(p_email, '')), '') is not null and p_email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' email,
           nullif(trim(coalesce(p_instagram, '')), '') is not null insta,
           nullif(trim(coalesce(p_site, '')), '') is not null
             and coalesce(p_enriq->'site'->>'resultado', 'ok') not in ('fora_do_ar') site,
           coalesce((p_enriq->'site'->>'whatsapp')::boolean, false) whats
  )
  select case
    when (email or whats) and ((tel::int + email::int + insta::int + site::int + whats::int) >= 2) then 'CONTATO_FORTE'
    when (tel or email or insta or site or whats) then 'CONTATO_PARCIAL'
    else 'SEM_CONTATO' end
  from c
$$;

do $$ begin
  if not exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'admin_prospeccao_leads' and column_name = 'contatabilidade') then
    alter table public.admin_prospeccao_leads add column contatabilidade text
      generated always as (public.prospeccao_contatabilidade(telefone, email, instagram, site, enriquecimento)) stored;
  end if;
  if not exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'admin_prospeccao_captura' and column_name = 'contatabilidade') then
    alter table public.admin_prospeccao_captura add column contatabilidade text
      generated always as (public.prospeccao_contatabilidade(telefone, email, instagram, site, enriquecimento)) stored;
  end if;
end $$;

-- 4 ------------------------------------------------------------------
create table if not exists public.admin_prospeccao_score_historico (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.admin_prospeccao_leads(id) on delete cascade,
  score_anterior integer,
  score_novo integer,
  entrou jsonb not null default '[]'::jsonb,
  saiu jsonb not null default '[]'::jsonb,
  origem text not null default 'automatico',
  criado_em timestamptz not null default now()
);
create index if not exists admin_prospeccao_score_historico_lead on public.admin_prospeccao_score_historico (lead_id, criado_em desc);
alter table public.admin_prospeccao_score_historico enable row level security;
revoke all on public.admin_prospeccao_score_historico from anon;
grant select on public.admin_prospeccao_score_historico to authenticated;
grant all on public.admin_prospeccao_score_historico to service_role;
drop policy if exists score_historico_select on public.admin_prospeccao_score_historico;
create policy score_historico_select on public.admin_prospeccao_score_historico for select to authenticated using (admin_pode_ver_lead(lead_id));

create or replace function public.prospeccao_score_historico() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_novos jsonb; v_velhos jsonb;
begin
  if tg_op = 'UPDATE' and new.score is not distinct from old.score then return null; end if;
  select coalesce(jsonb_agg(m), '[]') into v_novos from jsonb_array_elements(coalesce(new.score_motivos, '[]')) m
   where tg_op = 'INSERT' or not coalesce(old.score_motivos, '[]') @> jsonb_build_array(m);
  if tg_op = 'UPDATE' then
    select coalesce(jsonb_agg(m), '[]') into v_velhos from jsonb_array_elements(coalesce(old.score_motivos, '[]')) m
     where not coalesce(new.score_motivos, '[]') @> jsonb_build_array(m);
  end if;
  insert into admin_prospeccao_score_historico (lead_id, score_anterior, score_novo, entrou, saiu, origem)
  values (new.id, case when tg_op = 'UPDATE' then old.score end, new.score, v_novos, coalesce(v_velhos, '[]'),
          coalesce(nullif(current_setting('app.score_origem', true), ''), case when tg_op = 'INSERT' then 'criacao' else 'automatico' end));
  return null;
end $$;
revoke all on function public.prospeccao_score_historico() from public, anon, authenticated;
drop trigger if exists prospeccao_leads_score_historico on public.admin_prospeccao_leads;
create trigger prospeccao_leads_score_historico after insert or update of score on public.admin_prospeccao_leads
  for each row execute function public.prospeccao_score_historico();

-- ponto de partida: o score atual de cada lead (uma vez)
insert into public.admin_prospeccao_score_historico (lead_id, score_anterior, score_novo, entrou, origem)
select l.id, null, l.score, coalesce(l.score_motivos, '[]'), 'linha_de_base_013'
  from public.admin_prospeccao_leads l
 where l.score is not null
   and not exists (select 1 from public.admin_prospeccao_score_historico h where h.lead_id = l.id);

-- 5 ------------------------------------------------------------------
alter table public.admin_prospeccao_leads add column if not exists proxima_acao text;

create table if not exists public.admin_prospeccao_tarefas (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.admin_prospeccao_leads(id) on delete cascade,
  responsavel_id uuid,
  tipo text not null check (tipo in ('ligar','whatsapp','email','reuniao','enviar_diagnostico','enviar_proposta','follow_up','outro')),
  descricao text not null check (char_length(trim(descricao)) between 2 and 300),
  data timestamptz not null,
  status text not null default 'aberta' check (status in ('aberta','concluida','cancelada')),
  criado_por uuid default auth.uid(),
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
create index if not exists admin_prospeccao_tarefas_lead on public.admin_prospeccao_tarefas (lead_id, status, data);
create index if not exists admin_prospeccao_tarefas_resp on public.admin_prospeccao_tarefas (responsavel_id, status, data);
alter table public.admin_prospeccao_tarefas enable row level security;
revoke all on public.admin_prospeccao_tarefas from anon;
grant select, insert, update on public.admin_prospeccao_tarefas to authenticated;
grant all on public.admin_prospeccao_tarefas to service_role;
drop policy if exists tarefas_select on public.admin_prospeccao_tarefas;
drop policy if exists tarefas_insert on public.admin_prospeccao_tarefas;
drop policy if exists tarefas_update on public.admin_prospeccao_tarefas;
create policy tarefas_select on public.admin_prospeccao_tarefas for select to authenticated using (admin_pode_ver_lead(lead_id));
create policy tarefas_insert on public.admin_prospeccao_tarefas for insert to authenticated
  with check (admin_pode_ver_lead(lead_id) and (admin_eh_admin() or responsavel_id = auth.uid()));
create policy tarefas_update on public.admin_prospeccao_tarefas for update to authenticated
  using (admin_pode_ver_lead(lead_id)) with check (admin_pode_ver_lead(lead_id) and (admin_eh_admin() or responsavel_id = auth.uid()));
-- sem DELETE: tarefa é cancelada, não apagada (histórico)

create or replace function public.prospeccao_tarefas_guarda() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.responsavel_id := coalesce(new.responsavel_id, (select responsavel_id from admin_prospeccao_leads where id = new.lead_id), auth.uid());
    new.criado_por := coalesce(auth.uid(), new.criado_por);
    new.created_at := now();
  else
    new.lead_id := old.lead_id; new.criado_por := old.criado_por; new.created_at := old.created_at; -- imutáveis
  end if;
  if new.responsavel_id is not null and not exists (select 1 from admin_funcionarios f where f.id = new.responsavel_id and f.ativo and f.role in ('admin','prospeccao')) then
    raise exception 'Responsável inválido (precisa ser admin ou prospecção ativo).' using errcode = '22023';
  end if;
  new.completed_at := case when new.status = 'concluida' then coalesce(new.completed_at, now()) else null end;
  return new;
end $$;
drop trigger if exists prospeccao_tarefas_guarda on public.admin_prospeccao_tarefas;
create trigger prospeccao_tarefas_guarda before insert or update on public.admin_prospeccao_tarefas
  for each row execute function public.prospeccao_tarefas_guarda();

-- próxima ação do lead = tarefa ABERTA mais próxima (lembretes já usam proxima_atividade_em)
create or replace function public.prospeccao_tarefas_proxima_acao() returns trigger
language plpgsql security definer set search_path = public as $$
declare t record; v_lead uuid := coalesce(new.lead_id, old.lead_id);
begin
  select descricao, data into t from admin_prospeccao_tarefas where lead_id = v_lead and status = 'aberta' order by data asc limit 1;
  if found then
    update admin_prospeccao_leads set proxima_acao = t.descricao, proxima_atividade_em = t.data where id = v_lead;
  else
    update admin_prospeccao_leads set proxima_acao = null where id = v_lead and proxima_acao is not null;
  end if;
  return null;
end $$;
revoke all on function public.prospeccao_tarefas_proxima_acao() from public, anon, authenticated;
revoke all on function public.prospeccao_tarefas_guarda() from public, anon, authenticated;
drop trigger if exists prospeccao_tarefas_proxima_acao on public.admin_prospeccao_tarefas;
create trigger prospeccao_tarefas_proxima_acao after insert or update on public.admin_prospeccao_tarefas
  for each row execute function public.prospeccao_tarefas_proxima_acao();

-- 6 ------------------------------------------------------------------
alter table public.admin_prospeccao_cache_provider drop constraint if exists admin_prospeccao_cache_provider_provider_check;
alter table public.admin_prospeccao_cache_provider add constraint admin_prospeccao_cache_provider_provider_check
  check (provider in ('geoapify','overpass','geocodificacao','cnpj','site')) not valid;
alter table public.admin_prospeccao_cache_provider validate constraint admin_prospeccao_cache_provider_provider_check;

-- =====================================================================
-- DOWN (rollback manual, na ordem; NÃO apaga leads nem atividades):
--   drop trigger prospeccao_tarefas_proxima_acao on admin_prospeccao_tarefas;
--   drop trigger prospeccao_tarefas_guarda on admin_prospeccao_tarefas;
--   drop trigger prospeccao_leads_score_historico on admin_prospeccao_leads;
--   alter table admin_prospeccao_leads drop column contatabilidade;      -- coluna gerada, recalculável
--   alter table admin_prospeccao_captura drop column contatabilidade;
--   funções anteriores de aprovar_um / gravar_enriquecimento / enriquecimento_para_lead:
--     backup_auditoria.objetos_01_10_013
--   As tabelas novas (tarefas, score_historico, provider_saude) podem ficar
--   (o código antigo as ignora); apagá-las perde histórico — só com decisão do dono.
-- =====================================================================
