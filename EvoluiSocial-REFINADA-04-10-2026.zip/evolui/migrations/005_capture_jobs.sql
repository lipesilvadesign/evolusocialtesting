-- =====================================================================
-- Migration 005 — admin_prospeccao_buscas vira o CAPTURE JOB
-- Lead Capture Engine · 30/09/2026
--
-- Objetivo
--   Estender a tabela existente (sem tabela paralela): tipo, fonte, método,
--   campanha, parâmetros, providers, dono (criado_por_id), etapa, datas e
--   contadores. Estados: os antigos (em_andamento, concluido, erro) seguem
--   válidos; entram na_fila, em_revisao, cancelado.
--   RLS: antes QUALQUER funcionário ativo (inclusive papel design) via e
--   editava qualquer busca. Agora: admin vê todas; prospecção vê/edita só as
--   próprias; outros papéis não veem.
--
-- Compatibilidade com o código publicado antes: criado_por_id tem default
-- auth.uid(), então o insert antigo (sem essa coluna) continua passando.
--
-- Idempotente. Dependências: 002.
-- Backup: backup_auditoria.policies_30_09_lce (políticas substituídas).
-- Rollback:
--   -- recriar políticas antigas a partir do backup (colunas policyname/cmd/qual/with_check)
--   drop policy if exists buscas_select on public.admin_prospeccao_buscas; (idem insert/update/delete)
--   create policy funcionario_select on public.admin_prospeccao_buscas for select using (admin_eh_funcionario_ativo());
--   create policy funcionario_insert on public.admin_prospeccao_buscas for insert with check (admin_eh_funcionario_ativo());
--   create policy funcionario_update on public.admin_prospeccao_buscas for update using (admin_eh_funcionario_ativo());
--   alter table public.admin_prospeccao_buscas drop constraint admin_prospeccao_buscas_status_check;
--   alter table public.admin_prospeccao_buscas add constraint admin_prospeccao_buscas_status_check check (status in ('em_andamento','concluido','erro'));
--   (só se não houver linhas com status novos) e drop das colunas novas.
-- =====================================================================

create schema if not exists backup_auditoria;
do $$ begin
  if to_regclass('backup_auditoria.policies_30_09_lce') is null then
    create table backup_auditoria.policies_30_09_lce as
      select now() as salvo_em, schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
        from pg_policies where schemaname = 'public'
         and tablename in ('admin_prospeccao_buscas','admin_prospeccao_leads','admin_prospeccao_optouts','admin_prospeccao_envios','consultas_leads','site_contatos');
  end if;
end $$;

alter table public.admin_prospeccao_buscas
  add column if not exists tipo text not null default 'pesquisa',
  add column if not exists fonte text,
  add column if not exists metodo_captacao text,
  add column if not exists campanha text,
  add column if not exists parametros jsonb not null default '{}'::jsonb,
  add column if not exists providers text[] not null default '{}',
  add column if not exists criado_por_id uuid default auth.uid(),
  add column if not exists etapa text,
  add column if not exists iniciado_em timestamptz,
  add column if not exists finalizado_em timestamptz,
  add column if not exists qtd_encontrados int not null default 0,
  add column if not exists qtd_normalizados int not null default 0,
  add column if not exists qtd_duplicados int not null default 0,
  add column if not exists qtd_possiveis_duplicados int not null default 0,
  add column if not exists qtd_descartados int not null default 0,
  add column if not exists qtd_bloqueados int not null default 0,
  add column if not exists qtd_aprovados int not null default 0,
  add column if not exists erros jsonb not null default '[]'::jsonb;

comment on table public.admin_prospeccao_buscas is 'Capture job do Lead Capture Engine (uma execução de captação: pesquisa, importação, inbound). Nome mantido por compatibilidade.';

-- Backfill: dono das buscas antigas pelo e-mail gravado em criado_por
update public.admin_prospeccao_buscas b set criado_por_id = f.id
  from public.admin_funcionarios f
 where b.criado_por_id is null and lower(f.email) = lower(b.criado_por);
update public.admin_prospeccao_buscas set iniciado_em = created_at where iniciado_em is null;
update public.admin_prospeccao_buscas set finalizado_em = coalesce(updated_at, created_at)
 where finalizado_em is null and status in ('concluido','erro');
update public.admin_prospeccao_buscas set qtd_encontrados = coalesce(total_encontrado, 0) where qtd_encontrados = 0 and total_encontrado > 0;

alter table public.admin_prospeccao_buscas drop constraint if exists admin_prospeccao_buscas_status_check;
alter table public.admin_prospeccao_buscas add constraint admin_prospeccao_buscas_status_check
  check (status in ('na_fila','em_andamento','em_revisao','concluido','erro','cancelado'));
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'admin_prospeccao_buscas_tipo_check') then
    alter table public.admin_prospeccao_buscas add constraint admin_prospeccao_buscas_tipo_check
      check (tipo in ('pesquisa','importacao','inbound','manual'));
    alter table public.admin_prospeccao_buscas add constraint admin_prospeccao_buscas_etapa_check
      check (etapa is null or etapa in ('coleta','normalizacao','deduplicacao','enriquecimento','score'));
    alter table public.admin_prospeccao_buscas add constraint admin_prospeccao_buscas_metodo_check check (metodo_captacao is null or metodo_captacao in
      ('pesquisa_local','sincronizacao_automatica','importacao','formulario','indicacao','networking','prospeccao_manual'));
    alter table public.admin_prospeccao_buscas add constraint admin_prospeccao_buscas_campanha_check
      check (campanha is null or campanha ~ '^[a-z0-9_]{1,60}$');
  end if;
end $$;

create index if not exists admin_prospeccao_buscas_dono_idx on public.admin_prospeccao_buscas (criado_por_id, created_at desc);
create index if not exists admin_prospeccao_buscas_status_idx on public.admin_prospeccao_buscas (status) where status in ('na_fila','em_andamento','em_revisao');

-- Jobs que não são pesquisa não têm cidades
alter table public.admin_prospeccao_buscas alter column cidades set default '{}';
alter table public.admin_prospeccao_buscas alter column ramo set default '';

-- "É rotina do sistema?" — service role (JWT) ou manutenção direta no banco
-- (sem JWT, conexão do dono). NÃO usa current_user: dentro de função
-- SECURITY DEFINER o current_user vira o dono da função (bug encontrado
-- pelo robô em 30/09: todo mundo parecia "serviço").
create or replace function public.prospeccao_eh_servico() returns boolean
language sql stable set search_path = public as $$
  select coalesce(auth.role(), '') = 'service_role'
      or (coalesce(current_setting('request.jwt.claims', true), '') = ''
          and coalesce(current_setting('request.jwt.claim.role', true), '') = ''
          and session_user in ('postgres', 'supabase_admin'))
$$;

-- Quem pode ver/operar um job (usado também pela captura e pelas RPCs)
create or replace function public.prospeccao_pode_operar() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(admin_funcionario_role() in ('admin','prospeccao'), false)
$$;

create or replace function public.prospeccao_pode_ver_job(p_job_id uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select admin_eh_admin() or exists (
    select 1 from admin_prospeccao_buscas b
     where b.id = p_job_id and b.criado_por_id = auth.uid() and admin_funcionario_role() = 'prospeccao')
$$;

drop policy if exists funcionario_select on public.admin_prospeccao_buscas;
drop policy if exists funcionario_insert on public.admin_prospeccao_buscas;
drop policy if exists funcionario_update on public.admin_prospeccao_buscas;
drop policy if exists buscas_select on public.admin_prospeccao_buscas;
drop policy if exists buscas_insert on public.admin_prospeccao_buscas;
drop policy if exists buscas_update on public.admin_prospeccao_buscas;
drop policy if exists buscas_delete on public.admin_prospeccao_buscas;
create policy buscas_select on public.admin_prospeccao_buscas for select to authenticated
  using (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and criado_por_id = (select auth.uid())));
create policy buscas_insert on public.admin_prospeccao_buscas for insert to authenticated
  with check (prospeccao_pode_operar() and criado_por_id = (select auth.uid()));
create policy buscas_update on public.admin_prospeccao_buscas for update to authenticated
  using (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and criado_por_id = (select auth.uid())))
  with check (admin_eh_admin() or (admin_funcionario_role() = 'prospeccao' and criado_por_id = (select auth.uid())));
create policy buscas_delete on public.admin_prospeccao_buscas for delete to authenticated
  using (admin_eh_admin());
revoke all on public.admin_prospeccao_buscas from anon;
