-- ============================================================
-- CORREÇÃO DEFINITIVA — "Acesso não configurado" no painel
-- ============================================================
-- Idempotente: seguro rodar quantas vezes precisar, em qualquer estado
-- atual do banco. Escopo deliberadamente limitado a admin_funcionarios e
-- ao que a policy dela depende (não mexe nas demais tabelas do projeto,
-- pra não falhar caso alguma outra migração pendente ainda não tenha sido
-- aplicada).
--
-- Cobre as 3 causas possíveis do problema:
--   a) tabela/linha ausente          -> criada/inserida
--   b) ativo=false                   -> reativado
--   c) funções/policies de RLS ausentes, incompletas ou desatualizadas
--      (causa mais provável neste caso, já que a linha em si já estava
--      correta) -> recriadas do zero com CREATE OR REPLACE / DROP+CREATE
-- ============================================================

-- 1) Tabela (não recria se já existir)
create table if not exists admin_funcionarios (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  email text not null,
  role text not null check (role in ('admin', 'prospeccao', 'design')),
  ativo boolean not null default true,
  criado_por text,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);
alter table admin_funcionarios enable row level security;

-- 2) Funções auxiliares (security definer) — reescritas sempre, corrige
-- o caso de nunca terem sido criadas ou terem sido criadas com bug.
create or replace function admin_funcionario_role()
returns text
language sql
security definer
stable
as $$
  select role from admin_funcionarios where id = auth.uid() and ativo = true limit 1;
$$;

create or replace function admin_eh_admin()
returns boolean
language sql
security definer
stable
as $$
  select coalesce(admin_funcionario_role() = 'admin', false);
$$;

create or replace function admin_pode_ver_lead(p_lead_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select admin_eh_admin() or exists (
    select 1 from admin_prospeccao_leads where id = p_lead_id and responsavel_id = auth.uid()
  );
$$;

-- 3) Policies de admin_funcionarios — dropa (todos os nomes possíveis,
-- antigos e novos) e recria do zero, garantindo que existem exatamente
-- como devem.
drop policy if exists "authenticated_select_funcionarios" on admin_funcionarios;
drop policy if exists "authenticated_insert_funcionarios" on admin_funcionarios;
drop policy if exists "authenticated_update_funcionarios" on admin_funcionarios;
drop policy if exists "authenticated_delete_funcionarios" on admin_funcionarios;
drop policy if exists "select_propria_linha_ou_admin" on admin_funcionarios;
drop policy if exists "somente_admin_insert_funcionarios" on admin_funcionarios;
drop policy if exists "somente_admin_update_funcionarios" on admin_funcionarios;
drop policy if exists "somente_admin_delete_funcionarios" on admin_funcionarios;

create policy "select_propria_linha_ou_admin" on admin_funcionarios for select
  using (admin_eh_admin() or id = auth.uid());
create policy "somente_admin_insert_funcionarios" on admin_funcionarios for insert
  with check (admin_eh_admin());
create policy "somente_admin_update_funcionarios" on admin_funcionarios for update
  using (admin_eh_admin());
create policy "somente_admin_delete_funcionarios" on admin_funcionarios for delete
  using (admin_eh_admin());

-- 4) Backfill de segurança: qualquer auth.users que ainda não tenha linha
-- em admin_funcionarios vira 'admin' (ninguém que já usa o sistema perde
-- acesso). Quem já tem linha não é tocado aqui.
insert into admin_funcionarios (id, nome, email, role, ativo)
select id, coalesce(raw_user_meta_data->>'nome', split_part(email, '@', 1)), email, 'admin', true
from auth.users
on conflict (id) do nothing;

-- 5) Garante que a conta que reportou o problema está ativa (só age se
-- estiver desativada — não sobrescreve um role que você já tenha ajustado).
update admin_funcionarios
set ativo = true, updated_at = now()
where email = 'marketing@felipebranding.com.br' and ativo = false;

-- 6) Conferência final — rode e confira o resultado:
--    funcoes_criadas  esperado: 2
--    policies_criadas esperado: 4
--    role_marketing   esperado: 'admin' (ou o papel que você definiu)
--    ativo_marketing  esperado: true
select
  (select count(*) from pg_proc where proname in ('admin_funcionario_role','admin_eh_admin')) as funcoes_criadas,
  (select count(*) from pg_policies where tablename = 'admin_funcionarios') as policies_criadas,
  (select role from admin_funcionarios where email = 'marketing@felipebranding.com.br') as role_marketing,
  (select ativo from admin_funcionarios where email = 'marketing@felipebranding.com.br') as ativo_marketing;
